create PROCEDURE       "VQA_PLSQL_MFR_VENDOR"
IS
   /*--------------------------------------------------------------*
      CREATE DATE:  2008/02/25
      PLSQL      :  VQA_PLSQL_MFR_VENDOR
      Author     :  Shuya
      Purpase    :  每月執行一次
   *---------------------------------------------------------------*/
   vvendor_code       vqa_010_irr_weekly_t.vendor_code%TYPE;
   vcompany_code      vqa_010_irr_weekly_t.company_code%TYPE;
   vprocee_yyyymmdd   VARCHAR2 (8);
   vprocee_yyyymm     VARCHAR2 (6);
   itracepoint        VARCHAR2 (100);
   cerrortext         VARCHAR2 (500);
   record_count       NUMBER (6, 0);
BEGIN
   --抓當月份系統日期
   itracepoint := '000';
   vprocee_yyyymmdd := TO_CHAR (SYSDATE, 'YYYYMMDD');
   vprocee_yyyymm := SUBSTRB (vprocee_yyyymmdd, 1, 6);
   itracepoint := 0;

   FOR rec1 IN (SELECT DISTINCT mfr_name, global_vendor_code
                           FROM vqa_pdm_pn_data a, vqa_vew001_ir_data b
                          WHERE b.part_no = TRIM(USI_PN || ' ' || SEQUENCE))
   LOOP
      SELECT COUNT (*)
        INTO record_count
        FROM vqa_avl_relation
       WHERE manufacturer_name = rec1.mfr_name
         AND global_vendor_code = rec1.global_vendor_code;

      IF record_count = 0
      THEN
         INSERT INTO vqa_avl_relation
              VALUES (rec1.mfr_name, rec1.global_vendor_code, SYSDATE);
      END IF;

      COMMIT;
   END LOOP;

   COMMIT;
   mail_file_bidbdbadmin
                 (in_to_name      => 'shuya_chen@usiglobal.com',
                  subject         => '[VQA] PL/SQL VQA_PLSQL_MFR_VENDOR Succeed',
                  MESSAGE         =>    '[VQA_PLSQL_MFR_VENDOR], The total count is  '
                                     || TO_CHAR (itracepoint)
                 );
EXCEPTION
   WHEN OTHERS
   THEN
      --有錯誤產生則寄mail
      cerrortext := SQLERRM ();
      mail_file_bidbdbadmin
                 (in_to_name      => 'shuya_chen@usiglobal.com',
                  subject         => '[VQA] PL/SQL VQA_PLSQL_MFR_VENDOR ERROR',
                  MESSAGE         =>    '[VQA_PLSQL_MFR_VENDOR], The tracepoint is  '
                                     || itracepoint
                                     || ' and ErrorText= '
                                     || cerrortext
                 );
END vqa_plsql_mfr_vendor;
/

