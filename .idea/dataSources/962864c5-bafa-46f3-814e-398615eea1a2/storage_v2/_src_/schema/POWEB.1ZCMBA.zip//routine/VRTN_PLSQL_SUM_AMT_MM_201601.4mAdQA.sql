create PROCEDURE         "VRTN_PLSQL_SUM_AMT_MM_201601" AUTHID DEFINER
IS
  /*
    每月一號執行一次, 20160301 for 2015Q1 201503 Mothly
  */

  vYYYY                      varchar2(4);
  vMM                        varchar2(2);
  vYYYYQQ                    varchar2(6);
  vIR_AMT_TWD                PLD_KPI_IR_DETAIL.IR_AMT_TWD%TYPE;

  iTracePoint                varchar2(100);
  cErrorText                 varchar2(500);
  --add
  vPROCEE_YYYYMM             varchar2(6);

BEGIN
  iTracePoint := '000';
  select * into vYYYY, vMM, vYYYYQQ from (
    select trim(to_char(add_months(SYSDATE,-1), 'YYYY')), trim(to_char(add_months(SYSDATE,-1), 'MM')),
           trim(trim(to_char(add_months(SYSDATE,-1), 'YYYY')) || 'Q' || trim(to_char(add_months(SYSDATE,-1), 'Q')))
      from dual
  );
  

  vYYYYQQ := '2020Q1';
  vPROCEE_YYYYMM := '202002';
  vYYYY   := '2020';
  vMM     := '02';


  --刪除 VRTN_SUM01_AMT_MATGP_M
  iTracePoint := '100';
  delete from VRTN_SUM01_AMT_MATGP_M
   where YYYY = vYYYY
     and MM = vMM;
  commit;

  iTracePoint := '110';
  insert into VRTN_SUM01_AMT_MATGP_M ( SITE, VENDOR, GV_VENDOR, MATGROUP, YYYY, MM, QUARTER, BUKRS, AMOUNT, DATE_TIME )
     select a.COMPANY_CODE as SITE, a.VENDOR_ID as VENDOR, d.GLOBAL_VENDOR_CODE as GV_VENDOR, a.MTL_GROUP as MATGROUP,
            vYYYY as YYYY, vMM as MM, vYYYYQQ as QUARTER, a.COMPANY_CODE as BUKRS, round(sum(a.IR_AMT_TWD),5) as AMOUNT,
            to_char(SYSDATE, 'yyyymmddhh24miss') as DATE_TIME
       from PLD_KPI_IR_DETAIL a, PLD_KPI_VENDOR_MASTER b, VRTN_COMPANY_SITE c, GVM032_GLOBAL_VENDOR_ITEM d
      where SUBSTRB(a.IR_DATE,1,4) = SUBSTRB(vPROCEE_YYYYMM,1,4)
        and SUBSTRB(a.IR_DATE,5,2) = SUBSTRB(vPROCEE_YYYYMM,5,2)
    --where substr(a.IR_DATE,1,4) = vYYYY
    --  and substr(a.IR_DATE,5,2) = vMM
        and c.MFG_SITE = a.COMPANY_CODE
        and a.MTL_GROUP >= '001'
        and a.MTL_GROUP <= '059'
        and b.COMPANY_CODE = a.COMPANY_CODE
        and b.VENDOR_ID = a.VENDOR_ID
    --  and b.REC_ACCOUNT <> '0000214202' 
        and d.COMPANY_CODE = a.COMPANY_CODE
        and d.SAP_VENDOR_CODE = a.VENDOR_ID
        and d.GLOBAL_VENDOR_CODE not in ('H00000','H00001','H00002')
      group by a.COMPANY_CODE, a.VENDOR_ID, d.GLOBAL_VENDOR_CODE, a.MTL_GROUP;
  commit;

  iTracePoint := '120';  --MATGROUP, GV_VENDOR
  for REC1 in (
     select distinct MATGROUP, GV_VENDOR from VRTN_SUM01_AMT_MATGP_M
      where YYYY = vYYYY and MM = vMM
  ) loop
     BEGIN
       select * into vIR_AMT_TWD from (
         select round(sum(AMOUNT),5) from VRTN_SUM01_AMT_MATGP_M
          where YYYY = vYYYY
            and MM = vMM
            and MATGROUP = REC1.MATGROUP
            and GV_VENDOR = REC1.GV_VENDOR
       );
     EXCEPTION
       When OTHERS Then
         vIR_AMT_TWD := 0;
     END;
     Update VRTN_SUM01_AMT_MATGP_M
        set GV_PER = round(AMOUNT / vIR_AMT_TWD, 5)
      where YYYY = vYYYY
        and MM = vMM
        and MATGROUP = REC1.MATGROUP
        and GV_VENDOR = REC1.GV_VENDOR;
     commit;
  end loop;

  iTracePoint := '130';  --SITE
  for REC1 in (
     select distinct SITE from VRTN_SUM01_AMT_MATGP_M
      where YYYY = vYYYY and MM = vMM
  ) loop
     BEGIN
       select * into vIR_AMT_TWD from (
         select round(sum(AMOUNT),5) from VRTN_SUM01_AMT_MATGP_M
          where YYYY = vYYYY
            and MM = vMM
            and SITE = REC1.SITE
       );
     EXCEPTION
       When OTHERS Then
         vIR_AMT_TWD := 0;
     END;
     Update VRTN_SUM01_AMT_MATGP_M
        set SITE_PER = round(AMOUNT / vIR_AMT_TWD, 5)
      where YYYY = vYYYY
        and MM = vMM
        and SITE = REC1.SITE;
     commit;
  end loop;


  --刪除 VRTN_SUM02_AMT_VM_M
  iTracePoint := '200';
  delete from VRTN_SUM02_AMT_VM_M
   where YYYY = vYYYY
     and MM = vMM;
  commit;

  iTracePoint := '210';
  insert into VRTN_SUM02_AMT_VM_M ( SITE, VENDOR, GV_VENDOR, YYYY, MM, QUARTER, BUKRS, AMOUNT, DATE_TIME )
     select a.COMPANY_CODE as SITE, a.VENDOR_ID as VENDOR, d.GLOBAL_VENDOR_CODE as GV_VENDOR,
            vYYYY as YYYY, vMM as MM, vYYYYQQ as QUARTER, a.COMPANY_CODE as BUKRS, round(sum(a.IR_AMT_TWD),5) as AMOUNT,
            to_char(SYSDATE, 'yyyymmddhh24miss') as DATE_TIME
       from PLD_KPI_IR_DETAIL a, PLD_KPI_VENDOR_MASTER b, VRTN_COMPANY_SITE c, GVM032_GLOBAL_VENDOR_ITEM d
       where SUBSTRB(a.IR_DATE,1,4) = SUBSTRB(vPROCEE_YYYYMM,1,4)
         and SUBSTRB(a.IR_DATE,5,2) = SUBSTRB(vPROCEE_YYYYMM,5,2)
    --  where substr(a.IR_DATE,1,4) = vYYYY
    --    and substr(a.IR_DATE,5,2) = vMM
        and a.GLOBAL_VENDOR_CODE not in ('H00000','H00001','H00002')
        and c.MFG_SITE = a.COMPANY_CODE
        and a.MTL_GROUP >= '001'
        and a.MTL_GROUP <= '059'
        and b.COMPANY_CODE = a.COMPANY_CODE
        and b.VENDOR_ID = a.VENDOR_ID
  --      and b.REC_ACCOUNT <> '0000214202'
        and d.COMPANY_CODE = a.COMPANY_CODE
        and d.SAP_VENDOR_CODE = a.VENDOR_ID
        and d.GLOBAL_VENDOR_CODE not in ('H00000','H00001','H00002')
      group by a.COMPANY_CODE, a.VENDOR_ID, d.GLOBAL_VENDOR_CODE;
  commit;

  iTracePoint := '220';  --GV_VENDOR
  for REC1 in (
     select distinct GV_VENDOR from VRTN_SUM02_AMT_VM_M
      where YYYY = vYYYY and MM = vMM
  ) loop
     BEGIN
       select * into vIR_AMT_TWD from (
         select round(sum(AMOUNT),5) from VRTN_SUM02_AMT_VM_M
          where YYYY = vYYYY
            and MM = vMM
            and GV_VENDOR = REC1.GV_VENDOR
       );
     EXCEPTION
       When OTHERS Then
         vIR_AMT_TWD := 0;
     END;
     Update VRTN_SUM02_AMT_VM_M
        set GV_PER = round(AMOUNT / vIR_AMT_TWD, 5)
      where YYYY = vYYYY
        and MM = vMM
        and GV_VENDOR = REC1.GV_VENDOR;
     commit;
  end loop;

  iTracePoint := '230';  --SITE
  for REC1 in (
     select distinct SITE from VRTN_SUM02_AMT_VM_M
      where YYYY = vYYYY and MM = vMM
  ) loop
     BEGIN
       select * into vIR_AMT_TWD from (
         select round(sum(AMOUNT),5) from VRTN_SUM02_AMT_VM_M
          where YYYY = vYYYY
            and MM = vMM
            and SITE = REC1.SITE
       );
     EXCEPTION
       When OTHERS Then
         vIR_AMT_TWD := 0;
     END;
     Update VRTN_SUM02_AMT_VM_M
        set SITE_PER = round(AMOUNT / vIR_AMT_TWD, 5)
      where YYYY = vYYYY
        and MM = vMM
        and SITE = REC1.SITE;
     commit;
  end loop;


  --刪除 VRTN_SUM03_AMT_SITE_M
  iTracePoint := '300';
  delete from VRTN_SUM03_AMT_SITE_M
   where YYYY = vYYYY
     and MM = vMM;
  commit;

  iTracePoint := '310';
  insert into VRTN_SUM03_AMT_SITE_M ( SITE, YYYY, MM, QUARTER, BUKRS, AMOUNT, GV_PER, DATE_TIME )
  select SITE, YYYY, MM, QUARTER, BUKRS, AMOUNT, round(AMOUNT / G_AMT,5), to_char(SYSDATE, 'yyyymmddhh24miss') from (
    select a.COMPANY_CODE as SITE, vYYYY as YYYY, vMM as MM, vYYYYQQ as QUARTER, a.COMPANY_CODE as BUKRS, round(sum(a.IR_AMT_TWD),5) as AMOUNT,
           ( select round(sum(a1.IR_AMT_TWD),5) from PLD_KPI_IR_DETAIL a1, PLD_KPI_VENDOR_MASTER b1, VRTN_COMPANY_SITE c1, GVM032_GLOBAL_VENDOR_ITEM d1
             where SUBSTRB(a1.IR_DATE,1,4) = SUBSTRB(vPROCEE_YYYYMM,1,4)
               and SUBSTRB(a1.IR_DATE,5,2) = SUBSTRB(vPROCEE_YYYYMM,5,2)
          --  where substr(a1.IR_DATE,1,4) = vYYYY
          --    and substr(a1.IR_DATE,5,2) = vMM
                and a1.GLOBAL_VENDOR_CODE not in ('H00000','H00001','H00002')
                and c1.MFG_SITE = a1.COMPANY_CODE
                and a1.MTL_GROUP >= '001'
                and a1.MTL_GROUP <= '059'
                and b1.COMPANY_CODE = a1.COMPANY_CODE
                and b1.VENDOR_ID = a1.VENDOR_ID
  --            and b1.REC_ACCOUNT <> '0000214202'
                and d1.COMPANY_CODE = a1.COMPANY_CODE
                and d1.SAP_VENDOR_CODE = a1.VENDOR_ID
                and d1.GLOBAL_VENDOR_CODE not in ('H00000','H00001','H00002') ) as G_AMT
      from PLD_KPI_IR_DETAIL a, PLD_KPI_VENDOR_MASTER b, VRTN_COMPANY_SITE c, GVM032_GLOBAL_VENDOR_ITEM d
       where SUBSTRB(a.IR_DATE,1,4) = SUBSTRB(vPROCEE_YYYYMM,1,4)
         and SUBSTRB(a.IR_DATE,5,2) = SUBSTRB(vPROCEE_YYYYMM,5,2)
    -- where substr(a.IR_DATE,1,4) = vYYYY
    --   and substr(a.IR_DATE,5,2) = vMM
       and c.MFG_SITE = a.COMPANY_CODE
       and a.MTL_GROUP >= '001'
       and a.MTL_GROUP <= '059'
       and b.COMPANY_CODE = a.COMPANY_CODE
       and b.VENDOR_ID = a.VENDOR_ID
  --   and b.REC_ACCOUNT <> '0000214202'
       and d.COMPANY_CODE = a.COMPANY_CODE
       and d.SAP_VENDOR_CODE = a.VENDOR_ID
       and d.GLOBAL_VENDOR_CODE not in ('H00000','H00001','H00002')
     group by a.COMPANY_CODE );
  commit;

EXCEPTION
  When OTHERS Then
    --有錯誤產生則寄mail
    cErrorText := SQLERRM();
    MAIL_FILE_BIDBDBADMIN(in_to_name => 'shuchin_lin@usiglobal.com', subject => '[VRTN] PL/SQL VRTN_PLSQL_SUM_AMT_MM ERROR', message => '[VRTN_PLSQL_SUM_AMT_MM], The tracepoint is  ' || iTracePoint || ' and ErrorText= ' || cErrorText) ;
END;
/

