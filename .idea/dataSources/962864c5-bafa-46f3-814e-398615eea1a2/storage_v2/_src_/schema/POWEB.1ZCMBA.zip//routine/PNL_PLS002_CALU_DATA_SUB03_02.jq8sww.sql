create PROCEDURE PNL_PLS002_CALU_DATA_SUB03_02 (
  inCompany  in VARCHAR2,
  f_YYYYMMDD in VARCHAR2,
  t_YYYYMMDD in VARCHAR2
)
AUTHID DEFINER
/*********************************************************************
  PROG-ID      : PNL_PLS002_CALU_DATA_SUB03_02
  PROG-ACTION  : PROCESS RWF_SAP001_REVENUE_FORECAST  TO PNL_TRX001_DATA(03-03M,04-06M,05-09M,06-12M)(ROLLING FROM PNL_VIEW001_ALL_EM_DATA)
               : AMOUNT
  Author       : KANGI
  Date         : 2007/03/27
**********************************************************************/
is
   --處理 Revenue Forecast RWF_SAP001_REVENUE_FORECAST
   CURSOR PNL_TRX001_DATA_CUR is
	 SELECT TOP_KIND,PERIOD,TOP_PERIOD,PROFIT_CENTER FROM PNL_TRX001_DATA
       WHERE TOP_PERIOD NOT IN ('Budget','Actual')
	     AND YEAR = '2007'
		   --AND PERIOD < '200704'
       GROUP BY  TOP_KIND,PERIOD,TOP_PERIOD,PROFIT_CENTER
	   ORDER BY PERIOD,TOP_KIND ;
   iTracePoint  integer ;
   cErrorText varchar2(500) ;
   cPNL_YYYY PNL_TRX001_DATA.YEAR%TYPE;
   cRWF_YW  PNL_TRX001_DATA.RWF_YW%TYPE;
   cTOP_KIND PNL_TRX001_DATA.TOP_KIND%TYPE;
   cSIDE_KIND  PNL_TRX001_DATA.SIDE_KIND %TYPE;
   cTOP_PERIOD PNL_TRX001_DATA.TOP_PERIOD%TYPE;
   cFROM_PERIOD varchar2(6) ;
   cTO_PERIOD varchar2(6) ;
   nROLLING_AMT float;
   nROLLING_REV_AMT float;
   iROLLING_NUMBER integer ;
   iReduceMonth integer ;
   fUSD_TO_TWD_RATE float ;
   fRatio float ;
   dRUNDATE DATE ;

 BEGIN
   iTracePoint := 100 ;
   cPNL_YYYY := TO_CHAR(SYSDATE,'YYYY');
   dRUNDATE := SYSDATE ;
   iTracePoint := 200 ;
   ---FORECAST REVENUE('DM','DL','OH','AD','RD')
   ----INSERT PNL_TRX001_DATA FROM RWF_SAP001_REVENUE_FORECAST,
   ---ROLLING P/L('DM')
   ---DM ('02.1')
   cSIDE_KIND := '02.1' ;
   iROLLING_NUMBER := 6 ;
   iReduceMonth := -1*iROLLING_NUMBER ;
   iTracePoint := 300 ;
   MAIL_FILE_BIDBDBADMIN(in_to_name=>'kangi@ms.usi.com.tw',subject   => 'PL/SQL PNL_PLS002_CALU_DATA_SUB03_02 ERROR', message => '[PNL_PLS002_CALU_DATA_SUB03_02], The tracepoint is  ' || to_char(iTracePoint) || 'and ErrorText=' || cErrorText) ;
   iTracePoint := 400 ;
   --*****************************************************************************
   -- Formula
   --1.)  A% = SUM (Rolling前6個月M'tl ) /  SUM (Rolling前6個月 Actual Revenue )
   --2.)  M'tl =  Forecast Revenue * A %
   --*****************************************************************************
   FOR PNL_TRX001_DATA_REC in PNL_TRX001_DATA_CUR  LOOP
       iTracePoint := 500 ;
       IF TO_NUMBER(PNL_TRX001_DATA_REC.PERIOD) <= TO_NUMBER(TO_CHAR(SYSDATE,'YYYYMM')) THEN
          iTracePoint := 600 ;
          cFROM_PERIOD := TO_CHAR(ADD_MONTHS(TO_DATE(PNL_TRX001_DATA_REC.PERIOD||'01','YYYYMMDD'),iReduceMonth),'YYYYMM') ;
          cTO_PERIOD := TO_CHAR(ADD_MONTHS(TO_DATE(PNL_TRX001_DATA_REC.PERIOD||'01','YYYYMMDD'),-1),'YYYYMM');
          iTracePoint := 700 ;
       ELSE
          iTracePoint := 800 ;
          cFROM_PERIOD := TO_CHAR(ADD_MONTHS(SYSDATE,iReduceMonth),'YYYYMM') ;
          cTO_PERIOD := TO_CHAR(ADD_MONTHS(SYSDATE,-1),'YYYYMM');
          iTracePoint := 900 ;
       END IF ;

       iTracePoint := 1000 ;
       SELECT SUM(AMOUNT)*1000 INTO nROLLING_AMT
	        FROM PNL_VIEW001_ALL_EM_DATA
          WHERE YYYY||MONTH BETWEEN cFROM_PERIOD AND cTO_PERIOD
            AND TYPE_2 = 'Actual'
            AND SUBSTR(ACCOUNT2,1,4) = cSIDE_KIND
            AND AMOUNT <> 0
            AND PROFIT_CENTER = PNL_TRX001_DATA_REC.PROFIT_CENTER;
       iTracePoint := 1100 ;
       SELECT SUM(AMOUNT)*1000 INTO nROLLING_REV_AMT
	        FROM PNL_VIEW001_ALL_EM_DATA
          WHERE YYYY||MONTH BETWEEN cFROM_PERIOD AND cTO_PERIOD
            AND TYPE_2 = 'Actual'
            AND SUBSTR(ACCOUNT2,1,4) IN ('01.1')
            AND AMOUNT <> 0
            AND PROFIT_CENTER = PNL_TRX001_DATA_REC.PROFIT_CENTER;

       /*
       DBMS_OUTPUT.PUT_LINE(SUBSTR(TO_CHAR(SUBSTR(PNL_TRX001_DATA_REC.TOP_PERIOD,1,4)),1,255));
       DBMS_OUTPUT.PUT_LINE(SUBSTR(TO_CHAR(SUBSTR(PNL_TRX001_DATA_REC.TOP_PERIOD,6,4)),1,255));
       DBMS_OUTPUT.PUT_LINE(SUBSTR(TO_CHAR(nROLLING_AMT),1,255));
       DBMS_OUTPUT.PUT_LINE(SUBSTR(TO_CHAR(nROLLING_REV_AMT),1,255));
       */
       iTracePoint := 1200 ;
       IF nROLLING_REV_AMT = 0 THEN
          fRatio := 0 ;
       ELSE
          fRatio := nROLLING_AMT/nROLLING_REV_AMT ;
       END IF ;
       iTracePoint := 1300 ;

       iTracePoint := 1400 ;
       INSERT INTO PNL_TRX001_DATA
       SELECT COMPANY_CODE,YEAR,PERIOD,PROFIT_CENTER,TOP_KIND,
       cSIDE_KIND,TOP_PERIOD,AMT_LOCAL*fRatio,AMT_USD*fRatio,AMT_TWD*fRatio,
	     null RWF_YW,dRUNDATE
       FROM PNL_TRX001_DATA
        WHERE SIDE_KIND = '01.1'
          AND TOP_KIND = PNL_TRX001_DATA_REC.TOP_KIND
          AND PERIOD = PNL_TRX001_DATA_REC.PERIOD
          AND PROFIT_CENTER = PNL_TRX001_DATA_REC.PROFIT_CENTER;

       iTracePoint := 1500 ;
   END LOOP ;
   COMMIT ;


   ----INSERT PNL_TRX001_DATA FROM PNL_VIEW001_ALL_EM_DATA,
   ---ROLLING P/L('DL')
   ---DL ('02.2')
   iTracePoint := 1600 ;
   MAIL_FILE_BIDBDBADMIN(in_to_name=>'kangi@ms.usi.com.tw',subject   => 'PL/SQL PNL_PLS002_CALU_DATA_SUB03_02 ERROR', message => '[PNL_PLS002_CALU_DATA_SUB03_02], The tracepoint is  ' || to_char(iTracePoint) || 'and ErrorText=' || cErrorText) ;
   iTracePoint := 1700 ;
   --*****************************************************************************
   -- Formula
   --DL = SUM (Rolling前 6個月DL ) /  6
   --*****************************************************************************
   cSIDE_KIND := '02.2';
   iROLLING_NUMBER := 6 ;
   iReduceMonth := -1*iROLLING_NUMBER ;
   iTracePoint := 1800 ;
   FOR PNL_TRX001_DATA_REC in PNL_TRX001_DATA_CUR  LOOP
       iTracePoint := 1900 ;
       IF TO_NUMBER(PNL_TRX001_DATA_REC.PERIOD) <= TO_NUMBER(TO_CHAR(SYSDATE,'YYYYMM')) THEN
          iTracePoint := 2000 ;
          cFROM_PERIOD := TO_CHAR(ADD_MONTHS(TO_DATE(PNL_TRX001_DATA_REC.PERIOD||'01','YYYYMMDD'),iReduceMonth),'YYYYMM') ;
          cTO_PERIOD := TO_CHAR(ADD_MONTHS(TO_DATE(PNL_TRX001_DATA_REC.PERIOD||'01','YYYYMMDD'),-1),'YYYYMM');
          iTracePoint := 2100 ;
       ELSE
          iTracePoint := 2200 ;
          cFROM_PERIOD := TO_CHAR(ADD_MONTHS(SYSDATE,iReduceMonth),'YYYYMM') ;
          cTO_PERIOD := TO_CHAR(ADD_MONTHS(SYSDATE,-1),'YYYYMM');
          iTracePoint := 2300 ;
       END IF ;

       iTracePoint := 2400 ;
       INSERT INTO PNL_TRX001_DATA
       SELECT COMPANY_CODE,SUBSTR(PNL_TRX001_DATA_REC.PERIOD,1,4),PNL_TRX001_DATA_REC.PERIOD,
              PROFIT_CENTER,PNL_TRX001_DATA_REC.TOP_KIND,
	            cSIDE_KIND,
	            PNL_TRX001_DATA_REC.TOP_PERIOD,
	            SUM(AMOUNT)*1000/iROLLING_NUMBER AMT_LOCAL,SUM(AMOUNT)*1000*GET_EXCHANGE_RATE(YYYY,MONTH,'TWD','USD','T')/iROLLING_NUMBER AMT_USD,
	            SUM(AMOUNT)*1000/iROLLING_NUMBER AMT_TWD,NULL RWF_YW,
              dRUNDATE
	            FROM PNL_VIEW001_ALL_EM_DATA
              WHERE YYYY||MONTH BETWEEN cFROM_PERIOD AND cTO_PERIOD
                AND TYPE_2 = 'Actual'
                AND SUBSTR(ACCOUNT2,1,4) = cSIDE_KIND
                AND AMOUNT <> 0
                AND PROFIT_CENTER = PNL_TRX001_DATA_REC.PROFIT_CENTER
                GROUP BY COMPANY_CODE,YYYY,MONTH,PROFIT_CENTER,ACCOUNT2 ;
       iTracePoint := 2500 ;
   END LOOP ;
   COMMIT ;
   iTracePoint := 2600 ;
   ----INSERT PNL_TRX001_DATA FROM PNL_VIEW001_ALL_EM_DATA,
   ---ROLLING P/L('OH')
   ---OH ('02.3')
   cSIDE_KIND := '02.3';
   iROLLING_NUMBER := 6 ;
   iReduceMonth := -1*iROLLING_NUMBER ;
   iTracePoint := 2700 ;
   MAIL_FILE_BIDBDBADMIN(in_to_name=>'kangi@ms.usi.com.tw',subject   => 'PL/SQL PNL_PLS002_CALU_DATA_SUB03_02 ERROR', message => '[PNL_PLS002_CALU_DATA_SUB03_02], The tracepoint is  ' || to_char(iTracePoint) || 'and ErrorText=' || cErrorText) ;
   iTracePoint := 2800 ;
   --*****************************************************************************
   -- Formula
   --OH = SUM (Rolling前6個月OH ) / 6
   --*****************************************************************************
   FOR PNL_TRX001_DATA_REC in PNL_TRX001_DATA_CUR  LOOP
       iTracePoint := 2900 ;
       IF TO_NUMBER(PNL_TRX001_DATA_REC.PERIOD) <= TO_NUMBER(TO_CHAR(SYSDATE,'YYYYMM')) THEN
          iTracePoint := 3000 ;
          cFROM_PERIOD := TO_CHAR(ADD_MONTHS(TO_DATE(PNL_TRX001_DATA_REC.PERIOD||'01','YYYYMMDD'),iReduceMonth),'YYYYMM') ;
          cTO_PERIOD := TO_CHAR(ADD_MONTHS(TO_DATE(PNL_TRX001_DATA_REC.PERIOD||'01','YYYYMMDD'),-1),'YYYYMM');
          iTracePoint := 3100 ;
       ELSE
          iTracePoint := 3200 ;
          cFROM_PERIOD := TO_CHAR(ADD_MONTHS(SYSDATE,iReduceMonth),'YYYYMM') ;
          cTO_PERIOD := TO_CHAR(ADD_MONTHS(SYSDATE,-1),'YYYYMM');
          iTracePoint := 3300 ;
       END IF ;
       iTracePoint := 3400 ;
       INSERT INTO PNL_TRX001_DATA
       SELECT COMPANY_CODE,SUBSTR(PNL_TRX001_DATA_REC.PERIOD,1,4),PNL_TRX001_DATA_REC.PERIOD,
              PROFIT_CENTER,PNL_TRX001_DATA_REC.TOP_KIND,
	            cSIDE_KIND,
	            PNL_TRX001_DATA_REC.TOP_PERIOD,
	            SUM(AMOUNT)*1000/iROLLING_NUMBER AMT_LOCAL,SUM(AMOUNT)*1000*GET_EXCHANGE_RATE(YYYY,MONTH,'TWD','USD','T')/iROLLING_NUMBER AMT_USD,
	            SUM(AMOUNT)*1000/iROLLING_NUMBER AMT_TWD,NULL RWF_YW,
              dRUNDATE
	            FROM PNL_VIEW001_ALL_EM_DATA
              WHERE YYYY||MONTH BETWEEN cFROM_PERIOD AND cTO_PERIOD
                AND TYPE_2 = 'Actual'
                AND SUBSTR(ACCOUNT2,1,4) = cSIDE_KIND
                AND AMOUNT <> 0
                AND PROFIT_CENTER = PNL_TRX001_DATA_REC.PROFIT_CENTER
                GROUP BY COMPANY_CODE,YYYY,MONTH,PROFIT_CENTER,ACCOUNT2 ;
       iTracePoint := 3500 ;
   END LOOP ;
   COMMIT ;

   iTracePoint := 3600 ;
   MAIL_FILE_BIDBDBADMIN(in_to_name=>'kangi@ms.usi.com.tw',subject   => 'PL/SQL PNL_PLS002_CALU_DATA_SUB03_02 ERROR', message => '[PNL_PLS002_CALU_DATA_SUB03_02], The tracepoint is  ' || to_char(iTracePoint) || 'and ErrorText=' || cErrorText) ;
   iTracePoint := 3700 ;
   --*****************************************************************************
   -- Formula
   --1.)  B% =   SUM ( MOB Rolling 3個月 Export & Freght ) /  SUM (MOB Rolling 3個月 Actual Revenue )
   --2.)  C%= SUM( 非MOB Rolling前12個月export & Freght ) /  SUM (非MOB Rolling前12個月 Actual Revenue )
   --3.)  Export & Freght  = (MOB Forecast Revenue * B%)  +  (非MOB Forecast Revenue * C%)
   --  排除 0000000027 不列運費
   --*****************************************************************************
   ----INSERT PNL_TRX001_DATA FROM RWF_SAP001_REVENUE_FORECAST,
   ---ROLLING P/L('SALE')
   ---SALE ('03.1.1')
   cSIDE_KIND := '03.1.1' ;
   iTracePoint := 3800 ;
   FOR PNL_TRX001_DATA_REC in PNL_TRX001_DATA_CUR  LOOP
       iTracePoint := 3900 ;
       IF NOT PNL_TRX001_DATA_REC.PROFIT_CENTER = '0000000027' THEN
           iTracePoint := 4000 ;
           IF PNL_TRX001_DATA_REC.PROFIT_CENTER = '0000000021' THEN
              iTracePoint := 4100 ;
              iROLLING_NUMBER := 3 ;
              iReduceMonth := -1*iROLLING_NUMBER ;
              iTracePoint := 4200 ;
           ELSE
              iTracePoint := 4300 ;
              iROLLING_NUMBER := 12 ;
              iReduceMonth := -1*iROLLING_NUMBER ;
              iTracePoint := 4400 ;
           END IF ;
           iTracePoint := 4500 ;
           IF TO_NUMBER(PNL_TRX001_DATA_REC.PERIOD) <= TO_NUMBER(TO_CHAR(SYSDATE,'YYYYMM')) THEN
              iTracePoint := 4600 ;
              cFROM_PERIOD := TO_CHAR(ADD_MONTHS(TO_DATE(PNL_TRX001_DATA_REC.PERIOD||'01','YYYYMMDD'),iReduceMonth),'YYYYMM') ;
              cTO_PERIOD := TO_CHAR(ADD_MONTHS(TO_DATE(PNL_TRX001_DATA_REC.PERIOD||'01','YYYYMMDD'),-1),'YYYYMM');
              iTracePoint := 4700 ;
           ELSE
              iTracePoint := 4800 ;
              cFROM_PERIOD := TO_CHAR(ADD_MONTHS(SYSDATE,iReduceMonth),'YYYYMM') ;
              cTO_PERIOD := TO_CHAR(ADD_MONTHS(SYSDATE,-1),'YYYYMM');
              iTracePoint := 4900 ;
           END IF ;

            /*
           DBMS_OUTPUT.PUT_LINE(SUBSTR(TO_CHAR(SUBSTR(cTOP_PERIOD,1,4)),1,255));
           DBMS_OUTPUT.PUT_LINE(SUBSTR(TO_CHAR(SUBSTR(cTOP_PERIOD,6,4)),1,255));
           DBMS_OUTPUT.PUT_LINE(SUBSTR(TO_CHAR(nROLLING_AMT),1,255));
           DBMS_OUTPUT.PUT_LINE(SUBSTR(TO_CHAR(nROLLING_REV_AMT),1,255));
            */
           iTracePoint := 5000 ;
           SELECT SUM(AMOUNT)*1000 INTO nROLLING_AMT
	            FROM PNL_VIEW001_ALL_EM_DATA
             WHERE YYYY||MONTH BETWEEN cFROM_PERIOD AND cTO_PERIOD
               AND TYPE_2 = 'Actual'
               AND SUBSTR(ACCOUNT3,1,6) IN cSIDE_KIND
               AND SUBSTR(ACCOUNT2,1,4) IN SUBSTR(cSIDE_KIND,1,4)
               AND AMOUNT <> 0
               AND PROFIT_CENTER = PNL_TRX001_DATA_REC.PROFIT_CENTER;

           iTracePoint := 5100 ;
           SELECT SUM(AMOUNT)*1000 INTO nROLLING_REV_AMT
	            FROM PNL_VIEW001_ALL_EM_DATA
             WHERE YYYY||MONTH BETWEEN cFROM_PERIOD AND cTO_PERIOD
               AND TYPE_2 = 'Actual'
               AND SUBSTR(ACCOUNT2,1,4) IN ('01.1')
               AND AMOUNT <> 0
               AND PROFIT_CENTER = PNL_TRX001_DATA_REC.PROFIT_CENTER;

           iTracePoint := 5200 ;
           IF nROLLING_REV_AMT = 0 THEN
              fRatio := 0 ;
           ELSE
              fRatio := nROLLING_AMT/nROLLING_REV_AMT ;
           END IF ;

           iTracePoint := 5300 ;
           INSERT INTO PNL_TRX001_DATA
           SELECT COMPANY_CODE,YEAR,PERIOD,PROFIT_CENTER,TOP_KIND,
                  cSIDE_KIND,TOP_PERIOD,AMT_LOCAL*fRatio,AMT_USD*fRatio,AMT_TWD*fRatio,
	                null RWF_YW,dRUNDATE
                  FROM PNL_TRX001_DATA
            WHERE SIDE_KIND = '01.1'
              AND TOP_KIND = PNL_TRX001_DATA_REC.TOP_KIND
              AND PERIOD = PNL_TRX001_DATA_REC.PERIOD
              AND PROFIT_CENTER = PNL_TRX001_DATA_REC.PROFIT_CENTER ;
            iTracePoint := 5400 ;
       END IF;
            iTracePoint := 5500 ;
   END LOOP ;
   COMMIT ;

   iTracePoint := 5600 ;
   MAIL_FILE_BIDBDBADMIN(in_to_name=>'kangi@ms.usi.com.tw',subject   => 'PL/SQL PNL_PLS002_CALU_DATA_SUB03_02 ERROR', message => '[PNL_PLS002_CALU_DATA_SUB03_02], The tracepoint is  ' || to_char(iTracePoint) || 'and ErrorText=' || cErrorText) ;
   iTracePoint := 5700 ;
   --*****************************************************************************
   -- Formula
   --After service =  SUM (Rolling前12個月After service) / 12
   --*****************************************************************************
   ----INSERT PNL_TRX001_DATA FROM RWF_SAP001_REVENUE_FORECAST,
   ---ROLLING P/L('SALE')
   ---SALE ('03.1.2')
   cSIDE_KIND := '03.1.2' ;
   iROLLING_NUMBER := 12 ;
   iReduceMonth := -1*iROLLING_NUMBER ;
   iTracePoint := 5800 ;
   FOR PNL_TRX001_DATA_REC in PNL_TRX001_DATA_CUR  LOOP
       iTracePoint := 5900 ;
       IF TO_NUMBER(PNL_TRX001_DATA_REC.PERIOD) <= TO_NUMBER(TO_CHAR(SYSDATE,'YYYYMM')) THEN
          iTracePoint := 6000 ;
          cFROM_PERIOD := TO_CHAR(ADD_MONTHS(TO_DATE(PNL_TRX001_DATA_REC.PERIOD||'01','YYYYMMDD'),iReduceMonth),'YYYYMM') ;
          cTO_PERIOD := TO_CHAR(ADD_MONTHS(TO_DATE(PNL_TRX001_DATA_REC.PERIOD||'01','YYYYMMDD'),-1),'YYYYMM');
          iTracePoint := 6100 ;
       ELSE
          iTracePoint := 6200 ;
          cFROM_PERIOD := TO_CHAR(ADD_MONTHS(SYSDATE,iReduceMonth),'YYYYMM') ;
          cTO_PERIOD := TO_CHAR(ADD_MONTHS(SYSDATE,-1),'YYYYMM');
          iTracePoint := 6300 ;
       END IF ;
       iTracePoint := 6400 ;
       INSERT INTO PNL_TRX001_DATA
       SELECT COMPANY_CODE,SUBSTR(PNL_TRX001_DATA_REC.PERIOD,1,4),PNL_TRX001_DATA_REC.PERIOD,
              PROFIT_CENTER,PNL_TRX001_DATA_REC.TOP_KIND,
	            cSIDE_KIND,
	            PNL_TRX001_DATA_REC.TOP_PERIOD,
	            SUM(AMOUNT)*1000/iROLLING_NUMBER AMT_LOCAL,SUM(AMOUNT)*1000*GET_EXCHANGE_RATE(YYYY,MONTH,'TWD','USD','T')/iROLLING_NUMBER AMT_USD,
	            SUM(AMOUNT)*1000/iROLLING_NUMBER AMT_TWD,NULL RWF_YW,
              dRUNDATE
	            FROM PNL_VIEW001_ALL_EM_DATA
              WHERE YYYY||MONTH BETWEEN cFROM_PERIOD AND cTO_PERIOD
                AND TYPE_2 = 'Actual'
                AND SUBSTR(ACCOUNT2,1,4) = cSIDE_KIND
                AND AMOUNT <> 0
                AND PROFIT_CENTER = PNL_TRX001_DATA_REC.PROFIT_CENTER
                GROUP BY COMPANY_CODE,YYYY,MONTH,PROFIT_CENTER,ACCOUNT2 ;
       iTracePoint := 6500 ;
   END LOOP ;
   COMMIT ;

   iTracePoint := 6600 ;
   MAIL_FILE_BIDBDBADMIN(in_to_name=>'kangi@ms.usi.com.tw',subject   => 'PL/SQL PNL_PLS002_CALU_DATA_SUB03_02 ERROR', message => '[PNL_PLS002_CALU_DATA_SUB03_02], The tracepoint is  ' || to_char(iTracePoint) || 'and ErrorText=' || cErrorText) ;
   iTracePoint := 6700 ;
   --*****************************************************************************
   -- Formula
   --1.)   D%= SUM (Rolling前6個月 Bad debt)  /  SUM(Rolling前6個月 Actual Revenue)
   --2.)   Bad debt = Forecst Revenue * D %
   --*****************************************************************************
   ----INSERT PNL_TRX001_DATA FROM PNL_VIEW001_ALL_EM_DATA,
   ---ROLLING P/L('SALE')
   ---SALE ('03.1.3')
   cSIDE_KIND := '03.1.3' ;
   iROLLING_NUMBER := 6 ;
   iReduceMonth := -1*iROLLING_NUMBER ;
   iTracePoint := 6800 ;
   FOR PNL_TRX001_DATA_REC in PNL_TRX001_DATA_CUR  LOOP
       iTracePoint := 6900 ;
       IF TO_NUMBER(PNL_TRX001_DATA_REC.PERIOD) <= TO_NUMBER(TO_CHAR(SYSDATE,'YYYYMM')) THEN
          iTracePoint := 7000 ;
          cFROM_PERIOD := TO_CHAR(ADD_MONTHS(TO_DATE(PNL_TRX001_DATA_REC.PERIOD||'01','YYYYMMDD'),iReduceMonth),'YYYYMM') ;
          cTO_PERIOD := TO_CHAR(ADD_MONTHS(TO_DATE(PNL_TRX001_DATA_REC.PERIOD||'01','YYYYMMDD'),-1),'YYYYMM');
          iTracePoint := 7100 ;
       ELSE
          iTracePoint := 7200 ;
          cFROM_PERIOD := TO_CHAR(ADD_MONTHS(SYSDATE,iReduceMonth),'YYYYMM') ;
          cTO_PERIOD := TO_CHAR(ADD_MONTHS(SYSDATE,-1),'YYYYMM');
          iTracePoint := 7300 ;
       END IF ;
       iTracePoint := 7400 ;
       SELECT SUM(AMOUNT)*1000*-1 INTO nROLLING_AMT
	        FROM PNL_VIEW001_ALL_EM_DATA
          WHERE YYYY||MONTH BETWEEN cFROM_PERIOD AND cTO_PERIOD
            AND TYPE_2 = 'Actual'
            AND SUBSTR(ACCOUNT3,1,6) IN cSIDE_KIND
            AND SUBSTR(ACCOUNT2,1,4) IN SUBSTR(cSIDE_KIND,1,4)
            AND AMOUNT <> 0
            AND PROFIT_CENTER = PNL_TRX001_DATA_REC.PROFIT_CENTER;
       iTracePoint := 7500 ;
       SELECT SUM(AMOUNT)*1000 INTO nROLLING_REV_AMT
	        FROM PNL_VIEW001_ALL_EM_DATA
          WHERE YYYY||MONTH BETWEEN cFROM_PERIOD AND cTO_PERIOD
            AND TYPE_2 = 'Actual'
            AND SUBSTR(ACCOUNT2,1,4) IN ('01.1')
            AND AMOUNT <> 0
            AND PROFIT_CENTER = PNL_TRX001_DATA_REC.PROFIT_CENTER;

       /*
       DBMS_OUTPUT.PUT_LINE(SUBSTR(TO_CHAR(SUBSTR(PNL_TRX001_DATA_REC.TOP_PERIOD,1,4)),1,255));
       DBMS_OUTPUT.PUT_LINE(SUBSTR(TO_CHAR(SUBSTR(PNL_TRX001_DATA_REC.TOP_PERIOD,6,4)),1,255));
       DBMS_OUTPUT.PUT_LINE(SUBSTR(TO_CHAR(nROLLING_AMT),1,255));
       DBMS_OUTPUT.PUT_LINE(SUBSTR(TO_CHAR(nROLLING_REV_AMT),1,255));
       */
       iTracePoint := 7600 ;
       IF nROLLING_REV_AMT = 0 THEN
          fRatio := 0 ;
       ELSE
          fRatio := nROLLING_AMT/nROLLING_REV_AMT ;
       END IF ;


       iTracePoint := 7700 ;
       INSERT INTO PNL_TRX001_DATA
       SELECT COMPANY_CODE,YEAR,PERIOD,PROFIT_CENTER,TOP_KIND,
       cSIDE_KIND,TOP_PERIOD,AMT_LOCAL*fRatio,AMT_USD*fRatio,AMT_TWD*fRatio,
	     null RWF_YW,dRUNDATE
       FROM PNL_TRX001_DATA
        WHERE SIDE_KIND = '01.1'
          AND TOP_KIND = PNL_TRX001_DATA_REC.TOP_KIND
          AND PERIOD = PNL_TRX001_DATA_REC.PERIOD
          AND PROFIT_CENTER = PNL_TRX001_DATA_REC.PROFIT_CENTER ;

       iTracePoint := 7800 ;
   END LOOP ;
   COMMIT ;
   iTracePoint := 7900 ;
   MAIL_FILE_BIDBDBADMIN(in_to_name=>'kangi@ms.usi.com.tw',subject   => 'PL/SQL PNL_PLS002_CALU_DATA_SUB03_02 ERROR', message => '[PNL_PLS002_CALU_DATA_SUB03_02], The tracepoint is  ' || to_char(iTracePoint) || 'and ErrorText=' || cErrorText) ;
   iTracePoint := 8000 ;
   --*****************************************************************************
   -- Formula
   --Others = SUM(Rolling前6個月 others ) / 6
   --*****************************************************************************
    ---ROLLING P/L('SALE')
   ---SALE ('03.1.A')
   cSIDE_KIND := '03.1.A';
   iROLLING_NUMBER := 6 ;
   iReduceMonth := -1*iROLLING_NUMBER ;
   iTracePoint := 8100 ;
   FOR PNL_TRX001_DATA_REC in PNL_TRX001_DATA_CUR  LOOP
       iTracePoint := 8200 ;
       IF TO_NUMBER(PNL_TRX001_DATA_REC.PERIOD) <= TO_NUMBER(TO_CHAR(SYSDATE,'YYYYMM')) THEN
          iTracePoint := 8300 ;
          cFROM_PERIOD := TO_CHAR(ADD_MONTHS(TO_DATE(PNL_TRX001_DATA_REC.PERIOD||'01','YYYYMMDD'),iReduceMonth),'YYYYMM') ;
          cTO_PERIOD := TO_CHAR(ADD_MONTHS(TO_DATE(PNL_TRX001_DATA_REC.PERIOD||'01','YYYYMMDD'),-1),'YYYYMM');
          iTracePoint := 8400 ;
       ELSE
          iTracePoint := 8500 ;
          cFROM_PERIOD := TO_CHAR(ADD_MONTHS(SYSDATE,iReduceMonth),'YYYYMM') ;
          cTO_PERIOD := TO_CHAR(ADD_MONTHS(SYSDATE,-1),'YYYYMM');
          iTracePoint := 8600 ;
       END IF ;
       iTracePoint := 8700 ;
       INSERT INTO PNL_TRX001_DATA
       SELECT COMPANY_CODE,SUBSTR(PNL_TRX001_DATA_REC.PERIOD,1,4),PNL_TRX001_DATA_REC.PERIOD,
              PROFIT_CENTER,PNL_TRX001_DATA_REC.TOP_KIND,
	            cSIDE_KIND,
	            PNL_TRX001_DATA_REC.TOP_PERIOD,
	            SUM(AMOUNT)*1000/iROLLING_NUMBER AMT_LOCAL,SUM(AMOUNT)*1000*GET_EXCHANGE_RATE(YYYY,MONTH,'TWD','USD','T')/iROLLING_NUMBER AMT_USD,
	            SUM(AMOUNT)*1000/iROLLING_NUMBER AMT_TWD,NULL RWF_YW,
              dRUNDATE
	            FROM PNL_VIEW001_ALL_EM_DATA
              WHERE YYYY||MONTH BETWEEN cFROM_PERIOD AND cTO_PERIOD
                AND TYPE_2 = 'Actual'
                AND SUBSTR(ACCOUNT3,1,6) NOT IN ('03.1.1','03.1.2','03.1.3')
                AND SUBSTR(ACCOUNT2,1,4) IN SUBSTR(cSIDE_KIND,1,4)
                AND AMOUNT <> 0
                AND PROFIT_CENTER = PNL_TRX001_DATA_REC.PROFIT_CENTER
                GROUP BY COMPANY_CODE,YYYY,MONTH,PROFIT_CENTER,ACCOUNT2 ;
       iTracePoint := 8800 ;
   END LOOP ;
   iTracePoint := 8900 ;
   COMMIT ;

   MAIL_FILE_BIDBDBADMIN(in_to_name=>'kangi@ms.usi.com.tw',subject   => 'PL/SQL PNL_PLS002_CALU_DATA_SUB03_02 ERROR', message => '[PNL_PLS002_CALU_DATA_SUB03_02], The tracepoint is  ' || to_char(iTracePoint) || 'and ErrorText=' || cErrorText) ;
   iTracePoint := 9000 ;
   --*****************************************************************************
   -- Formula
   --Adm =  SUM(Rolling前6個月Adm) /  6
   --*****************************************************************************
   ----INSERT PNL_TRX001_DATA FROM PNL_VIEW001_ALL_EM_DATA,
   ---ROLLING P/L('AD')
   ---AD ('03.2')
   cSIDE_KIND := '03.2';
   iROLLING_NUMBER := 6 ;
   iReduceMonth := -1*iROLLING_NUMBER ;
   iTracePoint := 9100 ;
   FOR PNL_TRX001_DATA_REC in PNL_TRX001_DATA_CUR  LOOP
       iTracePoint := 9200 ;
       IF TO_NUMBER(PNL_TRX001_DATA_REC.PERIOD) <= TO_NUMBER(TO_CHAR(SYSDATE,'YYYYMM')) THEN
          iTracePoint := 9300 ;
          cFROM_PERIOD := TO_CHAR(ADD_MONTHS(TO_DATE(PNL_TRX001_DATA_REC.PERIOD||'01','YYYYMMDD'),iReduceMonth),'YYYYMM') ;
          cTO_PERIOD := TO_CHAR(ADD_MONTHS(TO_DATE(PNL_TRX001_DATA_REC.PERIOD||'01','YYYYMMDD'),-1),'YYYYMM');
          iTracePoint := 9400 ;
       ELSE
          iTracePoint := 9500 ;
          cFROM_PERIOD := TO_CHAR(ADD_MONTHS(SYSDATE,iReduceMonth),'YYYYMM') ;
          cTO_PERIOD := TO_CHAR(ADD_MONTHS(SYSDATE,-1),'YYYYMM');
          iTracePoint := 9600 ;
       END IF ;
       iTracePoint := 9700 ;
       INSERT INTO PNL_TRX001_DATA
       SELECT COMPANY_CODE,SUBSTR(PNL_TRX001_DATA_REC.PERIOD,1,4),PNL_TRX001_DATA_REC.PERIOD,
              PROFIT_CENTER,PNL_TRX001_DATA_REC.TOP_KIND,
	            cSIDE_KIND,
	            PNL_TRX001_DATA_REC.TOP_PERIOD,
	            SUM(AMOUNT)*1000/iROLLING_NUMBER AMT_LOCAL,SUM(AMOUNT)*1000*GET_EXCHANGE_RATE(YYYY,MONTH,'TWD','USD','T')/iROLLING_NUMBER AMT_USD,
	            SUM(AMOUNT)*1000/iROLLING_NUMBER AMT_TWD,NULL RWF_YW,
              dRUNDATE
	            FROM PNL_VIEW001_ALL_EM_DATA
              WHERE YYYY||MONTH BETWEEN cFROM_PERIOD AND cTO_PERIOD
                AND TYPE_2 = 'Actual'
                AND SUBSTR(ACCOUNT2,1,4) = cSIDE_KIND
                AND AMOUNT <> 0
                AND PROFIT_CENTER = PNL_TRX001_DATA_REC.PROFIT_CENTER
                GROUP BY COMPANY_CODE,YYYY,MONTH,PROFIT_CENTER,ACCOUNT2 ;
       iTracePoint := 9800 ;
   END LOOP ;
   iTracePoint := 9900 ;
   COMMIT ;
   MAIL_FILE_BIDBDBADMIN(in_to_name=>'kangi@ms.usi.com.tw',subject   => 'PL/SQL PNL_PLS002_CALU_DATA_SUB03_02 ERROR', message => '[PNL_PLS002_CALU_DATA_SUB03_02], The tracepoint is  ' || to_char(iTracePoint) || 'and ErrorText=' || cErrorText) ;
   iTracePoint := 10000 ;
   --*****************************************************************************
   -- Formula
   --RD =  Actual RD of Last Month
   --*****************************************************************************
   ---ROLLING P/L('RD')
   ---RD ('03.3')
   cSIDE_KIND := '03.3';
   iROLLING_NUMBER := 1 ;
   iReduceMonth := -1*iROLLING_NUMBER ;
   iTracePoint := 10100 ;
   FOR PNL_TRX001_DATA_REC in PNL_TRX001_DATA_CUR  LOOP
       iTracePoint := 10200 ;
       IF TO_NUMBER(PNL_TRX001_DATA_REC.PERIOD) <= TO_NUMBER(TO_CHAR(SYSDATE,'YYYYMM')) THEN
          iTracePoint := 10300 ;
          cFROM_PERIOD := TO_CHAR(ADD_MONTHS(TO_DATE(PNL_TRX001_DATA_REC.PERIOD||'01','YYYYMMDD'),iReduceMonth),'YYYYMM') ;
          cTO_PERIOD := TO_CHAR(ADD_MONTHS(TO_DATE(PNL_TRX001_DATA_REC.PERIOD||'01','YYYYMMDD'),-1),'YYYYMM');
          iTracePoint := 10400 ;
       ELSE
          iTracePoint := 10500 ;
          cFROM_PERIOD := TO_CHAR(ADD_MONTHS(SYSDATE,iReduceMonth),'YYYYMM') ;
          cTO_PERIOD := TO_CHAR(ADD_MONTHS(SYSDATE,-1),'YYYYMM');
          iTracePoint := 10600 ;
       END IF ;
       iTracePoint := 10700 ;
       INSERT INTO PNL_TRX001_DATA
       SELECT COMPANY_CODE,SUBSTR(PNL_TRX001_DATA_REC.PERIOD,1,4),PNL_TRX001_DATA_REC.PERIOD,
              PROFIT_CENTER,PNL_TRX001_DATA_REC.TOP_KIND,
	            cSIDE_KIND,
	            PNL_TRX001_DATA_REC.TOP_PERIOD,
	            SUM(AMOUNT)*1000/iROLLING_NUMBER AMT_LOCAL,SUM(AMOUNT)*1000*GET_EXCHANGE_RATE(YYYY,MONTH,'TWD','USD','T')/iROLLING_NUMBER AMT_USD,
	            SUM(AMOUNT)*1000/iROLLING_NUMBER AMT_TWD,NULL RWF_YW,
              dRUNDATE
	            FROM PNL_VIEW001_ALL_EM_DATA
              WHERE YYYY||MONTH BETWEEN cFROM_PERIOD AND cTO_PERIOD
                AND TYPE_2 = 'Actual'
                AND SUBSTR(ACCOUNT2,1,4) = cSIDE_KIND
                AND AMOUNT <> 0
                AND PROFIT_CENTER = PNL_TRX001_DATA_REC.PROFIT_CENTER
                GROUP BY COMPANY_CODE,YYYY,MONTH,PROFIT_CENTER,ACCOUNT2 ;
       iTracePoint := 10800 ;
   END LOOP ;
   iTracePoint := 10900 ;
   MAIL_FILE_BIDBDBADMIN(in_to_name=>'kangi@ms.usi.com.tw',subject   => 'PL/SQL PNL_PLS002_CALU_DATA_SUB03_02 ERROR', message => '[PNL_PLS002_CALU_DATA_SUB03_02], The tracepoint is  ' || to_char(iTracePoint) || 'and ErrorText=' || cErrorText) ;
   iTracePoint := 11000 ;

   COMMIT ;
 EXCEPTION
     WHEN OTHERS THEN
            --rollback ;
            cErrorText := SQLERRM() ;
            MAIL_FILE_BIDBDBADMIN(in_to_name=>'kangi@ms.usi.com.tw',subject   => 'PL/SQL PNL_PLS002_CALU_DATA_SUB03_02 ERROR', message => '[PNL_PLS002_CALU_DATA_SUB03_02], The tracepoint is  ' || to_char(iTracePoint) || 'and ErrorText=' || cErrorText) ;
            DBMS_OUTPUT.PUT_LINE(SUBSTR(cErrorText,1,255));
            DBMS_OUTPUT.PUT_LINE(TO_CHAR(iTracePoint));
END PNL_PLS002_CALU_DATA_SUB03_02;
/

