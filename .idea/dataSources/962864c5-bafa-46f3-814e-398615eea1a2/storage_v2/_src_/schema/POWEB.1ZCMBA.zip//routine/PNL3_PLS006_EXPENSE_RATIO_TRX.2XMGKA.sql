create PROCEDURE       pnl3_pls006_expense_ratio_trx (
   --inCompany  in VARCHAR2,
   inperiod   IN   VARCHAR2
--此程式在產生依SITE+PROFIT CENTER裡的END CUSTOMER REVENUE比率,原本在測試時期供費用比率計算
--現在供GM (也就是COGS)的使用,只有特定PROFIT CENTER才會參考此TABLE
--2009/2/9 比率由cost center的屬性區分成rd以及非rd,將來如果要分更細,則要用CATEGORY欄位來分
--因為rd的比率和非rd(sales/adm)不一樣,所以要這樣分
)
AUTHID DEFINER
IS
/*
   CURSOR c_pnl2
   IS
      SELECT   company_code, profit_center, SUM (headcount) AS headcount
          FROM pnl2_upl006_headcount
         WHERE period = inperiod
        HAVING SUM (headcount) <> 0
      GROUP BY company_code, profit_center;

   CURSOR c_pnl2_p
   IS
      SELECT   profit_center, SUM (headcount) AS headcount
          FROM pnl2_upl006_headcount
         WHERE period = inperiod
        HAVING SUM (headcount) <> 0
      GROUP BY profit_center;

   CURSOR c_pnl2_a
   IS
      SELECT   end_customer_id, SUM (headcount) AS headcount
          FROM pnl2_upl006_headcount
         WHERE period = inperiod
        HAVING SUM (headcount) <> 0
      GROUP BY end_customer_id;
*/
   a_rate   pnl3_map001_customer_rate.rate%TYPE;
   a_hc     pnl2_upl006_headcount.headcount%TYPE;
BEGIN
   DELETE FROM pnl3_map003_expense_ratio
         WHERE period = inperiod;

   COMMIT;

   --Clear field value
   UPDATE pnl2_upl006_headcount
      SET CATEGORY = NULL
    WHERE period = inperiod;

   COMMIT;

   --ReAssign Feild value
   UPDATE pnl2_upl006_headcount
      SET CATEGORY =
             (SELECT b.CATEGORY
                FROM kpi_map018_organization b
               WHERE b.period = pnl2_upl006_headcount.period
                 AND b.sap_cost_center = pnl2_upl006_headcount.cost_center
                 AND ROWNUM <= 1)
    WHERE period = inperiod;

   COMMIT;

   --Get Rate(Exclude RD)
   FOR rec1 IN (SELECT   company_code, profit_center,
                         SUM (headcount) AS headcount
                    FROM pnl2_upl006_headcount
                   WHERE period = inperiod AND CATEGORY <> 'RD'
                  HAVING SUM (headcount) <> 0
                GROUP BY company_code, profit_center)
   LOOP
      FOR rec2 IN (SELECT   company_code, profit_center, end_customer_id,
                            SUM (headcount) AS headcount
                       FROM pnl2_upl006_headcount
                      WHERE profit_center = rec1.profit_center
                        AND period = inperiod
                        AND company_code = rec1.company_code
                         AND CATEGORY <> 'RD'
                     --AND SOURCE <> 'UPL001'
                   HAVING   SUM (headcount) <> 0
                   GROUP BY company_code, profit_center, end_customer_id
                   ORDER BY headcount DESC)
      LOOP
         --2008/12/4 因UPLOAD的資料未上,所以只有COGS沒有Reverue,因此要加入判斷REC1.AMT_TWD <> 0,否則會有問題,待user 上傳後即無問題
         IF rec1.headcount = 0
         THEN
            a_rate := 0;
         ELSE
            a_rate := rec2.headcount / rec1.headcount;
         END IF;

         INSERT INTO pnl3_map003_expense_ratio
                     (period, profit_center, company_code,
                      end_customer_id, r_kind, area1, area2, area3, rate,
                      change_date
                     )
              VALUES (inperiod, rec1.profit_center, rec2.company_code,
                      rec2.end_customer_id, 'PL01', '4', '1', '1', a_rate,
                      SYSDATE
                     );

         COMMIT;

         INSERT INTO pnl3_map003_expense_ratio
                     (period, profit_center, company_code,
                      end_customer_id, r_kind, area1, area2, area3, rate,
                      change_date
                     )
              VALUES (inperiod, rec1.profit_center, rec2.company_code,
                      rec2.end_customer_id, 'PL01', '4', '1', '2', a_rate,
                      SYSDATE
                     );

         COMMIT;

         INSERT INTO pnl3_map003_expense_ratio
                     (period, profit_center, company_code,
                      end_customer_id, r_kind, area1, area2, area3, rate,
                      change_date
                     )
              VALUES (inperiod, rec1.profit_center, rec2.company_code,
                      rec2.end_customer_id, 'PL01', '4', '1', '3', a_rate,
                      SYSDATE
                     );

         COMMIT;

         INSERT INTO pnl3_map003_expense_ratio
                     (period, profit_center, company_code,
                      end_customer_id, r_kind, area1, area2, area3, rate,
                      change_date
                     )
              VALUES (inperiod, rec1.profit_center, rec2.company_code,
                      rec2.end_customer_id, 'PL01', '4', '1', '4', a_rate,
                      SYSDATE
                     );

         COMMIT;

         INSERT INTO pnl3_map003_expense_ratio
                     (period, profit_center, company_code,
                      end_customer_id, r_kind, area1, area2, area3, rate,
                      change_date
                     )
              VALUES (inperiod, rec1.profit_center, rec2.company_code,
                      rec2.end_customer_id, 'PL01', '4', '1', '5', a_rate,
                      SYSDATE
                     );

         COMMIT;

         INSERT INTO pnl3_map003_expense_ratio
                     (period, profit_center, company_code,
                      end_customer_id, r_kind, area1, area2, area3, rate,
                      change_date
                     )
              VALUES (inperiod, rec1.profit_center, rec2.company_code,
                      rec2.end_customer_id, 'PL01', '4', '1', '6', a_rate,
                      SYSDATE
                     );

         COMMIT;

         INSERT INTO pnl3_map003_expense_ratio
                     (period, profit_center, company_code,
                      end_customer_id, r_kind, area1, area2, area3, rate,
                      change_date
                     )
              VALUES (inperiod, rec1.profit_center, rec2.company_code,
                      rec2.end_customer_id, 'PL01', '4', '1', '7', a_rate,
                      SYSDATE
                     );

         COMMIT;

         INSERT INTO pnl3_map003_expense_ratio
                     (period, profit_center, company_code,
                      end_customer_id, r_kind, area1, area2, area3, rate,
                      change_date
                     )
              VALUES (inperiod, rec1.profit_center, rec2.company_code,
                      rec2.end_customer_id, 'PL01', '4', '2', '1', a_rate,
                      SYSDATE
                     );

         COMMIT;

         INSERT INTO pnl3_map003_expense_ratio
                     (period, profit_center, company_code,
                      end_customer_id, r_kind, area1, area2, area3, rate,
                      change_date
                     )
              VALUES (inperiod, rec1.profit_center, rec2.company_code,
                      rec2.end_customer_id, 'PL01', '4', '2', '2', a_rate,
                      SYSDATE
                     );

         COMMIT;

         INSERT INTO pnl3_map003_expense_ratio
                     (period, profit_center, company_code,
                      end_customer_id, r_kind, area1, area2, area3, rate,
                      change_date
                     )
              VALUES (inperiod, rec1.profit_center, rec2.company_code,
                      rec2.end_customer_id, 'PL01', '4', '2', '3', a_rate,
                      SYSDATE
                     );

         COMMIT;

         INSERT INTO pnl3_map003_expense_ratio
                     (period, profit_center, company_code,
                      end_customer_id, r_kind, area1, area2, area3, rate,
                      change_date
                     )
              VALUES (inperiod, rec1.profit_center, rec2.company_code,
                      rec2.end_customer_id, 'PL01', '4', '2', '4', a_rate,
                      SYSDATE
                     );

         COMMIT;
      END LOOP;
   END LOOP;

   FOR rec1 IN (SELECT   company_code, profit_center,
                         SUM (headcount) AS headcount
                    FROM pnl2_upl006_headcount
                   WHERE period = inperiod AND CATEGORY = 'RD'
                  HAVING SUM (headcount) <> 0
                GROUP BY company_code, profit_center)
   LOOP
      FOR rec2 IN (SELECT   company_code, profit_center, end_customer_id,
                            SUM (headcount) AS headcount
                       FROM pnl2_upl006_headcount
                      WHERE profit_center = rec1.profit_center
                        AND period = inperiod
                        AND company_code = rec1.company_code
                         AND CATEGORY = 'RD'
                     --AND SOURCE <> 'UPL001'
                   HAVING   SUM (headcount) <> 0
                   GROUP BY company_code, profit_center, end_customer_id
                   ORDER BY headcount DESC)
      LOOP
         --2008/12/4 因UPLOAD的資料未上,所以只有COGS沒有Reverue,因此要加入判斷REC1.AMT_TWD <> 0,否則會有問題,待user 上傳後即無問題
         IF rec1.headcount = 0
         THEN
            a_rate := 0;
         ELSE
            a_rate := rec2.headcount / rec1.headcount;
         END IF;

         INSERT INTO pnl3_map003_expense_ratio
                     (period, profit_center, company_code,
                      end_customer_id, r_kind, area1, area2, area3, rate,
                      change_date
                     )
              VALUES (inperiod, rec1.profit_center, rec2.company_code,
                      rec2.end_customer_id, 'PL01', '4', '3', '1', a_rate,
                      SYSDATE
                     );

         COMMIT;

         INSERT INTO pnl3_map003_expense_ratio
                     (period, profit_center, company_code,
                      end_customer_id, r_kind, area1, area2, area3, rate,
                      change_date
                     )
              VALUES (inperiod, rec1.profit_center, rec2.company_code,
                      rec2.end_customer_id, 'PL01', '4', '3', '2', a_rate,
                      SYSDATE
                     );

         COMMIT;

         INSERT INTO pnl3_map003_expense_ratio
                     (period, profit_center, company_code,
                      end_customer_id, r_kind, area1, area2, area3, rate,
                      change_date
                     )
              VALUES (inperiod, rec1.profit_center, rec2.company_code,
                      rec2.end_customer_id, 'PL01', '4', '3', '3', a_rate,
                      SYSDATE
                     );

         COMMIT;

         INSERT INTO pnl3_map003_expense_ratio
                     (period, profit_center, company_code,
                      end_customer_id, r_kind, area1, area2, area3, rate,
                      change_date
                     )
              VALUES (inperiod, rec1.profit_center, rec2.company_code,
                      rec2.end_customer_id, 'PL01', '4', '3', '4', a_rate,
                      SYSDATE
                     );

         COMMIT;
      END LOOP;
   END LOOP;

   ----> 以PROFIT CENTER來看 CUSTOMER REVENUE比率 邏輯開始 ----->
   DELETE FROM pnl3_map003_expense_pc_ratio
         WHERE period = inperiod;

   COMMIT;

   FOR rec1 IN (SELECT   profit_center, SUM (headcount) AS headcount
                    FROM pnl2_upl006_headcount
                   WHERE period = inperiod AND CATEGORY <> 'RD'
                  HAVING SUM (headcount) <> 0
                GROUP BY profit_center)
   LOOP
      FOR rec2 IN (SELECT   end_customer_id, SUM (headcount) headcount
                       FROM pnl2_upl006_headcount
                      WHERE profit_center = rec1.profit_center
                        AND period = inperiod
                         AND CATEGORY <> 'RD'
                     HAVING SUM (headcount) <> 0
                   GROUP BY end_customer_id
                   ORDER BY headcount DESC)
      LOOP
         IF rec2.headcount = 0
         THEN
            a_rate := 0;
         ELSE
            a_rate := rec2.headcount / rec1.headcount;
         END IF;

         INSERT INTO pnl3_map003_expense_pc_ratio
                     (period, profit_center, end_customer_id,
                      r_kind, area1, area2, area3, rate, change_date
                     )
              VALUES (inperiod, rec1.profit_center, rec2.end_customer_id,
                      'PL01', '4', '1', '1', a_rate, SYSDATE
                     );

         COMMIT;

         INSERT INTO pnl3_map003_expense_pc_ratio
                     (period, profit_center, end_customer_id,
                      r_kind, area1, area2, area3, rate, change_date
                     )
              VALUES (inperiod, rec1.profit_center, rec2.end_customer_id,
                      'PL01', '4', '1', '2', a_rate, SYSDATE
                     );

         COMMIT;

         INSERT INTO pnl3_map003_expense_pc_ratio
                     (period, profit_center, end_customer_id,
                      r_kind, area1, area2, area3, rate, change_date
                     )
              VALUES (inperiod, rec1.profit_center, rec2.end_customer_id,
                      'PL01', '4', '1', '3', a_rate, SYSDATE
                     );

         COMMIT;

         INSERT INTO pnl3_map003_expense_pc_ratio
                     (period, profit_center, end_customer_id,
                      r_kind, area1, area2, area3, rate, change_date
                     )
              VALUES (inperiod, rec1.profit_center, rec2.end_customer_id,
                      'PL01', '4', '1', '4', a_rate, SYSDATE
                     );

         COMMIT;

         INSERT INTO pnl3_map003_expense_pc_ratio
                     (period, profit_center, end_customer_id,
                      r_kind, area1, area2, area3, rate, change_date
                     )
              VALUES (inperiod, rec1.profit_center, rec2.end_customer_id,
                      'PL01', '4', '1', '5', a_rate, SYSDATE
                     );

         COMMIT;

         INSERT INTO pnl3_map003_expense_pc_ratio
                     (period, profit_center, end_customer_id,
                      r_kind, area1, area2, area3, rate, change_date
                     )
              VALUES (inperiod, rec1.profit_center, rec2.end_customer_id,
                      'PL01', '4', '1', '6', a_rate, SYSDATE
                     );

         COMMIT;

         INSERT INTO pnl3_map003_expense_pc_ratio
                     (period, profit_center, end_customer_id,
                      r_kind, area1, area2, area3, rate, change_date
                     )
              VALUES (inperiod, rec1.profit_center, rec2.end_customer_id,
                      'PL01', '4', '1', '7', a_rate, SYSDATE
                     );

         COMMIT;

         INSERT INTO pnl3_map003_expense_pc_ratio
                     (period, profit_center, end_customer_id,
                      r_kind, area1, area2, area3, rate, change_date
                     )
              VALUES (inperiod, rec1.profit_center, rec2.end_customer_id,
                      'PL01', '4', '2', '1', a_rate, SYSDATE
                     );

         COMMIT;

         INSERT INTO pnl3_map003_expense_pc_ratio
                     (period, profit_center, end_customer_id,
                      r_kind, area1, area2, area3, rate, change_date
                     )
              VALUES (inperiod, rec1.profit_center, rec2.end_customer_id,
                      'PL01', '4', '2', '2', a_rate, SYSDATE
                     );

         COMMIT;

         INSERT INTO pnl3_map003_expense_pc_ratio
                     (period, profit_center, end_customer_id,
                      r_kind, area1, area2, area3, rate, change_date
                     )
              VALUES (inperiod, rec1.profit_center, rec2.end_customer_id,
                      'PL01', '4', '2', '3', a_rate, SYSDATE
                     );

         COMMIT;

         INSERT INTO pnl3_map003_expense_pc_ratio
                     (period, profit_center, end_customer_id,
                      r_kind, area1, area2, area3, rate, change_date
                     )
              VALUES (inperiod, rec1.profit_center, rec2.end_customer_id,
                      'PL01', '4', '2', '4', a_rate, SYSDATE
                     );

         COMMIT;
      END LOOP;
   END LOOP;

   FOR rec1 IN (SELECT   profit_center, SUM (headcount) AS headcount
                    FROM pnl2_upl006_headcount
                   WHERE period = inperiod AND CATEGORY = 'RD'
                  HAVING SUM (headcount) <> 0
                GROUP BY profit_center)
   LOOP
      FOR rec2 IN (SELECT   end_customer_id, SUM (headcount) headcount
                       FROM pnl2_upl006_headcount
                      WHERE profit_center = rec1.profit_center
                        AND period = inperiod
                         AND CATEGORY = 'RD'
                     HAVING SUM (headcount) <> 0
                   GROUP BY end_customer_id
                   ORDER BY headcount DESC)
      LOOP
         IF rec2.headcount = 0
         THEN
            a_rate := 0;
         ELSE
            a_rate := rec2.headcount / rec1.headcount;
         END IF;

         INSERT INTO pnl3_map003_expense_pc_ratio
                     (period, profit_center, end_customer_id,
                      r_kind, area1, area2, area3, rate, change_date
                     )
              VALUES (inperiod, rec1.profit_center, rec2.end_customer_id,
                      'PL01', '4', '3', '1', a_rate, SYSDATE
                     );

         COMMIT;

         INSERT INTO pnl3_map003_expense_pc_ratio
                     (period, profit_center, end_customer_id,
                      r_kind, area1, area2, area3, rate, change_date
                     )
              VALUES (inperiod, rec1.profit_center, rec2.end_customer_id,
                      'PL01', '4', '3', '2', a_rate, SYSDATE
                     );

         COMMIT;

         INSERT INTO pnl3_map003_expense_pc_ratio
                     (period, profit_center, end_customer_id,
                      r_kind, area1, area2, area3, rate, change_date
                     )
              VALUES (inperiod, rec1.profit_center, rec2.end_customer_id,
                      'PL01', '4', '3', '3', a_rate, SYSDATE
                     );

         COMMIT;

         INSERT INTO pnl3_map003_expense_pc_ratio
                     (period, profit_center, end_customer_id,
                      r_kind, area1, area2, area3, rate, change_date
                     )
              VALUES (inperiod, rec1.profit_center, rec2.end_customer_id,
                      'PL01', '4', '3', '4', a_rate, SYSDATE
                     );

         COMMIT;
      END LOOP;
   END LOOP;

   ----> 以PROFIT CENTER來看 CUSTOMER REVENUE比率 邏輯結束<-------------

   ----> 全公司的END CUSTOMER REVENUE比率(不看SITE和PROFIT CENTER) 開始
   DELETE FROM pnl3_map003_expense_ww_ratio
         WHERE period = inperiod;

   COMMIT;
   a_hc := 0;

   BEGIN
      SELECT SUM (headcount)
        INTO a_hc
        FROM pnl2_upl006_headcount
        
       WHERE period = inperiod
         AND CATEGORY <> 'RD';
   EXCEPTION
      WHEN OTHERS
      THEN
         a_hc := 0;
   END;

   IF a_hc <> 0
   THEN
      FOR rec1 IN (SELECT   end_customer_id, SUM (headcount) AS headcount
                       FROM pnl2_upl006_headcount
                      WHERE period = inperiod AND CATEGORY <> 'RD'
                     HAVING SUM (headcount) <> 0
                   GROUP BY end_customer_id)
      LOOP
         a_rate := rec1.headcount / a_hc;

         INSERT INTO pnl3_map003_expense_ww_ratio
                     (period, end_customer_id, r_kind, area1, area2, area3,
                      rate, change_date
                     )
              VALUES (inperiod, rec1.end_customer_id, 'PL01', '4', '1', '1',
                      a_rate, SYSDATE
                     );

         COMMIT;

         INSERT INTO pnl3_map003_expense_ww_ratio
                     (period, end_customer_id, r_kind, area1, area2, area3,
                      rate, change_date
                     )
              VALUES (inperiod, rec1.end_customer_id, 'PL01', '4', '1', '2',
                      a_rate, SYSDATE
                     );

         COMMIT;

         INSERT INTO pnl3_map003_expense_ww_ratio
                     (period, end_customer_id, r_kind, area1, area2, area3,
                      rate, change_date
                     )
              VALUES (inperiod, rec1.end_customer_id, 'PL01', '4', '1', '3',
                      a_rate, SYSDATE
                     );

         COMMIT;

         INSERT INTO pnl3_map003_expense_ww_ratio
                     (period, end_customer_id, r_kind, area1, area2, area3,
                      rate, change_date
                     )
              VALUES (inperiod, rec1.end_customer_id, 'PL01', '4', '1', '4',
                      a_rate, SYSDATE
                     );

         COMMIT;

         INSERT INTO pnl3_map003_expense_ww_ratio
                     (period, end_customer_id, r_kind, area1, area2, area3,
                      rate, change_date
                     )
              VALUES (inperiod, rec1.end_customer_id, 'PL01', '4', '1', '5',
                      a_rate, SYSDATE
                     );

         COMMIT;

         INSERT INTO pnl3_map003_expense_ww_ratio
                     (period, end_customer_id, r_kind, area1, area2, area3,
                      rate, change_date
                     )
              VALUES (inperiod, rec1.end_customer_id, 'PL01', '4', '1', '6',
                      a_rate, SYSDATE
                     );

         COMMIT;

         INSERT INTO pnl3_map003_expense_ww_ratio
                     (period, end_customer_id, r_kind, area1, area2, area3,
                      rate, change_date
                     )
              VALUES (inperiod, rec1.end_customer_id, 'PL01', '4', '1', '7',
                      a_rate, SYSDATE
                     );

         COMMIT;

         INSERT INTO pnl3_map003_expense_ww_ratio
                     (period, end_customer_id, r_kind, area1, area2, area3,
                      rate, change_date
                     )
              VALUES (inperiod, rec1.end_customer_id, 'PL01', '4', '2', '1',
                      a_rate, SYSDATE
                     );

         COMMIT;

         INSERT INTO pnl3_map003_expense_ww_ratio
                     (period, end_customer_id, r_kind, area1, area2, area3,
                      rate, change_date
                     )
              VALUES (inperiod, rec1.end_customer_id, 'PL01', '4', '2', '2',
                      a_rate, SYSDATE
                     );

         COMMIT;

         INSERT INTO pnl3_map003_expense_ww_ratio
                     (period, end_customer_id, r_kind, area1, area2, area3,
                      rate, change_date
                     )
              VALUES (inperiod, rec1.end_customer_id, 'PL01', '4', '2', '3',
                      a_rate, SYSDATE
                     );

         COMMIT;

         INSERT INTO pnl3_map003_expense_ww_ratio
                     (period, end_customer_id, r_kind, area1, area2, area3,
                      rate, change_date
                     )
              VALUES (inperiod, rec1.end_customer_id, 'PL01', '4', '2', '4',
                      a_rate, SYSDATE
                     );

         COMMIT;
      END LOOP;

   a_hc := 0;

   BEGIN
      SELECT SUM (headcount)
        INTO a_hc
        FROM pnl2_upl006_headcount
        
       WHERE period = inperiod
         AND CATEGORY = 'RD';
   EXCEPTION
      WHEN OTHERS
      THEN
         a_hc := 0;
   END;


      FOR rec1 IN (SELECT   end_customer_id, SUM (headcount) AS headcount
                       FROM pnl2_upl006_headcount
                      WHERE period = inperiod AND CATEGORY = 'RD'
                     HAVING SUM (headcount) <> 0
                   GROUP BY end_customer_id)
      LOOP
         a_rate := rec1.headcount / a_hc;

         INSERT INTO pnl3_map003_expense_ww_ratio
                     (period, end_customer_id, r_kind, area1, area2, area3,
                      rate, change_date
                     )
              VALUES (inperiod, rec1.end_customer_id, 'PL01', '4', '3', '1',
                      a_rate, SYSDATE
                     );

         COMMIT;

         INSERT INTO pnl3_map003_expense_ww_ratio
                     (period, end_customer_id, r_kind, area1, area2, area3,
                      rate, change_date
                     )
              VALUES (inperiod, rec1.end_customer_id, 'PL01', '4', '3', '2',
                      a_rate, SYSDATE
                     );

         COMMIT;

         INSERT INTO pnl3_map003_expense_ww_ratio
                     (period, end_customer_id, r_kind, area1, area2, area3,
                      rate, change_date
                     )
              VALUES (inperiod, rec1.end_customer_id, 'PL01', '4', '3', '3',
                      a_rate, SYSDATE
                     );

         COMMIT;

         INSERT INTO pnl3_map003_expense_ww_ratio
                     (period, end_customer_id, r_kind, area1, area2, area3,
                      rate, change_date
                     )
              VALUES (inperiod, rec1.end_customer_id, 'PL01', '4', '3', '4',
                      a_rate, SYSDATE
                     );

         COMMIT;
      END LOOP;
   END IF;
----> 全公司的END CUSTOMER REVENUE比率(不看SITE和PROFIT CENTER) 邏輯結束 <----
END pnl3_pls006_expense_ratio_trx;
/

