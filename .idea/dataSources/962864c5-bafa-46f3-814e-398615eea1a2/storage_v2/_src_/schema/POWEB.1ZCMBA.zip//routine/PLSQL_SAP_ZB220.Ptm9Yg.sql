create PROCEDURE PLSQL_SAP_ZB220(
  inCompany  in SAP_ZRCON220_DATA.COMPANY_CODE%TYPE,
  f_YYYYMMDD in VARCHAR2,
  t_YYYYMMDD in VARCHAR2
)
is
 iTracePoint  integer ;
 cErrorText varchar2(500);
 vPROCEE_YYYYMMDD varchar2(8);

BEGIN
  iTracePoint := '000';


  --vPROCEE_YYYYMMDD  :=  to_char(sysdate-1,'YYYYMMDD');

  DELETE FROM SAP_ZRCON220_DATA WHERE COMPANY_CODE =inCompany;

  iTracePoint := '100';
  Insert into SAP_ZRCON220_DATA (
        COMPANY_CODE , PART_NO, WO_NO, PLANT, PROD_LINE, MT_GRP, WO_QTY, GR_QTY, INPUT_AMT, GR_AMT, WIP_AMT, LOC_CURR, DOWN_DATE )
   Select  COMPANY_CODE , PART_NO, WO_NO, PLANT, PROD_LINE, MT_GRP, WO_QTY, GR_QTY, INPUT_AMT, GR_AMT, WIP_AMT, LOC_CURR, DOWN_DATE
     from SAP_ZRCON220_DATA_T
    where COMPANY_CODE= inCompany;

   iTracePoint := '200';
   DELETE  from SAP_ZRCON220_DATA_T
    where COMPANY_CODE = inCompany;



   Commit;
EXCEPTION
   When OTHERS Then
    --有錯誤產生則寄mail
    cErrorText := SQLERRM();
    MAIL_FILE_BIDBDBADMIN(in_to_name => 'sam_chen@ms.usi.com.tw', subject => '[VRT] PL/SQL SAP_ZRCON220_DATA', message => '[SAP_ZRCON220_DATA], The tracepoint is  ' || iTracePoint || ' and ErrorText= ' || cErrorText) ;


END PLSQL_SAP_ZB220;
/

