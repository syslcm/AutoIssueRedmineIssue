create PROCEDURE "PLSQL_EGI_SAP_ZAPD345_T"
is
   iTracePoint     integer ;
   cErrorText      varchar2(500) ;
   cCOMPANY_ALIAS  varchar2(2);
   iCOUNT          number(6);
   cTIME_CREATE    varchar2(14);
   cDOC_ID         varchar2(30);
   a_EX_RATE_TWD       KPI_SAP001_COPA_TRX.EX_RATE_TWD%TYPE;

BEGIN
   --site
   --new add
   iTracePoint := 200;
   for REC1 in (
     select distinct SUBSTRB(P_DATE,1,6) as P_DATE, LOC_CURR
       from EGI_SAP_ZAPD345_T
      where MFG_SITE <> '1100'
   ) loop
     a_EX_RATE_TWD := GET_EXCHANGE_RATE(SUBSTRB(REC1.P_DATE,1,4),SUBSTRB(REC1.P_DATE,5,2),trim(REC1.LOC_CURR),'TWD','T') ;
     Update EGI_SAP_ZAPD345_T set TWD_NET = round(L_NET * a_EX_RATE_TWD, 6)
	  where SUBSTRB(P_DATE,1,6) = REC1.P_DATE
	    and LOC_CURR = REC1.LOC_CURR
		and DC = 'S';
     Update EGI_SAP_ZAPD345_T set TWD_NET = round(L_NET * a_EX_RATE_TWD * -1, 6)
	  where SUBSTRB(P_DATE,1,6) = REC1.P_DATE
	    and LOC_CURR = REC1.LOC_CURR
		and DC = 'H';
     commit;
   end loop;

EXCEPTION
  WHEN OTHERS THEN
    cErrorText := SQLERRM() ;
    MAIL_FILE_BIDBDBADMIN(in_to_name=>'minhorng@ms.usi.com.tw',subject   => '[IMS]PL/SQL IMS_PLSQL031_NONINFOREC ERROR', message => '[IMS_PLSQL031_NONINFOREC], The tracepoint is  ' || to_char(iTracePoint) || ' and ErrorText=' || cErrorText) ;
End PLSQL_EGI_SAP_ZAPD345_T;
/

