create PROCEDURE         "PLSQL_PLD_KPI_RFQ_LAST_PRICE" (
  inCompany  in VARCHAR2,
  f_YYYYMMDD in VARCHAR2,
  t_YYYYMMDD in VARCHAR2
)
/***********************************************************************
  PROG-ID      : PLSQL_PLD_KPI_RFQ_LAST_PRICE
  PROG-ACTION  : Get LAST PO PRICE From PLD_KPI_RFQ_LAST_PRICE_VIEW
                              (POWEB.VENDOR_QUOTA@RFQPRD.WORLD)
                 INSERT INTO PLD_KPI_RFQ_LAST_PRICE
  Author       : KATHY
  Date         : 2008/04/14
  UPDATE Date  : 2008/XX/XX
-------------------------------------------------------------------------------------------
--Run PLSQL WITH table:KPI_SAP017_ZB027_DATA_T (SEQ-03)
-------------------------------------------------------------------------------------------
*/
--***********************************************************************
AUTHID DEFINER
is

BEGIN
  DELETE FROM PLD_KPI_RFQ_LAST_PRICE;

   Insert into PLD_KPI_RFQ_LAST_PRICE (
          PART_NO, GVC_CODE, RFQ_PRICE, 
          RFQ_CURRENCY, QUOTE_DATE )
   Select PART_NO, GVC_CODE, RFQ_PRICE, 
          RFQ_CURRENCY, QUOTE_DATE
     from PLD_KPI_RFQ_LAST_PRICE_VIEW;
   Commit;

END PLSQL_PLD_KPI_RFQ_LAST_PRICE;
/

