create PROCEDURE PLSQL_PLD_KPI_VMI_SLM (
  inCompany  in VARCHAR2,
  f_YYYYMMDD in VARCHAR2,
  t_YYYYMMDD in VARCHAR2
)
AUTHID DEFINER
/*********************************************************************
  PROG-ID      : PLSQL_PLD_KPI_VMI_SLM
  PROG-ACTION  : PROCESS PLD_KPI_VMI_SLM_T TO PLD_KPI_VMI_SLM
  Author       : KATHY
  Date         : 2007/07/06
**********************************************************************/
is

  --找出 PLD_KPI_VMI_SLM_T 的 END_DATE+COMPANY_CODE
  CURSOR C_PLD_KPI_VMI_SLM_T is
    Select END_DATE, COMPANY_CODE
      from PLD_KPI_VMI_SLM_T
    where COMPANY_CODE = inCompany
     Group by END_DATE, COMPANY_CODE;

   v_END_DATE          VARCHAR2(8);
   nER_CNY_TWD         EGI0020_EXCHANGE_RATE.EXCHANGE_RATE%TYPE;
   nER_JPY_TWD         EGI0020_EXCHANGE_RATE.EXCHANGE_RATE%TYPE;
   nER_MXN_TWD         EGI0020_EXCHANGE_RATE.EXCHANGE_RATE%TYPE;
   nER_USD_TWD         EGI0020_EXCHANGE_RATE.EXCHANGE_RATE%TYPE;

BEGIN
   --取最後一筆 END_DATE
   FOR REC1 in C_PLD_KPI_VMI_SLM_T Loop
       v_END_DATE := REC1.END_DATE;
   END LOOP;


   --抓匯率 CNY -> TWD
   nER_CNY_TWD := Null;
   Select * into nER_CNY_TWD From (
     Select EXCHANGE_RATE from EGI0020_EXCHANGE_RATE
      where (VALID_FROM_DATEYYMM || VALID_FROM_DATEDD) <= v_END_DATE
        and TRIM(FROM_CURRENCY) = 'CNY'
        and TRIM(TO_CURRENCY) = 'TWD'
      order by (VALID_FROM_DATEYYMM || VALID_FROM_DATEDD) Desc
   ) Where ROWNUM <= 1;

   --抓匯率 JPY -> TWD
   nER_JPY_TWD := Null;
   Select * into nER_JPY_TWD From (
     Select EXCHANGE_RATE from EGI0020_EXCHANGE_RATE
      where (VALID_FROM_DATEYYMM || VALID_FROM_DATEDD) <= v_END_DATE
        and TRIM(FROM_CURRENCY) = 'JPY'
        and TRIM(TO_CURRENCY) = 'TWD'
      order by (VALID_FROM_DATEYYMM || VALID_FROM_DATEDD) Desc
   ) Where ROWNUM <= 1;

   --抓匯率 MXN -> TWD
   nER_MXN_TWD := Null;
   Select * into nER_MXN_TWD From (
     Select EXCHANGE_RATE from EGI0020_EXCHANGE_RATE
      where (VALID_FROM_DATEYYMM || VALID_FROM_DATEDD) <= v_END_DATE
        and TRIM(FROM_CURRENCY) = 'MXN'
        and TRIM(TO_CURRENCY) = 'TWD'
      order by (VALID_FROM_DATEYYMM || VALID_FROM_DATEDD) Desc
   ) Where ROWNUM <= 1;

   --抓匯率 USD -> TWD
   nER_USD_TWD := Null;
   Select * into nER_USD_TWD From (
     Select EXCHANGE_RATE from EGI0020_EXCHANGE_RATE
      where (VALID_FROM_DATEYYMM || VALID_FROM_DATEDD) <= v_END_DATE
        and TRIM(FROM_CURRENCY) = 'USD'
        and TRIM(TO_CURRENCY) = 'TWD'
      order by (VALID_FROM_DATEYYMM || VALID_FROM_DATEDD) Desc
   ) Where ROWNUM <= 1;

   --清除舊的 PLD_KPI_VMI_SLM 資料
   FOR REC1 in C_PLD_KPI_VMI_SLM_T Loop
      Delete from PLD_KPI_VMI_SLM
       where COMPANY_CODE = inCompany
         and END_DATE = REC1.END_DATE;
      Commit;
   END LOOP;

   --計算 台幣 & 美金
     If inCompany = '1100' Then
        UPDATE PLD_KPI_VMI_SLM_T
           SET AMT_TWD = VMI_AMT,
               AMT_USD = ROUND(AMT_TWD / nER_USD_TWD, 5);
     ElsIf inCompany = '1200' Then
        UPDATE PLD_KPI_VMI_SLM_T
           SET AMT_TWD = ROUND(VMI_AMT * nER_CNY_TWD, 5),
               AMT_USD = ROUND(AMT_TWD / nER_USD_TWD, 5);
     ElsIf inCompany = '1500' Then
        UPDATE PLD_KPI_VMI_SLM_T
           SET AMT_TWD = ROUND(VMI_AMT * nER_CNY_TWD, 5),
               AMT_USD = ROUND(AMT_TWD / nER_USD_TWD, 5);
     ElsIf inCompany = '2300' Then
        UPDATE PLD_KPI_VMI_SLM_T
           SET AMT_TWD = ROUND(VMI_AMT * nER_MXN_TWD, 5),
               AMT_USD = ROUND(AMT_TWD / nER_USD_TWD, 5);
     End If;
     Commit;


   -- PLD_KPI_VMI_SLM_T -> PLD_KPI_VMI_SLM
   Insert into PLD_KPI_VMI_SLM
        Select * From PLD_KPI_VMI_SLM_T
         where COMPANY_CODE = inCompany;
   Commit;

END PLSQL_PLD_KPI_VMI_SLM;
/

