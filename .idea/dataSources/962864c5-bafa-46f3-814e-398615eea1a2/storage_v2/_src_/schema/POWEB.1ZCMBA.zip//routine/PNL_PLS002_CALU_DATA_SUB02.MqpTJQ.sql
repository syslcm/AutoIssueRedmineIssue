create PROCEDURE PNL_PLS002_CALU_DATA_SUB02 (
  inCompany  in VARCHAR2,
  f_YYYYMMDD in VARCHAR2,
  t_YYYYMMDD in VARCHAR2
)
AUTHID DEFINER
/*********************************************************************
  PROG-ID      : PNL_PLS002_CALU_DATA_SUB02
  PROG-ACTION  : PROCESS PNL_VIEW001_ALL_EM_DATA  TO PNL_TRX001_DATA(02-ACT)
               : AMOUNT
  Author       : KANGI
  Date         : 2007/03/27
**********************************************************************/
is
   iTracePoint  integer ;
   cErrorText varchar2(500) ;
   cPNL_YYYY PNL_TRX001_DATA.YEAR%TYPE;
   fUSD_TO_TWD_RATE float ;
   dRUNDATE DATE ;

 BEGIN
   iTracePoint := 100 ;
   cPNL_YYYY := TO_CHAR(SYSDATE,'YYYY');
   dRUNDATE := SYSDATE ;
   iTracePoint := 200 ;
   ----DELETE PNL_MSS001_BGT_DATA
   DELETE PNL_TRX001_DATA WHERE YEAR = cPNL_YYYY AND TOP_KIND = '02-ACT';
   iTracePoint := 300 ;

   ----INSERT PNL_TRX001_DATA FROM PNL_VIEW001_ALL_EM_DATA
   ---BUDGET ('REV','DM','DL','OH','AD','RD')
   ---BUDGET ('01.1','02.1','02.2','02.3','03.2','03.3')
   INSERT INTO PNL_TRX001_DATA
   SELECT COMPANY_CODE,YYYY YEAR,YYYY||MONTH PERIOD,
       PROFIT_CENTER,'02-ACT' TOP_KIND,
	   SUBSTR(ACCOUNT2,1,4) SIDE_KIND,
	   'Actual' TOP_PERIOD,
	   SUM(AMOUNT)*1000 AMT_LOCAL,SUM(AMOUNT)*1000*GET_EXCHANGE_RATE(YYYY,MONTH,'TWD','USD','T') AMT_USD,
	   SUM(AMOUNT)*1000 AMT_TWD,NULL TO_PERIOD,
	   dRUNDATE
	   FROM PNL_VIEW001_ALL_EM_DATA
     WHERE YYYY = cPNL_YYYY
       AND TYPE_2 = 'Actual'
       AND SUBSTR(ACCOUNT2,1,4) IN ('01.1','02.1','02.2','02.3','03.2','03.3')
       AND AMOUNT <> 0
       GROUP BY COMPANY_CODE,YYYY,MONTH,PROFIT_CENTER,ACCOUNT2 ;
    iTracePoint := 400 ;

    ---BUDGET ('SALE')
    ---BUDGET ('03.1')
    INSERT INTO PNL_TRX001_DATA
    SELECT COMPANY_CODE,YYYY YEAR,YYYY||MONTH PERIOD,
           PROFIT_CENTER,'02-ACT' TOP_KIND,
	         DECODE(SUBSTR(ACCOUNT3,1,6),'03.1.1','03.1.1','03.1.2','03.1.2','03.1.3','03.1.3','03.1.A') SIDE_KIND,
	         'Actual' TOP_PERIOD,
	         SUM(AMOUNT)*1000 AMT_LOCAL,SUM(AMOUNT)*1000*GET_EXCHANGE_RATE(YYYY,MONTH,'TWD','USD','T') AMT_USD,
	         SUM(AMOUNT)*1000 AMT_TWD,NULL TO_PERIOD,
	         dRUNDATE
	         FROM PNL_VIEW001_ALL_EM_DATA
          WHERE YYYY = cPNL_YYYY
            AND TYPE_2 = 'Actual'
            AND SUBSTR(ACCOUNT2,1,4) IN ('03.1')
            AND AMOUNT <> 0
            GROUP BY COMPANY_CODE,YYYY,MONTH,PROFIT_CENTER,ACCOUNT3  ;

   iTracePoint := 500 ;
   COMMIT ;
 EXCEPTION
     WHEN OTHERS THEN
            --rollback ;
            cErrorText := SQLERRM() ;
            MAIL_FILE_BIDBDBADMIN(in_to_name=>'kangi@ms.usi.com.tw',subject   => 'PL/SQL PNL_PLS002_CALU_DATA_SUB02 ERROR', message => '[PNL_PLS002_CALU_DATA_SUB02], The tracepoint is  ' || to_char(iTracePoint) || 'and ErrorText=' || cErrorText) ;
            DBMS_OUTPUT.PUT_LINE(SUBSTR(cErrorText,1,255));
            DBMS_OUTPUT.PUT_LINE(TO_CHAR(iTracePoint));
END PNL_PLS002_CALU_DATA_SUB02;
/

