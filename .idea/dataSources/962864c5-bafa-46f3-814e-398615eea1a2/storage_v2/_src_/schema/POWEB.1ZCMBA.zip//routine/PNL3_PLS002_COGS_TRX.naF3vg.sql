create PROCEDURE       PNL3_PLS002_COGS_TRX (
  --inCompany  in VARCHAR2,
  inPeriod in VARCHAR2
  --inPC in VARCHAR2
  --2008/9/17 Create to Process get Amount in Local/USD/TWD
  --Trigger by PNL2_BAD_DEPT_UPLOAD.JSP
  --2009/1/20 增加project name,project type
)
AUTHID DEFINER
is
  CURSOR C_PNL2_DIRECT is
--2008/11/7 有發現  SUM(NET_REVENUE) <> 0 OR SUM(NET_COGS)  <> 0 條件成立但dm/dl/oh卻有值的戕況,因此不加入此條件
-- 在INSERT進資料庫時再排除金額=0的資料
   --不會有NET_REVENUE資料
    SELECT COMPANY_CODE,PROFIT_CENTER,COST_ELEMENT,CUSTOMER_ID as BILL_TO_PARTY,SHIP_TO_PARTY,MTL_GROUP,PART_NO,PLANT_CODE,MTL_TYPE,
           SUM(NET_REVENUE) AMT_LOCAL,SUM(NET_REVENUE_USD) AMT_USD,SUM(NET_REVENUE_TWD) AMT_TWD,
           SUM(COGS_MB) COGS_DM_LOCAL,SUM(COGS_MB_USD) COGS_DM_USD,SUM(COGS_MB_TWD) COGS_DM_TWD,
           SUM(COGS_LB) COGS_DL_LOCAL,SUM(COGS_LB_USD) COGS_DL_USD,SUM(COGS_LB_TWD) COGS_DL_TWD,
           SUM(COGS_OB) COGS_OH_LOCAL,SUM(COGS_OB_USD) COGS_OH_USD,SUM(COGS_OB_TWD) COGS_OH_TWD
    FROM KPI_SAP001_COPA_TRX
    WHERE  PERIOD = inPeriod 
      AND    ( NET_REVENUE <> 0 OR NET_COGS <>  0)
      AND    RELATED_PARTY <> 'Y'
      AND COST_ELEMENT IN ('0000510109','0000510110')
    GROUP BY COMPANY_CODE,PROFIT_CENTER,COST_ELEMENT,CUSTOMER_ID ,SHIP_TO_PARTY,MTL_GROUP,PART_NO,PLANT_CODE,MTL_TYPE;
    --HAVING ( SUM(NET_REVENUE) <> 0 OR SUM(NET_COGS)  <> 0 );
  


   --不會有NET_REVENUE資料
  CURSOR C_PNL3_SZ is
    SELECT COMPANY_CODE,PROFIT_CENTER,COST_ELEMENT,CUSTOMER_ID as BILL_TO_PARTY,SHIP_TO_PARTY,MTL_GROUP,PART_NO,PLANT_CODE,MTL_TYPE,
           SUM(NET_REVENUE) AMT_LOCAL,SUM(NET_REVENUE_USD) AMT_USD,SUM(NET_REVENUE_TWD) AMT_TWD,
           SUM(COGS_MB) COGS_DM_LOCAL,SUM(COGS_MB_USD) COGS_DM_USD,SUM(COGS_MB_TWD) COGS_DM_TWD,
           SUM(COGS_LB) COGS_DL_LOCAL,SUM(COGS_LB_USD) COGS_DL_USD,SUM(COGS_LB_TWD) COGS_DL_TWD,
           SUM(COGS_OB) COGS_OH_LOCAL,SUM(COGS_OB_USD) COGS_OH_USD,SUM(COGS_OB_TWD) COGS_OH_TWD
    FROM KPI_SAP001_COPA_TRX
    WHERE  PERIOD = inPeriod 
      AND    ( NET_REVENUE <> 0 OR NET_COGS <>  0)
      AND    RELATED_PARTY <> 'Y'
      AND COST_ELEMENT = '0000530101'
    GROUP BY COMPANY_CODE,PROFIT_CENTER,COST_ELEMENT,CUSTOMER_ID ,SHIP_TO_PARTY,MTL_GROUP,PART_NO,PLANT_CODE,MTL_TYPE;



  --Revenue 只能以profit center觀點來看,不要加入company_code,像22 在CA只有成本,沒有營收,所以就會漏掉
  CURSOR C_PNL2_REVENUE is
     SELECT PROFIT_CENTER,SUM(AMT_TWD) AMT_TWD
     FROM  PNL3_TRX001_COPA
     WHERE PERIOD = inPeriod 
     AND AREA1 = '1'
     AND AREA2 = '1'
     AND AREA3 = '0'
     --AND SOURCE <> 'UPL001'  --2008/11/20 上傳的revenue也要納入考慮,否則像38的uabit有最多營收卻沒有cogs
     GROUP BY PROFIT_CENTER;
     
     a_Rate          PNL2_UPL003_REALIZED_GM.EX_RATE_USD%TYPE;
     a_ENDCUSTOMER   KPI_SAP001_COPA_TRX.END_CUSTOMER_ID%TYPE;
     a_PROFIT_CENTER PNL3_TRX001_COPA.PROFIT_CENTER%TYPE;
     a_COUNTER       integer;
 BEGIN
   DELETE FROM PNL3_TRX002_GLACCOUNT
   WHERE Period = inPeriod ;
   Commit;
   
   DELETE PNL3_TRX002_GLACCOUNT_T 
     WHERE PERIOD = inPeriod;
     commit; 
   
   FOR REC1 in C_PNL2_REVENUE Loop
      --IF REC1.AMT_TWD <> 0 THEN  --某些Profit center沒有營收,例34/9X
      --2008/11/9 流程改變後(end_customer後來才update)所以要抓PNL3_TRX001_COPA,必須把沒有營收的END_CUSTOMER補入
        PNL3_PLS002_COGS_TRX_S01(inPeriod,REC1.PROFIT_CENTER,REC1.AMT_TWD,'0000510101');
        PNL3_PLS002_COGS_TRX_S01(inPeriod,REC1.PROFIT_CENTER,REC1.AMT_TWD,'0000510103');
        PNL3_PLS002_COGS_TRX_S01(inPeriod,REC1.PROFIT_CENTER,REC1.AMT_TWD,'0000510104');
        PNL3_PLS002_COGS_TRX_S01(inPeriod,REC1.PROFIT_CENTER,REC1.AMT_TWD,'0000510107');
        PNL3_PLS002_COGS_TRX_S01(inPeriod,REC1.PROFIT_CENTER,REC1.AMT_TWD,'0000510901');
        PNL3_PLS002_COGS_TRX_S01(inPeriod,REC1.PROFIT_CENTER,REC1.AMT_TWD,'0000510902');
        PNL3_PLS002_COGS_TRX_S01(inPeriod,REC1.PROFIT_CENTER,REC1.AMT_TWD,'0000510903');
        PNL3_PLS002_COGS_TRX_S01(inPeriod,REC1.PROFIT_CENTER,REC1.AMT_TWD,'0000510909');
        PNL3_PLS002_COGS_TRX_S01(inPeriod,REC1.PROFIT_CENTER,REC1.AMT_TWD,'0000510999');
 	Update PNL3_TRX002_GLACCOUNT_T
	   Set END_CUSTOMER_ID = 'LENOVO'
     Where Period = inPeriod
	   AND PROFIT_CENTER IN ('0000000020','0000000021')
       AND MTL_GROUP BETWEEN '001' AND '059'
       AND MTL_TYPE = 'RAW'
       AND END_CUSTOMER_ID IS NULL;
    commit;
    /*

	Update PNL3_TRX002_GLACCOUNT_T
	   Set END_CUSTOMER_ID = 'LENOVO'
     Where Period = inPeriod
	   AND (PROFIT_CENTER NOT IN ('0000000020','0000000021') OR PROFIT_CENTER IS NULL)
       AND MTL_GROUP BETWEEN '001' AND '059'
       AND SEARCH_TERM = 'LENOVO'
       AND MTL_TYPE = 'RAW'
       AND END_CUSTOMER_ID IS NULL;
    commit;
    */
    
	Update PNL3_TRX002_GLACCOUNT_T
	   Set END_CUSTOMER_ID = '其他-材料轉售'
     Where Period = inPeriod
	   AND (PROFIT_CENTER NOT IN ('0000000020','0000000021') OR PROFIT_CENTER IS NULL)
       AND MTL_GROUP BETWEEN '001' AND '059'
       AND MTL_TYPE = 'RAW'
       AND END_CUSTOMER_ID IS NULL;
    commit;
 
        update PNL3_TRX002_GLACCOUNT_T 
           SET END_CUSTOMER_ID = (SELECT TRIM(END_CUSTOMER_NAME) FROM CEP_MAP009_PARTNO_CUSTOMER
			     where FG_MATERIAL_NO = rpad(PNL3_TRX002_GLACCOUNT_T.PART_NO,18,' ')
			       and LAST_MODIFY_DATE <= SYSDATE AND ROWNUM = 1)
         WHERE PERIOD = inPeriod
           AND PROFIT_CENTER = REC1.PROFIT_CENTER
           AND END_CUSTOMER_ID IS NULL;
         commit;
         -- 2008/12/24 ADD ---->
         update PNL3_TRX002_GLACCOUNT_T 
           SET END_CUSTOMER_ID = (SELECT TRIM(b.end_customer_name)
                          FROM cep_zot001_fg_bom_list_f a,
                               cep_map009_partno_customer b
                         WHERE a.fg_material_no= b.fg_material_no
                           AND a.raw_material_no= rpad(PNL3_TRX002_GLACCOUNT_T.PART_NO,18,' ')
                           AND a.PLANT = PNL3_TRX002_GLACCOUNT_T.PLANT_CODE
                           AND a.MFG_SITE = PNL3_TRX002_GLACCOUNT_T.COMPANY_CODE
                           AND b.last_modify_date <= SYSDATE
                           AND ROWNUM = 1)
         WHERE PERIOD = inPeriod
           AND PROFIT_CENTER = REC1.PROFIT_CENTER
           AND END_CUSTOMER_ID IS NULL
           AND COST_ELEMENT IN ('0000510901','0000510902');
         commit;
         -- 2008/12/24 ADD <---
        PNL3_PLS002_COGS_TRX_S02(inPeriod,REC1.PROFIT_CENTER,REC1.AMT_TWD,'0000510101');
        PNL3_PLS002_COGS_TRX_S02(inPeriod,REC1.PROFIT_CENTER,REC1.AMT_TWD,'0000510103');
        PNL3_PLS002_COGS_TRX_S02(inPeriod,REC1.PROFIT_CENTER,REC1.AMT_TWD,'0000510104');
        PNL3_PLS002_COGS_TRX_S02(inPeriod,REC1.PROFIT_CENTER,REC1.AMT_TWD,'0000510107');
        PNL3_PLS002_COGS_TRX_S02(inPeriod,REC1.PROFIT_CENTER,REC1.AMT_TWD,'0000510901');
        PNL3_PLS002_COGS_TRX_S02(inPeriod,REC1.PROFIT_CENTER,REC1.AMT_TWD,'0000510902');
        PNL3_PLS002_COGS_TRX_S02(inPeriod,REC1.PROFIT_CENTER,REC1.AMT_TWD,'0000510903');
        PNL3_PLS002_COGS_TRX_S02(inPeriod,REC1.PROFIT_CENTER,REC1.AMT_TWD,'0000510909');
        PNL3_PLS002_COGS_TRX_S02(inPeriod,REC1.PROFIT_CENTER,REC1.AMT_TWD,'0000510999');
      --END IF;
   END LOOP;
   
   FOR REC1 in (SELECT PROFIT_CENTER
        FROM KPI_SAP001_COPA_TRX
       WHERE  PERIOD = inPeriod 
         AND    ( NET_REVENUE <> 0 OR NET_COGS <>  0)
         AND    RELATED_PARTY <> 'Y'
         GROUP BY PROFIT_CENTER) Loop
         
         a_PROFIT_CENTER := NULL;
         BEGIN
           SELECT DISTINCT PROFIT_CENTER INTO a_PROFIT_CENTER
              FROM PNL3_TRX001_COPA
             WHERE PERIOD = inPeriod 
               AND PROFIT_CENTER = REC1.PROFIT_CENTER
               --AND SOURCE <> 'UPL001'
               AND AREA1 = '1'
               AND AREA2 = '1'
               AND AREA3 = '0';
         EXCEPTION
            WHEN OTHERS THEN
             a_PROFIT_CENTER := NULL;
         END;
         IF a_PROFIT_CENTER  IS NULL THEN
           PNL3_PLS002_COGS_TRX_S01(inPeriod,REC1.PROFIT_CENTER,0,'0000510101');
           PNL3_PLS002_COGS_TRX_S01(inPeriod,REC1.PROFIT_CENTER,0,'0000510103');
           PNL3_PLS002_COGS_TRX_S01(inPeriod,REC1.PROFIT_CENTER,0,'0000510104');
           PNL3_PLS002_COGS_TRX_S01(inPeriod,REC1.PROFIT_CENTER,0,'0000510107');
           PNL3_PLS002_COGS_TRX_S01(inPeriod,REC1.PROFIT_CENTER,0,'0000510901');
           PNL3_PLS002_COGS_TRX_S01(inPeriod,REC1.PROFIT_CENTER,0,'0000510902');
           PNL3_PLS002_COGS_TRX_S01(inPeriod,REC1.PROFIT_CENTER,0,'0000510903');
           PNL3_PLS002_COGS_TRX_S01(inPeriod,REC1.PROFIT_CENTER,0,'0000510909');
           PNL3_PLS002_COGS_TRX_S01(inPeriod,REC1.PROFIT_CENTER,0,'0000510999');


           UPDATE PNL3_TRX002_GLACCOUNT
              SET END_CUSTOMER_ID = (SELECT TRIM(END_CUSTOMER_NAME) FROM CEP_MAP009_PARTNO_CUSTOMER
			                          WHERE FG_MATERIAL_NO = Rpad(PNL3_TRX002_GLACCOUNT.PART_NO,18,' ')
			                            AND LAST_MODIFY_DATE <= SYSDATE)
            WHERE PERIOD = inPeriod
              AND PROFIT_CENTER = REC1.PROFIT_CENTER
              AND END_CUSTOMER_ID IS NULL
              AND SOURCE = '2'; --只UPDATE沒有REVENUE的即可,其他的在前一段已UPDATE了
         commit;
         END IF;
   END LOOP;
   

         
   FOR REC2 in C_PNL2_DIRECT Loop
      IF REC2.COST_ELEMENT = '0000510109' THEN
        a_ENDCUSTOMER := 'INTEL';
      ELSE
        a_ENDCUSTOMER := 'SMC';
      END IF;
      
        IF REC2.AMT_LOCAL <> 0 THEN
           INSERT INTO PNL3_TRX002_GLACCOUNT (
               COMPANY_CODE         ,PERIOD            ,PROFIT_CENTER      ,COST_ELEMENT      ,BILL_TO_PARTY,SHIP_TO_PARTY,MTL_GROUP,PART_NO,PLANT_CODE,
               END_CUSTOMER_ID      ,R_KIND            ,AREA1              ,AREA2             ,MTL_TYPE,
               AREA3                ,AMT_LOCAL         ,AMT_TWD            ,AMT_USD           ,
               CREATE_DATE
           ) VALUES(
               REC2.COMPANY_CODE    ,inPeriod          ,REC2.PROFIT_CENTER ,REC2.COST_ELEMENT ,REC2.BILL_TO_PARTY,REC2.SHIP_TO_PARTY,REC2.MTL_GROUP,REC2.PART_NO,REC2.PLANT_CODE,
               a_ENDCUSTOMER        ,'PL01'            ,'1'                  ,'1'                 , REC2.MTL_TYPE,
               '0'                    ,REC2.AMT_LOCAL    , REC2.AMT_TWD      ,REC2.AMT_USD           ,
               SYSDATE
           );
           commit;
        END IF;
        
        IF REC2.COGS_DM_LOCAL <> 0 THEN
           INSERT INTO PNL3_TRX002_GLACCOUNT (
               COMPANY_CODE         ,PERIOD                ,PROFIT_CENTER      ,COST_ELEMENT ,BILL_TO_PARTY,SHIP_TO_PARTY,MTL_GROUP,PART_NO,PLANT_CODE,
               END_CUSTOMER_ID      ,R_KIND                ,AREA1              ,AREA2        ,MTL_TYPE,
               AREA3                ,AMT_LOCAL             ,AMT_TWD            ,AMT_USD      ,
               CREATE_DATE
           ) VALUES(
               REC2.COMPANY_CODE    ,inPeriod              ,REC2.PROFIT_CENTER ,REC2.COST_ELEMENT ,REC2.BILL_TO_PARTY,REC2.SHIP_TO_PARTY,REC2.MTL_GROUP,REC2.PART_NO,REC2.PLANT_CODE,
               a_ENDCUSTOMER        ,'PL01'                ,'2'                 ,'2'                 ,REC2.MTL_TYPE,
               '0'                    ,REC2.COGS_DM_LOCAL    , REC2.COGS_DM_TWD  ,REC2.COGS_DM_USD           ,
               SYSDATE
           );
           commit;
        END IF;
        
        IF REC2.COGS_DL_LOCAL <> 0 THEN
           INSERT INTO PNL3_TRX002_GLACCOUNT (
               COMPANY_CODE         ,PERIOD                ,PROFIT_CENTER      ,COST_ELEMENT ,BILL_TO_PARTY,SHIP_TO_PARTY,MTL_GROUP,PART_NO,PLANT_CODE,
               END_CUSTOMER_ID      ,R_KIND                ,AREA1              ,AREA2        ,MTL_TYPE,
               AREA3                ,AMT_LOCAL             ,AMT_TWD            ,AMT_USD      ,
               CREATE_DATE
           ) VALUES(
               REC2.COMPANY_CODE    ,inPeriod              ,REC2.PROFIT_CENTER ,REC2.COST_ELEMENT ,REC2.BILL_TO_PARTY,REC2.SHIP_TO_PARTY,REC2.MTL_GROUP,REC2.PART_NO,REC2.PLANT_CODE,
               a_ENDCUSTOMER        ,'PL01'                ,'2'                  ,'3'                 ,REC2.MTL_TYPE,
               '0'                    ,REC2.COGS_DL_LOCAL    , REC2.COGS_DL_TWD  ,REC2.COGS_DL_USD           ,
               SYSDATE
           );
           commit;
        END IF;
        
        IF REC2.COGS_OH_LOCAL <> 0 THEN
           INSERT INTO PNL3_TRX002_GLACCOUNT (
               COMPANY_CODE         ,PERIOD       ,PROFIT_CENTER   ,COST_ELEMENT ,BILL_TO_PARTY,SHIP_TO_PARTY,MTL_GROUP,PART_NO,PLANT_CODE,
               END_CUSTOMER_ID      ,R_KIND       ,AREA1           ,AREA2        ,MTL_TYPE,
               AREA3                ,AMT_LOCAL    ,AMT_TWD         ,AMT_USD      ,
               CREATE_DATE
           ) VALUES(
               REC2.COMPANY_CODE    ,inPeriod              ,REC2.PROFIT_CENTER ,REC2.COST_ELEMENT ,REC2.BILL_TO_PARTY,REC2.SHIP_TO_PARTY,REC2.MTL_GROUP,REC2.PART_NO,REC2.PLANT_CODE,
               a_ENDCUSTOMER        ,'PL01'                ,'2'                  ,'4'                 ,REC2.MTL_TYPE,
               '0'                    ,REC2.COGS_OH_LOCAL    , REC2.COGS_OH_TWD  ,REC2.COGS_OH_USD           ,
               SYSDATE
           );
           commit;
        END IF;
   END LOOP;
   
   
   FOR REC2 IN C_PNL3_SZ LOOP
       a_COUNTER := 0;
               FOR REC1 IN (SELECT END_CUSTOMER_ID,RATE 
                           FROM PNL3_MAP001_SITE_RATE 
                          WHERE R_KIND = 'PL01'  --隨便抓一筆來用,反正匯率都一樣
                            AND AREA1  = '4'
                            AND AREA2  = '1'
                            AND AREA3  = '1'
                            AND COMPANY_CODE = REC2.COMPANY_CODE
                            AND PROFIT_CENTER = REC2.PROFIT_CENTER
                            AND PERIOD = inPeriod) LOOP
                            a_RATE := REC1.RATE;
                            a_ENDCUSTOMER := REC1.END_CUSTOMER_ID;
                            a_COUNTER := 1;
                      IF REC2.AMT_LOCAL <> 0 THEN
                        INSERT INTO PNL3_TRX002_GLACCOUNT (
                            COMPANY_CODE         ,PERIOD       ,PROFIT_CENTER   ,COST_ELEMENT , BILL_TO_PARTY, SHIP_TO_PARTY, MTL_GROUP, PART_NO,PLANT_CODE,
                            END_CUSTOMER_ID      ,R_KIND       ,AREA1           ,AREA2        , MTL_TYPE,
                            AREA3                ,AMT_LOCAL    ,AMT_TWD         ,AMT_USD      , 
                            CREATE_DATE          ,SOURCE
                        ) VALUES(
                            REC2.COMPANY_CODE     ,inPeriod     ,REC2.PROFIT_CENTER, REC2.COST_ELEMENT ,REC2.BILL_TO_PARTY, REC2.SHIP_TO_PARTY, REC2.MTL_GROUP, REC2.PART_NO,REC2.PLANT_CODE,
                            a_ENDCUSTOMER  ,'PL01'       ,'1'               ,'1'            ,REC2.MTL_TYPE,
                            '0'                    ,round(REC2.AMT_LOCAL * a_RATE , 5)         ,
                            round(REC2.AMT_TWD * a_RATE , 5)  ,
                            round(REC2.AMT_USD * a_RATE , 5)  , SYSDATE             ,'510301'
                        );
                        commit;
                      END IF;
                      
                      IF REC2.COGS_DM_LOCAL <> 0 THEN
                        INSERT INTO PNL3_TRX002_GLACCOUNT (
                           COMPANY_CODE         ,PERIOD       ,PROFIT_CENTER   ,COST_ELEMENT ,BILL_TO_PARTY, SHIP_TO_PARTY, MTL_GROUP, PART_NO,PLANT_CODE,
                           END_CUSTOMER_ID      ,R_KIND       ,AREA1           ,AREA2        ,MTL_TYPE,
                           AREA3                ,AMT_LOCAL    ,AMT_TWD         ,AMT_USD      , 
                           CREATE_DATE          ,SOURCE
                        ) VALUES(
                           REC2.COMPANY_CODE     ,inPeriod     ,REC2.PROFIT_CENTER, REC2.COST_ELEMENT ,REC2.BILL_TO_PARTY, REC2.SHIP_TO_PARTY, REC2.MTL_GROUP, REC2.PART_NO,REC2.PLANT_CODE,
                           a_ENDCUSTOMER  ,'PL01'       ,'2'               ,'2'            ,REC2.MTL_TYPE,
                           '0'                    ,round(REC2.COGS_DM_LOCAL * a_RATE , 5)         ,
                           round(REC2.COGS_DM_TWD * a_RATE , 5)  ,
                           round(REC2.COGS_DM_USD * a_RATE , 5)  , SYSDATE                  ,'510301'
                        );
                        commit;
                      END IF;
                      
                      IF REC2.COGS_DL_LOCAL <> 0 THEN
                        INSERT INTO PNL3_TRX002_GLACCOUNT (
                            COMPANY_CODE         ,PERIOD       ,PROFIT_CENTER   ,COST_ELEMENT ,BILL_TO_PARTY, SHIP_TO_PARTY, MTL_GROUP, PART_NO,PLANT_CODE,
                            END_CUSTOMER_ID      ,R_KIND       ,AREA1           ,AREA2        ,MTL_TYPE,
                            AREA3                ,AMT_LOCAL    ,AMT_TWD         ,AMT_USD      , 
                            CREATE_DATE          ,SOURCE
                        ) VALUES(
                            REC2.COMPANY_CODE     ,inPeriod     ,REC2.PROFIT_CENTER, REC2.COST_ELEMENT  ,REC2.BILL_TO_PARTY, REC2.SHIP_TO_PARTY, REC2.MTL_GROUP, REC2.PART_NO,REC2.PLANT_CODE,
                            a_ENDCUSTOMER  ,'PL01'       ,'2'               ,'3'            ,REC2.MTL_TYPE,
                            '0'                    ,round(REC2.COGS_DL_LOCAL * a_RATE , 5)         ,
                            round(REC2.COGS_DL_TWD * a_RATE , 5)  ,
                            round(REC2.COGS_DL_USD * a_RATE , 5)  , SYSDATE                  ,'510301'
                        );
                        commit;
                      END IF;
                      
                      IF REC2.COGS_OH_LOCAL <> 0 THEN
                        INSERT INTO PNL3_TRX002_GLACCOUNT (
                            COMPANY_CODE         ,PERIOD       ,PROFIT_CENTER   ,COST_ELEMENT ,BILL_TO_PARTY, SHIP_TO_PARTY, MTL_GROUP, PART_NO,PLANT_CODE,
                            END_CUSTOMER_ID      ,R_KIND       ,AREA1           ,AREA2        ,MTL_TYPE,
                            AREA3                ,AMT_LOCAL    ,AMT_TWD         ,AMT_USD      ,
                            CREATE_DATE          ,SOURCE
                        ) VALUES(
                            REC2.COMPANY_CODE     ,inPeriod     ,REC2.PROFIT_CENTER, REC2.COST_ELEMENT  ,REC2.BILL_TO_PARTY, REC2.SHIP_TO_PARTY, REC2.MTL_GROUP, REC2.PART_NO,REC2.PLANT_CODE,
                            a_ENDCUSTOMER  ,'PL01'       ,'2'               ,'4'            , REC2.MTL_TYPE,
                            '0'                    ,round(REC2.COGS_OH_LOCAL * a_RATE , 5)         ,
                            round(REC2.COGS_OH_TWD * a_RATE , 5)  ,
                            round(REC2.COGS_OH_USD * a_RATE , 5)  , SYSDATE                  ,'510301'
                        );
                        commit;
                      END IF;
               
               END LOOP;
               
       IF a_COUNTER = 0 THEN
              FOR REC1 IN (SELECT END_CUSTOMER_ID,RATE 
                           --FROM PNL3_MAP001_GLOBAL_CUST_RATE 
                           FROM PNL3_MAP001_CUSTOMER_RATE
                          WHERE R_KIND = 'PL01'  --隨便抓一筆來用,反正匯率都一樣
                            AND AREA1  = '4'
                            AND AREA2  = '1'
                            AND AREA3  = '1'
                          --AND COMPANY_CODE = REC1.COMPANY_CODE
                            AND PROFIT_CENTER = REC2.PROFIT_CENTER
                            AND PERIOD = inPeriod) LOOP
                            a_RATE := REC1.RATE;
                            a_ENDCUSTOMER := REC1.END_CUSTOMER_ID;
                      IF REC2.AMT_LOCAL <> 0 THEN
                        INSERT INTO PNL3_TRX002_GLACCOUNT (
                            COMPANY_CODE         ,PERIOD       ,PROFIT_CENTER   ,COST_ELEMENT , BILL_TO_PARTY, SHIP_TO_PARTY, MTL_GROUP, PART_NO,PLANT_CODE,
                            END_CUSTOMER_ID      ,R_KIND       ,AREA1           ,AREA2        , MTL_TYPE,
                            AREA3                ,AMT_LOCAL    ,AMT_TWD         ,AMT_USD      , 
                            CREATE_DATE          ,SOURCE
                        ) VALUES(
                            REC2.COMPANY_CODE     ,inPeriod     ,REC2.PROFIT_CENTER, REC2.COST_ELEMENT ,REC2.BILL_TO_PARTY, REC2.SHIP_TO_PARTY, REC2.MTL_GROUP, REC2.PART_NO,REC2.PLANT_CODE,
                            a_ENDCUSTOMER  ,'PL01'       ,'1'               ,'1'            ,REC2.MTL_TYPE,
                            '0'                    ,round(REC2.AMT_LOCAL * a_RATE , 5)         ,
                            round(REC2.AMT_TWD * a_RATE , 5)  ,
                            round(REC2.AMT_USD * a_RATE , 5)  , SYSDATE             ,'510301'
                        );
                        commit;
                      END IF;
                      
                      IF REC2.COGS_DM_LOCAL <> 0 THEN
                        INSERT INTO PNL3_TRX002_GLACCOUNT (
                           COMPANY_CODE         ,PERIOD       ,PROFIT_CENTER   ,COST_ELEMENT ,BILL_TO_PARTY, SHIP_TO_PARTY, MTL_GROUP, PART_NO,PLANT_CODE,
                           END_CUSTOMER_ID      ,R_KIND       ,AREA1           ,AREA2        ,MTL_TYPE,
                           AREA3                ,AMT_LOCAL    ,AMT_TWD         ,AMT_USD      , 
                           CREATE_DATE          ,SOURCE
                        ) VALUES(
                           REC2.COMPANY_CODE     ,inPeriod     ,REC2.PROFIT_CENTER, REC2.COST_ELEMENT ,REC2.BILL_TO_PARTY, REC2.SHIP_TO_PARTY, REC2.MTL_GROUP, REC2.PART_NO,REC2.PLANT_CODE,
                           a_ENDCUSTOMER  ,'PL01'       ,'2'               ,'2'            ,REC2.MTL_TYPE,
                           '0'                    ,round(REC2.COGS_DM_LOCAL * a_RATE , 5)         ,
                           round(REC2.COGS_DM_TWD * a_RATE , 5)  ,
                           round(REC2.COGS_DM_USD * a_RATE , 5)  , SYSDATE                  ,'510301'
                        );
                        commit;
                      END IF;
                      
                      IF REC2.COGS_DL_LOCAL <> 0 THEN
                        INSERT INTO PNL3_TRX002_GLACCOUNT (
                            COMPANY_CODE         ,PERIOD       ,PROFIT_CENTER   ,COST_ELEMENT ,BILL_TO_PARTY, SHIP_TO_PARTY, MTL_GROUP, PART_NO,PLANT_CODE,
                            END_CUSTOMER_ID      ,R_KIND       ,AREA1           ,AREA2        ,MTL_TYPE,
                            AREA3                ,AMT_LOCAL    ,AMT_TWD         ,AMT_USD      , 
                            CREATE_DATE          ,SOURCE
                        ) VALUES(
                            REC2.COMPANY_CODE     ,inPeriod     ,REC2.PROFIT_CENTER, REC2.COST_ELEMENT  ,REC2.BILL_TO_PARTY, REC2.SHIP_TO_PARTY, REC2.MTL_GROUP, REC2.PART_NO,REC2.PLANT_CODE,
                            a_ENDCUSTOMER  ,'PL01'       ,'2'               ,'3'            ,REC2.MTL_TYPE,
                            '0'                    ,round(REC2.COGS_DL_LOCAL * a_RATE , 5)         ,
                            round(REC2.COGS_DL_TWD * a_RATE , 5)  ,
                            round(REC2.COGS_DL_USD * a_RATE , 5)  , SYSDATE                  ,'510301'
                        );
                        commit;
                      END IF;
                      
                      IF REC2.COGS_OH_LOCAL <> 0 THEN
                        INSERT INTO PNL3_TRX002_GLACCOUNT (
                            COMPANY_CODE         ,PERIOD       ,PROFIT_CENTER   ,COST_ELEMENT ,BILL_TO_PARTY, SHIP_TO_PARTY, MTL_GROUP, PART_NO,PLANT_CODE,
                            END_CUSTOMER_ID      ,R_KIND       ,AREA1           ,AREA2        ,MTL_TYPE,
                            AREA3                ,AMT_LOCAL    ,AMT_TWD         ,AMT_USD      ,
                            CREATE_DATE          ,SOURCE
                        ) VALUES(
                            REC2.COMPANY_CODE     ,inPeriod     ,REC2.PROFIT_CENTER, REC2.COST_ELEMENT  ,REC2.BILL_TO_PARTY, REC2.SHIP_TO_PARTY, REC2.MTL_GROUP, REC2.PART_NO,REC2.PLANT_CODE,
                            a_ENDCUSTOMER  ,'PL01'       ,'2'               ,'4'            , REC2.MTL_TYPE,
                            '0'                    ,round(REC2.COGS_OH_LOCAL * a_RATE , 5)         ,
                            round(REC2.COGS_OH_TWD * a_RATE , 5)  ,
                            round(REC2.COGS_OH_USD * a_RATE , 5)  , SYSDATE                  ,'510301'
                        );
                        commit;
                      END IF;
               
               END LOOP;

  
           
        
       END IF;
   END LOOP;
   
   DELETE PNL3_TRX002_GLACCOUNT_T 
     WHERE PERIOD = inPeriod;
     commit;
     
       UPDATE PNL3_TRX002_GLACCOUNT
      SET project_name =
             (SELECT DISTINCT TRIM (sap_project_name)
                         FROM cep_map010_partno_project
                        WHERE fg_material_no =
                                      RPAD (PNL3_TRX002_GLACCOUNT.part_no, 18, ' '))
    WHERE period = inperiod;

   commit;
   
   UPDATE PNL3_TRX002_GLACCOUNT
      SET project_TYPE =
             (SELECT DISTINCT TRIM (PROJECT_TYPE)
                         FROM CEP_WEB002_PROJECT
                        WHERE PROJECT_NAME = PNL3_TRX002_GLACCOUNT.PROJECT_NAME)
                                      --RPAD (PNL3_TRX002_GLACCOUNT.PROJECT_NAME, 30, ' '))
    WHERE period = inperiod;

   commit;
     
   /*
   
  DELETE FROM PNL3_TRX001_COPA
   WHERE Period = inPeriod 
     and SOURCE = 'GLACCOUNT';
   Commit;
   
   --包含'0000510101','0000510103','0000510104','0000510107',,'0000510901','0000510902','0000510903','0000510909','0000510999'
   FOR REC1 in (SELECT COMPANY_CODE,PERIOD,PROFIT_CENTER,END_CUSTOMER_ID,R_KIND,AREA1,AREA2,AREA3,BILL_TO_PARTY,SHIP_TO_PARTY,MTL_GROUP,PART_NO,
                       SUM(AMT_LOCAL) AMT_LOCAL,SUM(AMT_USD) AMT_USD,SUM(AMT_TWD) AMT_TWD
                  FROM PNL3_TRX002_GLACCOUNT
                 WHERE  PERIOD = inPeriod 
              GROUP BY COMPANY_CODE,PERIOD,PROFIT_CENTER,END_CUSTOMER_ID,R_KIND,AREA1,AREA2,AREA3,BILL_TO_PARTY,SHIP_TO_PARTY,MTL_GROUP,PART_NO) Loop

         Insert into PNL3_TRX001_COPA (
                COMPANY_CODE    , PERIOD         , PROFIT_CENTER      , END_CUSTOMER_ID ,BILL_TO_PARTY,SHIP_TO_PARTY,MTL_GROUP,PART_NO,
                AMT_LOCAL      , AMT_USD            , AMT_TWD         , SOURCE          ,
                R_KIND          , AREA1          ,AREA2               , AREA3           ,
                CREATE_DATE
                      ) VALUES (
                        REC1.COMPANY_CODE       , REC1.PERIOD       , REC1.PROFIT_CENTER      , REC1.END_CUSTOMER_ID ,REC1.BILL_TO_PARTY,REC1.SHIP_TO_PARTY,REC1.MTL_GROUP,REC1.PART_NO,
                        REC1.AMT_LOCAL          , REC1.AMT_USD      , REC1.AMT_TWD            , 'GLACCOUNT'          ,
                        REC1.R_KIND             , REC1.AREA1        , REC1.AREA2              , REC1.AREA3           ,
                        SYSDATE );
          Commit;
   END LOOP;
   */
    
END PNL3_PLS002_COGS_TRX;
/

