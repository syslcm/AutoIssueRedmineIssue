create PROCEDURE PLSQL_SAP_ZBPRD466(
  inCompany  in SAP_ZBPRD466_DATA.COMPANY_CODE%TYPE,
  f_YYYYMMDD in VARCHAR2,
  t_YYYYMMDD in VARCHAR2
)
is
 iTracePoint  integer ;
 cErrorText varchar2(500);
 vPROCEE_YYYYMMDD varchar2(8);

BEGIN
  iTracePoint := '000';


  --vPROCEE_YYYYMMDD  :=  to_char(sysdate-1,'YYYYMMDD');

  DELETE FROM SAP_ZBPRD466_DATA WHERE COMPANY_CODE =inCompany;

  iTracePoint := '100';
  Insert into SAP_ZBPRD466_DATA (
        COMPANY_CODE , FG_PN, PART_NO , CHANGE_DATE )
   Select  COMPANY_CODE , FG_PN, PART_NO , CHANGE_DATE
     from SAP_ZBPRD466_DATA_T
    where COMPANY_CODE= inCompany;

   iTracePoint := '200';
   DELETE  from SAP_ZBPRD466_DATA_T
    where COMPANY_CODE = inCompany;



   Commit;
EXCEPTION
   When OTHERS Then
    --有錯誤產生則寄mail
    cErrorText := SQLERRM();
    MAIL_FILE_BIDBDBADMIN(in_to_name => 'sam_chen@ms.usi.com.tw', subject => '[VRT] PL/SQL SAP_ZBPRD466_DATA', message => '[SAP_ZBPRD466_DATA], The tracepoint is  ' || iTracePoint || ' and ErrorText= ' || cErrorText) ;


END PLSQL_SAP_ZBPRD466;
/

