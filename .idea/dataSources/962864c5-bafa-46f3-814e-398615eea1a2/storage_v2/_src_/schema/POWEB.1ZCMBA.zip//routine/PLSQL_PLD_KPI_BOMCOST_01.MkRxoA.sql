create PROCEDURE PLSQL_PLD_KPI_BOMCOST_01 (
  inYYYYMM in VARCHAR2,
  inYYYYMM_fr in VARCHAR2
)
AUTHID DEFINER
is
  --處理 PLD_KPI_BOMCOST_ACTUAL
  CURSOR C_PLD_KPI_BOMCOST_ACTUAL_TMP is
    Select YYYYMM, COMPANY_CODE, PROFIT_CENTER, MTL_GROUP,
           SUM(C_AMT_USD) as C_AMT_USD, SUM(P_AMT_USD) as P_AMT_USD, SUM(QTY) as QTY
      from PLD_KPI_BOMCOST_ACTUAL_TMP
     Where YYYYMM = inYYYYMM
       and C_AMT_USD <> 0 and P_AMT_USD <> 0
     Group by YYYYMM, COMPANY_CODE, PROFIT_CENTER, MTL_GROUP;

  CURSOR C_PLD_KPI_BOMCOST_ACTUAL_TMP1 is
    Select A.YYYYMM, A.COMPANY_CODE, A.PROFIT_CENTER, A.MTL_GROUP,
           SUM(A.C_AMT_USD) as C_AMT_USD, SUM(A.P_AMT_USD) as P_AMT_USD
      from PLD_KPI_BOMCOST_ACTUAL_TMP A
     Where A.YYYYMM = inYYYYMM
       and A.C_AMT_USD <> 0 and A.P_AMT_USD <> 0
       and Exists (
             Select B.COMPONENT_NO from PLD_KPI_BG_KEY_PART B
              where B.COMPONENT_NO is NOT NULL
                and B.COMPONENT_NO = A.PART_NO
           )
     Group by A.YYYYMM, A.COMPANY_CODE, A.PROFIT_CENTER, A.MTL_GROUP;

  CURSOR C_PLD_KPI_BOMCOST_ACTUAL_TMP2 is
    Select A.YYYYMM, A.COMPANY_CODE, A.PROFIT_CENTER, A.MTL_GROUP,
           SUM(A.C_AMT_USD) as C_AMT_USD, SUM(A.P_AMT_USD) as P_AMT_USD
      from PLD_KPI_BOMCOST_ACTUAL_TMP A
     Where A.YYYYMM = inYYYYMM
       and A.C_AMT_USD <> 0 and A.P_AMT_USD <> 0
       and Exists (
             Select B.PART_NO from PLD_KPI_BOMCOST_CONSIGN_PART B
              where B.PART_NO is NOT NULL
                and B.PART_NO = A.PART_NO
                and B.PART_NO not in (
                  Select C.COMPONENT_NO from PLD_KPI_BG_KEY_PART C
                )
           )
     Group by A.YYYYMM, A.COMPANY_CODE, A.PROFIT_CENTER, A.MTL_GROUP;

  --處理 PLD_KPI_BOMCOST_FCST
  CURSOR C_PLD_KPI_BOMCOST_FCST_TMP is
    Select YYYYMM, COMPANY_CODE, PROFIT_CENTER, MTL_GROUP,
           SUM(C_AMT_USD) as C_AMT_USD, SUM(P_AMT_USD) as P_AMT_USD, SUM(QTY) as QTY
      from PLD_KPI_BOMCOST_FCST_TMP
     Where YYYYMM = inYYYYMM
       and C_AMT_USD <> 0 and P_AMT_USD <> 0
     Group by YYYYMM, COMPANY_CODE, PROFIT_CENTER, MTL_GROUP;

  CURSOR C_PLD_KPI_BOMCOST_FCST_TMP1 is
    Select A.YYYYMM, A.COMPANY_CODE, A.PROFIT_CENTER, A.MTL_GROUP,
           SUM(A.C_AMT_USD) as C_AMT_USD, SUM(A.P_AMT_USD) as P_AMT_USD
      from PLD_KPI_BOMCOST_FCST_TMP A
     Where A.YYYYMM = inYYYYMM
       and A.C_AMT_USD <> 0 and A.P_AMT_USD <> 0
       and Exists (
             Select B.COMPONENT_NO from PLD_KPI_BG_KEY_PART B
              where B.COMPONENT_NO is NOT NULL
                and B.COMPONENT_NO = A.PART_NO
           )
     Group by A.YYYYMM, A.COMPANY_CODE, A.PROFIT_CENTER, A.MTL_GROUP;

  CURSOR C_PLD_KPI_BOMCOST_FCST_TMP2 is
    Select A.YYYYMM, A.COMPANY_CODE, A.PROFIT_CENTER, A.MTL_GROUP,
           SUM(A.C_AMT_USD) as C_AMT_USD, SUM(A.P_AMT_USD) as P_AMT_USD
      from PLD_KPI_BOMCOST_FCST_TMP A
     Where A.YYYYMM = inYYYYMM
       and A.C_AMT_USD <> 0 and A.P_AMT_USD <> 0
       and Exists (
             Select B.PART_NO from PLD_KPI_BOMCOST_CONSIGN_PART B
              where B.PART_NO is NOT NULL
                and B.PART_NO = A.PART_NO
                and B.PART_NO not in (
                  Select C.COMPONENT_NO from PLD_KPI_BG_KEY_PART C
                )
           )
     Group by A.YYYYMM, A.COMPANY_CODE, A.PROFIT_CENTER, A.MTL_GROUP;

   nCOUNT              NUMBER(5);
   nBeDATE             VARCHAR2(8);
   nBE_USD_TWD         EGI0020_EXCHANGE_RATE.EXCHANGE_RATE%TYPE;
   nExchDATE           VARCHAR2(8);
   nER_USD_TWD         EGI0020_EXCHANGE_RATE.EXCHANGE_RATE%TYPE;
   nC_AMT_TWD          PLD_KPI_BOMCOST_ACTUAL.C_AMT_TWD%TYPE;
   nP_AMT_TWD          PLD_KPI_BOMCOST_ACTUAL.P_AMT_TWD%TYPE;
   nOverYYMM           VARCHAR2(6);

 BEGIN
   --計算begin date / 匯率 USD -> TWD
   If SUBSTR(inYYYYMM,5,2) in ('01','02','03') Then
     nBeDATE := SUBSTR(inYYYYMM,1,4) || '0101';
   ElsIf SUBSTR(inYYYYMM,3,2) in ('01','02','03') Then
     nBeDATE := SUBSTR(inYYYYMM,1,4) || '0401';
   ElsIf SUBSTR(inYYYYMM,3,2) in ('01','02','03') Then
     nBeDATE := SUBSTR(inYYYYMM,1,4) || '0701';
   Else
     nBeDATE := SUBSTR(inYYYYMM,1,4) || '1001';
   End If;
   nBE_USD_TWD := Null;
   Select * into nBE_USD_TWD From (
     Select EXCHANGE_RATE from EGI0020_EXCHANGE_RATE
      where (VALID_FROM_DATEYYMM || VALID_FROM_DATEDD) <= nBeDATE
        and TRIM(FROM_CURRENCY) = 'USD'
        and TRIM(TO_CURRENCY) = 'TWD'
      order by (VALID_FROM_DATEYYMM || VALID_FROM_DATEDD) Desc
   ) Where ROWNUM <= 1;

   --抓end date匯率 USD -> TWD
   nExchDATE := Null;
   nER_USD_TWD := Null;
   Select * into nExchDATE From (
     Select TO_CHAR(LAST_DAY(TO_DATE(inYYYYMM || '01','YYYYMMDD')),'YYYYMMDD')
       from DUAL
   ) Where ROWNUM <= 1;

   Select * into nER_USD_TWD From (
     Select EXCHANGE_RATE from EGI0020_EXCHANGE_RATE
      where (VALID_FROM_DATEYYMM || VALID_FROM_DATEDD) <= nExchDATE
        and TRIM(FROM_CURRENCY) = 'USD'
        and TRIM(TO_CURRENCY) = 'TWD'
      order by (VALID_FROM_DATEYYMM || VALID_FROM_DATEDD) Desc
   ) Where ROWNUM <= 1;

   --PLD_KPI_BOMCOST_ACTUAL--
   --Delete PLD_KPI_BOMCOST_ACTUAL 避免重複
   Delete From PLD_KPI_BOMCOST_ACTUAL
         Where SUBSTR(DATE_KEY,1,6) = inYYYYMM;
   Commit;

   --處理 PLD_KPI_BOMCOST_ACTUAL_TMP
   nCOUNT := 0;
   FOR REC1 in C_PLD_KPI_BOMCOST_ACTUAL_TMP LOOP
     nC_AMT_TWD := ROUND(REC1.C_AMT_USD * nER_USD_TWD, 5);
     nP_AMT_TWD := ROUND(REC1.P_AMT_USD * nER_USD_TWD, 5);
     Insert into PLD_KPI_BOMCOST_ACTUAL (
            DATE_KEY, COMPANY_CODE, PROFIT_CENTER, MTL_GROUP, C_AMT_USD, P_AMT_USD, C_AMT_TWD, P_AMT_TWD, QTY
          ) values (
            nExchDATE,
            REC1.COMPANY_CODE,
            REC1.PROFIT_CENTER,
            REC1.MTL_GROUP,
            REC1.C_AMT_USD,
            REC1.P_AMT_USD,
            nC_AMT_TWD,
            nP_AMT_TWD,
            REC1.QTY
          );
     nCOUNT := nCOUNT + 1;
     If nCOUNT = 50 Then
       Commit;
       nCOUNT := 0;
     End If;
   END LOOP;
   Commit;

   nCOUNT := 0;
   FOR REC1 in C_PLD_KPI_BOMCOST_ACTUAL_TMP1 LOOP
     Update PLD_KPI_BOMCOST_ACTUAL
        set C_BG_USD = REC1.C_AMT_USD,
            P_BG_USD = REC1.P_AMT_USD
      where DATE_KEY = nExchDATE
        and COMPANY_CODE = REC1.COMPANY_CODE
        and PROFIT_CENTER = REC1.PROFIT_CENTER
        and MTL_GROUP = REC1.MTL_GROUP;
     nCOUNT := nCOUNT + 1;
     If nCOUNT = 5 Then
       Commit;
       nCOUNT := 0;
     End If;
   END LOOP;
   Commit;

   nCOUNT := 0;
   FOR REC1 in C_PLD_KPI_BOMCOST_ACTUAL_TMP2 LOOP
     nC_AMT_TWD := ROUND(REC1.C_AMT_USD * nER_USD_TWD, 5);
     nP_AMT_TWD := ROUND(REC1.P_AMT_USD * nER_USD_TWD, 5);
     Update PLD_KPI_BOMCOST_ACTUAL
        set C_YC_USD = REC1.C_AMT_USD,
            P_YC_USD = REC1.P_AMT_USD,
            C_YC_TWD = nC_AMT_TWD,
            P_YC_TWD = nP_AMT_TWD
      where DATE_KEY = nExchDATE
        and COMPANY_CODE = REC1.COMPANY_CODE
        and PROFIT_CENTER = REC1.PROFIT_CENTER
        and MTL_GROUP = REC1.MTL_GROUP;
     nCOUNT := nCOUNT + 1;
     If nCOUNT = 5 Then
       Commit;
       nCOUNT := 0;
     End If;
   END LOOP;
   Commit;

   Update PLD_KPI_BOMCOST_ACTUAL set
      C_BG_USD = nvl(C_BG_USD,0),
      P_BG_USD = nvl(P_BG_USD,0),
      C_YC_USD = nvl(C_YC_USD,0),
      P_YC_USD = nvl(P_YC_USD,0),
      C_YC_TWD = nvl(C_YC_TWD,0),
      P_YC_TWD = nvl(P_YC_TWD,0)
    where DATE_KEY = nExchDATE;
   Commit;

   -------------------------------------------------------------
   --PLD_KPI_BOMCOST_FCST--
   --Delete PLD_KPI_BOMCOST_FCST 避免重複
   Delete From PLD_KPI_BOMCOST_FCST
         Where SUBSTR(DATE_KEY,1,6) = inYYYYMM;
   Commit;

   --處理 PLD_KPI_BOMCOST_FCST_TMP
   nCOUNT := 0;
   FOR REC1 in C_PLD_KPI_BOMCOST_FCST_TMP LOOP
     nC_AMT_TWD := ROUND(REC1.C_AMT_USD * nER_USD_TWD, 5);
     nP_AMT_TWD := ROUND(REC1.P_AMT_USD * nER_USD_TWD, 5);
     Insert into PLD_KPI_BOMCOST_FCST (
            DATE_KEY, COMPANY_CODE, PROFIT_CENTER, MTL_GROUP, C_AMT_USD, P_AMT_USD, C_AMT_TWD, P_AMT_TWD, QTY
          ) values (
            nExchDATE,
            REC1.COMPANY_CODE,
            REC1.PROFIT_CENTER,
            REC1.MTL_GROUP,
            REC1.C_AMT_USD,
            REC1.P_AMT_USD,
            nC_AMT_TWD,
            nP_AMT_TWD,
            REC1.QTY
          );
     nCOUNT := nCOUNT + 1;
     If nCOUNT = 50 Then
       Commit;
       nCOUNT := 0;
     End If;
   END LOOP;
   Commit;

   nCOUNT := 0;
   FOR REC1 in C_PLD_KPI_BOMCOST_FCST_TMP1 LOOP
     Update PLD_KPI_BOMCOST_FCST
        set C_BG_USD = REC1.C_AMT_USD,
            P_BG_USD = REC1.P_AMT_USD
      where DATE_KEY = nExchDATE
        and COMPANY_CODE = REC1.COMPANY_CODE
        and PROFIT_CENTER = REC1.PROFIT_CENTER
        and MTL_GROUP = REC1.MTL_GROUP;
     nCOUNT := nCOUNT + 1;
     If nCOUNT = 5 Then
       Commit;
       nCOUNT := 0;
     End If;
   END LOOP;
   Commit;

   nCOUNT := 0;
   FOR REC1 in C_PLD_KPI_BOMCOST_FCST_TMP2 LOOP
     nC_AMT_TWD := ROUND(REC1.C_AMT_USD * nER_USD_TWD, 5);
     nP_AMT_TWD := ROUND(REC1.P_AMT_USD * nER_USD_TWD, 5);
     Update PLD_KPI_BOMCOST_FCST
        set C_YC_USD = REC1.C_AMT_USD,
            P_YC_USD = REC1.P_AMT_USD,
            C_YC_TWD = nC_AMT_TWD,
            P_YC_TWD = nP_AMT_TWD
      where DATE_KEY = nExchDATE
        and COMPANY_CODE = REC1.COMPANY_CODE
        and PROFIT_CENTER = REC1.PROFIT_CENTER
        and MTL_GROUP = REC1.MTL_GROUP;
     nCOUNT := nCOUNT + 1;
     If nCOUNT = 5 Then
       Commit;
       nCOUNT := 0;
     End If;
   END LOOP;
   Commit;

   Update PLD_KPI_BOMCOST_FCST set
      C_BG_USD = nvl(C_BG_USD,0),
      P_BG_USD = nvl(P_BG_USD,0),
      C_YC_USD = nvl(C_YC_USD,0),
      P_YC_USD = nvl(P_YC_USD,0),
      C_YC_TWD = nvl(C_YC_TWD,0),
      P_YC_TWD = nvl(P_YC_TWD,0)
    where DATE_KEY = nExchDATE;
   Commit;

   -------------------------------------------------------------
   --PLD_KPI_BOMCOST_PRICE_CURR / PLD_KPI_BOMCOST_PRICE_PREV--
   Delete from PLD_KPI_BOMCOST_ACTUAL_TMP
    Where YYYYMM = inYYYYMM
      and ( C_AMT_USD = 0 or P_AMT_USD = 0 );
   Commit;

   Delete from PLD_KPI_BOMCOST_FCST_TMP
    Where YYYYMM = inYYYYMM
      and ( C_AMT_USD = 0 or P_AMT_USD = 0 );
   Commit;

   Delete from PLD_KPI_BOMCOST_PRICE_CURR
    Where YYYYMM = inYYYYMM
      and PRICE_USD = 0;
   Commit;

   Delete from PLD_KPI_BOMCOST_PRICE_PREV
    Where YYYYMM = inYYYYMM
      and PRICE_USD = 0;
   Commit;

   Update PLD_KPI_BOMCOST_ACTUAL_TMP set CONSIGN = 'B'
    Where YYYYMM = inYYYYMM
      and PART_NO in (
          Select C.COMPONENT_NO from PLD_KPI_BG_KEY_PART C
           where C.COMPONENT_NO is NOT NULL );
   Commit;

   Update PLD_KPI_BOMCOST_ACTUAL_TMP set CONSIGN = 'Y'
    Where YYYYMM = inYYYYMM
      and PART_NO in (
          Select B.PART_NO from PLD_KPI_BOMCOST_CONSIGN_PART B
           where B.PART_NO is NOT NULL )
      and PART_NO not in (
          Select C.COMPONENT_NO from PLD_KPI_BG_KEY_PART C
           where C.COMPONENT_NO is NOT NULL );
   Commit;

   Update PLD_KPI_BOMCOST_FCST_TMP set CONSIGN = 'B'
    Where YYYYMM = inYYYYMM
      and PART_NO in (
          Select C.COMPONENT_NO from PLD_KPI_BG_KEY_PART C
           where C.COMPONENT_NO is NOT NULL );
   Commit;

   Update PLD_KPI_BOMCOST_FCST_TMP set CONSIGN = 'Y'
    Where YYYYMM = inYYYYMM
      and PART_NO in (
          Select B.PART_NO from PLD_KPI_BOMCOST_CONSIGN_PART B
           where B.PART_NO is NOT NULL )
      and PART_NO not in (
          Select C.COMPONENT_NO from PLD_KPI_BG_KEY_PART C
           where C.COMPONENT_NO is NOT NULL );
   Commit;

   Update PLD_KPI_BOMCOST_PRICE_CURR set CONSIGN = 'B'
    Where YYYYMM = inYYYYMM
      and PART_NO in (
          Select C.COMPONENT_NO from PLD_KPI_BG_KEY_PART C
           where C.COMPONENT_NO is NOT NULL );
   Commit;

   Update PLD_KPI_BOMCOST_PRICE_CURR set CONSIGN = 'Y'
    Where YYYYMM = inYYYYMM
      and PART_NO in (
          Select B.PART_NO from PLD_KPI_BOMCOST_CONSIGN_PART B
           where B.PART_NO is NOT NULL )
      and PART_NO not in (
          Select C.COMPONENT_NO from PLD_KPI_BG_KEY_PART C
           where C.COMPONENT_NO is NOT NULL );
   Commit;

   Update PLD_KPI_BOMCOST_PRICE_PREV set CONSIGN = 'B'
    Where YYYYMM = inYYYYMM
      and PART_NO in (
          Select C.COMPONENT_NO from PLD_KPI_BG_KEY_PART C
           where C.COMPONENT_NO is NOT NULL );
   Commit;

   Update PLD_KPI_BOMCOST_PRICE_PREV set CONSIGN = 'Y'
    Where YYYYMM = inYYYYMM
      and PART_NO in (
          Select B.PART_NO from PLD_KPI_BOMCOST_CONSIGN_PART B
           where B.PART_NO is NOT NULL )
      and PART_NO not in (
          Select C.COMPONENT_NO from PLD_KPI_BG_KEY_PART C
           where C.COMPONENT_NO is NOT NULL );
   Commit;

   -------------------------------------------------------------
   --清除超過三年的資料--
   If inYYYYMM_fr = inYYYYMM Then
     nOverYYMM := TO_CHAR(TO_NUMBER(SUBSTRB(inYYYYMM,1,4)) - 3) || SUBSTRB(inYYYYMM,5,2);
     Delete from PLD_KPI_BOMCOST_ACTUAL where SUBSTRB(DATE_KEY,1,6) < nOverYYMM;
     Commit;
     Delete from PLD_KPI_BOMCOST_ACTUAL_TMP where YYYYMM < nOverYYMM;
     Commit;
     Delete from PLD_KPI_BOMCOST_FCST where SUBSTRB(DATE_KEY,1,6) < nOverYYMM;
     Commit;
     Delete from PLD_KPI_BOMCOST_FCST_TMP where YYYYMM < nOverYYMM;
     Commit;
     Delete from PLD_KPI_BOMCOST_PRICE_CURR where YYYYMM < nOverYYMM;
     Commit;
     Delete from PLD_KPI_BOMCOST_PRICE_PREV where YYYYMM < nOverYYMM;
     Commit;
   End If;

 END PLSQL_PLD_KPI_BOMCOST_01;
/

