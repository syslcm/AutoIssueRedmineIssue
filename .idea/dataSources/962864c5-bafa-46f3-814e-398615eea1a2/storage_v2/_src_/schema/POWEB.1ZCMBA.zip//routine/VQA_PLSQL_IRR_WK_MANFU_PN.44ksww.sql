create PROCEDURE         "VQA_PLSQL_IRR_WK_MANFU_PN" (
 inCompany  in VQA_050_IRR_WEEKLY_MANFU_PN_T.COMPANY_CODE%TYPE,
 f_YYYYMMDD in VARCHAR2,
 t_YYYYMMDD in VARCHAR2
)
IS
      /*--------------------------------------------------------------*
         CREATE DATE:  2008/01/26
         PLSQL      :  VQA_050_IRR_WEEKLY_MANFU_PN
         Author     :  Susan Lin
         Purpase    :  IRR RATE-Manfu(By 每週執行一次)
                       TW/SZ/SH/MX
      *---------------------------------------------------------------*
      */


 vCompany_code VQA_050_IRR_WEEKLY_MANFU_PN_T.Company_code%TYPE;
 vPROCEE_YYYYMMDD varchar2(8);
 vPROCEE_YYYYMM   varchar2(6);
 iTracePoint      varchar2(100);
 cErrorText       varchar2(500);

BEGIN

 --抓當月份系統日期
  iTracePoint := '100';
  vPROCEE_YYYYMMDD  :=  to_char(sysdate,'YYYYMMDD');
  vPROCEE_YYYYMM :=  SUBSTRB(vPROCEE_YYYYMMDD,1,6);

  for REC1 in ( select COMPANY_CODE, YYYY, MM, WEEK, MANUF, PART_NO, PTYPE, MATGROUP, REJECT_LOT_CNT, LOT_CNT, PERCENTAGE, DATE_TIME
                 from VQA_050_IRR_WEEKLY_MANFU_PN_T
                 where COMPANY_CODE = inCompany
                   and WEEK in (Select substrb(yyyyww,5,2) from DIMENSION_DATE Where date_key = to_char( sysdate - 7, 'yyyymmdd'))
                       ) loop
    if REC1.COMPANY_CODE is not null then
      iTracePoint := '110';
      vCompany_code := REC1.Company_code;
    end if;
  end loop;

 if vCOMPANY_CODE is null then
   --若沒抓到資料則寄 error mail
   iTracePoint := '120';
   cErrorText := 'No data!';
   MAIL_FILE_BIDBDBADMIN(in_to_name => 'shuchin_lin@usiglobal.com', subject => '[VQA] PL/SQL VQA_PLSQL_IRR_WK_MANFU_PN ERROR', message => '[VQA_010_IRR_WEEKLY_T], The tracepoint is  ' || iTracePoint || ' and ErrorText= ' || cErrorText) ;
 else


   iTracePoint := '200';
   Insert into VQA_050_IRR_WEEKLY_MANFU_PN (
                    COMPANY_CODE, YYYY, MM, WEEK, MANUF, PART_NO, PTYPE, MATGROUP, REJECT_LOT_CNT, LOT_CNT, PERCENTAGE, DATE_TIME, YYYYWW )
       Select COMPANY_CODE, YYYY, MM, WEEK, MANUF, PART_NO, PTYPE, MATGROUP, REJECT_LOT_CNT, LOT_CNT, PERCENTAGE, DATE_TIME, YYYY || WEEK
              from VQA_050_IRR_WEEKLY_MANFU_PN_T
              where COMPANY_CODE = inCompany
                and WEEK in (Select substrb(yyyyww,5,2) from DIMENSION_DATE Where date_key = to_char( sysdate - 7, 'yyyymmdd'));

    --清除重覆資料
    iTracePoint := '300';
    DELETE from VQA_050_IRR_WEEKLY_MANFU_PN_T
           where COMPANY_CODE = inCompany
             and WEEK in (Select substrb(yyyyww,5,2) from DIMENSION_DATE Where date_key = to_char( sysdate - 7, 'yyyymmdd'));
    Commit;


    -- 計算IRR WW 週資料
    if inCompany = '2300' then
       VQA_PLSQL_IRR_WK_MANFU_PN_WW;
	-- 計算STS WW 週資料
       VQA_PLSQL_STS_WK_MANFU_PN_WW;
    end if;



 end if;





EXCEPTION
   When OTHERS Then
    --有錯誤產生則寄mail
    cErrorText := SQLERRM();
    MAIL_FILE_BIDBDBADMIN(in_to_name => 'shuchin_lin@usiglobal.com', subject => '[VQA] PL/SQL VQA_PLSQL_IRR_WK_MANFU_PN ERROR', message => '[VQA_050_IRR_WEEKLY_MANFU_PN], The tracepoint is  ' || iTracePoint || ' and ErrorText= ' || cErrorText) ;

END VQA_PLSQL_IRR_WK_MANFU_PN;
/

