create PROCEDURE         "VRTN_PLSQL_QQ_GRADE" IS

    /*
             CREATE DATE:  2010/05/05
         PLSQL      :  VRTN_PLSQL_QQ_GRADE
                 Author     :  Susan Lin
                 Purpase    :  UPDATE VRTN_QQ_VENDOR_GV Score=0 For grade = ''
         ---------------------------------------------------------------------
         * 2010/07/08 for ugtw/ugsz
     */


 vPROCEE_YYYYMMDD varchar2(8);
 vPROCEE_YYYYMM   varchar2(6);
 iTracePoint      varchar2(100);
 cErrorText       varchar2(500);
 vCOMPANY_CODE    varchar2(4);
 vYYYYMM          varchar2(6);
 vSTART_DATE      varchar2(8);
 vEND_DATE        varchar2(8);
 vQUARTER         varchar2(8);
 vCK_GV_VENDOR    varchar2(10);
 vIR_AMT_TWD                PLD_KPI_IR_DETAIL.IR_AMT_TWD%TYPE;

BEGIN
    vCOMPANY_CODE := null;
    vYYYYMM := null;
    vSTART_DATE := null;
    vEND_DATE := null;
    
 select * into vQUARTER from (
  select trim(trim(to_char(add_months(SYSDATE,-1), 'YYYY')) || 'Q' || trim(to_char(add_months(SYSDATE,-1), 'Q')))
    from dual
 );


--    vQUARTER := '2010Q4';

  if vQUARTER is null then
     --若沒抓到資料則寄 error mail
     iTracePoint := '110';
     cErrorText := 'QUARTER error!';
     MAIL_FILE_BIDBDBADMIN(in_to_name => 'shuchin@ms.usi.com.tw', subject => '[VRTN] PL/SQL VRTN_PLSQL_QQ_GRADE ERROR', message => '[VRTN_PLSQL_QQ_GV], The tracepoint is  ' || iTracePoint || ' and ErrorText= ' || cErrorText) ;
  else


     --放入季交易資料
       iTracePoint := '110';
           for REC1 in (
               select * from  VRTN_QQ_VENDOR_GV
                        where QUARTER = vQUARTER
              ) loop


-- Add for GRADE By susan 2008/01/18
                  if REC1.TW_Q_SCORE = '0' and
                     REC1.TW_SUBTOT_Q = '0' and REC1.TW_SUBTOT_C = '0' and REC1.TW_SUBTOT_D = '0' then
                     REC1.TW_GRADE := '';
                  end if;

                  if REC1.SZ_Q_SCORE = '0' and
                     REC1.SZ_SUBTOT_Q = '0' and REC1.SZ_SUBTOT_C = '0' and REC1.SZ_SUBTOT_D = '0' then
                     REC1.SZ_GRADE := '';
                  end if;

                  if REC1.SH_Q_SCORE = '0' and
                     REC1.SH_SUBTOT_Q = '0' and REC1.SH_SUBTOT_C = '0' and REC1.SH_SUBTOT_D = '0' then
                     REC1.SH_GRADE := '';
                  end if;
                  
                  if REC1.UGSZ_Q_SCORE = '0' and
                     REC1.UGSZ_SUBTOT_Q = '0' and REC1.UGSZ_SUBTOT_C = '0' and REC1.UGSZ_SUBTOT_D = '0' then
                     REC1.UGSZ_GRADE := '';
                  end if;
                  
                  if REC1.UGTW_Q_SCORE = '0' and
                     REC1.UGTW_SUBTOT_Q = '0' and REC1.UGTW_SUBTOT_C = '0' and REC1.UGTW_SUBTOT_D = '0' then
                     REC1.UGTW_GRADE := '';
                  end if;


                  Update VRTN_QQ_VENDOR_GV
                         set TW_GRADE = REC1.TW_GRADE,
                             SZ_GRADE = REC1.SZ_GRADE,
                             SH_GRADE = REC1.SH_GRADE,
                             UGSZ_GRADE = REC1.UGSZ_GRADE,
                             UGTW_GRADE = REC1.UGTW_GRADE
                         where QUARTER  = vQUARTER
                           and GV_VENDOR = REC1.GV_VENDOR;

                  commit;
                end loop;



  end if;

EXCEPTION
   When OTHERS Then
    --有錯誤產生則寄mail
      cErrorText := SQLERRM();
      MAIL_FILE_BIDBDBADMIN(in_to_name => 'shuchin_lin@usiglobal.com', subject => '[VRTN] PL/SQL VRTN_PLSQL_QQ_GRADE ERROR', message => '[VRTN_PLSQL_QQ_GV], The tracepoint is  ' || iTracePoint || ' and ErrorText= ' || cErrorText);


END VRTN_PLSQL_QQ_GRADE;
/

