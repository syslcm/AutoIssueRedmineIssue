create PROCEDURE       pnl3_pls005_category_gen_trx (
   --inCompany  in VARCHAR2,
   inperiod   IN   VARCHAR2
--2008/10/15 Crate by wenrong
--2008/11/6  要搬到collect_data時,不要再加上mtl_group,ship_to,bill_to,pn等資料,畢竟只是要計算出summary資料而已,不然在200810除了未分配有3萬筆,其他copa/pca/glaccount
--加起來也2萬筆,卻跑出23萬筆的資料
--2008/12/18 因EXPENSE RATE尚未產生但老闆要看,因此從bugdet copy ratio到PNL3_MAP003_EXPENSE_RATE 由PNL3_PLS007_EXPENSE_MAP_TRX_V3 處理,因此
--這裡原本是呼叫PNL3_PLS007_EXPENSE_MAP_TRX_V1也暫由PNL3_PLS007_EXPENSE_MAP_TRX呼叫
-- 2009/2/11 增加執行pnl2_pls001_bad_debt_chang_trx,避免BUG出現
--2011/8/6 備份到pnl3_pls005_category_gen_trx_1 ,因為樓上那一塊常常有問題,檢查後都是會計自己在那裡加料,造成和SAP不合,所以直接抓會計的CUSTOMER MODEL最好了,有問題直接找會計
-- 在費用有太多筆數是>0 且小於1的,把他過濾掉
--2011/8/12 改了邏輯後,原本不滿意的變滿意了,但原本滿意的變不滿意了,有偷拿裡面的資料去做別的報表,所以要先回一版pnl3_pls005_category_gen_trx_1給USER,然後再回來此版本
--再叫USER以後用別的報表,不能用這個報表的資料當其他用途
)
AUTHID DEFINER
IS
   --呆帳金額(待寫)
   a_amount_l   pnl3_trx001_copa.amt_twd%TYPE;
   a_amount_t   pnl3_trx001_copa.amt_twd%TYPE;
   a_amount_u   pnl3_trx001_copa.amt_twd%TYPE;
   a_counter    INTEGER;
   a_amt        pnl3_trx001_copa.amt_twd%TYPE;
BEGIN
   pnl3_pls015_custommodel_trx (inperiod);
                          --將COPA裡正常的資料產生至 PNL2_TRX001_SUMMARY_DATA
   --Revenue比率要在此時產生供後面使用
   pnl3_pls006_revenue_ratio_trx (inperiod);
--在PNL3_PLS001_COPA_TRX裡面執行一次是要做掉COPA COST ELEMENT = 410103以及上傳的revenue但卻是有sap的
--而這裡則是為了沒有sap site的
   pnl3_pls006_expense_ratio_trx (inperiod);
   BEGIN
      UPDATE pnl3_map007_period_control
         SET period = inperiod
       WHERE period = inperiod;

      IF SQL%NOTFOUND
      THEN
         INSERT INTO pnl3_map007_period_control
                     (period
                     )
              VALUES (inperiod
                     );
      END IF;
   EXCEPTION
      WHEN OTHERS
      THEN
         a_counter := 0;
   END;

   BEGIN
      UPDATE pnl3_map002_year
         SET yyyy = SUBSTRB (inperiod, 1, 4)
       WHERE yyyy = SUBSTRB (inperiod, 1, 4);

      IF SQL%NOTFOUND
      THEN
         INSERT INTO pnl3_map002_year
                     (yyyy
                     )
              VALUES (SUBSTR (inperiod, 1, 4)
                     );
      END IF;
   EXCEPTION
      WHEN OTHERS
      THEN
         UPDATE pnl3_map002_year
            SET yyyy = SUBSTRB (inperiod, 1, 4)
          WHERE yyyy = SUBSTRB (inperiod, 1, 4);
   END;

   DELETE FROM pnl3_trx005_collect_detail
         WHERE period = inperiod;

   COMMIT;

   FOR rec1 IN (SELECT   company_code, period, profit_center, end_customer_id,
                         r_kind, area1, area2, area3, SOURCE,
                         SUM (amt_local) amt_local, SUM (amt_usd) amt_usd,
                         SUM (amt_twd) amt_twd
                    FROM pnl3_trx001_copa
                   WHERE period = inperiod
                GROUP BY company_code,
                         period,
                         profit_center,
                         end_customer_id,
                         r_kind,
                         area1,
                         area2,
                         area3,
                         SOURCE)
   LOOP
      INSERT INTO pnl3_trx005_collect_detail
                  (company_code, period, profit_center,
                   end_customer_id, amt_local, amt_usd,
                   amt_twd, SOURCE, r_kind, area1,
                   area2, area3, create_date
                  )
           VALUES (rec1.company_code, rec1.period, rec1.profit_center,
                   rec1.end_customer_id, rec1.amt_local, rec1.amt_usd,
                   rec1.amt_twd, rec1.SOURCE, rec1.r_kind, rec1.area1,
                   rec1.area2, rec1.area3, SYSDATE
                  );

      COMMIT;
   END LOOP;

 

   --以下在計算加總
    --Net Manufacturing Revenues  (Category:1/4/0)
   DELETE FROM pnl3_trx005_collect_detail
         WHERE period = inperiod
           AND r_kind = 'PL01'
           AND area1 = '1'
           AND area2 = '4'
           AND area3 = '0';

   COMMIT;

   --Gross margin
   DELETE FROM pnl3_trx005_collect_detail
         WHERE period = inperiod
           AND r_kind = 'PL01'
           AND area1 = '3'
           AND area2 = '0'
           AND area3 = '0';

   COMMIT;

   --COGS Subtotal
   DELETE FROM pnl3_trx005_collect_detail
         WHERE period = inperiod
           AND r_kind = 'PL01'
           AND area1 = '2'
           AND area2 = '6'
           AND area3 = '0';

   COMMIT;

   --從Revenue角度來看,但也得考慮到end customer可能沒有Revenue只有成本??雖然不大可能發生,仍要加入這條邏輯(寫在此LOOP後)
   FOR rec1 IN (SELECT   profit_center, end_customer_id, company_code,
                         SUM (amt_local) amt_local, SUM (amt_usd) amt_usd,
                         SUM (amt_twd) amt_twd, SOURCE
                    FROM pnl3_trx005_collect_detail
                   WHERE r_kind = 'PL01'
                     AND period = inperiod
                     AND area1 = '1'
                     AND area2 = '1'
                     AND area3 = '0'
                GROUP BY profit_center, end_customer_id, company_code, SOURCE)
   LOOP
      INSERT INTO pnl3_trx005_collect_detail
                  (company_code, period, profit_center,
                   end_customer_id, amt_local, amt_usd,
                   amt_twd, SOURCE, r_kind, area1, area2, area3,
                   create_date, TYPE
                  )
           VALUES (rec1.company_code, inperiod, rec1.profit_center,
                   rec1.end_customer_id, rec1.amt_local, rec1.amt_usd,
                   rec1.amt_twd, rec1.SOURCE, 'PL01', '1', '4', '0',
                   SYSDATE, 'SUM'
                  );

      COMMIT;
      --Gross margin & COGS Subtotal
      a_amount_l := rec1.amt_local;
      a_amount_t := rec1.amt_twd;
      a_amount_u := rec1.amt_usd;

      FOR rec2 IN (SELECT   profit_center, end_customer_id, company_code,
                            SOURCE, NVL (SUM (amt_local), 0) amt_local,
                            NVL (SUM (amt_usd), 0) amt_usd,
                            NVL (SUM (amt_twd), 0) amt_twd
                       FROM pnl3_trx005_collect_detail
                      WHERE r_kind = 'PL01'
                        AND period = inperiod
                        AND profit_center = rec1.profit_center
                        AND company_code = rec1.company_code
                        AND end_customer_id = rec1.end_customer_id
                        AND SOURCE = rec1.SOURCE
                        AND area1 = '2'
                        AND area2 IN ('2', '3', '4', '5')
                   --AND AREA3  = '0'
                   GROUP BY profit_center,
                            end_customer_id,
                            company_code,
                            SOURCE)
      LOOP
         a_amount_l := a_amount_l - rec2.amt_local;
         a_amount_t := a_amount_t - rec2.amt_twd;
         a_amount_u := a_amount_u - rec2.amt_usd;

         --COGS SubTotal
         INSERT INTO pnl3_trx005_collect_detail
                     (company_code, period, profit_center,
                      end_customer_id, amt_local, amt_usd,
                      amt_twd, SOURCE, r_kind, area1, area2, area3,
                      create_date, TYPE
                     )
              VALUES (rec2.company_code, inperiod, rec2.profit_center,
                      rec2.end_customer_id, rec2.amt_local, rec2.amt_usd,
                      rec2.amt_twd, rec1.SOURCE, 'PL01', '2', '6', '0',
                      SYSDATE, 'SUM'
                     );

         COMMIT;
      END LOOP;

      --Gross margin
      INSERT INTO pnl3_trx005_collect_detail
                  (company_code, period, profit_center,
                   end_customer_id, amt_local, amt_usd, amt_twd,
                   SOURCE, r_kind, area1, area2, area3, create_date, TYPE
                  )
           VALUES (rec1.company_code, inperiod, rec1.profit_center,
                   rec1.end_customer_id, a_amount_l, a_amount_u, a_amount_t,
                   rec1.SOURCE, 'PL01', '3', '0', '0', SYSDATE, 'SUM'
                  );

      COMMIT;
   END LOOP;

   FOR rec1 IN (SELECT   profit_center, end_customer_id, company_code, period,
                         SOURCE, NVL (SUM (amt_local), 0) amt_local,
                         NVL (SUM (amt_usd), 0) amt_usd,
                         NVL (SUM (amt_twd), 0) amt_twd
                    FROM pnl3_trx005_collect_detail
                   WHERE r_kind = 'PL01'
                     AND period = inperiod
                     --AND PROFIT_CENTER = REC1.PROFIT_CENTER
                     --AND COMPANY_CODE = REC1.COMPANY_CODE
                     --AND END_CUSTOMER_ID = REC1.END_CUSTOMER_ID
                     AND area1 = '2'
                     AND area2 IN ('2', '3', '4', '5')
                --AND AREA3  = '0'
                GROUP BY profit_center,
                         end_customer_id,
                         company_code,
                         period,
                         SOURCE)
   LOOP
      a_counter := 0;
      a_amount_l := 0;
      a_amount_t := 0;
      a_amount_u := 0;

      BEGIN
         SELECT   COUNT (*)
             INTO a_counter
             FROM pnl3_trx005_collect_detail
            WHERE r_kind = 'PL01'
              AND period = inperiod
              AND area1 = '1'
              AND area2 = '1'
              AND area3 = '0'
              AND profit_center = rec1.profit_center
              AND end_customer_id = rec1.end_customer_id
              AND company_code = rec1.company_code
              AND SOURCE = rec1.SOURCE
         GROUP BY profit_center, end_customer_id, company_code, SOURCE;

         IF SQL%NOTFOUND
         THEN
            a_counter := 0;
         END IF;
      EXCEPTION
         WHEN OTHERS
         THEN
            a_counter := 0;
      END;

      --表示此PC+SITE+END_CUSTOMER 沒有營收,只有成本
      IF a_counter = 0
      THEN
         INSERT INTO pnl3_trx005_collect_detail
                     (company_code, period, profit_center,
                      end_customer_id, amt_local, amt_usd,
                      amt_twd, SOURCE, r_kind, area1, area2, area3,
                      create_date, TYPE
                     )
              VALUES (rec1.company_code, rec1.period, rec1.profit_center,
                      rec1.end_customer_id, rec1.amt_local, rec1.amt_usd,
                      rec1.amt_twd, rec1.SOURCE, 'PL01', '2', '6', '0',
                      SYSDATE, 'SUM'
                     );

         COMMIT;
         --Gross margin
         a_amount_l := a_amount_l - rec1.amt_local;
         a_amount_t := a_amount_t - rec1.amt_twd;
         a_amount_u := a_amount_u - rec1.amt_usd;

         INSERT INTO pnl3_trx005_collect_detail
                     (company_code, period, profit_center,
                      end_customer_id, amt_local, amt_usd,
                      amt_twd, SOURCE, r_kind, area1, area2, area3,
                      create_date, TYPE
                     )
              VALUES (rec1.company_code, rec1.period, rec1.profit_center,
                      rec1.end_customer_id, a_amount_l, a_amount_u,
                      a_amount_t, rec1.SOURCE, 'PL01', '3', '0', '0',
                      SYSDATE, 'SUM'
                     );

         COMMIT;
      END IF;
   END LOOP;

   pnl2_pls001_bad_debt_chang_trx ('1100', inperiod);
--2009/2/11 重新設定呆帳的end customer id,避免USER上傳時的COPA沒有資料造成END CUSTOMER ID全部是OTHERS
-- 1100 是指上傳的SITE,目前所有呆帳都由TW上傳

   --費用金額(Category 4/X/X)
   IF SUBSTR (inperiod, 1, 4) = '2008'
   THEN
      pnl3_pls010_expense_2008_trx (inperiod);
   ELSE
      pnl3_pls007_expense_map_trx (inperiod);
   END IF;

   --exp.的total 或 subtotal要計算完再加
   FOR rec1 IN (SELECT   profit_center, end_customer_id, company_code, period,
                         SOURCE, NVL (SUM (amt_local), 0) amt_local,
                         NVL (SUM (amt_usd), 0) amt_usd,
                         NVL (SUM (amt_twd), 0) amt_twd
                    FROM pnl3_trx005_collect_detail
                   WHERE r_kind = 'PL01'
                     AND period = inperiod
                     AND area1 = '4'
                     AND area2 = '1'
                     AND area3 BETWEEN '1' AND '89'
                GROUP BY profit_center,
                         end_customer_id,
                         company_code,
                         period,
                         SOURCE)
   LOOP

      INSERT INTO pnl3_trx005_collect_detail
                  (company_code, period, profit_center,
                   end_customer_id, amt_local, amt_usd,
                   amt_twd, SOURCE, r_kind, area1, area2, area3,
                   create_date, TYPE
                  )
           VALUES (rec1.company_code, rec1.period, rec1.profit_center,
                   rec1.end_customer_id, rec1.amt_local, rec1.amt_usd,
                   rec1.amt_twd, rec1.SOURCE, 'PL01', '4', '1', '90',
                   SYSDATE, 'SUM'
                  );

      COMMIT;
      --這裡塞了一堆0只是因為為了BI的報表有層級而已,而且還有COMPANY CODE,所以不能省幾個欄位
      
      INSERT INTO pnl3_trx005_collect_detail
                  (company_code, period, profit_center,
                   end_customer_id, amt_local, amt_usd, amt_twd, SOURCE,
                   r_kind, area1, area2, area3, create_date, TYPE
                  )
           VALUES (rec1.company_code, rec1.period, rec1.profit_center,
                   rec1.end_customer_id, 0, 0, 0, rec1.SOURCE,
                   'PL01', '4', '1', '0', SYSDATE, 'SUM'
                  );

      COMMIT;
   END LOOP;

   FOR rec1 IN (SELECT   profit_center, end_customer_id, company_code, period,
                         SOURCE
                    FROM pnl3_trx005_collect_detail
                   WHERE r_kind = 'PL01' AND period = inperiod AND area1 = '4'
                GROUP BY profit_center,
                         end_customer_id,
                         company_code,
                         period,
                         SOURCE)
   LOOP
      INSERT INTO pnl3_trx005_collect_detail
                  (company_code, period, profit_center,
                   end_customer_id, amt_local, amt_usd, amt_twd, SOURCE,
                   r_kind, area1, area2, area3, create_date, TYPE
                  )
           VALUES (rec1.company_code, rec1.period, rec1.profit_center,
                   rec1.end_customer_id, 0, 0, 0, rec1.SOURCE,
                   'PL01', '4', '0', '0', SYSDATE, 'SUM'
                  );

      COMMIT;
   END LOOP;

   FOR rec1 IN (SELECT   profit_center, end_customer_id, company_code, period,
                         SOURCE, NVL (SUM (amt_local), 0) amt_local,
                         NVL (SUM (amt_usd), 0) amt_usd,
                         NVL (SUM (amt_twd), 0) amt_twd
                    FROM pnl3_trx005_collect_detail
                   WHERE r_kind = 'PL01'
                     AND period = inperiod
                     AND area1 = '4'
                     AND area2 = '2'
                     AND area3 BETWEEN '1' AND '89'
                GROUP BY profit_center,
                         end_customer_id,
                         company_code,
                         period,
                         SOURCE)
   LOOP
     IF rec1.amt_local < 1 AND rec1.amt_local > 0 THEN
        a_amt := 0;
      ELSE
      INSERT INTO pnl3_trx005_collect_detail
                  (company_code, period, profit_center,
                   end_customer_id, amt_local, amt_usd,
                   amt_twd, SOURCE, r_kind, area1, area2, area3,
                   create_date, TYPE
                  )
           VALUES (rec1.company_code, rec1.period, rec1.profit_center,
                   rec1.end_customer_id, rec1.amt_local, rec1.amt_usd,
                   rec1.amt_twd, rec1.SOURCE, 'PL01', '4', '2', '90',
                   SYSDATE, 'SUM'
                  );

      COMMIT;

      INSERT INTO pnl3_trx005_collect_detail
                  (company_code, period, profit_center,
                   end_customer_id, amt_local, amt_usd, amt_twd, SOURCE,
                   r_kind, area1, area2, area3, create_date, TYPE
                  )
           VALUES (rec1.company_code, rec1.period, rec1.profit_center,
                   rec1.end_customer_id, 0, 0, 0, rec1.SOURCE,
                   'PL01', '4', '2', '0', SYSDATE, 'SUM'
                  );

      COMMIT;
      END IF;
   END LOOP;

   FOR rec1 IN (SELECT   profit_center, end_customer_id, company_code, period,
                         SOURCE, NVL (SUM (amt_local), 0) amt_local,
                         NVL (SUM (amt_usd), 0) amt_usd,
                         NVL (SUM (amt_twd), 0) amt_twd
                    FROM pnl3_trx005_collect_detail
                   WHERE r_kind = 'PL01'
                     AND period = inperiod
                     AND area1 = '4'
                     AND area2 = '3'
                     AND area3 BETWEEN '1' AND '89'
                GROUP BY profit_center,
                         end_customer_id,
                         company_code,
                         period,
                         SOURCE)
   LOOP
     IF rec1.amt_local < 1 AND rec1.amt_local > 0 THEN
        a_amt := 0;
      ELSE
      INSERT INTO pnl3_trx005_collect_detail
                  (company_code, period, profit_center,
                   end_customer_id, amt_local, amt_usd,
                   amt_twd, SOURCE, r_kind, area1, area2, area3,
                   create_date, TYPE
                  )
           VALUES (rec1.company_code, rec1.period, rec1.profit_center,
                   rec1.end_customer_id, rec1.amt_local, rec1.amt_usd,
                   rec1.amt_twd, rec1.SOURCE, 'PL01', '4', '3', '90',
                   SYSDATE, 'SUM'
                  );

      COMMIT;

      INSERT INTO pnl3_trx005_collect_detail
                  (company_code, period, profit_center,
                   end_customer_id, amt_local, amt_usd, amt_twd, SOURCE,
                   r_kind, area1, area2, area3, create_date, TYPE
                  )
           VALUES (rec1.company_code, rec1.period, rec1.profit_center,
                   rec1.end_customer_id, 0, 0, 0, rec1.SOURCE,
                   'PL01', '4', '3', '0', SYSDATE, 'SUM'
                  );

      COMMIT;
    END IF;
   END LOOP;

   FOR rec1 IN (SELECT   profit_center, end_customer_id, company_code, period,
                         SOURCE, NVL (SUM (amt_local), 0) amt_local,
                         NVL (SUM (amt_usd), 0) amt_usd,
                         NVL (SUM (amt_twd), 0) amt_twd
                    FROM pnl3_trx005_collect_detail
                   WHERE r_kind = 'PL01'
                     AND period = inperiod
                     AND area1 = '4'
                     AND area3 = '90'
                GROUP BY profit_center,
                         end_customer_id,
                         company_code,
                         period,
                         SOURCE)
   LOOP
      INSERT INTO pnl3_trx005_collect_detail
                  (company_code, period, profit_center,
                   end_customer_id, amt_local, amt_usd,
                   amt_twd, SOURCE, r_kind, area1, area2, area3,
                   create_date, TYPE
                  )
           VALUES (rec1.company_code, rec1.period, rec1.profit_center,
                   rec1.end_customer_id, rec1.amt_local, rec1.amt_usd,
                   rec1.amt_twd, rec1.SOURCE, 'PL01', '4', '4', '0',
                   SYSDATE, 'SUM'
                  );

      COMMIT;
   END LOOP;

   FOR rec1 IN (SELECT   company_code, profit_center, end_customer_id,
                         SUM (amt_local) amt_local, SUM (amt_usd) amt_usd,
                         SUM (amt_twd) amt_twd
                    FROM pnl3_trx005_collect_detail
                   WHERE period = inperiod
                     AND r_kind = 'PL01'
                     AND area1 = '3'
                     AND area2 = '0'
                     AND area3 = '0'
                GROUP BY company_code, profit_center, end_customer_id)
   LOOP
      a_counter := 0;
      a_amount_l := rec1.amt_local;
      a_amount_t := rec1.amt_twd;
      a_amount_u := rec1.amt_usd;

      FOR rec2 IN (SELECT   profit_center, end_customer_id, company_code,
                            NVL (SUM (amt_local), 0) amt_local,
                            NVL (SUM (amt_usd), 0) amt_usd,
                            NVL (SUM (amt_twd), 0) amt_twd
                       FROM pnl3_trx005_collect_detail
                      WHERE r_kind = 'PL01'
                        AND period = inperiod
                        AND profit_center = rec1.profit_center
                        AND company_code = rec1.company_code
                        AND end_customer_id = rec1.end_customer_id
                        AND area1 = '4'
                        AND area2 = '4'
                        AND area3 = '0'
                   GROUP BY profit_center, end_customer_id, company_code)
      LOOP
         a_amount_l := a_amount_l + rec2.amt_local;
         a_amount_t := a_amount_t + rec2.amt_twd;
         a_amount_u := a_amount_u + rec2.amt_usd;
         a_counter := a_counter + 1;

         --COGS SubTotal
         INSERT INTO pnl3_trx005_collect_detail
                     (company_code, period, profit_center,
                      end_customer_id, amt_local, amt_usd,
                      amt_twd, SOURCE, r_kind, area1, area2, area3,
                      create_date, TYPE
                     )
              VALUES (rec2.company_code, inperiod, rec2.profit_center,
                      rec2.end_customer_id, a_amount_l, a_amount_u,
                      a_amount_t, 'TOTAL', 'PL01', '4', '5', '0',
                      SYSDATE, 'SUM'
                     );

         COMMIT;
      END LOOP;

      IF a_counter = 0
      THEN
         INSERT INTO pnl3_trx005_collect_detail
                     (company_code, period, profit_center,
                      end_customer_id, amt_local, amt_usd,
                      amt_twd, SOURCE, r_kind, area1, area2, area3,
                      create_date, TYPE
                     )
              VALUES (rec1.company_code, inperiod, rec1.profit_center,
                      rec1.end_customer_id, a_amount_l, a_amount_u,
                      a_amount_t, 'TOTAL', 'PL01', '4', '5', '0',
                      SYSDATE, 'SUM'
                     );

         COMMIT;
      END IF;
   END LOOP;

   FOR rec2 IN (SELECT   profit_center, end_customer_id, company_code,
                         NVL (SUM (amt_local), 0) amt_local,
                         NVL (SUM (amt_usd), 0) amt_usd,
                         NVL (SUM (amt_twd), 0) amt_twd
                    FROM pnl3_trx005_collect_detail
                   WHERE r_kind = 'PL01'
                     AND period = inperiod
                     AND area1 = '4'
                     AND area2 = '4'
                     AND area3 = '0'
                GROUP BY profit_center, end_customer_id, company_code)
   LOOP
      a_amount_l := rec2.amt_local;
      a_amount_t := rec2.amt_twd;
      a_amount_u := rec2.amt_usd;
      a_counter := 0;

      BEGIN
         SELECT COUNT (*)
           INTO a_counter
           FROM pnl3_trx005_collect_detail
          WHERE r_kind = 'PL01'
            AND period = inperiod
            AND profit_center = rec2.profit_center
            AND company_code = rec2.company_code
            AND end_customer_id = rec2.end_customer_id
            AND area1 = '3'
            AND area2 = '0'
            AND area3 = '0';
      EXCEPTION
         WHEN OTHERS
         THEN
            a_counter := 0;
      END;

      IF a_counter = 0
      THEN
         INSERT INTO pnl3_trx005_collect_detail
                     (company_code, period, profit_center,
                      end_customer_id, amt_local, amt_usd,
                      amt_twd, SOURCE, r_kind, area1, area2, area3,
                      create_date, TYPE
                     )
              VALUES (rec2.company_code, inperiod, rec2.profit_center,
                      rec2.end_customer_id, a_amount_l, a_amount_u,
                      a_amount_t, 'TOTAL', 'PL01', '4', '5', '0',
                      SYSDATE, 'SUM'
                     );

         COMMIT;
      END IF;
   END LOOP;

   ---以下兩段UPDATE 指令在將金額由正轉負由負轉正
   UPDATE pnl3_trx005_collect_detail
      SET acct_rate =
             (SELECT rate
                FROM pnl2_map001_acct_mapping
               WHERE r_kind = pnl3_trx005_collect_detail.r_kind
                 AND area1 = pnl3_trx005_collect_detail.area1
                 AND area2 = pnl3_trx005_collect_detail.area2
                 AND area3 = pnl3_trx005_collect_detail.area3)
    WHERE period = inperiod;

   COMMIT;

   UPDATE pnl3_trx005_collect_detail
      SET amt_twd = amt_twd * acct_rate,
          amt_usd = amt_usd * acct_rate,
          amt_local = amt_local * acct_rate
    WHERE period = inperiod;

   COMMIT;
--呆帳金額,待user上傳

--產出另一個報表
 --PNL2_PLS008_GEN_CUS_RPT_TRX(inPeriod);
END pnl3_pls005_category_gen_trx;
/

