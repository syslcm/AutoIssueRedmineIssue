create PROCEDURE       PNL3_PLS001_COPA_TRX_V1 (
  --inCompany  in VARCHAR2,
  t_Period in VARCHAR2
  --2008/11/4 ADD KPI_UPL001_REVENUE_TRX 
)
AUTHID DEFINER
is
 
--2008/11/7 有發現  SUM(NET_REVENUE) <> 0 OR SUM(NET_COGS)  <> 0 條件成立但dm/dl/oh卻有值的戕況,因此不加入此條件
-- 在INSERT進資料庫時再排除金額=0的資料
--範例在PROFIT_CENTER  23  SITE:1100  金額 -30973  COST_ELEEMENT 510902  這三個pn
--1568-018969-91
--1568-025307-71
--1568-026054-91

  
---USER Upload Non-SAP Data
  
  CURSOR C_PNL3_PLS001_R2 is
      SELECT COMPANY_CODE,PERIOD,PROFIT_CENTER,
            SUM(NET_REVENUE) AMT_LOCAL,SUM(NET_REVENUE_USD) AMT_USD,SUM(NET_REVENUE_TWD) AMT_TWD
        FROM KPI_UPL001_REVENUE_TRX
       WHERE PERIOD = t_Period
         AND     NET_REVENUE <> 0
         AND    RELATED_PARTY <> 'Y'
    GROUP BY COMPANY_CODE,PERIOD,PROFIT_CENTER
      HAVING  SUM(NET_REVENUE) <> 0 ;
      
--Update FG & END CUSTOMER Mapping
      
 BEGIN

       
    FOR REC1 in C_PNL3_PLS001_R2 Loop 
         IF REC1.COMPANY_CODE  = '1101' THEN
           IF REC1.PROFIT_CENTER = '0000000034' OR REC1.PROFIT_CENTER = '0000000038' THEN
              Insert into PNL3_TRX001_COPA (
                  COMPANY_CODE    , PERIOD         , PROFIT_CENTER      , 
                  AMT_LOCAL      , AMT_USD            , AMT_TWD         , SOURCE          ,
                  R_KIND          , AREA1          ,AREA2               , AREA3            ,
                  CREATE_DATE    ,END_CUSTOMER_ID
                      ) VALUES (
                        REC1.COMPANY_CODE       , REC1.PERIOD       , REC1.PROFIT_CENTER      , 
                        REC1.AMT_LOCAL    , REC1.AMT_USD            , REC1.AMT_TWD            , 'UPL001'               ,
                        'PL01'                  , '1'                 ,'1'                       , '0'                    ,
                        SYSDATE ,'UABIT''S CUST');
               Commit;
           ELSE

              Insert into PNL3_TRX001_COPA (
                  COMPANY_CODE    , PERIOD         , PROFIT_CENTER      , 
                  AMT_LOCAL      , AMT_USD            , AMT_TWD         , SOURCE          ,
                  R_KIND          , AREA1          ,AREA2               , AREA3            ,
                  CREATE_DATE     
                      ) VALUES (
                        REC1.COMPANY_CODE       , REC1.PERIOD       , REC1.PROFIT_CENTER      , 
                        REC1.AMT_LOCAL    , REC1.AMT_USD            , REC1.AMT_TWD            , 'UPL001'               ,
                        'PL01'                  , '1'                 ,'1'                       , '0'                    ,
                        SYSDATE   );
               Commit;
           END IF;
         ELSIF SUBSTR(REC1.COMPANY_CODE,1,1) = '9' THEN
              Insert into PNL3_TRX001_COPA (
                  COMPANY_CODE    , PERIOD         , PROFIT_CENTER      , 
                  AMT_LOCAL      , AMT_USD            , AMT_TWD         , SOURCE          ,
                  R_KIND          , AREA1          ,AREA2               , AREA3            ,
                  CREATE_DATE    ,END_CUSTOMER_ID
                      ) VALUES (
                        REC1.COMPANY_CODE       , REC1.PERIOD       , REC1.PROFIT_CENTER      , 
                        REC1.AMT_LOCAL    , REC1.AMT_USD            , REC1.AMT_TWD            , 'UPL001'               ,
                        'PL01'                  , '1'                 ,'1'                       , '0'                    ,
                        SYSDATE ,'投資公司');
               Commit;
         ELSE
              Insert into PNL3_TRX001_COPA (
                  COMPANY_CODE    , PERIOD         , PROFIT_CENTER      , 
                  AMT_LOCAL      , AMT_USD            , AMT_TWD         , SOURCE          ,
                  R_KIND          , AREA1          ,AREA2               , AREA3            ,
                  CREATE_DATE    
                      ) VALUES (
                        REC1.COMPANY_CODE       , REC1.PERIOD       , REC1.PROFIT_CENTER      , 
                        REC1.AMT_LOCAL    , REC1.AMT_USD            , REC1.AMT_TWD            , 'UPL001'               ,
                        'PL01'                  , '1'                 ,'1'                       , '0'                    ,
                        SYSDATE );
               Commit;
         END IF;

    END LOOP;
    
END PNL3_PLS001_COPA_TRX_V1;
/

