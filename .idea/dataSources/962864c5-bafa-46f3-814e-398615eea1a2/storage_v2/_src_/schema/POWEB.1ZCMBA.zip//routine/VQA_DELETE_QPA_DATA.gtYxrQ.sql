create PROCEDURE "VQA_DELETE_QPA_DATA"
IS
   /*--------------------------------------------------------------*
      CREATE DATE:  2010/11/10
      PLSQL      :  VQA_DELETE_QPA_DATA
      Author     :  Shuya
      Purpase    :  每天刪除100 天前DOWNLOAD 的QPA DATA？
    *---------------------------------------------------------------*/
   itracepoint        VARCHAR2 (100);
   cerrortext		  VARCHAR2 (100);
   record_count       NUMBER (6, 0);
BEGIN
   itracepoint := '100';
   delete VQA_LFO_WO_QPA where up_date < sysdate-100;
   COMMIT;


   mail_file_bidbdbadmin
              (in_to_name      => 'shuya_chen@usiglobal.com',
               subject         => '[VQA] PL/SQL VQA_DELETE_QPA_DATA Succeed',
               MESSAGE         =>    ' '
              );
EXCEPTION
   WHEN OTHERS
   THEN
      --有錯誤產生則寄mail
      cerrortext := SQLERRM ();
      mail_file_bidbdbadmin
                  (in_to_name      => 'shuya_chen@usiglobal.com',
                   subject         => '[VQA] PL/SQL VQA_DELETE_QPA_DATA ERROR',
                   MESSAGE         =>    '[VQA_DELETE_QPA_DATA], The tracepoint is  '
                                      || itracepoint
                                      || ' and ErrorText= '
                                      || cerrortext
                  );
END VQA_DELETE_QPA_DATA;
/

