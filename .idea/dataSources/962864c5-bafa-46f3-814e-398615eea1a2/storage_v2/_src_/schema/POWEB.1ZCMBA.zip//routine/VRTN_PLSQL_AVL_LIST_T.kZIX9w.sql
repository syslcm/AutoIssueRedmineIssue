create PROCEDURE       Vrtn_Plsql_Avl_List_T
IS
/******************************************************************************
   NAME:       vrtn_plsql_pdm_avl_list
   PURPOSE:    upload pdm data to poweb db.

   REVISIONS:
   Ver        Date        Author           Description
   ---------  ----------  ---------------  ------------------------------------
   1.0        96/10/9     Shuya           1. Created this procedure.

******************************************************************************/
   CURSOR pdm_avl_list
   IS
      SELECT   a.item_number pn,mb.text01 SEQUENCE, ma.NAME mfr, le.entryvalue mg,
               pt.VALUE phase
          FROM (SELECT i.*
                  FROM agile.item@pdm i
                 WHERE i.CLASS = '10000'
                   AND i.CATEGORY = '211226'
                   AND i.default_change > 0) a,
               agile.manu_by@pdm mb,
               agile.manu_parts@pdm mp,
               agile.manufacturers@pdm ma,
               agile.page_two@pdm p2,
               agile.listentry@pdm le,
               agile.propertytable@pdm pt
         WHERE mb.agile_part = a.ID
           AND mp.ID = mb.manu_part
           AND ma.ID = mp.manu_id
           AND p2.ID = a.ID
           AND mb.manu_part <> '0'
           AND mb.change_out = '0'
           AND mb.list02 IS NULL                                      -- Not Blocked
           AND p2.list16 = le.entryid
           AND (ma.status = pt.parentid AND pt.propertyid = 38)
      GROUP BY a.item_number, ma.NAME, le.entryvalue, pt.VALUE, mb.text01
      ORDER BY pn, SEQUENCE, mfr;

   t_count      INTEGER;
   cerrortext   CHAR (500);

BEGIN
   --(1)清除舊的VRTN_PDM_AVL_LIST 資料
   DELETE FROM VRTN_PDM_AVL_LIST;

   COMMIT;
   --(2)開始處理資料
   t_count := 0;

   FOR rec1 IN pdm_avl_list LOOP
      t_count := t_count + 1;
      IF rec1.SEQUENCE IS NOT NULL THEN
         INSERT INTO VRTN_PDM_AVL_LIST
                  (part_no, mfr_name, mtl_group, phase
                  )
           VALUES (rec1.pn||' '||rec1.SEQUENCE, rec1.mfr, rec1.mg, rec1.phase
                  );
      ELSE
         INSERT INTO VRTN_PDM_AVL_LIST
                  (part_no, mfr_name, mtl_group, phase
                  )
           VALUES (rec1.pn, rec1.mfr, rec1.mg, rec1.phase
                  );
	  END IF;
      IF t_count MOD 500 = 0 THEN
         COMMIT;
      END IF;
   END LOOP;

   COMMIT;
   Mail_File_Bidbdbadmin
                  (in_to_name      => 'shuya_chen@usiglobal.com',
                   subject         => 'vrtn_plsql_pdm_avl_list Succeed',
                   MESSAGE         =>    '[vrtn_plsql_pdm_avl_list], The total count is  '
                                      || TO_CHAR (t_count)
                  );
EXCEPTION
   WHEN NO_DATA_FOUND THEN
      NULL;
   WHEN OTHERS THEN
      cerrortext := SQLERRM ();
      Mail_File_Bidbdbadmin
                 (in_to_name      => 'shuya_chen@usiglobal.com',
                  subject         => 'vrtn_plsql_pdm_avl_list ERROR',
                  MESSAGE         =>    '[vrtn_plsql_pdm_avl_list], The current count is  '
                                     || TO_CHAR (t_count)
                                     || ' and ErrorText='
                                     || cerrortext
                 );
      RAISE;
END Vrtn_Plsql_Avl_List_T;
/

