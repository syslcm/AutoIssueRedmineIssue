create PROCEDURE       ROIC_PLS005_HS_TB_BTO (
  t_YYYYMMDD in VARCHAR2
)
AUTHID DEFINER
is
/*********************************************************************
  PROG-ID      : ROIC_PLS005_HS_TB_BTO
  PROG-ACTION  : Trial Balance - 投資架構依持股比例合併計算
  Author       : Patty
  Date         : 2019/02/26
  OA No.       : SAI095603
  Process      : 依持股比例合併計算 TB data - by GROUP_ACCT

**********************************************************************/
/*---------------------------------------------------------------------
-- 2019/04/17 SAI097955 Patty 增 RPT_TYPE 區分 'LEGAL','CONSOLIDATION'
---------------------------------------------------------------------*/
  sPROC_NAME         ROIC_PST000_LOG.PROC_NAME%TYPE;
  sRUN_SEQ           ROIC_PST000_LOG.RUN_SEQ%TYPE;
  sRUN_DESC          ROIC_PST000_LOG.RUN_DESC%TYPE;
  sPARAMETER_DESC    ROIC_PST000_LOG.PARAMETER_DESC%TYPE;      
  t_PERIOD           ROIC_SAP003_TB_DATA.PERIOD%TYPE;  
  w_FNUM             NUMBER(01);
  w_AMOUNT_TWD2      ROIC_SAP003_TB_DATA.AMOUNT_TWD2%TYPE;
  w_AMOUNT_USD2      ROIC_SAP003_TB_DATA.AMOUNT_USD2%TYPE;
  w_AMOUNT_CNY2      ROIC_SAP003_TB_DATA.AMOUNT_CNY2%TYPE; 
              
BEGIN

  t_PERIOD := SUBSTR(t_YYYYMMDD,1,6);

  sPROC_NAME := 'ROIC_PLS005_HS_TB_BTO';
  sRUN_SEQ   := '000010';
  sRUN_DESC  := 'Start';
  sPARAMETER_DESC := CONCAT('t_PERIOD=',t_PERIOD);
 
  --Insert Log
  INSERT INTO ROIC_PST000_LOG
      ( PROC_NAME, RUN_SEQ, RUN_DESC, PARAMETER_DESC )
    VALUES
      ( sPROC_NAME, sRUN_SEQ, sRUN_DESC, sPARAMETER_DESC );
  Commit;

  for REC1 in ( Select PARENT_SITE
                FROM ROIC_UPL005_SITE_LVL    
                WHERE PERIOD = t_PERIOD
                ORDER BY SITE_LEVEL DESC
  ) loop

     DELETE FROM ROIC_PST005_HS_TB_BTO 
            WHERE COMPANY_CODE = REC1.PARENT_SITE
              AND PERIOD = t_PERIOD;
     Commit;

    for REC2 in ( Select PARENT_SITE, CHILDS_SITE, PERCENTAGE
                  FROM ROIC_UPL006_SITE_REL   
                  WHERE PERIOD = t_PERIOD
                    AND PARENT_SITE = REC1.PARENT_SITE
    ) loop

     w_FNUM := 1;
     if REC2.PARENT_SITE = REC2.CHILDS_SITE then
        w_FNUM := 1;
     else
       BEGIN
         SELECT 2 INTO w_FNUM
           FROM ROIC_UPL005_SITE_LVL
           WHERE PERIOD = t_PERIOD
             AND PARENT_SITE = REC2.CHILDS_SITE;
       EXCEPTION
         WHEN OTHERS THEN
              w_FNUM := 1;
       END;
     end if; 

     if w_FNUM = 1 then
        for REC3 in ( SELECT COMPANY_CODE, PERIOD, GROUP_ACCT, RPT_TYPE,
                      SUM (amount_twd2) AS AMOUNT_TWD2, SUM (amount_usd2) AS AMOUNT_USD2, SUM(amount_cny2) AS AMOUNT_CNY2
                   FROM ROIC_VEW003_TBG1_BTO 
                   WHERE COMPANY_CODE = REC2.CHILDS_SITE
                     AND PERIOD = t_PERIOD
                   GROUP BY COMPANY_CODE, PERIOD, GROUP_ACCT, RPT_TYPE
        ) loop
          w_AMOUNT_TWD2 := REC3.AMOUNT_TWD2 * REC2.PERCENTAGE;
          w_AMOUNT_USD2 := REC3.AMOUNT_USD2 * REC2.PERCENTAGE;
          w_AMOUNT_CNY2 := REC3.AMOUNT_CNY2 * REC2.PERCENTAGE;


          INSERT INTO ROIC_PST005_HS_TB_BTO
            ( COMPANY_CODE, FR_SITE, PERIOD, GROUP_ACCT, RPT_TYPE, AMOUNT_TWD2, AMOUNT_USD2, AMOUNT_CNY2, PERCENTAGE,
              FR_AMT_TWD2, FR_AMT_USD2, FR_AMT_CNY2     
            ) VALUES 
            ( REC1.PARENT_SITE, REC2.CHILDS_SITE, REC3.PERIOD, REC3.GROUP_ACCT, REC3.RPT_TYPE, w_AMOUNT_TWD2, w_AMOUNT_USD2, w_AMOUNT_CNY2, REC2.PERCENTAGE,
              REC3.AMOUNT_TWD2, REC3.AMOUNT_USD2, REC3.AMOUNT_CNY2 );

          Commit;  

        end loop; 
     else
        for REC3 in ( SELECT COMPANY_CODE, PERIOD, GROUP_ACCT, RPT_TYPE,
                       SUM (amount_twd2) AS AMOUNT_TWD2, SUM (amount_usd2) AS AMOUNT_USD2, SUM(amount_cny2) AS AMOUNT_CNY2
                   FROM ROIC_PST005_HS_TB_BTO 
                   WHERE COMPANY_CODE = REC2.CHILDS_SITE
                     AND PERIOD = t_PERIOD
                   GROUP BY COMPANY_CODE, PERIOD, GROUP_ACCT, RPT_TYPE
        ) loop
          w_AMOUNT_TWD2 := REC3.AMOUNT_TWD2 * REC2.PERCENTAGE;
          w_AMOUNT_USD2 := REC3.AMOUNT_USD2 * REC2.PERCENTAGE;
          w_AMOUNT_CNY2 := REC3.AMOUNT_CNY2 * REC2.PERCENTAGE;


          INSERT INTO ROIC_PST005_HS_TB_BTO
            ( COMPANY_CODE, FR_SITE, PERIOD, GROUP_ACCT, RPT_TYPE, AMOUNT_TWD2, AMOUNT_USD2, AMOUNT_CNY2, PERCENTAGE,
              FR_AMT_TWD2, FR_AMT_USD2, FR_AMT_CNY2     
            ) VALUES 
            ( REC1.PARENT_SITE, REC2.CHILDS_SITE, REC3.PERIOD, REC3.GROUP_ACCT, REC3.RPT_TYPE, w_AMOUNT_TWD2, w_AMOUNT_USD2, w_AMOUNT_CNY2, REC2.PERCENTAGE,
              REC3.AMOUNT_TWD2, REC3.AMOUNT_USD2, REC3.AMOUNT_CNY2 );

          Commit;  
        end loop;   
     end if;

    end loop;     

  end loop;


  sRUN_SEQ   := '000020';
  sRUN_DESC  := 'End';

  --Insert Log
  INSERT INTO ROIC_PST000_LOG
      ( PROC_NAME, RUN_SEQ, RUN_DESC, PARAMETER_DESC )
    VALUES
      ( sPROC_NAME, sRUN_SEQ, sRUN_DESC, sPARAMETER_DESC );
  Commit;

END ROIC_PLS005_HS_TB_BTO;
/

