create PROCEDURE       PLSQL_PLD_KPI_SCALE_ZD588
(
    inCompany  in VARCHAR2,
    f_YYYYMMDD in VARCHAR2,
    t_YYYYMMDD in VARCHAR2
)
AUTHID DEFINER
is
    /*
    SAI030833 處理 PLD_KPI_INFOREC_SCALE 資料 (SAP ZD588)
    -- Inforecord Scale data
    -- 每月 15 日 SAP 下到 BI DB
    */
    iTracePoint         varchar2(3);
    cErrorText          varchar2(500);
    d_date              varchar2(8);
    xxx                 number(1);
BEGIN
        if inCompany = '2300' then
           xxx := -1;
        else
           xxx := 0;
        end if;

    --(000) 清除 create_date 錯誤者
    iTracePoint := '000';
    delete from PLD_KPI_INFOREC_SCALE_T
        where COMPANY_CODE = inCompany
        and CREATE_DATE <> to_char(sysdate + xxx,'yyyymmdd');
    commit;

    --(050) delete old data: PLD_KPI_INFOREC_SCALE
    iTracePoint := '050';
    delete from PLD_KPI_INFOREC_SCALE where COMPANY_CODE = inCompany and CREATE_DATE = to_char(sysdate,'yyyymmdd');
    commit;

    --(100) move data: PLD_KPI_INFOREC_SCALE_T  ->  PLD_KPI_INFOREC_SCALE
    iTracePoint := '100';
    insert into PLD_KPI_INFOREC_SCALE (
        COMPANY_CODE, CREATE_DATE, VENDOR_CODE, VENDOR_NAME, PART_NO, PART_DESC, PO_NO, PO_ITEM,
        INFO_CATEGORY, INFO_CURRENCY, INFO_PRICE, VALID_FROM, VALID_TO, PO_CURRENCY, PO_PRICE,
        MFG, MFG_PN, PO_DATE, QTY_01, PRICE_01, QTY_02, PRICE_02, QTY_03, PRICE_03,
        QTY_04, PRICE_04, QTY_05, PRICE_05, QTY_06, PRICE_06, QTY_07, PRICE_07,
        QTY_08, PRICE_08, QTY_09, PRICE_09, QTY_10, PRICE_10, PROFIT_CENTER, MATERIAL_GROUP, SOURCER_ID, SOURCER_NAME
    )
    select COMPANY_CODE, CREATE_DATE, VENDOR_CODE, VENDOR_NAME, PART_NO, PART_DESC, PO_NO, decode(PO_NO,null,null,PO_ITEM),
        INFO_CATEGORY, INFO_CURRENCY, INFO_PRICE, VALID_FROM, VALID_TO, PO_CURRENCY, decode(PO_NO,null,null,PO_PRICE),
        MFG, MFG_PN, decode(PO_NO,null,null,PO_DATE),
        decode(QTY_01,0,decode(PRICE_01,0,null,QTY_01),QTY_01), decode(PRICE_01,0,decode(QTY_01,0,null,PRICE_01),PRICE_01),
        decode(QTY_02,0,decode(PRICE_02,0,null,QTY_02),QTY_02), decode(PRICE_02,0,decode(QTY_02,0,null,PRICE_02),PRICE_02),
        decode(QTY_03,0,decode(PRICE_03,0,null,QTY_03),QTY_03), decode(PRICE_03,0,decode(QTY_03,0,null,PRICE_03),PRICE_03),
        decode(QTY_04,0,decode(PRICE_04,0,null,QTY_04),QTY_04), decode(PRICE_04,0,decode(QTY_04,0,null,PRICE_04),PRICE_04),
        decode(QTY_05,0,decode(PRICE_05,0,null,QTY_05),QTY_05), decode(PRICE_05,0,decode(QTY_05,0,null,PRICE_05),PRICE_05),
        decode(QTY_06,0,decode(PRICE_06,0,null,QTY_06),QTY_06), decode(PRICE_06,0,decode(QTY_06,0,null,PRICE_06),PRICE_06),
        decode(QTY_07,0,decode(PRICE_07,0,null,QTY_07),QTY_07), decode(PRICE_07,0,decode(QTY_07,0,null,PRICE_07),PRICE_07),
        decode(QTY_08,0,decode(PRICE_08,0,null,QTY_08),QTY_08), decode(PRICE_08,0,decode(QTY_08,0,null,PRICE_08),PRICE_08),
        decode(QTY_09,0,decode(PRICE_09,0,null,QTY_09),QTY_09), decode(PRICE_09,0,decode(QTY_09,0,null,PRICE_09),PRICE_09),
        decode(QTY_10,0,decode(PRICE_10,0,null,QTY_10),QTY_10), decode(PRICE_10,0,decode(QTY_10,0,null,PRICE_10),PRICE_10),
        PROFIT_CENTER, MATERIAL_GROUP, SOURCER_ID, SOURCER_NAME
    from PLD_KPI_INFOREC_SCALE_T
    where COMPANY_CODE = inCompany
    and CREATE_DATE = to_char(sysdate + xxx,'yyyymmdd');
    commit;

    --(200) 刪除過久資料
    iTracePoint := '200';
    select * into d_date from (
        select to_char(sysdate - 185, 'yyyymmdd') from dual
    );
    iTracePoint := '210';
    delete from PLD_KPI_INFOREC_SCALE
        where COMPANY_CODE = inCompany
        and CREATE_DATE <= d_date;
    commit;

    -- end
    iTracePoint := '999';
EXCEPTION
    WHEN OTHERS THEN
        cErrorText := SQLERRM();
        MAIL_FILE_BIDBDBADMIN(in_to_name=>'minhorng_su@usiglobal.com',subject   => '[PLD KPI]PL/SQL PLSQL_PLD_KPI_SCALE_ZD588 ERROR - Company: ' || inCompany, message => '[PLSQL_PLD_KPI_SCALE_ZD588], The tracepoint is  ' || iTracePoint || ' and ErrorText=' || cErrorText) ;
END PLSQL_PLD_KPI_SCALE_ZD588;
/

