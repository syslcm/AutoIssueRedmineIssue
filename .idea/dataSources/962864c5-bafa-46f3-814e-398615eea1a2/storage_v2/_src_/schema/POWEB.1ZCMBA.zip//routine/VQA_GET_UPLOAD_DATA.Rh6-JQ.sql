create FUNCTION vqa_get_upload_data (
   cmfr_name   IN   vqa_pdm_mfr_data.mfr_name%TYPE,
   cgroup_no   IN   vqa_vew002_upload_data.doc_group_no%TYPE
)
   RETURN VARCHAR2
/*********************************************************************
  PROG-ID      : VQA_GET_UPLOAD_DATA
  Author       : Shuya
  Date         : 2008/02/277
**********************************************************************/
IS
   CURSOR category_cur
   IS
      SELECT manufacturer_name,
             NVL (global_vendor_code, '') AS global_vendor_code,
             doc_group_no, doc_name, doc_desc, SOURCE
        FROM vqa_vew002_upload_data
       WHERE manufacturer_name = cmfr_name AND doc_group_no = cgroup_no;

   cmessage      VARCHAR2 (5000);
   mfr_name      VARCHAR2 (10);
   vendor_code   VARCHAR2 (10);
BEGIN
   cmessage := '';
   mfr_name := '';
   vendor_code := '-';

   FOR active_rec IN category_cur
   LOOP
      IF cmessage IS NOT NULL
      THEN
         cmessage := cmessage || ',';
      END IF;

      IF active_rec.SOURCE = 'Data'
      THEN
         cmessage := cmessage || active_rec.doc_desc;
      ELSE
         mfr_name := active_rec.manufacturer_name;
         /*vendor_code := active_rec.global_vendor_code;*/

         WHILE LENGTH (mfr_name) < 10
         LOOP
            mfr_name := mfr_name || '-';
         END LOOP;

         WHILE LENGTH (vendor_code) < 10
         LOOP
            vendor_code := vendor_code || '-';
         END LOOP;

         cmessage :=
               cmessage
            || '<a href="\AVL_files\AVL_Doc\'
            || mfr_name
            || '_'
            || active_rec.doc_group_no
            || '_'
            || vendor_code
            || '_'
            || active_rec.doc_name
            || '" target="_blank">'
            || active_rec.doc_desc
            || '</a>';
      END IF;
   END LOOP;

   RETURN cmessage;
END vqa_get_upload_data;
/

