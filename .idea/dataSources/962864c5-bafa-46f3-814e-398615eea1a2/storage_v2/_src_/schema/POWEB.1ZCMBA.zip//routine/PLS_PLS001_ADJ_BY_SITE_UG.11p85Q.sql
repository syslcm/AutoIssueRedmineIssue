create PROCEDURE       PLS_PLS001_ADJ_BY_SITE_UG (
  p_YYYYMMDD in VARCHAR2
)
AUTHID DEFINER
is
/*********************************************************************
  PROG-ID      : PLS_PLS001_ADJ_BY_SITE_UG
  PROG-ACTION  : P＆L adjust by site
  Author       : Patty
  Date         : 014/05/21
  OA No.       : SAI043515
  需求說明:
  A-1.作業1: 將單1 profit center 在單 1 Site 生產 --> 收入成本費用全歸於生產Site
  A-2.作業2: TSC (Profit center 28 ＆ 33) 收入成本及費用重新allocate
  A-3.作業3: Earning model 中, USI TW ＆ UG TW的銷、管、研費用,重新allocate
  A-4.作業4: 將單1 profit center 在多於2 site2生產產生的 NRE ＆ withholding收入成本分攤
      作業5: USI TW ＆ UG TW NPI工單的收入,成本及費用重新 allocate
      作業6. Site間相關收入,成本及費用相互調撥調整
    **作業A-4的P/C, 若出現在作業A-1中, 則挪開, 不做調整
**********************************************************************/
-- 2019/08/20 SAI104649 Patty Modify 'INSERT INTO PLS_PST001_EM':
--                      1.PNL_MSA001_EM_DATA Mapping to PNL_MAP007_ACCMAPPING
--                      2.Use PNL_MAP007_ACCMAPPING.ACCT_ID_NEW to replace
--                           PNL_MSA001_EM_DATA.ACCT_ID 
-- 2019/12/09 SAI110406 Pattty Modify:
--                      1.Copye Procedure from 'PLS_PLS001_ADJ_BY_SITE_ALL' to 'PLS_PLS001_ADJ_BY_SITE_UG'
--                      2.SELECT PNL_MSA001_EM_DATA WHERE GRP_CODE = 'UG' 
--                      3.只取 FR_SITE/TO_SITE 的 PLS_SITE_GRP = 'UG' 作業
-- 2020/05/18 SAI120208 Patty Modify:
--                      1.Use PNL_MAP007_ACCMAPPING.ACCT_ID_NEW to replace
--                            PNL_MSA001_EM_DATA.ACCT_ID (Insert into PLS_PST001_EM.EM_ACCT_ID)
/*---------------------------------------------------------------------------------------------------*/
  w_PERIOD           VARCHAR2(6);
  w_YYYY             VARCHAR2(4);
  w_MONTH            VARCHAR2(2);
  sPROC_NAME         PLS_PST000_LOG.PROC_NAME%TYPE;
  sRUN_SEQ           PLS_PST000_LOG.RUN_SEQ%TYPE;
  sRUN_DESC          PLS_PST000_LOG.RUN_DESC%TYPE;
  sPARAMETER_DESC    PLS_PST000_LOG.PARAMETER_DESC%TYPE;
  sAMOUNT            PLS_PST001_EM.AMOUNT%TYPE;
  sRPT_GRP           PLS_PST001_EM.RPT_GRP%TYPE;                 -- SAI110406

BEGIN
  w_PERIOD := SUBSTRB(p_YYYYMMDD,1,6);
  w_YYYY   := SUBSTRB(p_YYYYMMDD,1,4);
  w_MONTH  := SUBSTRB(p_YYYYMMDD,5,2);
  
  sRPT_GRP := 'UG';                                              -- SAI110406

  sPROC_NAME := 'PLS_PLS001_ADJ_BY_SITE_UG';
  sRUN_SEQ   := '000010';
  sRUN_DESC  := 'Start';
  sPARAMETER_DESC := CONCAT('w_PERIOD=',w_PERIOD);

  --Insert Log
  INSERT INTO PLS_PST000_LOG
      ( PROC_NAME, RUN_SEQ, RUN_DESC, PARAMETER_DESC )
    VALUES
      ( sPROC_NAME, sRUN_SEQ, sRUN_DESC, sPARAMETER_DESC );
  Commit;

  ---------------------------------------------------------------------------------------
  -- Delete data:
  DELETE FROM PLS_PST001_EM
      WHERE PERIOD = w_PERIOD
        AND RPT_GRP = sRPT_GRP;                    -- SAI110406
  Commit;

  DELETE FROM PLS_PST002_TMP
      WHERE RPT_GRP = sRPT_GRP;                    -- SAI110406
  Commit;

  DELETE FROM PLS_PST003_PROC
      WHERE PERIOD = w_PERIOD
        AND RPT_GRP = sRPT_GRP;                    -- SAI110406
  Commit;

  DELETE FROM PLS_PST004_ADJ
      WHERE PERIOD = w_PERIOD
       AND RPT_GRP = sRPT_GRP;                    -- SAI110406
  Commit;

  ---------------------------------------------------------------------------------------
  --Insert data:
  -- << -- SAI104649 Begin --
  -- INSERT INTO PLS_PST001_EM
  --   ( PERIOD, PROFIT_CENTER, SITE, EM_ACCT_ID, ACCT_ID, CURRENCY, AMOUNT )
  --   SELECT CONCAT(A.YYYY, A.MONTH) AS PERIOD, A.PROFIT_CENTER, A.COMPANY_CODE AS SITE, A.ACCT_ID AS EM_ACCT_ID,
  --          (SELECT B.ACCT_ID FROM PLS_MAP003_EM_ACCT_MAPPING B WHERE B.YYYY = A.YYYY AND B.EM_ACCT_ID = A.ACCT_ID AND B.EM_ORG ='Y') AS ACCT_ID,
  --          'TWD' AS CURRENCY, SUM(A.AMOUNT * 1000) AS AMOUNT
  --     FROM PNL_MSA001_EM_DATA A
  --     WHERE A.YYYY = w_YYYY
  --       AND A.MONTH = w_MONTH
  --       AND A.AMOUNT <> 0
  --       AND A.ACCT_ID <> ' '
  --     GROUP BY YYYY, MONTH, PROFIT_CENTER, COMPANY_CODE, ACCT_ID
  --     ORDER BY YYYY, MONTH, PROFIT_CENTER, COMPANY_CODE, ACCT_ID;

  INSERT INTO PLS_PST001_EM
    ( PERIOD, PROFIT_CENTER, SITE, EM_ACCT_ID, ACCT_ID, CURRENCY, AMOUNT, RPT_GRP )
  --  SELECT CONCAT(A.YYYY, A.MONTH) AS PERIOD, A.PROFIT_CENTER, A.COMPANY_CODE AS SITE, A.ACCT_ID AS EM_ACCT_ID,    -- SAI120208  
    SELECT CONCAT(A.YYYY, A.MONTH) AS PERIOD, A.PROFIT_CENTER, A.COMPANY_CODE AS SITE, C.ACCT_ID_NEW AS EM_ACCT_ID,  -- SAI120208
           (SELECT B.ACCT_ID FROM PLS_MAP003_EM_ACCT_MAPPING B WHERE B.YYYY = A.YYYY AND B.EM_ACCT_ID = C.ACCT_ID_NEW AND B.EM_ORG ='Y') AS ACCT_ID,
           'TWD' AS CURRENCY, SUM(A.AMOUNT * 1000) AS AMOUNT, sRPT_GRP AS RPT_GRP
      FROM PNL_MSA001_EM_DATA A,
           PNL_MAP007_ACCMAPPING C
      WHERE A.YYYY = w_YYYY
	AND A.MONTH = w_MONTH
        AND A.AMOUNT <> 0
        AND A.ACCT_ID <> ' '
        AND A.ACCOUNT = C.ACCNO
        AND A.GRP_CODE = 'UG'                                                                                              -- SAI110406
      GROUP BY YYYY, MONTH, PROFIT_CENTER, COMPANY_CODE, A.ACCT_ID, C.ACCT_ID_NEW
      ORDER BY YYYY, MONTH, PROFIT_CENTER, COMPANY_CODE, A.ACCT_ID, C.ACCT_ID_NEW;
  -- ----- SAI104649 End -->>
  Commit;

  INSERT INTO PLS_PST002_TMP
    ( PERIOD, PROFIT_CENTER, SITE, EM_ACCT_ID, ACCT_ID, CURRENCY, AMOUNT, PROC_FLAG, RPT_GRP )
    SELECT PERIOD, PROFIT_CENTER, SITE, EM_ACCT_ID, ACCT_ID, CURRENCY, AMOUNT, 'N' AS PROC_FLAG, RPT_GRP
      FROM PLS_PST001_EM WHERE PERIOD = w_PERIOD
                           AND RPT_GRP = sRPT_GRP;             -- SAI110406


  --A-1.作業1: 將PC存在於 PLS_UPL001_PD_SITE 的資料, 依 PLS_UPL001_PD_SITE 所指定的SITE重新歸屬
  --
  for REC1 in ( SELECT PERIOD, PROFIT_CENTER, TO_SITE
                  FROM PLS_UPL001_PD_SITE A
                 WHERE PERIOD = w_PERIOD
                   AND (SELECT PLS_SITE_GRP FROM PNL_MAP006_SITE_MAPPING WHERE COMPANY_CODE = A.TO_SITE) = sRPT_GRP       -- SAI110406
              ) loop
    --
    for REC1a in ( SELECT PERIOD, PROFIT_CENTER, SITE, EM_ACCT_ID, ACCT_ID, CURRENCY, AMOUNT, RPT_GRP
                     FROM PLS_PST002_TMP
                    WHERE PERIOD = REC1.PERIOD
                      AND PROFIT_CENTER = REC1.PROFIT_CENTER
                      AND PROC_FLAG = 'N'
                      AND RPT_GRP = sRPT_GRP              -- SAI110406
                 ) loop
      --
      INSERT INTO PLS_PST003_PROC
        ( PERIOD, PROFIT_CENTER, SITE, ACCT_ID, CURRENCY, AMOUNT, PROC_MEMO, PROC_EM_ACCT_ID, FR_SITE, RPT_GRP )
        VALUES
        ( REC1a.PERIOD, REC1a.PROFIT_CENTER, REC1.TO_SITE, REC1a.ACCT_ID, REC1a.CURRENCY, REC1a.AMOUNT, 'A1', REC1a.EM_ACCT_ID,REC1a.SITE, REC1a.RPT_GRP );
      --
    end loop;  -- REC1a loop
    --
    UPDATE PLS_PST002_TMP
      SET PROC_FLAG = 'Y1'
      WHERE PERIOD = REC1.PERIOD
        AND PROFIT_CENTER = REC1.PROFIT_CENTER
        AND PROC_FLAG = 'N'
        AND RPT_GRP = sRPT_GRP;             -- SAI110406
    --
  end loop;  -- REC1 loop
  Commit;

  --A-2.作業2: 將PC存在於 PLS_UPL002_TSC 的資料移除, 採用 PLS_UPL002_TSC 所指定的內容
  --
  for REC2 in ( SELECT PERIOD, PROFIT_CENTER, TO_SITE, TO_ACCT_ID, CURRENCY, AMOUNT
                  FROM PLS_UPL002_TSC A
                 WHERE PERIOD = w_PERIOD
                   AND (SELECT PLS_SITE_GRP FROM PNL_MAP006_SITE_MAPPING WHERE COMPANY_CODE = A.TO_SITE) = sRPT_GRP       -- SAI110406
              ) loop
    --
    INSERT INTO PLS_PST003_PROC
      ( PERIOD, PROFIT_CENTER, SITE, ACCT_ID, CURRENCY, AMOUNT, PROC_MEMO, PROC_EM_ACCT_ID, FR_SITE, RPT_GRP )
      VALUES
      ( REC2.PERIOD, REC2.PROFIT_CENTER, REC2.TO_SITE, REC2.TO_ACCT_ID, REC2.CURRENCY, REC2.AMOUNT, 'A2', '', '', sRPT_GRP );
    --
  end loop;  -- REC2 loop
  Commit;

  UPDATE PLS_PST002_TMP A
    SET PROC_FLAG = 'Y2'
    WHERE PERIOD = w_PERIOD
      AND PROC_FLAG = 'N'
      AND RPT_GRP = sRPT_GRP              -- SAI110406
      AND EXISTS ( SELECT A.PERIOD, A.PROFIT_CENTER
                     FROM PLS_UPL002_TSC B
                    WHERE B.PERIOD = A.PERIOD
                      AND B.PROFIT_CENTER = A.PROFIT_CENTER
                      AND (SELECT PLS_SITE_GRP FROM PNL_MAP006_SITE_MAPPING WHERE COMPANY_CODE = B.TO_SITE) = sRPT_GRP);   -- SAI110406 

  Commit;

  --A-3.作業3: 依 PLS_UPL003_RATIO 的比例分攤到各Site
  --
  for REC3 in ( SELECT PERIOD, PROFIT_CENTER, SITE, EM_ACCT_ID, ACCT_ID, CURRENCY, AMOUNT, RPT_GRP
                  FROM PLS_PST002_TMP
                 WHERE PERIOD = w_PERIOD
                   AND PROC_FLAG = 'N'
                   AND RPT_GRP = sRPT_GRP              -- SAI110406
              ) loop
    --
    for REC3a in ( SELECT PERIOD, PROFIT_CENTER, EM_ACCT_ID, FR_SITE, TO_SITE, RATIO
                     FROM PLS_UPL003_RATIO A
                    WHERE PERIOD = REC3.PERIOD
                      AND PROFIT_CENTER = REC3.PROFIT_CENTER
                      AND EM_ACCT_ID = REC3.EM_ACCT_ID
                      AND FR_SITE = REC3.SITE
                      AND (SELECT PLS_SITE_GRP FROM PNL_MAP006_SITE_MAPPING WHERE COMPANY_CODE = A.FR_SITE) = sRPT_GRP       -- SAI110406
                      AND (SELECT PLS_SITE_GRP FROM PNL_MAP006_SITE_MAPPING WHERE COMPANY_CODE = A.TO_SITE) = sRPT_GRP       -- SAI110406
                 ) loop
      --
      sAMOUNT := ROUND(REC3.AMOUNT * REC3a.RATIO,5);
      --
      INSERT INTO PLS_PST003_PROC
        ( PERIOD, PROFIT_CENTER, SITE, ACCT_ID, CURRENCY, AMOUNT, PROC_MEMO, PROC_EM_ACCT_ID, FR_SITE, RPT_GRP )
        VALUES
        ( REC3a.PERIOD, REC3a.PROFIT_CENTER, REC3a.TO_SITE, REC3.ACCT_ID, REC3.CURRENCY, sAMOUNT, 'A3', REC3.EM_ACCT_ID, REC3.SITE, REC3.RPT_GRP );
      --
    end loop;  -- REC3a loop
    --
  end loop;  -- REC3 loop
  Commit;

  UPDATE PLS_PST002_TMP A
    SET PROC_FLAG = 'Y3'
    WHERE PERIOD = w_PERIOD
      AND PROC_FLAG = 'N'
      AND RPT_GRP = sRPT_GRP              -- SAI110406
      AND EXISTS ( SELECT A.PERIOD, A.PROFIT_CENTER, A.SITE, A.EM_ACCT_ID
                     FROM PLS_UPL003_RATIO B
                    WHERE B.PERIOD = A.PERIOD
                      AND B.PROFIT_CENTER = A.PROFIT_CENTER
                      AND B.FR_SITE = A.SITE
                      AND B.EM_ACCT_ID = A.EM_ACCT_ID
                      AND (SELECT PLS_SITE_GRP FROM PNL_MAP006_SITE_MAPPING WHERE COMPANY_CODE = B.FR_SITE) = sRPT_GRP       -- SAI110406
                      AND (SELECT PLS_SITE_GRP FROM PNL_MAP006_SITE_MAPPING WHERE COMPANY_CODE = B.TO_SITE) = sRPT_GRP       -- SAI110406
                 );
  Commit;

  --A-4.作業4: 依 PLS_UPL004_ALLOC_AMT_ADJ 的內容做調整,
  --           若 PLS_UPL004_ALLOC_AMT_ADJ 的 P/C, 出現在 PLS_UPL001_PD_SITE 中, 則挪開, 不做調整
  --
  for REC4 in ( SELECT UP_UNIT, PERIOD, PROFIT_CENTER, ACCT_ID, FR_SITE, TO_SITE, CURRENCY, AMOUNT
                  FROM PLS_UPL004_ALLOC_AMT_ADJ A
                 WHERE PERIOD = w_PERIOD
                   AND (SELECT PLS_SITE_GRP FROM PNL_MAP006_SITE_MAPPING WHERE COMPANY_CODE = A.FR_SITE) = sRPT_GRP       -- SAI110406
                   AND (SELECT PLS_SITE_GRP FROM PNL_MAP006_SITE_MAPPING WHERE COMPANY_CODE = A.TO_SITE) = sRPT_GRP       -- SAI110406
                   AND NOT EXISTS ( SELECT B.PROFIT_CENTER FROM PLS_UPL001_PD_SITE B
				     WHERE B.PERIOD = A.PERIOD
				       AND B.PROFIT_CENTER = A.PROFIT_CENTER 
                                       AND (SELECT PLS_SITE_GRP FROM PNL_MAP006_SITE_MAPPING WHERE COMPANY_CODE = B.TO_SITE) = sRPT_GRP       -- SAI110406
                                  )
              ) loop
    --
    sAMOUNT := REC4.AMOUNT * -1;
    --
    INSERT INTO PLS_PST003_PROC
      ( PERIOD, PROFIT_CENTER, SITE, ACCT_ID, CURRENCY, AMOUNT, PROC_MEMO, PROC_EM_ACCT_ID, FR_SITE, RPT_GRP )
      VALUES
      ( REC4.PERIOD, REC4.PROFIT_CENTER, REC4.FR_SITE, REC4.ACCT_ID, REC4.CURRENCY, sAMOUNT, 'A4F', '', REC4.FR_SITE, sRPT_GRP );
    --
    INSERT INTO PLS_PST003_PROC
      ( PERIOD, PROFIT_CENTER, SITE, ACCT_ID, CURRENCY, AMOUNT, PROC_MEMO, PROC_EM_ACCT_ID, FR_SITE, RPT_GRP )
      VALUES
      ( REC4.PERIOD, REC4.PROFIT_CENTER, REC4.TO_SITE, REC4.ACCT_ID, REC4.CURRENCY, REC4.AMOUNT, 'A4T', '', REC4.FR_SITE, sRPT_GRP );
    --
  end loop;  -- REC4 loop
  Commit;

  --A-5. 將 PLS_PST002_TMP.PROC_FLAG = 'N' 的資料轉進 PLS_PST003_PROC
  for REC5 in ( SELECT PERIOD, PROFIT_CENTER, SITE, EM_ACCT_ID, ACCT_ID, CURRENCY, AMOUNT, RPT_GRP
                  FROM PLS_PST002_TMP
                 WHERE PERIOD = w_PERIOD
                   AND PROC_FLAG = 'N'
                   AND RPT_GRP = sRPT_GRP              -- SAI110406
              ) loop
    --
    INSERT INTO PLS_PST003_PROC
      ( PERIOD, PROFIT_CENTER, SITE, ACCT_ID, CURRENCY, AMOUNT, PROC_MEMO, PROC_EM_ACCT_ID, FR_SITE, RPT_GRP )
      VALUES
      ( REC5.PERIOD, REC5.PROFIT_CENTER, REC5.SITE, REC5.ACCT_ID, REC5.CURRENCY, REC5.AMOUNT, 'A5', REC5.EM_ACCT_ID, REC5.SITE, REC5.RPT_GRP );
    --
  end loop;  -- REC5 loop
  Commit;

  --
  INSERT INTO PLS_PST004_ADJ
    ( PERIOD, PROFIT_CENTER, SITE, ACCT_ID, CURRENCY, AMOUNT, RPT_GRP )
    SELECT PERIOD, PROFIT_CENTER, SITE, ACCT_ID, CURRENCY, SUM(AMOUNT), sRPT_GRP AS RPT_GRP
      FROM PLS_PST003_PROC
     WHERE PERIOD = w_PERIOD
       AND RPT_GRP = sRPT_GRP              -- SAI110406
     GROUP BY PERIOD, PROFIT_CENTER, SITE, ACCT_ID, CURRENCY;

  ---------------------------------------------------------------------------------------
  sPROC_NAME := 'PLS_PLS001_ADJ_BY_SITE_UG';
  sRUN_SEQ   := '000020';
  sRUN_DESC  := 'End';

  --Insert Log
  INSERT INTO PLS_PST000_LOG
      ( PROC_NAME, RUN_SEQ, RUN_DESC, PARAMETER_DESC )
    VALUES
      ( sPROC_NAME, sRUN_SEQ, sRUN_DESC, sPARAMETER_DESC );
  Commit;


END PLS_PLS001_ADJ_BY_SITE_UG;
/

