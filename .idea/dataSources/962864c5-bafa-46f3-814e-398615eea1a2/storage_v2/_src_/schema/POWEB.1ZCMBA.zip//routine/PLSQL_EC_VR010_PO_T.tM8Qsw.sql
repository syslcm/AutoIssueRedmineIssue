create PROCEDURE PLSQL_EC_VR010_PO_T (
	inCompany  in VARCHAR2,
	f_YYYYMMDD in VARCHAR2,
	t_YYYYMMDD in VARCHAR2
)
AUTHID DEFINER
is
	/*
	處理資料並放到正式 table
	KPI extricity job 中最後抓 po data, 且此處理 EC_VR020_RPT_PO & EC_VR021_RPT_TX
	*/
	iTracePoint         integer;
	cErrorText          varchar2(500);
	nEXEC_PERIOD        EC_VR010_PO_T.EXEC_PERIOD%TYPE;
	nFR_DATE            EC_VR010_PO_T.CREATE_DATE%TYPE;
	nTO_DATE            EC_VR010_PO_T.CREATE_DATE%TYPE;
	nCREATE_DATE        EC_VR010_PO_T.CREATE_DATE%TYPE;
	nExistFlag          varchar2(1);
	nGRQTY              EC_VR020_RPT_PO.ACCUM_GRQTY%TYPE;
	nSTD_M              EC_VR020_RPT_PO.REBATE_STD_M%TYPE;
	nSTD_Q              EC_VR020_RPT_PO.REBATE_STD_Q%TYPE;
	nPICKUP             EC_VR020_RPT_PO.REBATE_PICKUP%TYPE;
	nSOLD               EC_VR020_RPT_PO.ACCUM_SOLD%TYPE;
	nWARRANTY           EC_VR020_RPT_PO.ACCUM_WARRANTY%TYPE;
	nSTD_FLAG           EC_VR020_RPT_PO.STD_FLAG%TYPE;
	nPICKUP_FLAG        EC_VR020_RPT_PO.PICKUP_FLAG%TYPE;
	nLAST_GR_DATE       EC_VR020_RPT_PO.LAST_GR_DATE%TYPE;
BEGIN
	iTracePoint := 100;
	cErrorText := '';
	nEXEC_PERIOD := null;
	nCREATE_DATE := null;
	begin
		select * into nCREATE_DATE from (
			select min(CREATE_DATE) from EC_VR010_PO_T
				where CREATE_DATE <> t_YYYYMMDD
		) where rownum <= 1;
	exception
		when others then
			nCREATE_DATE := null;
	end;
	-- OK get data
	if nCREATE_DATE is null then
		iTracePoint := 200;
		select distinct EXEC_PERIOD into nEXEC_PERIOD from EC_VR010_PO_T
			where CREATE_DATE = t_YYYYMMDD;
		nFR_DATE := substr(nEXEC_PERIOD,1,8);
		nTO_DATE := substr(nEXEC_PERIOD,9,8);
		-- 清舊的正式資料
		iTracePoint := 210;
		delete from EC_VR010_PO
			where PO_DATE >= nFR_DATE and PO_DATE <= nTO_DATE;
		commit;
		insert into EC_VR010_PO
			select * from EC_VR010_PO_T where PO_DATE >= nFR_DATE and PO_DATE <= nTO_DATE;
		commit;
		-----------------------------------------------------------------------------------------------------------
		-- 處理 EC_VR020_RPT_PO
		iTracePoint := 300;
		for rec1 in (
			select distinct * from (
				select COMPANY_CODE, PO_NO, PO_LINE, VENDOR_CODE, VENDOR_NAME, PART_NO, PART_DESC, MFG_NAME, PO_DATE, PO_QTY, PO_PRICE
				from EC_VR010_PO where PO_DATE >= nFR_DATE and PO_DATE <= nTO_DATE
				union all
				select a.COMPANY_CODE, a.PO_NO, a.PO_LINE, b.VENDOR_CODE, b.VENDOR_NAME, b.PART_NO, b.PART_DESC, b.MFG_NAME, b.PO_DATE, b.PO_QTY, b.PO_PRICE
				from EC_VR011_GR a, EC_VR010_PO b where a.GR_DATE >= nFR_DATE and a.GR_DATE <= nTO_DATE
				and a.COMPANY_CODE = b.COMPANY_CODE and a.PO_NO = b.PO_NO and a.PO_LINE = b.PO_LINE
				union all
				select COMPANY_CODE, PO_NO, PO_LINE, VENDOR_CODE, VENDOR_NAME, PART_NO, PART_DESC, MFG_NAME, PO_DATE, PO_QTY, PO_PRICE
				from EC_VR012_SOLD where GI_DATE >= nFR_DATE and GI_DATE <= nTO_DATE
				union all
				select COMPANY_CODE, PO_NO, PO_LINE, VENDOR_CODE, VENDOR_NAME, PART_NO, PART_DESC, MFG_NAME, PO_DATE, PO_QTY, PO_PRICE
				from EC_VR013_WARRANTY where ADJ_DATE >= nFR_DATE and ADJ_DATE <= nTO_DATE
			)
		) loop
			cErrorText := rec1.PO_NO || rec1.PO_LINE;
			nExistFlag := 'N';
			nGRQTY := 0;
			nSTD_M := 0;
			nSTD_Q := 0;
			nPICKUP := 0;
			nSOLD := 0;
			nWARRANTY := 0;
			nSTD_FLAG := 'N';
			nPICKUP_FLAG := 'N';
			nLAST_GR_DATE := null;
			-- PO
			iTracePoint := 310;
			begin
				select * into nSTD_M, nSTD_Q, nPICKUP, nSTD_FLAG, nPICKUP_FLAG from (
					select a.REBATE_STD_M, a.REBATE_STD_Q, a.REBATE_PICKUP, a.STD_FLAG, a.PICKUP_FLAG
					from EC_VR010_PO a where a.COMPANY_CODE = rec1.COMPANY_CODE and a.PO_NO = rec1.PO_NO and a.PO_LINE = rec1.PO_LINE
			);
			exception
				when others then
					nSTD_M := 0;
					nSTD_Q := 0;
					nPICKUP := 0;
			end;
			-- GR
			iTracePoint := 320;
			begin
				select * into nGRQTY, nLAST_GR_DATE from (
					select sum(GR_QTY), max(GR_DATE) from EC_VR011_GR
					where COMPANY_CODE = rec1.COMPANY_CODE and PO_NO = rec1.PO_NO and PO_LINE = rec1.PO_LINE
				);
			exception
				when others then
					nGRQTY := 0;
					nLAST_GR_DATE := null;
			end;
			-- SOLD
			iTracePoint := 330;
			begin
				select * into nSOLD from (
					select sum(REBATE_PRICE) from EC_VR012_SOLD
					where COMPANY_CODE = rec1.COMPANY_CODE and PO_NO = rec1.PO_NO and PO_LINE = rec1.PO_LINE
				);
			exception
				when others then
					nSOLD := 0;
			end;
			-- WARRANTY
			iTracePoint := 340;
			begin
				select * into nWARRANTY from (
					select sum(DIFF_AMT) from EC_VR013_WARRANTY
					where COMPANY_CODE = rec1.COMPANY_CODE and PO_NO = rec1.PO_NO and PO_LINE = rec1.PO_LINE
				);
			exception
				when others then
					nWARRANTY := 0;
			end;
			-- nExistFlag
			iTracePoint := 350;
			begin
				select * into nExistFlag from (
					select 'Y' from EC_VR020_RPT_PO
					where COMPANY_CODE = rec1.COMPANY_CODE and PO_NO = rec1.PO_NO and PO_LINE = rec1.PO_LINE
				);
			exception
				when others then
					nExistFlag := 'N';
			end;
			-- modify EC_VR020_RPT_PO
			if nExistFlag = 'Y' then
				iTracePoint := 351;
				update EC_VR020_RPT_PO set
					ACCUM_GRQTY = nvl(nGRQTY,0),
					REBATE_STD_M = nvl(nSTD_M,0),
					REBATE_STD_Q = nvl(nSTD_Q,0),
					REBATE_PICKUP = nvl(nPICKUP,0),
					ACCUM_SOLD = nvl(nSOLD,0),
					ACCUM_WARRANTY = nvl(nWARRANTY,0),
					STD_FLAG = nSTD_FLAG,
					PICKUP_FLAG = nPICKUP_FLAG,
					LAST_GR_DATE = nLAST_GR_DATE
				where COMPANY_CODE = rec1.COMPANY_CODE and PO_NO = rec1.PO_NO and PO_LINE = rec1.PO_LINE;
			else
				iTracePoint := 352;
				insert into EC_VR020_RPT_PO ( COMPANY_CODE, PO_NO, PO_LINE, VENDOR_CODE, VENDOR_NAME,
					PART_NO, PART_DESC, MFG_NAME, PO_DATE, PO_QTY, PO_PRICE,
					ACCUM_GRQTY, REBATE_STD_M, REBATE_STD_Q, REBATE_PICKUP, ACCUM_SOLD, ACCUM_WARRANTY,
					STD_FLAG, PICKUP_FLAG, LAST_GR_DATE
				) values (
					rec1.COMPANY_CODE, rec1.PO_NO, rec1.PO_LINE, rec1.VENDOR_CODE, rec1.VENDOR_NAME,
					rec1.PART_NO, rec1.PART_DESC, rec1.MFG_NAME, rec1.PO_DATE, rec1.PO_QTY, rec1.PO_PRICE,
					nvl(nGRQTY,0), nvl(nSTD_M,0), nvl(nSTD_Q,0), nvl(nPICKUP,0), nvl(nSOLD,0), nvl(nWARRANTY,0),
					nSTD_FLAG, nPICKUP_FLAG, nLAST_GR_DATE
				);
			end if;
		end loop;
		commit;
		-----------------------------------------------------------------------------------------------------------
		-- 處理 EC_VR021_RPT_TX
		iTracePoint := 400;
		delete from EC_VR021_RPT_TX where TX_DATE >= nFR_DATE and TX_DATE <= nTO_DATE;
		commit;
		-- GR
		iTracePoint := 410;
		insert into EC_VR021_RPT_TX ( COMPANY_CODE, TX_NO, TX_ITEM, TX_DATE, TX_TYPE, PO_NO, PO_LINE,
			VENDOR_CODE, VENDOR_NAME, PART_NO, PART_DESC, MFG_NAME, PO_DATE, PO_QTY, PO_PRICE,
			TX_QTY, REBATE_STD_M, REBATE_STD_Q, REBATE_PICKUP, REBATE_SOLD, REBATE_WARRANTY,
			STD_FLAG, PICKUP_FLAG )
		select distinct a.COMPANY_CODE, a.GR_NO, a.GR_ITEM, a.GR_DATE, 'GR', a.PO_NO, a.PO_LINE,
			b.VENDOR_CODE, b.VENDOR_NAME, b.PART_NO, b.PART_DESC, b.MFG_NAME, b.PO_DATE, b.PO_QTY, b.PO_PRICE,
			a.GR_QTY, a.REBATE_STD_M, a.REBATE_STD_Q, a.REBATE_PICKUP, 0, 0,
			a.STD_FLAG, a.PICKUP_FLAG
		from EC_VR011_GR a, EC_VR010_PO b
		where a.GR_DATE >= nFR_DATE and a.GR_DATE <= nTO_DATE
		and a.COMPANY_CODE = b.COMPANY_CODE and a.PO_NO = b.PO_NO and a.PO_LINE = b.PO_LINE;
		commit;
		-- SOLD
		iTracePoint := 420;
		insert into EC_VR021_RPT_TX ( COMPANY_CODE, TX_NO, TX_ITEM, TX_DATE, TX_TYPE, PO_NO, PO_LINE,
			VENDOR_CODE, VENDOR_NAME, PART_NO, PART_DESC, MFG_NAME, PO_DATE, PO_QTY, PO_PRICE,
			TX_QTY, REBATE_STD_M, REBATE_STD_Q, REBATE_PICKUP, REBATE_SOLD, REBATE_WARRANTY )
		select * from (
			select COMPANY_CODE, GI_DATE as TX_NO, trim(to_char(sum(1),'0000')) as TX_ITEM, GI_DATE as TX_DATE, 'SOLD' as TX_TYPE, PO_NO, PO_LINE,
				VENDOR_CODE, VENDOR_NAME, PART_NO, PART_DESC, MFG_NAME, PO_DATE, PO_QTY, PO_PRICE,
				sum(1) as TX_QTY, 0 as REBATE_STD_M, 0 as REBATE_STD_Q, 0 as REBATE_PICKUP, sum(REBATE_PRICE) as REBATE_SOLD, 0 as REBATE_WARRANTY
			from EC_VR012_SOLD where GI_DATE >= nFR_DATE and GI_DATE <= nTO_DATE
			group by COMPANY_CODE, GI_DATE, PO_NO, PO_LINE, VENDOR_CODE, VENDOR_NAME, PART_NO, PART_DESC, MFG_NAME, PO_DATE, PO_QTY, PO_PRICE
		);
		commit;
		-- WARRANTY
		iTracePoint := 430;
		insert into EC_VR021_RPT_TX ( COMPANY_CODE, TX_NO, TX_ITEM, TX_DATE, TX_TYPE, PO_NO, PO_LINE,
			VENDOR_CODE, VENDOR_NAME, PART_NO, PART_DESC, MFG_NAME, PO_DATE, PO_QTY, PO_PRICE,
			TX_QTY, REBATE_STD_M, REBATE_STD_Q, REBATE_PICKUP, REBATE_SOLD, REBATE_WARRANTY )
		select * from (
			select COMPANY_CODE, ADJ_DATE as TX_NO, trim(to_char(sum(1),'0000')) as TX_ITEM, ADJ_DATE as TX_DATE, 'WARRANTY' as TX_TYPE, PO_NO, PO_LINE,
				VENDOR_CODE, VENDOR_NAME, PART_NO, PART_DESC, MFG_NAME, PO_DATE, PO_QTY, PO_PRICE,
				sum(QTY_STK) as TX_QTY, 0 as REBATE_STD_M, 0 as REBATE_STD_Q, 0 as REBATE_PICKUP, 0 as REBATE_SOLD, sum(DIFF_AMT) as REBATE_WARRANTY
			from EC_VR013_WARRANTY where ADJ_DATE >= nFR_DATE and ADJ_DATE <= nTO_DATE
			group by COMPANY_CODE, ADJ_DATE, PO_NO, PO_LINE, VENDOR_CODE, VENDOR_NAME, PART_NO, PART_DESC, MFG_NAME, PO_DATE, PO_QTY, PO_PRICE
		);
		commit;
		-----------------------------------------------------------------------------------------------------------
		-- 處理 EC_VR022_RPT_TX_SUM_D
		iTracePoint := 500;
		delete from EC_VR022_RPT_TX_SUM_D where TX_DATE >= nFR_DATE and TX_DATE <= nTO_DATE;
		commit;
		iTracePoint := 510;
		insert into EC_VR022_RPT_TX_SUM_D ( COMPANY_CODE, VENDOR_CODE, TX_DATE, VENDOR_NAME,
			TX_STD_M, TX_STD_Q, TX_PICKUP,
			PO_STD_M, PO_STD_Q, PO_PICKUP,
			REBATE_SOLD, REBATE_WARRANTY, IR_AMT, DIFF_TX, DIFF_PO )
		select COMPANY_CODE, VENDOR_CODE, TX_DATE, VENDOR_NAME,
			nvl(sum(TX_STD_M),0), nvl(sum(TX_STD_Q),0), nvl(sum(TX_PICKUP),0),
			nvl(sum(PO_STD_M),0), nvl(sum(PO_STD_Q),0), nvl(sum(PO_PICKUP),0),
			nvl(sum(REBATE_SOLD),0), nvl(sum(REBATE_WARRANTY),0), nvl(sum(IR_AMT),0), 0, 0
		from (
			-- PO
			select COMPANY_CODE, VENDOR_CODE, PO_DATE as TX_DATE, VENDOR_NAME,
				0 as TX_STD_M, 0 as TX_STD_Q, 0 as TX_PICKUP,
				REBATE_STD_M as PO_STD_M, REBATE_STD_Q as PO_STD_Q, REBATE_PICKUP as PO_PICKUP,
				0 as REBATE_SOLD, 0 as REBATE_WARRANTY, 0 as IR_AMT
			from EC_VR010_PO where PO_DATE >= nFR_DATE and PO_DATE <= nTO_DATE
			union all
			-- GR
			select a.COMPANY_CODE, b.VENDOR_CODE, a.GR_DATE as TX_DATE, b.VENDOR_NAME,
				a.REBATE_STD_M as TX_STD_M, a.REBATE_STD_Q as TX_STD_Q, a.REBATE_PICKUP as TX_PICKUP,
				0 as PO_STD_M, 0 as PO_STD_Q, 0 as PO_PICKUP,
				0 as REBATE_SOLD, 0 as REBATE_WARRANTY, 0 as IR_AMT
			from EC_VR011_GR a, EC_VR010_PO b where a.GR_DATE >= nFR_DATE and a.GR_DATE <= nTO_DATE
			and a.COMPANY_CODE = b.COMPANY_CODE and a.PO_NO = b.PO_NO and a.PO_LINE = b.PO_LINE
			union all
			-- SOLD
			select COMPANY_CODE, VENDOR_CODE, GI_DATE as TX_DATE, VENDOR_NAME,
				0 as TX_STD_M, 0 as TX_STD_Q, 0 as TX_PICKUP,
				0 as PO_STD_M, 0 as PO_STD_Q, 0 as PO_PICKUP,
				REBATE_PRICE as REBATE_SOLD, 0 as REBATE_WARRANTY, 0 as IR_AMT
			from EC_VR012_SOLD where GI_DATE >= nFR_DATE and GI_DATE <= nTO_DATE
			union all
			-- WARRANTY
			select COMPANY_CODE, VENDOR_CODE, ADJ_DATE as TX_DATE, VENDOR_NAME,
				0 as TX_STD_M, 0 as TX_STD_Q, 0 as TX_PICKUP,
				0 as PO_STD_M, 0 as PO_STD_Q, 0 as PO_PICKUP,
				0 as REBATE_SOLD, DIFF_AMT as REBATE_WARRANTY, 0 as IR_AMT
			from EC_VR013_WARRANTY where ADJ_DATE >= nFR_DATE and ADJ_DATE <= nTO_DATE
			-- IR
			union all
			select COMPANY_CODE, VENDOR_CODE, DOC_DATE as TX_DATE, VENDOR_NAME,
				0 as TX_STD_M, 0 as TX_STD_Q, 0 as TX_PICKUP,
				0 as PO_STD_M, 0 as PO_STD_Q, 0 as PO_PICKUP,
				0 as REBATE_SOLD, 0 as REBATE_WARRANTY, IR_AMT
			from EC_VR014_IR where DOC_DATE >= nFR_DATE and DOC_DATE <= nTO_DATE
		) group by COMPANY_CODE, VENDOR_CODE, TX_DATE, VENDOR_NAME;
		commit;
		iTracePoint := 510;
		update EC_VR022_RPT_TX_SUM_D set
			DIFF_TX = ( IR_AMT - ( TX_STD_M + TX_STD_Q + TX_PICKUP + REBATE_SOLD + REBATE_WARRANTY ) ),
			DIFF_PO = ( IR_AMT - ( PO_STD_M + PO_STD_Q + PO_PICKUP + REBATE_SOLD + REBATE_WARRANTY ) )
		where TX_DATE >= nFR_DATE and TX_DATE <= nTO_DATE;
		commit;
	-----------------------------------------------------------------------------------------------------------
	-- nCREATE_DATE not null -> fail data
	else
		iTracePoint := 900;
		cErrorText := 'CREATE_DATE get ' || nCREATE_DATE;
		MAIL_FILE_BIDBDBADMIN(in_to_name=>'minhorng@ms.usi.com.tw',subject   => '[KPI] PL/SQL PLSQL_EC_VR010_PO_T ERROR - Company: ' || inCompany, message => '[PLSQL_EC_VR010_PO_T], The tracepoint is  ' || to_char(iTracePoint) || ' and ErrorText=' || cErrorText) ;
	end if;
EXCEPTION
	WHEN OTHERS THEN
		cErrorText := cErrorText || '>' || SQLERRM();
		MAIL_FILE_BIDBDBADMIN(in_to_name=>'minhorng@ms.usi.com.tw',subject   => '[KPI] PL/SQL PLSQL_EC_VR010_PO_T ERROR - Company: ' || inCompany, message => '[PLSQL_EC_VR010_PO_T], The tracepoint is  ' || to_char(iTracePoint) || ' and ErrorText=' || cErrorText) ;
		rollback;
END;
/

