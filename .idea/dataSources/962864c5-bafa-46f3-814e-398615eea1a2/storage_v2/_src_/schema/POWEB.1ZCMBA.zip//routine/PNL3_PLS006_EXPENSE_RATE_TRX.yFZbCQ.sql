create PROCEDURE       PNL3_PLS006_EXPENSE_RATE_TRX (
  --inCompany  in VARCHAR2,
  inPeriod in VARCHAR2
  --此程式在產生依SITE+PROFIT CENTER裡的END CUSTOMER REVENUE比率,原本在測試時期供費用比率計算
  --現在供GM (也就是COGS)的使用,只有特定PROFIT CENTER才會參考此TABLE
)
AUTHID DEFINER
is


  CURSOR C_PNL2_REVENUE is
     SELECT COMPANY_CODE,PROFIT_CENTER,SUM(AMT_TWD) AMT_TWD
     FROM  PNL3_TRX001_COPA
     WHERE PERIOD = inPeriod 
     AND AREA1 = '1'
     AND AREA2 = '1'
     AND AREA3 = '0'
     --AND SOURCE <> 'UPL001'
     GROUP BY COMPANY_CODE,PROFIT_CENTER;
     
     a_Rate          PNL3_MAP001_CUSTOMER_RATE.RATE%TYPE;
 BEGIN
   DELETE FROM PNL3_MAP001_SITE_RATE
   WHERE Period = inPeriod ;
   Commit;
   

   FOR REC1 in C_PNL2_REVENUE Loop
        FOR REC2 in (SELECT COMPANY_CODE,END_CUSTOMER_ID,SUM(AMT_TWD) AMT_TWD FROM PNL3_TRX001_COPA 
                      WHERE PROFIT_CENTER = REC1.PROFIT_CENTER
                        AND PERIOD = inPeriod
                        AND COMPANY_CODE = REC1.COMPANY_CODE
                        AND AREA1 = '1'
                        AND AREA2 = '1'
                        AND AREA3 = '0'
                        AND AMT_TWD <> 0
                        --AND SOURCE <> 'UPL001'
                        GROUP BY COMPANY_CODE,END_CUSTOMER_ID ORDER BY AMT_TWD DESC) Loop
            --2008/12/4 因UPLOAD的資料未上,所以只有COGS沒有Reverue,因此要加入判斷REC1.AMT_TWD <> 0,否則會有問題,待user 上傳後即無問題
            if REC1.AMT_TWD = 0 THEN
              a_Rate := 0;
            ELSE            
              a_Rate :=  REC2.AMT_TWD / REC1.AMT_TWD;
            END IF;   
               

            INSERT INTO PNL3_MAP001_SITE_RATE
                  (PERIOD   ,PROFIT_CENTER   ,COMPANY_CODE   ,END_CUSTOMER_ID ,
                   R_KIND   ,AREA1           ,AREA2          ,AREA3           ,
                   RATE     ,CHANGE_DATE
                  )
                  VALUES (
                   inPeriod ,REC1.PROFIT_CENTER , REC2.COMPANY_CODE,REC2.END_CUSTOMER_ID,
                   'PL01'   ,'4'                 , '1'              ,'1'                  ,
                   a_Rate   ,sysdate
                  );
            COMMIT;      
            INSERT INTO PNL3_MAP001_SITE_RATE
                  (PERIOD   ,PROFIT_CENTER   ,COMPANY_CODE   ,END_CUSTOMER_ID ,
                   R_KIND   ,AREA1           ,AREA2          ,AREA3           ,
                   RATE     ,CHANGE_DATE
                  )
                  VALUES (
                   inPeriod ,REC1.PROFIT_CENTER , REC2.COMPANY_CODE,REC2.END_CUSTOMER_ID,
                   'PL01'   ,'4'                 , '1'             , '2'                  ,
                   a_Rate   ,sysdate
                  );
            COMMIT;      
            INSERT INTO PNL3_MAP001_SITE_RATE
                  (PERIOD   ,PROFIT_CENTER   ,COMPANY_CODE   ,END_CUSTOMER_ID ,
                   R_KIND   ,AREA1           ,AREA2          ,AREA3           ,
                   RATE     ,CHANGE_DATE
                  )
                  VALUES (
                   inPeriod ,REC1.PROFIT_CENTER , REC2.COMPANY_CODE,REC2.END_CUSTOMER_ID,
                   'PL01'   ,'4'                 , '1'             , '3'                  ,
                   a_Rate   ,sysdate
                  );
            COMMIT;      
            INSERT INTO PNL3_MAP001_SITE_RATE
                  (PERIOD   ,PROFIT_CENTER   ,COMPANY_CODE   ,END_CUSTOMER_ID ,
                   R_KIND   ,AREA1           ,AREA2          ,AREA3           ,
                   RATE     ,CHANGE_DATE
                  )
                  VALUES (
                   inPeriod ,REC1.PROFIT_CENTER , REC2.COMPANY_CODE,REC2.END_CUSTOMER_ID,
                   'PL01'   ,'4'                 , '1'              ,'4'                  ,
                   a_Rate   ,sysdate
                  );  
            COMMIT;      
            INSERT INTO PNL3_MAP001_SITE_RATE
                  (PERIOD   ,PROFIT_CENTER   ,COMPANY_CODE   ,END_CUSTOMER_ID ,
                   R_KIND   ,AREA1           ,AREA2          ,AREA3           ,
                   RATE     ,CHANGE_DATE
                  )
                  VALUES (
                   inPeriod ,REC1.PROFIT_CENTER , REC2.COMPANY_CODE,REC2.END_CUSTOMER_ID,
                   'PL01'   ,'4'                 , '1'             , '5'                  ,
                   a_Rate   ,sysdate
                  );
            COMMIT;      
            INSERT INTO PNL3_MAP001_SITE_RATE
                  (PERIOD   ,PROFIT_CENTER   ,COMPANY_CODE   ,END_CUSTOMER_ID ,
                   R_KIND   ,AREA1           ,AREA2          ,AREA3           ,
                   RATE     ,CHANGE_DATE
                  )
                  VALUES (
                   inPeriod ,REC1.PROFIT_CENTER , REC2.COMPANY_CODE,REC2.END_CUSTOMER_ID,
                   'PL01'   ,'4'                 , '1'              ,'6'                  ,
                   a_Rate   ,sysdate
                  );    
            COMMIT;      
            INSERT INTO PNL3_MAP001_SITE_RATE
                  (PERIOD   ,PROFIT_CENTER   ,COMPANY_CODE   ,END_CUSTOMER_ID ,
                   R_KIND   ,AREA1           ,AREA2          ,AREA3           ,
                   RATE     ,CHANGE_DATE
                  )
                  VALUES (
                   inPeriod ,REC1.PROFIT_CENTER , REC2.COMPANY_CODE,REC2.END_CUSTOMER_ID,
                   'PL01'   ,'4'                 , '1'             , '7'                  ,
                   a_Rate   ,sysdate
                  );  
            COMMIT;      
            INSERT INTO PNL3_MAP001_SITE_RATE
                  (PERIOD   ,PROFIT_CENTER   ,COMPANY_CODE   ,END_CUSTOMER_ID ,
                   R_KIND   ,AREA1           ,AREA2          ,AREA3           ,
                   RATE     ,CHANGE_DATE
                  )
                  VALUES (
                   inPeriod ,REC1.PROFIT_CENTER , REC2.COMPANY_CODE,REC2.END_CUSTOMER_ID,
                   'PL01'   ,'4'                 , '2'              ,'1'                  ,
                   a_Rate   ,sysdate
                  );
            COMMIT;      
            INSERT INTO PNL3_MAP001_SITE_RATE
                  (PERIOD   ,PROFIT_CENTER   ,COMPANY_CODE   ,END_CUSTOMER_ID ,
                   R_KIND   ,AREA1           ,AREA2          ,AREA3           ,
                   RATE     ,CHANGE_DATE
                  )
                  VALUES (
                   inPeriod ,REC1.PROFIT_CENTER , REC2.COMPANY_CODE,REC2.END_CUSTOMER_ID,
                   'PL01'   ,'4'                 , '2'             , '2'                  ,
                   a_Rate   ,sysdate
                  );
            COMMIT;      
            INSERT INTO PNL3_MAP001_SITE_RATE
                  (PERIOD   ,PROFIT_CENTER   ,COMPANY_CODE   ,END_CUSTOMER_ID ,
                   R_KIND   ,AREA1           ,AREA2          ,AREA3           ,
                   RATE     ,CHANGE_DATE
                  )
                  VALUES (
                   inPeriod ,REC1.PROFIT_CENTER , REC2.COMPANY_CODE,REC2.END_CUSTOMER_ID,
                   'PL01'   ,'4'                 , '2'              ,'3'                  ,
                   a_Rate   ,sysdate
                  );
            COMMIT;      
            INSERT INTO PNL3_MAP001_SITE_RATE
                  (PERIOD   ,PROFIT_CENTER   ,COMPANY_CODE   ,END_CUSTOMER_ID ,
                   R_KIND   ,AREA1           ,AREA2          ,AREA3           ,
                   RATE     ,CHANGE_DATE
                  )
                  VALUES (
                   inPeriod ,REC1.PROFIT_CENTER , REC2.COMPANY_CODE,REC2.END_CUSTOMER_ID,
                   'PL01'   ,'4'                 , '2'             , '4'                  ,
                   a_Rate   ,sysdate
                  ); 
            COMMIT;      
            INSERT INTO PNL3_MAP001_SITE_RATE
                  (PERIOD   ,PROFIT_CENTER   ,COMPANY_CODE   ,END_CUSTOMER_ID ,
                   R_KIND   ,AREA1           ,AREA2          ,AREA3           ,
                   RATE     ,CHANGE_DATE
                  )
                  VALUES (
                   inPeriod ,REC1.PROFIT_CENTER , REC2.COMPANY_CODE,REC2.END_CUSTOMER_ID,
                   'PL01'   ,'4'                 , '3'              ,'1'                  ,
                   a_Rate   ,sysdate
                  );
            COMMIT;      
            INSERT INTO PNL3_MAP001_SITE_RATE
                  (PERIOD   ,PROFIT_CENTER   ,COMPANY_CODE   ,END_CUSTOMER_ID ,
                   R_KIND   ,AREA1           ,AREA2          ,AREA3           ,
                   RATE     ,CHANGE_DATE
                  )
                  VALUES (
                   inPeriod ,REC1.PROFIT_CENTER , REC2.COMPANY_CODE,REC2.END_CUSTOMER_ID,
                   'PL01'   ,'4'                 , '3'             , '2'                  ,
                   a_Rate   ,sysdate
                  );
            COMMIT;      
            INSERT INTO PNL3_MAP001_SITE_RATE
                  (PERIOD   ,PROFIT_CENTER   ,COMPANY_CODE   ,END_CUSTOMER_ID ,
                   R_KIND   ,AREA1           ,AREA2          ,AREA3           ,
                   RATE     ,CHANGE_DATE
                  )
                  VALUES (
                   inPeriod ,REC1.PROFIT_CENTER , REC2.COMPANY_CODE,REC2.END_CUSTOMER_ID,
                   'PL01'   ,'4'                 , '3'              ,'3'                  ,
                   a_Rate   ,sysdate
                  );
            COMMIT;      
            INSERT INTO PNL3_MAP001_SITE_RATE
                  (PERIOD   ,PROFIT_CENTER   ,COMPANY_CODE   ,END_CUSTOMER_ID ,
                   R_KIND   ,AREA1           ,AREA2          ,AREA3           ,
                   RATE     ,CHANGE_DATE
                  )
                  VALUES (
                   inPeriod ,REC1.PROFIT_CENTER , REC2.COMPANY_CODE,REC2.END_CUSTOMER_ID,
                   'PL01'   ,'4'                 , '3'             , '4'                  ,
                   a_Rate   ,sysdate
                  );
            COMMIT;       
        END LOOP;
   END LOOP;
   

    
END PNL3_PLS006_EXPENSE_RATE_TRX;
/

