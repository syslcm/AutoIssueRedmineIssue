create PROCEDURE test_pls_del (p_array_size IN PLS_INTEGER DEFAULT 100)
IS
   type row_type is table of rowid index by binary_integer;
   rows row_type;
 begin
    select rowid rid bulk collect into rows FROM T1  ;
    for i in 1..rows.count
   loop
        --dbms_output.put_line(rows(i).rowid);
        DELETE T1 WHERE ROWID = rows(i) ;
   end loop;
END test_pls_del;
/

