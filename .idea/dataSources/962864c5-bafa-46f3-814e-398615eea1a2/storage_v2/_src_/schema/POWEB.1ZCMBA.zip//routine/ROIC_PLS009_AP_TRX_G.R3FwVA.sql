create PROCEDURE       ROIC_PLS009_AP_TRX_G (
  inCompany  in VARCHAR2,
  f_YYYYMMDD in VARCHAR2,
  t_YYYYMMDD in VARCHAR2
)
AUTHID DEFINER
is
/*********************************************************************
  PROG-ID      : ROIC_PLS009_AP_TRX_G
  PROG-ACTION  : AP Summary Process
  Author       : Patty
  Date         : 2019/07/04 
  OA No.       : SAI101564
**********************************************************************/
  f_PERIOD           VARCHAR2(6);
  t_PERIOD           VARCHAR2(6);
  
  CURSOR C_TRX is
       Select COMPANY_CODE, 
              PERIOD,
              NVL(PROFIT_CENTER,' ') AS PROFIT_CENTER,
              VENDOR_ID,
              RELATED_PARTY,
              ACCOUNT_NO,
              CURRENCY_LOC,
              CURRENCY_DOC,
              NVL(SUM(AMOUNT_LOC),0) AS AMOUNT_LOC,
              NVL(SUM(AMOUNT_DOC),0) AS AMOUNT_DOC,
              NVL(SUM(EVALUATION_AMT),0) AS EVALUATION_AMT              
         From ( Select /*+INDEX (KPI_SAP006_AP_TRX KPI_SAP006_AP_TRX_IDX1) */
                       A.COMPANY_CODE as COMPANY_CODE, 
                       A.PERIOD as PERIOD, 
                       A.PROFIT_CENTER as PROFIT_CENTER,
                       A.VENDOR_ID as VENDOR_ID,
                       A.RELATED_PARTY as RELATED_PARTY,
                       A.ACCOUNT_NO as ACCOUNT_NO,
                       A.CURRENCY_LOC as CURRENCY_LOC,
                       A.CURRENCY_DOC as CURRENCY_DOC,
                       A.AMOUNT_LOC AS AMOUNT_LOC,
                       A.AMOUNT_DOC AS AMOUNT_DOC,
                       A.EVALUATION_AMT AS EVALUATION_AMT  
                  from KPI_SAP006_AP_TRX A  
                 where A.COMPANY_CODE = inCompany
                   and A.PERIOD >= SUBSTRB(f_YYYYMMDD,1,6) 
                   and A.PERIOD <= SUBSTRB(t_YYYYMMDD,1,6) 
         ) Group by COMPANY_CODE, PERIOD, PROFIT_CENTER, VENDOR_ID, RELATED_PARTY, ACCOUNT_NO, CURRENCY_LOC, CURRENCY_DOC;

BEGIN
  f_PERIOD := SUBSTRB(f_YYYYMMDD,1,6);
  t_PERIOD := SUBSTRB(t_YYYYMMDD,1,6);

  --Delete Old Data-- 
  Delete from ROIC_PST011_AP_TRX_G WHERE COMPANY_CODE = inCompany
                                     AND PERIOD >= f_PERIOD 
                                     AND PERIOD <= t_PERIOD; 
  Commit;

  --Insert data
  FOR REC in C_TRX Loop
    INSERT INTO ROIC_PST011_AP_TRX_G
      ( COMPANY_CODE, PERIOD, PROFIT_CENTER, VENDOR_ID, RELATED_PARTY, ACCOUNT_NO, CURRENCY_LOC, CURRENCY_DOC, AMOUNT_LOC, AMOUNT_DOC, EVALUATION_AMT
     ) values ( REC.COMPANY_CODE, REC.PERIOD, REC.PROFIT_CENTER, REC.VENDOR_ID, REC.RELATED_PARTY, REC.ACCOUNT_NO, 
                REC.CURRENCY_LOC, REC.CURRENCY_DOC, REC.AMOUNT_LOC, REC.AMOUNT_DOC, REC.EVALUATION_AMT );
  End Loop;
  Commit;
      
END ROIC_PLS009_AP_TRX_G;
/

