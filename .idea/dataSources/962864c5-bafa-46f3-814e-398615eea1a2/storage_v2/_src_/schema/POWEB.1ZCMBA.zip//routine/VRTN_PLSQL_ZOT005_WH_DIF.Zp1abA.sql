create PROCEDURE         "VRTN_PLSQL_ZOT005_WH_DIF" IS

   /*
    每月執行一次 - for MAT_Group
        Create By Susan Lin
    1. 抓 VRT_WH001_INCOMING_EXCEP 資料
    2. 清VRTN_ZOT005_WH_DIF
    3. Insert to VRTN_ZOT005_WH_DIF table
    4. Insert to VRTN_MAP030_SUMMARY_GRAD
   */

  vPERCENTAGE_L1             VRT_MAP020_RATE_INDEX.PERCENTAGE%TYPE;
  vPERCENTAGE_L2             VRT_MAP020_RATE_INDEX.PERCENTAGE%TYPE;
  vPERCENTAGE_L3             VRT_MAP020_RATE_INDEX.PERCENTAGE%TYPE;
  vPERCENTAGE_L4             VRT_MAP020_RATE_INDEX.PERCENTAGE%TYPE;
  iTracePoint                varchar2(100);
  cErrorText                 varchar2(500);
  vPROCEE_YYYYMMDD           varchar2(8);
  vPROCEE_YYYYMM             varchar2(6);
  vSCORE                     VRT_MAP040_RANGE_SCORE.SCORES%TYPE;



  CURSOR C_WH001_INCOMING_EXCEP is
    Select NVL(B.MTL_GROUP,'999') as MTL_GROUP,A.*
      from VRT_WH001_INCOMING_EXCEP A, PLD_KPI_PN_MTLGRP_SUBGRP B
     where A.PART = B.PART_NO(+)
	   and A.MATGROUP is null;


BEGIN
    --抓上個月份
    iTracePoint := '100';
        vPROCEE_YYYYMM := TO_CHAR(ADD_MONTHS(SYSDATE, -1), 'YYYYMM');
        vPROCEE_YYYYMMDD  :=  to_char(sysdate,'YYYYMMDD');

	--UPDATE VRT_WH001_INCOMING_EXCEP MatGroup  from pld_kpi_pn_matlgrp_subgrp
    iTracePoint := '110';
    FOR REC1 in C_WH001_INCOMING_EXCEP Loop
      Update VRT_WH001_INCOMING_EXCEP
         set MATGROUP = REC1.MTL_GROUP
       where SITE = REC1.SITE
         and LIFNR = REC1.LIFNR
         and SERIALNO = REC1.SERIALNO
         and ENTRY_DATE = REC1.ENTRY_DATE
         and SYSDATETIME = REC1.SYSDATETIME
         and PART = REC1.PART;
      Commit;
    END LOOP;




   --先清舊的資料以避免重覆
    iTracePoint := '200' || vPROCEE_YYYYMM;
        DELETE FROM VRTN_ZOT005_WH_DIF
           where P_YEAR || P_MONTH = vPROCEE_YYYYMM;
    commit;


    --放入上月分數
    iTracePoint := '300';
    for REC1 in ( Select C_TEMP.P_YEAR, C_TEMP.P_MONTH, C_TEMP.QUARTER AS QUARTER,C_TEMP.COMPANY_CODE, C_TEMP.SITE, C_TEMP.VENDOR_ID, C_TEMP.MATGROUP, C_TEMP.PTYPE, C_TEMP.DATE_TIME, C_TEMP.TOTAL_GR_CNT, A_TEMP.WH_CNT,
           -- round((((C_TEMP.TOTAL_GR_CNT - 10) * (A_TEMP.WH_CNT))  / C_TEMP.TOTAL_GR_CNT),5) AS SCORE
			round((((C_TEMP.TOTAL_GR_CNT - (10 * A_TEMP.WH_CNT))  / C_TEMP.TOTAL_GR_CNT) * 100),5)  AS SCORE
                             from
    ( select substr(GR_DATE,1,4) AS P_YEAR,
               substr(GR_DATE,5,2) AS P_MONTH,
               D.QUARTER AS QUARTER,
               C.COMPANY_CODE,
               DECODE(C.COMPANY_CODE,C.COMPANY_CODE,C.COMPANY_CODE) AS SITE,
               C.VENDOR_ID,
               C.MTL_GROUP AS MATGROUP,
               'DI' AS PTYPE,
               TO_CHAR(sysdate,'YYYYMMDD') AS DATE_TIME,
               count(*) AS TOTAL_GR_CNT
               from PLD_KPI_SITE_GR_AMT C, DIMENSION_DATE D
           WHERE substr(GR_DATE,1,6) = TO_CHAR(ADD_MONTHS(SYSDATE, -1), 'YYYYMM') AND
                 C.GR_DATE = D.DATE_KEY AND
                 C.VENDOR_ID <> ' '
                 GROUP BY C.COMPANY_CODE,
                          substr(C.GR_DATE,1,4),
                          substr(GR_DATE,5,2),
                          D.QUARTER,
                          DECODE(C.COMPANY_CODE,C.COMPANY_CODE,C.COMPANY_CODE),
                          C.VENDOR_ID,
                          C.MTL_GROUP,
                          sysdate) C_TEMP,
     (select A.YYYY, A.MM, A.BUKRS AS COMPANY_CODE, A.SITE, A.LIFNR AS VENDOR_CODE, A.MATGROUP,
                     count(*) AS WH_CNT
                     from VRT_WH001_INCOMING_EXCEP A
                     WHERE YYYY || MM = TO_CHAR(ADD_MONTHS(SYSDATE, -1), 'YYYYMM')
                           GROUP BY A.YYYY,
                           A.MM,
                           A.BUKRS,
                           A.SITE,
                           A.LIFNR,
                           A.MATGROUP )A_TEMP
      WHERE  A_TEMP.SITE (+)= C_TEMP.SITE AND
             A_TEMP.VENDOR_CODE (+)= C_TEMP.VENDOR_ID AND
			 A_TEMP.MATGROUP (+)= C_TEMP.MATGROUP AND
             A_TEMP.YYYY (+)= C_TEMP.P_YEAR AND
             A_TEMP.MM (+)= C_TEMP.P_MONTH
                             ) loop

      -- process score is '空白
       if REC1.WH_CNT is null then
          vSCORE := 100;
       elsif REC1.SCORE > 100 then
          vSCORE := 100;
       elsif REC1.SCORE < 0 then
          vSCORE := 0;
       else
          vSCORE := REC1.SCORE;
       end if;



      --放到 VRTN_ZOT005_WH_DIF
      iTracePoint := '400-' || REC1.COMPANY_CODE || '-' || REC1.VENDOR_ID || '-' || vPROCEE_YYYYMM;
      insert into VRTN_ZOT005_WH_DIF (
             P_YEAR, P_MONTH, P_QUARTER, COMPANY_CODE, SITE, VENDOR_CODE, MATGROUP, PTYPE, SCORES, WH_DIF_CNT, TOTAL_GR_CNT,DATE_TIME
           ) values (
             REC1.P_YEAR,
             REC1.P_MONTH,
             --'09',
             REC1.QUARTER,
             --'Q4',
             REC1.COMPANY_CODE,
             REC1.SITE,
             REC1.VENDOR_ID,
             REC1.MATGROUP,
             REC1.PTYPE,
             vSCORE,
             --   REC1.SCORE,
             REC1.WH_CNT,
             REC1.TOTAL_GR_CNT,
             vPROCEE_YYYYMMDD
           );
      commit;
    end loop;


 --抓各階分數
  iTracePoint := '500';
  vPERCENTAGE_L1 := null;
  vPERCENTAGE_L2 := null;
  vPERCENTAGE_L3 := null;
  vPERCENTAGE_L4 := null;

  for REC1 in ( select LEVEL_S, PERCENTAGE from VRTN_MAP020_RATE_INDEX
                 where INDEX_KEY = 'DELIVERY' and TYPE = 'DI' ) loop
    if REC1.LEVEL_S = 'L1' then
      iTracePoint := '510';
      vPERCENTAGE_L1 := REC1.PERCENTAGE;
    elsif REC1.LEVEL_S = 'L2' then
      iTracePoint := '520';
      vPERCENTAGE_L2 := REC1.PERCENTAGE;
    elsif REC1.LEVEL_S = 'L3' then
      iTracePoint := '530';
      vPERCENTAGE_L3 := REC1.PERCENTAGE;
    elsif REC1.LEVEL_S = 'L4' then
      iTracePoint := '540';
      vPERCENTAGE_L4 := REC1.PERCENTAGE;
    end if;
  end loop;

  if vPERCENTAGE_L1 is null or vPERCENTAGE_L2 is null or vPERCENTAGE_L3 is null or vPERCENTAGE_L4 is null then
    --若沒抓到資料則寄 error mail
    iTracePoint := '550';
    cErrorText := 'vPERCENTAGE_L1 is ' || nvl(to_char(vPERCENTAGE_L1),'null') || ',vPERCENTAGE_L2 is ' || nvl(to_char(vPERCENTAGE_L2),'null') || ',vPERCENTAGE_L3 is ' || nvl(to_char(vPERCENTAGE_L3),'null') || ',vPERCENTAGE_L4 is ' || nvl(to_char(vPERCENTAGE_L4),'null');
    MAIL_FILE_BIDBDBADMIN(in_to_name => 'shuchin_lin@usiglobal.com', subject => '[VRTN] PL/SQL VRTN_PLSQL_ZOT005_WH_DIF ERROR', message => '[VRTN_PLSQL_ZOT005_WH_DIF ], The tracepoint is  ' || iTracePoint || ' and ErrorText= ' || cErrorText) ;
  else
    --先清舊的資料以避免重覆
    iTracePoint := '500-' || vPROCEE_YYYYMM;
    delete from VRTN_MAP030_SUMMARY_GRAD
     where TYPE = 'DI' and YYYY = substr(vPROCEE_YYYYMM,1,4) and MM = substr(vPROCEE_YYYYMM,5,2);
    commit;


    --放入上月分數
    iTracePoint := '600';
    for REC1 in (select a.P_YEAR, a.P_MONTH, a.P_QUARTER, a.COMPANY_CODE, a.SITE, a.VENDOR_CODE, a.MATGROUP, a.PTYPE, a.SCORES AS SCORE
                   from VRTN_ZOT005_WH_DIF a
                   where ( a.P_YEAR || a.P_MONTH ) = vPROCEE_YYYYMM
                   group by  a.P_YEAR, a.P_MONTH, a.P_QUARTER, a.COMPANY_CODE, a.SITE, a.VENDOR_CODE, a.MATGROUP, a.PTYPE, a.SCORES
                         ) loop


    --放到 VRTN_MAP030_SUMMARY_GRAD
      iTracePoint := '700-' || REC1.SITE || '-' || REC1.VENDOR_CODE || '-' ||  SUBSTRB(vPROCEE_YYYYMM,1,6);
      insert into VRTN_MAP030_SUMMARY_GRAD (
             SITE, LIFNR, MATGROUP, TYPE, YYYY, MM, QUARTER, BUKRS, L1, GRADE_L1, L2, GRADE_L2, L3, GRADE_L3, L4, GRADE_L4
           ) values (
             REC1.SITE,
             REC1.VENDOR_CODE,
             REC1.MATGROUP,
             REC1.PTYPE,
             REC1.P_YEAR,
             REC1.P_MONTH,
             REC1.P_QUARTER,
             REC1.COMPANY_CODE,
             'S0',
             round(REC1.SCORE * vPERCENTAGE_L1, 5),
             'D0',
             round(REC1.SCORE * vPERCENTAGE_L2, 5),
             'D3',
             round(REC1.SCORE * vPERCENTAGE_L3, 5),
             'DI',
             round(REC1.SCORE * vPERCENTAGE_L4, 5)
           );
      commit;
    end loop;
  end if;


EXCEPTION
  When OTHERS Then
    --有錯誤產生則寄mail
    cErrorText := SQLERRM();
    MAIL_FILE_BIDBDBADMIN(in_to_name => 'shuchin_lin@usiglobal.com', subject => '[VRTN] VRTN_PLSQL_ZOT005_WH_DIF ERROR', message => '[VRTN_ZOT005_WH_DIF], The tracepoint is  ' || iTracePoint || ' and ErrorText= ' || cErrorText) ;

END VRTN_PLSQL_ZOT005_WH_DIF;
/

