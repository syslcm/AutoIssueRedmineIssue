create PROCEDURE       pnl3_pls002_cogs_trx_s01  (
   --inCOMPANY       in VARCHAR2,
   inperiod          IN   VARCHAR2,
   inprofit_center   IN   VARCHAR2,
   inamt             IN   NUMBER,
   inglaccount       IN   VARCHAR
--2009/1/14 修正邏輯,針對沒有營收的忘了加材料轉售和levono,發現200811的PC 90有2個科目510101/510104 cogs金額不到10元,所以設一個條件如果金額小於100元就不分了,
--免得90跑出一堆global的end csutomer,到時問起來還要查
-- 發現200812有137元的,因此加大條件到1000
)
AUTHID DEFINER
IS
--2008/11/7 有發現  SUM(NET_REVENUE) <> 0 OR SUM(NET_COGS)  <> 0 條件成立但dm/dl/oh卻有值的戕況,因此不加入此條件
-- 在INSERT進資料庫時再排除金額=0的資料
   a_rate            NUMBER (20, 10);
   a_trate           NUMBER (20, 10);
   a_counter         INTEGER;
   --i_COUNTER       integer;
   a_endcustomer     pnl3_trx001_copa.end_customer_id%TYPE;
   a_net_revenue     pnl3_trx001_copa.amt_twd%TYPE;
   a_revenue_local   pnl3_trx001_copa.amt_twd%TYPE;
   a_revenue_twd     pnl3_trx001_copa.amt_twd%TYPE;
   a_revenue_usd     pnl3_trx001_copa.amt_twd%TYPE;
   a_cogs_dm_local   pnl3_trx001_copa.amt_twd%TYPE;
   a_cogs_dm_twd     pnl3_trx001_copa.amt_twd%TYPE;
   a_cogs_dm_usd     pnl3_trx001_copa.amt_twd%TYPE;
   a_cogs_dl_local   pnl3_trx001_copa.amt_twd%TYPE;
   a_cogs_dl_twd     pnl3_trx001_copa.amt_twd%TYPE;
   a_cogs_dl_usd     pnl3_trx001_copa.amt_twd%TYPE;
   a_cogs_oh_local   pnl3_trx001_copa.amt_twd%TYPE;
   a_cogs_oh_twd     pnl3_trx001_copa.amt_twd%TYPE;
   a_cogs_oh_usd     pnl3_trx001_copa.amt_twd%TYPE;
BEGIN
   a_rate := 0;

   IF inamt = 0
   THEN                                               --沒有營收,全部歸others
      a_rate := 1;

      FOR rec2 IN (SELECT   company_code, customer_id AS bill_to_party,
                            ship_to_party, mtl_group, part_no, plant_code,
                            mtl_type, SUM (net_revenue) net_revenue,
                            SUM (net_revenue_usd) net_revenue_usd,
                            SUM (net_revenue_twd) net_revenue_twd,
                            ABS (SUM (net_cogs_twd)) net_cogs_twd,
                            SUM (cogs_mb) cogs_mb,
                            SUM (cogs_mb_usd) cogs_mb_usd,
                            SUM (cogs_mb_twd) cogs_mb_twd,
                            SUM (cogs_lb) cogs_lb,
                            SUM (cogs_lb_usd) cogs_lb_usd,
                            SUM (cogs_lb_twd) cogs_lb_twd,
                            SUM (cogs_ob) cogs_ob,
                            SUM (cogs_ob_usd) cogs_ob_usd,
                            SUM (cogs_ob_twd) cogs_ob_twd
                       --(SELECT TRIM(END_CUSTOMER_NAME) FROM CEP_MAP009_PARTNO_CUSTOMER where TRIM(FG_MATERIAL_NO) = TRIM(PART_NO) and LAST_MODIFY_DATE <= SYSDATE )
                       --END_CUSTOMER_ID
                   FROM     kpi_sap001_copa_trx
                      WHERE period = inperiod
                        AND profit_center = inprofit_center
                        AND (net_revenue <> 0 OR net_cogs <> 0)
                        AND related_party <> 'Y'
                        --AND    PART_NO IS NULL
                        AND cost_element = inglaccount
                   GROUP BY company_code,
                            profit_center,
                            period,
                            customer_id,
                            ship_to_party,
                            mtl_group,
                            part_no,
                            plant_code,
                            mtl_type)
      LOOP
         --HAVING ( SUM(NET_REVENUE) <> 0 OR SUM(NET_COGS)  <> 0 )
         a_endcustomer := NULL;
         a_rate := 1;

         IF inprofit_center = '0000000034'
         THEN
            a_endcustomer := 'UABIT''S CUST';

            IF rec2.net_revenue <> 0
            THEN
               INSERT INTO pnl3_trx002_glaccount
                           (company_code, period, profit_center,
                            cost_element, bill_to_party,
                            ship_to_party, mtl_group,
                            part_no, plant_code, end_customer_id,
                            r_kind, area1, area2, mtl_type, area3,
                            amt_local,
                            amt_twd,
                            amt_usd,
                            create_date, SOURCE
                           )
                    VALUES (rec2.company_code, inperiod, inprofit_center,
                            inglaccount, rec2.bill_to_party,
                            rec2.ship_to_party, rec2.mtl_group,
                            rec2.part_no, rec2.plant_code, a_endcustomer,
                            'PL01', '1', '1', rec2.mtl_type, '0',
                            ROUND (rec2.net_revenue * a_rate, 5),
                            ROUND (rec2.net_revenue_twd * a_rate, 5),
                            ROUND (rec2.net_revenue_usd * a_rate, 5),
                            SYSDATE, '2'
                           );

               COMMIT;
            END IF;

            IF rec2.cogs_mb <> 0
            THEN
               INSERT INTO pnl3_trx002_glaccount
                           (company_code, period, profit_center,
                            cost_element, bill_to_party,
                            ship_to_party, mtl_group,
                            part_no, plant_code, end_customer_id,
                            r_kind, area1, area2, mtl_type, area3,
                            amt_local,
                            amt_twd,
                            amt_usd, create_date,
                            SOURCE
                           )
                    VALUES (rec2.company_code, inperiod, inprofit_center,
                            inglaccount, rec2.bill_to_party,
                            rec2.ship_to_party, rec2.mtl_group,
                            rec2.part_no, rec2.plant_code, a_endcustomer,
                            'PL01', '2', '2', rec2.mtl_type, '0',
                            ROUND (rec2.cogs_mb * a_rate, 5),
                            ROUND (rec2.cogs_mb_twd * a_rate, 5),
                            ROUND (rec2.cogs_mb_usd * a_rate, 5), SYSDATE,
                            '2'
                           );

               COMMIT;
            END IF;

            IF rec2.cogs_lb <> 0
            THEN
               INSERT INTO pnl3_trx002_glaccount
                           (company_code, period, profit_center,
                            cost_element, bill_to_party,
                            ship_to_party, mtl_group,
                            part_no, plant_code, end_customer_id,
                            r_kind, area1, area2, mtl_type, area3,
                            amt_local,
                            amt_twd,
                            amt_usd, create_date,
                            SOURCE
                           )
                    VALUES (rec2.company_code, inperiod, inprofit_center,
                            inglaccount, rec2.bill_to_party,
                            rec2.ship_to_party, rec2.mtl_group,
                            rec2.part_no, rec2.plant_code, a_endcustomer,
                            'PL01', '2', '3', rec2.mtl_type, '0',
                            ROUND (rec2.cogs_lb * a_rate, 5),
                            ROUND (rec2.cogs_lb_twd * a_rate, 5),
                            ROUND (rec2.cogs_lb_usd * a_rate, 5), SYSDATE,
                            '2'
                           );

               COMMIT;
            END IF;

            IF rec2.cogs_ob <> 0
            THEN
               INSERT INTO pnl3_trx002_glaccount
                           (company_code, period, profit_center,
                            cost_element, bill_to_party,
                            ship_to_party, mtl_group,
                            part_no, plant_code, end_customer_id,
                            r_kind, area1, area2, mtl_type, area3,
                            amt_local,
                            amt_twd,
                            amt_usd, create_date,
                            SOURCE
                           )
                    VALUES (rec2.company_code, inperiod, inprofit_center,
                            inglaccount, rec2.bill_to_party,
                            rec2.ship_to_party, rec2.mtl_group,
                            rec2.part_no, rec2.plant_code, a_endcustomer,
                            'PL01', '2', '4', rec2.mtl_type, '0',
                            ROUND (rec2.cogs_ob * a_rate, 5),
                            ROUND (rec2.cogs_ob_twd * a_rate, 5),
                            ROUND (rec2.cogs_ob_usd * a_rate, 5), SYSDATE,
                            '2'
                           );

               COMMIT;
            END IF;
         ELSIF SUBSTR (inprofit_center, 1, 9) = '000000009'
         THEN
            IF SUBSTR (rec2.company_code, 1, 1) = '9'
            THEN
               a_endcustomer := '投資公司';

               IF rec2.net_revenue <> 0
               THEN
                  INSERT INTO pnl3_trx002_glaccount
                              (company_code, period, profit_center,
                               cost_element, bill_to_party,
                               ship_to_party, mtl_group,
                               part_no, plant_code, end_customer_id,
                               r_kind, area1, area2, mtl_type, area3,
                               amt_local,
                               amt_twd,
                               amt_usd,
                               create_date, SOURCE
                              )
                       VALUES (rec2.company_code, inperiod, inprofit_center,
                               inglaccount, rec2.bill_to_party,
                               rec2.ship_to_party, rec2.mtl_group,
                               rec2.part_no, rec2.plant_code, a_endcustomer,
                               'PL01', '1', '1', rec2.mtl_type, '0',
                               ROUND (rec2.net_revenue * a_rate, 5),
                               ROUND (rec2.net_revenue_twd * a_rate, 5),
                               ROUND (rec2.net_revenue_usd * a_rate, 5),
                               SYSDATE, '2'
                              );

                  COMMIT;
               END IF;

               IF rec2.cogs_mb <> 0
               THEN
                  INSERT INTO pnl3_trx002_glaccount
                              (company_code, period, profit_center,
                               cost_element, bill_to_party,
                               ship_to_party, mtl_group,
                               part_no, plant_code, end_customer_id,
                               r_kind, area1, area2, mtl_type, area3,
                               amt_local,
                               amt_twd,
                               amt_usd,
                               create_date, SOURCE
                              )
                       VALUES (rec2.company_code, inperiod, inprofit_center,
                               inglaccount, rec2.bill_to_party,
                               rec2.ship_to_party, rec2.mtl_group,
                               rec2.part_no, rec2.plant_code, a_endcustomer,
                               'PL01', '2', '2', rec2.mtl_type, '0',
                               ROUND (rec2.cogs_mb * a_rate, 5),
                               ROUND (rec2.cogs_mb_twd * a_rate, 5),
                               ROUND (rec2.cogs_mb_usd * a_rate, 5),
                               SYSDATE, '2'
                              );

                  COMMIT;
               END IF;

               IF rec2.cogs_lb <> 0
               THEN
                  INSERT INTO pnl3_trx002_glaccount
                              (company_code, period, profit_center,
                               cost_element, bill_to_party,
                               ship_to_party, mtl_group,
                               part_no, plant_code, end_customer_id,
                               r_kind, area1, area2, mtl_type, area3,
                               amt_local,
                               amt_twd,
                               amt_usd,
                               create_date, SOURCE
                              )
                       VALUES (rec2.company_code, inperiod, inprofit_center,
                               inglaccount, rec2.bill_to_party,
                               rec2.ship_to_party, rec2.mtl_group,
                               rec2.part_no, rec2.plant_code, a_endcustomer,
                               'PL01', '2', '3', rec2.mtl_type, '0',
                               ROUND (rec2.cogs_lb * a_rate, 5),
                               ROUND (rec2.cogs_lb_twd * a_rate, 5),
                               ROUND (rec2.cogs_lb_usd * a_rate, 5),
                               SYSDATE, '2'
                              );

                  COMMIT;
               END IF;

               IF rec2.cogs_ob <> 0
               THEN
                  INSERT INTO pnl3_trx002_glaccount
                              (company_code, period, profit_center,
                               cost_element, bill_to_party,
                               ship_to_party, mtl_group,
                               part_no, plant_code, end_customer_id,
                               r_kind, area1, area2, mtl_type, area3,
                               amt_local,
                               amt_twd,
                               amt_usd,
                               create_date, SOURCE
                              )
                       VALUES (rec2.company_code, inperiod, inprofit_center,
                               inglaccount, rec2.bill_to_party,
                               rec2.ship_to_party, rec2.mtl_group,
                               rec2.part_no, rec2.plant_code, a_endcustomer,
                               'PL01', '2', '4', rec2.mtl_type, '0',
                               ROUND (rec2.cogs_ob * a_rate, 5),
                               ROUND (rec2.cogs_ob_twd * a_rate, 5),
                               ROUND (rec2.cogs_ob_usd * a_rate, 5),
                               SYSDATE, '2'
                              );

                  COMMIT;
               END IF;
            ELSE
               a_endcustomer := NULL;

               IF     (   inprofit_center = '0000000020'
                       OR inprofit_center = '0000000021'
                      )
                  AND (rec2.mtl_group >= '001' AND rec2.mtl_group <= '059')
                  AND rec2.mtl_type = 'RAW'
               THEN
                  a_endcustomer := 'LENOVO';
               ELSIF     (    inprofit_center <> '0000000020'
                          AND inprofit_center <> '0000000021'
                         )
                     AND (rec2.mtl_group >= '001' AND rec2.mtl_group <= '059'
                         )
                     AND rec2.mtl_type = 'RAW'
               THEN
                  a_endcustomer := '其他-材料轉售';
               ELSE
                  BEGIN
                     SELECT TRIM (end_customer_name)
                       INTO a_endcustomer
                       FROM cep_map009_partno_customer
                      WHERE fg_material_no = RPAD (rec2.part_no, 18, ' ')
                        AND last_modify_date <= SYSDATE;
                  EXCEPTION
                     WHEN OTHERS
                     THEN
                        a_endcustomer := NULL;
                  END;
               END IF;

               IF a_endcustomer IS NOT NULL
               THEN
                  IF rec2.net_revenue <> 0
                  THEN
                     INSERT INTO pnl3_trx002_glaccount
                                 (company_code, period,
                                  profit_center, cost_element,
                                  bill_to_party, ship_to_party,
                                  mtl_group, part_no,
                                  plant_code, end_customer_id, r_kind,
                                  area1, area2, mtl_type, area3,
                                  amt_local,
                                  amt_twd,
                                  amt_usd,
                                  create_date, SOURCE
                                 )
                          VALUES (rec2.company_code, inperiod,
                                  inprofit_center, inglaccount,
                                  rec2.bill_to_party, rec2.ship_to_party,
                                  rec2.mtl_group, rec2.part_no,
                                  rec2.plant_code, a_endcustomer, 'PL01',
                                  '1', '1', rec2.mtl_type, '0',
                                  ROUND (rec2.net_revenue * a_rate, 5),
                                  ROUND (rec2.net_revenue_twd * a_rate, 5),
                                  ROUND (rec2.net_revenue_usd * a_rate, 5),
                                  SYSDATE, '2'
                                 );

                     COMMIT;
                  END IF;

                  IF rec2.cogs_mb <> 0
                  THEN
                     INSERT INTO pnl3_trx002_glaccount
                                 (company_code, period,
                                  profit_center, cost_element,
                                  bill_to_party, ship_to_party,
                                  mtl_group, part_no,
                                  plant_code, end_customer_id, r_kind,
                                  area1, area2, mtl_type, area3,
                                  amt_local,
                                  amt_twd,
                                  amt_usd,
                                  create_date, SOURCE
                                 )
                          VALUES (rec2.company_code, inperiod,
                                  inprofit_center, inglaccount,
                                  rec2.bill_to_party, rec2.ship_to_party,
                                  rec2.mtl_group, rec2.part_no,
                                  rec2.plant_code, a_endcustomer, 'PL01',
                                  '2', '2', rec2.mtl_type, '0',
                                  ROUND (rec2.cogs_mb * a_rate, 5),
                                  ROUND (rec2.cogs_mb_twd * a_rate, 5),
                                  ROUND (rec2.cogs_mb_usd * a_rate, 5),
                                  SYSDATE, '2'
                                 );

                     COMMIT;
                  END IF;

                  IF rec2.cogs_lb <> 0
                  THEN
                     INSERT INTO pnl3_trx002_glaccount
                                 (company_code, period,
                                  profit_center, cost_element,
                                  bill_to_party, ship_to_party,
                                  mtl_group, part_no,
                                  plant_code, end_customer_id, r_kind,
                                  area1, area2, mtl_type, area3,
                                  amt_local,
                                  amt_twd,
                                  amt_usd,
                                  create_date, SOURCE
                                 )
                          VALUES (rec2.company_code, inperiod,
                                  inprofit_center, inglaccount,
                                  rec2.bill_to_party, rec2.ship_to_party,
                                  rec2.mtl_group, rec2.part_no,
                                  rec2.plant_code, a_endcustomer, 'PL01',
                                  '2', '3', rec2.mtl_type, '0',
                                  ROUND (rec2.cogs_lb * a_rate, 5),
                                  ROUND (rec2.cogs_lb_twd * a_rate, 5),
                                  ROUND (rec2.cogs_lb_usd * a_rate, 5),
                                  SYSDATE, '2'
                                 );

                     COMMIT;
                  END IF;

                  IF rec2.cogs_ob <> 0
                  THEN
                     INSERT INTO pnl3_trx002_glaccount
                                 (company_code, period,
                                  profit_center, cost_element,
                                  bill_to_party, ship_to_party,
                                  mtl_group, part_no,
                                  plant_code, end_customer_id, r_kind,
                                  area1, area2, mtl_type, area3,
                                  amt_local,
                                  amt_twd,
                                  amt_usd,
                                  create_date, SOURCE
                                 )
                          VALUES (rec2.company_code, inperiod,
                                  inprofit_center, inglaccount,
                                  rec2.bill_to_party, rec2.ship_to_party,
                                  rec2.mtl_group, rec2.part_no,
                                  rec2.plant_code, a_endcustomer, 'PL01',
                                  '2', '4', rec2.mtl_type, '0',
                                  ROUND (rec2.cogs_ob * a_rate, 5),
                                  ROUND (rec2.cogs_ob_twd * a_rate, 5),
                                  ROUND (rec2.cogs_ob_usd * a_rate, 5),
                                  SYSDATE, '2'
                                 );

                     COMMIT;
                  END IF;
               ELSE
                  IF rec2.net_cogs_twd > 1000
                  THEN
                     a_counter := 0;

                     FOR rec1 IN
                        (SELECT end_customer_id, rate
                           --FROM PNL3_MAP001_GLOBAL_CUST_RATE
                         FROM   pnl3_map001_customer_rate
                          WHERE r_kind =
                                        'PL01'
                                              --隨便抓一筆來用,反正匯率都一樣
                            AND area1 = '4'
                            AND area2 = '1'
                            AND area3 = '1'
                            --AND COMPANY_CODE = REC1.COMPANY_CODE
                            AND profit_center = inprofit_center
                            AND period = inperiod)
                     LOOP
                        a_counter := 1;
                        a_rate := rec1.rate;
                        a_endcustomer := rec1.end_customer_id;

                        IF rec2.net_revenue <> 0
                        THEN
                           INSERT INTO pnl3_trx002_glaccount
                                       (company_code, period,
                                        profit_center, cost_element,
                                        bill_to_party,
                                        ship_to_party, mtl_group,
                                        part_no, plant_code,
                                        end_customer_id, r_kind, area1,
                                        area2, mtl_type, area3,
                                        amt_local,
                                        amt_twd,
                                        amt_usd,
                                        create_date, SOURCE
                                       )
                                VALUES (rec2.company_code, inperiod,
                                        inprofit_center, inglaccount,
                                        rec2.bill_to_party,
                                        rec2.ship_to_party, rec2.mtl_group,
                                        rec2.part_no, rec2.plant_code,
                                        a_endcustomer, 'PL01', '1',
                                        '1', rec2.mtl_type, '0',
                                        ROUND (rec2.net_revenue * a_rate, 5),
                                        ROUND (rec2.net_revenue_twd * a_rate,
                                               5
                                              ),
                                        ROUND (rec2.net_revenue_usd * a_rate,
                                               5
                                              ),
                                        SYSDATE, '2'
                                       );

                           COMMIT;
                        END IF;

                        IF rec2.cogs_mb <> 0
                        THEN
                           INSERT INTO pnl3_trx002_glaccount
                                       (company_code, period,
                                        profit_center, cost_element,
                                        bill_to_party,
                                        ship_to_party, mtl_group,
                                        part_no, plant_code,
                                        end_customer_id, r_kind, area1,
                                        area2, mtl_type, area3,
                                        amt_local,
                                        amt_twd,
                                        amt_usd,
                                        create_date, SOURCE
                                       )
                                VALUES (rec2.company_code, inperiod,
                                        inprofit_center, inglaccount,
                                        rec2.bill_to_party,
                                        rec2.ship_to_party, rec2.mtl_group,
                                        rec2.part_no, rec2.plant_code,
                                        a_endcustomer, 'PL01', '2',
                                        '2', rec2.mtl_type, '0',
                                        ROUND (rec2.cogs_mb * a_rate, 5),
                                        ROUND (rec2.cogs_mb_twd * a_rate, 5),
                                        ROUND (rec2.cogs_mb_usd * a_rate, 5),
                                        SYSDATE, '2'
                                       );

                           COMMIT;
                        END IF;

                        IF rec2.cogs_lb <> 0
                        THEN
                           INSERT INTO pnl3_trx002_glaccount
                                       (company_code, period,
                                        profit_center, cost_element,
                                        bill_to_party,
                                        ship_to_party, mtl_group,
                                        part_no, plant_code,
                                        end_customer_id, r_kind, area1,
                                        area2, mtl_type, area3,
                                        amt_local,
                                        amt_twd,
                                        amt_usd,
                                        create_date, SOURCE
                                       )
                                VALUES (rec2.company_code, inperiod,
                                        inprofit_center, inglaccount,
                                        rec2.bill_to_party,
                                        rec2.ship_to_party, rec2.mtl_group,
                                        rec2.part_no, rec2.plant_code,
                                        a_endcustomer, 'PL01', '2',
                                        '3', rec2.mtl_type, '0',
                                        ROUND (rec2.cogs_lb * a_rate, 5),
                                        ROUND (rec2.cogs_lb_twd * a_rate, 5),
                                        ROUND (rec2.cogs_lb_usd * a_rate, 5),
                                        SYSDATE, '2'
                                       );

                           COMMIT;
                        END IF;

                        IF rec2.cogs_ob <> 0
                        THEN
                           INSERT INTO pnl3_trx002_glaccount
                                       (company_code, period,
                                        profit_center, cost_element,
                                        bill_to_party,
                                        ship_to_party, mtl_group,
                                        part_no, plant_code,
                                        end_customer_id, r_kind, area1,
                                        area2, mtl_type, area3,
                                        amt_local,
                                        amt_twd,
                                        amt_usd,
                                        create_date, SOURCE
                                       )
                                VALUES (rec2.company_code, inperiod,
                                        inprofit_center, inglaccount,
                                        rec2.bill_to_party,
                                        rec2.ship_to_party, rec2.mtl_group,
                                        rec2.part_no, rec2.plant_code,
                                        a_endcustomer, 'PL01', '2',
                                        '4', rec2.mtl_type, '0',
                                        ROUND (rec2.cogs_ob * a_rate, 5),
                                        ROUND (rec2.cogs_ob_twd * a_rate, 5),
                                        ROUND (rec2.cogs_ob_usd * a_rate, 5),
                                        SYSDATE, '2'
                                       );

                           COMMIT;
                        END IF;
                     END LOOP;

                     IF a_counter = 0
                     THEN
                        FOR rec1 IN (SELECT end_customer_id, rate
                                       FROM pnl3_map001_global_cust_rate
                                      --FROM PNL3_MAP001_CUSTOMER_RATE
                                     WHERE  r_kind = 'PL01'
                                        --隨便抓一筆來用,反正匯率都一樣
                                        AND area1 = '4'
                                        AND area2 = '1'
                                        AND area3 = '1'
                                        --AND COMPANY_CODE = REC1.COMPANY_CODE
                                        --AND PROFIT_CENTER = REC2.PROFIT_CENTER
                                        AND period = inperiod)
                        LOOP
                           a_rate := rec1.rate;
                           a_endcustomer := rec1.end_customer_id;

                           IF rec2.net_revenue <> 0
                           THEN
                              INSERT INTO pnl3_trx002_glaccount
                                          (company_code, period,
                                           profit_center, cost_element,
                                           bill_to_party,
                                           ship_to_party,
                                           mtl_group, part_no,
                                           plant_code, end_customer_id,
                                           r_kind, area1, area2, mtl_type,
                                           area3,
                                           amt_local,
                                           amt_twd,
                                           amt_usd,
                                           create_date, SOURCE
                                          )
                                   VALUES (rec2.company_code, inperiod,
                                           inprofit_center, inglaccount,
                                           rec2.bill_to_party,
                                           rec2.ship_to_party,
                                           rec2.mtl_group, rec2.part_no,
                                           rec2.plant_code, a_endcustomer,
                                           'PL01', '1', '1', rec2.mtl_type,
                                           '0',
                                           ROUND (rec2.net_revenue * a_rate,
                                                  5),
                                           ROUND (rec2.net_revenue_twd
                                                  * a_rate,
                                                  5
                                                 ),
                                           ROUND (rec2.net_revenue_usd
                                                  * a_rate,
                                                  5
                                                 ),
                                           SYSDATE, '2'
                                          );

                              COMMIT;
                           END IF;

                           IF rec2.cogs_mb <> 0
                           THEN
                              INSERT INTO pnl3_trx002_glaccount
                                          (company_code, period,
                                           profit_center, cost_element,
                                           bill_to_party,
                                           ship_to_party,
                                           mtl_group, part_no,
                                           plant_code, end_customer_id,
                                           r_kind, area1, area2, mtl_type,
                                           area3,
                                           amt_local,
                                           amt_twd,
                                           amt_usd,
                                           create_date, SOURCE
                                          )
                                   VALUES (rec2.company_code, inperiod,
                                           inprofit_center, inglaccount,
                                           rec2.bill_to_party,
                                           rec2.ship_to_party,
                                           rec2.mtl_group, rec2.part_no,
                                           rec2.plant_code, a_endcustomer,
                                           'PL01', '2', '2', rec2.mtl_type,
                                           '0',
                                           ROUND (rec2.cogs_mb * a_rate, 5),
                                           ROUND (rec2.cogs_mb_twd * a_rate,
                                                  5),
                                           ROUND (rec2.cogs_mb_usd * a_rate,
                                                  5),
                                           SYSDATE, '2'
                                          );

                              COMMIT;
                           END IF;

                           IF rec2.cogs_lb <> 0
                           THEN
                              INSERT INTO pnl3_trx002_glaccount
                                          (company_code, period,
                                           profit_center, cost_element,
                                           bill_to_party,
                                           ship_to_party,
                                           mtl_group, part_no,
                                           plant_code, end_customer_id,
                                           r_kind, area1, area2, mtl_type,
                                           area3,
                                           amt_local,
                                           amt_twd,
                                           amt_usd,
                                           create_date, SOURCE
                                          )
                                   VALUES (rec2.company_code, inperiod,
                                           inprofit_center, inglaccount,
                                           rec2.bill_to_party,
                                           rec2.ship_to_party,
                                           rec2.mtl_group, rec2.part_no,
                                           rec2.plant_code, a_endcustomer,
                                           'PL01', '2', '3', rec2.mtl_type,
                                           '0',
                                           ROUND (rec2.cogs_lb * a_rate, 5),
                                           ROUND (rec2.cogs_lb_twd * a_rate,
                                                  5),
                                           ROUND (rec2.cogs_lb_usd * a_rate,
                                                  5),
                                           SYSDATE, '2'
                                          );

                              COMMIT;
                           END IF;

                           IF rec2.cogs_ob <> 0
                           THEN
                              INSERT INTO pnl3_trx002_glaccount
                                          (company_code, period,
                                           profit_center, cost_element,
                                           bill_to_party,
                                           ship_to_party,
                                           mtl_group, part_no,
                                           plant_code, end_customer_id,
                                           r_kind, area1, area2, mtl_type,
                                           area3,
                                           amt_local,
                                           amt_twd,
                                           amt_usd,
                                           create_date, SOURCE
                                          )
                                   VALUES (rec2.company_code, inperiod,
                                           inprofit_center, inglaccount,
                                           rec2.bill_to_party,
                                           rec2.ship_to_party,
                                           rec2.mtl_group, rec2.part_no,
                                           rec2.plant_code, a_endcustomer,
                                           'PL01', '2', '4', rec2.mtl_type,
                                           '0',
                                           ROUND (rec2.cogs_ob * a_rate, 5),
                                           ROUND (rec2.cogs_ob_twd * a_rate,
                                                  5),
                                           ROUND (rec2.cogs_ob_usd * a_rate,
                                                  5),
                                           SYSDATE, '2'
                                          );

                              COMMIT;
                           END IF;
                        END LOOP;
                     END IF;
                  END IF;
               END IF;
            END IF;
         ELSE                                                  --不屬於34,9x的
            a_endcustomer := NULL;

            IF     (   inprofit_center = '0000000020'
                    OR inprofit_center = '0000000021'
                   )
               AND (rec2.mtl_group >= '001' AND rec2.mtl_group <= '059')
               AND rec2.mtl_type = 'RAW'
            THEN
               a_endcustomer := 'LENOVO';
            ELSIF     (   inprofit_center <> '0000000020'
                       OR inprofit_center <> '0000000021'
                      )
                  AND (rec2.mtl_group >= '001' AND rec2.mtl_group <= '059')
                  AND rec2.mtl_type = 'RAW'
            THEN
               a_endcustomer := '其他-材料轉售';
            ELSE
               BEGIN
                  SELECT TRIM (end_customer_name)
                    INTO a_endcustomer
                    FROM cep_map009_partno_customer
                   WHERE fg_material_no = RPAD (rec2.part_no, 18, ' ')
                     AND last_modify_date <= SYSDATE;
               EXCEPTION
                  WHEN OTHERS
                  THEN
                     a_endcustomer := NULL;
               END;
            END IF;

            IF a_endcustomer IS NOT NULL
            THEN
               IF rec2.net_revenue <> 0
               THEN
                  INSERT INTO pnl3_trx002_glaccount
                              (company_code, period, profit_center,
                               cost_element, bill_to_party,
                               ship_to_party, mtl_group,
                               part_no, plant_code, end_customer_id,
                               r_kind, area1, area2, mtl_type, area3,
                               amt_local,
                               amt_twd,
                               amt_usd,
                               create_date, SOURCE
                              )
                       VALUES (rec2.company_code, inperiod, inprofit_center,
                               inglaccount, rec2.bill_to_party,
                               rec2.ship_to_party, rec2.mtl_group,
                               rec2.part_no, rec2.plant_code, a_endcustomer,
                               'PL01', '1', '1', rec2.mtl_type, '0',
                               ROUND (rec2.net_revenue * a_rate, 5),
                               ROUND (rec2.net_revenue_twd * a_rate, 5),
                               ROUND (rec2.net_revenue_usd * a_rate, 5),
                               SYSDATE, '2'
                              );

                  COMMIT;
               END IF;

               IF rec2.cogs_mb <> 0
               THEN
                  INSERT INTO pnl3_trx002_glaccount
                              (company_code, period, profit_center,
                               cost_element, bill_to_party,
                               ship_to_party, mtl_group,
                               part_no, plant_code, end_customer_id,
                               r_kind, area1, area2, mtl_type, area3,
                               amt_local,
                               amt_twd,
                               amt_usd,
                               create_date, SOURCE
                              )
                       VALUES (rec2.company_code, inperiod, inprofit_center,
                               inglaccount, rec2.bill_to_party,
                               rec2.ship_to_party, rec2.mtl_group,
                               rec2.part_no, rec2.plant_code, a_endcustomer,
                               'PL01', '2', '2', rec2.mtl_type, '0',
                               ROUND (rec2.cogs_mb * a_rate, 5),
                               ROUND (rec2.cogs_mb_twd * a_rate, 5),
                               ROUND (rec2.cogs_mb_usd * a_rate, 5),
                               SYSDATE, '2'
                              );

                  COMMIT;
               END IF;

               IF rec2.cogs_lb <> 0
               THEN
                  INSERT INTO pnl3_trx002_glaccount
                              (company_code, period, profit_center,
                               cost_element, bill_to_party,
                               ship_to_party, mtl_group,
                               part_no, plant_code, end_customer_id,
                               r_kind, area1, area2, mtl_type, area3,
                               amt_local,
                               amt_twd,
                               amt_usd,
                               create_date, SOURCE
                              )
                       VALUES (rec2.company_code, inperiod, inprofit_center,
                               inglaccount, rec2.bill_to_party,
                               rec2.ship_to_party, rec2.mtl_group,
                               rec2.part_no, rec2.plant_code, a_endcustomer,
                               'PL01', '2', '3', rec2.mtl_type, '0',
                               ROUND (rec2.cogs_lb * a_rate, 5),
                               ROUND (rec2.cogs_lb_twd * a_rate, 5),
                               ROUND (rec2.cogs_lb_usd * a_rate, 5),
                               SYSDATE, '2'
                              );

                  COMMIT;
               END IF;

               IF rec2.cogs_ob <> 0
               THEN
                  INSERT INTO pnl3_trx002_glaccount
                              (company_code, period, profit_center,
                               cost_element, bill_to_party,
                               ship_to_party, mtl_group,
                               part_no, plant_code, end_customer_id,
                               r_kind, area1, area2, mtl_type, area3,
                               amt_local,
                               amt_twd,
                               amt_usd,
                               create_date, SOURCE
                              )
                       VALUES (rec2.company_code, inperiod, inprofit_center,
                               inglaccount, rec2.bill_to_party,
                               rec2.ship_to_party, rec2.mtl_group,
                               rec2.part_no, rec2.plant_code, a_endcustomer,
                               'PL01', '2', '4', rec2.mtl_type, '0',
                               ROUND (rec2.cogs_ob * a_rate, 5),
                               ROUND (rec2.cogs_ob_twd * a_rate, 5),
                               ROUND (rec2.cogs_ob_usd * a_rate, 5),
                               SYSDATE, '2'
                              );

                  COMMIT;
               END IF;
            ELSE
               IF rec2.net_cogs_twd > 1000
               THEN
                  --只處理大於10元的,免得跑出一堆end customer但金額卻小到看不到
                  FOR rec1 IN (SELECT end_customer_id, rate
                                 FROM pnl3_map001_site_rate
                                WHERE r_kind = 'PL01'
                                  --隨便抓一筆來用,反正匯率都一樣
                                  AND area1 = '4'
                                  AND area2 = '1'
                                  AND area3 = '1'
                                  AND company_code = rec2.company_code
                                  AND profit_center = inprofit_center
                                  AND period = inperiod)
                  LOOP
                     a_rate := rec1.rate;
                     a_endcustomer := rec1.end_customer_id;

                     IF rec2.net_revenue <> 0
                     THEN
                        INSERT INTO pnl3_trx002_glaccount
                                    (company_code, period,
                                     profit_center, cost_element,
                                     bill_to_party, ship_to_party,
                                     mtl_group, part_no,
                                     plant_code, end_customer_id, r_kind,
                                     area1, area2, mtl_type, area3,
                                     amt_local,
                                     amt_twd,
                                     amt_usd,
                                     create_date, SOURCE
                                    )
                             VALUES (rec2.company_code, inperiod,
                                     inprofit_center, inglaccount,
                                     rec2.bill_to_party, rec2.ship_to_party,
                                     rec2.mtl_group, rec2.part_no,
                                     rec2.plant_code, a_endcustomer, 'PL01',
                                     '1', '1', rec2.mtl_type, '0',
                                     ROUND (rec2.net_revenue * a_rate, 5),
                                     ROUND (rec2.net_revenue_twd * a_rate, 5),
                                     ROUND (rec2.net_revenue_usd * a_rate, 5),
                                     SYSDATE, '2'
                                    );

                        COMMIT;
                     END IF;

                     IF rec2.cogs_mb <> 0
                     THEN
                        INSERT INTO pnl3_trx002_glaccount
                                    (company_code, period,
                                     profit_center, cost_element,
                                     bill_to_party, ship_to_party,
                                     mtl_group, part_no,
                                     plant_code, end_customer_id, r_kind,
                                     area1, area2, mtl_type, area3,
                                     amt_local,
                                     amt_twd,
                                     amt_usd,
                                     create_date, SOURCE
                                    )
                             VALUES (rec2.company_code, inperiod,
                                     inprofit_center, inglaccount,
                                     rec2.bill_to_party, rec2.ship_to_party,
                                     rec2.mtl_group, rec2.part_no,
                                     rec2.plant_code, a_endcustomer, 'PL01',
                                     '2', '2', rec2.mtl_type, '0',
                                     ROUND (rec2.cogs_mb * a_rate, 5),
                                     ROUND (rec2.cogs_mb_twd * a_rate, 5),
                                     ROUND (rec2.cogs_mb_usd * a_rate, 5),
                                     SYSDATE, '2'
                                    );

                        COMMIT;
                     END IF;

                     IF rec2.cogs_lb <> 0
                     THEN
                        INSERT INTO pnl3_trx002_glaccount
                                    (company_code, period,
                                     profit_center, cost_element,
                                     bill_to_party, ship_to_party,
                                     mtl_group, part_no,
                                     plant_code, end_customer_id, r_kind,
                                     area1, area2, mtl_type, area3,
                                     amt_local,
                                     amt_twd,
                                     amt_usd,
                                     create_date, SOURCE
                                    )
                             VALUES (rec2.company_code, inperiod,
                                     inprofit_center, inglaccount,
                                     rec2.bill_to_party, rec2.ship_to_party,
                                     rec2.mtl_group, rec2.part_no,
                                     rec2.plant_code, a_endcustomer, 'PL01',
                                     '2', '3', rec2.mtl_type, '0',
                                     ROUND (rec2.cogs_lb * a_rate, 5),
                                     ROUND (rec2.cogs_lb_twd * a_rate, 5),
                                     ROUND (rec2.cogs_lb_usd * a_rate, 5),
                                     SYSDATE, '2'
                                    );

                        COMMIT;
                     END IF;

                     IF rec2.cogs_ob <> 0
                     THEN
                        INSERT INTO pnl3_trx002_glaccount
                                    (company_code, period,
                                     profit_center, cost_element,
                                     bill_to_party, ship_to_party,
                                     mtl_group, part_no,
                                     plant_code, end_customer_id, r_kind,
                                     area1, area2, mtl_type, area3,
                                     amt_local,
                                     amt_twd,
                                     amt_usd,
                                     create_date, SOURCE
                                    )
                             VALUES (rec2.company_code, inperiod,
                                     inprofit_center, inglaccount,
                                     rec2.bill_to_party, rec2.ship_to_party,
                                     rec2.mtl_group, rec2.part_no,
                                     rec2.plant_code, a_endcustomer, 'PL01',
                                     '2', '4', rec2.mtl_type, '0',
                                     ROUND (rec2.cogs_ob * a_rate, 5),
                                     ROUND (rec2.cogs_ob_twd * a_rate, 5),
                                     ROUND (rec2.cogs_ob_usd * a_rate, 5),
                                     SYSDATE, '2'
                                    );

                        COMMIT;
                     END IF;
                  END LOOP;
               END IF;
            END IF;
         END IF;
      END LOOP;
   /*  不要在這裡抓END_CUSTOMER會造成效能很不好,跑一個小時還跑不出來 在PNL3_PLS002_COGS_TRX 直接UPDATE即可
   IF REC2.PART_NO IS NOT NULL THEN
      BEGIN
        select DISTINCT TRIM(END_CUSTOMER_NAME) into a_ENDCUSTOMER
       from CEP_MAP009_PARTNO_CUSTOMER
      where TRIM(FG_MATERIAL_NO) = TRIM(REC2.PART_NO)
        and LAST_MODIFY_DATE <= SYSDATE;
      EXCEPTION
        WHEN OTHERS THEN
        a_ENDCUSTOMER := NULL;
      END;
   END IF;
   */
   ELSE                                                              -- 有營收
      a_endcustomer := NULL;

      FOR rec2 IN (SELECT   company_code, customer_id AS bill_to_party,
                            ship_to_party, mtl_group, part_no, plant_code,
                            mtl_type, SUM (net_revenue) net_revenue,
                            SUM (net_revenue_usd) net_revenue_usd,
                            SUM (net_revenue_twd) net_revenue_twd,
                            SUM (cogs_mb) cogs_mb,
                            SUM (cogs_mb_usd) cogs_mb_usd,
                            SUM (cogs_mb_twd) cogs_mb_twd,
                            SUM (cogs_lb) cogs_lb,
                            SUM (cogs_lb_usd) cogs_lb_usd,
                            SUM (cogs_lb_twd) cogs_lb_twd,
                            SUM (cogs_ob) cogs_ob,
                            SUM (cogs_ob_usd) cogs_ob_usd,
                            SUM (cogs_ob_twd) cogs_ob_twd
                       -- (SELECT TRIM(END_CUSTOMER_NAME) FROM CEP_MAP009_PARTNO_CUSTOMER where TRIM(FG_MATERIAL_NO) = TRIM(PART_NO) and LAST_MODIFY_DATE <= SYSDATE )
                       -- END_CUSTOMER_ID
                   FROM     kpi_sap001_copa_trx
                      WHERE period = inperiod
                        AND profit_center = inprofit_center
                        AND (net_revenue <> 0 OR net_cogs <> 0)
                        AND related_party <> 'Y'
                        --AND    PART_NO IS NOT NULL
                        AND cost_element = inglaccount
                   GROUP BY company_code,
                            profit_center,
                            period,
                            customer_id,
                            ship_to_party,
                            mtl_group,
                            part_no,
                            plant_code,
                            mtl_type)
      LOOP
          --HAVING ( SUM(NET_REVENUE) <> 0 OR SUM(NET_COGS)  <> 0 )
         /*  不要在這裡抓END_CUSTOMER會造成效能很不好,跑一個小時還跑不出來
             在PNL3_PLS002_COGS_TRX 直接UPDATE即可
         */
         IF rec2.net_revenue <> 0
         THEN
            INSERT INTO pnl3_trx002_glaccount_t
                        (company_code, period, profit_center,
                         cost_element, bill_to_party,
                         ship_to_party, mtl_group, part_no,
                         plant_code, end_customer_id, r_kind, area1, area2,
                         mtl_type, area3, amt_local,
                         amt_twd, amt_usd, customer_revenue,
                         pc_revenue, rate, create_date
                        )
                 VALUES (rec2.company_code, inperiod, inprofit_center,
                         inglaccount, rec2.bill_to_party,
                         rec2.ship_to_party, rec2.mtl_group, rec2.part_no,
                         rec2.plant_code, a_endcustomer, 'PL01', '1', '1',
                         rec2.mtl_type, '0', rec2.net_revenue,
                         rec2.net_revenue_twd, rec2.net_revenue_usd, inamt,
                         rec2.net_revenue_twd, 1, SYSDATE
                        );

            COMMIT;
         END IF;

         IF rec2.cogs_mb <> 0
         THEN
            INSERT INTO pnl3_trx002_glaccount_t
                        (company_code, period, profit_center,
                         cost_element, bill_to_party,
                         ship_to_party, mtl_group, part_no,
                         plant_code, end_customer_id, r_kind, area1, area2,
                         mtl_type, area3, amt_local, amt_twd,
                         amt_usd, customer_revenue, pc_revenue, rate,
                         create_date
                        )
                 VALUES (rec2.company_code, inperiod, inprofit_center,
                         inglaccount, rec2.bill_to_party,
                         rec2.ship_to_party, rec2.mtl_group, rec2.part_no,
                         rec2.plant_code, a_endcustomer, 'PL01', '2', '2',
                         rec2.mtl_type, '0', rec2.cogs_mb, rec2.cogs_mb_twd,
                         rec2.cogs_mb_usd, inamt, rec2.net_revenue_twd, 1,
                         SYSDATE
                        );

            COMMIT;
         END IF;

         IF rec2.cogs_lb <> 0
         THEN
            INSERT INTO pnl3_trx002_glaccount_t
                        (company_code, period, profit_center,
                         cost_element, bill_to_party,
                         ship_to_party, mtl_group, part_no,
                         plant_code, end_customer_id, r_kind, area1, area2,
                         mtl_type, area3, amt_local, amt_twd,
                         amt_usd, customer_revenue, pc_revenue, rate,
                         create_date
                        )
                 VALUES (rec2.company_code, inperiod, inprofit_center,
                         inglaccount, rec2.bill_to_party,
                         rec2.ship_to_party, rec2.mtl_group, rec2.part_no,
                         rec2.plant_code, a_endcustomer, 'PL01', '2', '3',
                         rec2.mtl_type, '0', rec2.cogs_lb, rec2.cogs_lb_twd,
                         rec2.cogs_lb_usd, inamt, rec2.net_revenue_twd, 1,
                         SYSDATE
                        );

            COMMIT;
         END IF;

         IF rec2.cogs_ob <> 0
         THEN
            INSERT INTO pnl3_trx002_glaccount_t
                        (company_code, period, profit_center,
                         cost_element, bill_to_party,
                         ship_to_party, mtl_group, part_no,
                         plant_code, end_customer_id, r_kind, area1, area2,
                         mtl_type, area3, amt_local, amt_twd,
                         amt_usd, customer_revenue, pc_revenue, rate,
                         create_date
                        )
                 VALUES (rec2.company_code, inperiod, inprofit_center,
                         inglaccount, rec2.bill_to_party,
                         rec2.ship_to_party, rec2.mtl_group, rec2.part_no,
                         rec2.plant_code, a_endcustomer, 'PL01', '2', '4',
                         rec2.mtl_type, '0', rec2.cogs_ob, rec2.cogs_ob_twd,
                         rec2.cogs_ob_usd, inamt, rec2.net_revenue_twd, 1,
                         SYSDATE
                        );

            COMMIT;
         END IF;
      END LOOP;
   END IF;
END pnl3_pls002_cogs_trx_s01;
/

