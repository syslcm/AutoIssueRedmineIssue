create PROCEDURE         "PLSQL_VAT016_QUANTITY_MGT" (
  inCompany  in VRT_SAP016_QUALITY_MANA.COMPANY_CODE%TYPE,
  f_YYYYMMDD in VARCHAR2,
  t_YYYYMMDD in VARCHAR2
)
is
/*
  MatGroup version -old  2015 regina@ms.usi.com.tw
*/
 iTracePoint  integer ;
 cErrorText varchar2(500);

BEGIN
  iTracePoint := 100;
  DELETE FROM VRT_SAP016_QUALITY_MANA WHERE COMPANY_CODE =inCompany
     and YYYYMM IN (SELECT YYYYMM FROM VRT_SAP016_QUALITY_MANA_T  WHERE  COMPANY_CODE =inCompany GROUP BY YYYYMM);

  iTracePoint := 200;
   Insert into VRT_SAP016_QUALITY_MANA (
           COMPANY_CODE , YYYYMM ,  SITE  ,  YYYY  ,  MM,  VENDOR_NO , SCORE    )
   Select  COMPANY_CODE , YYYYMM ,  SITE  ,  YYYY  ,  MM , VENDOR_NO,  SCORE
     from VRT_SAP016_QUALITY_MANA_T
    where COMPANY_CODE= inCompany
      and YYYYMM  IN (SELECT YYYYMM FROM VRT_SAP016_QUALITY_MANA_T  WHERE  COMPANY_CODE =inCompany GROUP BY YYYYMM);

  iTracePoint := 300;
   DELETE   FROM VRT_MAP030_SUMMARY_GRAD WHERE  TYPE ='QD' AND
                BUKRS = inCompany
           AND  YYYY||MM IN (SELECT YYYYMM FROM VRT_SAP016_QUALITY_MANA_T  WHERE  COMPANY_CODE =inCompany GROUP BY YYYYMM) ;

  iTracePoint := 400;
   EXECUTE IMMEDIATE 'INSERT INTO  VRT_MAP030_SUMMARY_GRAD
   SELECT  SITE, VENDOR_NO AS LIFNR , ''QD'' AS TYPE  ,yyyy, mm,''Q''||to_char(TO_DATE(YYYYMM||''01'',''YYYYMMDD''),''Q'') QUARTER, company_code as burks , ''S0'' AS L1,
     ROUND(SCORE*(SELECT percentage from VRT_MAP020_RATE_INDEX where INDEX_KEY =''QUALITY'' AND TYPE =''QD'' AND LEVEL_S = ''L1''),5) GRADE_L1,''Q0'' AS L2,
     ROUND(SCORE*(SELECT percentage from VRT_MAP020_RATE_INDEX where INDEX_KEY =''QUALITY'' AND TYPE =''QD'' AND LEVEL_S = ''L2''),5) GRADE_L2,''QD'' AS L3,
     ROUND(SCORE*(SELECT percentage from VRT_MAP020_RATE_INDEX where INDEX_KEY =''QUALITY'' AND TYPE =''QD'' AND LEVEL_S = ''L3''),5) GRADE_L3,''QD'' AS L4,
     ROUND(SCORE*(SELECT percentage from VRT_MAP020_RATE_INDEX where INDEX_KEY =''QUALITY'' AND TYPE =''QD'' AND LEVEL_S = ''L4''),5) AS GRADE_L4 FROM (SELECT   SITE, yyyy, yyyymm, mm, vendor_no,
           avg(SCORE) SCORE ,COMPANY_CODE fROM VRT_SAP016_QUALITY_MANA
       WHERE  COMPANY_CODE ='|| inCompany ||'
	       and YYYYMM  IN (SELECT YYYYMM FROM VRT_SAP016_QUALITY_MANA_T  WHERE  COMPANY_CODE ='|| inCompany ||' GROUP BY YYYYMM)
		   GROUP BY SITE, YYYY,YYYYMM,MM,VENDOR_NO,COMPANY_CODE)';
  iTracePoint := 500;
   DELETE  from VRT_SAP016_QUALITY_MANA_T
    where COMPANY_CODE =inCompany ;
  iTracePoint := 600;
   Commit;
  iTracePoint := 700;
EXCEPTION
  When OTHERS Then
    --有錯誤產生則寄mail
    cErrorText := SQLERRM();
    MAIL_FILE_BIDBDBADMIN(in_to_name => 'shuchin_lin@usiglobal.com', subject => '[VRT] PL/SQL PLSQL_VAT016_QUANTITY_MGT ERROR', message => '[PLSQL_VAT016_QUANTITY_MGT], The tracepoint is  ' || iTracePoint || ' and ErrorText= ' || cErrorText) ;

END PLSQL_VAT016_QUANTITY_MGT;
/

