create PROCEDURE PLSQL_DCF_SAP_QUOTA_ARR (
	inCOMPANY_CODE IN SAP_QUOTA_ARR_T.COMPANY_CODE%TYPE
)
AUTHID DEFINER
is
	iTracePoint                varchar2(100);
	cErrorText                 varchar2(500);
BEGIN
	iTracePoint := 'START';
	FOR REC1 in (
		select distinct COMPANY_CODE, PLANT, PART_NO from SAP_QUOTA_ARR_T where COMPANY_CODE = inCOMPANY_CODE
	) LOOP
		iTracePoint := REC1.COMPANY_CODE || '/' || REC1.PLANT || '/' || REC1.PART_NO;
		begin
			--delete old
			iTracePoint := 'D' || iTracePoint;
			delete from SAP_QUOTA_ARR where COMPANY_CODE = REC1.COMPANY_CODE
				and PLANT = REC1.PLANT and PART_NO = REC1.PART_NO;
			--insert new
			iTracePoint := 'I' || iTracePoint;
			insert into SAP_QUOTA_ARR
			select * from SAP_QUOTA_ARR_T where COMPANY_CODE = REC1.COMPANY_CODE
				and PLANT = REC1.PLANT and PART_NO = REC1.PART_NO;
			commit;
		exception
		when others then
			cErrorText := SQLERRM();
			MAIL_FILE_BIDBDBADMIN(in_to_name => 'minhorng@ms.usi.com.tw', subject => '[DCF] PL/SQL PLSQL_DCF_SAP_QUOTA_ARR (ETL-SAP) ERROR - ' || inCOMPANY_CODE, message => '[PLSQL_DCF_SAP_QUOTA_ARR], The tracepoint is  ' || iTracePoint || ' and ErrorText= ' || cErrorText) ;
			rollback;
		end;
	END LOOP;
END PLSQL_DCF_SAP_QUOTA_ARR;
/

