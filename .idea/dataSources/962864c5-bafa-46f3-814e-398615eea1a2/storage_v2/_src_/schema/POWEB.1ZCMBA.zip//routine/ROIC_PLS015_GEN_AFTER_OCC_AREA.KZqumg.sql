create PROCEDURE       ROIC_PLS015_GEN_AFTER_OCC_AREA (
/* ********************************************************************
  PROG-ID      : ROIC_PLS015_GEN_AFTER_OCC_AREA
  PROG-ACTION  : 
  Author       : Asan Chang
  Date         : 2019/10/25
  OA Number    : SAI107106
  Description  : Generate data of fixed assets
********************************************************************* 
* 2019/11/12 SAI107106 Asan Chang Modify �H�H�H�H�H�H�H�H�H�H�HD
*/
   incompany    IN   VARCHAR2,
   YYYYMM       IN   VARCHAR2
)
AUTHID DEFINER
IS
   CURSOR ROIC_ALL_AM
   IS
      /*
      select 
      a.COMPANY_CODE, a.PERIOD, a.ASSET_CLASS, a.ASSET_NO , a.ASSET_SUB_NO,
      a.COST_CENTER CCtr1, a.EV_GRP5 ,a.FYE_ACQ_VAL, a.CUR_NET_BOOK_VAL, a.S_SEQ,
      b.BUILDING ,b.OCC_AREA , b.RADIO ,b.COST_CENTER CCtr2      
      from ROA_SAP004_AM_LIST  a
      left join ROA_SAP003_OCC_AREA b 
      on  a.EV_GRP5 = b.BUILDING  
      and a.company_code =  b.company_code 
      and a.period = b.period      
      where a.COMPANY_CODE = incompany
      and a.PERIOD = YYYYMM;
      */
      select
      a.COMPANY_CODE, a.PERIOD, a.ASSET_CLASS, a.ASSET_NO , a.ASSET_SUB_NO,
      a.COST_CENTER CCtr1, a.EV_GRP5 ,a.FYE_ACQ_VAL, a.CUR_NET_BOOK_VAL BOOK_VAL, c.S_SEQ,
      b.BUILDING ,b.OCC_AREA , b.RADIO ,b.COST_CENTER CCtr2    ,
      ''  REASON_CODE, '' USE_CODE, '' CLASS_CODE      
      from ROIC_SAP001_AM_LIST  a
      left join ROIC_MAP004_AM_LIST_TYPE  c on  a.COMPANY_CODE = c.COMPANY_CODE and a.PERIOD = c.PERIOD and a.ASSET_CLASS = c.ASSET_CLASS 
	  and a.ASSET_NO = c.ASSET_NO and a.ASSET_SUB_NO = c.ASSET_SUB_NO
      left join  ROA_SAP003_OCC_AREA b on  a.EV_GRP5 = b.BUILDING and a.company_code =  b.company_code and a.period = b.period
      where a.COMPANY_CODE = incompany
      and a.PERIOD = YYYYMM

      UNION ALL

      select
      a.COMPANY_CODE, a.PERIOD, a.ASSET_CLASS, a.ASSET_NO , '0' as ASSET_SUB_NO,
      a.COST_CENTER CCtr1, '' as EV_GRP5 ,a.FYE_ACQ_VAL, a.CURR_NET_BOOK_VAL  BOOK_VAL, a.S_SEQ,
      '' as BUILDING ,TO_NUMBER('') as OCC_AREA ,  TO_NUMBER('') as RADIO ,'' as CCtr2,
      a.REASON_CODE, a.USE_CODE, a.CLASS_CODE
      from ROIC_UPL014_AM_ADJ a
      where a.COMPANY_CODE = incompany
      and a.PERIOD = YYYYMM;
      
   itracepoint         INTEGER;
   tmp_OWN_TYPE        VARCHAR(1);  --'A':�H�H�Hu�H�H�HB, 'B':�H�H�Hv�H�H�HB
   TMP_AMT1            NUMBER(15,5);
   TMP_AMT2            NUMBER(15,5);
   TMP_AMT3            NUMBER(15,5);
   TMP_AMT4            NUMBER(15,5);   
   TMP_AMT5            NUMBER(15,5);
   TMP_AMT6            NUMBER(15,5);  
   TMP_AMT7            NUMBER(15,5);
   TMP_AMT8            NUMBER(15,5);    
   TMP_CCTR            VARCHAR(10);
   EX_RATE_TWD1        NUMBER(15,5);
   EX_RATE_USD1        NUMBER(15,5);
   EX_RATE_CNY1        NUMBER(15,5);
   NEW_COMPANY_CODE    VARCHAR(4);
   sPROC_NAME          ROIC_PST000_LOG.PROC_NAME%TYPE;
   sRUN_SEQ            ROIC_PST000_LOG.RUN_SEQ%TYPE;
   sRUN_DESC           ROIC_PST000_LOG.RUN_DESC%TYPE;
   sPARAMETER_DESC     ROIC_PST000_LOG.PARAMETER_DESC%TYPE;    
BEGIN

  --(0)Insert Log start
  sPROC_NAME := 'ROIC_PLS015_GEN_AFTER_OCC_AREA';
  sRUN_SEQ   := '000010';
  sRUN_DESC  := 'Start';
  sPARAMETER_DESC := CONCAT(CONCAT(CONCAT('PERIOD=',YYYYMM),';Site='),incompany);
  
  
  INSERT INTO ROIC_PST000_LOG
      ( PROC_NAME, RUN_SEQ, RUN_DESC, PARAMETER_DESC )
    VALUES
      ( sPROC_NAME, sRUN_SEQ, sRUN_DESC, sPARAMETER_DESC );
  Commit;

     --(1)�HM�H�H�H�H�H�H�H�H
     DELETE FROM ROIC_PST015_AFTER_OCC_AREA
     where PERIOD       = YYYYMM
     AND   COMPANY_CODE = incompany;
     COMMIT;  
    
     DELETE FROM ROIC_PST015_AFTER_OCC_AREA
     where PERIOD       = YYYYMM
     AND   FROM_COMPANY_CODE = incompany;
     COMMIT; 

   FOR REC1 IN ROIC_ALL_AM LOOP
     SELECT EX_RATE_TWD, EX_RATE_USD, EX_RATE_CNY 
     INTO   EX_RATE_TWD1, EX_RATE_USD1, EX_RATE_CNY1 FROM ROIC_SAP001_AM_LIST 
     WHERE 
     COMPANY_CODE = incompany
     and PERIOD = YYYYMM 
     and rownum <= 1 and EX_RATE_TWD is not null;
     
 
     
     if REC1.EV_GRP5 IS NOT NULL then
       tmp_OWN_TYPE := 'A';
       TMP_AMT1 := ROUND(REC1.FYE_ACQ_VAL     / 100 * REC1.RADIO, 5);
       TMP_AMT2 := ROUND(REC1.BOOK_VAL        / 100 * REC1.RADIO, 5);
       TMP_AMT3 := ROUND(REC1.FYE_ACQ_VAL     / 100 * REC1.RADIO * EX_RATE_TWD1, 5);
       TMP_AMT4 := ROUND(REC1.BOOK_VAL        / 100 * REC1.RADIO * EX_RATE_TWD1, 5);       
       TMP_AMT5 := ROUND(REC1.FYE_ACQ_VAL     / 100 * REC1.RADIO * EX_RATE_USD1, 5);
       TMP_AMT6 := ROUND(REC1.BOOK_VAL        / 100 * REC1.RADIO * EX_RATE_USD1, 5);    
       TMP_AMT7 := ROUND(REC1.FYE_ACQ_VAL     / 100 * REC1.RADIO * EX_RATE_CNY1, 5);
       TMP_AMT8 := ROUND(REC1.BOOK_VAL        / 100 * REC1.RADIO * EX_RATE_CNY1, 5);
       
       TMP_CCTR := RTRIM(REC1.CCtr2, ' ') ;
     else
       tmp_OWN_TYPE := 'B';
       TMP_AMT1 := REC1.FYE_ACQ_VAL;
       TMP_AMT2 := REC1.BOOK_VAL ; 
       TMP_AMT3 := REC1.FYE_ACQ_VAL      * EX_RATE_TWD1;
       TMP_AMT4 := REC1.BOOK_VAL         * EX_RATE_TWD1;        
       TMP_AMT5 := REC1.FYE_ACQ_VAL      * EX_RATE_USD1;
       TMP_AMT6 := REC1.BOOK_VAL         * EX_RATE_USD1; 
       TMP_AMT7 := REC1.FYE_ACQ_VAL      * EX_RATE_CNY1;
       TMP_AMT8 := REC1.BOOK_VAL         * EX_RATE_CNY1;        
       TMP_CCTR := RTRIM(REC1.CCtr1, ' ');       
     end if; 
     
     NEW_COMPANY_CODE := ''; 
     
     BEGIN
     select TO_COMPANY_CODE  INTO NEW_COMPANY_CODE  FROM ROA_UPL008_ALLOC_TO_SITE WHERE COMPANY_CODE = incompany AND RTRIM(COST_CENTER) = TMP_CCTR; 
       --(3)�H}�Hl�HB�Hz�H�H�H�H
       INSERT INTO ROIC_PST015_AFTER_OCC_AREA (
       
       /*
       COMPANY_CODE ,       
       PERIOD ,      
       ASSET_NO ,            
       ASSET_SUB_NO ,        
       EV_GRP5 ,      
       SENDER_COST_CENTER ,  
       RECEIVER_COST_CENTER ,
       BUILDING ,
       OCC_AREA ,          
       RADIO ,          
       OWN_TYPE ,            
       ACQ_VAL ,          
       BOOK_VAL ,           
       ORIGINAL_ACQ_VAL ,    
       ORIGINAL_BOOK_VAL ,  
       S_SEQ, 
       FROM_COMPANY_CODE
       */
       
       COMPANY_CODE ,
       PERIOD ,
       ASSET_NO ,
       ASSET_SUB_NO ,
       EV_GRP5 ,
       SENDER_COST_CENTER ,
       RECEIVER_COST_CENTER ,
       BUILDING ,
       OCC_AREA ,
       RADIO ,
       OWN_TYPE ,
       ORIGINAL_ACQ_VAL,
       ORIGINAL_BOOK_VAL,         
       ACQ_VAL ,
       BOOK_VAL ,
       ACQ_VAL_TWD ,
       BOOK_VAL_TWD ,
       ACQ_VAL_USD ,
       BOOK_VAL_USD , 
       ACQ_VAL_CNY ,
       BOOK_VAL_CNY ,    
       S_SEQ ,  
       REASON_CODE ,
       USE_CODE ,
       CLASS_CODE , 
       FROM_COMPANY_CODE
       
       
       
       
       ) VALUES (  
       NEW_COMPANY_CODE ,
       REC1.PERIOD ,
       REC1.ASSET_NO ,
       REC1.ASSET_SUB_NO ,
       REC1.EV_GRP5 ,
       REC1.CCtr1 ,  
       RTRIM(TMP_CCTR, ' ') ,
       REC1.BUILDING ,
       REC1.OCC_AREA ,
       REC1.RADIO ,
       tmp_OWN_TYPE, 
       REC1.FYE_ACQ_VAL ,    
       REC1.BOOK_VAL ,         
       TMP_AMT1 ,
       TMP_AMT2 ,
       TMP_AMT3 ,
       TMP_AMT4 ,
       TMP_AMT5,
       TMP_AMT6 , 
       TMP_AMT7 ,
       TMP_AMT8 ,    
       REC1.S_SEQ ,  
       REC1.REASON_CODE ,
       REC1.USE_CODE ,
       REC1.CLASS_CODE , 
       REC1.COMPANY_CODE );       
       
       /*       
       NEW_COMPANY_CODE,       
       REC1.PERIOD ,      
       REC1.ASSET_NO ,            
       REC1.ASSET_SUB_NO ,        
       REC1.EV_GRP5,      
       REC1.CCtr1 ,  
       RTRIM(TMP_CCTR, ' ') ,
       REC1.BUILDING ,
       REC1.OCC_AREA ,          
       REC1.RADIO ,          
       tmp_OWN_TYPE,            
       TMP_AMT1 ,          
       TMP_AMT2 ,           
       REC1.FYE_ACQ_VAL ,    
       REC1.CUR_NET_BOOK_VAL ,  
       REC1.S_SEQ,
       REC1.COMPANY_CODE  );
       */
       COMMIT;  
       
              
     EXCEPTION
       WHEN NO_DATA_FOUND THEN  
       --(3)�H}�Hl�HB�Hz�H�H�H�H
       INSERT INTO ROIC_PST015_AFTER_OCC_AREA (
       /*
       COMPANY_CODE ,       
       PERIOD ,      
       ASSET_NO ,            
       ASSET_SUB_NO ,        
       EV_GRP5 ,      
       SENDER_COST_CENTER ,  
       RECEIVER_COST_CENTER ,
       BUILDING ,
       OCC_AREA ,          
       RADIO ,          
       OWN_TYPE ,            
       ACQ_VAL ,          
       BOOK_VAL ,           
       ORIGINAL_ACQ_VAL ,    
       ORIGINAL_BOOK_VAL ,  
       S_SEQ*/
       COMPANY_CODE ,
       PERIOD ,
       ASSET_NO ,
       ASSET_SUB_NO ,
       EV_GRP5 ,
       SENDER_COST_CENTER ,
       RECEIVER_COST_CENTER ,
       BUILDING ,
       OCC_AREA ,
       RADIO ,
       OWN_TYPE ,
       ORIGINAL_ACQ_VAL,
       ORIGINAL_BOOK_VAL,         
       ACQ_VAL ,
       BOOK_VAL ,
       ACQ_VAL_TWD ,
       BOOK_VAL_TWD ,
       ACQ_VAL_USD ,
       BOOK_VAL_USD , 
       ACQ_VAL_CNY ,
       BOOK_VAL_CNY ,    
       S_SEQ ,  
       REASON_CODE ,
       USE_CODE ,
       CLASS_CODE        
       
       
       ) VALUES (                                 
       /*REC1.COMPANY_CODE ,       
       REC1.PERIOD ,      
       REC1.ASSET_NO ,            
       REC1.ASSET_SUB_NO ,        
       REC1.EV_GRP5,      
       REC1.CCtr1 ,  
       RTRIM(TMP_CCTR, ' ') ,
       REC1.BUILDING ,
       REC1.OCC_AREA ,          
       REC1.RADIO ,          
       tmp_OWN_TYPE,            
       TMP_AMT1 ,          
       TMP_AMT2 ,           
       REC1.FYE_ACQ_VAL ,    
       REC1.CUR_NET_BOOK_VAL ,  
       REC1.S_SEQ*/
       REC1.COMPANY_CODE ,
       REC1.PERIOD ,
       REC1.ASSET_NO ,
       REC1.ASSET_SUB_NO ,
       REC1.EV_GRP5 ,
       REC1.CCtr1 ,  
       RTRIM(TMP_CCTR, ' ') ,
       REC1.BUILDING ,
       REC1.OCC_AREA ,
       REC1.RADIO ,
       tmp_OWN_TYPE, 
       REC1.FYE_ACQ_VAL ,    
       REC1.BOOK_VAL ,         
       TMP_AMT1 ,
       TMP_AMT2 ,
       TMP_AMT3 ,
       TMP_AMT4 ,
       TMP_AMT5,
       TMP_AMT6 , 
       TMP_AMT7 ,
       TMP_AMT8 ,    
       REC1.S_SEQ ,  
       REC1.REASON_CODE ,
       REC1.USE_CODE ,
       REC1.CLASS_CODE    
       
       
           ); 
       COMMIT;     
     END;
     
     
   END LOOP;

  -----------------------------------------
  --(0)Insert Log end
  sRUN_SEQ   := '000020';
  sRUN_DESC  := 'End';

  --Insert Log
  INSERT INTO ROIC_PST000_LOG
      ( PROC_NAME, RUN_SEQ, RUN_DESC, PARAMETER_DESC )
    VALUES
      ( sPROC_NAME, sRUN_SEQ, sRUN_DESC, sPARAMETER_DESC );
  Commit;   
   
END ROIC_PLS015_GEN_AFTER_OCC_AREA;
/

