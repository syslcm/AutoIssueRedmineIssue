create PROCEDURE PLSQL_EC_VR011_GR_T (
	inCompany  in VARCHAR2,
	f_YYYYMMDD in VARCHAR2,
	t_YYYYMMDD in VARCHAR2
)
AUTHID DEFINER
is
	/*
	處理資料並放到正式 table
	*/
	iTracePoint         integer;
	cErrorText          varchar2(500);
	nEXEC_PERIOD        EC_VR011_GR_T.EXEC_PERIOD%TYPE;
	nFR_DATE            EC_VR011_GR_T.CREATE_DATE%TYPE;
	nTO_DATE            EC_VR011_GR_T.CREATE_DATE%TYPE;
	nCREATE_DATE        EC_VR011_GR_T.CREATE_DATE%TYPE;

BEGIN
	iTracePoint := 100;
	cErrorText := '';
	nEXEC_PERIOD := null;
	nCREATE_DATE := null;
	begin
		select * into nCREATE_DATE from (
			select min(CREATE_DATE) from EC_VR011_GR_T
				where CREATE_DATE <> t_YYYYMMDD
		) where rownum <= 1;
	exception
		when others then
			nCREATE_DATE := null;
	end;
	-- OK get data
	if nCREATE_DATE is null then
		iTracePoint := 200;
		select distinct EXEC_PERIOD into nEXEC_PERIOD from EC_VR011_GR_T
			where CREATE_DATE = t_YYYYMMDD;
		nFR_DATE := substr(nEXEC_PERIOD,1,8);
		nTO_DATE := substr(nEXEC_PERIOD,9,8);
		-- 清舊的正式資料
		iTracePoint := 210;
		delete from EC_VR011_GR
			where GR_DATE >= nFR_DATE and GR_DATE <= nTO_DATE;
		commit;
		insert into EC_VR011_GR
			select * from EC_VR011_GR_T where GR_DATE >= nFR_DATE and GR_DATE <= nTO_DATE;
		commit;
	-- nCREATE_DATE not null -> fail data
	else
		iTracePoint := 900;
		cErrorText := 'CREATE_DATE get ' || nCREATE_DATE;
		MAIL_FILE_BIDBDBADMIN(in_to_name=>'minhorng@ms.usi.com.tw',subject   => '[KPI] PL/SQL PLSQL_EC_VR011_GR_T ERROR - Company: ' || inCompany, message => '[PLSQL_EC_VR011_GR_T], The tracepoint is  ' || to_char(iTracePoint) || ' and ErrorText=' || cErrorText) ;
	end if;
EXCEPTION
	WHEN OTHERS THEN
		cErrorText := SQLERRM();
		MAIL_FILE_BIDBDBADMIN(in_to_name=>'minhorng@ms.usi.com.tw',subject   => '[KPI] PL/SQL PLSQL_EC_VR011_GR_T ERROR - Company: ' || inCompany, message => '[PLSQL_EC_VR011_GR_T], The tracepoint is  ' || to_char(iTracePoint) || ' and ErrorText=' || cErrorText) ;
		rollback;
END;
/

