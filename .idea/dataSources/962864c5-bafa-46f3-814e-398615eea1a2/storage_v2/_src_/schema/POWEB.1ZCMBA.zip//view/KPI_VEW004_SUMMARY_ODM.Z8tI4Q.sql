create view KPI_VEW004_SUMMARY_ODM as
SELECT "BG", "COMPANY_CODE", "PLANT_CODE", "PERIOD", "PART_NO",
          "PROFIT_CENTER", "PARTNER_PROFIT_CENTER", "ACCOUNT_ASSIGNMENT",
          "MTL_GROUP", "MTL_GROUP_1", "RELATED_PARTY", "MTL_TYPE",
          "MTL_TYPE_AF", "NET_QTY", "NET_REVENUE", "NET_REVENUE_USD",
          "NET_REVENUE_TWD", "SOURCE", "PROJECT_NAME", "PROJECT_TYPE"
     FROM kpi_sap011_revenue_sum a, kpi_zot001_pdm_project d
    WHERE a.part_no = d.fg_no(+)
   UNION ALL
   SELECT NVL ((SELECT d.bg_id
                  FROM kpi_map002_bg_map d
                 WHERE d.company_code = c.company_code
                   AND d.profit_center = c.profit_center
                   AND d.start_date < SYSDATE
                   AND d.end_date > SYSDATE),
               'Others'
              ) bg,
          c.company_code, c.plant_code, c.period, c.part_no, c.profit_center,
          c.partner_profit_center, c.account_assignment, c.mtl_group,
          c.mtl_group_1, c.related_party, c.mtl_type, c.mtl_type_af,
          c.net_qty, c.net_revenue, c.net_revenue_usd, c.net_revenue_twd,
          c.adj_kind, c.project_name, c.project_type
     FROM (SELECT   c.company_code, ' ' AS plant_code, c.period,
                    ' ' AS part_no, c.profit_center, c.partner_profit_center,
                    c.account_assignment, ' ' AS mtl_group,
                    ' ' AS mtl_group_1, c.related_party, ' ' AS mtl_type,
                    ' ' AS mtl_type_af, 0 AS net_qty,
                    SUM (c.net_revenue) net_revenue,
                    SUM (c.net_revenue_usd) net_revenue_usd,
                    SUM (c.net_revenue_twd) net_revenue_twd, c.adj_kind,
                    '' AS project_name, '' AS project_type
               FROM kpi_upl001_revenue_trx c
           GROUP BY c.company_code,
                    c.period,
                    c.adj_kind,
                    c.profit_center,
                    c.partner_profit_center,
                    c.account_assignment,
                    c.related_party) c
/

