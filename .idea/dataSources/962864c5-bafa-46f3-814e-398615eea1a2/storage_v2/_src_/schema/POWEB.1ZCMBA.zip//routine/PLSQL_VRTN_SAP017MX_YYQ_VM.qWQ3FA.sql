create PROCEDURE         "PLSQL_VRTN_SAP017MX_YYQ_VM" (
  inCompany  in VRTN_SAP017MX_QQ_MAIL_LIST.COMPANY_CODE%TYPE,
  f_YYYYMMDD in VARCHAR2,
  t_YYYYMMDD in VARCHAR2 
)
is
 iTracePoint  integer ;
 cErrorText varchar2(500);

 /*
  2018/05/10 Susan 
  MX Site By vendor summary qq vendor 
*/
BEGIN
 
 
 

 
   DELETE FROM VRTN_SAP017MX_QQ_MAIL_LIST WHERE COMPANY_CODE =inCompany
          and QUARTER IN (SELECT QUARTER FROM  VRTN_SAP017MX_QQ_MAIL_LIST_T  WHERE  COMPANY_CODE =inCompany GROUP BY QUARTER);
   
   iTracePoint := 300; 
   Insert into VRTN_SAP017MX_QQ_MAIL_LIST  (
           QUARTER, GV_VENDOR, COMPANY_CODE, VENDOR  )
   Select  QUARTER,  GV_VENDOR, COMPANY_CODE, VENDOR 
     from VRTN_SAP017MX_QQ_MAIL_LIST_T
    where COMPANY_CODE= inCompany
      and QUARTER IN (SELECT QUARTER FROM VRTN_SAP017MX_QQ_MAIL_LIST_T WHERE COMPANY_CODE =inCompany GROUP BY QUARTER);



  iTracePoint := 400;
 --  DELETE  from VRTN_SAP017MX_QQ_MAIL_LIST_T
 --     where COMPANY_CODE = inCompany
 --     and QUARTER IN (SELECT QUARTER FROM VRTN_SAP017MX_QQ_MAIL_LIST_T  WHERE COMPANY_CODE =inCompany GROUP BY QUARTER);

   Commit;
EXCEPTION
  When OTHERS Then
    --有錯誤產生則寄mail
    cErrorText := SQLERRM();
    MAIL_FILE_BIDBDBADMIN(in_to_name => 'shuchin_lin@usiglobal.com', subject => '[VRTN] PLSQL_VRTN_SAP017MX_YYQ_VM ERROR', message => '[PLSQL_VATN014_MANUAL_SCORE], The tracepoint is  ' || iTracePoint || ' and ErrorText= ' || cErrorText) ;

END PLSQL_VRTN_SAP017MX_YYQ_VM;
/

