create PROCEDURE vqa_plsql_lfo_mm
AUTHID DEFINER
IS
   vprocee_yyyymm   VARCHAR2 (6);
BEGIN
   vprocee_yyyymm := TO_CHAR (SYSDATE - 7, 'YYYYMM');

   --刪除資料
   DELETE FROM vqa_lfo_monthly
         WHERE yyyymm = vprocee_yyyymm;

   -- insert
   INSERT INTO vqa_lfo_monthly
      SELECT   a.company_code, SUBSTR (vprocee_yyyymm, 1, 4) AS yyyy,
               SUBSTR (vprocee_yyyymm, 5, 2) AS mm,
                  'Q'
               || TO_CHAR (TO_DATE (vprocee_yyyymm || '01', 'yyyymmdd'), 'Q')
                                                                  AS quarter,
               a.mfr_name, a.component, a.mfr_pn,
               SUM (b.error_cnt * a.qpa) / SUM (a.wo_qty) * 1000000 AS lfo,
               TO_CHAR (SYSDATE, 'YYYYMMDDHH24MISS') AS date_time,
               vprocee_yyyymm AS yyyymm,
               SUM (b.error_cnt * a.qpa) AS error_cnt,
               SUM (a.wo_qty) AS total_cnt
          FROM vqa_lfo_wo_qpa a,
               (SELECT   company_code, mo_number, mfr_name, usi_pn, mfr_pn,
                         SUM (cnt) AS error_cnt
                    FROM vqa_lfo_error_cnt
                   WHERE repair_date LIKE vprocee_yyyymm || '%'
                GROUP BY company_code, mo_number, mfr_name, usi_pn, mfr_pn) b
         WHERE a.component = b.usi_pn
           AND a.mfr_name = b.mfr_name
           AND a.mfr_pn = b.mfr_pn
           AND a.company_code = b.company_code
           AND a.work_order = b.mo_number
      GROUP BY a.company_code, a.mfr_name, a.component, a.mfr_pn;

   COMMIT;

   INSERT INTO vqa_lfo_monthly
      SELECT   '0000', SUBSTR (vprocee_yyyymm, 1, 4) AS yyyy,
               SUBSTR (vprocee_yyyymm, 5, 2) AS mm,
                  'Q'
               || TO_CHAR (TO_DATE (vprocee_yyyymm || '01', 'yyyymmdd'), 'Q')
                                                                   AS quarter,
               a.mfr_name, a.component, a.mfr_pn,
               SUM (b.error_cnt * a.qpa) / SUM (a.wo_qty) * 1000000 AS lfo,
               TO_CHAR (SYSDATE, 'YYYYMMDDHH24MISS') AS date_time,
               vprocee_yyyymm AS yyyymm,
               SUM (b.error_cnt * a.qpa) AS error_cnt,
               SUM (a.wo_qty) AS total_cnt
          FROM vqa_lfo_wo_qpa a,
               (SELECT   company_code, mo_number, mfr_name, usi_pn, mfr_pn,
                         SUM (cnt) AS error_cnt
                    FROM vqa_lfo_error_cnt
                   WHERE repair_date LIKE vprocee_yyyymm || '%'
                GROUP BY company_code, mo_number, mfr_name, usi_pn, mfr_pn) b
         WHERE a.component = b.usi_pn
           AND a.mfr_name = b.mfr_name
           AND a.mfr_pn = b.mfr_pn
           AND a.company_code = b.company_code
           AND a.work_order = b.mo_number
      GROUP BY a.company_code, a.mfr_name, a.component, a.mfr_pn;

   COMMIT;

   update vqa_lfo_monthly set lfo = '1000000'
         WHERE yyyymm = vprocee_yyyymm AND lfo > 1000000;

   COMMIT;
END vqa_plsql_lfo_mm;
/

