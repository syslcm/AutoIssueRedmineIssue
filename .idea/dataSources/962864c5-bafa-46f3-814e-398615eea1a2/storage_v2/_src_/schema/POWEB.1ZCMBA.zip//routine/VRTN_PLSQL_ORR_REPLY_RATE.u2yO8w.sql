create PROCEDURE         "VRTN_PLSQL_ORR_REPLY_RATE" IS
  /*
    每月一號執行一次
   (當 VRTN_PLSQL_SAP005_ON_TIME_DEL 執行 site 1100 時會呼叫此PL/SQL)
    1. 抓 VRTN_MAP020_RATE_INDEX - 各階層的分數比率
    2. 抓 VRTN_VEW001_ORR_REPLY_RATE 資料 ( ORR 回覆率分數 - DF)
    3. 將計算後值放到 VRTN_MAP030_SUMMARY_GRAD
    (VRTN_MAP030_SUMMARY_GRAD-L1,L2,L3,L4 參考文件 VRTN_MAP060_LEVEL_DESC)
  */

  vPROCEE_YYYYMM             varchar2(6);
  vPERCENTAGE_L1             VRTN_MAP020_RATE_INDEX.PERCENTAGE%TYPE;
  vPERCENTAGE_L2             VRTN_MAP020_RATE_INDEX.PERCENTAGE%TYPE;
  vPERCENTAGE_L3             VRTN_MAP020_RATE_INDEX.PERCENTAGE%TYPE;
  vPERCENTAGE_L4             VRTN_MAP020_RATE_INDEX.PERCENTAGE%TYPE;

  iTracePoint                varchar2(100);
  cErrorText                 varchar2(500);

BEGIN
  --抓上個月份
  iTracePoint := '100';
  vPROCEE_YYYYMM := TO_CHAR(ADD_MONTHS(SYSDATE, -1), 'YYYYMM');

  --抓各階分數
  iTracePoint := '200';
  vPERCENTAGE_L1 := null;
  vPERCENTAGE_L2 := null;
  vPERCENTAGE_L3 := null;
  vPERCENTAGE_L4 := null;

  for REC1 in ( select LEVEL_S, PERCENTAGE from VRTN_MAP020_RATE_INDEX
                 where INDEX_KEY = 'DELIVERY' and TYPE = 'DF' ) loop
    if REC1.LEVEL_S = 'L1' then
      iTracePoint := '210';
      vPERCENTAGE_L1 := REC1.PERCENTAGE;
    elsif REC1.LEVEL_S = 'L2' then
      iTracePoint := '220';
      vPERCENTAGE_L2 := REC1.PERCENTAGE;
    elsif REC1.LEVEL_S = 'L3' then
      iTracePoint := '230';
      vPERCENTAGE_L3 := REC1.PERCENTAGE;
    elsif REC1.LEVEL_S = 'L4' then
      iTracePoint := '240';
      vPERCENTAGE_L4 := REC1.PERCENTAGE;
    end if;
  end loop;

  if vPERCENTAGE_L1 is null or vPERCENTAGE_L2 is null or vPERCENTAGE_L3 is null or vPERCENTAGE_L4 is null then
    --若沒抓到資料則寄 error mail
    iTracePoint := '250';
    cErrorText := 'vPERCENTAGE_L1 is ' || nvl(to_char(vPERCENTAGE_L1),'null') || ',vPERCENTAGE_L2 is ' || nvl(to_char(vPERCENTAGE_L2),'null') || ',vPERCENTAGE_L3 is ' || nvl(to_char(vPERCENTAGE_L3),'null') || ',vPERCENTAGE_L4 is ' || nvl(to_char(vPERCENTAGE_L4),'null');
    MAIL_FILE_BIDBDBADMIN(in_to_name => 'shuchin_line@usiglobal.com', subject => '[VRTN] PL/SQL VRTN_PLSQL_ORR_REPLY_RATE ERROR', message => '[VRTN_PLSQL_ORR_REPLY_RATE], The tracepoint is  ' || iTracePoint || ' and ErrorText= ' || cErrorText) ;
  else
    --先清舊的資料以避免重覆
    iTracePoint := '300-' || vPROCEE_YYYYMM;
    delete from VRTN_MAP030_SUMMARY_GRAD where TYPE = 'DF'
       and YYYY = substr(vPROCEE_YYYYMM,1,4) and MM = substr(vPROCEE_YYYYMM,5,2);
    commit;

    --放入上月分數
    iTracePoint := '400';
    for REC1 in ( select SITE, VENDOR_CODE, MTL_GROUP, PTYPE, YYYY, MM, QUARTER, COMPANY_CODE,
                         round( SUM(REPLY_CNT) / SUM(SEND_CNT) * 100, 5) as SCORE
                    from VRTN_VEW001_ORR_REPLY_RATE where YYYYMM = vPROCEE_YYYYMM
                   group by SITE, VENDOR_CODE, MTL_GROUP, PTYPE, YYYY, MM, QUARTER, COMPANY_CODE ) loop
      --放到 VRTN_MAP030_SUMMARY_GRAD
      iTracePoint := '400-' || REC1.SITE || '-' || REC1.VENDOR_CODE || '-' || vPROCEE_YYYYMM;
      insert into VRTN_MAP030_SUMMARY_GRAD (
             SITE, LIFNR, MATGROUP, TYPE, YYYY, MM, QUARTER, BUKRS, L1, GRADE_L1, L2, GRADE_L2, L3, GRADE_L3, L4, GRADE_L4
           ) values (
             REC1.SITE,
             REC1.VENDOR_CODE,
			 REC1.MTL_GROUP,
             REC1.PTYPE,
             REC1.YYYY,
             REC1.MM,
             REC1.QUARTER,
             REC1.COMPANY_CODE,
             'S0',
             round(REC1.SCORE * vPERCENTAGE_L1, 5),
             'D0',
             round(REC1.SCORE * vPERCENTAGE_L2, 5),
             'D3',
             round(REC1.SCORE * vPERCENTAGE_L3, 5),
             'DF',
             round(REC1.SCORE * vPERCENTAGE_L4, 5)
           );
      commit;
    end loop;
  end if;

EXCEPTION
  When OTHERS Then
    --有錯誤產生則寄mail
    cErrorText := SQLERRM();
    MAIL_FILE_BIDBDBADMIN(in_to_name => 'shuchin_lin@usiglobal.com', subject => '[VRTN] PL/SQL VRTN_PLSQL_ORR_REPLY_RATE ERROR', message => '[VRTN_PLSQL_ORR_REPLY_RATE], The tracepoint is  ' || iTracePoint || ' and ErrorText= ' || cErrorText) ;
END;
/

