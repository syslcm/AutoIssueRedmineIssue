create PROCEDURE PNL_PLS002_CALU_DATA_SUB01 (
  inCompany  in VARCHAR2,
  f_YYYYMMDD in VARCHAR2,
  t_YYYYMMDD in VARCHAR2
)
AUTHID DEFINER
/*********************************************************************
  PROG-ID      : PNL_PLS002_CALU_DATA_SUB01
  PROG-ACTION  : PROCESS BUDGET DATA TO PNL_TRX001_DATA(01-BGT)
               : AMOUNT * -1
  Author       : KANGI
  Date         : 2007/03/27
**********************************************************************/
is
   iTracePoint  integer ;
   cErrorText varchar2(500) ;
   cPNL_YYYY PNL_TRX001_DATA.YEAR%TYPE;
   fUSD_TO_TWD_RATE float ;
   dRUNDATE DATE ;

 BEGIN
   iTracePoint := 100 ;
   cPNL_YYYY := TO_CHAR(SYSDATE,'YYYY');
   dRUNDATE := SYSDATE ;
   iTracePoint := 200 ;
   ----DELETE PNL_MSS001_BGT_DATA
   DELETE PNL_TRX001_DATA WHERE YEAR = cPNL_YYYY AND TOP_KIND = '01-BGT';
   iTracePoint := 300 ;
   ----INSERT PNL_TRX001_DATA FROM PNL_MSS001_BGT_DATA
   ---BUDGET ('REV')
   INSERT INTO PNL_TRX001_DATA
   SELECT COMPANY_CODE,YEAR,PERIOD,
          PROFIT_CENTER,'01-BGT' TOP_KIND,
	        DECODE(CLASS,'REV','01.1',CLASS) SIDE_KIND,
	        'Budget' TOP_PERIOD,
	        SUM(AMT_LOCAL) AMT_LOCAL,SUM(AMT_USD) AMT_USD,
	        SUM(AMT_TWD) AMT_TWD,NULL TO_PERIOD,
	        dRUNDATE
          FROM PNL_MSS001_BGT_DATA
          WHERE YEAR = '2007'
            AND CLASS IN ('REV')
          GROUP BY COMPANY_CODE,YEAR,PROFIT_CENTER,
                   PERIOD,CLASS ;
    iTracePoint := 400 ;


   ----INSERT PNL_TRX001_DATA FROM PNL_MSS001_BGT_DATA
   ---BUDGET ('REV','DM','DL','OH','AD','RD')
   INSERT INTO PNL_TRX001_DATA
   SELECT COMPANY_CODE,YEAR,PERIOD,
          PROFIT_CENTER,'01-BGT' TOP_KIND,
	        DECODE(CLASS,'DM','02.1','DL','02.2','OH','02.3','AD','03.2','RD','03.3',CLASS) SIDE_KIND,
	        'Budget' TOP_PERIOD,
	        SUM(AMT_LOCAL)*-1 AMT_LOCAL,SUM(AMT_USD)*-1 AMT_USD,
	        SUM(AMT_TWD)*-1 AMT_TWD,NULL TO_PERIOD,
	        dRUNDATE
          FROM PNL_MSS001_BGT_DATA
          WHERE YEAR = '2007'
            AND CLASS IN ('DM','DL','OH','AD','RD')
          GROUP BY COMPANY_CODE,YEAR,PROFIT_CENTER,
                   PERIOD,CLASS ;
    iTracePoint := 400 ;
    ---Add Salary(03.1.S=>0200,0201,0202)
    ---BUDGET ('SALE')
    INSERT INTO PNL_TRX001_DATA
    SELECT COMPANY_CODE,YEAR,PERIOD,
           PROFIT_CENTER,'01-BGT' TOP_KIND,
	         DECODE(ACCOUNT,'0900','03.1.1','1800','03.1.1','3400','03.1.2','2400','03.1.3','0200','03.1.S','0201','03.1.S','0202','03.1.S','03.1.A') SIDE_KIND,
	         'Budget' TOP_PERIOD,
	         SUM(AMT_LOCAL)*-1 AMT_LOCAL,SUM(AMT_USD)*-1 AMT_USD,
	         SUM(AMT_TWD)*-1 AMT_TWD,NULL TO_PERIOD,
	         dRUNDATE
           FROM PNL_MSS001_BGT_DATA
           WHERE YEAR = '2007'
             AND CLASS IN ('SALE')
           GROUP BY COMPANY_CODE,YEAR,PROFIT_CENTER,
                    PERIOD,ACCOUNT ;

   iTracePoint := 500 ;
   COMMIT ;
 EXCEPTION
     WHEN OTHERS THEN
            --rollback ;
            cErrorText := SQLERRM() ;
            MAIL_FILE_BIDBDBADMIN(in_to_name=>'kangi@ms.usi.com.tw',subject   => 'PL/SQL PNL_PLS002_CALU_DATA ERROR', message => '[PNL_PLS002_CALU_DATA_SUB01], The tracepoint is  ' || to_char(iTracePoint) || 'and ErrorText=' || cErrorText) ;
            DBMS_OUTPUT.PUT_LINE(SUBSTR(cErrorText,1,255));
            DBMS_OUTPUT.PUT_LINE(TO_CHAR(iTracePoint));
END PNL_PLS002_CALU_DATA_SUB01;
/

