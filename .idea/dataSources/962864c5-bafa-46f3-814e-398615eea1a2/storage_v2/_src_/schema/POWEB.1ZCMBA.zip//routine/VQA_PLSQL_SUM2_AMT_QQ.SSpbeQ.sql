create PROCEDURE         "VQA_PLSQL_SUM2_AMT_QQ" IS

      /*--------------------------------------------------------------*
         CREATE DATE:  2008/02/29
         PLSQL      :  VQA_PLSQL_SUM2_AMT_QQ
         Purpase    :  Amount Summary(By 每月執行一次 for 季資料 TW/SZ/SH
             table: Insert to VQA_SUM04_AMT_MATGP_Q table&
                          VQA_SUM05_AMT_MF_Q  table&
      *---------------------------------------------------------------*
      */

 vPROCEE_YYYYMMDD varchar2(8);
 vPROCEE_YYYYMM   varchar2(6);
 iTracePoint      varchar2(100);
 cErrorText       varchar2(500);
 vCOMPANY_CODE    varchar2(4);
 vYYYYMM          varchar2(6);
 vSTART_DATE      varchar2(8);
 vEND_DATE        varchar2(8);
 vQUARTER         varchar2(8);

 vCK_MANUF        varchar2(10);
-- vIR_AMT_TWD      PLD_KPI_IR_DETAIL.IR_AMT_TWD%TYPE;
 vIR_AMT_TWD        NUMBER(17,5); 

BEGIN
    vCOMPANY_CODE := null;
    vYYYYMM := null;
    vSTART_DATE := null;
    vEND_DATE := null;
    vQUARTER := null;
    vCK_MANUF := null;
    vIR_AMT_TWD := null;

   --抓上個月資料
     iTracePoint := '100';
     vPROCEE_YYYYMM := TO_CHAR(ADD_MONTHS(SYSDATE, -1), 'YYYYMM');
   --抓季資料
      for REC1 in (Select QUARTER
                          FROM DIMENSION_DATE
                          WHERE YYYY = SUBSTRB(vPROCEE_YYYYMM,1,4)
                            AND MM = SUBSTRB(vPROCEE_YYYYMM,5,2)
                            ) loop
         vQUARTER := SUBSTRB(vPROCEE_YYYYMM,1,4) || REC1.QUARTER;
      end loop;
    --抓季起始區間資料
         for REC1 in (Select MIN(DATE_KEY) AS DATE_KEY
                             FROM DIMENSION_DATE
                             WHERE QUARTER = SUBSTRB(vQUARTER,5,2)
                               AND YYYY = SUBSTRB(vQUARTER,1,4)
                               ) loop
            vSTART_DATE := REC1.DATE_KEY;
         end loop;
    --抓季終上區間資料
        for REC1 in (Select MAX(DATE_KEY) AS DATE_KEY
                            FROM DIMENSION_DATE
                            WHERE QUARTER = SUBSTRB(vQUARTER,5,2)
                              AND YYYY = SUBSTRB(vQUARTER,1,4)
                             ) loop
            vEND_DATE := REC1.DATE_KEY;
        end loop;



  if vQUARTER is null then
     --若沒抓到資料則寄 error mail
     iTracePoint := '110';
     cErrorText := 'QUARTER error!';
     MAIL_FILE_BIDBDBADMIN(in_to_name => 'shuchin@ms.usi.com.tw', subject => '[VQA] PL/SQL VRTN_PLSQL_SUM4_GV_AMT_QQ ERROR', message => '[VQA_PLSQL_SUM2_AMT_QQ], The tracepoint is  ' || iTracePoint || ' and ErrorText= ' || cErrorText) ;
  else

     --清除舊的 VQA_SUM04_AMT_MATGP_Q 資料
       iTracePoint := '200';
       DELETE FROM VQA_SUM04_AMT_MATGP_Q WHERE QUARTER = vQUARTER;


     --放入季Amount  BY SITE,MANUF,MATGROUP
       iTracePoint := '210';
       for REC1 in ( Select SITE, MANUF, MATGROUP, QUARTER, BUKRS, round(SUM(AMOUNT), 2) as Q_AMOUNT
                            from VQA_SUM01_AMT_MATGP_M
                            where MANUF is Not Null
                              and MATGROUP is Not Null
                              and QUARTER = vQUARTER
                    Group by SITE, MANUF, MATGROUP, QUARTER, BUKRS
                    ) loop
      --放到 VQA_SUM04_AMT_MATGP_Q
      iTracePoint := '220-' || REC1.MANUF || '-' || REC1.MATGROUP || '-' || vPROCEE_YYYYMM || REC1.QUARTER;
      insert into VQA_SUM04_AMT_MATGP_Q (
            SITE, MANUF, MATGROUP, QUARTER, BUKRS, Q_AMOUNT, FROM_DATE, TO_DATE, DATE_TIME
           ) values (
           REC1.SITE,
           REC1.MANUF,
           REC1.MATGROUP,
           REC1.QUARTER,
           REC1.BUKRS,
           REC1.Q_AMOUNT,
           vSTART_DATE,
           vEND_DATE,
           to_char(SYSDATE, 'yyyymmddhh24miss')
           );
      commit;
    end loop;
  end if;

--
  iTracePoint := '221';  --MATGROUP, MANUF -GV_PER
  for REC1 in (
     select distinct MANUF, MATGROUP from VQA_SUM04_AMT_MATGP_Q
      where QUARTER = vQUARTER
  ) loop
     BEGIN
       select * into vIR_AMT_TWD from (
         select round(sum(Q_AMOUNT),5) from VQA_SUM04_AMT_MATGP_Q
          where QUARTER = vQUARTER
            and MATGROUP = REC1.MATGROUP
            and MANUF = REC1.MANUF
       );
     EXCEPTION
       When OTHERS Then
         vIR_AMT_TWD := 0;
     END;
     Update VQA_SUM04_AMT_MATGP_Q
        set GV_PER = round(Q_AMOUNT / vIR_AMT_TWD, 5)
      where QUARTER = vQUARTER
        and MATGROUP = REC1.MATGROUP
        and MANUF = REC1.MANUF;
     commit;
  end loop;

  iTracePoint := '130';  --SITE
  for REC1 in (
     select distinct SITE from VQA_SUM04_AMT_MATGP_Q
      where QUARTER = vQUARTER
  ) loop
     BEGIN
       select * into vIR_AMT_TWD from (
         select round(sum(Q_AMOUNT),5) from VQA_SUM04_AMT_MATGP_Q
          where QUARTER = vQUARTER
            and SITE = REC1.SITE
       );
     EXCEPTION
       When OTHERS Then
         vIR_AMT_TWD := 0;
     END;
     Update VQA_SUM04_AMT_MATGP_Q
        set SITE_PER = round(Q_AMOUNT / vIR_AMT_TWD, 5)
      where QUARTER = vQUARTER
        and SITE = REC1.SITE;
     commit;
  end loop;



  --Process By SITE,MANUF for 季, Data From 月
   iTracePoint := '300';
   for REC1 in ( Select SITE, MANUF, QUARTER
                        from VQA_SUM02_AMT_MF_M
                        where MANUF is Not Null
                          and QUARTER = vQUARTER
                    ) loop
     vCK_MANUF := REC1.MANUF;
   end loop;

  if vCK_MANUF is null then
     --若沒抓到資料則寄 error mail
     iTracePoint := '400';
     cErrorText := 'VQA_SUM02_AMT_MF_M  - NO DATA!';
     MAIL_FILE_BIDBDBADMIN(in_to_name => 'shuchin@ms.usi.com.tw', subject => '[VQA] PL/SQL VQA_PLSQL_SUM2_AMT_QQ  ERROR', message => '[VQA_SUM02_AMT_MF_M ], The tracepoint is  ' || iTracePoint || ' and ErrorText= ' || cErrorText) ;
  else

     --清除舊的 VQA_SUM05_AMT_MF_Q
       iTracePoint := '500';
       DELETE FROM VQA_SUM05_AMT_MF_Q WHERE QUARTER = vQUARTER;

     --抓季Amount from 月
       iTracePoint := '510';
        for REC1 in ( Select SITE, MANUF, QUARTER, BUKRS, round(SUM(AMOUNT), 2) as Q_AMOUNT
                             from VQA_SUM02_AMT_MF_M
                             where MANUF is Not Null
                               and QUARTER = vQUARTER
                    Group by SITE, MANUF, QUARTER, BUKRS
                    ) loop
      --放到 VQA_SUM05_AMT_MF_Q
      iTracePoint := '520-' || REC1.MANUF || '-' || vPROCEE_YYYYMM || REC1.QUARTER;
      insert into VQA_SUM05_AMT_MF_Q (
                  SITE, MANUF, QUARTER, BUKRS, Q_AMOUNT, FROM_DATE, TO_DATE, DATE_TIME
           ) values (
           REC1.SITE,
           REC1.MANUF,
           REC1.QUARTER,
           REC1.BUKRS,
           REC1.Q_AMOUNT,
           vSTART_DATE,
           vEND_DATE,
           to_char(SYSDATE, 'yyyymmddhh24miss')
           );
      commit;
    end loop;
  end if;

  iTracePoint := '530';  --MANUF - GV_PER
  for REC1 in (
     select distinct MANUF from VQA_SUM05_AMT_MF_Q
      where QUARTER = vQUARTER
  ) loop
     BEGIN
       select * into vIR_AMT_TWD from (
         select round(sum(Q_AMOUNT),5) from VQA_SUM05_AMT_MF_Q
          where QUARTER = vQUARTER
            and MANUF = REC1.MANUF
       );
     EXCEPTION
       When OTHERS Then
         vIR_AMT_TWD := 0;
     END;
     Update VQA_SUM05_AMT_MF_Q
        set GV_PER = round(Q_AMOUNT / vIR_AMT_TWD, 5)
      where QUARTER = vQUARTER
        and MANUF = REC1.MANUF;
     commit;
  end loop;

  iTracePoint := '540';  --SITE - SITE_PER
  for REC1 in (
     select distinct SITE from VQA_SUM05_AMT_MF_Q
      where QUARTER = vQUARTER
  ) loop
     BEGIN
       select * into vIR_AMT_TWD from (
         select round(sum(Q_AMOUNT),5) from VQA_SUM05_AMT_MF_Q
          where QUARTER = vQUARTER
            and SITE = REC1.SITE
       );
     EXCEPTION
       When OTHERS Then
         vIR_AMT_TWD := 0;
     END;
     Update VQA_SUM05_AMT_MF_Q
        set SITE_PER = round(Q_AMOUNT / vIR_AMT_TWD, 5)
      where QUARTER = vQUARTER
        and SITE = REC1.SITE;
     commit;
  end loop;


EXCEPTION
   When OTHERS Then
    --有錯誤產生則寄mail
      cErrorText := SQLERRM();
      MAIL_FILE_BIDBDBADMIN(in_to_name => 'shuchin_lin@usiglobal.com', subject => '[VQA] PL/SQL VQA_PLSQL_SUM2_AMT_QQ ERROR', message => '[VQA_SUM05_AMT_MF_Q], The tracepoint is  ' || iTracePoint || ' and ErrorText= ' || cErrorText);


END VQA_PLSQL_SUM2_AMT_QQ;
/

