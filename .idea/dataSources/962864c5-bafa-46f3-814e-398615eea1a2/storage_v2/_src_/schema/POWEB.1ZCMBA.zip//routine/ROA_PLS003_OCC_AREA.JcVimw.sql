create PROCEDURE         "ROA_PLS003_OCC_AREA" (
/* ********************************************************************
  PROG-ID      : ROA_PLS003_OCC_AREA
  PROG-ACTION  : 
  Author       : Jeff Hsieh
  Date         : 2017/03/24
  OA Number    : SAI069980
********************************************************************* */
-- 2017/04/28 Kathy: structure YEAR+PERIOD ==> PERIOD    
-- 2017/05/16 Jeff: BO00000 * 100
   incompany    IN   VARCHAR2,
   f_yyyymmdd   IN   VARCHAR2,
   t_yyyymmdd   IN   VARCHAR2

) 
AUTHID DEFINER
IS            
   PERIOD_TMP      ROA_SAP003_OCC_AREA.PERIOD%TYPE;
   COST_CENTER_TMP ROA_SAP003_OCC_AREA.COST_CENTER%TYPE;
   RADIO_TMP       ROA_SAP003_OCC_AREA.RADIO%TYPE; 
   RADIO_TMP_1       ROA_SAP003_OCC_AREA.RADIO%TYPE;  
   RADIO_TMP_2       ROA_SAP003_OCC_AREA.RADIO%TYPE; 
   RADIO_SUM    ROA_SAP003_OCC_AREA.RADIO%TYPE;
   RADIO_TMP_3    ROA_SAP003_OCC_AREA.RADIO%TYPE; 
   RADIO_TMP_4    ROA_SAP003_OCC_AREA.RADIO%TYPE; 
   RADIO_TMP_5    ROA_SAP003_OCC_AREA.RADIO%TYPE;
   RADIO_TMP_6    ROA_SAP003_OCC_AREA.COST_CENTER%TYPE;
   OCC_AREA_TMP    ROA_SAP003_OCC_AREA.OCC_AREA%TYPE;
   
   --tempStr varchar2(1000);
   CURSOR ROA_SAP003_OCC_AREA_T
   IS
      SELECT COMPANY_CODE,PERIOD,BUILDING,Trim(COST_CENTER) as COST_CENTER,OCC_AREA,RADIO,C_DATE,C_TIME,C_UNAME
               
      FROM ROA_SAP003_OCC_AREA_T
      where COMPANY_CODE = incompany;


   itracepoint    INTEGER;
   --COMPANY_CODE_T varchar2(4);    
   
BEGIN         
	--2018/11/05 add start
	--select COMPANY_CODE into COMPANY_CODE_T from ROA_SAP003_OCC_AREA_T
	 --where COMPANY_CODE = incompany; 
     --AND   PERIOD IN (SELECT PERIOD FROM ROA_SAP003_OCC_AREA_T );
    --if COMPANY_CODE_T is not null and COMPANY_CODE_T <> '' then 
     --2018/11/05 add end
     --(1)?????
     DELETE FROM ROA_SAP003_OCC_AREA
     where COMPANY_CODE = incompany 
     AND   PERIOD IN (SELECT PERIOD FROM ROA_SAP003_OCC_AREA_T where COMPANY_CODE = incompany );
     COMMIT;  

   FOR REC1 IN ROA_SAP003_OCC_AREA_T LOOP
   
   --(3)??????
       INSERT INTO ROA_SAP003_OCC_AREA (
          COMPANY_CODE, 
          PERIOD,
          BUILDING,
          COST_CENTER,
          OCC_AREA,
          RADIO,
          C_DATE,
          C_TIME,
          C_UNAME
          ) VALUES (      
          REC1.COMPANY_CODE, 
           REC1.PERIOD,         
          REC1.BUILDING,             
          trim(REC1.COST_CENTER), 
          REC1.OCC_AREA,           
          REC1.RADIO,             
          REC1.C_DATE,
          REC1.C_TIME,
          REC1.C_UNAME
           );   
       COMMIT;
       PERIOD_TMP :=REC1.PERIOD;
       COST_CENTER_TMP :=REC1.COST_CENTER;
   END LOOP;     

   DECLARE   
   AERA_SUM  NUMBER;  
   
   CURSOR ROA_SAP003_OCC_AREA  IS
     SELECT DISTINCT COST_CENTER FROM ROA_SAP003_OCC_AREA
      WHERE COMPANY_CODE = incompany
        AND PERIOD = PERIOD_TMP;  
   itracepoint   INTEGER;      
   BEGIN  
	   SELECT SUM(OCC_AREA) INTO AERA_SUM
	     FROM ROA_SAP003_OCC_AREA
	    WHERE COMPANY_CODE = incompany 
	      AND PERIOD = PERIOD_TMP; 
	   COMMIT; 

   
	   --error := incompany;
	   FOR REC2 IN ROA_SAP003_OCC_AREA LOOP
	       RADIO_TMP    := NULL;
	       OCC_AREA_TMP := NULL;
	       SELECT SUM(OCC_AREA) INTO OCC_AREA_TMP
	        FROM  ROA_SAP003_OCC_AREA
	        WHERE COMPANY_CODE = incompany 
	          AND PERIOD = PERIOD_TMP
	          AND COST_CENTER = REC2.COST_CENTER;
	       RADIO_TMP := OCC_AREA_TMP / AERA_SUM; 
	       
	       RADIO_TMP := RADIO_TMP * 100;  
	       
--	       tempStr := incompany || '-' || PERIOD_TMP || '-' || REC2.COST_CENTER || '-'|| to_char(OCC_AREA_TMP)|| '-'|| to_char(RADIO_TMP);   
	       --tempStr := SQL%ROWCOUNT || '-' || PERIOD_TMP || '-' || REC2.COST_CENTER || '-'|| to_char(OCC_AREA_TMP)|| '-'|| to_char(RADIO_TMP); 
--	       trans := tempStr;
	         INSERT INTO ROA_SAP003_OCC_AREA (
	          COMPANY_CODE,
	          PERIOD,
	          BUILDING,
	          COST_CENTER,
	          OCC_AREA,
	          RADIO,
	          C_DATE,
	          C_TIME,
	          C_UNAME
	         ) VALUES (      
	          incompany, 
	          PERIOD_TMP,         
	          'B000000',             
	          trim(REC2.COST_CENTER), 
	          OCC_AREA_TMP,           
	          RADIO_TMP,             
	          TO_CHAR(SYSDATE,'YYYYMMDD'),
	          TO_CHAR(SYSDATE,'HH24MISS'),
	          'SYSTEM'
	           );   
	       COMMIT;    
	   END LOOP; 
	   SELECT SUM(radio) INTO RADIO_SUM  FROM ROA_SAP003_OCC_AREA
	    WHERE COMPANY_CODE = incompany
        AND PERIOD = PERIOD_TMP
        AND BUILDING = 'B000000';
	       IF RADIO_SUM <> 100 THEN
	           RADIO_TMP_3 := 100 - RADIO_SUM ;
	           SELECT COST_CENTER,RADIO INTO RADIO_TMP_6, RADIO_TMP_4 FROM ROA_SAP003_OCC_AREA 
	            WHERE RADIO = (SELECT MAX(RADIO) FROM ROA_SAP003_OCC_AREA WHERE BUILDING = 'B000000' AND COMPANY_CODE = incompany AND PERIOD = PERIOD_TMP)
	              AND COMPANY_CODE = incompany
	              AND PERIOD = PERIOD_TMP
	              AND BUILDING = 'B000000';

	           RADIO_TMP_5 := RADIO_TMP_4 + RADIO_TMP_3;
	           UPDATE ROA_SAP003_OCC_AREA SET RADIO = RADIO_TMP_5
	            WHERE COST_CENTER = RADIO_TMP_6
	              AND COMPANY_CODE = incompany
	              AND PERIOD = PERIOD_TMP
	              AND BUILDING = 'B000000';  
	           COMMIT;
	       END IF;
   END;     
      
 --//////////////////////////////   
    --(3) ????
   --DELETE FROM ROA_SAP003_OCC_AREA_T
    --where COMPANY_CODE = incompany;
    --COMMIT;
   --end if; --2018/11/05 add
--exception 
--when others then
  --error := tempStr || '---' || sqlerrm();
END ROA_PLS003_OCC_AREA;
/

