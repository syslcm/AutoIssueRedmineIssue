create PROCEDURE PLSQL_GVM032B_USG_CREATE (
    outRES OUT VARCHAR2
)
AUTHID DEFINER
is
    /*
    Create: 2009/10/05 Minhorng
    1. 針對 USG-TW / USG-SZ vendor code Copy from  USI-TW / USI-SZ (例: USI-TW 0000012345 -> USG-TW 1100-12345)
    2.1 USI-TW / USI-SZ GVC 變更時, USG-TW / USG-SZ 也需變更
    2.2 針對 SH1500 & KS4100 處理 (同台SAP不同Client)
    3. 由 GVM_AutoRelease.exe 執行 (daily 02:00 每隔4小時 @ 10.0.1.70)
    
    其他備註:
    PLD_KPI_VENDOR_MASTER,GVM_060_SAP_DATA_LFM1 會透過 BI VB BI_VENDOR 等寫入資料
    */
    
    t_GLOBAL_VENDOR_CODE       GVM032_GLOBAL_VENDOR_ITEM.GLOBAL_VENDOR_CODE%TYPE;
BEGIN
    outRES := 'START';
    for REC1 in (
        Select COMPANY_CODE, REF_COMPANY from GVM014_SITE_NODISPLAY
        where COMPANY_CODE is not null and REF_COMPANY is not null
        and COMPANY_CODE <> REF_COMPANY
        group by COMPANY_CODE, REF_COMPANY
    ) loop
        outRES := 'S1-' || REC1.COMPANY_CODE;
        -- 處理 USI-TW / USI-SZ GVC 變更時, USG-TW / USG-SZ 也需變更
        for REC2 in (
            select SAP_VENDOR_CODE, count(*) as CNT from (
                select GLOBAL_VENDOR_CODE, SAP_VENDOR_CODE
                from GVM032_GLOBAL_VENDOR_ITEM
                where COMPANY_CODE = REC1.REF_COMPANY
                union
                select GLOBAL_VENDOR_CODE, ('00000' || substr(SAP_VENDOR_CODE,6,5)) as SAP_VENDOR_CODE
                from GVM032_GLOBAL_VENDOR_ITEM
                where COMPANY_CODE = REC1.COMPANY_CODE
            ) group by SAP_VENDOR_CODE
            having count(*) > 1
        ) loop
            outRES := 'S2-' || REC1.REF_COMPANY || REC2.SAP_VENDOR_CODE;
            t_GLOBAL_VENDOR_CODE := null;
            select * into t_GLOBAL_VENDOR_CODE from (
                select GLOBAL_VENDOR_CODE from GVM032_GLOBAL_VENDOR_ITEM
                where COMPANY_CODE = REC1.REF_COMPANY
                and SAP_VENDOR_CODE = REC2.SAP_VENDOR_CODE
            ) where rownum <= 1;
            update GVM032_GLOBAL_VENDOR_ITEM
                set GLOBAL_VENDOR_CODE = t_GLOBAL_VENDOR_CODE
            where COMPANY_CODE = REC1.COMPANY_CODE
            and SAP_VENDOR_CODE = trim(REC1.REF_COMPANY || '-' || substr(REC2.SAP_VENDOR_CODE,6,5));
            commit;
        end loop;
        
        -- 處理 USI-TW / USI-SZ vendor code 新增者
        outRES := 'S3-' || REC1.COMPANY_CODE;
        insert into GVM032_GLOBAL_VENDOR_ITEM (
            GLOBAL_VENDOR_CODE, COMPANY_CODE,
            SAP_VENDOR_CODE,
            INIT_NAME, SEARCH_TERM, COUNTRY_KEY, RECON_ACCOUNT, PO_CURRENCY,
            PAYMENT_TERM, INCOTERM, INCOTERM_2, REQUEST_NO, ATTACH_FILE
        )
        select a.GLOBAL_VENDOR_CODE, REC1.COMPANY_CODE as COMPANY_CODE,
            trim(a.COMPANY_CODE || '-' || substr(a.SAP_VENDOR_CODE,6,5)) as SAP_VENDOR_CODE,
            a.INIT_NAME, a.SEARCH_TERM, a.COUNTRY_KEY, a.RECON_ACCOUNT, a.PO_CURRENCY, 
            a.PAYMENT_TERM, a.INCOTERM, a.INCOTERM_2, a.REQUEST_NO, a.ATTACH_FILE
        from GVM032_GLOBAL_VENDOR_ITEM a
        where a.COMPANY_CODE = REC1.REF_COMPANY
        and not exists (
            select GLOBAL_VENDOR_CODE from GVM032_GLOBAL_VENDOR_ITEM
            where COMPANY_CODE = REC1.COMPANY_CODE
            and SAP_VENDOR_CODE = trim(a.COMPANY_CODE || '-' || substr(a.SAP_VENDOR_CODE,6,5))
        );
        commit;
    end loop;
    commit;
    
    /*
    -- 針對 SH1500 & KS4100 處理(同台SAP), 若另一company code data已建起時(此會透過SAP複製並傳到PLD_KPI_VENDOR_MASTER)
    -- GVM032_GLOBAL_VENDOR_ITEM 亦建起
    for rec3 in (
        select VENDOR_ID, count(*) as CNT from ( 
            select COMPANY_CODE, VENDOR_ID from PLD_KPI_VENDOR_MASTER where COMPANY_CODE in ('1500','4100')
            union all
            select COMPANY_CODE, SAP_VENDOR_CODE as VENDOR_ID from GVM032_GLOBAL_VENDOR_ITEM where COMPANY_CODE in ('1500','4100')
        ) group by VENDOR_ID
        having count(*) = 3
    ) loop
        -- 抓沒資料的 site 處理
        for rec5 in (
            select '1500' as T_SITE, '4100' as F_SITE, count(*) as R_CNT from GVM032_GLOBAL_VENDOR_ITEM
            where COMPANY_CODE = '1500' and SAP_VENDOR_CODE = rec3.VENDOR_ID
            union
            select '4100' as T_SITE, '1500' as F_SITE, count(*) as R_CNT from GVM032_GLOBAL_VENDOR_ITEM
            where COMPANY_CODE = '4100' and SAP_VENDOR_CODE = rec3.VENDOR_ID
        ) loop
            if rec5.R_CNT = 0 then
                -- 寫入 GVM032_GLOBAL_VENDOR_ITEM
                insert into GVM032_GLOBAL_VENDOR_ITEM ( GLOBAL_VENDOR_CODE, COMPANY_CODE, SAP_VENDOR_CODE, INIT_NAME, SEARCH_TERM, 
                    COUNTRY_KEY, RECON_ACCOUNT, PO_CURRENCY, PAYMENT_TERM, INCOTERM, INCOTERM_2, REQUEST_NO, ATTACH_FILE )
                select a.GLOBAL_VENDOR_CODE, rec5.T_SITE as COMPANY_CODE, a.SAP_VENDOR_CODE, a.INIT_NAME, a.SEARCH_TERM, 
                    a.COUNTRY_KEY, b.REC_ACCOUNT, a.PO_CURRENCY, c.PAYMENT_TERM, c.INCOTERM, c.INCOTERM_2, null as REQUEST_NO, null as ATTACH_FILE
                from GVM032_GLOBAL_VENDOR_ITEM a, PLD_KPI_VENDOR_MASTER b, GVM_060_SAP_DATA_LFM1 c
                where b.COMPANY_CODE = rec5.T_SITE and b.VENDOR_ID = rec3.VENDOR_ID
                and c.COMPANY_CODE = b.COMPANY_CODE and c.SAP_VENDOR_CODE = b.VENDOR_ID
                and    a.COMPANY_CODE = rec5.F_SITE and a.SAP_VENDOR_CODE = b.VENDOR_ID
                and not exists (
                    select x.COMPANY_CODE from GVM032_GLOBAL_VENDOR_ITEM x
                    where x.COMPANY_CODE = rec5.T_SITE
                    and x.SAP_VENDOR_CODE = rec3.VENDOR_ID
                );
                -- commit
                commit;
            end if;
        end loop;
    end loop;
    */
    
    outRES := 'SUCCESS';
EXCEPTION
    WHEN OTHERS THEN
        outRES := TRIM(outRES) || ' -> ' || TRIM(SUBSTR(SQLERRM,1,100));
        Rollback;
        MAIL_FILE_BIDBDBADMIN(in_to_name=>'minhorng@ms.usi.com.tw',subject   => '[GVM]PL/SQL PLSQL_GVM032B_USG_CREATE ERROR', message => '[PLSQL_GVM032B_USG_CREATE], ErrorText=' || outRES);
END PLSQL_GVM032B_USG_CREATE;
/

