create PROCEDURE PLSQL_DCF_RPT_WEEKLY_LOA_5 (
  outRES OUT VARCHAR2
)
AUTHID DEFINER
is
  --抓LT, MOQ (COMPANY: 1100/1130 1200/1210 1300/1310 1500/1510 2300/2310 )
  CURSOR C_SAP_MATERIAL_PLANT is
    Select A.COMPANY_CODE, A.PART_NO, A.LT, A.MOQ
      From SAP_MATERIAL_PLANT A, DCF_IBM_LOA_CURRENT B
     where A.PART_NO like B.USI_PN_LIKE || '%'
       and ( ( A.COMPANY_CODE = '1100' and A.PLANT = '1130' )
          or ( A.COMPANY_CODE = '1200' and A.PLANT = '1210' )
          or ( A.COMPANY_CODE = '1300' and A.PLANT = '1310' )
          or ( A.COMPANY_CODE = '1500' and A.PLANT = '1510' )
          or ( A.COMPANY_CODE = '2300' and A.PLANT = '2310' ) )
     Group by A.COMPANY_CODE, A.PART_NO, A.LT, A.MOQ;

  --抓Open PO Qty 1(不管供應商 - PO_CUTIN_DATE)
  CURSOR C_DCF_USI_SITE_DATA2 is
    Select B.COMPANY_CODE, A.USI_PN, SUM(NVL(B.REQ_QTY,0) - NVL(B.DEL_QTY,0)) as OPEN_PO_QTY
      From DCF_USI_SITE_DATA A, POWEB_DAILY_PO B, DCF_CONTROL_OPEN_PO C
     where A.USI_PN is NOT Null
       and B.PART_NO = A.USI_PN
       and B.COMPANY_CODE in ('1100','1200','1300','1500','2300')
       and C.USI_PN = B.PART_NO
       and TO_DATE(C.SHIP_CUTIN_DATE,'YYYYMMDD') > TO_DATE(B.REQ_DATE,'YYYYMMDD')
       and C.SHIP_CUTIN_DATE is NOT Null
     Group by B.COMPANY_CODE, A.USI_PN;

  --抓Open PO Qty 2(不管供應商 - SHIP_CUTIN_DATE)
  CURSOR C_DCF_USI_SITE_DATA1 is
    Select B.COMPANY_CODE, A.USI_PN, SUM(NVL(B.REQ_QTY,0) - NVL(B.DEL_QTY,0)) as OPEN_PO_QTY
      From DCF_USI_SITE_DATA A, POWEB_DAILY_PO B, DCF_CONTROL_OPEN_PO C
     where A.USI_PN is NOT Null
       and B.PART_NO = A.USI_PN
       and B.COMPANY_CODE in ('1100','1200','1300','1500','2300')
       and C.USI_PN = B.PART_NO
       and TO_DATE(C.PO_CUTIN_DATE,'YYYYMMDD') > TO_DATE(B.POCRE_DATE,'YYYYMMDD')
       and C.PO_CUTIN_DATE is NOT Null
     Group by B.COMPANY_CODE, A.USI_PN;

  --抓Stock
  CURSOR C_EGI0150_END_STORAGELOC is
    Select TRIM(A.MFG_SITE) as MFG_SITE, TRIM(A.MATERIAL) as MATERIAL, SUM(A.UNRESTRICTED_USE) as STOCK
      From EGI0150_END_STORAGELOC A, DCF_CONTROL_STOCK C
     where A.MFG_SITE = C.MFG_SITE
       and A.PLANT = C.PLANT
       and A.POST_DATE_YYYY = C.POST_DATE_YYYY
       and A.POST_DATE_MM = C.POST_DATE_MM
       and A.PLANT <> '9999'
       and Exists(
             Select B.USI_PN_LIKE from DCF_IBM_LOA_CURRENT B
              where TRIM(A.MATERIAL) like TRIM(B.USI_PN_LIKE) || '%'
                and B.USI_PN_LIKE is Not Null
           )
     Group by TRIM(A.MFG_SITE), TRIM(A.MATERIAL);

  --處理 RFQ_BOM_USAGE -> 設QTA_FLAG
  CURSOR C_RFQ_BOM_USAGE is
    Select A.COMPONENT_NO
      From RFQ_BOM_USAGE A
     where ( A.PART_NO, A.ALTER_ITEM_GROUP ) in (
             Select B.PART_NO, B.ALTER_ITEM_GROUP
               from RFQ_BOM_USAGE B, DCF_RPT_WEEKLY_LOA C
              where C.USI_PN like B.COMPONENT_NO || '%'
                and C.QTA_FLAG = 'Y'
           )
     Group by A.COMPONENT_NO;

   nCOUNT              NUMBER(3);

 BEGIN
   outRES := 'START';

   --抓LT, MOQ
   nCOUNT := 0;
   FOR REC1 in C_SAP_MATERIAL_PLANT LOOP
     outRES := 'C_SAP_MATERIAL_PLANT:' || REC1.COMPANY_CODE || '<>' || REC1.PART_NO;
     If REC1.COMPANY_CODE = '1100' Then
       Update DCF_USI_SITE_DATA 
          set USI_LT_TW = REC1.LT, USI_MOQ_TW = REC1.MOQ
        where USI_PN like REC1.PART_NO || '%'
          and USI_PN is NOT Null;
     ElsIf REC1.COMPANY_CODE = '1200' Then
       Update DCF_USI_SITE_DATA 
          set USI_LT_SZ = REC1.LT, USI_MOQ_SZ = REC1.MOQ
        where USI_PN like REC1.PART_NO || '%'
          and USI_PN is NOT Null;
     ElsIf REC1.COMPANY_CODE = '1300' Then
       Update DCF_USI_SITE_DATA 
          set USI_LT_JP = REC1.LT, USI_MOQ_JP = REC1.MOQ
        where USI_PN like REC1.PART_NO || '%'
          and USI_PN is NOT Null;
     ElsIf REC1.COMPANY_CODE = '1500' Then
       Update DCF_USI_SITE_DATA 
          set USI_LT_SH = REC1.LT, USI_MOQ_SH = REC1.MOQ
        where USI_PN like REC1.PART_NO || '%'
          and USI_PN is NOT Null;
     ElsIf REC1.COMPANY_CODE = '2300' Then
       Update DCF_USI_SITE_DATA 
          set USI_LT_MX = REC1.LT, USI_MOQ_MX = REC1.MOQ
        where USI_PN like REC1.PART_NO || '%'
          and USI_PN is NOT Null;
     End If;
     nCOUNT := nCOUNT + 1;
     If nCOUNT = 10 Then
       Commit;
       nCOUNT := 0;
     End If;
   END LOOP;
   Commit;
   outRES := 'UPDATE C_SAP_MATERIAL_PLANT OK';

   --抓Open PO Qty 1
   nCOUNT := 0;
   FOR REC1 in C_DCF_USI_SITE_DATA1 LOOP
     outRES := 'C_DCF_USI_SITE_DATA1:' || REC1.COMPANY_CODE || '<>' || REC1.USI_PN;
     If REC1.COMPANY_CODE = '1100' Then
       Update DCF_USI_SITE_DATA 
          set USI_PO_TW = REC1.OPEN_PO_QTY
        where USI_PN = REC1.USI_PN;
     ElsIf REC1.COMPANY_CODE = '1200' Then
       Update DCF_USI_SITE_DATA 
          set USI_PO_SZ = REC1.OPEN_PO_QTY
        where USI_PN = REC1.USI_PN;
     ElsIf REC1.COMPANY_CODE = '1300' Then
       Update DCF_USI_SITE_DATA 
          set USI_PO_JP = REC1.OPEN_PO_QTY
        where USI_PN = REC1.USI_PN;
     ElsIf REC1.COMPANY_CODE = '1500' Then
       Update DCF_USI_SITE_DATA 
          set USI_PO_SH = REC1.OPEN_PO_QTY
        where USI_PN = REC1.USI_PN;
     ElsIf REC1.COMPANY_CODE = '2300' Then
       Update DCF_USI_SITE_DATA 
          set USI_PO_MX = REC1.OPEN_PO_QTY
        where USI_PN = REC1.USI_PN;
     End If;
     nCOUNT := nCOUNT + 1;
     If nCOUNT = 10 Then
       Commit;
       nCOUNT := 0;
     End If;
   END LOOP;
   Commit;
   outRES := 'UPDATE C_DCF_USI_SITE_DATA1 OK';

   --抓Open PO Qty 2
   nCOUNT := 0;
   FOR REC1 in C_DCF_USI_SITE_DATA2 LOOP
     outRES := 'C_DCF_USI_SITE_DATA2:' || REC1.COMPANY_CODE || '<>' || REC1.USI_PN;
     If REC1.COMPANY_CODE = '1100' Then
       Update DCF_USI_SITE_DATA 
          set USI_PO_TW = REC1.OPEN_PO_QTY
        where USI_PN = REC1.USI_PN;
     ElsIf REC1.COMPANY_CODE = '1200' Then
       Update DCF_USI_SITE_DATA 
          set USI_PO_SZ = REC1.OPEN_PO_QTY
        where USI_PN = REC1.USI_PN;
     ElsIf REC1.COMPANY_CODE = '1300' Then
       Update DCF_USI_SITE_DATA 
          set USI_PO_JP = REC1.OPEN_PO_QTY
        where USI_PN = REC1.USI_PN;
     ElsIf REC1.COMPANY_CODE = '1500' Then
       Update DCF_USI_SITE_DATA 
          set USI_PO_SH = REC1.OPEN_PO_QTY
        where USI_PN = REC1.USI_PN;
     ElsIf REC1.COMPANY_CODE = '2300' Then
       Update DCF_USI_SITE_DATA 
          set USI_PO_MX = REC1.OPEN_PO_QTY
        where USI_PN = REC1.USI_PN;
     End If;
     nCOUNT := nCOUNT + 1;
     If nCOUNT = 10 Then
       Commit;
       nCOUNT := 0;
     End If;
   END LOOP;
   Commit;
   outRES := 'UPDATE C_DCF_USI_SITE_DATA2 OK';

   --抓Stock
   nCOUNT := 0;
   FOR REC1 in C_EGI0150_END_STORAGELOC LOOP
     outRES := 'C_EGI0150_END_STORAGELOC:' || REC1.MFG_SITE || '<>' || REC1.MATERIAL;
     If REC1.MFG_SITE = '1100' Then
       Update DCF_USI_SITE_DATA 
          set USI_STOCK_TW = REC1.STOCK
        where USI_PN like TRIM(REC1.MATERIAL) || '%'
          and USI_PN is NOT Null;
     ElsIf REC1.MFG_SITE = '1200' Then
       Update DCF_USI_SITE_DATA 
          set USI_STOCK_SZ = REC1.STOCK
        where USI_PN like TRIM(REC1.MATERIAL) || '%'
          and USI_PN is NOT Null;
     ElsIf REC1.MFG_SITE = '1300' Then
       Update DCF_USI_SITE_DATA 
          set USI_STOCK_JP = REC1.STOCK
        where USI_PN like TRIM(REC1.MATERIAL) || '%'
          and USI_PN is NOT Null;
     ElsIf REC1.MFG_SITE = '1500' Then
       Update DCF_USI_SITE_DATA 
          set USI_STOCK_SH = REC1.STOCK
        where USI_PN like TRIM(REC1.MATERIAL) || '%'
          and USI_PN is NOT Null;
     ElsIf REC1.MFG_SITE = '2300' Then
       Update DCF_USI_SITE_DATA 
          set USI_STOCK_MX = REC1.STOCK
        where USI_PN like TRIM(REC1.MATERIAL) || '%'
          and USI_PN is NOT Null;
     End If;
     nCOUNT := nCOUNT + 1;
     If nCOUNT = 5 Then
       Commit;
       nCOUNT := 0;
     End If;
   END LOOP;
   Commit;
   outRES := 'UPDATE C_EGI0150_END_STORAGELOC OK';

   --處理 RFQ_BOM_USAGE -> 設QTA_FLAG
   nCOUNT := 0;
   FOR REC1 in C_RFQ_BOM_USAGE LOOP
     outRES := 'C_RFQ_BOM_USAGE:' || REC1.COMPONENT_NO;
     Update DCF_RPT_WEEKLY_LOA
        set QTA_FLAG = 'Y'
      where USI_PN like REC1.COMPONENT_NO || '%'
        and NVL(QTA_FLAG,'N') = 'N';   
     nCOUNT := nCOUNT + 1;
     If nCOUNT = 5 Then
       Commit;
       nCOUNT := 0;
     End If;
   END LOOP;
   Commit;
   outRES := 'UPDATE C_RFQ_BOM_USAGE OK';
   /*
   DBMS_STATS.GATHER_SCHEMA_STATS
   (
     ownname => 'POWEB',
     estimate_percent => NULL,
     method_opt => NULL,
     cascade => TRUE
   );
   Commit;
   */
   outRES := 'SUCCESS';
 EXCEPTION
   WHEN OTHERS THEN
     outRES := TRIM(outRES) || ' - ' || TRIM(SUBSTR(SQLERRM,1,100));
     Rollback;
 END PLSQL_DCF_RPT_WEEKLY_LOA_5;
/

