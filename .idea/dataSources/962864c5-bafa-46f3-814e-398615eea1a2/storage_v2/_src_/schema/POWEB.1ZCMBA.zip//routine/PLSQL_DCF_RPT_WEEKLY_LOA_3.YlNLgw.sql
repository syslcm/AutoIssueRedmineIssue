create PROCEDURE PLSQL_DCF_RPT_WEEKLY_LOA_3 (
  outRES OUT VARCHAR2
)
AUTHID DEFINER
is
  --處理 DCF_CONTROL_OPEN_PO
  CURSOR C_DCF_CONTROL_OPEN_PO1 is
    Select A.USI_PN, MAX(A.PO_CUTIN_DATE) as PO_CUTIN_DATE
      From DCF_USI_MANUAL A
     Where A.USI_PN is NOT NULL
       and A.PO_CUTIN_DATE is NOT NULL
       and Exists (
         Select B.COMPANY_CODE from POWEB_DAILY_PO B
          where B.PART_NO = A.USI_PN
            and B.COMPANY_CODE in ('1100','1200','1300','1500','2300')
       )
     Group by A.USI_PN;

  --處理 DCF_CONTROL_OPEN_PO (2)
  CURSOR C_DCF_CONTROL_OPEN_PO2 is
    Select A.USI_PN, MAX(A.SHIP_CUTIN_DATE) as SHIP_CUTIN_DATE
      From DCF_USI_MANUAL A
     Where A.USI_PN is NOT NULL
       and A.SHIP_CUTIN_DATE is NOT NULL
       and Exists (
         Select B.COMPANY_CODE from POWEB_DAILY_PO B
          where B.PART_NO = A.USI_PN
            and B.COMPANY_CODE in ('1100','1200','1300','1500','2300')
       )
       and A.USI_PN NOT IN (
         Select C.USI_PN from DCF_USI_MANUAL C
          where C.USI_PN is NOT NULL
            and C.PO_CUTIN_DATE is NOT NULL
       )
     Group by A.USI_PN;

  --處理 DCF_USI_SITE_DATA
  CURSOR C_DCF_USI_SITE_DATA is
    Select USI_PN
      From DCF_RPT_WEEKLY_LOA
     Where USI_PN is NOT NULL
     Group by USI_PN;

  --抓對不到USI PN的IBM PN
  CURSOR C_DCF_IBM_LOA_CURRENT is
    Select distinct
           B.IBM_PN, B.IBM_VENDOR_NO, B.COUNCIL_NAME, B.COMMODITY, B.IBM_PART_DESC,
           B.IBM_VENDOR, B.IBM_LAST_QUOTA, B.IBM_QUOTA, B.IBM_CONTRACT, B.CONTRACT_START,
           B.CONTRACT_END, B.IBM_LAST_PRICE, B.LAST_PRICE_DATE, B.IBM_PRICE, B.IBM_CURRENCY,
           B.PRICE_START, B.PRICE_END, B.IBM_LAST_LT, B.IBM_LT, B.IBM_MOQ, B.VENDOR_MULT, B.CUSTOMER
      From DCF_IBM_LOA_CURRENT B
     where NOT EXISTS (
	    Select C.IBM_PN from DCF_RPT_WEEKLY_LOA C
		 where C.IBM_PN = B.IBM_PN
		   and C.IBM_VENDOR_NO = B.IBM_VENDOR_NO
	  );

   nCOUNT              NUMBER(3);
   nQTA_DIFF           DCF_RPT_WEEKLY_LOA.QTA_DIFF%TYPE;
   nPRICE_DISCREPANCY  DCF_RPT_WEEKLY_LOA.PRICE_DISCREPANCY%TYPE;
   nLT_DIFF            DCF_RPT_WEEKLY_LOA.LT_DIFF%TYPE;

 BEGIN
   outRES := 'START';

   --處理 DCF_CONTROL_OPEN_PO (1)
   Delete from DCF_CONTROL_OPEN_PO;
   Commit;
   nCOUNT := 0;
   FOR REC1 in C_DCF_CONTROL_OPEN_PO1 LOOP
     outRES := 'C_DCF_CONTROL_OPEN_PO1:' || REC1.USI_PN;
     Insert into DCF_CONTROL_OPEN_PO ( USI_PN, PO_CUTIN_DATE )
          values ( REC1.USI_PN, REC1.PO_CUTIN_DATE );
     If nCOUNT = 10 Then
       Commit;
       nCOUNT := 0;
     End If;
   END LOOP;
   Commit;
   outRES := 'Insert C_DCF_CONTROL_OPEN_PO1 OK';

   --處理 DCF_CONTROL_OPEN_PO (2)
   nCOUNT := 0;
   FOR REC1 in C_DCF_CONTROL_OPEN_PO2 LOOP
     outRES := 'C_DCF_CONTROL_OPEN_PO2:' || REC1.USI_PN;
     Insert into DCF_CONTROL_OPEN_PO ( USI_PN, SHIP_CUTIN_DATE )
          values ( REC1.USI_PN, REC1.SHIP_CUTIN_DATE );
     If nCOUNT = 10 Then
       Commit;
       nCOUNT := 0;
     End If;
   END LOOP;
   Commit;
   outRES := 'Insert C_DCF_CONTROL_OPEN_PO2 OK';

   --處理 DCF_USI_SITE_DATA
   Delete from DCF_USI_SITE_DATA;
   Commit;
   nCOUNT := 0;
   FOR REC1 in C_DCF_USI_SITE_DATA LOOP
     outRES := 'C_DCF_USI_SITE_DATA:' || REC1.USI_PN;
     Insert into DCF_USI_SITE_DATA ( USI_PN )
          values ( REC1.USI_PN );
     If nCOUNT = 10 Then
       Commit;
       nCOUNT := 0;
     End If;
   END LOOP;
   Commit;
   outRES := 'Insert C_DCF_USI_SITE_DATA OK';

  --抓對不到USI PN的IBM PN
   nCOUNT := 0;
   FOR REC1 in C_DCF_IBM_LOA_CURRENT LOOP
     outRES := 'C_DCF_IBM_LOA_CURRENT:' || REC1.IBM_PN || '<>' || REC1.IBM_VENDOR_NO;
     If ( REC1.IBM_LAST_QUOTA is NULL ) or ( REC1.IBM_LAST_QUOTA = REC1.IBM_QUOTA ) Then
       nQTA_DIFF := 'NO';
     Else
       nQTA_DIFF := 'YES';
     End If;
     If REC1.IBM_LAST_PRICE is NULL Then
       nPRICE_DISCREPANCY := 0;
     Else
       nPRICE_DISCREPANCY := NVL(REC1.IBM_PRICE,0) - NVL(REC1.IBM_LAST_PRICE,0);
     End If;
     If REC1.IBM_LAST_LT is NULL Then
       nLT_DIFF := 0;
     Else
       nLT_DIFF := NVL(REC1.IBM_LT,0) - NVL(REC1.IBM_LAST_LT,0);
     End If;

     Insert into DCF_RPT_WEEKLY_LOA ( IBM_PN, COUNCIL_NAME, COMMODITY, IBM_PART_DESC,
                                      IBM_VENDOR, IBM_LAST_QUOTA, IBM_QUOTA, QTA_DIFF, IBM_VENDOR_NO,
                                      IBM_CONTRACT, CONTRACT_START, CONTRACT_END,
                                      IBM_LAST_PRICE, LAST_PRICE_DATE, IBM_PRICE,
                                      IBM_CURRENCY, PRICE_START, PRICE_END, PRICE_DISCREPANCY,
                                      IBM_LAST_LT, IBM_LT, LT_DIFF, IBM_MOQ, VENDOR_MULT, CUSTOMER )
          values ( REC1.IBM_PN, REC1.COUNCIL_NAME, REC1.COMMODITY, REC1.IBM_PART_DESC,
                   REC1.IBM_VENDOR, REC1.IBM_LAST_QUOTA, REC1.IBM_QUOTA, nQTA_DIFF, REC1.IBM_VENDOR_NO,
                   REC1.IBM_CONTRACT, REC1.CONTRACT_START, REC1.CONTRACT_END,
                   REC1.IBM_LAST_PRICE, REC1.LAST_PRICE_DATE, REC1.IBM_PRICE,
                   REC1.IBM_CURRENCY, REC1.PRICE_START, REC1.PRICE_END, nPRICE_DISCREPANCY,
                   REC1.IBM_LAST_LT, REC1.IBM_LT, nLT_DIFF, REC1.IBM_MOQ, REC1.VENDOR_MULT, REC1.CUSTOMER );
     nCOUNT := nCOUNT + 1;
     If nCOUNT = 10 Then
       Commit;
       nCOUNT := 0;
     End If;
   END LOOP;
   Commit;
   outRES := 'INSERT C_DCF_IBM_LOA_CURRENT OK';

   outRES := 'SUCCESS';
 EXCEPTION
   WHEN OTHERS THEN
     outRES := TRIM(outRES) || ' - ' || TRIM(SUBSTR(SQLERRM,1,100));
     Rollback;
 END PLSQL_DCF_RPT_WEEKLY_LOA_3;
/

