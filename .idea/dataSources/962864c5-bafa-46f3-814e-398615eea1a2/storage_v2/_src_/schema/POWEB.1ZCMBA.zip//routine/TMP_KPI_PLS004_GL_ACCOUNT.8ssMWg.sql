create PROCEDURE TMP_KPI_PLS004_GL_ACCOUNT (
  inCompany  in VARCHAR2,
  f_YYYYMMDD in VARCHAR2,
  t_YYYYMMDD in VARCHAR2
)
AUTHID DEFINER
is

   t_CURRENCY_LOCAL    TMP_KPI_SAP004_GL_ACCOUNT.CURRENCY_LOCAL%TYPE;
   a_EX_RATE_USD       TMP_KPI_SAP004_GL_ACCOUNT.EX_RATE_USD%TYPE;
   a_EX_RATE_TWD       TMP_KPI_SAP004_GL_ACCOUNT.EX_RATE_TWD%TYPE;
   b_EX_RATE_USD       TMP_KPI_SAP004_GL_ACCOUNT.EX_RATE_USD%TYPE;
   b_EX_RATE_TWD       TMP_KPI_SAP004_GL_ACCOUNT.EX_RATE_TWD%TYPE;

BEGIN
 --抓CURRENCY_LOCAL
 t_CURRENCY_LOCAL := Null;
 Begin
   Select * into t_CURRENCY_LOCAL From (
     Select distinct CURRENCY_LOCAL from TMP_KPI_SAP004_GL_ACCOUNT
      where COMPANY_CODE = inCompany
        and CURRENCY_LOCAL is Not Null
        and PERIOD >= SUBSTRB(f_YYYYMMDD,1,6)
        and PERIOD <= SUBSTRB(t_YYYYMMDD,1,6)
   ) Where ROWNUM <= 1;
 EXCEPTION
   When OTHERS Then
     t_CURRENCY_LOCAL := Null;
 End;

 If t_CURRENCY_LOCAL is Not Null Then
   --計算匯率
   a_EX_RATE_TWD := Null;
   a_EX_RATE_USD := Null;
   b_EX_RATE_TWD := Null;
   b_EX_RATE_USD := Null;

   a_EX_RATE_USD := GET_EXCHANGE_RATE(SUBSTRB(f_YYYYMMDD,1,4),SUBSTRB(f_YYYYMMDD,5,2),t_CURRENCY_LOCAL,'USD','T') ;
   a_EX_RATE_TWD := GET_EXCHANGE_RATE(SUBSTRB(f_YYYYMMDD,1,4),SUBSTRB(f_YYYYMMDD,5,2),t_CURRENCY_LOCAL,'TWD','T') ;
   b_EX_RATE_USD := GET_EXCHANGE_RATE(SUBSTRB(t_YYYYMMDD,1,4),SUBSTRB(t_YYYYMMDD,5,2),t_CURRENCY_LOCAL,'USD','T') ;
   b_EX_RATE_TWD := GET_EXCHANGE_RATE(SUBSTRB(t_YYYYMMDD,1,4),SUBSTRB(t_YYYYMMDD,5,2),t_CURRENCY_LOCAL,'TWD','T') ;

   /*
   If t_CURRENCY_LOCAL = 'TWD' Then
     a_EX_RATE_TWD := 1;
     b_EX_RATE_TWD := 1;
   ElsIf t_CURRENCY_LOCAL = 'USD' Then
     a_EX_RATE_USD := 1;
     b_EX_RATE_USD := 1;
   End If;
   If a_EX_RATE_USD is Null Then
     Select * into a_EX_RATE_USD From (
       Select ROUND(1 / EXCH_RATE, 5) from KPI_MAP006_EXCHANGE_RATE
        where YYYY = SUBSTRB(f_YYYYMMDD,1,4)
          and MM = SUBSTRB(f_YYYYMMDD,5,2)
          and FROM_CURRENCY = 'USD'
          and TO_CURRENCY = t_CURRENCY_LOCAL
     ) Where ROWNUM <= 1;
     --若無後期匯率則抓前期的
     Begin
       Select * into b_EX_RATE_USD From (
         Select ROUND(1 / EXCH_RATE, 5) from KPI_MAP006_EXCHANGE_RATE
          where YYYY = SUBSTRB(t_YYYYMMDD,1,4)
            and MM = SUBSTRB(t_YYYYMMDD,5,2)
            and FROM_CURRENCY = 'USD'
            and TO_CURRENCY = t_CURRENCY_LOCAL
       ) Where ROWNUM <= 1;
     EXCEPTION
       When OTHERS Then
         Select * into b_EX_RATE_USD From (
           Select ROUND(1 / EXCH_RATE, 5) from KPI_MAP006_EXCHANGE_RATE
            where YYYY = SUBSTRB(f_YYYYMMDD,1,4)
              and MM = SUBSTRB(f_YYYYMMDD,5,2)
              and FROM_CURRENCY = 'USD'
              and TO_CURRENCY = t_CURRENCY_LOCAL
         ) Where ROWNUM <= 1;
     End;
   End If;
   If a_EX_RATE_TWD is Null Then
     Select * into a_EX_RATE_TWD From (
       Select ROUND(EXCH_RATE * a_EX_RATE_USD, 5) from KPI_MAP006_EXCHANGE_RATE
        where YYYY = SUBSTRB(f_YYYYMMDD,1,4)
          and MM = SUBSTRB(f_YYYYMMDD,5,2)
          and FROM_CURRENCY = 'USD'
          and TO_CURRENCY = 'TWD'
     ) Where ROWNUM <= 1;
     --若無後期匯率則抓前期的
     Begin
       Select * into b_EX_RATE_TWD From (
         Select ROUND(EXCH_RATE * b_EX_RATE_USD, 5) from KPI_MAP006_EXCHANGE_RATE
          where YYYY = SUBSTRB(t_YYYYMMDD,1,4)
            and MM = SUBSTRB(t_YYYYMMDD,5,2)
            and FROM_CURRENCY = 'USD'
            and TO_CURRENCY = 'TWD'
       ) Where ROWNUM <= 1;
     EXCEPTION
       When OTHERS Then
         Select * into b_EX_RATE_TWD From (
           Select ROUND(EXCH_RATE * b_EX_RATE_USD, 5) from KPI_MAP006_EXCHANGE_RATE
            where YYYY = SUBSTRB(f_YYYYMMDD,1,4)
              and MM = SUBSTRB(f_YYYYMMDD,5,2)
              and FROM_CURRENCY = 'USD'
              and TO_CURRENCY = 'TWD'
         ) Where ROWNUM <= 1;
     End;
   End If;
   */

   --開始處理資料
   --(1) EX_RATE_xxx, NET_REVENUE_xxx, NET_COGS_xxx
   Update TMP_KPI_SAP004_GL_ACCOUNT
      Set EX_RATE_USD = a_EX_RATE_USD,
          EX_RATE_TWD = a_EX_RATE_TWD,
          NET_AMOUNT_USD = Round(NET_AMOUNT * a_EX_RATE_USD, 5),
          NET_AMOUNT_TWD = Round(NET_AMOUNT * a_EX_RATE_TWD, 5)
    Where COMPANY_CODE = inCompany
      and PERIOD = SUBSTRB(f_YYYYMMDD,1,6);
   Commit;

   Update TMP_KPI_SAP004_GL_ACCOUNT
      Set EX_RATE_USD = b_EX_RATE_USD,
          EX_RATE_TWD = b_EX_RATE_TWD,
          NET_AMOUNT_USD = Round(NET_AMOUNT * b_EX_RATE_USD, 5),
          NET_AMOUNT_TWD = Round(NET_AMOUNT * b_EX_RATE_TWD, 5)
    Where COMPANY_CODE = inCompany
      and PERIOD = SUBSTRB(t_YYYYMMDD,1,6);
   Commit;

 End If;
END TMP_KPI_PLS004_GL_ACCOUNT;
/

