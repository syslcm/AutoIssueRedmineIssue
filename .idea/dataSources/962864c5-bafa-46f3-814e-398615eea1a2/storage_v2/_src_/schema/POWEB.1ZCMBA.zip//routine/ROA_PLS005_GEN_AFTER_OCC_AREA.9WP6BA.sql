create PROCEDURE       ROA_PLS005_GEN_AFTER_OCC_AREA (
/* ********************************************************************
  PROG-ID      : ROA_PLS005_GEN_AFTER_OCC_AREA
  PROG-ACTION  : 
  Author       : Asan Chang
  Date         : 2017/05/03
  OA Number    : SAI071408
  Description  : Generate data of fixed assets
********************************************************************* */
   incompany    IN   VARCHAR2,
   YYYYMM       IN   VARCHAR2
)
AUTHID DEFINER
IS
   CURSOR ROA_SAP004_AM_LIST
   IS
      /*SELECT COMPANY_CODE, PERIOD, ASSET_CLASS, ASSET_NO , ASSET_SUB_NO,    
      COST_CENTER, EV_GRP5 ,EV_GRP5_TEXT, CAP_DATE , ASSET_NAME, FYE_ACQ_VAL,     
      CUM_ACQ_VAL, ASSET_VAL_TRANS, VAL_ADJTRANS_FYE, CUM_ORD_DEPREC, 
      ORD_DEP_PSTD, PSTD_UNPL_DEP, CUM_UNPLND_DEP, CUR_NET_BOOK_VAL, 
      INVENTORY_NOTE, SOURCE_FROM               
      FROM ROA_SAP004_AM_LIST*/
      select 
      a.COMPANY_CODE, a.PERIOD, a.ASSET_CLASS, a.ASSET_NO , a.ASSET_SUB_NO,
      a.COST_CENTER CCtr1, a.EV_GRP5 ,a.FYE_ACQ_VAL, a.CUR_NET_BOOK_VAL, a.S_SEQ,
      b.BUILDING ,b.OCC_AREA , b.RADIO ,b.COST_CENTER CCtr2      
      from ROA_SAP004_AM_LIST  a
      left join ROA_SAP003_OCC_AREA b 
      on  a.EV_GRP5 = b.BUILDING  
      and a.company_code =  b.company_code 
      and a.period = b.period      
      where a.COMPANY_CODE = incompany
      and a.PERIOD = YYYYMM;
      /*
      select
      a.COMPANY_CODE, a.PERIOD, a.ASSET_CLASS, a.ASSET_NO , a.ASSET_SUB_NO,
      a.COST_CENTER CCtr1, a.EV_GRP5 ,a.FYE_ACQ_VAL, a.CUR_NET_BOOK_VAL, a.S_SEQ,
      b.BUILDING ,b.OCC_AREA , b.RADIO ,RTRIM(b.COST_CENTER) CCtr2   , c.to_company_code
      from ROA_SAP004_AM_LIST  a
      left join ROA_SAP003_OCC_AREA b
      on  a.EV_GRP5 = b.BUILDING
      and a.company_code =  b.company_code
      and a.period = b.period
      left join  ROA_UPL008_ALLOC_TO_SITE c
      on a.COMPANY_CODE = b.COMPANY_CODE AND c.COST_CENTER = RTRIM(b.COST_CENTER)
      where a.COMPANY_CODE = incompany
      and a.PERIOD =YYYYMM; 
      */
   itracepoint         INTEGER;
   tmp_OWN_TYPE        VARCHAR(1);  --'A':分攤金額, 'B':自己金額
   TMP_AMT1            NUMBER(15,5);
   TMP_AMT2            NUMBER(15,5);
   TMP_CCTR            VARCHAR(10);
   NEW_COMPANY_CODE    VARCHAR(4);
BEGIN


     --(1)清除舊資料
     DELETE FROM ROA_PST002_AFTER_OCC_AREA
     where PERIOD       = YYYYMM
     AND   COMPANY_CODE = incompany;
     COMMIT;  
    
     DELETE FROM ROA_PST002_AFTER_OCC_AREA
     where PERIOD       = YYYYMM
     AND   FROM_COMPANY_CODE = incompany;
     COMMIT; 

   FOR REC1 IN ROA_SAP004_AM_LIST LOOP
     if REC1.EV_GRP5 IS NOT NULL then
       tmp_OWN_TYPE := 'A';
       TMP_AMT1 := ROUND(REC1.FYE_ACQ_VAL / 100 * REC1.RADIO, 5);
       TMP_AMT2 := ROUND(REC1.CUR_NET_BOOK_VAL / 100 * REC1.RADIO, 5);
       TMP_CCTR := RTRIM(REC1.CCtr2, ' ') ;
     else
       tmp_OWN_TYPE := 'B';
       TMP_AMT1 := REC1.FYE_ACQ_VAL;
       TMP_AMT2 := REC1.CUR_NET_BOOK_VAL; 
       TMP_CCTR := RTRIM(REC1.CCtr1, ' ');       
     end if; 
     
     NEW_COMPANY_CODE := ''; 
     
     BEGIN
     select TO_COMPANY_CODE  INTO NEW_COMPANY_CODE  FROM ROA_UPL008_ALLOC_TO_SITE WHERE COMPANY_CODE = incompany AND RTRIM(COST_CENTER) = TMP_CCTR; 
       --(3)開始處理資料
       INSERT INTO ROA_PST002_AFTER_OCC_AREA (
       COMPANY_CODE ,       
       PERIOD ,      
       ASSET_NO ,            
       ASSET_SUB_NO ,        
       EV_GRP5 ,      
       SENDER_COST_CENTER ,  
       RECEIVER_COST_CENTER ,
       BUILDING ,
       OCC_AREA ,          
       RADIO ,          
       OWN_TYPE ,            
       ACQ_VAL ,          
       BOOK_VAL ,           
       ORIGINAL_ACQ_VAL ,    
       ORIGINAL_BOOK_VAL ,  
       S_SEQ, 
       FROM_COMPANY_CODE
       ) VALUES (                                 
       NEW_COMPANY_CODE,       
       REC1.PERIOD ,      
       REC1.ASSET_NO ,            
       REC1.ASSET_SUB_NO ,        
       REC1.EV_GRP5,      
       REC1.CCtr1 ,  
       RTRIM(TMP_CCTR, ' ') ,
       REC1.BUILDING ,
       REC1.OCC_AREA ,          
       REC1.RADIO ,          
       tmp_OWN_TYPE,            
       TMP_AMT1 ,          
       TMP_AMT2 ,           
       REC1.FYE_ACQ_VAL ,    
       REC1.CUR_NET_BOOK_VAL ,  
       REC1.S_SEQ,
       REC1.COMPANY_CODE  );
       COMMIT;  
              
     EXCEPTION
       WHEN NO_DATA_FOUND THEN  
       --(3)開始處理資料
       INSERT INTO ROA_PST002_AFTER_OCC_AREA (
       COMPANY_CODE ,       
       PERIOD ,      
       ASSET_NO ,            
       ASSET_SUB_NO ,        
       EV_GRP5 ,      
       SENDER_COST_CENTER ,  
       RECEIVER_COST_CENTER ,
       BUILDING ,
       OCC_AREA ,          
       RADIO ,          
       OWN_TYPE ,            
       ACQ_VAL ,          
       BOOK_VAL ,           
       ORIGINAL_ACQ_VAL ,    
       ORIGINAL_BOOK_VAL ,  
       S_SEQ
       ) VALUES (                                 
       REC1.COMPANY_CODE ,       
       REC1.PERIOD ,      
       REC1.ASSET_NO ,            
       REC1.ASSET_SUB_NO ,        
       REC1.EV_GRP5,      
       REC1.CCtr1 ,  
       RTRIM(TMP_CCTR, ' ') ,
       REC1.BUILDING ,
       REC1.OCC_AREA ,          
       REC1.RADIO ,          
       tmp_OWN_TYPE,            
       TMP_AMT1 ,          
       TMP_AMT2 ,           
       REC1.FYE_ACQ_VAL ,    
       REC1.CUR_NET_BOOK_VAL ,  
       REC1.S_SEQ
           ); 
       COMMIT;     
     END;
     
     
   END LOOP;

   
   
END ROA_PLS005_GEN_AFTER_OCC_AREA;
/

