create PROCEDURE       pnl3_pls008_realized_trx (
   --inCOMPANY       in VARCHAR2,
   inperiod   IN   VARCHAR2
--2008/9/17 Create to Process get Amount in Local/USD/TWD
--Trigger by PNL2_BAD_DEPT_UPLOAD.JSP
)
AUTHID DEFINER
IS
--2008/11/7 有發現  SUM(NET_REVENUE) <> 0 OR SUM(NET_COGS)  <> 0 條件成立但dm/dl/oh卻有值的戕況,因此不加入此條件
-- 在INSERT進資料庫時再排除金額=0的資料
   a_rate          NUMBER (20, 10);
   a_counter       INTEGER;
   --i_COUNTER       integer;
   a_endcustomer   pnl3_trx001_copa.end_customer_id%TYPE;
BEGIN
   DELETE FROM pnl3_trx007_realized_gm
         WHERE period = inperiod;

   COMMIT;
   a_rate := 0;

   --已有END CUSTOMER的資料直接進db
   INSERT INTO pnl3_trx007_realized_gm
      SELECT *
        FROM pnl2_upl003_realized_gm
       WHERE period = inperiod AND end_customer_id IS NOT NULL;

   FOR rec1 IN (SELECT *
                  FROM pnl2_upl003_realized_gm
                 WHERE period = inperiod AND end_customer_id IS NULL)
   LOOP
      --HAVING ( SUM(NET_REVENUE) <> 0 OR SUM(NET_COGS)  <> 0 )
      a_endcustomer := NULL;
      a_rate := 1;

      IF rec1.profit_center = '0000000034'
      THEN
         a_endcustomer := 'UABIT''S CUST';

         INSERT INTO pnl3_trx007_realized_gm
                     (YEAR, MONTH, profit_center,
                      company_code, end_customer_id, customer_id,
                      currency_local, amount_local, period,
                      material_group, material_type,
                      material, ship_to_party, amount_twd,
                      ex_rate_twd, amount_usd, ex_rate_usd,
                      create_date, uploadsite, plant_code, SOURCE,CATEGORY,CUST_GROUP,SEARCH_TERM,SHIP_TO_PARTY_GROUP,
                      VV006,VV007,VV014,VV015,VV016,VV017,VV018,VV019,
                      VV006_TWD,VV007_TWD,VV014_TWD,VV015_TWD,VV016_TWD,VV017_TWD,VV018_TWD,VV019_TWD,
                      VV006_USD,VV007_USD,VV014_USD,VV015_USD,VV016_USD,VV017_USD,VV018_USD,VV019_USD
                     )
              VALUES (rec1.YEAR, rec1.MONTH, rec1.profit_center,
                      rec1.company_code, a_endcustomer, rec1.customer_id,
                      rec1.currency_local, rec1.amount_local, rec1.period,
                      rec1.material_group, rec1.material_type,
                      rec1.material, rec1.ship_to_party, rec1.amount_twd,
                      rec1.ex_rate_twd, rec1.amount_usd, rec1.ex_rate_usd,
                      SYSDATE, rec1.uploadsite, rec1.plant_code, rec1.SOURCE,REC1.CATEGORY,REC1.CUST_GROUP,REC1.SEARCH_TERM,REC1.SHIP_TO_PARTY_GROUP,
                     REC1.VV006,REC1.VV007,REC1.VV014,REC1.VV015,REC1.VV016,REC1.VV017,REC1.VV018,REC1.VV019,
                     REC1.VV006_TWD,REC1.VV007_TWD,REC1.VV014_TWD,REC1.VV015_TWD,REC1.VV016_TWD,REC1.VV017_TWD,REC1.VV018_TWD,REC1.VV019_TWD,
                     REC1.VV006_USD,REC1.VV007_USD,REC1.VV014_USD,REC1.VV015_USD,REC1.VV016_USD,REC1.VV017_USD,REC1.VV018_USD,REC1.VV019_USD
                     );

         COMMIT;
      ELSIF SUBSTR (rec1.profit_center, 1, 9) = '000000009'
      THEN
         IF SUBSTR (rec1.company_code, 1, 1) = '9'
         THEN
            a_endcustomer := '投資公司';

            INSERT INTO pnl3_trx007_realized_gm
                        (YEAR, MONTH, profit_center,
                         company_code, end_customer_id, customer_id,
                         currency_local, amount_local,
                         period, material_group,
                         material_type, material,
                         ship_to_party, amount_twd,
                         ex_rate_twd, amount_usd,
                         ex_rate_usd, create_date, uploadsite,
                         plant_code, SOURCE, CATEGORY,CUST_GROUP,SEARCH_TERM,SHIP_TO_PARTY_GROUP,
                     VV006,VV007,VV014,VV015,VV016,VV017,VV018,VV019,
                     VV006_TWD,VV007_TWD,VV014_TWD,VV015_TWD,VV016_TWD,VV017_TWD,VV018_TWD,VV019_TWD,
                     VV006_USD,VV007_USD,VV014_USD,VV015_USD,VV016_USD,VV017_USD,VV018_USD,VV019_USD
                        )
                 VALUES (rec1.YEAR, rec1.MONTH, rec1.profit_center,
                         rec1.company_code, a_endcustomer, rec1.customer_id,
                         rec1.currency_local, rec1.amount_local,
                         rec1.period, rec1.material_group,
                         rec1.material_type, rec1.material,
                         rec1.ship_to_party, rec1.amount_twd,
                         rec1.ex_rate_twd, rec1.amount_usd,
                         rec1.ex_rate_usd, SYSDATE, rec1.uploadsite,
                         rec1.plant_code, rec1.SOURCE, REC1.CATEGORY,REC1.CUST_GROUP,REC1.SEARCH_TERM,REC1.SHIP_TO_PARTY_GROUP,
                     REC1.VV006,REC1.VV007,REC1.VV014,REC1.VV015,REC1.VV016,REC1.VV017,REC1.VV018,REC1.VV019,
                     REC1.VV006_TWD,REC1.VV007_TWD,REC1.VV014_TWD,REC1.VV015_TWD,REC1.VV016_TWD,REC1.VV017_TWD,REC1.VV018_TWD,REC1.VV019_TWD,
                     REC1.VV006_USD,REC1.VV007_USD,REC1.VV014_USD,REC1.VV015_USD,REC1.VV016_USD,REC1.VV017_USD,REC1.VV018_USD,REC1.VV019_USD
                        );

            COMMIT;
         ELSE
            a_counter := 0;

            FOR rec2 IN (SELECT end_customer_id, rate
                           FROM pnl3_map001_customer_rate
                          WHERE r_kind =
                                        'PL01'
                                              --隨便抓一筆來用,反正匯率都一樣
                            AND area1 = '4'
                            AND area2 = '1'
                            AND area3 = '1'
                            --AND COMPANY_CODE = REC1.COMPANY_CODE
                            AND profit_center = rec1.profit_center
                            AND period = inperiod)
            LOOP
               a_rate := rec2.rate;
               a_endcustomer := rec2.end_customer_id;
               a_counter := 1;

               INSERT INTO pnl3_trx007_realized_gm
                           (YEAR, MONTH, profit_center,
                            company_code, end_customer_id,
                            customer_id, currency_local,
                            amount_local,
                            period, material_group,
                            material_type, material,
                            ship_to_party,
                            amount_twd,
                            ex_rate_twd,
                            amount_usd,
                            ex_rate_usd, create_date, uploadsite,
                            plant_code, SOURCE, CATEGORY,CUST_GROUP,SEARCH_TERM,SHIP_TO_PARTY_GROUP,
                     VV006,VV007,VV014,VV015,VV016,VV017,VV018,VV019,
                     VV006_TWD,VV007_TWD,VV014_TWD,VV015_TWD,VV016_TWD,VV017_TWD,VV018_TWD,VV019_TWD,
                     VV006_USD,VV007_USD,VV014_USD,VV015_USD,VV016_USD,VV017_USD,VV018_USD,VV019_USD
                           )
                    VALUES (rec1.YEAR, rec1.MONTH, rec1.profit_center,
                            rec1.company_code, a_endcustomer,
                            rec1.customer_id, rec1.currency_local,
                            ROUND (rec1.amount_local * a_rate, 5),
                            rec1.period, rec1.material_group,
                            rec1.material_type, rec1.material,
                            rec1.ship_to_party,
                            ROUND (rec1.amount_twd * a_rate, 5),
                            rec1.ex_rate_twd,
                            ROUND (rec1.amount_usd * a_rate, 5),
                            rec1.ex_rate_usd, SYSDATE, rec1.uploadsite,
                            rec1.plant_code, rec1.SOURCE,REC1.CATEGORY,REC1.CUST_GROUP,REC1.SEARCH_TERM,REC1.SHIP_TO_PARTY_GROUP,
                     ROUND(REC1.VV006 * a_RATE,5),ROUND(REC1.VV007 * a_RATE,5),ROUND(REC1.VV014 * a_RATE,5),ROUND(REC1.VV015 * a_RATE,5),ROUND(REC1.VV016 * a_RATE,5),ROUND(REC1.VV017 * a_RATE,5),ROUND(REC1.VV018 * a_RATE,5),ROUND(REC1.VV019 * a_RATE,5),
                     ROUND(REC1.VV006_TWD * a_RATE,5),ROUND(REC1.VV007_TWD * a_RATE,5),ROUND(REC1.VV014_TWD * a_RATE,5),ROUND(REC1.VV015_TWD * a_RATE,5),ROUND(REC1.VV016_TWD * a_RATE,5),ROUND(REC1.VV017_TWD * a_RATE,5),ROUND(REC1.VV018_TWD * a_RATE,5),ROUND(REC1.VV019_TWD * a_RATE,5),
                     ROUND(REC1.VV006_USD * a_RATE,5),ROUND(REC1.VV007_USD * a_RATE,5),ROUND(REC1.VV014_USD * a_RATE,5),ROUND(REC1.VV015_USD * a_RATE,5),ROUND(REC1.VV016_USD * a_RATE,5),ROUND(REC1.VV017_USD * a_RATE,5),ROUND(REC1.VV018_USD * a_RATE,5),ROUND(REC1.VV019_USD * a_RATE,5)
                           );

               COMMIT;
            END LOOP;

            IF a_counter = 0
            THEN
               FOR rec2 IN (SELECT end_customer_id, rate
                              FROM pnl3_map001_global_cust_rate
                             WHERE r_kind =
                                        'PL01'
                                              --隨便抓一筆來用,反正匯率都一樣
                               AND area1 = '4'
                               AND area2 = '1'
                               AND area3 = '1'
                               --AND COMPANY_CODE = REC1.COMPANY_CODE
                               --AND PROFIT_CENTER = REC1.PROFIT_CENTER
                               AND period = inperiod)
               LOOP
                  a_rate := rec2.rate;
                  a_endcustomer := rec2.end_customer_id;

                  INSERT INTO pnl3_trx007_realized_gm
                              (YEAR, MONTH, profit_center,
                               company_code, end_customer_id,
                               customer_id, currency_local,
                               amount_local,
                               period, material_group,
                               material_type, material,
                               ship_to_party,
                               amount_twd,
                               ex_rate_twd,
                               amount_usd,
                               ex_rate_usd, create_date, uploadsite,
                               plant_code, SOURCE, CATEGORY,CUST_GROUP,SEARCH_TERM,SHIP_TO_PARTY_GROUP,
                     VV006,VV007,VV014,VV015,VV016,VV017,VV018,VV019,
                     VV006_TWD,VV007_TWD,VV014_TWD,VV015_TWD,VV016_TWD,VV017_TWD,VV018_TWD,VV019_TWD,
                     VV006_USD,VV007_USD,VV014_USD,VV015_USD,VV016_USD,VV017_USD,VV018_USD,VV019_USD
                              )
                       VALUES (rec1.YEAR, rec1.MONTH, rec1.profit_center,
                               rec1.company_code, a_endcustomer,
                               rec1.customer_id, rec1.currency_local,
                               ROUND (rec1.amount_local * a_rate, 5),
                               rec1.period, rec1.material_group,
                               rec1.material_type, rec1.material,
                               rec1.ship_to_party,
                               ROUND (rec1.amount_twd * a_rate, 5),
                               rec1.ex_rate_twd,
                               ROUND (rec1.amount_usd * a_rate, 5),
                               rec1.ex_rate_usd, SYSDATE, rec1.uploadsite,
                               rec1.plant_code, rec1.SOURCE,REC1.CATEGORY,REC1.CUST_GROUP,REC1.SEARCH_TERM,REC1.SHIP_TO_PARTY_GROUP,
                     ROUND(REC1.VV006 * a_RATE,5),ROUND(REC1.VV007 * a_RATE,5),ROUND(REC1.VV014 * a_RATE,5),ROUND(REC1.VV015 * a_RATE,5),ROUND(REC1.VV016 * a_RATE,5),ROUND(REC1.VV017 * a_RATE,5),ROUND(REC1.VV018 * a_RATE,5),ROUND(REC1.VV019 * a_RATE,5),
                     ROUND(REC1.VV006_TWD * a_RATE,5),ROUND(REC1.VV007_TWD * a_RATE,5),ROUND(REC1.VV014_TWD * a_RATE,5),ROUND(REC1.VV015_TWD * a_RATE,5),ROUND(REC1.VV016_TWD * a_RATE,5),ROUND(REC1.VV017_TWD * a_RATE,5),ROUND(REC1.VV018_TWD * a_RATE,5),ROUND(REC1.VV019_TWD * a_RATE,5),
                     ROUND(REC1.VV006_USD * a_RATE,5),ROUND(REC1.VV007_USD * a_RATE,5),ROUND(REC1.VV014_USD * a_RATE,5),ROUND(REC1.VV015_USD * a_RATE,5),ROUND(REC1.VV016_USD * a_RATE,5),ROUND(REC1.VV017_USD * a_RATE,5),ROUND(REC1.VV018_USD * a_RATE,5),ROUND(REC1.VV019_USD * a_RATE,5)
                              );

                  COMMIT;
               END LOOP;
            END IF;
         END IF;
      ELSE
         a_counter := 0;

         FOR rec2 IN (SELECT end_customer_id, rate
                        FROM pnl3_map001_customer_rate
                       WHERE r_kind = 'PL01'  --隨便抓一筆來用,反正匯率都一樣
                         AND area1 = '4'
                         AND area2 = '1'
                         AND area3 = '1'
                         --AND COMPANY_CODE = REC1.COMPANY_CODE
                         AND profit_center = rec1.profit_center
                         AND period = inperiod)
         LOOP
            a_rate := rec2.rate;
            a_endcustomer := rec2.end_customer_id;
            a_counter := 1;

            INSERT INTO pnl3_trx007_realized_gm
                        (YEAR, MONTH, profit_center,
                         company_code, end_customer_id, customer_id,
                         currency_local,
                         amount_local, period,
                         material_group, material_type,
                         material, ship_to_party,
                         amount_twd,
                         ex_rate_twd,
                         amount_usd,
                         ex_rate_usd, create_date, uploadsite,
                         plant_code, SOURCE, CATEGORY,CUST_GROUP,SEARCH_TERM,SHIP_TO_PARTY_GROUP,
                     VV006,VV007,VV014,VV015,VV016,VV017,VV018,VV019,
                     VV006_TWD,VV007_TWD,VV014_TWD,VV015_TWD,VV016_TWD,VV017_TWD,VV018_TWD,VV019_TWD,
                     VV006_USD,VV007_USD,VV014_USD,VV015_USD,VV016_USD,VV017_USD,VV018_USD,VV019_USD
                        )
                 VALUES (rec1.YEAR, rec1.MONTH, rec1.profit_center,
                         rec1.company_code, a_endcustomer, rec1.customer_id,
                         rec1.currency_local,
                         ROUND (rec1.amount_local * a_rate, 5), rec1.period,
                         rec1.material_group, rec1.material_type,
                         rec1.material, rec1.ship_to_party,
                         ROUND (rec1.amount_twd * a_rate, 5),
                         rec1.ex_rate_twd,
                         ROUND (rec1.amount_usd * a_rate, 5),
                         rec1.ex_rate_usd, SYSDATE, rec1.uploadsite,
                         rec1.plant_code, rec1.SOURCE,REC1.CATEGORY,REC1.CUST_GROUP,REC1.SEARCH_TERM,REC1.SHIP_TO_PARTY_GROUP,
                     ROUND(REC1.VV006 * a_RATE,5),ROUND(REC1.VV007 * a_RATE,5),ROUND(REC1.VV014 * a_RATE,5),ROUND(REC1.VV015 * a_RATE,5),ROUND(REC1.VV016 * a_RATE,5),ROUND(REC1.VV017 * a_RATE,5),ROUND(REC1.VV018 * a_RATE,5),ROUND(REC1.VV019 * a_RATE,5),
                     ROUND(REC1.VV006_TWD * a_RATE,5),ROUND(REC1.VV007_TWD * a_RATE,5),ROUND(REC1.VV014_TWD * a_RATE,5),ROUND(REC1.VV015_TWD * a_RATE,5),ROUND(REC1.VV016_TWD * a_RATE,5),ROUND(REC1.VV017_TWD * a_RATE,5),ROUND(REC1.VV018_TWD * a_RATE,5),ROUND(REC1.VV019_TWD * a_RATE,5),
                     ROUND(REC1.VV006_USD * a_RATE,5),ROUND(REC1.VV007_USD * a_RATE,5),ROUND(REC1.VV014_USD * a_RATE,5),ROUND(REC1.VV015_USD * a_RATE,5),ROUND(REC1.VV016_USD * a_RATE,5),ROUND(REC1.VV017_USD * a_RATE,5),ROUND(REC1.VV018_USD * a_RATE,5),ROUND(REC1.VV019_USD * a_RATE,5)
                        );

            COMMIT;
         END LOOP;

         IF a_counter = 0
         THEN
            FOR rec2 IN (SELECT end_customer_id, rate
                           FROM pnl3_map001_global_cust_rate
                          WHERE r_kind =
                                        'PL01'
                                              --隨便抓一筆來用,反正匯率都一樣
                            AND area1 = '4'
                            AND area2 = '1'
                            AND area3 = '1'
                            --AND COMPANY_CODE = REC1.COMPANY_CODE
                              --AND PROFIT_CENTER = REC1.PROFIT_CENTER
                            AND period = inperiod)
            LOOP
               a_rate := rec2.rate;
               a_endcustomer := rec2.end_customer_id;
               a_counter := 1;

               INSERT INTO pnl3_trx007_realized_gm
                           (YEAR, MONTH, profit_center,
                            company_code, end_customer_id,
                            customer_id, currency_local,
                            amount_local,
                            period, material_group,
                            material_type, material,
                            ship_to_party,
                            amount_twd,
                            ex_rate_twd,
                            amount_usd,
                            ex_rate_usd, create_date, uploadsite,
                            plant_code, SOURCE, CATEGORY,CUST_GROUP,SEARCH_TERM,SHIP_TO_PARTY_GROUP,
                                                 VV006,VV007,VV014,VV015,VV016,VV017,VV018,VV019,
                     VV006_TWD,VV007_TWD,VV014_TWD,VV015_TWD,VV016_TWD,VV017_TWD,VV018_TWD,VV019_TWD,
                     VV006_USD,VV007_USD,VV014_USD,VV015_USD,VV016_USD,VV017_USD,VV018_USD,VV019_USD
                           )
                    VALUES (rec1.YEAR, rec1.MONTH, rec1.profit_center,
                            rec1.company_code, a_endcustomer,
                            rec1.customer_id, rec1.currency_local,
                            ROUND (rec1.amount_local * a_rate, 5),
                            rec1.period, rec1.material_group,
                            rec1.material_type, rec1.material,
                            rec1.ship_to_party,
                            ROUND (rec1.amount_twd * a_rate, 5),
                            rec1.ex_rate_twd,
                            ROUND (rec1.amount_usd * a_rate, 5),
                            rec1.ex_rate_usd, SYSDATE, rec1.uploadsite,
                            rec1.plant_code, rec1.SOURCE,REC1.CATEGORY,REC1.CUST_GROUP,REC1.SEARCH_TERM,REC1.SHIP_TO_PARTY_GROUP,
                                                 ROUND(REC1.VV006 * a_RATE,5),ROUND(REC1.VV007 * a_RATE,5),ROUND(REC1.VV014 * a_RATE,5),ROUND(REC1.VV015 * a_RATE,5),ROUND(REC1.VV016 * a_RATE,5),ROUND(REC1.VV017 * a_RATE,5),ROUND(REC1.VV018 * a_RATE,5),ROUND(REC1.VV019 * a_RATE,5),
                     ROUND(REC1.VV006_TWD * a_RATE,5),ROUND(REC1.VV007_TWD * a_RATE,5),ROUND(REC1.VV014_TWD * a_RATE,5),ROUND(REC1.VV015_TWD * a_RATE,5),ROUND(REC1.VV016_TWD * a_RATE,5),ROUND(REC1.VV017_TWD * a_RATE,5),ROUND(REC1.VV018_TWD * a_RATE,5),ROUND(REC1.VV019_TWD * a_RATE,5),
                     ROUND(REC1.VV006_USD * a_RATE,5),ROUND(REC1.VV007_USD * a_RATE,5),ROUND(REC1.VV014_USD * a_RATE,5),ROUND(REC1.VV015_USD * a_RATE,5),ROUND(REC1.VV016_USD * a_RATE,5),ROUND(REC1.VV017_USD * a_RATE,5),ROUND(REC1.VV018_USD * a_RATE,5),ROUND(REC1.VV019_USD * a_RATE,5)
                           );

               COMMIT;
            END LOOP;
         END IF;
      END IF;
   END LOOP;

   UPDATE pnl3_trx007_realized_gm
      SET project_name =
             (SELECT DISTINCT TRIM (sap_project_name)
                         FROM cep_map010_partno_project
                        WHERE fg_material_no =
                                 RPAD (pnl3_trx007_realized_gm.material,
                                       18,
                                       ' '
                                      ))
    WHERE period = inperiod;

   COMMIT;

   UPDATE pnl3_trx007_realized_gm
      SET project_type =
                  (SELECT DISTINCT TRIM (project_type)
                              FROM cep_web002_project
                             WHERE project_name =
                                          pnl3_trx007_realized_gm.project_name)
    --RPAD (PNL3_TRX003_UNUTILIZATION.PROJECT_NAME, 30, ' '))
   WHERE  period = inperiod;

   COMMIT;
END pnl3_pls008_realized_trx;
/

