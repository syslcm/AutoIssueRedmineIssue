create PROCEDURE         "PLSQL_PLD_KPI_AUDIT_ZD468_T" (
	inCompany  in VARCHAR2,
	f_YYYYMMDD in VARCHAR2,
	t_YYYYMMDD in VARCHAR2
)
AUTHID DEFINER
is
	/*
	處理 PLD_KPI_AUDIT_ZD468x 資料 (SAP ZD468)
	-- PO vs Inforecord diff.
	-- PR / PO without inforecord
	-- interface: KPI_SYS005_TABLELIST
	SAI029479 2012/05/16 M.H 每週計算CM處理P/R withount info record之筆數與平均處理天數
		加入處理 PLD_KPI_AUDIT_ZD468_PR_OPEN & PLD_KPI_AUDIT_ZD468_PR_CLOSE
		扣除星期六日當休假日, 其他先不管
  SAI054810 Susan 2016/05/16 Add PLANT_STATUS, 修改--(100) 
                 (PLD_KPI_AUDIT_ZD468_T =>PLD_KPI_AUDIT_ZD468)
  SAI054017 Susan 20160729 jq same other site 
  for mx site                	          	
	*/
	iTracePoint         varchar2(3);
	cErrorText          varchar2(500);
	nDIFF_DAY           PLD_KPI_AUDIT_ZD468_PR_CLOSE.DIFF_DAY%TYPE;
BEGIN
	--(000) 清除 create_date 錯誤者
	iTracePoint := '000';
--20180821 MARK By susan	
--	delete from PLD_KPI_AUDIT_ZD468_T
--		where COMPANY_CODE = inCompany
--		and CREATE_DATE <> to_char(sysdate,'yyyymmdd');
--	commit;

	--(010)Vendor 為USI的也全部刪除(GVC: H00479).
	iTracePoint := '010';
	delete from PLD_KPI_AUDIT_ZD468_T
		where COMPANY_CODE = inCompany
		and VENDOR_CODE in (
			select SAP_VENDOR_CODE from GVM032_GLOBAL_VENDOR_ITEM
			where GLOBAL_VENDOR_CODE in ('H00479')
			and COMPANY_CODE = inCompany
		);
	commit;

	--(030)清除PO price cut-in by PO create date的供應商(Global Vendor Code)
	-- 暫未定義


	--(050) delete old data: PLD_KPI_AUDIT_ZD468
	iTracePoint := '050';
	-- mark 20180821 NEW
	--delete from PLD_KPI_AUDIT_ZD468 where COMPANY_CODE = inCompany;
	--commit;

	--(100) move data: PLD_KPI_AUDIT_ZD468_T  ->  PLD_KPI_AUDIT_ZD468
	iTracePoint := '100';
  insert into PLD_KPI_AUDIT_ZD468 (
		COMPANY_CODE, PLANT, VENDOR_CODE, VENDOR_NAME, PART_NO, MFG, USI_MPN,
		DOC_CURRENCY, DOC_PRICE, INF_CURRENCY, INF_PRICE, DIFF_RATE, QUOTA_ARR,
		PART_DESC, INF_TAX, INF_VALID, SP, BUYER_CODE, BUYER_NAME, SOURCER_ID, SOURCER_NAME,
		DOC_NO, DOC_ITEM, DOC_QTY, OPEN_QTY, PSTYP, DOC_CREATE, PART_GROUP, PROFIT_CENTER,
		DOC_TAX, DOC_USD_UP, INF_USD_UP, DIFF_USD_AMT, REC_OWNER, REC_TYPE, VMI, CREATE_DATE,
		SITE, SP_DEP, REASON_CODE,
		PO_HEADER_MP, REASON_REMARK, DOC_TYPE, PLANT_STATUS
	)
	select a.COMPANY_CODE, a.PLANT, a.VENDOR_CODE, a.VENDOR_NAME, a.PART_NO, a.MFG, a.USI_MPN,
			a.DOC_CURRENCY, a.DOC_PRICE, a.INF_CURRENCY, a.INF_PRICE, a.DIFF_RATE, a.QUOTA_ARR,
			a.PART_DESC, a.INF_TAX, a.INF_VALID, a.SP, a.BUYER_CODE, a.BUYER_NAME, a.SOURCER_ID, a.SOURCER_NAME,
			a.DOC_NO, a.DOC_ITEM, a.DOC_QTY, a.OPEN_QTY, a.PSTYP, a.DOC_CREATE, a.PART_GROUP, a.PROFIT_CENTER,
			a.DOC_TAX, a.DOC_USD_UP, a.INF_USD_UP, a.DIFF_USD_AMT, a.REC_OWNER, a.REC_TYPE, a.VMI, a.CREATE_DATE,
			trim(upper(b.DEPT_NAME_KPI2)), trim(upper(c.SP_CODE)), a.REASON_CODE,
			a.PO_HEADER_MP, a.REASON_REMARK, a.DOC_TYPE, a.PLANT_STATUS
		from PLD_KPI_AUDIT_ZD468_T a, Z_POWEB_050A b, PLD_KPI_RFQ_WORKER_MASTER_VIEW c
		where a.COMPANY_CODE = inCompany
		and a.CREATE_DATE = to_char(sysdate,'yyyymmdd')
		and b.COMPANY_CODE (+)= a.COMPANY_CODE
		and b.BUYER_CODE (+)= a.BUYER_CODE
		and c.WORKER_ID (+)= a.SOURCER_ID;
	commit;

	--(150) update  PLD_KPI_AUDIT_ZD468-SITE為空白者
	iTracePoint := '150';
	update PLD_KPI_AUDIT_ZD468
		set SITE = '.other'
	where COMPANY_CODE = inCompany
	and CREATE_DATE = to_char(sysdate,'yyyymmdd')
	and SITE is null;
	commit;

	--(170) update  PLD_KPI_AUDIT_ZD468-SP_DEP為空白者
	iTracePoint := '170';
	update PLD_KPI_AUDIT_ZD468
		set SP_DEP = '.other'
	where COMPANY_CODE = inCompany
	and CREATE_DATE = to_char(sysdate,'yyyymmdd')
	and SP_DEP is null;
	commit;


	--(200) update REC_TYPE2
	iTracePoint := '200';
	update PLD_KPI_AUDIT_ZD468
		set REC_TYPE2 = REC_OWNER
	where COMPANY_CODE = inCompany
	and CREATE_DATE = to_char(sysdate,'yyyymmdd')
	and REC_OWNER = '--'
	and REC_TYPE2 is null;
	commit;

	--(220) update REC_TYPE2 (MP 1.PO price > InfoReocrd)
	iTracePoint := '220';
	update PLD_KPI_AUDIT_ZD468
		set REC_TYPE2 = '1.PO price > InfoReocrd'
	where COMPANY_CODE = inCompany
	and CREATE_DATE = to_char(sysdate,'yyyymmdd')
	and REC_OWNER = 'MP'
	and INF_CURRENCY = DOC_CURRENCY
	and REC_TYPE2 is null;
	commit;

	--(260) update REC_TYPE2 --> 20080918移到MP
	iTracePoint := '260';
	update PLD_KPI_AUDIT_ZD468
		set REC_TYPE2 = '2.PO without InfoReocrd'
	where COMPANY_CODE = inCompany
	and CREATE_DATE = to_char(sysdate,'yyyymmdd')
	and REC_OWNER = 'MP'
	and REC_TYPE = 'PO'
	and INF_PRICE is null
	and REC_TYPE2 is null;
	commit;

	--(225) update REC_TYPE2 (MP 3.Currency different)
	iTracePoint := '225';
	update PLD_KPI_AUDIT_ZD468
		set REC_TYPE2 = '3.Currency different'
	where COMPANY_CODE = inCompany
	and CREATE_DATE = to_char(sysdate,'yyyymmdd')
	and REC_OWNER = 'MP'
	and INF_CURRENCY <> DOC_CURRENCY
	and REC_TYPE2 is null;
	commit;

	--(250) update REC_TYPE2 (SP 1.PO price < InfoReocrd)
	iTracePoint := '250';
	update PLD_KPI_AUDIT_ZD468
		set REC_TYPE2 = '1.PO price < InfoReocrd'
	where COMPANY_CODE = inCompany
	and CREATE_DATE = to_char(sysdate,'yyyymmdd')
	and REC_OWNER = 'SP'
	and REC_TYPE = 'PO'
	and INF_PRICE is not null
	and REC_TYPE2 is null;
	commit;

	--(260) update REC_TYPE2 (SP 2.PR without InfoReocrd)
	iTracePoint := '260';
	update PLD_KPI_AUDIT_ZD468
		set REC_TYPE2 = '2.PR without InfoReocrd'
	where COMPANY_CODE = inCompany
	and CREATE_DATE = to_char(sysdate,'yyyymmdd')
	and REC_OWNER = 'SP'
	and REC_TYPE = 'PR'
	and INF_PRICE is null
	and REC_TYPE2 is null;
	commit;

	--(270) update REC_TYPE2 (SP 3.PR InfoReocrd Overdue)
	iTracePoint := '270';
	update PLD_KPI_AUDIT_ZD468 set
		REC_TYPE2 = '3.PR InfoReocrd Overdue',
		REC_OWNER = 'SP'
	where COMPANY_CODE = inCompany
	and CREATE_DATE = to_char(sysdate,'yyyymmdd')
	and REC_OWNER = 'SP2'
	and REC_TYPE = 'PR'
	and REC_TYPE2 is null;
	commit;

	--(300) update PART_TYPE (1-1) : RFQ VENDOR_MASTER set consign
	iTracePoint := '300';
	update PLD_KPI_AUDIT_ZD468
		set PART_TYPE = 'CONSIGN'
	where COMPANY_CODE = inCompany
	and CREATE_DATE = to_char(sysdate,'yyyymmdd')
	and PART_TYPE is null
	and (COMPANY_CODE,VENDOR_CODE) in (
		select COMPANY_CODE, SAP_VENDOR_CODE from PLD_KPI_CONSIGN_VENDOR_VIEW
	);
	commit;

	--(310) update PART_TYPE (1-2) : RFQ PRICE_LOA set consign
	iTracePoint := '305';
	update PLD_KPI_AUDIT_ZD468
		set PART_TYPE = 'CONSIGN'
	where COMPANY_CODE = inCompany
	and CREATE_DATE = to_char(sysdate,'yyyymmdd')
	and PART_TYPE is null
	and PART_NO in (
		select CUSTOM_PART from PLD_KPI_PRICE_LOA_VIEW where LOA_TYPE = 'CONSIGN'
	);
	commit;

	--(310) update PART_TYPE (1-3) : Part like '6x-xxxxxx-xx' or 'xx-xxxxxx-6x'
	iTracePoint := '310';
	update PLD_KPI_AUDIT_ZD468
		set PART_TYPE = 'CONSIGN'
	where COMPANY_CODE = inCompany
	and CREATE_DATE = to_char(sysdate,'yyyymmdd')
	and PART_TYPE is null
	and ( PART_NO like '6_-______-__' or PART_NO like '__-______-6_' );
	commit;

	--(320) update PART_TYPE - loa
	iTracePoint := '320';
	update PLD_KPI_AUDIT_ZD468
		set PART_TYPE = 'LOA'
	where COMPANY_CODE = inCompany
	and CREATE_DATE = to_char(sysdate,'yyyymmdd')
	and PART_TYPE is null
	and PART_NO in (
		select CUSTOM_PART from PLD_KPI_PRICE_LOA_VIEW where LOA_TYPE = 'LOA'
	);
	commit;

	--(330) update PART_TYPE - normal
	iTracePoint := '330';
	update PLD_KPI_AUDIT_ZD468
		set PART_TYPE = 'NORMAL'
	where COMPANY_CODE = inCompany
	and CREATE_DATE = to_char(sysdate,'yyyymmdd')
	and PART_TYPE is null;
	commit;


	--(350)處理 PLD_KPI_AUDIT_ZD468_HISTORY
	iTracePoint := '350';
	delete from PLD_KPI_AUDIT_ZD468_HISTORY
		where COMPANY_CODE = inCompany
		and CREATE_DATE = to_char(sysdate,'yyyymmdd');
	commit;

	iTracePoint := '380';
	insert into PLD_KPI_AUDIT_ZD468_HISTORY
		select * from PLD_KPI_AUDIT_ZD468
		where COMPANY_CODE = inCompany
		and CREATE_DATE = to_char(sysdate,'yyyymmdd')
		and nvl(REC_OWNER,'--') <> '--';
	commit;

	--(400)處理 PLD_KPI_AUDIT_ZD468_SUM
	iTracePoint := '400';
	delete from PLD_KPI_AUDIT_ZD468_SUM
		where COMPANY_CODE = inCompany
		and CREATE_DATE = to_char(sysdate,'yyyymmdd')
		and REC_TYPE = 'price';
	commit;

	iTracePoint := '420';
	insert into PLD_KPI_AUDIT_ZD468_SUM (
		CREATE_DATE, REC_OWNER, REC_TYPE, REC_TYPE2, REC_LOCATION, REC_COUNT, REC_AMOUNT,
		COMPANY_CODE, PART_TYPE
	)
	select CREATE_DATE, REC_OWNER, 'price', REC_TYPE2, SITE, sum(1), sum(DIFF_USD_AMT),
		COMPANY_CODE, PART_TYPE
		from PLD_KPI_AUDIT_ZD468
		where COMPANY_CODE = inCompany
		and CREATE_DATE = to_char(sysdate,'yyyymmdd')
		and REC_OWNER = 'MP'
		group by CREATE_DATE, REC_OWNER, REC_TYPE2, SITE, COMPANY_CODE, PART_TYPE;
	commit;

	iTracePoint := '440';
	insert into PLD_KPI_AUDIT_ZD468_SUM (
		CREATE_DATE, REC_OWNER, REC_TYPE, REC_TYPE2, REC_LOCATION, REC_COUNT, REC_AMOUNT,
		COMPANY_CODE, PART_TYPE
	)
	select CREATE_DATE, REC_OWNER, 'price', REC_TYPE2, SP_DEP, sum(1), sum(DIFF_USD_AMT),
		COMPANY_CODE, PART_TYPE
		from PLD_KPI_AUDIT_ZD468
		where COMPANY_CODE = inCompany
		and CREATE_DATE = to_char(sysdate,'yyyymmdd')
		and REC_OWNER = 'SP'
		group by CREATE_DATE, REC_OWNER, REC_TYPE2, SP_DEP, COMPANY_CODE, PART_TYPE;
	commit;

	--(450)處理 PLD_KPI_AUDIT_ZD468_SP_R1
	-- 用於 SP report P/R without InfoRecord  計算天數 (\\10.0.3.136\F:\DMS\DMS_MAC_report\DMS_MAC_report.exe)
	iTracePoint := '450';
	delete from PLD_KPI_AUDIT_ZD468_SP_R1
		where COMPANY_CODE = inCompany;
	commit;
	----(451) normal
	iTracePoint := '451';
	insert into PLD_KPI_AUDIT_ZD468_SP_R1 (
		COMPANY_CODE, USI_MPN, VENDOR_CODE, SP_DEP, PART_TYPE, CREATE_DATE, DOC_CREATE, DIFF_DAYS
	)
	select COMPANY_CODE, USI_MPN, VENDOR_CODE, SP_DEP, 'NORMAL', CREATE_DATE,
		min(DOC_CREATE),
		floor(SYSDATE - TO_DATE(min(DOC_CREATE),'yyyymmdd'))
	from PLD_KPI_AUDIT_ZD468
	where COMPANY_CODE = inCompany
	and CREATE_DATE = to_char(sysdate,'yyyymmdd')
	and REC_OWNER = 'SP'
	and REC_TYPE2 = '2.PR without InfoReocrd'
	and DOC_CREATE >= '20080701'
	and PART_NO not like '%-C'
	and PART_NO not like '%-60'
	and PART_NO not like '67-%'
	and PART_NO not like '69-%'
	and not exists (
		select PART_NO from SAP_MATERIAL_PLANT
		where COMPANY_CODE = PLD_KPI_AUDIT_ZD468.COMPANY_CODE
		and PART_NO = PLD_KPI_AUDIT_ZD468.PART_NO
		and PLANT = PLD_KPI_AUDIT_ZD468.PLANT
		and SPEC_PROCUREMENT = '10'
	)
	group by COMPANY_CODE, USI_MPN, VENDOR_CODE, SP_DEP, CREATE_DATE;
	commit;
	----(452) consign
	iTracePoint := '452';
	insert into PLD_KPI_AUDIT_ZD468_SP_R1 (
		COMPANY_CODE, USI_MPN, VENDOR_CODE, SP_DEP, PART_TYPE, CREATE_DATE, DOC_CREATE, DIFF_DAYS
	)
	select COMPANY_CODE, USI_MPN, VENDOR_CODE, SP_DEP, 'CONSIGN', CREATE_DATE,
		min(DOC_CREATE),
		floor(SYSDATE - TO_DATE(min(DOC_CREATE),'yyyymmdd'))
	from PLD_KPI_AUDIT_ZD468
	where COMPANY_CODE = inCompany
	and CREATE_DATE = to_char(sysdate,'yyyymmdd')
	and REC_OWNER = 'SP'
	and REC_TYPE2 = '2.PR without InfoReocrd'
	and DOC_CREATE >= '20080701'
	and (
		PART_NO like '%-C' or
		PART_NO like '%-60' or
		PART_NO like '67-%' or
		PART_NO like '69-%' or
		exists (
			select PART_NO from SAP_MATERIAL_PLANT
			where COMPANY_CODE = PLD_KPI_AUDIT_ZD468.COMPANY_CODE
			and PART_NO = PLD_KPI_AUDIT_ZD468.PART_NO
			and PLANT = PLD_KPI_AUDIT_ZD468.PLANT
			and SPEC_PROCUREMENT = '10'
		)
	)
	group by COMPANY_CODE, USI_MPN, VENDOR_CODE, SP_DEP, CREATE_DATE;
	commit;

	--(455)處理 PLD_KPI_AUDIT_ZD468_MP_R1
	-- 用於 Buyer report P/R without InfoRecord  計算天數 (\\10.0.3.136\F:\DMS\DMS_MAC_report\DMS_MAC_report.exe)
	iTracePoint := '450';
	delete from PLD_KPI_AUDIT_ZD468_MP_R1
		where COMPANY_CODE = inCompany;
	commit;
	----(456)
	iTracePoint := '456';
	insert into PLD_KPI_AUDIT_ZD468_MP_R1 (
		COMPANY_CODE, USI_MPN, VENDOR_CODE, BUYER_CODE, CREATE_DATE, DOC_CREATE, DIFF_DAYS
	)
	select COMPANY_CODE, USI_MPN, VENDOR_CODE, BUYER_CODE, CREATE_DATE,
		min(DOC_CREATE),
		floor(SYSDATE - TO_DATE(min(DOC_CREATE),'yyyymmdd'))
	from PLD_KPI_AUDIT_ZD468
	where COMPANY_CODE = inCompany
	and CREATE_DATE = to_char(sysdate,'yyyymmdd')
	and REC_OWNER = 'SP'
	and REC_TYPE2 = '2.PR without InfoReocrd'
	and DOC_CREATE >= '20080701'
	group by COMPANY_CODE, USI_MPN, VENDOR_CODE, BUYER_CODE, CREATE_DATE;
	commit;

	--(500)處理 PLD_KPI_AUDIT_ZD468_MFG   (抓VIEW_EGI0010_MATL_MASTER資料)
	iTracePoint := '500';
	delete from PLD_KPI_AUDIT_ZD468_MFG where COMPANY_CODE = inCompany;
	commit;
	iTracePoint := '510';
	insert into PLD_KPI_AUDIT_ZD468_MFG (
		COMPANY_CODE, PART_NO, MFG, MFG_PN, MATERIAL_GROUP, MATERIAL_TYPE, PART_DESC
	)
	select distinct MFG_SITE, MATERIAL, MANUFACTURE_NUMBER, MANUFACTURE_PART, MATERIAL_GROUP, MATERIAL_TYPE, DESCRIPTION
	from VIEW_EGI0010_MATL_MASTER
	where MFG_SITE = inCompany;
	commit;

	-------------------------------------------------------------------------------------------------
	-- 每週計算CM處理P/R withount info record之筆數與平均處理天數
	--   030大類且描述含 C/S 的需剔除 (燒錄 IC owner是site buyer)
	-------------------------------------------------------------------------------------------------
	iTracePoint := '600';
	delete from PLD_KPI_AUDIT_ZD468_PR_CLOSE where COMPANY_CODE = inCompany AND CLOSED_DATE = to_char(sysdate - 1,'yyyymmdd');
	commit;
	iTracePoint := '610';
	update PLD_KPI_AUDIT_ZD468_PR_OPEN set CLOSED_DATE = '00000000' where COMPANY_CODE = inCompany AND CLOSED_DATE = to_char(sysdate - 1,'yyyymmdd');
	commit;
	--(630) add to PLD_KPI_AUDIT_ZD468_PR_CLOSE
	iTracePoint := '630';
	for rec3 in (
		select distinct a.COMPANY_CODE, a.DOC_NO, a.DOC_ITEM, a.DOC_CREATE, a.PART_NO, a.PART_DESC, a.SOURCER_ID, a.SOURCER_NAME, a.SP_DEP,
			to_char(sysdate - 1,'yyyymmdd') as CLOSED_DATE, (to_date(to_char(sysdate - 1,'yyyymmdd'),'yyyymmdd') - to_date(a.DOC_CREATE,'yyyymmdd')) as DIFF_DAY
		from PLD_KPI_AUDIT_ZD468_PR_OPEN a
		where a.COMPANY_CODE = inCompany and a.CLOSED_DATE = '00000000'
		and not exists (
			select b.COMPANY_CODE from PLD_KPI_AUDIT_ZD468 b
			where b.COMPANY_CODE = a.COMPANY_CODE and b.CREATE_DATE = to_char(sysdate,'yyyymmdd') and b.REC_OWNER = 'SP'
			and b.REC_TYPE2 = '2.PR without InfoReocrd' and b.DOC_NO = a.DOC_NO	and b.DOC_ITEM = a.DOC_ITEM
		)
	) loop
		-- 計算處理天數 (找出星期六日有幾天並扣除之)
		nDIFF_DAY := 0;
		select count(*) into nDIFF_DAY from DIMENSION_DATE
		where DATE_KEY >= rec3.DOC_CREATE and DATE_KEY <= rec3.CLOSED_DATE and DAY_OF_WK in ('6','0');
		if nDIFF_DAY >= rec3.DIFF_DAY then
			nDIFF_DAY := 0;
		else
			nDIFF_DAY := rec3.DIFF_DAY - nDIFF_DAY;
		end if;
		--
		iTracePoint := '633';
		insert into PLD_KPI_AUDIT_ZD468_PR_CLOSE (
			COMPANY_CODE, DOC_NO, DOC_ITEM, DOC_CREATE, PART_NO, PART_DESC, SOURCER_ID, SOURCER_NAME, SP_DEP, CLOSED_DATE, DIFF_DAY
		) values (
			rec3.COMPANY_CODE, rec3.DOC_NO, rec3.DOC_ITEM, rec3.DOC_CREATE, rec3.PART_NO, rec3.PART_DESC,
			rec3.SOURCER_ID, rec3.SOURCER_NAME, rec3.SP_DEP, rec3.CLOSED_DATE, nDIFF_DAY
		);
		--
		iTracePoint := '636';
		update PLD_KPI_AUDIT_ZD468_PR_OPEN set CLOSED_DATE = rec3.CLOSED_DATE
		where COMPANY_CODE = rec3.COMPANY_CODE and DOC_NO = rec3.DOC_NO and DOC_ITEM = rec3.DOC_ITEM;
		--
		iTracePoint := '639';
		commit;
	end loop;

	-- 處理舊的 PLD_KPI_AUDIT_ZD468_PR_OPEN (1) 已存在 / 或是 re-open
	iTracePoint := '700';
	for rec4 in (
		select distinct a.COMPANY_CODE, a.DOC_NO, a.DOC_ITEM, b.DOC_CREATE, b.PART_NO, b.PART_DESC, b.SOURCER_ID, b.SOURCER_NAME, b.SP_DEP
		from PLD_KPI_AUDIT_ZD468_PR_OPEN a, PLD_KPI_AUDIT_ZD468 b
		where a.COMPANY_CODE = inCompany
		and b.COMPANY_CODE = a.COMPANY_CODE and b.DOC_NO = a.DOC_NO and b.DOC_ITEM = a.DOC_ITEM
		and b.CREATE_DATE = to_char(sysdate,'yyyymmdd') and b.REC_OWNER = 'SP' and b.REC_TYPE2 = '2.PR without InfoReocrd'
	) loop
		--
		iTracePoint := '703';
		update PLD_KPI_AUDIT_ZD468_PR_OPEN set
			DOC_CREATE = rec4.DOC_CREATE, PART_NO = rec4.PART_NO, PART_DESC = rec4.PART_DESC,
			SOURCER_ID = rec4.SOURCER_ID, SOURCER_NAME = rec4.SOURCER_NAME, SP_DEP = rec4.SP_DEP, CLOSED_DATE = '00000000'
		where COMPANY_CODE = rec4.COMPANY_CODE and DOC_NO = rec4.DOC_NO and DOC_ITEM = rec4.DOC_ITEM;
		-- 可能是 reopen, 故要從 PLD_KPI_AUDIT_ZD468_PR_CLOSE 拿掉
		iTracePoint := '706';
		delete from PLD_KPI_AUDIT_ZD468_PR_CLOSE where COMPANY_CODE = rec4.COMPANY_CODE and DOC_NO = rec4.DOC_NO and rec4.DOC_ITEM = DOC_ITEM;
		--
		iTracePoint := '709';
		commit;
	end loop;
	-- 處理舊的 PLD_KPI_AUDIT_ZD468_PR_OPEN (2) 新增
	iTracePoint := '750';
	insert into PLD_KPI_AUDIT_ZD468_PR_OPEN (
		COMPANY_CODE, DOC_NO, DOC_ITEM, DOC_CREATE, PART_NO, PART_DESC, SOURCER_ID, SOURCER_NAME, SP_DEP, CLOSED_DATE )
	select distinct b.COMPANY_CODE, b.DOC_NO, b.DOC_ITEM, b.DOC_CREATE, b.PART_NO, b.PART_DESC, b.SOURCER_ID, b.SOURCER_NAME, b.SP_DEP, '00000000'
	from PLD_KPI_AUDIT_ZD468 b
	where b.COMPANY_CODE = inCompany and b.CREATE_DATE = to_char(sysdate,'yyyymmdd')
	and b.REC_OWNER = 'SP' and b.REC_TYPE2 = '2.PR without InfoReocrd'
	and b.DOC_CREATE >= '20080701' and b.DOC_CREATE < to_char(sysdate,'yyyymmdd')
	and ( (b.PART_GROUP not like '030%') OR (b.PART_GROUP like '030%' and b.PART_DESC not like '%C/S%') )
	and b.PART_NO not like '%-C' and b.PART_NO not like '%-60' and b.PART_NO not like '67-%' and b.PART_NO not like '69-%'
	and not exists ( select c.PART_NO from SAP_MATERIAL_PLANT c where c.COMPANY_CODE = b.COMPANY_CODE and c.PART_NO = b.PART_NO and c.PLANT = b.PLANT and c.SPEC_PROCUREMENT = '10' )
	and not exists ( select a.COMPANY_CODE from PLD_KPI_AUDIT_ZD468_PR_OPEN a where a.COMPANY_CODE = b.COMPANY_CODE and a.DOC_NO = b.DOC_NO and a.DOC_ITEM = b.DOC_ITEM );
	commit;

	-- end
	iTracePoint := '999';
EXCEPTION
	WHEN OTHERS THEN
		cErrorText := SQLERRM();
		MAIL_FILE_BIDBDBADMIN(in_to_name=>'shuchin_lin@usiglobal.com',subject   => '[PLD KPI]PL/SQL PLSQL_PLD_KPI_AUDIT_ZD468_ITAB ERROR - Company: ' || inCompany, message => '[PLSQL_PLD_KPI_AUDIT_ZD468_T], The tracepoint is  ' || iTracePoint || ' and ErrorText=' || cErrorText) ;
END PLSQL_PLD_KPI_AUDIT_ZD468_T;
/

