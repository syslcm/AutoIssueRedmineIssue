create PROCEDURE "VQA_PLSQL_PN_DATA"
AUTHID DEFINER
IS
/*--------------------------------------------------------------*
 * ProgNo : SP1820
 *--------------------------------------------------------------
 * Modification Date : 2018/04/18 V1.1.2     
 * Programmer        : Andy Chan   
 * Application form# : Re: 修改SP: POWEB.VQA_PLSQL_PN_DATA [GOA#SAI082351]    
 * Reasons           : 為避免 Table Check 異常，用 Update 的方式來同步PDM Data，取代目前的 Delete all & Insert.
 *--------------------------------------------------------------
 * CREATE DATE:  2008/2/257
 * PLSQL      :  VQA_PLSQL_PN_DATA
 * Author     :  Shuya
 * Purpase    :  每天執行
*---------------------------------------------------------------*/
VVENDOR_CODE       VQA_010_IRR_WEEKLY.VENDOR_CODE%TYPE;
VCOMPANY_CODE      VQA_010_IRR_WEEKLY.COMPANY_CODE%TYPE;
VPROCEE_YYYYMMDD   VARCHAR2 (8);
VPROCEE_YYYYMM     VARCHAR2 (6);
ITRACEPOINT        VARCHAR2 (100);
CERRORTEXT         VARCHAR2 (500);
CHECK_COUNT        NUMBER(1) := 0;
BEGIN
   ITRACEPOINT := 0;

   FOR REC1 IN (SELECT   A.ITEM_NUMBER PN, MP.PART_NUMBER MFRPN, MA.NAME MFR,
                         (SELECT PT.VALUE
                            FROM AGILE.PROPERTYTABLE@PDM PT
                           WHERE PT.PARENTID = MP.STATUS
                             AND PT.PROPERTYID = 38) PHASE,
                         MB.TEXT01 SEQUENCE, A.MAT_GRP, A.CATEGORY
                    FROM (SELECT I.ID, I.ITEM_NUMBER,
                                 (SELECT ENTRYVALUE
                                    FROM AGILE.LISTENTRY@PDM
                                   WHERE ENTRYID = P2.LIST16) MAT_GRP,
                                 (SELECT ENTRYVALUE
                                    FROM AGILE.LISTENTRY@PDM
                                   WHERE ENTRYID = P2.LIST24) CATEGORY
                            FROM AGILE.ITEM@PDM I, AGILE.PAGE_TWO@PDM P2
                           WHERE I.CLASS = '10000'
                             AND I.CATEGORY = '211226'
                             AND I.DEFAULT_CHANGE > 0
                             AND I.ID = P2.ID) A,
                         AGILE.MANU_BY@PDM MB,
                         AGILE.MANU_PARTS@PDM MP,
                         AGILE.MANUFACTURERS@PDM MA
                   WHERE MB.AGILE_PART = A.ID
                     AND MP.ID = MB.MANU_PART
                     AND MA.ID = MP.MANU_ID
                     AND MB.MANU_PART <> '0'
                     AND MB.CHANGE_OUT = '0'
                     AND MB.LIST02 IS NULL                      -- NOT BLOCKED
                ORDER BY PN, SEQUENCE, MFR)
   LOOP
     SELECT COUNT(*) INTO CHECK_COUNT FROM VQA_PDM_PN_DATA 
       WHERE USI_PN = REC1.PN
       AND MFR_PN = REC1.MFRPN
       AND MFR_NAME = REC1.MFR;
     
     IF CHECK_COUNT > 0 THEN
       UPDATE VQA_PDM_PN_DATA 
       SET PHASE = REC1.PHASE, 
         SEQUENCE = REC1.SEQUENCE, 
         MAT_GRP = REC1.MAT_GRP, 
         CATEGORY = REC1.CATEGORY
       WHERE USI_PN = REC1.PN
       AND MFR_PN = REC1.MFRPN
       AND MFR_NAME = REC1.MFR;
     ELSE
       INSERT INTO VQA_PDM_PN_DATA (USI_PN, MFR_PN, MFR_NAME, PHASE, SEQUENCE, MAT_GRP, CATEGORY)
       VALUES (REC1.PN, REC1.MFRPN, REC1.MFR, REC1.PHASE, REC1.SEQUENCE, REC1.MAT_GRP, REC1.CATEGORY); 
     END IF;

     ITRACEPOINT := ITRACEPOINT + 1;
     
     IF ITRACEPOINT MOD 500 = 0 THEN
       COMMIT;
     END IF;
   END LOOP;

   COMMIT;
   MAIL_FILE_BIDBDBADMIN
             (IN_TO_NAME      => 'andy_chan@usiglobal.com',
              SUBJECT         => '[VQA] PL/SQL VQA_PLSQL_PN_DATA SUCCEED',
              MESSAGE         =>    '[PL/SQL VQA_PLSQL_PN_DATA], THE TOTAL COUNT IS  '
                                 || TO_CHAR (ITRACEPOINT)
             );
EXCEPTION
   WHEN OTHERS
   THEN
      --有錯誤產生信寄MAIL
      CERRORTEXT := SQLERRM ();
      MAIL_FILE_BIDBDBADMIN
                 (IN_TO_NAME      => 'andy_chan@usiglobal.com',
                  SUBJECT         => '[VQA] PL/SQL VQA_PLSQL_PN_DATA ERROR',
                  MESSAGE         =>    '[PL/SQL VQA_020_IRR_MONTHLY ], THE TRACEPOINT IS  '
                                     || ITRACEPOINT
                                     || ' AND ERRORTEXT= '
                                     || CERRORTEXT
                 );
END VQA_PLSQL_PN_DATA;
/

