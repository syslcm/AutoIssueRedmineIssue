create PROCEDURE PNL_PLS002_CALU_DATA (
  inCompany  in VARCHAR2,
  f_YYYYMMDD in VARCHAR2,
  t_YYYYMMDD in VARCHAR2
)
AUTHID DEFINER
/*********************************************************************
  PROG-ID      : PNL_PLS002_CALU_DATA
  PROG-ACTION  : GET BUDGET's SUMMARY DATA FROM SQL SERVER TO BIDB
  Author       : KANGI
  Date         : 2007/03/27
**********************************************************************/
is
   cCURRENT_PERIOD KPI_SAP001_COPA_TRX.PERIOD%TYPE ;
   dBILLING_END_DATE_BY_MON RWF_SAP002_REVENUE_ACTUAL.BILLING_END_DATE_BY_MON%TYPE;
   iTracePoint  integer ;
   cErrorText varchar2(500) ;
   cPNL_YYYY PNL_MSS001_BGT_DATA.YEAR%TYPE;
   fUSD_TO_TWD_RATE float ;
   dRUNDATE DATE ;

 BEGIN
   iTracePoint := 100 ;
   cPNL_YYYY := TO_CHAR(SYSDATE,'YYYY');
   dRUNDATE := SYSDATE ;
   ---PROCESS BUDGET DATA TO PNL_TRX001_DATA(01-BGT)
   PNL_PLS002_CALU_DATA_SUB01('1100','20070101','20071231');


   ---PROCESS PNL_MSA001_EM_DATA  TO PNL_TRX001_DATA(02-ACT)
   PNL_PLS002_CALU_DATA_SUB02('1100','20070101','20071231');


   ---PNL_PLS002_CALU_DATA_SUB03
   ---PROG-ACTION  : (03-03M,04-06M,05-09M,06-12M)
   PNL_PLS002_CALU_DATA_SUB03('1100','20070101','20071231');


   iTracePoint := 400 ;
   COMMIT ;
 EXCEPTION
     WHEN OTHERS THEN
            --rollback ;
            cErrorText := SQLERRM() ;
            MAIL_FILE_BIDBDBADMIN(in_to_name=>'kangi@ms.usi.com.tw',subject   => 'PL/SQL PNL_PLS002_CALU_DATA ERROR', message => '[PNL_PLS002_CALU_DATA], The tracepoint is  ' || to_char(iTracePoint) || 'and ErrorText=' || cErrorText) ;
            DBMS_OUTPUT.PUT_LINE(SUBSTR(cErrorText,1,255));
            DBMS_OUTPUT.PUT_LINE(TO_CHAR(iTracePoint));
END PNL_PLS002_CALU_DATA;
/

