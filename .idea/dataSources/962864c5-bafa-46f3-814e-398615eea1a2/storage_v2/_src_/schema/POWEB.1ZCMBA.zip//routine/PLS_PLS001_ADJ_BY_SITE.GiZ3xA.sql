create PROCEDURE       PLS_PLS001_ADJ_BY_SITE (
  p_YYYYMMDD in VARCHAR2
)
AUTHID DEFINER
is
/*********************************************************************
  PROG-ID      : PLS_PLS001_ADJ_BY_SITE
  PROG-ACTION  : P＆L adjust by site
  Author       : Patty
  Date         : 2014/05/21
  OA No.       : SAI043515
  需求說明:
  A-1.作業1: 將單1 profit center 在單 1 Site 生產 --> 收入成本費用全歸於生產Site
  A-2.作業2: TSC (Profit center 28 ＆ 33) 收入成本及費用重新allocate
  A-3.作業3: Earning model 中, USI TW ＆ UG TW的銷、管、研費用,重新allocate
  A-4.作業4: 將單1 profit center 在多於2 site2生產產生的 NRE ＆ withholding收入成本分攤
      作業5: USI TW ＆ UG TW NPI工單的收入,成本及費用重新 allocate
      作業6. Site間相關收入,成本及費用相互調撥調整
    **作業A-4的P/C, 若出現在作業A-1中, 則挪開, 不做調整
**********************************************************************/
-- 2019/08/20 SAI104649 Patty Modify 'INSERT INTO PLS_PST001_EM':
--                      1.PNL_MSA001_EM_DATA Mapping to PNL_MAP007_ACCMAPPING
--                      2.Use PNL_MAP007_ACCMAPPING.ACCT_ID_NEW to replace
--                           PNL_MSA001_EM_DATA.ACCT_ID 
-- 2020/01/30 SAI110406 Pattty Modify:
--                      1.Delete Old Process Source
--                      2.Call Procedure PLS_PLS001_ADJ_BY_SITE_ALL ＆ PLS_PLS001_ADJ_BY_SITE_UG
/*---------------------------------------------------------------------------------------------------*/
  w_PERIOD           VARCHAR2(6);
  w_YYYY             VARCHAR2(4);
  w_MONTH            VARCHAR2(2);
  sPROC_NAME         PLS_PST000_LOG.PROC_NAME%TYPE;
  sRUN_SEQ           PLS_PST000_LOG.RUN_SEQ%TYPE;
  sRUN_DESC          PLS_PST000_LOG.RUN_DESC%TYPE;
  sPARAMETER_DESC    PLS_PST000_LOG.PARAMETER_DESC%TYPE;
  sAMOUNT            PLS_PST001_EM.AMOUNT%TYPE;

BEGIN
  w_PERIOD := SUBSTRB(p_YYYYMMDD,1,6);
  w_YYYY   := SUBSTRB(p_YYYYMMDD,1,4);
  w_MONTH  := SUBSTRB(p_YYYYMMDD,5,2);

  sPROC_NAME := 'PLS_PLS001_ADJ_BY_SITE';
  sRUN_SEQ   := '000010';
  sRUN_DESC  := 'Start';
  sPARAMETER_DESC := CONCAT('w_PERIOD=',w_PERIOD);

  --Insert Log
  INSERT INTO PLS_PST000_LOG
      ( PROC_NAME, RUN_SEQ, RUN_DESC, PARAMETER_DESC )
    VALUES
      ( sPROC_NAME, sRUN_SEQ, sRUN_DESC, sPARAMETER_DESC );
  Commit;


-- << SAI110406 Begin --

  --Exec Store Procedure
  PLS_PLS001_ADJ_BY_SITE_ALL(w_PERIOD);
  PLS_PLS001_ADJ_BY_SITE_UG(w_PERIOD);

-- -- SAI110406 End -->>

  ---------------------------------------------------------------------------------------
  sPROC_NAME := 'PLS_PLS001_ADJ_BY_SITE';
  sRUN_SEQ   := '000020';
  sRUN_DESC  := 'End';

  --Insert Log
  INSERT INTO PLS_PST000_LOG
      ( PROC_NAME, RUN_SEQ, RUN_DESC, PARAMETER_DESC )
    VALUES
      ( sPROC_NAME, sRUN_SEQ, sRUN_DESC, sPARAMETER_DESC );
  Commit;


END PLS_PLS001_ADJ_BY_SITE;
/

