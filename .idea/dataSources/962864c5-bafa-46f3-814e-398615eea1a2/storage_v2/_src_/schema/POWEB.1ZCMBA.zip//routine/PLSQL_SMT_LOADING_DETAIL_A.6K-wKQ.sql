create PROCEDURE PLSQL_SMT_LOADING_DETAIL_A(
  inCompany  in SMT_LOADING_DETAIL_T.COMPANY_CODE%TYPE,
  f_YYYYMMDD in VARCHAR2,
  t_YYYYMMDD in VARCHAR2
)
is
 iTracePoint  integer ;
 cErrorText varchar2(500);

BEGIN
  iTracePoint := '000';


  DELETE FROM SMT_LOADING_DETAIL WHERE COMPANY_CODE = inCompany AND D_TYPE = 'Actual' AND (SFLAG IS NULL OR SFLAG = '')
     and YYYYWW IN (SELECT YYYYWW FROM SMT_LOADING_DETAIL_T WHERE COMPANY_CODE = inCompany AND D_TYPE = 'Actual' AND (SFLAG IS NULL OR SFLAG = ''));
     
  DELETE FROM SMT_LOADING_DETAIL WHERE COMPANY_CODE = inCompany AND D_TYPE = 'Actual' AND SFLAG = 'X'
     and YYYYWW IN (SELECT YYYYWW FROM SMT_LOADING_DETAIL_T WHERE COMPANY_CODE = inCompany AND D_TYPE = 'Actual' AND SFLAG = 'X');     

  iTracePoint := '100';
  Insert into SMT_LOADING_DETAIL (
        COMPANY_CODE , PD , DEPARTMENT , D_TYPE , IN_SUB , ITEMS , WORK_CENTER , MATERIAL , ORDER_NUMBER , BAS_DATE , ACT_DATE , TAR_QTY , U_HOUR , T_HOUR , BU , MAC , PLANT , YYYYWW   )
   Select  COMPANY_CODE , PD , DEPARTMENT , D_TYPE , IN_SUB , ITEMS , WORK_CENTER , MATERIAL , ORDER_NUMBER , BAS_DATE , ACT_DATE , TAR_QTY , U_HOUR , T_HOUR , BU , MAC , PLANT , YYYYWW
     from SMT_LOADING_DETAIL_T
    where COMPANY_CODE= inCompany AND D_TYPE = 'Actual';

   iTracePoint := '200';
   DELETE  from SMT_LOADING_DETAIL_T
    where COMPANY_CODE = inCompany AND D_TYPE = 'Actual';



   Commit;
EXCEPTION
   When OTHERS Then
    --有錯誤產生則寄mail
    cErrorText := SQLERRM();
    MAIL_FILE_BIDBDBADMIN(in_to_name => 'sam_chen@ms.usi.com.tw', subject => '[VRT] PL/SQL SMT_LOADING_DETAIL Actual ERROR', message => '[SMT_LOADING_DETAIL Actual], The tracepoint is  ' || iTracePoint || ' and ErrorText= ' || cErrorText) ;


END PLSQL_SMT_LOADING_DETAIL_A;

/

