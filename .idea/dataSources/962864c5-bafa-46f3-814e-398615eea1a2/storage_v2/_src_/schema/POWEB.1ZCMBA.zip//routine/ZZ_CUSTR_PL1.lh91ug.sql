create PROCEDURE ZZ_CUSTR_PL1
 AUTHID DEFINER
is

BEGIN
   FOR REC1 in (
    Select distinct * from KPI_ZOTTMP_2006_MG
   ) Loop
      ----
      Update KPI_SAP001_COPA_TRX
         Set MTL_GROUP = REC1.MTL_GROUP_NEW
       Where SUBSTR(PERIOD,1,4) = '2011'
         and MTL_GROUP_OLD = REC1.MTL_GROUP
         and PART_NO = REC1.PART_NO;
      Commit;
      ----
      Update KPI_SAP002_PCA_TRX
         Set MTL_GROUP = REC1.MTL_GROUP_NEW
       Where SUBSTR(PERIOD,1,4) = '2011'
         and MTL_GROUP_OLD = REC1.MTL_GROUP
         and PART_NO = REC1.PART_NO;
      Commit;
      ----
      Update KPI_SAP011_REVENUE_SUM
         Set MTL_GROUP = REC1.MTL_GROUP_NEW
       Where SUBSTR(PERIOD,1,4) = '2011'
         and MTL_GROUP_OLD = REC1.MTL_GROUP
         and PART_NO = REC1.PART_NO;
      Commit;
      ----
      Update KPI_SAP018_COGS_DATA
         Set MTL_GROUP = REC1.MTL_GROUP_NEW
       Where SUBSTR(PERIOD,1,4) = '2011'
         and MTL_GROUP_OLD = REC1.MTL_GROUP
         and PART_NO = REC1.PART_NO;
      ----
      Commit;
   END LOOP;

   --------------------------------------------------

   FOR REC1 in (
    Select distinct * from KPI_ZOTTMP_2006_PC
   ) Loop
      ----
      Update KPI_SAP001_COPA_TRX
         Set PROFIT_CENTER = REC1.PROFIT_CENTER_NEW
       Where SUBSTR(PERIOD,1,4) = '2011'
         and PROFIT_CENTER_OLD = REC1.PROFIT_CENTER
         and PART_NO = REC1.PART_NO;
      Commit;
      ----
      Update KPI_SAP002_PCA_TRX
         Set PROFIT_CENTER = REC1.PROFIT_CENTER_NEW
       Where SUBSTR(PERIOD,1,4) = '2011'
         and PROFIT_CENTER_OLD = REC1.PROFIT_CENTER
         and PART_NO = REC1.PART_NO;
      Commit;
      ----
      Update KPI_SAP011_REVENUE_SUM
         Set PROFIT_CENTER = REC1.PROFIT_CENTER_NEW
       Where SUBSTR(PERIOD,1,4) = '2011'
         and PROFIT_CENTER_OLD = REC1.PROFIT_CENTER
         and PART_NO = REC1.PART_NO;
      Commit;
      ----
      Update KPI_SAP018_COGS_DATA
         Set PROFIT_CENTER = REC1.PROFIT_CENTER_NEW
       Where SUBSTR(PERIOD,1,4) = '2011'
         and PROFIT_CENTER_OLD = REC1.PROFIT_CENTER
         and PART_NO = REC1.PART_NO;
      ----
      Commit;
   END LOOP;

END ZZ_CUSTR_PL1;
/

