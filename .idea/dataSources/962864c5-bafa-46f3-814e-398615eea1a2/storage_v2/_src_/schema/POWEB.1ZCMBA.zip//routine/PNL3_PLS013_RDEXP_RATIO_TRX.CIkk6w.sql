create PROCEDURE       pnl3_pls013_RDexp_ratio_trx (
   --inCompany  in VARCHAR2,
   inperiod   IN   VARCHAR2
--本程式是FOR PROJECT使用,而費用中的SALES和ADM則用營收的REVENUE比率分攤
--而RD費用分攤則先用CON_SAP001_TRX分完後的金額再由project的營收金額來分攤
--2009/10/22  Catergory3 / Category4 不納入比率運算,
--
)
AUTHID DEFINER
IS
     CURSOR C_PNL2_REVENUE is
     SELECT COMPANY_CODE,PROFIT_CENTER,SUM(AMT_TWD) AMT_TWD
     FROM  PNL3_TRX005_COLLECT_PN
     WHERE PERIOD = inPeriod 
     AND AREA1 = '1'
     AND AREA2 = '1'
     AND AREA3 = '0'
     --AND SOURCE <> 'UPL001'
     GROUP BY COMPANY_CODE,PROFIT_CENTER;
     
   a_amount PNL3_TRX005_COLLECT_PN.AMT_TWD%TYPE;
   a_rate   pnl3_map001_customer_rate.rate%TYPE;
   a_hc     pnl2_upl006_headcount.headcount%TYPE;
BEGIN

   --以下開始為從RD工時算出分攤比

   DELETE FROM PNL3_MAP009_RDEXP_RATIO
         WHERE period = inperiod;

   COMMIT;


   --Get Rate(Exclude RD)
   FOR rec1 IN (SELECT   B.company_code, profit_center,
                         SUM (project_work_hours) AS WH
                    FROM con_sap004_project_id a, con_sap002_project_wh_trx b
                   WHERE A.project_id = B.project_id
                     AND period = inperiod 
                     AND  A.PROJECT_CATEGORY IN ('Category1','Category2')
                  HAVING SUM (project_work_hours) <> 0
                GROUP BY B.company_code, profit_center)
   LOOP
      FOR rec2 IN (SELECT   B.company_code, profit_center, project_name,
                            SUM (project_work_hours) AS WH
                       FROM  con_sap004_project_id a, con_sap002_project_wh_trx b
                      WHERE A.project_id = B.project_id
                        AND period = inperiod
                        and profit_center  = rec1.profit_center
                        and B.company_code = rec1.company_code
                        AND A.PROJECT_CATEGORY IN ('Category1','Category2')
                     --AND SOURCE <> 'UPL001'
                   HAVING   SUM (project_work_hours) <> 0
                   GROUP BY B.company_code, profit_center, project_name
                   ORDER BY WH DESC)
      LOOP
         --2008/12/4 因UPLOAD的資料未上,所以只有COGS沒有Reverue,因此要加入判斷REC1.AMT_TWD <> 0,否則會有問題,待user 上傳後即無問題
         IF rec1.WH = 0
         THEN
            a_rate := 0;
         ELSE
            a_rate := rec2.WH / rec1.WH;
         END IF;

         INSERT INTO PNL3_MAP009_RDEXP_RATIO
                     (period, profit_center, company_code,
                      project_name, r_kind, area1, area2, area3, rate,
                      change_date
                     )
              VALUES (inperiod, rec1.profit_center, rec2.company_code,
                      rec2.project_name, 'PL02', '4', '3', '1', a_rate,
                      SYSDATE
                     );

         COMMIT;

         INSERT INTO PNL3_MAP009_RDEXP_RATIO
                     (period, profit_center, company_code,
                      project_name, r_kind, area1, area2, area3, rate,
                      change_date
                     )
              VALUES (inperiod, rec1.profit_center, rec2.company_code,
                      rec2.project_name, 'PL02', '4', '3', '2', a_rate,
                      SYSDATE
                     );

         COMMIT;
         INSERT INTO PNL3_MAP009_RDEXP_RATIO

                     (period, profit_center, company_code,
                      project_name, r_kind, area1, area2, area3, rate,
                      change_date
                     )
              VALUES (inperiod, rec1.profit_center, rec2.company_code,
                      rec2.project_name, 'PL02', '4', '3', '3', a_rate,
                      SYSDATE
                     );

         COMMIT;

         INSERT INTO PNL3_MAP009_RDEXP_RATIO
                     (period, profit_center, company_code,
                      project_name, r_kind, area1, area2, area3, rate,
                      change_date
                     )
              VALUES (inperiod, rec1.profit_center, rec2.company_code,
                      rec2.project_name, 'PL02', '4', '3', '4', a_rate,
                      SYSDATE
                     );

         COMMIT;


      END LOOP;
   END LOOP;



   ----> 以PROFIT CENTER來看 Project WorkingHours比率 邏輯開始 ----->
   DELETE FROM PNL3_MAP009_RDEXP_PC_RATIO
         WHERE period = inperiod;

   COMMIT;

   FOR rec1 IN (SELECT   profit_center, SUM (project_work_hours) AS WH
                    FROM con_sap004_project_id a, con_sap002_project_wh_trx b
                   WHERE A.project_id = B.project_id
                     AND period = inperiod 
                     AND  A.PROJECT_CATEGORY IN ('Category1','Category2') 
                  HAVING SUM (project_work_hours) <> 0
                GROUP BY profit_center)
   LOOP
         FOR rec2 IN (SELECT  project_name,
                            SUM (project_work_hours) AS WH
                       FROM  con_sap004_project_id a, con_sap002_project_wh_trx b
                      WHERE A.project_id = B.project_id
                        AND period = inperiod
                        AND profit_center = rec1.profit_center
                        AND  A.PROJECT_CATEGORY IN ('Category1','Category2')
                   HAVING   SUM (project_work_hours) <> 0
                   GROUP BY  project_name
                   ORDER BY WH DESC)

      LOOP
         IF rec2.WH = 0
         THEN
            a_rate := 0;
         ELSE
            a_rate := rec2.WH / rec1.WH;
         END IF;

         INSERT INTO PNL3_MAP009_RDEXP_PC_RATIO
                     (period, profit_center, project_name,
                      r_kind, area1, area2, area3, rate, change_date
                     )
              VALUES (inperiod, rec1.profit_center, rec2.project_name,
                      'PL02', '4', '3', '1', a_rate, SYSDATE
                     );

         COMMIT;

         INSERT INTO PNL3_MAP009_RDEXP_PC_RATIO
                     (period, profit_center, project_name,
                      r_kind, area1, area2, area3, rate, change_date
                     )
              VALUES (inperiod, rec1.profit_center, rec2.project_name,
                      'PL02', '4', '3', '2', a_rate, SYSDATE
                     );

         COMMIT;

         INSERT INTO PNL3_MAP009_RDEXP_PC_RATIO
                     (period, profit_center, project_name,
                      r_kind, area1, area2, area3, rate, change_date
                     )
              VALUES (inperiod, rec1.profit_center, rec2.project_name,
                      'PL02', '4', '3', '3', a_rate, SYSDATE
                     );

         COMMIT;

         INSERT INTO PNL3_MAP009_RDEXP_PC_RATIO
                     (period, profit_center, project_name,
                      r_kind, area1, area2, area3, rate, change_date
                     )
              VALUES (inperiod, rec1.profit_center, rec2.project_name,
                      'PL02', '4', '3', '4', a_rate, SYSDATE
                     );

         COMMIT;

 
      END LOOP;
   END LOOP;


   ----> 以PROFIT CENTER來看 Project WorkingHours比率 邏輯結束<-------------

   ----> 全公司的 Project WorkingHours比率(不看SITE和PROFIT CENTER) 開始
   DELETE FROM PNL3_MAP009_RDEXP_WW_RATIO
         WHERE period = inperiod;

   COMMIT;
   a_hc := 0;

   BEGIN
      SELECT SUM (project_work_hours)
        INTO a_hc
        FROM con_sap002_project_wh_trx
        
       WHERE period = inperiod;
   EXCEPTION
      WHEN OTHERS
      THEN
         a_hc := 0;
   END;

   IF a_hc <> 0
   THEN
         FOR rec1 IN (SELECT    project_name, SUM (project_work_hours) AS WH
                       FROM  con_sap004_project_id a, con_sap002_project_wh_trx b
                      WHERE A.project_id = B.project_id 
                        AND period = inperiod
                        AND ( A.PROJECT_CATEGORY IN ('Category1','Category2') OR A.PROJECT_CATEGORY IS NULL )
                   HAVING   SUM (project_work_hours) <> 0
                   GROUP BY  project_name
                   ORDER BY WH DESC)

      LOOP
         a_rate := rec1.WH / a_hc;

         INSERT INTO PNL3_MAP009_RDEXP_WW_RATIO
                     (period, project_name, r_kind, area1, area2, area3,
                      rate, change_date
                     )
              VALUES (inperiod, rec1.project_name, 'PL02', '4', '3', '1',
                      a_rate, SYSDATE
                     );

         COMMIT;

         INSERT INTO PNL3_MAP009_RDEXP_WW_RATIO
                     (period, project_name, r_kind, area1, area2, area3,
                      rate, change_date
                     )
              VALUES (inperiod, rec1.project_name, 'PL02', '4', '3', '2',
                      a_rate, SYSDATE
                     );

         COMMIT;

         INSERT INTO PNL3_MAP009_RDEXP_WW_RATIO
                     (period, project_name, r_kind, area1, area2, area3,
                      rate, change_date
                     )
              VALUES (inperiod, rec1.project_name, 'PL02', '4', '3', '3',
                      a_rate, SYSDATE
                     );

         COMMIT;

         INSERT INTO PNL3_MAP009_RDEXP_WW_RATIO
                     (period, project_name, r_kind, area1, area2, area3,
                      rate, change_date
                     )
              VALUES (inperiod, rec1.project_name, 'PL02', '4', '3', '4',
                      a_rate, SYSDATE
                     );

         COMMIT;


      END LOOP;


   END IF;
----> 全公司的 Project WorkingHours比率(不看SITE和PROFIT CENTER) 邏輯結束 <----

--從RD工時算出分攤比運算結束

--以下開始計算以Revenue來分的Project 比率
   DELETE FROM PNL3_MAP010_PROJECTEXP_RATIO WHERE PERIOD = inPeriod;
   COMMIT;
   DELETE FROM PNL3_MAP010_PROJECTEXP_PCRATIO WHERE PERIOD = inPeriod;
   COMMIT;
   DELETE FROM PNL3_MAP010_PROJECTEXP_WWRATIO WHERE PERIOD = inPeriod;
   COMMIT;
   
    FOR REC1 in C_PNL2_REVENUE Loop
        FOR REC2 in (SELECT COMPANY_CODE,PROJECT_NAME,SUM(AMT_TWD) AMT_TWD FROM PNL3_TRX005_COLLECT_PN 
                      WHERE PROFIT_CENTER = REC1.PROFIT_CENTER
                        AND PERIOD = inPeriod
                        AND COMPANY_CODE = REC1.COMPANY_CODE
                        AND AREA1 = '1'
                        AND AREA2 = '1'
                        AND AREA3 = '0'
                        AND AMT_TWD <> 0
                        --AND SOURCE <> 'UPL001'
                        GROUP BY COMPANY_CODE,PROJECT_NAME ORDER BY AMT_TWD DESC) Loop
            --2008/12/4 因UPLOAD的資料未上,所以只有COGS沒有Reverue,因此要加入判斷REC1.AMT_TWD <> 0,否則會有問題,待user 上傳後即無問題
            if REC1.AMT_TWD = 0 THEN
              a_Rate := 0;
            ELSE            
              a_Rate :=  REC2.AMT_TWD / REC1.AMT_TWD;
            END IF;   
               

            INSERT INTO PNL3_MAP010_PROJECTEXP_RATIO
                  (PERIOD   ,PROFIT_CENTER   ,COMPANY_CODE   ,PROJECT_NAME ,
                   R_KIND   ,AREA1           ,AREA2          ,AREA3           ,
                   RATE     ,CHANGE_DATE
                  )
                  VALUES (
                   inPeriod ,REC1.PROFIT_CENTER , REC2.COMPANY_CODE,REC2.PROJECT_NAME,
                   'PL02'   ,'4'                 , '1'              ,'1'                  ,
                   a_Rate   ,sysdate
                  );
            COMMIT;      
            INSERT INTO PNL3_MAP010_PROJECTEXP_RATIO
                  (PERIOD   ,PROFIT_CENTER   ,COMPANY_CODE   ,PROJECT_NAME ,
                   R_KIND   ,AREA1           ,AREA2          ,AREA3           ,
                   RATE     ,CHANGE_DATE
                  )
                  VALUES (
                   inPeriod ,REC1.PROFIT_CENTER , REC2.COMPANY_CODE,REC2.PROJECT_NAME,
                   'PL02'   ,'4'                 , '1'             , '2'                  ,
                   a_Rate   ,sysdate
                  );
            COMMIT;      
            INSERT INTO PNL3_MAP010_PROJECTEXP_RATIO
                  (PERIOD   ,PROFIT_CENTER   ,COMPANY_CODE   ,PROJECT_NAME ,
                   R_KIND   ,AREA1           ,AREA2          ,AREA3           ,
                   RATE     ,CHANGE_DATE
                  )
                  VALUES (
                   inPeriod ,REC1.PROFIT_CENTER , REC2.COMPANY_CODE,REC2.PROJECT_NAME,
                   'PL02'   ,'4'                 , '1'             , '3'                  ,
                   a_Rate   ,sysdate
                  );
            COMMIT;      
            INSERT INTO PNL3_MAP010_PROJECTEXP_RATIO
                  (PERIOD   ,PROFIT_CENTER   ,COMPANY_CODE   ,PROJECT_NAME ,
                   R_KIND   ,AREA1           ,AREA2          ,AREA3           ,
                   RATE     ,CHANGE_DATE
                  )
                  VALUES (
                   inPeriod ,REC1.PROFIT_CENTER , REC2.COMPANY_CODE,REC2.PROJECT_NAME,
                   'PL02'   ,'4'                 , '1'              ,'4'                  ,
                   a_Rate   ,sysdate
                  );  
            COMMIT;      
            INSERT INTO PNL3_MAP010_PROJECTEXP_RATIO
                  (PERIOD   ,PROFIT_CENTER   ,COMPANY_CODE   ,PROJECT_NAME ,
                   R_KIND   ,AREA1           ,AREA2          ,AREA3           ,
                   RATE     ,CHANGE_DATE
                  )
                  VALUES (
                   inPeriod ,REC1.PROFIT_CENTER , REC2.COMPANY_CODE,REC2.PROJECT_NAME,
                   'PL02'   ,'4'                 , '1'             , '5'                  ,
                   a_Rate   ,sysdate
                  );
            COMMIT;      
            INSERT INTO PNL3_MAP010_PROJECTEXP_RATIO
                  (PERIOD   ,PROFIT_CENTER   ,COMPANY_CODE   ,PROJECT_NAME ,
                   R_KIND   ,AREA1           ,AREA2          ,AREA3           ,
                   RATE     ,CHANGE_DATE
                  )
                  VALUES (
                   inPeriod ,REC1.PROFIT_CENTER , REC2.COMPANY_CODE,REC2.PROJECT_NAME,
                   'PL02'   ,'4'                 , '1'              ,'6'                  ,
                   a_Rate   ,sysdate
                  );    
            COMMIT;      
            INSERT INTO PNL3_MAP010_PROJECTEXP_RATIO
                  (PERIOD   ,PROFIT_CENTER   ,COMPANY_CODE   ,PROJECT_NAME ,
                   R_KIND   ,AREA1           ,AREA2          ,AREA3           ,
                   RATE     ,CHANGE_DATE
                  )
                  VALUES (
                   inPeriod ,REC1.PROFIT_CENTER , REC2.COMPANY_CODE,REC2.PROJECT_NAME,
                   'PL02'   ,'4'                 , '1'             , '7'                  ,
                   a_Rate   ,sysdate
                  );  
            COMMIT;      
            INSERT INTO PNL3_MAP010_PROJECTEXP_RATIO
                  (PERIOD   ,PROFIT_CENTER   ,COMPANY_CODE   ,PROJECT_NAME ,
                   R_KIND   ,AREA1           ,AREA2          ,AREA3           ,
                   RATE     ,CHANGE_DATE
                  )
                  VALUES (
                   inPeriod ,REC1.PROFIT_CENTER , REC2.COMPANY_CODE,REC2.PROJECT_NAME,
                   'PL02'   ,'4'                 , '2'              ,'1'                  ,
                   a_Rate   ,sysdate
                  );
            COMMIT;      
            INSERT INTO PNL3_MAP010_PROJECTEXP_RATIO
                  (PERIOD   ,PROFIT_CENTER   ,COMPANY_CODE   ,PROJECT_NAME ,
                   R_KIND   ,AREA1           ,AREA2          ,AREA3           ,
                   RATE     ,CHANGE_DATE
                  )
                  VALUES (
                   inPeriod ,REC1.PROFIT_CENTER , REC2.COMPANY_CODE,REC2.PROJECT_NAME,
                   'PL02'   ,'4'                 , '2'             , '2'                  ,
                   a_Rate   ,sysdate
                  );
            COMMIT;      
            INSERT INTO PNL3_MAP010_PROJECTEXP_RATIO
                  (PERIOD   ,PROFIT_CENTER   ,COMPANY_CODE   ,PROJECT_NAME ,
                   R_KIND   ,AREA1           ,AREA2          ,AREA3           ,
                   RATE     ,CHANGE_DATE
                  )
                  VALUES (
                   inPeriod ,REC1.PROFIT_CENTER , REC2.COMPANY_CODE,REC2.PROJECT_NAME,
                   'PL02'   ,'4'                 , '2'              ,'3'                  ,
                   a_Rate   ,sysdate
                  );
            COMMIT;      
            INSERT INTO PNL3_MAP010_PROJECTEXP_RATIO
                  (PERIOD   ,PROFIT_CENTER   ,COMPANY_CODE   ,PROJECT_NAME ,
                   R_KIND   ,AREA1           ,AREA2          ,AREA3           ,
                   RATE     ,CHANGE_DATE
                  )
                  VALUES (
                   inPeriod ,REC1.PROFIT_CENTER , REC2.COMPANY_CODE,REC2.PROJECT_NAME,
                   'PL02'   ,'4'                 , '2'             , '4'                  ,
                   a_Rate   ,sysdate
                  ); 
            COMMIT; 
            INSERT INTO PNL3_MAP010_PROJECTEXP_RATIO
                  (PERIOD   ,PROFIT_CENTER   ,COMPANY_CODE   ,PROJECT_NAME ,
                   R_KIND   ,AREA1           ,AREA2          ,AREA3           ,
                   RATE     ,CHANGE_DATE
                  )
                  VALUES (
                   inPeriod ,REC1.PROFIT_CENTER , REC2.COMPANY_CODE,REC2.PROJECT_NAME,
                   'PL02'   ,'4'                 , '3'              ,'1'                  ,
                   a_Rate   ,sysdate
                  );
            COMMIT;      
            INSERT INTO PNL3_MAP010_PROJECTEXP_RATIO
                  (PERIOD   ,PROFIT_CENTER   ,COMPANY_CODE   ,PROJECT_NAME ,
                   R_KIND   ,AREA1           ,AREA2          ,AREA3           ,
                   RATE     ,CHANGE_DATE
                  )
                  VALUES (
                   inPeriod ,REC1.PROFIT_CENTER , REC2.COMPANY_CODE,REC2.PROJECT_NAME,
                   'PL02'   ,'4'                 , '3'             , '2'                  ,
                   a_Rate   ,sysdate
                  );
            COMMIT;      
            INSERT INTO PNL3_MAP010_PROJECTEXP_RATIO
                  (PERIOD   ,PROFIT_CENTER   ,COMPANY_CODE   ,PROJECT_NAME ,
                   R_KIND   ,AREA1           ,AREA2          ,AREA3           ,
                   RATE     ,CHANGE_DATE
                  )
                  VALUES (
                   inPeriod ,REC1.PROFIT_CENTER , REC2.COMPANY_CODE,REC2.PROJECT_NAME,
                   'PL02'   ,'4'                 , '3'              ,'3'                  ,
                   a_Rate   ,sysdate
                  );
            COMMIT;      
            INSERT INTO PNL3_MAP010_PROJECTEXP_RATIO
                  (PERIOD   ,PROFIT_CENTER   ,COMPANY_CODE   ,PROJECT_NAME ,
                   R_KIND   ,AREA1           ,AREA2          ,AREA3           ,
                   RATE     ,CHANGE_DATE
                  )
                  VALUES (
                   inPeriod ,REC1.PROFIT_CENTER , REC2.COMPANY_CODE,REC2.PROJECT_NAME,
                   'PL02'   ,'4'                 , '3'             , '4'                  ,
                   a_Rate   ,sysdate
                  ); 
            COMMIT;         
        END LOOP;
   END LOOP;
   
   
       FOR REC1 in (SELECT PROFIT_CENTER, SUM(AMT_TWD) AMT_TWD FROM PNL3_TRX005_COLLECT_PN 
                      WHERE PERIOD = inPeriod
                        AND AREA1 = '1'
                        AND AREA2 = '1'
                        AND AREA3 = '0'
                        AND AMT_TWD <> 0
                        --AND SOURCE <> 'UPL001'
                        GROUP BY PROFIT_CENTER ORDER BY AMT_TWD DESC) Loop
        FOR REC2 in (SELECT PROJECT_NAME,SUM(AMT_TWD) AMT_TWD FROM PNL3_TRX005_COLLECT_PN 
                      WHERE PROFIT_CENTER = REC1.PROFIT_CENTER
                        AND PERIOD = inPeriod
                        AND AREA1 = '1'
                        AND AREA2 = '1'
                        AND AREA3 = '0'
                        AND AMT_TWD <> 0
                        --AND SOURCE <> 'UPL001'
                        GROUP BY PROJECT_NAME ORDER BY AMT_TWD DESC) Loop
            if REC1.AMT_TWD = 0 THEN
              a_Rate := 0;
            ELSE            
              a_Rate :=  REC2.AMT_TWD / REC1.AMT_TWD;
            END IF;   
               

            INSERT INTO PNL3_MAP010_PROJECTEXP_PCRATIO
                  (PERIOD   ,PROFIT_CENTER   ,PROJECT_NAME ,
                   R_KIND   ,AREA1           ,AREA2          ,AREA3           ,
                   RATE     ,CHANGE_DATE
                  )
                  VALUES (
                   inPeriod ,REC1.PROFIT_CENTER , REC2.PROJECT_NAME,
                   'PL02'   ,'4'                 , '1'              ,'1'                  ,
                   a_Rate   ,sysdate
                  );
            COMMIT;      
            INSERT INTO PNL3_MAP010_PROJECTEXP_PCRATIO
                  (PERIOD   ,PROFIT_CENTER   ,PROJECT_NAME ,
                   R_KIND   ,AREA1           ,AREA2          ,AREA3           ,
                   RATE     ,CHANGE_DATE
                  )
                  VALUES (
                   inPeriod ,REC1.PROFIT_CENTER , REC2.PROJECT_NAME,
                   'PL02'   ,'4'                 , '1'             , '2'                  ,
                   a_Rate   ,sysdate
                  );
            COMMIT;      
            INSERT INTO PNL3_MAP010_PROJECTEXP_PCRATIO
                  (PERIOD   ,PROFIT_CENTER   ,PROJECT_NAME ,
                   R_KIND   ,AREA1           ,AREA2          ,AREA3           ,
                   RATE     ,CHANGE_DATE
                  )
                  VALUES (
                   inPeriod ,REC1.PROFIT_CENTER , REC2.PROJECT_NAME,
                   'PL02'   ,'4'                 , '1'             , '3'                  ,
                   a_Rate   ,sysdate
                  );
            COMMIT;      
            INSERT INTO PNL3_MAP010_PROJECTEXP_PCRATIO
                  (PERIOD   ,PROFIT_CENTER      ,PROJECT_NAME ,
                   R_KIND   ,AREA1           ,AREA2          ,AREA3           ,
                   RATE     ,CHANGE_DATE
                  )
                  VALUES (
                   inPeriod ,REC1.PROFIT_CENTER , REC2.PROJECT_NAME,
                   'PL02'   ,'4'                 , '1'              ,'4'                  ,
                   a_Rate   ,sysdate
                  );  
            COMMIT;      
            INSERT INTO PNL3_MAP010_PROJECTEXP_PCRATIO
                  (PERIOD   ,PROFIT_CENTER      ,PROJECT_NAME ,
                   R_KIND   ,AREA1           ,AREA2          ,AREA3           ,
                   RATE     ,CHANGE_DATE
                  )
                  VALUES (
                   inPeriod ,REC1.PROFIT_CENTER , REC2.PROJECT_NAME,
                   'PL02'   ,'4'                 , '1'             , '5'                  ,
                   a_Rate   ,sysdate
                  );
            COMMIT;      
            INSERT INTO PNL3_MAP010_PROJECTEXP_PCRATIO
                  (PERIOD   ,PROFIT_CENTER      ,PROJECT_NAME ,
                   R_KIND   ,AREA1           ,AREA2          ,AREA3           ,
                   RATE     ,CHANGE_DATE
                  )
                  VALUES (
                   inPeriod ,REC1.PROFIT_CENTER , REC2.PROJECT_NAME,
                   'PL02'   ,'4'                 , '1'              ,'6'                  ,
                   a_Rate   ,sysdate
                  );    
            COMMIT;      
            INSERT INTO PNL3_MAP010_PROJECTEXP_PCRATIO
                  (PERIOD   ,PROFIT_CENTER      ,PROJECT_NAME ,
                   R_KIND   ,AREA1           ,AREA2          ,AREA3           ,
                   RATE     ,CHANGE_DATE
                  )
                  VALUES (
                   inPeriod ,REC1.PROFIT_CENTER , REC2.PROJECT_NAME,
                   'PL02'   ,'4'                 , '1'             , '7'                  ,
                   a_Rate   ,sysdate
                  );  
            COMMIT;      
            INSERT INTO PNL3_MAP010_PROJECTEXP_PCRATIO
                  (PERIOD   ,PROFIT_CENTER      ,PROJECT_NAME ,
                   R_KIND   ,AREA1           ,AREA2          ,AREA3           ,
                   RATE     ,CHANGE_DATE
                  )
                  VALUES (
                   inPeriod ,REC1.PROFIT_CENTER , REC2.PROJECT_NAME,
                   'PL02'   ,'4'                 , '2'              ,'1'                  ,
                   a_Rate   ,sysdate
                  );
            COMMIT;      
            INSERT INTO PNL3_MAP010_PROJECTEXP_PCRATIO
                  (PERIOD   ,PROFIT_CENTER      ,PROJECT_NAME ,
                   R_KIND   ,AREA1           ,AREA2          ,AREA3           ,
                   RATE     ,CHANGE_DATE
                  )
                  VALUES (
                   inPeriod ,REC1.PROFIT_CENTER , REC2.PROJECT_NAME,
                   'PL02'   ,'4'                 , '2'             , '2'                  ,
                   a_Rate   ,sysdate
                  );
            COMMIT;      
            INSERT INTO PNL3_MAP010_PROJECTEXP_PCRATIO
                  (PERIOD   ,PROFIT_CENTER      ,PROJECT_NAME ,
                   R_KIND   ,AREA1           ,AREA2          ,AREA3           ,
                   RATE     ,CHANGE_DATE
                  )
                  VALUES (
                   inPeriod ,REC1.PROFIT_CENTER , REC2.PROJECT_NAME,
                   'PL02'   ,'4'                 , '2'              ,'3'                  ,
                   a_Rate   ,sysdate
                  );
            COMMIT;      
            INSERT INTO PNL3_MAP010_PROJECTEXP_PCRATIO
                  (PERIOD   ,PROFIT_CENTER      ,PROJECT_NAME ,
                   R_KIND   ,AREA1           ,AREA2          ,AREA3           ,
                   RATE     ,CHANGE_DATE
                  )
                  VALUES (
                   inPeriod ,REC1.PROFIT_CENTER , REC2.PROJECT_NAME,
                   'PL02'   ,'4'                 , '2'             , '4'                  ,
                   a_Rate   ,sysdate
                  ); 
            COMMIT; 
            INSERT INTO PNL3_MAP010_PROJECTEXP_PCRATIO
                  (PERIOD   ,PROFIT_CENTER   ,PROJECT_NAME ,
                   R_KIND   ,AREA1           ,AREA2          ,AREA3           ,
                   RATE     ,CHANGE_DATE
                  )
                  VALUES (
                   inPeriod ,REC1.PROFIT_CENTER , REC2.PROJECT_NAME,
                   'PL02'   ,'4'                 , '3'              ,'1'                  ,
                   a_Rate   ,sysdate
                  );
            COMMIT;      
            INSERT INTO PNL3_MAP010_PROJECTEXP_PCRATIO
                  (PERIOD   ,PROFIT_CENTER   ,PROJECT_NAME ,
                   R_KIND   ,AREA1           ,AREA2          ,AREA3           ,
                   RATE     ,CHANGE_DATE
                  )
                  VALUES (
                   inPeriod ,REC1.PROFIT_CENTER , REC2.PROJECT_NAME,
                   'PL02'   ,'4'                 , '3'             , '2'                  ,
                   a_Rate   ,sysdate
                  );
            COMMIT;      
            INSERT INTO PNL3_MAP010_PROJECTEXP_PCRATIO
                  (PERIOD   ,PROFIT_CENTER   ,PROJECT_NAME ,
                   R_KIND   ,AREA1           ,AREA2          ,AREA3           ,
                   RATE     ,CHANGE_DATE
                  )
                  VALUES (
                   inPeriod ,REC1.PROFIT_CENTER , REC2.PROJECT_NAME,
                   'PL02'   ,'4'                 , '3'              ,'3'                  ,
                   a_Rate   ,sysdate
                  );
            COMMIT;      
            INSERT INTO PNL3_MAP010_PROJECTEXP_PCRATIO
                  (PERIOD   ,PROFIT_CENTER   ,PROJECT_NAME ,
                   R_KIND   ,AREA1           ,AREA2          ,AREA3           ,
                   RATE     ,CHANGE_DATE
                  )
                  VALUES (
                   inPeriod ,REC1.PROFIT_CENTER , REC2.PROJECT_NAME,
                   'PL02'   ,'4'                 , '3'             , '4'                  ,
                   a_Rate   ,sysdate
                  ); 
            COMMIT;         
        END LOOP;
   END LOOP;
   
   a_amount := 0;
   BEGIN SELECT SUM(AMT_TWD) AMT_TWD INTO a_amount 
           FROM PNL3_TRX005_COLLECT_PN 
          WHERE PERIOD = inPeriod
            AND AREA1 = '1'
            AND AREA2 = '1'
            AND AREA3 = '0'
            AND AMT_TWD <> 0;
   EXCEPTION
    WHEN OTHERS THEN
      a_amount := 0;
   END;
        FOR REC2 in (SELECT PROJECT_NAME,SUM(AMT_TWD) AMT_TWD FROM PNL3_TRX005_COLLECT_PN 
                      WHERE PERIOD = inPeriod
                        AND AREA1 = '1'
                        AND AREA2 = '1'
                        AND AREA3 = '0'
                        AND AMT_TWD <> 0
                        --AND SOURCE <> 'UPL001'
                        GROUP BY PROJECT_NAME ORDER BY AMT_TWD DESC) Loop
            if a_amount = 0 THEN
              a_Rate := 0;
            ELSE            
              a_Rate :=  REC2.AMT_TWD / a_amount;
            END IF;   
               

            INSERT INTO PNL3_MAP010_PROJECTEXP_WWRATIO
                  (PERIOD   ,PROJECT_NAME ,
                   R_KIND   ,AREA1           ,AREA2          ,AREA3           ,
                   RATE     ,CHANGE_DATE
                  )
                  VALUES (
                   inPeriod , REC2.PROJECT_NAME,
                   'PL02'   ,'4'                 , '1'              ,'1'                  ,
                   a_Rate   ,sysdate
                  );
            COMMIT;      
            INSERT INTO PNL3_MAP010_PROJECTEXP_WWRATIO
                  (PERIOD   ,PROJECT_NAME ,
                   R_KIND   ,AREA1           ,AREA2          ,AREA3           ,
                   RATE     ,CHANGE_DATE
                  )
                  VALUES (
                   inPeriod , REC2.PROJECT_NAME,
                   'PL02'   ,'4'                 , '1'             , '2'                  ,
                   a_Rate   ,sysdate
                  );
            COMMIT;      
            INSERT INTO PNL3_MAP010_PROJECTEXP_WWRATIO
                  (PERIOD      ,PROJECT_NAME ,
                   R_KIND   ,AREA1           ,AREA2          ,AREA3           ,
                   RATE     ,CHANGE_DATE
                  )
                  VALUES (
                   inPeriod , REC2.PROJECT_NAME,
                   'PL02'   ,'4'                 , '1'             , '3'                  ,
                   a_Rate   ,sysdate
                  );
            COMMIT;      
            INSERT INTO PNL3_MAP010_PROJECTEXP_WWRATIO
                  (PERIOD   ,PROJECT_NAME ,
                   R_KIND   ,AREA1           ,AREA2          ,AREA3           ,
                   RATE     ,CHANGE_DATE
                  )
                  VALUES (
                   inPeriod , REC2.PROJECT_NAME,
                   'PL02'   ,'4'                 , '1'              ,'4'                  ,
                   a_Rate   ,sysdate
                  );  
            COMMIT;      
            INSERT INTO PNL3_MAP010_PROJECTEXP_WWRATIO
                  (PERIOD   ,PROJECT_NAME ,
                   R_KIND   ,AREA1           ,AREA2          ,AREA3           ,
                   RATE     ,CHANGE_DATE
                  )
                  VALUES (
                   inPeriod , REC2.PROJECT_NAME,
                   'PL02'   ,'4'                 , '1'             , '5'                  ,
                   a_Rate   ,sysdate
                  );
            COMMIT;      
            INSERT INTO PNL3_MAP010_PROJECTEXP_WWRATIO
                  (PERIOD   ,PROJECT_NAME ,
                   R_KIND   ,AREA1           ,AREA2          ,AREA3           ,
                   RATE     ,CHANGE_DATE
                  )
                  VALUES (
                   inPeriod , REC2.PROJECT_NAME,
                   'PL02'   ,'4'                 , '1'              ,'6'                  ,
                   a_Rate   ,sysdate
                  );    
            COMMIT;      
            INSERT INTO PNL3_MAP010_PROJECTEXP_WWRATIO
                  (PERIOD   ,PROJECT_NAME ,
                   R_KIND   ,AREA1           ,AREA2          ,AREA3           ,
                   RATE     ,CHANGE_DATE
                  )
                  VALUES (
                   inPeriod , REC2.PROJECT_NAME,
                   'PL02'   ,'4'                 , '1'             , '7'                  ,
                   a_Rate   ,sysdate
                  );  
            COMMIT;      
            INSERT INTO PNL3_MAP010_PROJECTEXP_WWRATIO
                  (PERIOD   ,PROJECT_NAME ,
                   R_KIND   ,AREA1           ,AREA2          ,AREA3           ,
                   RATE     ,CHANGE_DATE
                  )
                  VALUES (
                   inPeriod , REC2.PROJECT_NAME,
                   'PL02'   ,'4'                 , '2'              ,'1'                  ,
                   a_Rate   ,sysdate
                  );
            COMMIT;      
            INSERT INTO PNL3_MAP010_PROJECTEXP_WWRATIO
                  (PERIOD   ,PROJECT_NAME ,
                   R_KIND   ,AREA1           ,AREA2          ,AREA3           ,
                   RATE     ,CHANGE_DATE
                  )
                  VALUES (
                   inPeriod , REC2.PROJECT_NAME,
                   'PL02'   ,'4'                 , '2'             , '2'                  ,
                   a_Rate   ,sysdate
                  );
            COMMIT;      
            INSERT INTO PNL3_MAP010_PROJECTEXP_WWRATIO
                  (PERIOD   ,PROJECT_NAME ,
                   R_KIND   ,AREA1           ,AREA2          ,AREA3           ,
                   RATE     ,CHANGE_DATE
                  )
                  VALUES (
                   inPeriod , REC2.PROJECT_NAME,
                   'PL02'   ,'4'                 , '2'              ,'3'                  ,
                   a_Rate   ,sysdate
                  );
            COMMIT;      
            INSERT INTO PNL3_MAP010_PROJECTEXP_WWRATIO
                  (PERIOD   ,PROJECT_NAME ,
                   R_KIND   ,AREA1           ,AREA2          ,AREA3           ,
                   RATE     ,CHANGE_DATE
                  )
                  VALUES (
                   inPeriod , REC2.PROJECT_NAME,
                   'PL02'   ,'4'                 , '2'             , '4'                  ,
                   a_Rate   ,sysdate
                  ); 
            COMMIT;    
            INSERT INTO PNL3_MAP010_PROJECTEXP_WWRATIO
                  (PERIOD   ,PROJECT_NAME ,
                   R_KIND   ,AREA1           ,AREA2          ,AREA3           ,
                   RATE     ,CHANGE_DATE
                  )
                  VALUES (
                   inPeriod ,REC2.PROJECT_NAME,
                   'PL02'   ,'4'                 , '3'              ,'1'                  ,
                   a_Rate   ,sysdate
                  );
            COMMIT;      
            INSERT INTO PNL3_MAP010_PROJECTEXP_WWRATIO
                  (PERIOD   ,PROJECT_NAME ,
                   R_KIND   ,AREA1           ,AREA2          ,AREA3           ,
                   RATE     ,CHANGE_DATE
                  )
                  VALUES (
                   inPeriod ,REC2.PROJECT_NAME,
                   'PL02'   ,'4'                 , '3'             , '2'                  ,
                   a_Rate   ,sysdate
                  );
            COMMIT;      
            INSERT INTO PNL3_MAP010_PROJECTEXP_WWRATIO
                  (PERIOD   ,PROJECT_NAME ,
                   R_KIND   ,AREA1           ,AREA2          ,AREA3           ,
                   RATE     ,CHANGE_DATE
                  )
                  VALUES (
                   inPeriod ,REC2.PROJECT_NAME,
                   'PL02'   ,'4'                 , '3'              ,'3'                  ,
                   a_Rate   ,sysdate
                  );
            COMMIT;      
            INSERT INTO PNL3_MAP010_PROJECTEXP_WWRATIO
                  (PERIOD   ,PROJECT_NAME ,
                   R_KIND   ,AREA1           ,AREA2          ,AREA3           ,
                   RATE     ,CHANGE_DATE
                  )
                  VALUES (
                   inPeriod ,REC2.PROJECT_NAME,
                   'PL02'   ,'4'                 , '3'             , '4'                  ,
                   a_Rate   ,sysdate
                  ); 
            COMMIT;    
        END LOOP;

--以Revenue來分的Project 比率 結束
END pnl3_pls013_RDexp_ratio_trx;
/

