create PROCEDURE         "VQA_PLSQL_SUM3_GV_AMT_MM" IS

     /*--------------------------------------------------------------*
         CREATE DATE:  2008/02/29
         PLSQL      :  VQA_PLSQL_SUM3_GV_AMT_MM
         Author     :  Susan Lin
         Purpase    :  Amount Summary WW -Monthly(By 每月執行一次)
                       TW/SZ/SH
                       VQA_SUM07_AMT_GV_MF_MATGP_M, VQA_SUM08_AMT_GV_MF_M
     *---------------------------------------------------------------*
     */



 vPROCEE_YYYYMMDD varchar2(8);
 vPROCEE_YYYYMM   varchar2(6);
 iTracePoint      varchar2(100);
 cErrorText       varchar2(500);
 vCOMPANY_CODE    varchar2(4);
 vYYYYMM          varchar2(6);

BEGIN
    vCOMPANY_CODE := null;
    vYYYYMM := null;

   --抓上個月資料
     iTracePoint := '100';
     vPROCEE_YYYYMM := TO_CHAR(ADD_MONTHS(SYSDATE, -1), 'YYYYMM');

  

  vCOMPANY_CODE := '1100';
  if vCOMPANY_CODE is null then
     --若沒抓到資料則寄 error mail
     iTracePoint := '110';
     cErrorText := 'No data!';
     MAIL_FILE_BIDBDBADMIN(in_to_name => 'shuchin@ms.usi.com.tw', subject => '[VQA] PL/SQL VQA_PLSQL_SUM3_GV_AMT_MM ERROR', message => '[VQA_PLSQL_SUM3_GV_AMT_MM], The tracepoint is  ' || iTracePoint || ' and ErrorText= ' || cErrorText) ;
  else

     --清除舊的 VQA_SUM07_AMT_GV_MF_MATGP_M 資料
       iTracePoint := '200';
       DELETE FROM VQA_SUM07_AMT_GV_MF_MATGP_M WHERE YYYY = SUBSTRB(vPROCEE_YYYYMM,1,4)
                                               AND MM   = SUBSTRB(vPROCEE_YYYYMM,5,2);

     --放入上月分數
       iTracePoint := '210';
       for REC1 in ( Select A.MFR_NAME AS MANUF, A.MTL_GROUP, SUBSTRB(A.IR_DATE,1,4) AS YYYY, SUBSTRB(A.IR_DATE,5,2) AS MM,  SUBSTRB(A.IR_DATE,1,4) || C.QUARTER AS QUARTER, round(SUM(A.IR_AMT_TWD), 2) as IR_AMT_TWD
                            from PLD_KPI_IR_DETAIL A, DIMENSION_DATE C, VRTN_COMPANY_SITE D
                                where A.COMPANY_CODE is Not Null
                                and A.GLOBAL_VENDOR_CODE is Not Null
                                and A.COMPANY_CODE = D.MFG_SITE
                                and A.MTL_GROUP is Not Null
                                and A.MTL_GROUP >= '001'
                                and A.MTL_GROUP <= '059'
                                and A.PART_NO is Not Null
                                and SUBSTRB(A.IR_DATE,1,4) = SUBSTRB(vPROCEE_YYYYMM,1,4)
                                and SUBSTRB(A.IR_DATE,5,2) = SUBSTRB(vPROCEE_YYYYMM,5,2)
                                and A.MFR_NAME IS NOT NULL
                                and (SUBSTRB(A.IR_DATE,1,4) || SUBSTRB(A.IR_DATE,5,2) || '01' ) = C.DATE_KEY
              Group by A.MFR_NAME , A.MTL_GROUP, SUBSTRB(A.IR_DATE,1,4), SUBSTRB(A.IR_DATE,5,2), C.QUARTER
              ) loop

      --放到 VQA_SUM07_AMT_GV_MF_MATGP_M
      iTracePoint := '220-' || REC1.MANUF || '-' || REC1.MTL_GROUP || '-' || vPROCEE_YYYYMM || REC1.YYYY || REC1.MM;
      insert into VQA_SUM07_AMT_GV_MF_MATGP_M( MANUF, MATGROUP, YYYY, MM, QUARTER, AMOUNT, SITE, DATE_TIME
           ) values (
           REC1.MANUF,
           REC1.MTL_GROUP,
           REC1.YYYY,
           REC1.MM,
           REC1.QUARTER,
           REC1.IR_AMT_TWD,
           '',
           to_char(SYSDATE, 'yyyymmddhh24miss')
           );
      commit;
    end loop;
  end if;


  --Process - WW MANUF BY 季
  --增加select matgroup check有值才做
   for REC1 in (SELECT MANUF, YYYY, MM FROM VQA_SUM07_AMT_GV_MF_MATGP_M
                       WHERE YYYY = SUBSTRB(vPROCEE_YYYYMM,1,4)
                         AND MM = SUBSTRB(vPROCEE_YYYYMM,5,2)
                         ) loop
      vYYYYMM := REC1.YYYY || REC1.MM;
   end loop;

  if vYYYYMM is null then
     --若沒抓到資料則寄 error mail
     iTracePoint := '300';
     cErrorText := 'No data!';
     MAIL_FILE_BIDBDBADMIN(in_to_name => 'shuchin@ms.usi.com.tw', subject => '[VQA] PL/SQL VQA_PLSQL_SUM3_GV_AMT_MM ERROR', message => '[VQA_PLSQL_SUM3_GV_AMT_MM], The tracepoint is  ' || iTracePoint || ' and ErrorText= ' || cErrorText) ;
  else

     --清除舊的 VQA_SUM08_AMT_GV_MF_M 資料
       iTracePoint := '400';
       DELETE FROM VQA_SUM08_AMT_GV_MF_M WHERE YYYY = SUBSTRB(vPROCEE_YYYYMM,1,4)
                                           AND MM   = SUBSTRB(vPROCEE_YYYYMM,5,2);

     --放入上月分數
       iTracePoint := '500';
       for REC1 in ( Select MANUF, YYYY, MM, QUARTER , round(SUM(AMOUNT), 2) as AMOUNT
                            from VQA_SUM07_AMT_GV_MF_MATGP_M
                                where MANUF is Not Null
                                and MATGROUP is Not Null
                                and YYYY = SUBSTRB(vPROCEE_YYYYMM,1,4)
                                and MM = SUBSTRB(vPROCEE_YYYYMM,5,2)
              Group by MANUF, YYYY, MM, QUARTER
              ) loop
      --放到 VQA_SUM08_AMT_GV_MF_M
      iTracePoint := '510-' || REC1.MANUF || '-' ||  REC1.YYYY || REC1.MM;
      insert into VQA_SUM08_AMT_GV_MF_M(
                  MANUF, YYYY, MM, QUARTER, AMOUNT, SITE, DATE_TIME
           ) values (
           REC1.MANUF,
           REC1.YYYY,
           REC1.MM,
           REC1.QUARTER,
           REC1.AMOUNT,
           '',
           to_char(SYSDATE, 'yyyymmddhh24miss')
           );
      commit;
    end loop;
  end if;



EXCEPTION
   When OTHERS Then
    --有錯誤產生則寄mail
      cErrorText := SQLERRM();
      MAIL_FILE_BIDBDBADMIN(in_to_name => 'shuchin_lin@usiglobl.com', subject => '[VQA] PL/SQL VQA_PLSQL_SUM3_GV_AMT_MM ERROR', message => '[VQA_PLSQL_SUM3_GV_AMT_MM], The tracepoint is  ' || iTracePoint || ' and ErrorText= ' || cErrorText);


END VQA_PLSQL_SUM3_GV_AMT_MM;
/

