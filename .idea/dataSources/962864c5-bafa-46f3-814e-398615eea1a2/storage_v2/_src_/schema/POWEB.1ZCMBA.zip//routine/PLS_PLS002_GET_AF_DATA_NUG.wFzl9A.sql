create PROCEDURE       "PLS_PLS002_GET_AF_DATA_NUG" (
  f_YYYYMM in VARCHAR2
)
AUTHID DEFINER
/*********************************************************************
  PROG-ID      : PLS_PLS002_GET_AF_DATA_NUG
                 ( called by ??? - 每次重新計算 by Site分攤EM資料時)
  PROG-ACTION  : 產生 NON-UG 資料
                 取 PLS_PST005_AF_DATA.RPT_GRP = 'ALL'  扣去
                    PLS_PST005_AF_DATA.RPT_GRP = 'UG'
  Author       : Patty
  Date         : 2020/02/19
  OA No.       : SAI114678
 ======================================================================                 
-
**********************************************************************/
is

  sRPT_GRP           PLS_PST005_AF_DATA.RPT_GRP%TYPE;            

BEGIN


  sRPT_GRP := 'NON-UG';                                          

-- -------------------------------------------------------------------------------
    /*   先刪除 AF 當月 DATA   */
-- -------------------------------------------------------------------------------
   DELETE FROM PLS_PST005_AF_DATA WHERE PERIOD = f_YYYYMM
                                    AND RPT_GRP = sRPT_GRP;      -- SAI110406

-- -------------------------------------------------------------------------------
    /*   產生 AF 當月 DATA   */
-- -------------------------------------------------------------------------------
   Insert into PLS_PST005_AF_DATA (
          PERIOD, KIND, PROFIT_CENTER, SITE, ACCT_ID, CURRENCY, AMOUNT, RPT_GRP
         )
   SELECT A.PERIOD, A.KIND, A.PROFIT_CENTER, A.SITE, A.ACCT_ID, A.CURRENCY,
          SUM( CASE WHEN A.RPT_GRP = 'UG'  THEN A.AMOUNT *-1 ELSE A.AMOUNT END ) as AMOUNT,
          sRPT_GRP AS RPT_GRP
   FROM PLS_PST005_AF_DATA A
    WHERE A.PERIOD = f_YYYYMM
      AND RPT_GRP IN ('ALL','UG')
   GROUP BY A.PERIOD, A.KIND, A.PROFIT_CENTER, A.SITE, A.ACCT_ID, A.CURRENCY;
   Commit;
--

-- -------------------------------------------------------------------------------

END PLS_PLS002_GET_AF_DATA_NUG;
/

