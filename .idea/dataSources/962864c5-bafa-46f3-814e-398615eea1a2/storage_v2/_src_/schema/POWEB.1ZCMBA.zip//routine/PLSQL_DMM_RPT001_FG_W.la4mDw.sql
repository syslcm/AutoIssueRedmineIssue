create PROCEDURE "PLSQL_DMM_RPT001_FG_W" (
  nCOMPANY_CODE in DMM_RPT001_FG_W.COMPANY_CODE%TYPE,
  f_YYYYMMDD    in VARCHAR2,
  t_YYYYMMDD    in VARCHAR2
)
/*
********************************************************************
  PROG-ID      : PLSQL_DMM_RPT001_FG_W
  PROG-ACTION  : 匯集 FG Bom cost 到 table DMM_RPT001_FG_W
  Author       : Minhorng
  Date         : 2008/02/14
  2008/12/22 weekly report 從星期一改為星期五當基準
*********************************************************************
*/
is
	iTracePoint           integer ;
	cErrorText            varchar2(500) ;
	cCHK1                 varchar2(100) ;
	cCHK2                 varchar2(100) ;
	existFlag             varchar2(1);
	tCREATE_DATE          DMM_RPT001_FG_W.CREATE_DATE%TYPE;
	tCREATE_DATE2         DMM_RPT001_FG_W.CREATE_DATE%TYPE;
	tPERIOD_C             DMM_RPT001_FG_W.PERIOD%TYPE;
	tPERIOD_P             DMM_RPT001_FG_W.PERIOD%TYPE;
	tDAY_OF_WK            DIMENSION_DATE.DAY_OF_WK%TYPE;
	tDATE_KEY_F           DIMENSION_DATE.DATE_KEY%TYPE;
	tDATE_KEY_T           DIMENSION_DATE.DATE_KEY%TYPE;
	--usd
	tCOST_MAC             DMM_RPT001_FG_W.COST_MAC%TYPE;
	tINFOREC_MAC          DMM_RPT001_FG_W.INFOREC_MAC%TYPE;
	tCOST_MAC_P           DMM_RPT001_FG_W.COST_MAC_P%TYPE;
	tINFOREC_MAC_P        DMM_RPT001_FG_W.INFOREC_MAC_P%TYPE;
	--loc
	tCOST_MAC_LOC         DMM_RPT001_FG_W.COST_MAC_LOC%TYPE;
	tINFOREC_MAC_LOC      DMM_RPT001_FG_W.INFOREC_MAC_LOC%TYPE;
	tCOST_MAC_LOC_P       DMM_RPT001_FG_W.COST_MAC_LOC_P%TYPE;
	tINFOREC_MAC_LOC_P    DMM_RPT001_FG_W.INFOREC_MAC_LOC_P%TYPE;
	----
	tCOMPANY_CODE         DMM_RPT004_BOMMAC_D.COMPANY_CODE%TYPE;
	tUSI_CONT             DMM_RPT004_BOMMAC_D.USI_CONT%TYPE;
BEGIN
	cErrorText := ' ';
	cCHK1 := ' ';
	cCHK2 := ' ';
	tCREATE_DATE2 := null;
	--抓 PERIOD
	iTracePoint := 100;
	select * into tDAY_OF_WK from (
		select DAY_OF_WK from DIMENSION_DATE where DATE_KEY = t_YYYYMMDD
	) where rownum <= 1;
	iTracePoint := 110;
	select * into tPERIOD_C from (
		select to_char(to_date(t_YYYYMMDD,'yyyymmdd'),'iyyyiw') from dual
	) where rownum <= 1;
	iTracePoint := 115;
	select * into tPERIOD_P from (
		select to_char(to_date(t_YYYYMMDD,'yyyymmdd') - 7,'iyyyiw') from dual
	) where rownum <= 1;
	--(t_YYYYMMDD - 1) 天若為星期一則 tCREATE_DATE2 設為 null
	--2008/12/22 改為認 星期五
	iTracePoint := 120;
	BEGIN
		select * into tCREATE_DATE2 from (
			select DATE_KEY from DIMENSION_DATE
			where DATE_KEY = to_char(to_date(t_YYYYMMDD,'yyyymmdd') - 1,'yyyymmdd')
			and DAY_OF_WK != '5'
		);
	EXCEPTION
		WHEN OTHERS THEN
			tCREATE_DATE2 := null;
	END;
	---------------------------------------------------------------------------------------------
	--check & move data
	iTracePoint := 121;
	BEGIN
	select * into tCREATE_DATE from (
	  select distinct CREATE_DATE from DMM_TMP001_BOM where CREATE_DATE = t_YYYYMMDD
		and COMPANY_CODE = nCOMPANY_CODE
	) where rownum <= 1;
	EXCEPTION
		WHEN OTHERS THEN
			tCREATE_DATE := t_YYYYMMDD;
	END;
	iTracePoint := 122;
	BEGIN
	select * into tCREATE_DATE from (
	  select distinct CREATE_DATE from DMM_TMP002_INT_PART where CREATE_DATE = t_YYYYMMDD
		and COMPANY_CODE = nCOMPANY_CODE
	) where rownum <= 1;
	EXCEPTION
		WHEN OTHERS THEN
			tCREATE_DATE := t_YYYYMMDD;
	END;
	iTracePoint := 123;
	BEGIN
	select * into tCREATE_DATE from (
	  select distinct CREATE_DATE from DMM_TMP003_QTA_INF where CREATE_DATE = t_YYYYMMDD
		and COMPANY_CODE = nCOMPANY_CODE
	) where rownum <= 1;
	EXCEPTION
		WHEN OTHERS THEN
			tCREATE_DATE := t_YYYYMMDD;
	END;
	iTracePoint := 124;
	BEGIN
	select * into tCREATE_DATE from (
	  select distinct CREATE_DATE from DMM_TMP004_PO where CREATE_DATE = t_YYYYMMDD
		and COMPANY_CODE = nCOMPANY_CODE
	) where rownum <= 1;
	EXCEPTION
		WHEN OTHERS THEN
			tCREATE_DATE := t_YYYYMMDD;
	END;
	iTracePoint := 125;
	BEGIN
	select * into tCREATE_DATE from (
	  select distinct CREATE_DATE from DMM_TMP005_MSG where CREATE_DATE = t_YYYYMMDD
		and COMPANY_CODE = nCOMPANY_CODE
	) where rownum <= 1;
	EXCEPTION
		WHEN OTHERS THEN
			tCREATE_DATE := t_YYYYMMDD;
	END;
	iTracePoint := 126;
	BEGIN
	select * into tCREATE_DATE from (
	  select distinct CREATE_DATE from DMM_TMP006_FGFCST where CREATE_DATE = t_YYYYMMDD
		and COMPANY_CODE = nCOMPANY_CODE
	) where rownum <= 1;
	EXCEPTION
		WHEN OTHERS THEN
			tCREATE_DATE := t_YYYYMMDD;
	END;
	iTracePoint := 127;
	BEGIN
	select * into tCREATE_DATE from (
	  select distinct CREATE_DATE from DMM_TMP007_FG101 where CREATE_DATE = t_YYYYMMDD
		and COMPANY_CODE = nCOMPANY_CODE
	) where rownum <= 1;
	EXCEPTION
		WHEN OTHERS THEN
			tCREATE_DATE := t_YYYYMMDD;
	END;
	---------------------------------------------------------------------------------------------
	---------------------------------------------------------------------------------------------
	--清舊有資料
	-- 取消判斷 LOA / Consign (2009/01/08)
	/*
	iTracePoint := 130;
	delete from DMM_OTH001_LOA;
	insert into DMM_OTH001_LOA ( PART_NO, PART_TYPE )
		select distinct PART_NO, 'Y' from RFQ_LOA_PART where PART_TYPE in ('LOA','CONSIGN');
	commit;
	*/
	iTracePoint := 135;
	delete from DMM_SAP001_BOM where COMPANY_CODE = nCOMPANY_CODE and CREATE_DATE = t_YYYYMMDD;
	commit;
	delete from DMM_SAP002_INT_PART where COMPANY_CODE = nCOMPANY_CODE and CREATE_DATE = t_YYYYMMDD;
	commit;
	delete from DMM_SAP003_QTA_INF where COMPANY_CODE = nCOMPANY_CODE and CREATE_DATE = t_YYYYMMDD;
	commit;
	delete from DMM_SAP004_PO where COMPANY_CODE = nCOMPANY_CODE and CREATE_DATE = t_YYYYMMDD;
	commit;
	delete from DMM_SAP005_MSG where COMPANY_CODE = nCOMPANY_CODE and CREATE_DATE = t_YYYYMMDD;
	commit;
	delete from DMM_SAP006_FGFCST where COMPANY_CODE = nCOMPANY_CODE and CREATE_DATE = t_YYYYMMDD;
	commit;
	delete from DMM_SAP007_FG101 where COMPANY_CODE = nCOMPANY_CODE and CREATE_DATE = t_YYYYMMDD;
	commit;
	---------------------------------------------------------------------------------------------
	---------------------------------------------------------------------------------------------
	--寫到正式 table
	iTracePoint := 140;
	insert into DMM_SAP001_BOM
		select * from DMM_TMP001_BOM where COMPANY_CODE = nCOMPANY_CODE and CREATE_DATE = t_YYYYMMDD;
	commit;
	insert into DMM_SAP002_INT_PART
		select * from DMM_TMP002_INT_PART where COMPANY_CODE = nCOMPANY_CODE and CREATE_DATE = t_YYYYMMDD;
	commit;
	insert into DMM_SAP003_QTA_INF
		select * from DMM_TMP003_QTA_INF where COMPANY_CODE = nCOMPANY_CODE and CREATE_DATE = t_YYYYMMDD;
	commit;
	insert into DMM_SAP004_PO
		select * from DMM_TMP004_PO where COMPANY_CODE = nCOMPANY_CODE and CREATE_DATE = t_YYYYMMDD;
	commit;
	insert into DMM_SAP005_MSG
		select * from DMM_TMP005_MSG where COMPANY_CODE = nCOMPANY_CODE and CREATE_DATE = t_YYYYMMDD;
	commit;
	insert into DMM_SAP006_FGFCST
		select * from DMM_TMP006_FGFCST where COMPANY_CODE = nCOMPANY_CODE and CREATE_DATE = t_YYYYMMDD;
	commit;
	insert into DMM_SAP007_FG101
		select * from DMM_TMP007_FG101 where COMPANY_CODE = nCOMPANY_CODE and CREATE_DATE = t_YYYYMMDD;
	commit;
	iTracePoint := 142;
	for REC1 in (
		select distinct a.COMPANY_CODE, a.PLANT, a.FG, a.FG_DESC from DMM_TMP001_BOM a
		where a.COMPANY_CODE = nCOMPANY_CODE
		and exists (
			select COMPANY_CODE from DMM_OTH002_FG_DESC
			where COMPANY_CODE = a.COMPANY_CODE and PLANT = a.PLANT
			and FG = a.FG and FG_DESC != a.FG_DESC
		)
	) loop
		update DMM_OTH002_FG_DESC set FG_DESC = REC1.FG_DESC
			where COMPANY_CODE = REC1.COMPANY_CODE
			and PLANT = REC1.PLANT
			and FG = REC1.FG;
		commit;
	end loop;
	iTracePoint := 145;
	insert into DMM_OTH002_FG_DESC ( COMPANY_CODE, PLANT, FG, FG_DESC )
		select distinct a.COMPANY_CODE, a.PLANT, a.FG, a.FG_DESC
			from DMM_TMP001_BOM a
			where a.COMPANY_CODE = nCOMPANY_CODE
			and not exists (
				select COMPANY_CODE from DMM_OTH002_FG_DESC
				where COMPANY_CODE = a.COMPANY_CODE
				and PLANT = a.PLANT
				and FG = a.FG
			);
	commit;
	---------------------------------------------------------------------------------------------
	---------------------------------------------------------------------------------------------
	--處理 DMM_SAP002_INT_PART  (以後預估週次須與當週比)
	iTracePoint := 150;
	cCHK1 := ' ';
	cCHK2 := ' ';
	for REC1 in (
		select * from DMM_SAP002_INT_PART where COMPANY_CODE = nCOMPANY_CODE and PERIOD = tPERIOD_C and CREATE_DATE = t_YYYYMMDD
		order by PERIOD, COMPANY_CODE, ISSUE_PLANT, COMPONENT, YYYYWW
	) loop
		cCHK2 := trim(REC1.PERIOD) || trim(REC1.COMPANY_CODE) || trim(REC1.ISSUE_PLANT) || trim(REC1.COMPONENT);
		if cCHK1 <> cCHK2 then
			if REC1.PERIOD = REC1.YYYYWW then
				--當週值, 做為以後預估週次的比對基準
				tCOST_MAC := REC1.MAC_USD;
				tINFOREC_MAC := REC1.INFOREC_USD;
				tCOST_MAC_LOC := REC1.MAC_LOC;
				tINFOREC_MAC_LOC := REC1.INFOREC_LOC;
				cCHK1 := cCHK2;
			end if;
		end if;
		if cCHK1 = cCHK2 then
			--update table
			update DMM_SAP002_INT_PART set
				MAC_LOC_P = tCOST_MAC_LOC,
				INFOREC_LOC_P = tINFOREC_MAC_LOC,
				MAC_USD_P = tCOST_MAC,
				INFOREC_USD_P = tINFOREC_MAC
			where PERIOD = REC1.PERIOD
			and COMPANY_CODE = REC1.COMPANY_CODE
			and ISSUE_PLANT = REC1.ISSUE_PLANT
			and COMPONENT = REC1.COMPONENT
			and YYYYWW = REC1.YYYYWW
			and CREATE_DATE = REC1.CREATE_DATE;
			commit;
		end if;
	end loop;
	---------------------------------------------------------------------------------------------
	--處理 DMM_SAP003_QTA_INF  (以後預估週次須與當週比)
	iTracePoint := 160;
	cCHK1 := ' ';
	cCHK2 := ' ';
	for REC1 in (
		select * from DMM_SAP003_QTA_INF where COMPANY_CODE = nCOMPANY_CODE and PERIOD = tPERIOD_C and CREATE_DATE = t_YYYYMMDD
		order by PERIOD, COMPANY_CODE, PLANT, COMPONENT, MPN, VENDOR_CODE, YYYYWW
	) loop
		cCHK2 := trim(REC1.PERIOD) || trim(REC1.COMPANY_CODE) || trim(REC1.PLANT) || trim(REC1.COMPONENT) || trim(REC1.MPN) || trim(REC1.VENDOR_CODE);
		if cCHK1 <> cCHK2 then
			if REC1.PERIOD = REC1.YYYYWW then
				--當週值, 做為以後預估週次的比對基準
				tINFOREC_MAC := REC1.INFOREC_USD;
				tINFOREC_MAC_LOC := REC1.INFOREC_LOC;
				cCHK1 := cCHK2;
			end if;
		end if;
		--update table
		if cCHK1 = cCHK2 then
			update DMM_SAP003_QTA_INF set
				INFOREC_LOC_P = tINFOREC_MAC_LOC,
				INFOREC_USD_P = tINFOREC_MAC
			where PERIOD = REC1.PERIOD
			and COMPANY_CODE = REC1.COMPANY_CODE
			and PLANT = REC1.PLANT
			and COMPONENT = REC1.COMPONENT
			and MPN = REC1.MPN
			and VENDOR_CODE = REC1.VENDOR_CODE
			and YYYYWW = REC1.YYYYWW
			and CREATE_DATE = REC1.CREATE_DATE;
			commit;
		end if;
	end loop;
	---------------------------------------------------------------------------------------------
	---------------------------------------------------------------------------------------------
	--處理日報 (for monty & quarter report)
	iTracePoint := 200;
	delete from DMM_RPT003_FG_D where DATE_KEY >= t_YYYYMMDD and CREATE_DATE <= t_YYYYMMDD
		and COMPANY_CODE = nCOMPANY_CODE;
	commit;
	----- DMM_RPT003_FG_D
	iTracePoint := 211;
	delete from DMM_RPT003_FG_D_TMP where COMPANY_CODE = nCOMPANY_CODE;
	commit;
	iTracePoint := 212;
	insert into DMM_RPT003_FG_D_TMP (
		DATE_KEY, COMPANY_CODE, PLANT, FG, USI_CONT, CREATE_DATE, COST_MAC, INFOREC_MAC,
		COST_MAC_LOC, INFOREC_MAC_LOC )
	select YW_DATE, COMPANY_CODE, PLANT, FG, USI_CONT, CREATE_DATE,
		nvl(sum(round(BOM_USAGE * QTA * MAC_USD * REQD_QTY / 10000,6)),0) as COST_MAC,
		nvl(sum(round(BOM_USAGE * QTA * INFOREC_USD * REQD_QTY / 10000,6)),0) as INFOREC_MAC,
		nvl(sum(round(BOM_USAGE * QTA * MAC_LOC * REQD_QTY / 10000,6)),0) as COST_MAC_LOC,
		nvl(sum(round(BOM_USAGE * QTA * INFOREC_LOC * REQD_QTY / 10000,6)),0) as INFOREC_MAC_LOC
	from (
		select AL1.PERIOD, AL1.COMPANY_CODE, AL1.PLANT, AL1.FG,
			decode(AL1.ALT_GRP, null, 100, AL1.BOM_USAGE) as BOM_USAGE,
			round(AL1.REQD_QTY / 10000,6) as REQD_QTY, nvl(AL2.YYYYWW, AL1.PERIOD) as YYYYWW,
			nvl(AL2.YW_DATE, AL1.CREATE_DATE) as YW_DATE,
			nvl(AL3.PART_TYPE, 'N') as USI_CONT,
			AL4.QTA, AL2.MAC_USD, AL2.INFOREC_USD, AL2.MAC_LOC, AL2.INFOREC_LOC, AL1.CREATE_DATE
		from DMM_SAP001_BOM AL1, DMM_SAP002_INT_PART AL2, DMM_OTH001_LOA AL3, DMM_SAP003_QTA_INF AL4
		where AL1.PERIOD = AL2.PERIOD (+) and AL1.COMPANY_CODE = AL2.COMPANY_CODE (+)
		and AL1.ISSUE_PLANT = AL2.ISSUE_PLANT (+) and AL1.COMPONENT = AL2.COMPONENT (+)
		and AL1.CREATE_DATE = AL2.CREATE_DATE (+)
		and AL2.PERIOD = AL4.PERIOD (+) and AL2.COMPANY_CODE = AL4.COMPANY_CODE (+)
		and AL2.ISSUE_PLANT = AL4.PLANT (+) and AL2.COMPONENT = AL4.COMPONENT (+)
		and AL2.YYYYWW = AL4.YYYYWW (+) and AL2.CREATE_DATE = AL4.CREATE_DATE (+)
		and AL2.COMPONENT = AL3.PART_NO (+)
		and AL1.COMPANY_CODE = nCOMPANY_CODE and AL1.PERIOD = tPERIOD_C and AL1.CREATE_DATE = t_YYYYMMDD
	)
	group by COMPANY_CODE, PLANT, FG, YW_DATE, USI_CONT, CREATE_DATE;
	commit;
	iTracePoint := 213;
	insert into DMM_RPT003_FG_D (
		DATE_KEY, COMPANY_CODE, PLANT, FG, USI_CONT, CREATE_DATE, COST_MAC, INFOREC_MAC,
		COST_MAC_LOC, INFOREC_MAC_LOC )
	select DATE_KEY, COMPANY_CODE, PLANT, FG, USI_CONT, CREATE_DATE, COST_MAC, INFOREC_MAC, COST_MAC_LOC, INFOREC_MAC_LOC
	from DMM_RPT003_FG_D_TMP
	where COMPANY_CODE = nCOMPANY_CODE
	and not exists(
		select COMPANY_CODE from DMM_RPT003_FG_D
		where DATE_KEY = DMM_RPT003_FG_D_TMP.DATE_KEY
		and COMPANY_CODE = DMM_RPT003_FG_D_TMP.COMPANY_CODE
		and PLANT = DMM_RPT003_FG_D_TMP.PLANT
		and FG = DMM_RPT003_FG_D_TMP.FG
		and USI_CONT = DMM_RPT003_FG_D_TMP.USI_CONT
	);
	commit;
	cCHK2 := ' ';

	---------------------------------------------------------------------------------------------
	-- 2012-06-19 拿掉 delete 改用 update
	-----------------------------------------------------------------------
	-- DMM_RPT004_BOMMAC_D_TMP 為 global temporary table
	-----------------------------------------------------------------------
	iTracePoint := 220;
	delete from DMM_RPT004_BOMMAC_D_TMP where COMPANY_CODE = nCOMPANY_CODE;
	iTracePoint := 221;
	insert into DMM_RPT004_BOMMAC_D_TMP (
		DATE_KEY, COMPANY_CODE, PLANT, FG, USI_CONT, CREATE_DATE, ISSUE_PLANT, COMPONENT,
		COST_MAC, INFOREC_MAC, COST_MAC_LOC, INFOREC_MAC_LOC )
	select YW_DATE, COMPANY_CODE, PLANT, FG, USI_CONT, CREATE_DATE, ISSUE_PLANT, COMPONENT,
		nvl(sum(round(BOM_USAGE * QTA * MAC_USD * REQD_QTY / 10000,6)),0) as COST_MAC,
		nvl(sum(round(BOM_USAGE * QTA * INFOREC_USD * REQD_QTY / 10000,6)),0) as INFOREC_MAC,
		nvl(sum(round(BOM_USAGE * QTA * MAC_LOC * REQD_QTY / 10000,6)),0) as COST_MAC_LOC,
		nvl(sum(round(BOM_USAGE * QTA * INFOREC_LOC * REQD_QTY / 10000,6)),0) as INFOREC_MAC_LOC
	from (
		select AL1.PERIOD, AL1.COMPANY_CODE, AL1.PLANT, AL1.FG, AL1.ISSUE_PLANT, AL1.COMPONENT,
			decode(AL1.ALT_GRP, null, 100, AL1.BOM_USAGE) as BOM_USAGE,
			round(AL1.REQD_QTY / 10000,6) as REQD_QTY, nvl(AL2.YYYYWW, AL1.PERIOD) as YYYYWW,
			nvl(AL2.YW_DATE, AL1.CREATE_DATE) as YW_DATE,
			nvl(AL3.PART_TYPE, 'N') as USI_CONT,
			AL4.QTA, AL2.MAC_USD, AL2.INFOREC_USD, AL2.MAC_LOC, AL2.INFOREC_LOC, AL1.CREATE_DATE
		from DMM_SAP001_BOM AL1, DMM_SAP002_INT_PART AL2, DMM_OTH001_LOA AL3, DMM_SAP003_QTA_INF AL4
		where AL1.PERIOD = AL2.PERIOD (+) and AL1.COMPANY_CODE = AL2.COMPANY_CODE (+)
		and AL1.ISSUE_PLANT = AL2.ISSUE_PLANT (+) and AL1.COMPONENT = AL2.COMPONENT (+)
		and AL1.CREATE_DATE = AL2.CREATE_DATE (+)
		and AL2.PERIOD = AL4.PERIOD (+) and AL2.COMPANY_CODE = AL4.COMPANY_CODE (+)
		and AL2.ISSUE_PLANT = AL4.PLANT (+) and AL2.COMPONENT = AL4.COMPONENT (+)
		and AL2.YYYYWW = AL4.YYYYWW (+) and AL2.CREATE_DATE = AL4.CREATE_DATE (+)
		and AL2.COMPONENT = AL3.PART_NO (+)
		and AL1.COMPANY_CODE = nCOMPANY_CODE and AL1.PERIOD = tPERIOD_C and AL1.CREATE_DATE = t_YYYYMMDD
	) group by COMPANY_CODE, PLANT, FG, ISSUE_PLANT, COMPONENT, YW_DATE, USI_CONT, CREATE_DATE;
	-- update 已存在者
	iTracePoint := 222;
	cCHK2 := ' ';
	for rec_t1 in (
		select DATE_KEY, COMPANY_CODE, PLANT, FG, USI_CONT, CREATE_DATE, ISSUE_PLANT, COMPONENT,
			COST_MAC, INFOREC_MAC, COST_MAC_LOC, INFOREC_MAC_LOC
		from DMM_RPT004_BOMMAC_D_TMP
		where COMPANY_CODE = nCOMPANY_CODE
		and exists(
			select COMPANY_CODE from DMM_RPT004_BOMMAC_D
			where DATE_KEY = DMM_RPT004_BOMMAC_D_TMP.DATE_KEY
			and COMPANY_CODE = DMM_RPT004_BOMMAC_D_TMP.COMPANY_CODE
			and PLANT = DMM_RPT004_BOMMAC_D_TMP.PLANT
			and FG = DMM_RPT004_BOMMAC_D_TMP.FG
			and ISSUE_PLANT = DMM_RPT004_BOMMAC_D_TMP.ISSUE_PLANT
			and COMPONENT = DMM_RPT004_BOMMAC_D_TMP.COMPONENT
			and USI_CONT = DMM_RPT004_BOMMAC_D_TMP.USI_CONT
		)
	) loop
		cCHK2 := rec_t1.DATE_KEY || rec_t1.PLANT || rec_t1.FG || rec_t1.COMPONENT;
		update DMM_RPT004_BOMMAC_D set
			CREATE_DATE = rec_t1.CREATE_DATE,
			COST_MAC = rec_t1.COST_MAC,
			INFOREC_MAC = rec_t1.INFOREC_MAC,
			COST_MAC_LOC = rec_t1.COST_MAC_LOC,
			INFOREC_MAC_LOC = rec_t1.INFOREC_MAC_LOC
		where DATE_KEY = rec_t1.DATE_KEY
		and COMPANY_CODE = rec_t1.COMPANY_CODE and PLANT = rec_t1.PLANT
		and FG = rec_t1.FG and ISSUE_PLANT = rec_t1.ISSUE_PLANT
		and COMPONENT = rec_t1.COMPONENT and USI_CONT = rec_t1.USI_CONT;
		commit;
	end loop;
	cCHK2 := ' ';
	-- insert 不存在者
	iTracePoint := 223;
	insert into DMM_RPT004_BOMMAC_D (
		DATE_KEY, COMPANY_CODE, PLANT, FG, USI_CONT, CREATE_DATE, ISSUE_PLANT, COMPONENT,
		COST_MAC, INFOREC_MAC, COST_MAC_LOC, INFOREC_MAC_LOC )
	select DATE_KEY, COMPANY_CODE, PLANT, FG, USI_CONT, CREATE_DATE, ISSUE_PLANT, COMPONENT,
		COST_MAC, INFOREC_MAC, COST_MAC_LOC, INFOREC_MAC_LOC
	from DMM_RPT004_BOMMAC_D_TMP
	where COMPANY_CODE = nCOMPANY_CODE
	and	not exists(
		select COMPANY_CODE from DMM_RPT004_BOMMAC_D
		where DATE_KEY = DMM_RPT004_BOMMAC_D_TMP.DATE_KEY
		and COMPANY_CODE = DMM_RPT004_BOMMAC_D_TMP.COMPANY_CODE
		and PLANT = DMM_RPT004_BOMMAC_D_TMP.PLANT
		and FG = DMM_RPT004_BOMMAC_D_TMP.FG
		and ISSUE_PLANT = DMM_RPT004_BOMMAC_D_TMP.ISSUE_PLANT
		and COMPONENT = DMM_RPT004_BOMMAC_D_TMP.COMPONENT
		and USI_CONT = DMM_RPT004_BOMMAC_D_TMP.USI_CONT
	);
	commit;
	-- 刪除不存在的 item (利用 DMM_SAP001_BOM)
	iTracePoint := 225;
	delete from DMM_RPT004_BOMMAC_D_TMP where COMPANY_CODE = nCOMPANY_CODE;
	iTracePoint := 226;  -- 先抓出大於今天, 且不是今天建的的有哪些
	insert into DMM_RPT004_BOMMAC_D_TMP ( DATE_KEY, COMPANY_CODE, PLANT, FG, ISSUE_PLANT, COMPONENT, USI_CONT )
		select min(DATE_KEY), COMPANY_CODE, PLANT, FG, ISSUE_PLANT, COMPONENT, USI_CONT from DMM_RPT004_BOMMAC_D
		where COMPANY_CODE = nCOMPANY_CODE and DATE_KEY >= t_YYYYMMDD and CREATE_DATE < t_YYYYMMDD
		and exists (
			select FG from DMM_UPL001_SELLING
			where COMPANY_CODE = DMM_RPT004_BOMMAC_D.COMPANY_CODE
			and PLANT = DMM_RPT004_BOMMAC_D.PLANT
			and FG = DMM_RPT004_BOMMAC_D.FG
			and FROM_DATE <= t_YYYYMMDD
			and TO_DATE >= t_YYYYMMDD
		)
		group by COMPANY_CODE, PLANT, FG, ISSUE_PLANT, COMPONENT, USI_CONT;
	iTracePoint := 227;  -- 刪除有的 , 剩下的就不存在於 DMM_SAP001_BOM 中的
	delete from DMM_RPT004_BOMMAC_D_TMP
		where COMPANY_CODE = nCOMPANY_CODE
		and exists (
			select COMPANY_CODE from DMM_SAP001_BOM
			where COMPANY_CODE = DMM_RPT004_BOMMAC_D_TMP.COMPANY_CODE
			and CREATE_DATE = t_YYYYMMDD
			and PLANT = DMM_RPT004_BOMMAC_D_TMP.PLANT
			and FG = DMM_RPT004_BOMMAC_D_TMP.FG
			and ISSUE_PLANT = DMM_RPT004_BOMMAC_D_TMP.ISSUE_PLANT
			and COMPONENT = DMM_RPT004_BOMMAC_D_TMP.COMPONENT
		);
	iTracePoint := 228;
	for rec_t0 in (
		select DATE_KEY, COMPANY_CODE, PLANT, FG, ISSUE_PLANT, COMPONENT, USI_CONT
		from DMM_RPT004_BOMMAC_D_TMP where COMPANY_CODE = nCOMPANY_CODE
	) loop
		cCHK2 := rec_t0.DATE_KEY || rec_t0.PLANT || rec_t0.FG || rec_t0.COMPONENT;
		-- 不用 delete, 改用改掉 key 值
		tCOMPANY_CODE := replace(rec_t0.COMPANY_CODE,'0','x');
		tUSI_CONT := trim(rec_t0.USI_CONT) || t_YYYYMMDD;

		delete from DMM_RPT004_BOMMAC_D
			where DATE_KEY >= rec_t0.DATE_KEY
			and COMPANY_CODE = rec_t0.COMPANY_CODE
			and PLANT = rec_t0.PLANT
			and FG = rec_t0.FG
			and ISSUE_PLANT = rec_t0.ISSUE_PLANT
			and COMPONENT = rec_t0.COMPONENT
			and USI_CONT = rec_t0.USI_CONT
			and CREATE_DATE < t_YYYYMMDD;

		/*
		update DMM_RPT004_BOMMAC_D
		set COMPANY_CODE = tCOMPANY_CODE, USI_CONT = tUSI_CONT
			where DATE_KEY >= rec_t0.DATE_KEY
			and COMPANY_CODE = rec_t0.COMPANY_CODE
			and PLANT = rec_t0.PLANT
			and FG = rec_t0.FG
			and ISSUE_PLANT = rec_t0.ISSUE_PLANT
			and COMPONENT = rec_t0.COMPONENT
			and USI_CONT = rec_t0.USI_CONT
			and CREATE_DATE < t_YYYYMMDD;
		*/
		commit;

	end loop;
	cCHK2 := ' ';
	delete from DMM_RPT004_BOMMAC_D_TMP where COMPANY_CODE = nCOMPANY_CODE;
	/*
	for rec_tmp in (
		select YW_DATE, COMPANY_CODE, PLANT, FG, USI_CONT, CREATE_DATE, ISSUE_PLANT, COMPONENT,
			nvl(sum(round(BOM_USAGE * QTA * MAC_USD * REQD_QTY / 10000,6)),0) as COST_MAC,
			nvl(sum(round(BOM_USAGE * QTA * INFOREC_USD * REQD_QTY / 10000,6)),0) as INFOREC_MAC,
			nvl(sum(round(BOM_USAGE * QTA * MAC_LOC * REQD_QTY / 10000,6)),0) as COST_MAC_LOC,
			nvl(sum(round(BOM_USAGE * QTA * INFOREC_LOC * REQD_QTY / 10000,6)),0) as INFOREC_MAC_LOC
		from (
			select AL1.PERIOD, AL1.COMPANY_CODE, AL1.PLANT, AL1.FG, AL1.ISSUE_PLANT, AL1.COMPONENT,
				decode(AL1.ALT_GRP, null, 100, AL1.BOM_USAGE) as BOM_USAGE,
				round(AL1.REQD_QTY / 10000,6) as REQD_QTY, nvl(AL2.YYYYWW, AL1.PERIOD) as YYYYWW,
				nvl(AL2.YW_DATE, AL1.CREATE_DATE) as YW_DATE,
				nvl(AL3.PART_TYPE, 'N') as USI_CONT,
				AL4.QTA, AL2.MAC_USD, AL2.INFOREC_USD, AL2.MAC_LOC, AL2.INFOREC_LOC, AL1.CREATE_DATE
			from DMM_SAP001_BOM AL1, DMM_SAP002_INT_PART AL2, DMM_OTH001_LOA AL3, DMM_SAP003_QTA_INF AL4
			where AL1.PERIOD = AL2.PERIOD (+) and AL1.COMPANY_CODE = AL2.COMPANY_CODE (+)
			and AL1.ISSUE_PLANT = AL2.ISSUE_PLANT (+) and AL1.COMPONENT = AL2.COMPONENT (+)
			and AL1.CREATE_DATE = AL2.CREATE_DATE (+)
			and AL2.PERIOD = AL4.PERIOD (+) and AL2.COMPANY_CODE = AL4.COMPANY_CODE (+)
			and AL2.ISSUE_PLANT = AL4.PLANT (+) and AL2.COMPONENT = AL4.COMPONENT (+)
			and AL2.YYYYWW = AL4.YYYYWW (+) and AL2.CREATE_DATE = AL4.CREATE_DATE (+)
			and AL2.COMPONENT = AL3.PART_NO (+)
			and AL1.COMPANY_CODE = nCOMPANY_CODE and AL1.PERIOD = tPERIOD_C and AL1.CREATE_DATE = t_YYYYMMDD
		) group by COMPANY_CODE, PLANT, FG, ISSUE_PLANT, COMPONENT, YW_DATE, USI_CONT, CREATE_DATE
	) loop
		existFlag := null;
		begin
			select * into existFlag from (
				select 'Y' from DMM_RPT004_BOMMAC_D
				where DATE_KEY = rec_tmp.YW_DATE
				and COMPANY_CODE = rec_tmp.COMPANY_CODE and PLANT = rec_tmp.PLANT
				and FG = rec_tmp.FG and ISSUE_PLANT = rec_tmp.ISSUE_PLANT
				and COMPONENT = rec_tmp.COMPONENT and USI_CONT = rec_tmp.USI_CONT
			) where rownum <= 1;
		exception
			when others then
				existFlag := null;
		end;
		if existFlag is null then
			insert into DMM_RPT004_BOMMAC_D ( DATE_KEY, COMPANY_CODE, PLANT,
				FG, USI_CONT, CREATE_DATE, ISSUE_PLANT, COMPONENT,
				COST_MAC, INFOREC_MAC, COST_MAC_LOC, INFOREC_MAC_LOC )
			values ( rec_tmp.YW_DATE, rec_tmp.COMPANY_CODE, rec_tmp.PLANT,
				rec_tmp.FG, rec_tmp.USI_CONT, rec_tmp.CREATE_DATE, rec_tmp.ISSUE_PLANT, rec_tmp.COMPONENT,
				rec_tmp.COST_MAC, rec_tmp.INFOREC_MAC, rec_tmp.COST_MAC_LOC, rec_tmp.INFOREC_MAC_LOC
			);
		else
			update DMM_RPT004_BOMMAC_D set
				CREATE_DATE = rec_tmp.CREATE_DATE,
				COST_MAC = rec_tmp.COST_MAC,
				INFOREC_MAC = rec_tmp.INFOREC_MAC,
				COST_MAC_LOC = rec_tmp.COST_MAC_LOC,
				INFOREC_MAC_LOC = rec_tmp.INFOREC_MAC_LOC
			where DATE_KEY = rec_tmp.YW_DATE
			and COMPANY_CODE = rec_tmp.COMPANY_CODE and PLANT = rec_tmp.PLANT
			and FG = rec_tmp.FG and ISSUE_PLANT = rec_tmp.ISSUE_PLANT
			and COMPONENT = rec_tmp.COMPONENT and USI_CONT = rec_tmp.USI_CONT;
		end if;
		commit;
	end loop;
	-- 刪除不存在的 item (利用 DMM_SAP001_BOM)
	iTracePoint := 222;
	delete from DMM_RPT004_BOMMAC_D where COMPANY_CODE = nCOMPANY_CODE
		and DATE_KEY >= t_YYYYMMDD and CREATE_DATE < t_YYYYMMDD
		and not exists (
			select COMPANY_CODE from DMM_SAP001_BOM
			where COMPANY_CODE = nCOMPANY_CODE
			and CREATE_DATE = t_YYYYMMDD
			and PLANT = DMM_RPT004_BOMMAC_D.PLANT
			and FG = DMM_RPT004_BOMMAC_D.FG
			and ISSUE_PLANT = DMM_RPT004_BOMMAC_D.ISSUE_PLANT
			and COMPONENT = DMM_RPT004_BOMMAC_D.COMPONENT
		);
	commit;
	*/

	---------------------------------------------------------------------------------------------
	--處理 DMM_RPT003_FG_D - FG_QTY (FCST)
	iTracePoint := 250;
	update DMM_RPT003_FG_D
		set FG_QTY = (
			select QTY from DMM_SAP006_FGFCST
			where PERIOD = tPERIOD_C
			and COMPANY_CODE = DMM_RPT003_FG_D.COMPANY_CODE
			and PLANT = DMM_RPT003_FG_D.PLANT
			and FG = DMM_RPT003_FG_D.FG
			and YW_DATE = DMM_RPT003_FG_D.DATE_KEY
			and CREATE_DATE = t_YYYYMMDD )
	where COMPANY_CODE = nCOMPANY_CODE and DATE_KEY >= t_YYYYMMDD and CREATE_DATE <= t_YYYYMMDD;
	commit;
	--處理FG Qty (PAST)
	iTracePoint := 255;
	update DMM_RPT003_FG_D
		set FG_QTY = (
			select QTY from DMM_SAP007_FG101
			where COMPANY_CODE = DMM_RPT003_FG_D.COMPANY_CODE
			and PLANT = DMM_RPT003_FG_D.PLANT
			and FG = DMM_RPT003_FG_D.FG
			and DATE_KEY = DMM_RPT003_FG_D.DATE_KEY
		)
	where COMPANY_CODE = nCOMPANY_CODE and DATE_KEY = to_char(to_date(t_YYYYMMDD,'yyyymmdd') - 1,'yyyymmdd');
	commit;
	---------------------------------------------------------------------------------------------
	--處理 check 報表資料 (2008/12/18 minhorng add)
	iTracePoint := 280;
	delete from DMM_SAP002_INT_PART_AVG1 where COMPANY_CODE = nCOMPANY_CODE;
	commit;
	iTracePoint := 285;
	insert into DMM_SAP002_INT_PART_AVG1 (
		COMPANY_CODE, ISSUE_PLANT, COMPONENT, DIFF_AVG, ABS_DIFF_AVG, SN
	)
	select COMPANY_CODE, ISSUE_PLANT, COMPONENT, DIFF_AVG, ABS_DIFF_AVG, rownum
	from (
		select COMPANY_CODE, ISSUE_PLANT, COMPONENT,
			round(AVG((MAC_USD - MAC_USD_P) / MAC_USD_P),6) as DIFF_AVG,
			abs(round(AVG((MAC_USD - MAC_USD_P) / MAC_USD_P),6)) as ABS_DIFF_AVG
		from DMM_SAP002_INT_PART
		where COMPANY_CODE = nCOMPANY_CODE
		and CREATE_DATE = t_YYYYMMDD
		and YW_DATE != t_YYYYMMDD
		and MAC_USD_P != 0
		group by COMPANY_CODE, ISSUE_PLANT, COMPONENT
		order by abs(round(AVG((MAC_USD - MAC_USD_P) / MAC_USD_P),6)) desc
	);
	commit;
	iTracePoint := 290;
	delete from DMM_SAP002_INT_TOP_HISTORY where COMPANY_CODE = nCOMPANY_CODE and CREATE_DATE = t_YYYYMMDD;
	commit;
	iTracePoint := 293;
	delete from DMM_SAP002_INT_TOP_HISTORY where COMPANY_CODE = nCOMPANY_CODE
		and CREATE_DATE <= to_char(to_date(t_YYYYMMDD,'yyyymmdd') - 7,'yyyymmdd');
	commit;
	iTracePoint := 295;
	insert into DMM_SAP002_INT_TOP_HISTORY (
		CREATE_DATE, COMPANY_CODE, ISSUE_PLANT, COMPONENT, DIFF_AVG, ABS_DIFF_AVG, SN
	)
	select t_YYYYMMDD, COMPANY_CODE, ISSUE_PLANT, COMPONENT, DIFF_AVG, ABS_DIFF_AVG, SN
	from DMM_SAP002_INT_PART_AVG1
	where COMPANY_CODE = nCOMPANY_CODE
	and SN <= 20;
	commit;
	---------------------------------------------------------------------------------------------
	--處理週報 (每週星期一)
	-- 2008/12/22 改認每週星期五
	iTracePoint := 300;
	if tDAY_OF_WK = '5' then
		cCHK1 := ' ';
		cCHK2 := ' ';

		--清舊的或非實際值 (週報: DMM_RPT001_FG_W)
		iTracePoint := 310;
		delete from DMM_RPT001_FG_W where COMPANY_CODE = nCOMPANY_CODE and PERIOD = tPERIOD_C;
		commit;
		delete from DMM_RPT001_FG_W where COMPANY_CODE = nCOMPANY_CODE and PERIOD <> YYYYWW
			and CREATE_DATE <= t_YYYYMMDD;
		commit;

		--清 DMM_RPT002_BOM_W 本週避免重複 (週報: DMM_RPT002_BOM_W)
		iTracePoint := 320;
		delete from DMM_RPT002_BOM_W where COMPANY_CODE = nCOMPANY_CODE and PERIOD = tPERIOD_C;
		commit;

		--insert  DMM_RPT002_BOM_W
		iTracePoint := 330;
		insert into DMM_RPT002_BOM_W
			SELECT AL1.PERIOD, nvl(AL2.YW_DATE,AL1.CREATE_DATE) as YW_DATE,
				AL1.COMPANY_CODE, AL1.PLANT, AL1.FG, AL1.SN, AL1.LV, AL1.SFG, AL1.ALT_GRP,
				decode(AL1.ALT_GRP, null, 100, nvl(AL1.BOM_USAGE,0)) as BOM_USAGE, AL1.ITEM_NO, AL1.COMPONENT,
				AL1.ISSUE_PLANT, AL1.MTL_GRP, AL1.REQD_QTY, AL1.ROW_LV,
				nvl(AL3.PART_TYPE, 'N') as USI_CONT, AL4.MPN,
				AL4.VENDOR_CODE, AL4.QTA, AL2.MAC_LOC, AL2.MAC_USD, AL2.MAC_LOC_P, AL2.MAC_USD_P,
				AL4.INFOREC_LOC, AL4.INFOREC_USD, AL4.INFOREC_LOC_P, AL4.INFOREC_USD_P, AL2.INFOREC_USED,
				nvl(AL2.YYYYWW, AL1.PERIOD) as YYYYWW, AL1.CREATE_DATE
			FROM DMM_SAP001_BOM AL1, DMM_SAP002_INT_PART AL2, DMM_OTH001_LOA AL3, DMM_SAP003_QTA_INF AL4
			WHERE AL1.PERIOD = AL2.PERIOD (+) AND AL1.COMPANY_CODE = AL2.COMPANY_CODE (+)
			AND AL1.ISSUE_PLANT = AL2.ISSUE_PLANT (+) AND AL1.COMPONENT = AL2.COMPONENT (+)
			AND AL1.CREATE_DATE = AL2.CREATE_DATE (+)
			AND AL2.PERIOD = AL4.PERIOD (+) AND AL2.COMPANY_CODE = AL4.COMPANY_CODE (+)
			AND AL2.ISSUE_PLANT = AL4.PLANT (+) AND AL2.COMPONENT = AL4.COMPONENT (+)
			AND AL2.YYYYWW = AL4.YYYYWW (+) AND AL2.CREATE_DATE = AL4.CREATE_DATE (+)
			AND AL2.COMPONENT = AL3.PART_NO (+)
			AND AL1.COMPANY_CODE = nCOMPANY_CODE and AL1.PERIOD = tPERIOD_C and AL1.CREATE_DATE = t_YYYYMMDD;
		commit;

		--處理本週資料 - DMM_RPT001_FG_W - (當週須比上週資料; 而以後預估週次須與當週比)
		iTracePoint := 340;
		cCHK1 := ' ';
		cCHK2 := ' ';
		for REC1 in (
			select PERIOD, COMPANY_CODE, PLANT, FG, USI_CONT, YYYYWW, YW_DATE, CREATE_DATE,
				nvl(sum(round(BOM_USAGE * QTA * MAC_USD * REQD_QTY / 10000,6)),0) as COST_MAC,
				nvl(sum(round(BOM_USAGE * QTA * INFOREC_USD * REQD_QTY / 10000,6)),0) as INFOREC_MAC,
				nvl(sum(round(BOM_USAGE * QTA * MAC_LOC * REQD_QTY / 10000,6)),0) as COST_MAC_LOC,
				nvl(sum(round(BOM_USAGE * QTA * INFOREC_LOC * REQD_QTY / 10000,6)),0) as INFOREC_MAC_LOC
			from (
				select AL1.PERIOD, AL1.COMPANY_CODE, AL1.PLANT, AL1.FG,
					decode(AL1.ALT_GRP, null, 100, AL1.BOM_USAGE) as BOM_USAGE,
					round(AL1.REQD_QTY / 10000,6) as REQD_QTY, nvl(AL2.YYYYWW, AL1.PERIOD) as YYYYWW,
					nvl(AL2.YW_DATE, AL1.CREATE_DATE) as YW_DATE,
					nvl(AL3.PART_TYPE, 'N') as USI_CONT,
					AL4.QTA, AL2.MAC_USD, AL2.INFOREC_USD, AL2.MAC_LOC, AL2.INFOREC_LOC, AL1.CREATE_DATE
					from DMM_SAP001_BOM AL1, DMM_SAP002_INT_PART AL2, DMM_OTH001_LOA AL3, DMM_SAP003_QTA_INF AL4
					where AL1.PERIOD = AL2.PERIOD (+) and AL1.COMPANY_CODE = AL2.COMPANY_CODE (+)
					and AL1.ISSUE_PLANT = AL2.ISSUE_PLANT (+) and AL1.COMPONENT = AL2.COMPONENT (+)
					and AL1.CREATE_DATE = AL2.CREATE_DATE (+)
					and AL2.PERIOD = AL4.PERIOD (+) and AL2.COMPANY_CODE = AL4.COMPANY_CODE (+)
					and AL2.ISSUE_PLANT = AL4.PLANT (+) and AL2.COMPONENT = AL4.COMPONENT (+)
					and AL2.YYYYWW = AL4.YYYYWW (+) and AL2.CREATE_DATE = AL4.CREATE_DATE (+)
					and AL2.COMPONENT = AL3.PART_NO (+)
					and AL1.COMPANY_CODE = nCOMPANY_CODE and AL1.PERIOD = tPERIOD_C and AL1.CREATE_DATE = t_YYYYMMDD
			)
			group by PERIOD, COMPANY_CODE, PLANT, FG, USI_CONT, YYYYWW, YW_DATE, CREATE_DATE
			order by PERIOD, COMPANY_CODE, PLANT, FG, USI_CONT, YYYYWW
		) loop
			cCHK2 := trim(REC1.PERIOD) || trim(REC1.COMPANY_CODE) || trim(REC1.PLANT) || trim(REC1.FG) || trim(REC1.USI_CONT);
			if REC1.PERIOD = REC1.YYYYWW then
				--當週值, 做為以後預估週次的比對基準
				tCOST_MAC := REC1.COST_MAC;
				tINFOREC_MAC := REC1.INFOREC_MAC;
				tCOST_MAC_LOC := REC1.COST_MAC_LOC;
				tINFOREC_MAC_LOC := REC1.INFOREC_MAC_LOC;
				--抓上週值來當本週的比對基準, 若無資料則放本週
				begin
					select * into tCOST_MAC_P, tINFOREC_MAC_P, tCOST_MAC_LOC_P, tINFOREC_MAC_LOC_P from (
						select COST_MAC, INFOREC_MAC, COST_MAC_LOC, INFOREC_MAC_LOC from DMM_RPT001_FG_W
							where COMPANY_CODE = REC1.COMPANY_CODE
							and PLANT = REC1.PLANT
							and FG = REC1.FG
							and USI_CONT = REC1.USI_CONT
							and PERIOD = tPERIOD_P
					) where rownum <= 1;
				exception
					when others then
						-- 上週有不同 USI_CONT 有值則放 0, 都無才放本週
						begin
							select * into tCOST_MAC_P from (
								select COST_MAC from DMM_RPT001_FG_W
									where COMPANY_CODE = REC1.COMPANY_CODE
									and PLANT = REC1.PLANT
									and FG = REC1.FG
									and USI_CONT != REC1.USI_CONT
									and PERIOD = tPERIOD_P
							) where rownum <= 1;
							tCOST_MAC_P := 0;
							tINFOREC_MAC_P := 0;
							tCOST_MAC_LOC_P := 0;
							tINFOREC_MAC_LOC_P := 0;
						exception
							when others then
								tCOST_MAC_P := tCOST_MAC;
								tINFOREC_MAC_P := tINFOREC_MAC;
								tCOST_MAC_LOC_P := tCOST_MAC_LOC;
								tINFOREC_MAC_LOC_P := tINFOREC_MAC_LOC;
						end;
				end;
			else
				--用當週值做為以後預估週次的比對基準
				tCOST_MAC_P := tCOST_MAC;
				tINFOREC_MAC_P := tINFOREC_MAC;
				tCOST_MAC_LOC_P := tCOST_MAC_LOC;
				tINFOREC_MAC_LOC_P := tINFOREC_MAC_LOC;
			end if;
			--檢查是否已經有值
			begin
				select * into tCREATE_DATE from (
					select CREATE_DATE from DMM_RPT001_FG_W
						where COMPANY_CODE = REC1.COMPANY_CODE
						and PLANT = REC1.PLANT
						and FG = REC1.FG
						and YYYYWW = REC1.YYYYWW
						and USI_CONT = REC1.USI_CONT
				) where rownum <= 1;
			exception
				when others then
					tCREATE_DATE := null;
			end;
			--insert table
			if tCREATE_DATE is null then
				insert into DMM_RPT001_FG_W (
					PERIOD, COMPANY_CODE, PLANT, FG, YYYYWW, COST_MAC, COST_MAC_P, INFOREC_MAC, INFOREC_MAC_P,
					USI_CONT, YW_DATE, COST_MAC_LOC, COST_MAC_LOC_P, INFOREC_MAC_LOC, INFOREC_MAC_LOC_P, CREATE_DATE
				) values (
					REC1.PERIOD, REC1.COMPANY_CODE, REC1.PLANT, REC1.FG, REC1.YYYYWW,
					REC1.COST_MAC,
					tCOST_MAC_P,
					REC1.INFOREC_MAC,
					tINFOREC_MAC_P,
					REC1.USI_CONT,
					REC1.YW_DATE,
					REC1.COST_MAC_LOC,
					tCOST_MAC_LOC_P,
					REC1.INFOREC_MAC_LOC,
					tINFOREC_MAC_LOC_P,
					REC1.CREATE_DATE
				);
				commit;
			end if;
		end loop;

		--處理FG Qty (FCST)
		iTracePoint := 350;
		update DMM_RPT001_FG_W
			set FG_QTY = (
				select sum(QTY) from DMM_SAP006_FGFCST
				where PERIOD = DMM_RPT001_FG_W.PERIOD
				and COMPANY_CODE = DMM_RPT001_FG_W.COMPANY_CODE
				and PLANT = DMM_RPT001_FG_W.PLANT
				and FG = DMM_RPT001_FG_W.FG
				and YYYYWW = DMM_RPT001_FG_W.YYYYWW
				and CREATE_DATE = t_YYYYMMDD
			)
		where COMPANY_CODE = nCOMPANY_CODE and PERIOD = tPERIOD_C and YYYYWW >= tPERIOD_C;
		commit;
		--處理FG Qty (PAST)
		iTracePoint := 355;
		select * into tDATE_KEY_F, tDATE_KEY_T from (
			select MIN(DATE_KEY), MAX(DATE_KEY) from DIMENSION_DATE where YYYYWW = tPERIOD_P
		);
		iTracePoint := 357;
		update DMM_RPT001_FG_W
			set FG_QTY = (
				select sum(QTY) from DMM_SAP007_FG101
				where COMPANY_CODE = DMM_RPT001_FG_W.COMPANY_CODE
				and PLANT = DMM_RPT001_FG_W.PLANT
				and FG = DMM_RPT001_FG_W.FG
				and DATE_KEY >= tDATE_KEY_F
				and DATE_KEY <= tDATE_KEY_T
			)
		where COMPANY_CODE = nCOMPANY_CODE and PERIOD = tPERIOD_P and YYYYWW = tPERIOD_P;
		commit;
		--建立 DMM_RPT001_FG_W_MAX
		delete from DMM_RPT001_FG_W_MAX where COMPANY_CODE = nCOMPANY_CODE;
		commit;
		insert into DMM_RPT001_FG_W_MAX
			select COMPANY_CODE, PLANT, FG, MAX(PERIOD)
			from DMM_RPT001_FG_W
			where COMPANY_CODE = nCOMPANY_CODE
			group by COMPANY_CODE, PLANT, FG;
		commit;
		--建立 DMM_RPT001_FG_W_HISTORY
		delete from DMM_RPT001_FG_W_HISTORY where PERIOD = tPERIOD_C and COMPANY_CODE = nCOMPANY_CODE;
		commit;
		insert into DMM_RPT001_FG_W_HISTORY
			select PERIOD, COMPANY_CODE, PLANT, FG, YYYYWW, sum(COST_MAC), sum(COST_MAC_P),
				sum(INFOREC_MAC), sum(INFOREC_MAC_P), 'X', YW_DATE,	sum(COST_MAC_LOC), sum(COST_MAC_LOC_P),
				sum(INFOREC_MAC_LOC), sum(INFOREC_MAC_LOC_P), CREATE_DATE, FG_QTY
			from DMM_RPT001_FG_W where COMPANY_CODE = nCOMPANY_CODE and PERIOD = tPERIOD_C
			group by PERIOD, COMPANY_CODE, PLANT, FG, YYYYWW, 'X', YW_DATE, CREATE_DATE, FG_QTY;
		commit;
		delete from DMM_RPT001_FG_W_HISTORY
			where PERIOD <= to_char(to_date(t_YYYYMMDD,'yyyymmdd') - 180,'iyyyiw')
			and COMPANY_CODE = nCOMPANY_CODE;
		commit;
	end if;

	-- 清昨天資料 ( *. 星期一的都要保留 !!)
	-- 2008/12/22 改星期五的要保留
	iTracePoint := 700;
	if tCREATE_DATE2 is not null and tDAY_OF_WK != '6' then
		iTracePoint := 710;
		delete from DMM_SAP001_BOM where COMPANY_CODE = nCOMPANY_CODE and CREATE_DATE = tCREATE_DATE2;
		commit;
		iTracePoint := 720;
		delete from DMM_SAP002_INT_PART where COMPANY_CODE = nCOMPANY_CODE and CREATE_DATE = tCREATE_DATE2;
		commit;
		iTracePoint := 730;
		delete from DMM_SAP003_QTA_INF where COMPANY_CODE = nCOMPANY_CODE and CREATE_DATE = tCREATE_DATE2;
		commit;
		iTracePoint := 740;
		delete from DMM_SAP004_PO where COMPANY_CODE = nCOMPANY_CODE and CREATE_DATE = tCREATE_DATE2;
		commit;
		iTracePoint := 750;
		delete from DMM_SAP005_MSG where COMPANY_CODE = nCOMPANY_CODE and CREATE_DATE = tCREATE_DATE2;
		commit;
		iTracePoint := 760;
		delete from DMM_SAP006_FGFCST where COMPANY_CODE = nCOMPANY_CODE and CREATE_DATE = tCREATE_DATE2;
		commit;
	end if;

	----------------------------------------------------------------------------------------------
	--處理不用資料 (每週星期六)
	iTracePoint := 800;
	if tDAY_OF_WK = '6' then     --處理不用資料 (每週星期六)
		--清除舊的 DMM_SAP001_BOM , DMM_RPT002_BOM_W , DMM_SAP006_FGFCST(非最大period者)
		iTracePoint := 810;
		FOR REC1 IN (
			select distinct COMPANY_CODE, PLANT, FG, PERIOD
			from DMM_RPT001_FG_W_MAX
			where COMPANY_CODE = nCOMPANY_CODE
		) loop
			iTracePoint := 811;
			delete from DMM_SAP001_BOM
				where PERIOD < REC1.PERIOD
				and COMPANY_CODE = REC1.COMPANY_CODE
				and PLANT = REC1.PLANT
				and FG = REC1.FG;
			commit;
			iTracePoint := 812;
			delete from DMM_SAP006_FGFCST
				where PERIOD < REC1.PERIOD
				and COMPANY_CODE = REC1.COMPANY_CODE
				and PLANT = REC1.PLANT
				and FG = REC1.FG;
			commit;
			iTracePoint := 813;
			delete from DMM_RPT002_BOM_W
				where PERIOD < REC1.PERIOD
				and COMPANY_CODE = REC1.COMPANY_CODE
				and PLANT = REC1.PLANT
				and FG = REC1.FG;
			commit;
		end loop;
		--清除舊的 DMM_SAP002_INT_PART , DMM_SAP003_QTA_INF,  DMM_SAP004_PO, DMM_SAP005_MSG (非最大period者)
		iTracePoint := 820;
		FOR REC1 IN (
			select max(PERIOD) as M_PERIOD
			from DMM_RPT001_FG_W_MAX
			where COMPANY_CODE = nCOMPANY_CODE
		) loop
			iTracePoint := 821;
			delete from DMM_SAP002_INT_PART
				where COMPANY_CODE = nCOMPANY_CODE
				and PERIOD < REC1.M_PERIOD
				and PERIOD not in (
					select distinct PERIOD from DMM_RPT001_FG_W_MAX
					where COMPANY_CODE = nCOMPANY_CODE
				);
			commit;
			iTracePoint := 822;
			delete from DMM_SAP003_QTA_INF
				where COMPANY_CODE = nCOMPANY_CODE
				and PERIOD < REC1.M_PERIOD
				and PERIOD not in (
					select distinct PERIOD from DMM_RPT001_FG_W_MAX
					where COMPANY_CODE = nCOMPANY_CODE
				);
			commit;
			iTracePoint := 823;
			delete from DMM_SAP004_PO
				where COMPANY_CODE = nCOMPANY_CODE
				and PERIOD < REC1.M_PERIOD
				and PERIOD not in (
					select distinct PERIOD from DMM_RPT001_FG_W_MAX
					where COMPANY_CODE = nCOMPANY_CODE
				);
			commit;
			iTracePoint := 824;
			delete from DMM_SAP005_MSG
				where COMPANY_CODE = nCOMPANY_CODE
				and PERIOD < REC1.M_PERIOD
				and PERIOD not in (
					select distinct PERIOD from DMM_RPT001_FG_W_MAX
					where COMPANY_CODE = nCOMPANY_CODE
				);
			commit;
		end loop;
	end if;
	commit;
EXCEPTION
  WHEN OTHERS THEN
    cErrorText := trim(cCHK2) || '>' || SQLERRM() ;
    MAIL_FILE_BIDBDBADMIN(in_to_name=>'minhorng@ms.usi.com.tw',subject   => '[DMM]PL/SQL PLSQL_DMM_RPT001_FG_W ERROR - Company: ' || nCOMPANY_CODE, message => '[PLSQL_DMM_RPT001_FG_W], The tracepoint is  ' || to_char(iTracePoint) || ' and ErrorText=' || cErrorText) ;
	rollback;
End PLSQL_DMM_RPT001_FG_W;
/

