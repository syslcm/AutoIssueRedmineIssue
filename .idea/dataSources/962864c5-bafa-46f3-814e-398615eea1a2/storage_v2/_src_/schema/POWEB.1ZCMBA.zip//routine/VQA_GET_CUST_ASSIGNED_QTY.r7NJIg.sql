create FUNCTION VQA_Get_Cust_Assigned_Qty(cmfr_name IN vqa_pdm_mfr_data.mfr_name%TYPE,cvendor_code IN vqa_vew001_ir_data.GLOBAL_VENDOR_CODE%TYPE) RETURN VARCHAR2
/*********************************************************************
  PROG-ID      : VQA_Get_Cust_Assigned_Qty
  Author       : Shuya
  Date         : 2008/01/17
**********************************************************************/ 
IS CURSOR pn_cur IS
    SELECT COUNT(DISTINCT al2.mfr_pn) AS cnt_pn
      FROM poweb.vqa_pdm_mfr_data al1,
        poweb.vqa_pdm_pn_data al2,
        poweb.vqa_vew001_ir_data al3
     WHERE(al2.usi_pn = al3.part_no
       AND al2.mfr_name = al1.mfr_name)
       AND ((al2.Phase='Customer Assignment'))     
       AND AL3.GLOBAL_VENDOR_CODE = cvendor_code
       AND al1.mfr_name = cmfr_name
     order by category;
cmessage VARCHAR2(5000);
BEGIN
  cmessage := '';
  FOR active_rec IN pn_cur  LOOP
    cmessage := active_rec.cnt_pn;
  END LOOP;

  RETURN cmessage;
END VQA_Get_Cust_Assigned_Qty;
/

