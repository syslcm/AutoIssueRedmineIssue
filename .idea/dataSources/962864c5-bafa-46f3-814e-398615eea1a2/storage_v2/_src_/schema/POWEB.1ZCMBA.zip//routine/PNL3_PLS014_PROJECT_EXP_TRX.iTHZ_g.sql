create PROCEDURE       pnl3_pls014_project_exp_trx (
   --Copy from PNL3_PLS011_EXPENSE_MAP_TRX,流程不同,不能套用
   inperiod   IN   VARCHAR2
)
AUTHID DEFINER
IS
   --2009/6/12 SALES/ADM的比率由營收來決定(SITE + PROFIT_CENTER + PROJECT)
   --          RD的營收除了EM的TOTAL金額為主之外,還必須去抓CON_SAP001_TRX的串COST
   --          CENTER的大類(directly,bg,corporation)以及project先分掉,剩餘的
   --          再用Revenue分掉(有回沖觀念,不論EM-CON_SAP001是多少均要分)
   --2009/10/22 和use談定後,針對PROJECT C3,C4 , GENERAL的要再分掉,因此現學現用TEMPOPARY TABLE  ,先將資料搬到此TEMP TABLE後再做運算到實體TABLE
   --          注意 不能用COMMMIT,否則資料會消失掉
   --          Profit center 90要進來,By Customer不進來的原因是在於:USER都用profit center的角度來看,而profit center90的net金額=0,所以不用看
   --          但by project則是用project的角度來看,所以不會等於0,因此要納進來看
   --2009/11/10 原使用temp table但是on commit,目前碰到Index長太快,所以改用on session來試試,因此打開commit指令
   a_year      pnl_msa001_em_data.yyyy%TYPE;
   a_month     pnl_msa001_em_data.MONTH%TYPE;
   a_ousd      pnl2_upl005_commission.amount_usd%TYPE;
   a_otwd      pnl2_upl005_commission.amount_twd%TYPE;
   a_usd       pnl2_upl005_commission.amount_usd%TYPE;
   a_twd       pnl2_upl005_commission.amount_twd%TYPE;
   t_usd       pnl2_upl005_commission.amount_usd%TYPE;
   t_twd       pnl2_upl005_commission.amount_twd%TYPE;
   n_usd       pnl2_upl005_commission.amount_usd%TYPE;
   n_twd       pnl2_upl005_commission.amount_twd%TYPE;
   a_amount    pnl3_trx001_copa.amt_twd%TYPE;
   l_amount    pnl3_trx001_copa.amt_twd%TYPE;
   t_amount    pnl3_trx001_copa.amt_twd%TYPE;
   a_counter   INTEGER;
   b_counter   INTEGER;
   a_rate      NUMBER (20, 10);
BEGIN
   a_year := SUBSTRB (inperiod, 1, 4);
   a_month := SUBSTRB (inperiod, 5, 6);

   DELETE FROM pnl3_trx005_collect_pn
         WHERE period = inperiod AND SOURCE = 'EXPENSE';

   COMMIT;
   t_amount := 0;

   --呆帳費用可以透過mapping table 'PNL2_MAP002_EM_PNL_CLASS'將其END DATE調整就不會進來改由user上傳(寫在最後面)來處理
   --原本的佣金和材料費用是含在sales和rd的某一個大項裡,所以在用headcount比率分攤前就要扣除這些金額和客戶後剩下的
   --金額再用headcount比率(不含上傳的客戶)來分攤掉
   --佣金,是放在SALES裡的Attribution directly,材料費用則是放在RD的Attribution directly,
   FOR rec1 IN (SELECT profit_center, company_code, amount, amount_usd,
                       r_kind, area1, area2, area3
                  FROM pnl_msa001_em_data a, pnl2_map002_em_pnl_class b
                 WHERE yyyy = a_year
                   AND MONTH = a_month
                   AND type_2 = 'Actual'
                   AND a.acct_id = b.acct_id
                   AND r_kind = 'PL02'
                    --AND profit_center = '0000000011'
                   -- AND area1 = '4'
                   AND area2 <> '3'
                   --AND area3 = '3'
                   --and area3 = '6'
                   AND SYSDATE BETWEEN start_date AND end_date)
   LOOP
   
      IF rec1.profit_center = '0000000034'
      THEN

            INSERT INTO pnl3_trx005_collect_pn_temp
                        (company_code, period, profit_center,
                         project_name, amt_local,
                         amt_usd,
                         amt_twd, SOURCE,
                         r_kind, area1, area2, area3,
                         create_date
                        )
                 VALUES (rec1.company_code, inperiod, rec1.profit_center,
                         'UABIT''S CUST', ROUND (rec1.amount * 1000, 5),
                         ROUND (rec1.amount_usd * 1000, 5),
                         ROUND (rec1.amount * 1000, 5), 'EXPENSE',
                         rec1.r_kind, rec1.area1, rec1.area2, rec1.area3,
                         SYSDATE
                        );

            COMMIT;

         
      ELSIF SUBSTR (rec1.profit_center, 1, 1) = 'G'
      THEN
         a_counter := 0;
      ELSE
         IF (rec1.area2 = '3')
         THEN                                                         --3指RD
            a_counter := 0;
         ELSE                                              --其他,指SALES或ADM
            a_counter := 0;

            FOR rec2 IN (SELECT project_name, rate
                           FROM pnl3_map010_projectexp_ratio
                          WHERE r_kind = rec1.r_kind
                            AND area1 = rec1.area1
                            AND area2 = rec1.area2
                            AND area3 = rec1.area3
                            AND company_code = rec1.company_code
                            AND profit_center = rec1.profit_center
                            AND period = inperiod
                            AND rate <> 0)
            LOOP
               a_counter := 1;

               INSERT INTO pnl3_trx005_collect_pn_temp
                           (company_code, period, profit_center,
                            project_name,
                            amt_local,
                            amt_usd,
                            amt_twd,
                            SOURCE, r_kind, area1, area2,
                            area3, create_date
                           )
                    VALUES (rec1.company_code, inperiod, rec1.profit_center,
                            rec2.project_name,
                            ROUND (rec1.amount * 1000 * rec2.rate, 5),
                            ROUND (rec1.amount_usd * 1000 * rec2.rate, 5),
                            ROUND (rec1.amount * 1000 * rec2.rate, 5),
                            'EXPENSE', rec1.r_kind, rec1.area1, rec1.area2,
                            rec1.area3, SYSDATE
                           );
              COMMIT;
            END LOOP;

            IF a_counter = 0
            THEN
               FOR rec2 IN (SELECT project_name, rate
                              FROM pnl3_map010_projectexp_pcratio
                             WHERE r_kind = rec1.r_kind
                               AND area1 = rec1.area1
                               AND area2 = rec1.area2
                               AND area3 = rec1.area3
                               AND period = inperiod
                               AND rate <> 0
                               --AND company_code = rec1.company_code
                               AND profit_center = rec1.profit_center)
               LOOP
                  a_counter := 1;

                  INSERT INTO pnl3_trx005_collect_pn_temp
                              (company_code, period,
                               profit_center, project_name,
                               amt_local,
                               amt_usd,
                               amt_twd,
                               SOURCE, r_kind, area1,
                               area2, area3, create_date
                              )
                       VALUES (rec1.company_code, inperiod,
                               rec1.profit_center, rec2.project_name,
                               ROUND (rec1.amount * 1000 * rec2.rate, 5),
                               ROUND (rec1.amount_usd * 1000 * rec2.rate, 5),
                               ROUND (rec1.amount * 1000 * rec2.rate, 5),
                               'EXPENSE', rec1.r_kind, rec1.area1,
                               rec1.area2, rec1.area3, SYSDATE
                              );
                 COMMIT;
               END LOOP;
            END IF;

            IF a_counter = 0
            THEN
               FOR rec2 IN (SELECT project_name, rate
                              FROM pnl3_map010_projectexp_wwratio
                             WHERE r_kind = rec1.r_kind
                               AND area1 = rec1.area1
                               AND area2 = rec1.area2
                               AND area3 = rec1.area3
                               AND period = inperiod
                               AND rate <> 0)
               --AND company_code = rec1.company_code
               --AND profit_center = rec1.profit_center)
               LOOP
                  INSERT INTO pnl3_trx005_collect_pn_temp
                              (company_code, period,
                               profit_center, project_name,
                               amt_local,
                               amt_usd,
                               amt_twd,
                               SOURCE, r_kind, area1,
                               area2, area3, create_date
                              )
                       VALUES (rec1.company_code, inperiod,
                               rec1.profit_center, rec2.project_name,
                               ROUND (rec1.amount * 1000 * rec2.rate, 5),
                               ROUND (rec1.amount_usd * 1000 * rec2.rate, 5),
                               ROUND (rec1.amount * 1000 * rec2.rate, 5),
                               'EXPENSE', rec1.r_kind, rec1.area1,
                               rec1.area2, rec1.area3, SYSDATE
                              );
                 COMMIT;
               END LOOP;
            END IF;
         END IF;
      END IF;
   END LOOP;

   /*
   *  薪資歸在directly這一塊,所以在MAPPING表 PNL2_MAP002_EM_PNL_CLASS 改MAPPING即可
   */
   FOR rec1 IN (SELECT   profit_center, company_code,
                         SUM (amount * 1000) amount,
                         SUM (amount_usd * 1000) amount_usd, r_kind, area1,
                         area2, area3
                    FROM pnl_msa001_em_data a, pnl2_map002_em_pnl_class b
                   WHERE yyyy = a_year
                     AND MONTH = a_month
                     AND type_2 = 'Actual'
                     AND a.acct_id = b.acct_id
                     AND r_kind = 'PL02'
                     -- AND profit_center = '0000000011'
                      --AND area1 = '4'
                     AND area2 = '3'
                     --AND area3 = '1'
                     --and area3 = '6'
                     AND SYSDATE BETWEEN start_date AND end_date
                GROUP BY profit_center,
                         company_code,
                         r_kind,
                         area1,
                         area2,
                         area3)
   LOOP
      a_otwd := rec1.amount;
      a_ousd := rec1.amount_usd;
      a_twd := 0;
      a_usd := 0;

      IF SUBSTR (rec1.profit_center, 1, 1) = 'G'
      THEN
         a_counter := 0;
      ELSE
         IF rec1.area3 = '2'
         THEN
            FOR rec2 IN (SELECT   project_name, em_account,
                                  SUM (amount_twd) amount_twd,
                                  SUM (amount_usd) amount_usd
                             FROM con_sap001_rd_expense_trx a,
                                  con_sap004_project_id b,
                                  kpi_map018_organization c
                            WHERE a.period = inperiod
                              AND a.profit_center = rec1.profit_center
                              AND a.company_code = rec1.company_code
                              AND a.order_no IS NOT NULL
                              AND a.cost_center IS NOT NULL
                              AND a.order_no = b.project_id
                              AND a.cost_center = c.sap_cost_center
                              AND a.period = c.period
                              AND c.em_account = 'Attribution directly'
                         GROUP BY project_name, em_account)
            LOOP
               a_twd := a_twd + (rec2.amount_twd * -1);
               a_usd := a_usd + (rec2.amount_usd * -1);

               INSERT INTO pnl3_trx005_collect_pn_temp
                           (company_code, period, profit_center,
                            project_name, amt_local,
                            amt_usd, amt_twd,
                            SOURCE, TYPE, r_kind, area1,
                            area2, area3, create_date
                           )
                    VALUES (rec1.company_code, inperiod, rec1.profit_center,
                            rec2.project_name, rec2.amount_twd * -1,
                            rec2.amount_usd * -1, rec2.amount_twd * -1,
                            'EXPENSE', 'CON', rec1.r_kind, rec1.area1,
                            rec1.area2, rec1.area3, SYSDATE
                           );
              COMMIT;
            END LOOP;
         ELSIF rec1.area3 = '3'
         THEN
            FOR rec2 IN (SELECT   project_name, em_account,
                                  SUM (amount_twd) amount_twd,
                                  SUM (amount_usd) amount_usd
                             FROM con_sap001_rd_expense_trx a,
                                  con_sap004_project_id b,
                                  kpi_map018_organization c
                            WHERE a.period = inperiod
                              AND a.profit_center = rec1.profit_center
                              AND a.company_code = rec1.company_code
                              AND a.order_no IS NOT NULL
                              AND a.cost_center IS NOT NULL
                              AND a.order_no = b.project_id
                              AND a.cost_center = c.sap_cost_center
                              AND a.period = c.period
                              AND c.em_account = 'Allocation-BG'
                         GROUP BY project_name, em_account)
            LOOP
               a_twd := a_twd + (rec2.amount_twd * -1);
               a_usd := a_usd + (rec2.amount_usd * -1);

               INSERT INTO pnl3_trx005_collect_pn_temp
                           (company_code, period, profit_center,
                            project_name, amt_local,
                            amt_usd, amt_twd,
                            SOURCE, TYPE, r_kind, area1,
                            area2, area3, create_date
                           )
                    VALUES (rec1.company_code, inperiod, rec1.profit_center,
                            rec2.project_name, rec2.amount_twd * -1,
                            rec2.amount_usd * -1, rec2.amount_twd * -1,
                            'EXPENSE', 'CON', rec1.r_kind, rec1.area1,
                            rec1.area2, rec1.area3, SYSDATE
                           );
              COMMIT;
            END LOOP;
         ELSIF rec1.area3 = '4'
         THEN
            FOR rec2 IN (SELECT   project_name, em_account,
                                  SUM (amount_twd) amount_twd,
                                  SUM (amount_usd) amount_usd
                             FROM con_sap001_rd_expense_trx a,
                                  con_sap004_project_id b,
                                  kpi_map018_organization c
                            WHERE a.period = inperiod
                              AND a.profit_center = rec1.profit_center
                              AND a.company_code = rec1.company_code
                              AND a.order_no IS NOT NULL
                              AND a.cost_center IS NOT NULL
                              AND a.order_no = b.project_id
                              AND a.cost_center = c.sap_cost_center
                              AND a.period = c.period
                              AND c.em_account IN
                                     ('Allocation-Corporate1',
                                      'Allocation-Corporate2')
                         GROUP BY project_name, em_account)
            LOOP
               a_twd := a_twd + (rec2.amount_twd * -1);
               a_usd := a_usd + (rec2.amount_usd * -1);

               INSERT INTO pnl3_trx005_collect_pn_temp
                           (company_code, period, profit_center,
                            project_name, amt_local,
                            amt_usd, amt_twd,
                            SOURCE, TYPE, r_kind, area1,
                            area2, area3, create_date
                           )
                    VALUES (rec1.company_code, inperiod, rec1.profit_center,
                            rec2.project_name, rec2.amount_twd * -1,
                            rec2.amount_usd * -1, rec2.amount_twd * -1,
                            'EXPENSE', 'CON', rec1.r_kind, rec1.area1,
                            rec1.area2, rec1.area3, SYSDATE
                           );
              COMMIT;
            END LOOP;
         END IF;

          --IF rec1.area3 = '2' OR rec1.area3 = '3' OR rec1.area3 = '4'
         -- THEN
         t_twd := a_otwd - a_twd;
         t_usd := a_ousd - a_usd;

         IF ABS (t_twd) > 100
         THEN
            --為了避免太多project出現,因此限定台幣差異超過100元的才要回沖
            a_counter := 0;

            FOR rec3 IN (SELECT project_name, rate
                           FROM pnl3_map009_rdexp_ratio
                          WHERE r_kind = rec1.r_kind
                            AND area1 = rec1.area1
                            AND area2 = rec1.area2
                            AND area3 = rec1.area3
                            AND company_code = rec1.company_code
                            AND profit_center = rec1.profit_center
                            AND period = inperiod
                            AND rate <> 0)
            LOOP
               a_counter := 1;

               INSERT INTO pnl3_trx005_collect_pn_temp
                           (company_code, period, profit_center,
                            project_name, amt_local,
                            amt_usd,
                            amt_twd, SOURCE,
                            r_kind, area1, area2, area3,
                            create_date
                           )
                    VALUES (rec1.company_code, inperiod, rec1.profit_center,
                            rec3.project_name, ROUND (t_twd * rec3.rate, 5),
                            ROUND (t_usd * rec3.rate, 5),
                            ROUND (t_twd * rec3.rate, 5), 'EXPENSE',
                            rec1.r_kind, rec1.area1, rec1.area2, rec1.area3,
                            SYSDATE
                           );
              COMMIT;
            END LOOP;

            --IF ABS (t_twd) > 100
            --THEN
            IF a_counter = 0
            THEN
               FOR rec3 IN (SELECT project_name, rate
                              FROM pnl3_map009_rdexp_pc_ratio
                             WHERE r_kind = rec1.r_kind
                               AND area1 = rec1.area1
                               AND area2 = rec1.area2
                               AND area3 = rec1.area3
                               AND period = inperiod
                               AND rate <> 0
                               --AND company_code = rec1.company_code
                               AND profit_center = rec1.profit_center)
               LOOP
                  a_counter := 1;

                  INSERT INTO pnl3_trx005_collect_pn_temp
                              (company_code, period,
                               profit_center, project_name,
                               amt_local,
                               amt_usd,
                               amt_twd, SOURCE,
                               r_kind, area1, area2,
                               area3, create_date
                              )
                       VALUES (rec1.company_code, inperiod,
                               rec1.profit_center, rec3.project_name,
                               ROUND (t_twd * rec3.rate, 5),
                               ROUND (t_usd * rec3.rate, 5),
                               ROUND (t_twd * rec3.rate, 5), 'EXPENSE',
                               rec1.r_kind, rec1.area1, rec1.area2,
                               rec1.area3, SYSDATE
                              );
                 COMMIT;
               END LOOP;
            END IF;
         --END IF;
         END IF;
      -- END IF;
      END IF;
   END LOOP;

   --COMMIT;
   FOR rec3 IN (SELECT *
                  FROM pnl3_trx005_collect_pn_temp)
   LOOP
      IF    SUBSTR (rec3.project_name, 1, 10) = 'Category 3'
         OR SUBSTR (rec3.project_name, 1, 10) = 'Category 4'
      THEN
         a_counter := 0;

         IF rec3.area2 = '3'                                          --   RD
         THEN
            a_counter := 0;

            FOR rec2 IN (SELECT project_name, rate
                           FROM pnl3_map009_rdexp_ratio
                          WHERE r_kind = rec3.r_kind
                            AND area1 = rec3.area1
                            AND area2 = rec3.area2
                            AND area3 = rec3.area3
                            AND company_code = rec3.company_code
                            AND profit_center = rec3.profit_center
                            AND period = rec3.period
                            AND rate <> 0)
            LOOP
               a_counter := 1;

               INSERT INTO pnl3_trx005_collect_pn
                           (company_code, period,
                            profit_center, r_kind, area1,
                            area2, area3,
                            amt_local,
                            amt_usd,
                            amt_twd,
                            end_customer_id, pdm_project,
                            SOURCE, TYPE, part_no,
                            acct_rate, project_name, create_date
                           )
                    VALUES (rec3.company_code, rec3.period,
                            rec3.profit_center, rec3.r_kind, rec3.area1,
                            rec3.area2, rec3.area3,
                            ROUND (rec3.amt_local * rec2.rate, 5),
                            ROUND (rec3.amt_usd * rec2.rate, 5),
                            ROUND (rec3.amt_twd * rec2.rate, 5),
                            rec3.end_customer_id, rec3.pdm_project,
                            rec3.SOURCE, rec3.TYPE, rec3.part_no,
                            rec3.acct_rate, rec2.project_name, SYSDATE
                           );
              COMMIT;
            END LOOP;

            --IF ABS (t_twd) > 100
            --THEN
            IF a_counter = 0
            THEN
               FOR rec2 IN (SELECT project_name, rate
                              FROM pnl3_map009_rdexp_pc_ratio
                             WHERE r_kind = rec3.r_kind
                               AND area1 = rec3.area1
                               AND area2 = rec3.area2
                               AND area3 = rec3.area3
                               AND period = rec3.period
                               AND profit_center = rec3.profit_center
                               AND rate <> 0)
               LOOP
                  a_counter := 1;

                  INSERT INTO pnl3_trx005_collect_pn
                              (company_code, period,
                               profit_center, r_kind, area1,
                               area2, area3,
                               amt_local,
                               amt_usd,
                               amt_twd,
                               end_customer_id, pdm_project,
                               SOURCE, TYPE, part_no,
                               acct_rate, project_name, create_date
                              )
                       VALUES (rec3.company_code, rec3.period,
                               rec3.profit_center, rec3.r_kind, rec3.area1,
                               rec3.area2, rec3.area3,
                               ROUND (rec3.amt_local * rec2.rate, 5),
                               ROUND (rec3.amt_usd * rec2.rate, 5),
                               ROUND (rec3.amt_twd * rec2.rate, 5),
                               rec3.end_customer_id, rec3.pdm_project,
                               rec3.SOURCE, rec3.TYPE, rec3.part_no,
                               rec3.acct_rate, rec2.project_name, SYSDATE
                              );
                  COMMIT;
               END LOOP;
            END IF;
         ELSE                                                        --   非RD
            a_counter := 0;
            FOR rec2 IN (SELECT project_name, rate
                           FROM pnl3_map010_projectexp_ratio
                          WHERE r_kind = rec3.r_kind
                            AND area1 = rec3.area1
                            AND area2 = rec3.area2
                            AND area3 = rec3.area3
                            AND company_code = rec3.company_code
                            AND profit_center = rec3.profit_center
                            AND period = rec3.period
                            AND rate <> 0)
            LOOP
               a_counter := 1;

               INSERT INTO pnl3_trx005_collect_pn
                           (company_code, period,
                            profit_center, r_kind, area1,
                            area2, area3,
                            amt_local,
                            amt_usd,
                            amt_twd,
                            end_customer_id, pdm_project,
                            SOURCE, TYPE, part_no,
                            acct_rate, project_name, create_date
                           )
                    VALUES (rec3.company_code, rec3.period,
                            rec3.profit_center, rec3.r_kind, rec3.area1,
                            rec3.area2, rec3.area3,
                            ROUND (rec3.amt_local * rec2.rate, 5),
                            ROUND (rec3.amt_usd * rec2.rate, 5),
                            ROUND (rec3.amt_twd * rec2.rate, 5),
                            rec3.end_customer_id, rec3.pdm_project,
                            rec3.SOURCE, rec3.TYPE, rec3.part_no,
                            rec3.acct_rate, rec2.project_name, SYSDATE
                           );
              COMMIT;
            END LOOP;

            IF a_counter = 0
            THEN
               FOR rec2 IN (SELECT project_name, rate
                              FROM pnl3_map010_projectexp_pcratio
                             WHERE r_kind = rec3.r_kind
                               AND area1 = rec3.area1
                               AND area2 = rec3.area2
                               AND area3 = rec3.area3
                               AND period = rec3.period
                               AND profit_center = rec3.profit_center
                               AND rate <> 0)
               LOOP
                  a_counter := 1;

                  INSERT INTO pnl3_trx005_collect_pn
                              (company_code, period,
                               profit_center, r_kind, area1,
                               area2, area3,
                               amt_local,
                               amt_usd,
                               amt_twd,
                               end_customer_id, pdm_project,
                               SOURCE, TYPE, part_no,
                               acct_rate, project_name, create_date
                              )
                       VALUES (rec3.company_code, rec3.period,
                               rec3.profit_center, rec3.r_kind, rec3.area1,
                               rec3.area2, rec3.area3,
                               ROUND (rec3.amt_local * rec2.rate, 5),
                               ROUND (rec3.amt_usd * rec2.rate, 5),
                               ROUND (rec3.amt_twd * rec2.rate, 5),
                               rec3.end_customer_id, rec3.pdm_project,
                               rec3.SOURCE, rec3.TYPE, rec3.part_no,
                               rec3.acct_rate, rec2.project_name, SYSDATE
                              );
                 COMMIT;
               END LOOP;
            END IF;

            IF a_counter = 0
            THEN
               FOR rec2 IN (SELECT project_name, rate
                              FROM pnl3_map010_projectexp_wwratio
                             WHERE r_kind = rec3.r_kind
                               AND area1 = rec3.area1
                               AND area2 = rec3.area2
                               AND area3 = rec3.area3
                               AND period = rec3.period
                               AND rate <> 0)
               LOOP
                  INSERT INTO pnl3_trx005_collect_pn
                              (company_code, period,
                               profit_center, r_kind, area1,
                               area2, area3,
                               amt_local,
                               amt_usd,
                               amt_twd,
                               end_customer_id, pdm_project,
                               SOURCE, TYPE, part_no,
                               acct_rate, project_name, create_date
                              )
                       VALUES (rec3.company_code, rec3.period,
                               rec3.profit_center, rec3.r_kind, rec3.area1,
                               rec3.area2, rec3.area3,
                               ROUND (rec3.amt_local * rec2.rate, 5),
                               ROUND (rec3.amt_usd * rec2.rate, 5),
                               ROUND (rec3.amt_twd * rec2.rate, 5),
                               rec3.end_customer_id, rec3.pdm_project,
                               rec3.SOURCE, rec3.TYPE, rec3.part_no,
                               rec3.acct_rate, rec2.project_name, SYSDATE
                              );
                 COMMIT;
               END LOOP;
            END IF;
         END IF;
      ELSIF SUBSTR (rec3.project_name, 1, 7) = 'GENERAL'
      THEN
         IF rec3.area2 = '3'
         THEN                                                         --   RD
            IF SUBSTR (rec3.profit_center, 1, 9) = '000000009'
            THEN
               IF rec3.project_name = 'GENERAL FOR COMMON APTD' THEN
                 rec3.project_name := 'GENERAL FOR PROFIT CENTER 90';
               END IF;
               INSERT INTO pnl3_trx005_collect_pn
                           (company_code, period,
                            profit_center, r_kind, area1,
                            area2, area3, amt_local,
                            amt_usd, amt_twd,
                            end_customer_id, pdm_project,
                            SOURCE, TYPE, part_no,
                            acct_rate, project_name,
                            project_type, pjm, project_l1,
                            project_l2, project_l3,
                            project_l4, project_l5,
                            project_l6, create_date
                           )
                    VALUES (rec3.company_code, rec3.period,
                            rec3.profit_center, rec3.r_kind, rec3.area1,
                            rec3.area2, rec3.area3, rec3.amt_local,
                            rec3.amt_usd, rec3.amt_twd,
                            rec3.end_customer_id, rec3.pdm_project,
                            rec3.SOURCE, rec3.TYPE, rec3.part_no,
                            rec3.acct_rate, rec3.project_name,
                            rec3.project_type, rec3.pjm, rec3.project_l1,
                            rec3.project_l2, rec3.project_l3,
                            rec3.project_l4, rec3.project_l5,
                            rec3.project_l6, SYSDATE
                           );
            ELSE
               a_counter := 0;

               FOR rec2 IN (SELECT project_name, rate
                              FROM pnl3_map009_rdexp_ratio
                             WHERE r_kind = rec3.r_kind
                               AND area1 = rec3.area1
                               AND area2 = rec3.area2
                               AND area3 = rec3.area3
                               AND company_code = rec3.company_code
                               AND profit_center = rec3.profit_center
                               AND period = rec3.period
                               AND rate <> 0)
               LOOP
                  a_counter := 1;

                  INSERT INTO pnl3_trx005_collect_pn
                              (company_code, period,
                               profit_center, r_kind, area1,
                               area2, area3,
                               amt_local,
                               amt_usd,
                               amt_twd,
                               end_customer_id, pdm_project,
                               SOURCE, TYPE, part_no,
                               acct_rate, project_name, create_date
                              )
                       VALUES (rec3.company_code, rec3.period,
                               rec3.profit_center, rec3.r_kind, rec3.area1,
                               rec3.area2, rec3.area3,
                               ROUND (rec3.amt_local * rec2.rate, 5),
                               ROUND (rec3.amt_usd * rec2.rate, 5),
                               ROUND (rec3.amt_twd * rec2.rate, 5),
                               rec3.end_customer_id, rec3.pdm_project,
                               rec3.SOURCE, rec3.TYPE, rec3.part_no,
                               rec3.acct_rate, rec2.project_name, SYSDATE
                              );
                 COMMIT;
               END LOOP;

               --IF ABS (t_twd) > 100
               --THEN
               IF a_counter = 0
               THEN
                  FOR rec2 IN (SELECT project_name, rate
                                 FROM pnl3_map009_rdexp_pc_ratio
                                WHERE r_kind = rec3.r_kind
                                  AND area1 = rec3.area1
                                  AND area2 = rec3.area2
                                  AND area3 = rec3.area3
                                  AND period = rec3.period
                                  AND profit_center = rec3.profit_center
                                  AND rate <> 0)
                  LOOP
                     a_counter := 1;

                     INSERT INTO pnl3_trx005_collect_pn
                                 (company_code, period,
                                  profit_center, r_kind,
                                  area1, area2, area3,
                                  amt_local,
                                  amt_usd,
                                  amt_twd,
                                  end_customer_id, pdm_project,
                                  SOURCE, TYPE, part_no,
                                  acct_rate, project_name, create_date
                                 )
                          VALUES (rec3.company_code, rec3.period,
                                  rec3.profit_center, rec3.r_kind,
                                  rec3.area1, rec3.area2, rec3.area3,
                                  ROUND (rec3.amt_local * rec2.rate, 5),
                                  ROUND (rec3.amt_usd * rec2.rate, 5),
                                  ROUND (rec3.amt_twd * rec2.rate, 5),
                                  rec3.end_customer_id, rec3.pdm_project,
                                  rec3.SOURCE, rec3.TYPE, rec3.part_no,
                                  rec3.acct_rate, rec2.project_name, SYSDATE
                                 );
                    COMMIT;
                  END LOOP;
               END IF;
            END IF;
         ELSE                                                        -- Non RD
            IF SUBSTR (rec3.profit_center, 1, 9) = '000000009'
            THEN
               INSERT INTO pnl3_trx005_collect_pn
                           (company_code, period,
                            profit_center, r_kind, area1,
                            area2, area3, amt_local,
                            amt_usd, amt_twd,
                            end_customer_id, pdm_project,
                            SOURCE, TYPE, part_no,
                            acct_rate, project_name,
                            project_type, pjm, project_l1,
                            project_l2, project_l3,
                            project_l4, project_l5,
                            project_l6, create_date
                           )
                    VALUES (rec3.company_code, rec3.period,
                            rec3.profit_center, rec3.r_kind, rec3.area1,
                            rec3.area2, rec3.area3, rec3.amt_local,
                            rec3.amt_usd, rec3.amt_twd,
                            rec3.end_customer_id, rec3.pdm_project,
                            rec3.SOURCE, rec3.TYPE, rec3.part_no,
                            rec3.acct_rate, rec3.project_name,
                            rec3.project_type, rec3.pjm, rec3.project_l1,
                            rec3.project_l2, rec3.project_l3,
                            rec3.project_l4, rec3.project_l5,
                            rec3.project_l6, SYSDATE
                           );
            ELSE
               a_counter := 0;

               FOR rec2 IN (SELECT project_name, rate
                              FROM pnl3_map010_projectexp_ratio
                             WHERE r_kind = rec3.r_kind
                               AND area1 = rec3.area1
                               AND area2 = rec3.area2
                               AND area3 = rec3.area3
                               AND company_code = rec3.company_code
                               AND profit_center = rec3.profit_center
                               AND period = rec3.period
                               AND rate <> 0)
               LOOP
                  a_counter := 1;

                  INSERT INTO pnl3_trx005_collect_pn
                              (company_code, period,
                               profit_center, r_kind, area1,
                               area2, area3,
                               amt_local,
                               amt_usd,
                               amt_twd,
                               end_customer_id, pdm_project,
                               SOURCE, TYPE, part_no,
                               acct_rate, project_name, create_date
                              )
                       VALUES (rec3.company_code, rec3.period,
                               rec3.profit_center, rec3.r_kind, rec3.area1,
                               rec3.area2, rec3.area3,
                               ROUND (rec3.amt_local * rec2.rate, 5),
                               ROUND (rec3.amt_usd * rec2.rate, 5),
                               ROUND (rec3.amt_twd * rec2.rate, 5),
                               rec3.end_customer_id, rec3.pdm_project,
                               rec3.SOURCE, rec3.TYPE, rec3.part_no,
                               rec3.acct_rate, rec2.project_name, SYSDATE
                              );
                 COMMIT;
               END LOOP;

               IF a_counter = 0
               THEN
                  FOR rec2 IN (SELECT project_name, rate
                                 FROM pnl3_map010_projectexp_pcratio
                                WHERE r_kind = rec3.r_kind
                                  AND area1 = rec3.area1
                                  AND area2 = rec3.area2
                                  AND area3 = rec3.area3
                                  AND period = rec3.period
                                  AND profit_center = rec3.profit_center
                                  AND rate <> 0)
                  LOOP
                     a_counter := 1;

                     INSERT INTO pnl3_trx005_collect_pn
                                 (company_code, period,
                                  profit_center, r_kind,
                                  area1, area2, area3,
                                  amt_local,
                                  amt_usd,
                                  amt_twd,
                                  end_customer_id, pdm_project,
                                  SOURCE, TYPE, part_no,
                                  acct_rate, project_name, create_date
                                 )
                          VALUES (rec3.company_code, rec3.period,
                                  rec3.profit_center, rec3.r_kind,
                                  rec3.area1, rec3.area2, rec3.area3,
                                  ROUND (rec3.amt_local * rec2.rate, 5),
                                  ROUND (rec3.amt_usd * rec2.rate, 5),
                                  ROUND (rec3.amt_twd * rec2.rate, 5),
                                  rec3.end_customer_id, rec3.pdm_project,
                                  rec3.SOURCE, rec3.TYPE, rec3.part_no,
                                  rec3.acct_rate, rec2.project_name, SYSDATE
                                 );
                    COMMIT;
                  END LOOP;
               END IF;

               IF a_counter = 0
               THEN
                  FOR rec2 IN (SELECT project_name, rate
                                 FROM pnl3_map010_projectexp_wwratio
                                WHERE r_kind = rec3.r_kind
                                  AND area1 = rec3.area1
                                  AND area2 = rec3.area2
                                  AND area3 = rec3.area3
                                  AND period = rec3.period
                                  AND rate <> 0)
                  LOOP
                     INSERT INTO pnl3_trx005_collect_pn
                                 (company_code, period,
                                  profit_center, r_kind,
                                  area1, area2, area3,
                                  amt_local,
                                  amt_usd,
                                  amt_twd,
                                  end_customer_id, pdm_project,
                                  SOURCE, TYPE, part_no,
                                  acct_rate, project_name, create_date
                                 )
                          VALUES (rec3.company_code, rec3.period,
                                  rec3.profit_center, rec3.r_kind,
                                  rec3.area1, rec3.area2, rec3.area3,
                                  ROUND (rec3.amt_local * rec2.rate, 5),
                                  ROUND (rec3.amt_usd * rec2.rate, 5),
                                  ROUND (rec3.amt_twd * rec2.rate, 5),
                                  rec3.end_customer_id, rec3.pdm_project,
                                  rec3.SOURCE, rec3.TYPE, rec3.part_no,
                                  rec3.acct_rate, rec2.project_name, SYSDATE
                                 );
                    COMMIT;
                  END LOOP;
               END IF;
            END IF;
         END IF;
      ELSE
         INSERT INTO pnl3_trx005_collect_pn
                     (company_code, period, profit_center,
                      r_kind, area1, area2, area3,
                      amt_local, amt_usd, amt_twd,
                      end_customer_id, pdm_project, SOURCE,
                      TYPE, part_no, acct_rate,
                      project_name, project_type, pjm,
                      project_l1, project_l2, project_l3,
                      project_l4, project_l5, project_l6,
                      create_date
                     )
              VALUES (rec3.company_code, rec3.period, rec3.profit_center,
                      rec3.r_kind, rec3.area1, rec3.area2, rec3.area3,
                      rec3.amt_local, rec3.amt_usd, rec3.amt_twd,
                      rec3.end_customer_id, rec3.pdm_project, rec3.SOURCE,
                      rec3.TYPE, rec3.part_no, rec3.acct_rate,
                      rec3.project_name, rec3.project_type, rec3.pjm,
                      rec3.project_l1, rec3.project_l2, rec3.project_l3,
                      rec3.project_l4, rec3.project_l5, rec3.project_l6,
                      SYSDATE
                     );
                     COMMIT;
      END IF;
   END LOOP;

   UPDATE pnl3_trx005_collect_pn
      SET pjm = (SELECT pjm
                   FROM cep_web002_project
                  WHERE project_name = pnl3_trx005_collect_pn.project_name)
    WHERE period = inperiod AND area1 = '4' AND pjm IS NULL;

   COMMIT;
   UPDATE pnl3_trx005_collect_pn
      SET project_l1 =
                   (SELECT project_l1
                      FROM cep_web002_project
                     WHERE project_name = pnl3_trx005_collect_pn.project_name)
    WHERE period = inperiod AND area1 = '4' AND project_l1 IS NULL;

   COMMIT;
   UPDATE pnl3_trx005_collect_pn
      SET project_l2 =
                   (SELECT project_l2
                      FROM cep_web002_project
                     WHERE project_name = pnl3_trx005_collect_pn.project_name)
    WHERE period = inperiod AND area1 = '4' AND project_l2 IS NULL;

   COMMIT;
   UPDATE pnl3_trx005_collect_pn
      SET project_l3 =
                   (SELECT project_l3
                      FROM cep_web002_project
                     WHERE project_name = pnl3_trx005_collect_pn.project_name)
    WHERE period = inperiod AND area1 = '4' AND project_l3 IS NULL;

   COMMIT;
   UPDATE pnl3_trx005_collect_pn
      SET project_l4 =
                   (SELECT project_l4
                      FROM cep_web002_project
                     WHERE project_name = pnl3_trx005_collect_pn.project_name)
    WHERE period = inperiod AND area1 = '4' AND project_l4 IS NULL;

   COMMIT;
   UPDATE pnl3_trx005_collect_pn
      SET project_l5 =
                   (SELECT project_l5
                      FROM cep_web002_project
                     WHERE project_name = pnl3_trx005_collect_pn.project_name)
    WHERE period = inperiod AND area1 = '4' AND project_l5 IS NULL;

   COMMIT;
   UPDATE pnl3_trx005_collect_pn
      SET project_l6 =
                   (SELECT project_l6
                      FROM cep_web002_project
                     WHERE project_name = pnl3_trx005_collect_pn.project_name)
    WHERE period = inperiod AND area1 = '4' AND project_l6 IS NULL;

   COMMIT;
END pnl3_pls014_project_exp_trx;
/

