create PROCEDURE       ROA_PLS006_GEN_ALLOC_TO_PC_V2 (
/* ********************************************************************
  PROG-ID      : ROA_PLS006_GEN_ALLOC_TO_PC_V2
  PROG-ACTION  : 
  Author       : Asan Chang
  Date         : 2017/06/01
  OA Number    : SAI071408
  Description  : Generate data of fixed assets
********************************************************************* 
* 2017/06/22 Asan Chang ref table:ROA_UPL008_ALLOC_TO_SITE
********************************************************************* 
* 2017/07/06 Asan Chang 比率找不到則優先用AS2_CODE = NOT0001
* 原先的corp2 用AS2_CODE =COP2001。AS2_CODE = NOT0001找不到才放PC= NO FOUND
********************************************************************* 
*/
   incompany    IN   VARCHAR2,
   YYYYMM       IN   VARCHAR2
)      
AUTHID DEFINER
IS     
   CURSOR FROM_DATA
   IS
   
   --[Version 1]
   --select *
   --from ROA_PST002_AFTER_OCC_AREA a
   --where a.COMPANY_CODE = incompany  
   --and a.PERIOD = YYYYMM
   --order by asset_no, asset_sub_no, Building; 
   
   --[Version 2]
   --select a.rowid,a.*, LPAD(b.ROA_PC, 10, '0') ROA_PC, b.PD ,b.ROA_PD,LPAD(b.PROFIT_CENTER, 10, '0') PROFIT_CENTER, b.EM_ACCOUNT,  b.CATEGORY
   --from ROA_PST002_AFTER_OCC_AREA a  left  join KPI_MAP018_ORGANIZATION b
   --on b.COMPANY_CODE = a.COMPANY_CODE AND a.PERIOD = b.PERIOD AND b.SAP_COST_CENTER = a.RECEIVER_COST_CENTER
   --where a.COMPANY_CODE = incompany 
   --and a.PERIOD = YYYYMM
   --order by asset_no, asset_sub_no, Building;
   
   --[Version 3]
   select aa.* ,LPAD(b.ROA_PC, 10, '0') ROA_PC, b.PD ,b.ROA_PD,LPAD(b.PROFIT_CENTER, 10, '0') PROFIT_CENTER, b.EM_ACCOUNT,  b.CATEGORY
   from
   (
   select a.*, decode(c.to_company_code,null,a.company_code, c.to_company_code) NEW_COMPANY_CODE
   from ROA_PST002_AFTER_OCC_AREA a  left join ROA_UPL008_ALLOC_TO_SITE c
   on a.COMPANY_CODE = c.COMPANY_CODE AND a.RECEIVER_COST_CENTER = c.COST_CENTER
   ) aa
   left  join KPI_MAP018_ORGANIZATION b
   on aa.NEW_COMPANY_CODE = b.COMPANY_CODE  AND aa.PERIOD = b.PERIOD
   AND aa.RECEIVER_COST_CENTER = b.SAP_COST_CENTER
   where aa.COMPANY_CODE = incompany
   and aa.PERIOD = YYYYMM  
   order by asset_no, asset_sub_no, Building;
   
   
      
   itracepoint         INTEGER;
   tmp_ALLOC_TYPE      VARCHAR(2);              --分攤方式 ex:01,02,03...
   tmp_PC              VARCHAR2(10 BYTE);
   tmp_WW_RATIO        NUMBER(15,2);
   tmp_LEGAL_RATIO     NUMBER(15,2);
   TMP_AMT1            NUMBER(15,5);
   TMP_AMT2            NUMBER(15,5);   
   TMP_TTL_MHRATE      Number(15,5);
   TMP_ROA_PD          VARCHAR(7);
   CORP2_NORMAL_CODE   VARCHAR(8);
   CORP2_NOFOUND_CODE  VARCHAR(8);  
   RATE_FLAG           VARCHAR(1);
   ------------------------sub function ------------------------
  PROCEDURE INSERT_DATA (
    in_COMPANY_CODE         IN VARCHAR2,
    in_ASSET_NO             IN VARCHAR2,
    in_ASSET_SUB_NO         IN VARCHAR2,
    in_SENDER_COST_CENTER   IN VARCHAR2,
    in_RECEIVER_COST_CENTER IN VARCHAR2,
    in_PC                   IN VARCHAR2,
    in_ALLOC_TYPE           IN VARCHAR2,
    in_OWN_TYPE             IN VARCHAR2,
    in_ACQ_VAL              IN NUMBER,
    in_BOOK_VAL             IN NUMBER,
    in_S_SEQ                IN VARCHAR2,
    in_ROA_PD               IN VARCHAR2
  ) IS
  BEGIN
   --(3)開始處理資料
     INSERT INTO ROA_PST003_ALLOC_TO_PC (
       COMPANY_CODE ,       
       PERIOD ,      
       ASSET_NO ,            
       ASSET_SUB_NO ,      
       SENDER_COST_CENTER ,  
       RECEIVER_COST_CENTER ,
       PC ,
       ALLOC_TYPE ,                   
       OWN_TYPE ,            
       ACQ_VAL ,          
       BOOK_VAL ,            
       S_SEQ, 
       FROM_COMPANY_CODE,
       ROA_PD
       ) VALUES (                                 
       incompany ,       
       YYYYMM ,      
       in_ASSET_NO ,            
       in_ASSET_SUB_NO ,      
       in_SENDER_COST_CENTER ,  
       in_RECEIVER_COST_CENTER ,
       in_PC ,
       in_ALLOC_TYPE ,                   
       in_OWN_TYPE ,            
       in_ACQ_VAL ,          
       in_BOOK_VAL ,            
       in_S_SEQ,
       in_COMPANY_CODE,
       in_ROA_PD
           );   
       COMMIT;
  END INSERT_DATA;
  ------------------------sub function ------------------------  
  
   ------------------------sub function2 ------------------------
  PROCEDURE INSERT_DATA2 (
    in_COMPANY_CODE         IN VARCHAR2,
    in_ASSET_NO             IN VARCHAR2,
    in_ASSET_SUB_NO         IN VARCHAR2,
    in_SENDER_COST_CENTER   IN VARCHAR2,
    in_RECEIVER_COST_CENTER IN VARCHAR2,
    in_PC                   IN VARCHAR2,
    in_ALLOC_TYPE           IN VARCHAR2,
    in_OWN_TYPE             IN VARCHAR2,
    in_ACQ_VAL              IN NUMBER,
    in_BOOK_VAL             IN NUMBER,
    in_S_SEQ                IN VARCHAR2,
    in_ROA_PD               IN VARCHAR2
  ) IS
  BEGIN
   --(3)開始處理資料
     INSERT INTO ROA_PST003_ALLOC_TO_PC (
       COMPANY_CODE ,       
       PERIOD ,      
       ASSET_NO ,            
       ASSET_SUB_NO ,      
       SENDER_COST_CENTER ,  
       RECEIVER_COST_CENTER ,
       PC ,
       ALLOC_TYPE ,                   
       OWN_TYPE ,            
       ACQ_VAL ,          
       BOOK_VAL ,            
       S_SEQ ,
       FROM_COMPANY_CODE,
       ROA_PD
       ) VALUES (                                 
       in_COMPANY_CODE,       
       YYYYMM ,      
       in_ASSET_NO ,            
       in_ASSET_SUB_NO ,      
       in_SENDER_COST_CENTER ,  
       in_RECEIVER_COST_CENTER ,
       in_PC ,
       in_ALLOC_TYPE ,                   
       in_OWN_TYPE ,            
       in_ACQ_VAL ,          
       in_BOOK_VAL ,            
       in_S_SEQ,
       incompany,
       in_ROA_PD
           );   
       COMMIT;
  END INSERT_DATA2;
  ------------------------sub function2 ------------------------   
  
  

   ------------------------sub function3 ------------------------
  PROCEDURE INSERT_DATA3 (
    in_PROFIT_CENTER             IN VARCHAR2,
    in_FUNCTION                  IN VARCHAR2,
    in_UNIT                      IN VARCHAR2,
    in_GROUP_ID                  IN VARCHAR2,
    in_DIVISION                  IN VARCHAR2,
    in_DEPARTMENT                IN VARCHAR2,
    in_SAP_COST_CENTER           IN VARCHAR2,
    in_BUDGET_COST               IN VARCHAR2,
    in_CATEGORY                  IN VARCHAR2,
    in_EM_ACCOUNT                IN VARCHAR2,
    in_LOCATION                  IN VARCHAR2,
    in_SECTIONS                  IN VARCHAR2,
    in_PD                        IN VARCHAR2,
    in_YEAR                      IN VARCHAR2, 
    in_ROA_PD                    IN VARCHAR2,
    in_ROA_PC                    IN VARCHAR2  
       
  ) IS
  BEGIN
   --(3)開始處理資料
     INSERT INTO ROA_MAP018_ORGANIZATION (
       COMPANY_CODE ,            
       PROFIT_CENTER,
       FUNCTION,
       UNIT,
       GROUP_ID,
       DIVISION,
       DEPARTMENT,
       SAP_COST_CENTER,
       BUDGET_COST,
       CATEGORY,
       EM_ACCOUNT,
       LOCATION,
       PERIOD,
       SECTIONS,
       CREATEDATE,
       PD,
       YEAR,
       ROA_PD,
       ROA_PC,
       CREATE_DATE
       ) VALUES (                                        
       incompany ,            
       in_PROFIT_CENTER,
       in_FUNCTION,
       in_UNIT,
       in_GROUP_ID,
       in_DIVISION,
       in_DEPARTMENT,
       in_SAP_COST_CENTER,
       in_BUDGET_COST,
       in_CATEGORY,
       in_EM_ACCOUNT,
       in_LOCATION,
       YYYYMM,
       in_SECTIONS,
       sysdate,
       in_PD,
       in_YEAR,
       in_ROA_PD,
       in_ROA_PC,
       sysdate
           );   
       COMMIT;
  END INSERT_DATA3;
  ------------------------sub function2 ------------------------ 
  
   PROCEDURE NO_RATE (
    in_COMPANY_CODE         IN VARCHAR2,
    in_FROM_COMPANY_CODE    IN VARCHAR2,
    in_PERIOD               IN VARCHAR2,
    in_ASSET_NO             IN VARCHAR2,
    in_ASSET_SUB_NO         IN VARCHAR2,
    in_SENDER_COST_CENTER   IN VARCHAR2,
    in_RECEIVER_COST_CENTER IN VARCHAR2,
    in_PC                   IN VARCHAR2,
    in_ALLOC_TYPE           IN VARCHAR2,
    in_OWN_TYPE             IN VARCHAR2,
    in_ACQ_VAL              IN NUMBER,
    in_BOOK_VAL             IN NUMBER,
    in_S_SEQ                IN VARCHAR2
  ) IS
  BEGIN
   --(3)開始處理資料
   FOR REC3 IN (
   select LPAD(PC, 10, '0') PC, RATIO FROM ROA_UPL006_ALLC_CORP2 WHERE COMPANY_CODE = in_COMPANY_CODE AND PERIOD = in_PERIOD AND RATIO > 0  AND AS2_CODE = CORP2_NOFOUND_CODE
   )
   LOOP                
     tmp_PC := REC3.PC;
     TMP_AMT1 := ROUND(in_ACQ_VAL / 100 * REC3.RATIO, 5);
     TMP_AMT2 := ROUND(in_BOOK_VAL / 100 * REC3.RATIO, 5);
     INSERT_DATA(in_FROM_COMPANY_CODE,in_ASSET_NO ,in_ASSET_SUB_NO ,in_SENDER_COST_CENTER ,in_RECEIVER_COST_CENTER ,
     tmp_PC , in_ALLOC_TYPE ,in_OWN_TYPE  , TMP_AMT1 ,TMP_AMT2 ,in_S_SEQ,CORP2_NOFOUND_CODE);            
   END LOOP; 
  END NO_RATE;
  ------------------------sub function2 ------------------------ 
       
BEGIN
     --(1)清除舊資料
     DELETE FROM ROA_PST003_ALLOC_TO_PC
     where PERIOD       = YYYYMM
     AND   COMPANY_CODE = incompany;
     COMMIT;  

     DELETE FROM ROA_PST003_ALLOC_TO_PC
     where PERIOD       = YYYYMM
     AND   FROM_COMPANY_CODE = incompany;
     COMMIT;       
           
           
     DELETE FROM ROA_MAP018_ORGANIZATION   
     where PERIOD       = YYYYMM
     AND   COMPANY_CODE = incompany;
     COMMIT; 
     
     
     --(2)取得分攤比率
     BEGIN
     select WW_RATIO ,LEGAL_RATIO  INTO tmp_WW_RATIO, tmp_LEGAL_RATIO  FROM ROA_UPL007_WW_LEGAL WHERE COMPANY_CODE = incompany
     AND PERIOD = YYYYMM; 
     EXCEPTION
       WHEN NO_DATA_FOUND THEN  -- catches all 'no data found' errors
       tmp_WW_RATIO := 0;   
       tmp_LEGAL_RATIO  := 0;     
     END;    
     
     CORP2_NORMAL_CODE := 'COP2001';
     CORP2_NOFOUND_CODE := 'NOT0001';    
    
  FOR REC1 IN FROM_DATA LOOP    

    --Update ROA_PST002_AFTER_OCC_AREA SET TO_NEXT = '' where rowid = REC1.rowid;
    COMMIT;
         if REC1.COMPANY_CODE = '9000' and REC1.COMPANY_CODE <> REC1.NEW_COMPANY_CODE then
           REC1.FROM_COMPANY_CODE := REC1.COMPANY_CODE;
           REC1.COMPANY_CODE := REC1.NEW_COMPANY_CODE;
         end if;
         
         if REC1.ROA_PC IS NOT NULL then    
           /*  ---------A---------  */
           tmp_ALLOC_TYPE := 'A1'; 
           tmp_PC := REC1.ROA_PC;
           INSERT_DATA(REC1.FROM_COMPANY_CODE, REC1.ASSET_NO ,REC1.ASSET_SUB_NO ,REC1.SENDER_COST_CENTER ,REC1.RECEIVER_COST_CENTER ,
           tmp_PC , tmp_ALLOC_TYPE ,REC1.OWN_TYPE , REC1.ACQ_VAL ,REC1.BOOK_VAL ,REC1.S_SEQ,'');
         ELSIF REC1.EM_ACCOUNT = 'Attribution directly' THEN  
           /*  ---------B---------  */
           tmp_ALLOC_TYPE := 'B1';
           tmp_PC := REC1.PROFIT_CENTER;
           INSERT_DATA(REC1.FROM_COMPANY_CODE,REC1.ASSET_NO ,REC1.ASSET_SUB_NO ,REC1.SENDER_COST_CENTER ,REC1.RECEIVER_COST_CENTER ,
           tmp_PC , tmp_ALLOC_TYPE ,REC1.OWN_TYPE , REC1.ACQ_VAL ,REC1.BOOK_VAL ,REC1.S_SEQ,'');          
         ELSIF REC1.EM_ACCOUNT = 'Allocation-Corporate3' THEN  
           /*  ---------C---------  */
           tmp_ALLOC_TYPE := 'C1';
           tmp_PC := '0000000093';
           INSERT_DATA(REC1.FROM_COMPANY_CODE,REC1.ASSET_NO ,REC1.ASSET_SUB_NO ,REC1.SENDER_COST_CENTER ,REC1.RECEIVER_COST_CENTER ,
           tmp_PC , tmp_ALLOC_TYPE ,REC1.OWN_TYPE , REC1.ACQ_VAL ,REC1.BOOK_VAL ,REC1.S_SEQ,'');           
         ELSIF REC1.EM_ACCOUNT = 'Allocation-Corporate2' and ( tmp_WW_RATIO = 0 and tmp_LEGAL_RATIO = 0 ) THEN  
           /*  ---------D---------  */        
           tmp_ALLOC_TYPE := 'D1'; 
           RATE_FLAG := 'F';             
           FOR REC3 IN (
           select LPAD(PC, 10, '0') PC, RATIO FROM ROA_UPL006_ALLC_CORP2 WHERE COMPANY_CODE = REC1.COMPANY_CODE AND PERIOD = REC1.PERIOD AND RATIO > 0  AND AS2_CODE = CORP2_NORMAL_CODE
           )
           LOOP   
             RATE_FLAG := 'T'; 
             tmp_PC := REC3.PC;
             TMP_AMT1 := ROUND(REC1.ACQ_VAL / 100 * REC3.RATIO, 5);
             TMP_AMT2 := ROUND(REC1.BOOK_VAL / 100 * REC3.RATIO, 5);
             INSERT_DATA(REC1.FROM_COMPANY_CODE,REC1.ASSET_NO ,REC1.ASSET_SUB_NO ,REC1.SENDER_COST_CENTER ,REC1.RECEIVER_COST_CENTER ,
             tmp_PC , tmp_ALLOC_TYPE ,REC1.OWN_TYPE , TMP_AMT1 ,TMP_AMT2 ,REC1.S_SEQ,CORP2_NORMAL_CODE);            
           END LOOP;  
           IF RATE_FLAG = 'F' THEN           
             NO_RATE (REC1.COMPANY_CODE,REC1.FROM_COMPANY_CODE,REC1.PERIOD,REC1.ASSET_NO ,REC1.ASSET_SUB_NO ,REC1.SENDER_COST_CENTER ,REC1.RECEIVER_COST_CENTER ,
             tmp_PC , tmp_ALLOC_TYPE ,REC1.OWN_TYPE , REC1.ACQ_VAL ,REC1.BOOK_VAL ,REC1.S_SEQ);
           end IF;
           
                      
         ELSIF REC1.EM_ACCOUNT = 'Allocation-Corporate2' and ( tmp_WW_RATIO > 0 and tmp_LEGAL_RATIO > 0  ) THEN  
           /*  ---------E---------  */            
           --------  
           RATE_FLAG := 'F';
           FOR REC3 IN (
           select LPAD(PC, 10, '0') PC, RATIO FROM ROA_UPL006_ALLC_CORP2 WHERE COMPANY_CODE = REC1.COMPANY_CODE AND PERIOD = REC1.PERIOD AND RATIO > 0  AND AS2_CODE = CORP2_NORMAL_CODE
           )
           LOOP         
             RATE_FLAG := 'T'; 
             tmp_ALLOC_TYPE := 'E1'; 
             tmp_PC := REC3.PC;
             TMP_AMT1 := ROUND(REC1.ACQ_VAL / 100 * REC3.RATIO / 100 * tmp_LEGAL_RATIO, 5);
             TMP_AMT2 := ROUND(REC1.BOOK_VAL / 100 * REC3.RATIO / 100 * tmp_LEGAL_RATIO, 5);
             INSERT_DATA(REC1.FROM_COMPANY_CODE,REC1.ASSET_NO ,REC1.ASSET_SUB_NO ,REC1.SENDER_COST_CENTER ,REC1.RECEIVER_COST_CENTER ,
             tmp_PC , tmp_ALLOC_TYPE ,REC1.OWN_TYPE , TMP_AMT1 ,TMP_AMT2 ,REC1.S_SEQ,CORP2_NORMAL_CODE);              
           END LOOP;           
           IF RATE_FLAG = 'F' THEN           
             NO_RATE (REC1.COMPANY_CODE,REC1.FROM_COMPANY_CODE,REC1.PERIOD,REC1.ASSET_NO ,REC1.ASSET_SUB_NO ,REC1.SENDER_COST_CENTER ,REC1.RECEIVER_COST_CENTER ,
             tmp_PC , tmp_ALLOC_TYPE ,REC1.OWN_TYPE , REC1.ACQ_VAL ,REC1.BOOK_VAL ,REC1.S_SEQ);
           end IF;          
           --------
             
           RATE_FLAG := 'F'; 
           FOR REC3 IN (
           select LPAD(PC, 10, '0') PC, RATIO  FROM ROA_UPL006_ALLC_CORP2 WHERE COMPANY_CODE = 'A999' AND PERIOD = REC1.PERIOD AND RATIO > 0  AND AS2_CODE = CORP2_NORMAL_CODE
           )
           LOOP  
             RATE_FLAG := 'T'; 
             tmp_ALLOC_TYPE := 'E2'; 
             tmp_PC := REC3.PC;
             TMP_AMT1 := ROUND(REC1.ACQ_VAL / 100 * REC3.RATIO / 100 * tmp_WW_RATIO, 5);
             TMP_AMT2 := ROUND(REC1.BOOK_VAL  / 100 * REC3.RATIO / 100 * tmp_WW_RATIO, 5);
             INSERT_DATA2('A999',REC1.ASSET_NO ,REC1.ASSET_SUB_NO ,REC1.SENDER_COST_CENTER ,REC1.RECEIVER_COST_CENTER ,
             tmp_PC , tmp_ALLOC_TYPE ,REC1.OWN_TYPE , TMP_AMT1 ,TMP_AMT2 ,REC1.S_SEQ,CORP2_NORMAL_CODE);              
           END LOOP; 
           IF RATE_FLAG = 'F' THEN           
             NO_RATE (REC1.COMPANY_CODE,REC1.FROM_COMPANY_CODE,REC1.PERIOD,REC1.ASSET_NO ,REC1.ASSET_SUB_NO ,REC1.SENDER_COST_CENTER ,REC1.RECEIVER_COST_CENTER ,
             tmp_PC , tmp_ALLOC_TYPE ,REC1.OWN_TYPE , REC1.ACQ_VAL ,REC1.BOOK_VAL ,REC1.S_SEQ);
           end IF;                       
         ELSIF ( REC1.EM_ACCOUNT = 'Allocation-Corporate1' OR REC1.EM_ACCOUNT = 'Allocation-BG' ) AND REC1.CATEGORY = 'OH' THEN   --OH         
            /*  ---------F---------  */  
           If REC1.ROA_PD IS NOT NULL then
             select sum(MH_RATE) INTO TMP_TTL_MHRATE FROM ROA_SAP002_CO_MH_RATE WHERE COMPANY_CODE = REC1.COMPANY_CODE AND PERIOD = REC1.PERIOD AND ROA_PD = REC1.ROA_PD;
             If TMP_TTL_MHRATE IS NOT NULL and TMP_TTL_MHRATE > 0 then  
             
               RATE_FLAG := 'F'; 
               FOR REC3 IN (
               select LPAD(PC, 10, '0') PC, MH_RATE FROM ROA_SAP002_CO_MH_RATE WHERE COMPANY_CODE = REC1.COMPANY_CODE AND PERIOD = REC1.PERIOD AND ROA_PD = REC1.ROA_PD    
               )
               LOOP  
                 RATE_FLAG := 'T'; 
                 tmp_ALLOC_TYPE := 'F1'; 
                 tmp_PC := REC3.PC;
                 TMP_AMT1 := ROUND(REC1.ACQ_VAL * REC3.MH_RATE , 5);
                 TMP_AMT2 := ROUND(REC1.BOOK_VAL * REC3.MH_RATE , 5);
                 INSERT_DATA(REC1.FROM_COMPANY_CODE,REC1.ASSET_NO ,REC1.ASSET_SUB_NO ,REC1.SENDER_COST_CENTER ,REC1.RECEIVER_COST_CENTER ,
                 tmp_PC , tmp_ALLOC_TYPE ,REC1.OWN_TYPE , TMP_AMT1 ,TMP_AMT2 ,REC1.S_SEQ,REC1.ROA_PD);             
               END LOOP; 
               IF RATE_FLAG = 'F' THEN           
                 NO_RATE (REC1.COMPANY_CODE,REC1.FROM_COMPANY_CODE,REC1.PERIOD,REC1.ASSET_NO ,REC1.ASSET_SUB_NO ,REC1.SENDER_COST_CENTER ,REC1.RECEIVER_COST_CENTER ,
                 tmp_PC , tmp_ALLOC_TYPE ,REC1.OWN_TYPE , REC1.ACQ_VAL ,REC1.BOOK_VAL ,REC1.S_SEQ);
               end IF;                            
                
             ELSIF TMP_TTL_MHRATE IS NULL OR TMP_TTL_MHRATE = 0 then    
               --RATE = 0 或是找不到比率
              
               --取得可以用的ROAPD
               TMP_ROA_PD := REC1.ROA_PD;    --
               LOOP    
                 If SUBSTR(TMP_ROA_PD,4,4) = '0000' then 
                   TMP_ROA_PD :=  SUBSTR(TMP_ROA_PD,1,1) || '000000';
                 ELSIF SUBSTR(TMP_ROA_PD,6,2) = '00' then 
                   TMP_ROA_PD :=  SUBSTR(TMP_ROA_PD,1,3) || '0000';
                 ELSIF SUBSTR(TMP_ROA_PD,6,2) <> '00' then
                   TMP_ROA_PD :=  SUBSTR(TMP_ROA_PD,1,5) || '00';
                 end if;
                 select sum(MH_RATE) INTO TMP_TTL_MHRATE FROM ROA_SAP002_CO_MH_RATE WHERE COMPANY_CODE = REC1.COMPANY_CODE AND PERIOD = REC1.PERIOD AND ROA_PD = TMP_ROA_PD;                
                 EXIT WHEN TMP_TTL_MHRATE > 0 OR TMP_ROA_PD = 'P000000';
               END LOOP;   
                 
               

               FOR REC3 IN (  
                select LPAD(PC, 10, '0') PC, MH_RATE FROM ROA_SAP002_CO_MH_RATE WHERE COMPANY_CODE = REC1.COMPANY_CODE AND PERIOD = REC1.PERIOD AND ROA_PD = TMP_ROA_PD
               )
               LOOP
                 tmp_PC := REC3.PC;  
                 tmp_ALLOC_TYPE := 'F2';  
                 TMP_AMT1 := ROUND(REC1.ACQ_VAL * REC3.MH_RATE , 5);
                 TMP_AMT2 := ROUND(REC1.BOOK_VAL * REC3.MH_RATE , 5);
                 INSERT_DATA(REC1.FROM_COMPANY_CODE,REC1.ASSET_NO ,REC1.ASSET_SUB_NO ,REC1.SENDER_COST_CENTER ,REC1.RECEIVER_COST_CENTER ,
                 tmp_PC , tmp_ALLOC_TYPE ,REC1.OWN_TYPE , TMP_AMT1 ,TMP_AMT2 ,REC1.S_SEQ,TMP_ROA_PD);              
               END LOOP;               
               
             end if; 
             
             
           else
             tmp_ALLOC_TYPE := 'F3';                 
             FOR REC3 IN (  
             select LPAD(PC, 10, '0') PC, MH_RATE FROM ROA_SAP002_CO_MH_RATE WHERE COMPANY_CODE = REC1.COMPANY_CODE AND PERIOD = REC1.PERIOD AND ROA_PD = 'P000000'
             )
             LOOP
               tmp_PC := REC3.PC;
               TMP_AMT1 := ROUND(REC1.ACQ_VAL * REC3.MH_RATE , 5);
               TMP_AMT2 := ROUND(REC1.BOOK_VAL * REC3.MH_RATE , 5);
               INSERT_DATA(REC1.FROM_COMPANY_CODE,REC1.ASSET_NO ,REC1.ASSET_SUB_NO ,REC1.SENDER_COST_CENTER ,REC1.RECEIVER_COST_CENTER ,
               tmp_PC , tmp_ALLOC_TYPE ,REC1.OWN_TYPE , TMP_AMT1 ,TMP_AMT2 ,REC1.S_SEQ,'P000000');              
             END LOOP;  
                      
           end if;
        
         
         ELSIF ( REC1.EM_ACCOUNT = 'Allocation-Corporate1' OR REC1.EM_ACCOUNT = 'Allocation-BG' ) AND REC1.CATEGORY <> 'OH'  THEN  --OP  
           /*  ---------G---------  */ 
           tmp_ALLOC_TYPE := 'G1';  
           RATE_FLAG := 'F';

           FOR REC3 IN ( 
             select * FROM HCA_UPL002_ALLOCATION_OP WHERE COMPANY_CODE = REC1.COMPANY_CODE AND PERIOD = REC1.PERIOD AND COST_CENTER = REC1.RECEIVER_COST_CENTER 
             AND ALLOCATION_RATIO > 0 
           )
           LOOP
             tmp_PC := REC3.PC;
             TMP_AMT1 := ROUND(REC1.ACQ_VAL * REC3.ALLOCATION_RATIO , 5);
             TMP_AMT2 := ROUND(REC1.BOOK_VAL * REC3.ALLOCATION_RATIO , 5);
             INSERT_DATA(REC1.FROM_COMPANY_CODE,REC1.ASSET_NO ,REC1.ASSET_SUB_NO ,REC1.SENDER_COST_CENTER ,REC1.RECEIVER_COST_CENTER ,
             tmp_PC , tmp_ALLOC_TYPE ,REC1.OWN_TYPE , TMP_AMT1 ,TMP_AMT2 ,REC1.S_SEQ,'');  
             RATE_FLAG := 'T';                      
           END LOOP; 
           IF RATE_FLAG = 'F' THEN           
             NO_RATE (REC1.COMPANY_CODE,REC1.FROM_COMPANY_CODE,REC1.PERIOD,REC1.ASSET_NO ,REC1.ASSET_SUB_NO ,REC1.SENDER_COST_CENTER ,REC1.RECEIVER_COST_CENTER ,
             tmp_PC , tmp_ALLOC_TYPE ,REC1.OWN_TYPE , REC1.ACQ_VAL ,REC1.BOOK_VAL ,REC1.S_SEQ);
           end IF;
           
                              
         else   
           /*  ---------H---------  */    
           tmp_ALLOC_TYPE := 'H1';
           tmp_PC :='NO FOUND';
           TMP_AMT1 := ROUND(REC1.ACQ_VAL  , 5);
           TMP_AMT2 := ROUND(REC1.BOOK_VAL  , 5);
           INSERT_DATA(REC1.FROM_COMPANY_CODE,REC1.ASSET_NO ,REC1.ASSET_SUB_NO ,REC1.SENDER_COST_CENTER ,REC1.RECEIVER_COST_CENTER ,
           tmp_PC , tmp_ALLOC_TYPE ,REC1.OWN_TYPE , TMP_AMT1 ,TMP_AMT2 ,REC1.S_SEQ,'');              
         end if;                      

    --Update ROA_PST002_AFTER_OCC_AREA SET TO_NEXT = 'S' where rowid = REC1.rowid;
    COMMIT;
      
  END LOOP; 
  
  
  FOR REC3 IN (  
  select * FROM KPI_MAP018_ORGANIZATION  WHERE COMPANY_CODE = incompany AND PERIOD = YYYYMM
  )
  LOOP
    INSERT_DATA3( REC3.PROFIT_CENTER,REC3.FUNCTION,REC3.UNIT,REC3.GROUP_ID,REC3.DIVISION,REC3.DEPARTMENT,REC3.SAP_COST_CENTER,
    REC3.BUDGET_COST,REC3.CATEGORY, REC3.EM_ACCOUNT,REC3.LOCATION,REC3.SECTIONS,REC3.PD,REC3.YEAR,REC3.ROA_PD,REC3.ROA_PC);         
  END LOOP;   

  --


END ROA_PLS006_GEN_ALLOC_TO_PC_V2;
/

