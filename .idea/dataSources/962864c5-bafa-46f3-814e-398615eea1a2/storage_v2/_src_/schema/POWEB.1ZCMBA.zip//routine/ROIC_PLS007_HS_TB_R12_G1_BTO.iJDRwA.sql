create PROCEDURE       ROIC_PLS007_HS_TB_R12_G1_BTO (
  t_YYYYMMDD in VARCHAR2
)
AUTHID DEFINER
is
/*********************************************************************
  PROG-ID      : ROIC_PLS007_HS_TB_R12_G1_BTO
  PROG-ACTION  : Trial Balance - 投資架構 Roll Up 12 Months (Site Combine Data)
  Author       : Patty
  Date         : 2019/05/16
  OA No.       : SAI097956
  Process      :
  1. Roll Up 12 Months (Group by COMPANY_CODE, PERIOD, GROUP1)
  2. Save Total/Average to table
  3. Only 'CONSOLIDATION'
**********************************************************************/
/*---------------------------------------------------------------------
---------------------------------------------------------------------*/
  sPROC_NAME         ROIC_PST000_LOG.PROC_NAME%TYPE;
  sRUN_SEQ           ROIC_PST000_LOG.RUN_SEQ%TYPE;
  sRUN_DESC          ROIC_PST000_LOG.RUN_DESC%TYPE;
  sPARAMETER_DESC    ROIC_PST000_LOG.PARAMETER_DESC%TYPE;
  w_AMOUNT_TWD2      ROIC_PST006_HS_TB_G1_BTO.AMOUNT_TWD2%TYPE;
  w_AMOUNT_USD2      ROIC_PST006_HS_TB_G1_BTO.AMOUNT_USD2%TYPE;
  w_AMOUNT_CNY2      ROIC_PST006_HS_TB_G1_BTO.AMOUNT_CNY2%TYPE; 
  s_PERIOD           ROIC_PST006_HS_TB_G1_BTO.PERIOD%TYPE;         
  t_PERIOD           ROIC_PST006_HS_TB_G1_BTO.PERIOD%TYPE;  
  w_DivCnt           NUMBER(06);
  w_VALID_YM         PNL_MAP006_SITE_MAPPING.ROIC_VALID_YM%TYPE;
  w_eYYYY            NUMBER(06);
  w_eMM              NUMBER(06);
  w_sYYYY            NUMBER(06);
  w_sMM              NUMBER(06);
             
BEGIN

  t_PERIOD := SUBSTR(t_YYYYMMDD,1,6);
  s_PERIOD := TO_CHAR(ADD_MONTHS(TO_DATE (CONCAT (t_PERIOD, '01'), 'YYYYMMDD'),'-11'),'YYYYMM');
  w_eYYYY  := SUBSTR(t_PERIOD,1,4);
  w_eMM    := SUBSTR(t_PERIOD,5,2);

  sPROC_NAME := 'ROIC_PLS007_HS_TB_R12_G1_BTO';
  sRUN_SEQ   := '000010';
  sRUN_DESC  := 'Start';
  sPARAMETER_DESC := CONCAT(CONCAT(CONCAT('s_PERIOD=',s_PERIOD),';t_PERIOD='),t_PERIOD);
 
  --Insert Log
  INSERT INTO ROIC_PST000_LOG
      ( PROC_NAME, RUN_SEQ, RUN_DESC, PARAMETER_DESC )
    VALUES
      ( sPROC_NAME, sRUN_SEQ, sRUN_DESC, sPARAMETER_DESC );
  Commit;

  DELETE FROM ROIC_PST009_HS_TBG1_ROLL_BTO 
          WHERE PERIOD = t_PERIOD;
  Commit;

  for REC1 in ( Select COMPANY_CODE
                FROM ROIC_PST006_HS_TB_G1_BTO   
               WHERE PERIOD = t_PERIOD
                 GROUP BY COMPANY_CODE
  ) loop

    BEGIN
      SELECT ROIC_VALID_YM INTO w_VALID_YM
        FROM PNL_MAP006_SITE_MAPPING
        WHERE COMPANY_CODE = REC1.COMPANY_CODE;
    EXCEPTION
      WHEN OTHERS THEN
           w_VALID_YM := t_PERIOD;
    END;

    w_DivCnt := 1;
    if w_VALID_YM <= s_PERIOD then
       w_DivCnt := 12;
    else
       if w_VALID_YM <= t_PERIOD then
          w_sYYYY  := SUBSTR(w_VALID_YM,1,4);
          w_sMM    := SUBSTR(w_VALID_YM,5,2);
          w_DivCnt := ( w_eYYYY * 12 + w_eMM ) - ( w_sYYYY * 12 + w_sMM ) + 1;
       end if;
    end if; 

    for REC2 in ( Select COMPANY_CODE, GROUP1, 
	               SUM(AMOUNT_TWD2) AS AMOUNT_TWD2, SUM(AMOUNT_USD2) AS AMOUNT_USD2, SUM(AMOUNT_CNY2) AS AMOUNT_CNY2
                FROM ROIC_PST006_HS_TB_G1_BTO   
               WHERE COMPANY_CODE = REC1.COMPANY_CODE
                 AND PERIOD >= s_PERIOD
		 AND PERIOD <= t_PERIOD   
                 AND RPT_TYPE = 'CONSOLIDATION'       
                 GROUP BY COMPANY_CODE, GROUP1
    ) loop

      INSERT INTO ROIC_PST009_HS_TBG1_ROLL_BTO
            ( COMPANY_CODE, PERIOD, GROUP1, TYPE, AMOUNT_TWD2, AMOUNT_USD2, AMOUNT_CNY2, DIVCNT     
            ) VALUES 
            ( REC2.COMPANY_CODE, t_PERIOD, REC2.GROUP1, 'TOT', REC2.AMOUNT_TWD2, REC2.AMOUNT_USD2, REC2.AMOUNT_CNY2, w_DivCnt );

      Commit;  

      w_AMOUNT_TWD2 := REC2.AMOUNT_TWD2 / w_DivCnt;
      w_AMOUNT_USD2 := REC2.AMOUNT_USD2 / w_DivCnt;
      w_AMOUNT_CNY2 := REC2.AMOUNT_CNY2 / w_DivCnt;

      INSERT INTO ROIC_PST009_HS_TBG1_ROLL_BTO
            ( COMPANY_CODE, PERIOD, GROUP1, TYPE, AMOUNT_TWD2, AMOUNT_USD2, AMOUNT_CNY2, DIVCNT     
            ) VALUES 
            ( REC2.COMPANY_CODE, t_PERIOD, REC2.GROUP1, 'AVG', w_AMOUNT_TWD2, w_AMOUNT_USD2, w_AMOUNT_CNY2, w_DivCnt );

      Commit;  

     end loop;     

  end loop;


  sRUN_SEQ   := '000020';
  sRUN_DESC  := 'End';

  --Insert Log
  INSERT INTO ROIC_PST000_LOG
      ( PROC_NAME, RUN_SEQ, RUN_DESC, PARAMETER_DESC )
    VALUES
      ( sPROC_NAME, sRUN_SEQ, sRUN_DESC, sPARAMETER_DESC );
  Commit;

END ROIC_PLS007_HS_TB_R12_G1_BTO;
/

