create PROCEDURE PLSQL_DCF_RPT_WEEKLY_LOA_2 (
  outRES OUT VARCHAR2
)
AUTHID DEFINER
is
  --轉USI_PRICE -> USI_PRICE_USD, 並比對IBM Price
  CURSOR C_DCF_RPT_WEEKLY_LOA is
    Select distinct IBM_PN, IBM_VENDOR_NO, IBM_PRICE, USI_PN, USI_VENDOR_NO, USI_CURRENCY, USI_PRICE, CUSTOMER
     From DCF_RPT_WEEKLY_LOA
    where USI_CURRENCY is Not Null
      and USI_PRICE is Not Null
      and IBM_PRICE is Not Null;

  --抓VMI (COMPANY: 1100)
  CURSOR C_RFQ_SAP_ZD047 is
    Select distinct A.VENDOR_ID, A.PART_NO
     From RFQ_SAP_ZD047 A, DCF_IBM_LOA_CURRENT B
    where A.PART_NO like B.USI_PN_LIKE || '%'
      and A.COMPANY_CODE = '1100';

  --USI Part存在AMPL,但不存在於RFQ / SAP Inforec者
  CURSOR C_SAP_AMPL is
    Select distinct
           A.PART_NO,
           B.IBM_PN, B.IBM_VENDOR_NO, B.COUNCIL_NAME, B.COMMODITY, B.IBM_PART_DESC,
           B.IBM_VENDOR, B.IBM_LAST_QUOTA, B.IBM_QUOTA, B.IBM_CONTRACT, B.CONTRACT_START,
           B.CONTRACT_END, B.IBM_LAST_PRICE, B.LAST_PRICE_DATE, B.IBM_PRICE, B.IBM_CURRENCY,
           B.PRICE_START, B.PRICE_END, B.IBM_LAST_LT, B.IBM_LT, B.IBM_MOQ, B.VENDOR_MULT, B.CUSTOMER
      From SAP_AMPL A, DCF_IBM_LOA_CURRENT B
     --where A.PART_NO like B.USI_PN_LIKE || '%'
     where TRIM(SUBSTRB(A.PART_NO,1,7)) = TRIM(B.USI_PN_LIKE)
       and NOT EXISTS (
	    Select C.USI_PN from DCF_RPT_WEEKLY_LOA C
		 where C.USI_PN = A.PART_NO
	  )
       and ( A.DELE_FLAG is NULL or A.DELE_FLAG = '' );

  --處理DCF_CONTROL_STOCK
  CURSOR C_DCF_CONTROL_STOCK is
    Select TRIM(MFG_SITE) as MFG_SITE, TRIM(PLANT) as PLANT, TRIM(MAX(POST_DATE_YYYY)) as POST_DATE_YYYY, TRIM(MAX(POST_DATE_MM)) as POST_DATE_MM
      From EGI0150_END_STORAGELOC
     where ( ( TRIM(MFG_SITE) = '1100' and TRIM(PLANT) in ('1110','1120','1130','1140') )
          or ( TRIM(MFG_SITE) = '1200' and TRIM(PLANT) in ('1210','1211','1220','1221','1230','1231','1240','1241','1250','1251') )
          or ( TRIM(MFG_SITE) = '1300' and TRIM(PLANT) in ('1310','1320') )
          or ( TRIM(MFG_SITE) = '1500' and TRIM(PLANT) in ('1510','1511') )
          or ( TRIM(MFG_SITE) = '2300' and TRIM(PLANT) in ('2310','2320','2330') )
           )
       and TRIM(PLANT) <> '9999'
       and POST_DATE_YYYY is not null
       and POST_DATE_MM is not null
     Group by TRIM(MFG_SITE), TRIM(PLANT);

   nUSI_PRICE_USD      DCF_RPT_WEEKLY_LOA.USI_PRICE_USD%TYPE;
   nPRICE_DIFF         DCF_RPT_WEEKLY_LOA.PRICE_DIFF%TYPE;
   nCOUNT              NUMBER(3);
   nQTA_DIFF           DCF_RPT_WEEKLY_LOA.QTA_DIFF%TYPE;
   nPRICE_DISCREPANCY  DCF_RPT_WEEKLY_LOA.PRICE_DISCREPANCY%TYPE;
   nLT_DIFF            DCF_RPT_WEEKLY_LOA.LT_DIFF%TYPE;
   nVMI                DCF_RPT_WEEKLY_LOA.VMI%TYPE;

 BEGIN
   outRES := 'START';

   --轉USI_PRICE -> USI_PRICE_USD, 並比對IBM Price
   nCOUNT := 0;
   FOR REC1 in C_DCF_RPT_WEEKLY_LOA LOOP
     outRES := 'C_DCF_RPT_WEEKLY_LOA:' || REC1.CUSTOMER || '<>' || REC1.IBM_PN || '<>'  || REC1.IBM_VENDOR_NO || '<>' || REC1.USI_PN || '<>' || REC1.USI_VENDOR_NO;
     If REC1.USI_CURRENCY = 'USD' Then
       nUSI_PRICE_USD := REC1.USI_PRICE;
     Else
       BEGIN
         Select * into nUSI_PRICE_USD From (
           Select Round( (A.EXCH_RATE * REC1.USI_PRICE / B.EXCH_RATE), 6)
             from DCF_EXCHANGE_RATE A, DCF_EXCHANGE_RATE B
            where A.TO_CURRENCY = 'TWD'
              and A.FROM_CURRENCY = REC1.USI_CURRENCY
              and B.TO_CURRENCY = 'TWD'
              and B.FROM_CURRENCY = 'USD'
         ) Where ROWNUM <= 1;
       EXCEPTION
         WHEN OTHERS THEN
           nUSI_PRICE_USD := Null;
       END;
     End If;
     If nUSI_PRICE_USD is Not Null Then
       nPRICE_DIFF := Round(nUSI_PRICE_USD - REC1.IBM_PRICE, 6);
     Else
       nPRICE_DIFF := Null;
     End If;
     Update DCF_RPT_WEEKLY_LOA
        set USI_PRICE_USD = nUSI_PRICE_USD,
            PRICE_DIFF = nPRICE_DIFF
      where USI_PN = REC1.USI_PN
        and USI_VENDOR_NO = REC1.USI_VENDOR_NO
        and IBM_PN = REC1.IBM_PN
        and IBM_VENDOR_NO = REC1.IBM_VENDOR_NO
        and CUSTOMER = REC1.CUSTOMER;
     nCOUNT := nCOUNT + 1;
     If nCOUNT = 10 Then
       Commit;
       nCOUNT := 0;
     End If;
   END LOOP;
   Commit;
   outRES := 'UPDATE C_DCF_RPT_WEEKLY_LOA OK';

   --抓VMI
   nCOUNT := 0;
   FOR REC1 in C_RFQ_SAP_ZD047 LOOP
     outRES := 'C_RFQ_SAP_ZD047:' || REC1.PART_NO || '<>'  || REC1.VENDOR_ID;
     Update DCF_RPT_WEEKLY_LOA set VMI = 'YES'
      where USI_PN = REC1.PART_NO
        and USI_VENDOR_NO = REC1.VENDOR_ID;
     nCOUNT := nCOUNT + 1;
     If nCOUNT = 10 Then
       Commit;
       nCOUNT := 0;
     End If;
   END LOOP;
   Commit;
   /*
   --將非VMI的Items,其VMI設為 NO
   Update DCF_RPT_WEEKLY_LOA set VMI = 'NO'
    where USI_PN is NOT NULL
      and USI_VENDOR_NO is NOT NULL
      and NVL(VMI,'NVL') <> 'YES';
   Commit;
   */
   outRES := 'UPDATE C_RFQ_SAP_ZD047 OK';

   --USI Part存在AMPL,但不存在於RFQ / SAP Inforec者
   nCOUNT := 0;
   FOR REC1 in C_SAP_AMPL LOOP
     outRES := 'C_SAP_AMPL:' || REC1.CUSTOMER || '<>' || REC1.IBM_PN || '<>' || REC1.PART_NO || '<>' || REC1.IBM_VENDOR_NO;
     If ( REC1.IBM_LAST_QUOTA is NULL ) or ( REC1.IBM_LAST_QUOTA = REC1.IBM_QUOTA ) Then
       nQTA_DIFF := 'NO';
     Else
       nQTA_DIFF := 'YES';
     End If;
     If REC1.IBM_LAST_PRICE is NULL Then
       nPRICE_DISCREPANCY := 0;
     Else
       nPRICE_DISCREPANCY := NVL(REC1.IBM_PRICE,0) - NVL(REC1.IBM_LAST_PRICE,0);
     End If;
     If REC1.IBM_LAST_LT is NULL Then
       nLT_DIFF := 0;
     Else
       nLT_DIFF := NVL(REC1.IBM_LT,0) - NVL(REC1.IBM_LAST_LT,0);
     End If;

     Insert into DCF_RPT_WEEKLY_LOA ( IBM_PN, USI_PN, COUNCIL_NAME, COMMODITY, IBM_PART_DESC,
                                      IBM_VENDOR, IBM_LAST_QUOTA, IBM_QUOTA, QTA_DIFF, IBM_VENDOR_NO,
                                      IBM_CONTRACT, CONTRACT_START, CONTRACT_END,
                                      IBM_LAST_PRICE, LAST_PRICE_DATE, IBM_PRICE,
                                      IBM_CURRENCY, PRICE_START, PRICE_END, PRICE_DISCREPANCY,
                                      IBM_LAST_LT, IBM_LT, LT_DIFF, IBM_MOQ, VENDOR_MULT, CUSTOMER )
          values ( REC1.IBM_PN, REC1.PART_NO, REC1.COUNCIL_NAME, REC1.COMMODITY, REC1.IBM_PART_DESC,
                   REC1.IBM_VENDOR, REC1.IBM_LAST_QUOTA, REC1.IBM_QUOTA, nQTA_DIFF, REC1.IBM_VENDOR_NO,
                   REC1.IBM_CONTRACT, REC1.CONTRACT_START, REC1.CONTRACT_END,
                   REC1.IBM_LAST_PRICE, REC1.LAST_PRICE_DATE, REC1.IBM_PRICE,
                   REC1.IBM_CURRENCY, REC1.PRICE_START, REC1.PRICE_END, nPRICE_DISCREPANCY,
                   REC1.IBM_LAST_LT, REC1.IBM_LT, nLT_DIFF, REC1.IBM_MOQ, REC1.VENDOR_MULT, REC1.CUSTOMER );
     nCOUNT := nCOUNT + 1;
     If nCOUNT = 10 Then
       Commit;
       nCOUNT := 0;
     End If;
   END LOOP;
   Commit;
   outRES := 'INSERT C_SAP_AMPL OK';

   --處理DCF_CONTROL_STOCK
   Delete from DCF_CONTROL_STOCK;
   Commit;
   outRES := 'Delete DCF_CONTROL_STOCK OK';
   nCOUNT := 0;
   FOR REC1 in C_DCF_CONTROL_STOCK LOOP
     outRES := 'C_DCF_CONTROL_STOCK:' || REC1.MFG_SITE || '<>' || REC1.PLANT || '<>' || REC1.POST_DATE_YYYY || '<>' || REC1.POST_DATE_MM;
     Insert into DCF_CONTROL_STOCK
            ( MFG_SITE, PLANT, POST_DATE_YYYY, POST_DATE_MM )
     values ( REC1.MFG_SITE, REC1.PLANT, REC1.POST_DATE_YYYY, REC1.POST_DATE_MM );
     nCOUNT := nCOUNT + 1;
     If nCOUNT = 10 Then
       Commit;
       nCOUNT := 0;
     End If;
   END LOOP;
   Commit;
   outRES := 'INSERT C_DCF_CONTROL_STOCK OK';

   outRES := 'SUCCESS';
 EXCEPTION
   WHEN OTHERS THEN
     outRES := TRIM(outRES) || ' - ' || TRIM(SUBSTR(SQLERRM,1,100));
     Rollback;
 END PLSQL_DCF_RPT_WEEKLY_LOA_2;
/

