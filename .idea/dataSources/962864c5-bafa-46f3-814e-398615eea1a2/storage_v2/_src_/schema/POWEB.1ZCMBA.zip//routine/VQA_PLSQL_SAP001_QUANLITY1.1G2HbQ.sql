create PROCEDURE         "VQA_PLSQL_SAP001_QUANLITY1" (
 inCompany  in VRT_SAP001_QUANLITY1_SITE.COMPANY_CODE%TYPE,
 f_YYYYMMDD in VARCHAR2,
 t_YYYYMMDD in VARCHAR2

)
IS

    /*---------------------------------------------*
	  Create date: 2008/02/26
	  Author    :  Susan Lin
      Purpase   :  Quality detail , 每月執行一次
     1. 抓 VQA_PLSQL_SAP001_QUANLITY1_T 資料
     2. Insert to VQA_PLSQL_SAP001_QUANLITY1 table
    *----------------------------------------------*/

 vPERCENTAGE_L1  VRT_MAP020_RATE_INDEX.PERCENTAGE%TYPE;
 vPERCENTAGE_L2  VRT_MAP020_RATE_INDEX.PERCENTAGE%TYPE;
 vPERCENTAGE_L3  VRT_MAP020_RATE_INDEX.PERCENTAGE%TYPE;
 vPERCENTAGE_L4  VRT_MAP020_RATE_INDEX.PERCENTAGE%TYPE;
 vCompany_code   VQA_SAP001_QUANLITY1_PN_T.COMPANY_CODE%TYPE;
 vPROCEE_YYYYMM  varchar2(6);
 iTracePoint     varchar2(100);
 cErrorText      varchar2(500);

BEGIN

  --抓上個月份
  iTracePoint := '100';
  vPROCEE_YYYYMM := TO_CHAR(ADD_MONTHS(SYSDATE, -1), 'YYYYMM');

  for REC1 in ( select YYYY, MM, SITE , COMPANY_CODE , PTYPE, MANUF, MATGROUP, MATNR, QKENNZAHL, DATE_TIME
                 from VQA_SAP001_QUANLITY1_PN_T
                 where SITE = inCompany
                   and YYYY = SUBSTRB(vPROCEE_YYYYMM,1,4)
                   and MM   = SUBSTRB(vPROCEE_YYYYMM,5,2)
                       ) loop
    if REC1.COMPANY_CODE is not null then
      iTracePoint := '110';
      vCompany_code := REC1.Company_code;
    end if;
  end loop;

  if vCOMPANY_CODE is null then
    --若沒抓到資料則寄 error mail
    iTracePoint := '120';
    cErrorText := 'No data!';
    MAIL_FILE_BIDBDBADMIN(in_to_name => 'shuchin@ms.usi.com.tw', subject => '[VQA] PL/SQL VQA_PLSQL_SAP001_QUANLITY1 ERROR', message => '[VQA_SAP001_QUANLITY1_PN_T], The tracepoint is  ' || iTracePoint || ' and ErrorText= ' || cErrorText) ;
  else


    --清除重覆資料
     DELETE FROM VQA_SAP001_QUANLITY1_PN
            WHERE SITE = inCompany
              and YYYY = SUBSTRB(vPROCEE_YYYYMM,1,4)
              and MM   = SUBSTRB(vPROCEE_YYYYMM,5,2);

    iTracePoint := '200';
    Insert into VQA_SAP001_QUANLITY1_PN (YYYY, MM, SITE , COMPANY_CODE , PTYPE, MANUF, MATGROUP, MATNR, QKENNZAHL, DATE_TIME)
        Select YYYY, MM, SITE , COMPANY_CODE , PTYPE, MANUF, MATGROUP, MATNR, QKENNZAHL, DATE_TIME
               from VQA_SAP001_QUANLITY1_PN_T
               where SITE = inCompany
                and YYYY = SUBSTRB(vPROCEE_YYYYMM,1,4)
                and MM   = SUBSTRB(vPROCEE_YYYYMM,5,2);









    --抓各階分數
    iTracePoint := '400';
    vPERCENTAGE_L1 := null;
    vPERCENTAGE_L2 := null;
    vPERCENTAGE_L3 := null;
    vPERCENTAGE_L4 := null;

    for REC1 in ( select LEVEL_S, PERCENTAGE from VRT_MAP020_RATE_INDEX
                   where INDEX_KEY = 'QUALITY' and TYPE = 'QA' ) loop
      if REC1.LEVEL_S = 'L1' then
        iTracePoint := '410';
        vPERCENTAGE_L1 := REC1.PERCENTAGE;
      elsif REC1.LEVEL_S = 'L2' then
        iTracePoint := '420';
        vPERCENTAGE_L2 := REC1.PERCENTAGE;
      elsif REC1.LEVEL_S = 'L3' then
        iTracePoint := '430';
        vPERCENTAGE_L3 := REC1.PERCENTAGE;
      elsif REC1.LEVEL_S = 'L4' then
        iTracePoint := '440';
        vPERCENTAGE_L4 := REC1.PERCENTAGE;
      end if;
    end loop;

    if vPERCENTAGE_L1 is null or vPERCENTAGE_L2 is null or vPERCENTAGE_L3 is null or vPERCENTAGE_L4 is null then
      --若沒抓到資料則寄 error mail
      iTracePoint := '450';
      cErrorText := 'vPERCENTAGE_L1 is ' || nvl(to_char(vPERCENTAGE_L1),'null') || ',vPERCENTAGE_L2 is ' || nvl(to_char(vPERCENTAGE_L2),'null') || ',vPERCENTAGE_L3 is ' || nvl(to_char(vPERCENTAGE_L3),'null') || ',vPERCENTAGE_L4 is ' || nvl(to_char(vPERCENTAGE_L4),'null');
      MAIL_FILE_BIDBDBADMIN(in_to_name => 'shuchin@ms.usi.com.tw', subject => '[VQA] PL/SQL VQA_SAP001_QUANLITY1_PN ERROR', message => '[VRT_MAP020_RATE_INDEX ], The tracepoint is  ' || iTracePoint || ' and ErrorText= ' || cErrorText) ;
    else

      --先清舊的資料以避免重覆
      iTracePoint := '500-' || vPROCEE_YYYYMM;
      delete from VQA_MAP000_SUMMARY_GRAD
       where TYPE = 'QA' and YYYY = substr(vPROCEE_YYYYMM,1,4) and MM = substr(vPROCEE_YYYYMM,5,2)
         and SITE = inCompany;
      commit;


      --放入上月分數 (summary for matGroup, 同時處理QUARTER )
      iTracePoint := '500';
     for REC1 in ( select a.YYYY, a.MM, a.SITE , a.COMPANY_CODE , a.PTYPE, a.MANUF, a.MATGROUP, a.QKENNZAHL as SCORE, to_char(SYSDATE, 'yyyymmddhh24miss') as DATE_TIME, b.QUARTER,
                   round(sum(QKENNZAHL)) as sum_score, sum(CNT) as tot_cnt,
                   round(round(sum(QKENNZAHL)) / sum(CNT) ) as SCORES
                         from VQA_SAP001_QUANLITY1_PN_T a, DIMENSION_DATE b
                         where a.YYYY = SUBSTRB(vPROCEE_YYYYMM,1,4) and
                               a.MM   = SUBSTRB(vPROCEE_YYYYMM,5,2) and
                               a.COMPANY_CODE = inCompany
                          Group by a.YYYY, a.MM, a.SITE , a.COMPANY_CODE , a.PTYPE, a.MANUF, a.MATGROUP,a.QKENNZAHL, '', b.QUARTER

     ) loop


        --放到 VQA_MAP000_SUMMARY_GRAD (by MATROUP
        iTracePoint := '500-' || REC1.SITE || '-' ||  REC1.MANUF || '-' || REC1.MATGROUP || '-' ||  SUBSTRB(vPROCEE_YYYYMM,1,6);
        insert into VQA_MAP000_SUMMARY_GRAD (
               SITE, MANUF, MATGROUP, TYPE, YYYY, MM, QUARTER, BUKRS, L1, GRADE_L1, L2, GRADE_L2, L3, GRADE_L3, L4, GRADE_L4
             ) values (
               REC1.SITE,
               REC1.MANUF,
               REC1.MATGROUP,
               REC1.PTYPE,
               REC1.YYYY,
               REC1.MM,
               REC1.QUARTER,
               REC1.COMPANY_CODE,
               'S0',
               round(REC1.SCORE * vPERCENTAGE_L1, 5),
               'Q0',
               round(REC1.SCORE * vPERCENTAGE_L2, 5),
               'QA',
               round(REC1.SCORE * vPERCENTAGE_L3, 5),
               'QA',
               round(REC1.SCORE * vPERCENTAGE_L4, 5)
             );
        commit;
      end loop;


	  --清除重覆資料
      iTracePoint := '600';
        DELETE  from VQA_SAP001_QUANLITY1_PN_T
         where SITE = inCompany
           and YYYY = SUBSTRB(vPROCEE_YYYYMM,1,4)
           and MM   = SUBSTRB(vPROCEE_YYYYMM,5,2);



    end if;

  end if;

EXCEPTION
   When OTHERS Then
    --有錯誤產生則寄mail
    cErrorText := SQLERRM();
    MAIL_FILE_BIDBDBADMIN(in_to_name => 'shuchin_lin@usiglobal.com', subject => '[VQA] PL/SQL VQA_PLSQL_SAP001_QUANLITY1 ERROR', message => '[VQA_SAP001_QUANLITY1_PN], The tracepoint is  ' || iTracePoint || ' and ErrorText= ' || cErrorText) ;

END VQA_PLSQL_SAP001_QUANLITY1;
/

