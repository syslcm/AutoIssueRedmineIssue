create PROCEDURE PLSQL_PTP_INTEL_WEEKLY_3 (
  outRES OUT VARCHAR2
)
AUTHID DEFINER
is
  --USI Part存在AMPL,但不存在於RFQ / SAP Inforec者
  CURSOR C_SAP_AMPL is
    Select distinct
           A.PART_NO,
           B.VERSION, B.COMMODITY, B.COMMODITY_SPECIALIST, B.INTEL_PART, B.INTEL_DESCRIPTION, B.SUPPLIER,
           B.WEIGHTED_COST, B.CONTRACT_PRICE, B.INTEL_ALLOCATION, B.EFFECTIVITY_DATE, B.INTEL_COMMENT,
           B.LAST_ALLOCATION, B.INTEL_LAST_PRICE, B.LAST_PRICE_DATE
      From SAP_AMPL A, PTP_INTEL_CURRENT B
     where A.COMPANY_CODE = '1500'
       and A.INT_PART_NO = B.INTEL_PART
       and NOT EXISTS (
	    Select C.USI_PN from PTP_INTEL_WEEKLY_REPORT C
	     where C.USI_PN = A.PART_NO
	  )
       and ( A.DELE_FLAG is NULL or A.DELE_FLAG = '' )
       and SUBSTRB(B.INTEL_PART,-3,3) <> 'XXX';

  CURSOR C_SAP_AMPL_2 is
    Select distinct
           A.PART_NO,
           B.VERSION, B.COMMODITY, B.COMMODITY_SPECIALIST, B.INTEL_PART, B.INTEL_DESCRIPTION, B.SUPPLIER,
           B.WEIGHTED_COST, B.CONTRACT_PRICE, B.INTEL_ALLOCATION, B.EFFECTIVITY_DATE, B.INTEL_COMMENT,
           B.LAST_ALLOCATION, B.INTEL_LAST_PRICE, B.LAST_PRICE_DATE
      From SAP_AMPL A, PTP_INTEL_CURRENT B
     where A.COMPANY_CODE = '1500'
       and A.INT_PART_NO like SUBSTRB(B.INTEL_PART,1,LENGTHB(B.INTEL_PART)-3) || '%'
       and NOT EXISTS (
	    Select C.USI_PN from PTP_INTEL_WEEKLY_REPORT C
	     where C.USI_PN = A.PART_NO
	  )
       and ( A.DELE_FLAG is NULL or A.DELE_FLAG = '' )
       and SUBSTRB(B.INTEL_PART,-3,3) = 'XXX';


  --求 SH QTA Begin & End Date
  CURSOR C_PTP_INTEL_WEEKLY_REPORT_0 is
    Select distinct USI_PN, USI_VENDOR_CODE
      From PTP_INTEL_WEEKLY_REPORT
     Where USI_PN is Not Null
       and USI_VENDOR_CODE is Not Null
       and USI_QUOTA_SH is Not Null
     Group by USI_PN, USI_VENDOR_CODE;

  --算 USI AVG PRICE (有Quota)
  CURSOR C_PTP_INTEL_WEEKLY_REPORT_1 is
    Select distinct INTEL_PART, WEIGHTED_COST
      From PTP_INTEL_WEEKLY_REPORT
     where USI_PN is Not Null
       and USI_QUOTA_SH > 0
       and USI_PRICE_USD is Not Null
     Group by INTEL_PART, WEIGHTED_COST;

  --算 USI AVG PRICE (無Quota)
  CURSOR C_PTP_INTEL_WEEKLY_REPORT_2 is
    Select distinct A.INTEL_PART, A.WEIGHTED_COST
      From PTP_INTEL_WEEKLY_REPORT A
     where A.USI_PN is Not Null
       and NVL(A.USI_QUOTA_SH,0) = 0
       and A.USI_PRICE_USD is Not Null
       and A.INTEL_PART Not in (
           Select distinct B.INTEL_PART
             From PTP_INTEL_WEEKLY_REPORT B
            where B.USI_PN is Not Null
              and B.USI_QUOTA_SH > 0
              and B.USI_PRICE_USD is Not Null )
     Group by A.INTEL_PART, A.WEIGHTED_COST;


   nCOUNT              NUMBER(5);
   nUSI_AVG_PRICE      PTP_INTEL_WEEKLY_REPORT.USI_AVG_PRICE%TYPE;
   nPRICE_DIFF_AVG     PTP_INTEL_WEEKLY_REPORT.PRICE_DIFF_AVG%TYPE;
   nQTA_D1_SH          PTP_INTEL_WEEKLY_REPORT.QTA_D1_SH%TYPE;
   nQTA_D2_SH          PTP_INTEL_WEEKLY_REPORT.QTA_D2_SH%TYPE;
   nPRICE_DIFF         PTP_INTEL_WEEKLY_REPORT.PRICE_DIFF%TYPE;
   nALLOCATION_DIFF    PTP_INTEL_WEEKLY_REPORT.ALLOCATION_DIFF%TYPE;

 BEGIN
   outRES := 'START';
   --USI Part存在AMPL,但不存在於RFQ / SAP Inforec者(非xxx)
   nCOUNT := 0;
   FOR REC1 in C_SAP_AMPL LOOP
     outRES := 'C_SAP_AMPL:' || REC1.PART_NO || REC1.INTEL_PART || REC1.SUPPLIER;
     nALLOCATION_DIFF := Null;
     If REC1.INTEL_ALLOCATION is Not Null and REC1.LAST_ALLOCATION is Not Null Then
       nALLOCATION_DIFF := REC1.INTEL_ALLOCATION - REC1.LAST_ALLOCATION;
     End If;

     Insert into PTP_INTEL_WEEKLY_REPORT
               ( VERSION, COMMODITY, COMMODITY_SPECIALIST, INTEL_PART,
                 INTEL_DESCRIPTION, SUPPLIER, WEIGHTED_COST, CONTRACT_PRICE,
                 INTEL_ALLOCATION, EFFECTIVITY_DATE, INTEL_COMMENT, USI_PN,
                 LAST_ALLOCATION, INTEL_LAST_PRICE, LAST_PRICE_DATE, ALLOCATION_DIFF
               ) values (
                 REC1.VERSION, REC1.COMMODITY, REC1.COMMODITY_SPECIALIST, REC1.INTEL_PART,
                 REC1.INTEL_DESCRIPTION, REC1.SUPPLIER, REC1.WEIGHTED_COST, REC1.CONTRACT_PRICE,
                 REC1.INTEL_ALLOCATION, REC1.EFFECTIVITY_DATE, REC1.INTEL_COMMENT, REC1.PART_NO,
                 REC1.LAST_ALLOCATION, REC1.INTEL_LAST_PRICE, REC1.LAST_PRICE_DATE, nALLOCATION_DIFF
               );
     nCOUNT := nCOUNT + 1;
     If nCOUNT = 100 Then
       Commit;
       nCOUNT := 0;
     End If;
   END LOOP;
   Commit;
   outRES := 'Upd C_SAP_AMPL OK';

   --USI Part存在AMPL,但不存在於RFQ / SAP Inforec者(xxx)
   nCOUNT := 0;
   FOR REC1 in C_SAP_AMPL_2 LOOP
     outRES := 'C_SAP_AMPL_2:' || REC1.PART_NO || REC1.INTEL_PART || REC1.SUPPLIER;
     nALLOCATION_DIFF := Null;
     If REC1.INTEL_ALLOCATION is Not Null and REC1.LAST_ALLOCATION is Not Null Then
       nALLOCATION_DIFF := REC1.INTEL_ALLOCATION - REC1.LAST_ALLOCATION;
     End If;

     Insert into PTP_INTEL_WEEKLY_REPORT
               ( VERSION, COMMODITY, COMMODITY_SPECIALIST, INTEL_PART,
                 INTEL_DESCRIPTION, SUPPLIER, WEIGHTED_COST, CONTRACT_PRICE,
                 INTEL_ALLOCATION, EFFECTIVITY_DATE, INTEL_COMMENT, USI_PN,
                 LAST_ALLOCATION, INTEL_LAST_PRICE, LAST_PRICE_DATE, ALLOCATION_DIFF
               ) values (
                 REC1.VERSION, REC1.COMMODITY, REC1.COMMODITY_SPECIALIST, REC1.INTEL_PART,
                 REC1.INTEL_DESCRIPTION, REC1.SUPPLIER, REC1.WEIGHTED_COST, REC1.CONTRACT_PRICE,
                 REC1.INTEL_ALLOCATION, REC1.EFFECTIVITY_DATE, REC1.INTEL_COMMENT, REC1.PART_NO,
                 REC1.LAST_ALLOCATION, REC1.INTEL_LAST_PRICE, REC1.LAST_PRICE_DATE, nALLOCATION_DIFF
               );
     nCOUNT := nCOUNT + 1;
     If nCOUNT = 100 Then
       Commit;
       nCOUNT := 0;
     End If;
   END LOOP;
   Commit;
   outRES := 'Upd C_SAP_AMPL_2 OK';

   --求 SH QTA Begin & End Date
   nCOUNT := 0;
   FOR REC1 in C_PTP_INTEL_WEEKLY_REPORT_0 LOOP
     outRES := 'C_PTP_INTEL_WEEKLY_REPORT_0:' || REC1.USI_PN || '<>' || REC1.USI_VENDOR_CODE;
     nQTA_D1_SH := Null;
     nQTA_D2_SH := Null;
     BEGIN
       Select * into nQTA_D1_SH, nQTA_D2_SH From (
           Select TO_CHAR(BEGIN_DATE,'YYYYMMDD'), TO_CHAR(END_DATE,'YYYYMMDD')
             from RFQ_QTA_ARR_CURR
            where COMPANY_CODE = '1500'
              and VENDOR_ID = REC1.USI_VENDOR_CODE
              and ( PART_NO = REC1.USI_PN or MPN_PART_NO = REC1.USI_PN )
         ) Where ROWNUM <= 1;
     EXCEPTION
       WHEN OTHERS THEN
         nQTA_D1_SH := Null;
         nQTA_D2_SH := Null;
     END;
     If nQTA_D1_SH is Null Then
       BEGIN
         Select * into nQTA_D1_SH, nQTA_D2_SH From (
             Select TO_CHAR(BEGIN_DATE,'YYYYMMDD'), TO_CHAR(END_DATE,'YYYYMMDD')
               from RFQ_QTA_ARR_PREV
              where COMPANY_CODE = '1500'
                and VENDOR_ID = REC1.USI_VENDOR_CODE
                and ( PART_NO = REC1.USI_PN or MPN_PART_NO = REC1.USI_PN )
           ) Where ROWNUM <= 1;
       EXCEPTION
         WHEN OTHERS THEN
           nQTA_D1_SH := Null;
           nQTA_D2_SH := Null;
       END;
     End If;
     Update PTP_INTEL_WEEKLY_REPORT
        set QTA_D1_SH = nQTA_D1_SH,
            QTA_D2_SH = nQTA_D2_SH
      where USI_PN = REC1.USI_PN
        and USI_VENDOR_CODE = REC1.USI_VENDOR_CODE;
     nCOUNT := nCOUNT + 1;
     If nCOUNT = 100 Then
       Commit;
       nCOUNT := 0;
     End If;
   END LOOP;
   Commit;
   outRES := 'Upd C_PTP_INTEL_WEEKLY_REPORT_0 OK';

   --算 USI AVG PRICE (有Quota)
   nCOUNT := 0;
   FOR REC1 in C_PTP_INTEL_WEEKLY_REPORT_1 LOOP
     outRES := 'C_PTP_INTEL_WEEKLY_REPORT_1:' || REC1.INTEL_PART;
     nUSI_AVG_PRICE := Null;
     BEGIN
       Select * into nUSI_AVG_PRICE From (
           Select Round(SUM(USI_PRICE_USD * USI_QUOTA_SH) / SUM(USI_QUOTA_SH),6)
             from PTP_INTEL_WEEKLY_REPORT
            where INTEL_PART = REC1.INTEL_PART
              and USI_PN is Not Null
              and USI_QUOTA_SH > 0
              and USI_PRICE_USD is Not Null
         ) Where ROWNUM <= 1;
     EXCEPTION
       WHEN OTHERS THEN
         nUSI_AVG_PRICE := Null;
     END;
     nPRICE_DIFF_AVG := Null;
     If nUSI_AVG_PRICE is Not Null Then
       nPRICE_DIFF_AVG := Round(nUSI_AVG_PRICE - NVL(REC1.WEIGHTED_COST,0),6);
     End If;
     Update PTP_INTEL_WEEKLY_REPORT
        set USI_AVG_PRICE = nUSI_AVG_PRICE,
            PRICE_DIFF_AVG = nPRICE_DIFF_AVG,
            QTA_FLAG = 'Y'
      where INTEL_PART = REC1.INTEL_PART
        and USI_AVG_PRICE is Null;
     nCOUNT := nCOUNT + 1;
     If nCOUNT = 100 Then
       Commit;
       nCOUNT := 0;
     End If;
   END LOOP;
   Commit;
   outRES := 'Upd C_PTP_INTEL_WEEKLY_REPORT_1 OK';

   --算 USI AVG PRICE (無Quota)
   nCOUNT := 0;
   FOR REC1 in C_PTP_INTEL_WEEKLY_REPORT_2 LOOP
     outRES := 'C_PTP_INTEL_WEEKLY_REPORT_2:' || REC1.INTEL_PART;
     nUSI_AVG_PRICE := Null;
     BEGIN
       Select * into nUSI_AVG_PRICE From (
           Select Round(SUM(USI_PRICE_USD * NVL(USI_QUOTA_SH,100)) / SUM(NVL(USI_QUOTA_SH,100)),6)
             from PTP_INTEL_WEEKLY_REPORT
            where INTEL_PART = REC1.INTEL_PART
              and USI_PN is Not Null
              and NVL(USI_QUOTA_SH,0) = 0
              and USI_PRICE_USD is Not Null
         ) Where ROWNUM <= 1;
     EXCEPTION
       WHEN OTHERS THEN
         nUSI_AVG_PRICE := Null;
     END;
     nPRICE_DIFF_AVG := Null;
     If nUSI_AVG_PRICE is Not Null Then
       nPRICE_DIFF_AVG := Round(nUSI_AVG_PRICE - NVL(REC1.WEIGHTED_COST,0),6);
     End If;
     Update PTP_INTEL_WEEKLY_REPORT
        set USI_AVG_PRICE = nUSI_AVG_PRICE,
            PRICE_DIFF_AVG = nPRICE_DIFF_AVG
      where INTEL_PART = REC1.INTEL_PART
        and USI_AVG_PRICE is Null;
     nCOUNT := nCOUNT + 1;
     If nCOUNT = 100 Then
       Commit;
       nCOUNT := 0;
     End If;
   END LOOP;
   Commit;
   outRES := 'Upd C_PTP_INTEL_WEEKLY_REPORT_2 OK';

   --處理 PTP_INTEL_CONTROL_PO
   Delete from PTP_INTEL_CONTROL_PO;
   Commit;
   outRES := 'Del PTP_INTEL_CONTROL_PO OK';
   Insert into PTP_INTEL_CONTROL_PO
    Select A.USI_PN, MAX(A.PO_CUTIN_DATE) as PO_CUTIN_DATE, Null
      From PTP_INTEL_USI_MANUAL A
     Where A.USI_PN is NOT NULL
       and A.PO_CUTIN_DATE is NOT NULL
       and Exists (
         Select B.COMPANY_CODE from POWEB_DAILY_PO B
          where B.PART_NO = A.USI_PN
            and B.COMPANY_CODE in ('1500')
       )
     Group by A.USI_PN;
   Commit;
   outRES := 'Upd PTP_INTEL_CONTROL_PO(PO) OK';
   Insert into PTP_INTEL_CONTROL_PO
    Select A.USI_PN, Null, MAX(A.SHIP_CUTIN_DATE) as SHIP_CUTIN_DATE
      From PTP_INTEL_USI_MANUAL A
     Where A.USI_PN is NOT NULL
       and A.SHIP_CUTIN_DATE is NOT NULL
       and Exists (
         Select B.COMPANY_CODE from POWEB_DAILY_PO B
          where B.PART_NO = A.USI_PN
            and B.COMPANY_CODE in ('1500')
       )
       and A.USI_PN NOT IN (
         Select C.USI_PN from PTP_INTEL_USI_MANUAL C
          where C.USI_PN is NOT NULL
            and C.PO_CUTIN_DATE is NOT NULL
       )
     Group by A.USI_PN;
   Commit;
   outRES := 'Upd PTP_INTEL_CONTROL_PO(SHIP) OK';

   outRES := 'SUCCESS';
 EXCEPTION
   WHEN OTHERS THEN
     outRES := TRIM(outRES) || ' - ' || TRIM(SUBSTR(SQLERRM,1,100));
     Rollback;
 END PLSQL_PTP_INTEL_WEEKLY_3;
/

