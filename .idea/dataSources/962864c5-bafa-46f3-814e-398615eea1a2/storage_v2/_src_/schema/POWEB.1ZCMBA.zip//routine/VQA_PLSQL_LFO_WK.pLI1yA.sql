create PROCEDURE vqa_plsql_lfo_wk
AUTHID DEFINER
IS
   f_yyyymmdd   VARCHAR2 (8);
   f_yyyyww     VARCHAR2 (6);
BEGIN
   f_yyyymmdd := TO_CHAR (SYSDATE - 7, 'YYYYMMDD');

   SELECT yyyyww
     INTO f_yyyyww
     FROM dimension_date
    WHERE date_key = f_yyyymmdd;

   --刪除資料
   DELETE FROM vqa_lfo_weekly
         WHERE yyyyww = f_yyyyww;

   -- insert
   INSERT INTO vqa_lfo_weekly
      SELECT   a.company_code, SUBSTR (f_yyyyww, 1, 4) AS yyyy, '',
               SUBSTR (f_yyyyww, 5, 2), a.mfr_name, a.component, a.mfr_pn,
               SUM (b.error_cnt) / SUM (a.wo_qty * a.qpa) * 1000000 AS lfo,
               TO_CHAR (SYSDATE, 'YYYYMMDDHH24MISS') AS date_time, f_yyyyww,
               SUM (b.error_cnt) AS error_cnt,
               SUM (a.wo_qty * a.qpa) AS total_cnt
          FROM vqa_lfo_wo_qpa a,
               (SELECT   company_code, SUBSTR (mo_number, 1, 7) AS mo_number,
                         mfr_name, usi_pn, mfr_pn, SUM (cnt) AS error_cnt
                    FROM vqa_lfo_error_cnt
                   WHERE repair_date IN (SELECT date_key
                                           FROM dimension_date
                                          WHERE yyyyww = f_yyyyww)
                GROUP BY company_code, mo_number, mfr_name, usi_pn, mfr_pn) b
         WHERE a.qpa > 0
           AND a.component = b.usi_pn
           AND a.mfr_name = b.mfr_name
           AND a.mfr_pn = b.mfr_pn
           AND a.company_code = b.company_code
           AND a.work_order = b.mo_number
      GROUP BY a.company_code, a.mfr_name, a.component, a.mfr_pn;

   COMMIT;

   INSERT INTO vqa_lfo_weekly
      SELECT   '0000', SUBSTR (f_yyyyww, 1, 4) AS yyyy, '',
               SUBSTR (f_yyyyww, 5, 2), a.mfr_name, a.component, a.mfr_pn,
               SUM (b.error_cnt) / SUM (a.wo_qty * a.qpa) * 1000000 AS lfo,
               TO_CHAR (SYSDATE, 'YYYYMMDDHH24MISS') AS date_time, f_yyyyww,
               SUM (b.error_cnt) AS error_cnt,
               SUM (a.wo_qty * a.qpa) AS total_cnt
          FROM vqa_lfo_wo_qpa a,
               (SELECT   company_code, SUBSTR (mo_number, 1, 7) AS mo_number,
                         mfr_name, usi_pn, mfr_pn, SUM (cnt) AS error_cnt
                    FROM vqa_lfo_error_cnt
                   WHERE repair_date IN (SELECT date_key
                                           FROM dimension_date
                                          WHERE yyyyww = f_yyyyww)
                GROUP BY company_code, mo_number, mfr_name, usi_pn, mfr_pn) b
         WHERE a.qpa > 0
           AND a.component = b.usi_pn
           AND a.mfr_name = b.mfr_name
           AND a.mfr_pn = b.mfr_pn
           AND a.company_code = b.company_code
           AND a.work_order = SUBSTR (b.mo_number, 1, 7)
      GROUP BY a.company_code, a.mfr_name, a.component, a.mfr_pn;

   COMMIT;

   update vqa_lfo_weekly set LFO = '1000000' WHERE YYYYWW = f_yyyyww AND LFO > 1000000;

   COMMIT;

END vqa_plsql_lfo_wk;
/

