create PROCEDURE plsql_pmi_eps_process_raw_data (
   incompany    IN   VARCHAR2,                                       --invalid
   f_yyyymmdd   IN   VARCHAR2,                                       --invalid
   t_yyyymmdd   IN   VARCHAR2                                        --invalid
)
IS
   itracepoint      INTEGER;
   cerrortext       VARCHAR2 (500);

   CURSOR c_main
   IS

      SELECT   *
          FROM pmi_sap001_emp_rawdata
         WHERE company_code = inCompany
      ORDER BY emp_no;

   v_main           c_main%ROWTYPE;
   c_company_code   VARCHAR2 (4);
   c_is_late        INTEGER;
   c_pass_date      VARCHAR2 (8);
   c_pass_time      VARCHAR2 (4);
   c_hour_of_day    INTEGER;
   c_org_id_40      pmi_sap002_org_relation.org_id_40%TYPE;
   c_org_id_45      pmi_sap002_org_relation.org_id_45%TYPE;
   c_org_id_50      pmi_sap002_org_relation.org_id_50%TYPE;
   c_org_id_55      pmi_sap002_org_relation.org_id_55%TYPE;
   c_org_id_60      pmi_sap002_org_relation.org_id_60%TYPE;
   c_org_id_65      pmi_sap002_org_relation.org_id_65%TYPE;
BEGIN
   itracepoint := 100;

   c_company_code := incompany;
   itracepoint := 200;

   SELECT TO_NUMBER (TO_CHAR (SYSDATE, 'hh24'))
     INTO c_hour_of_day
     FROM DUAL;
   itracepoint := 300;
   IF incompany = '1100'
   THEN
      IF c_hour_of_day <= 7
      THEN
         INSERT INTO pmi_zot002_emp_clock_backup
            (SELECT *
               FROM pmi_zot001_emp_clock
              WHERE company_code = incompany);
	     itracepoint := 400;

         DELETE      pmi_zot001_emp_clock
               WHERE company_code = incompany;
         itracepoint := 400;
      END IF;
   ELSE
      IF c_hour_of_day <= 10
      THEN
         INSERT INTO pmi_zot002_emp_clock_backup
            (SELECT *
               FROM pmi_zot001_emp_clock
              WHERE company_code = incompany);

			  itracepoint := 500;

         DELETE      pmi_zot001_emp_clock
               WHERE company_code = incompany;

			   itracepoint := 600;
      END IF;
   END IF;

   itracepoint := 700;

   OPEN c_main;

   LOOP
      FETCH c_main
       INTO v_main;

      EXIT WHEN c_main%NOTFOUND;
      c_org_id_40 := '';
      c_org_id_45 := '';
      c_org_id_50 := '';
      c_org_id_55 := '';
      c_org_id_60 := '';
      c_org_id_65 := '';


      itracepoint := 800;
 BEGIN
      SELECT org_id_65, org_id_60, org_id_55, org_id_50, org_id_45,
             org_id_40
        INTO c_org_id_65, c_org_id_60, c_org_id_55, c_org_id_50, c_org_id_45,
             c_org_id_40
        FROM pmi_sap002_org_relation
       WHERE org_id = v_main.org_id
         AND company_code = incompany
         AND org_level = v_main.org_level
         AND company_code = c_company_code;

     itracepoint := 900;

         SELECT pass_date, pass_time
           INTO c_pass_date, c_pass_time
           FROM pmi_upl001_clock_data
          WHERE CONCAT (pass_date, pass_time) =
                   (SELECT MAX (CONCAT (pass_date, pass_time))
                      FROM pmi_upl001_clock_data
                     WHERE TO_CHAR (TO_NUMBER (emp_no)) =
                                           TO_CHAR (TO_NUMBER (v_main.emp_no))
                       AND company_code = incompany)
            AND TO_CHAR (TO_NUMBER (emp_no)) =
                                           TO_CHAR (TO_NUMBER (v_main.emp_no))
            AND company_code = incompany
            AND ROWNUM <= 1;
    itracepoint := 1000;
           --If inCompany = '1100' Then
             -- 5 minutes buffer
           --    If to_date(C_PASS_DATE || C_PASS_TIME,'yyyymmddhh24mi') > to_date(v_main.WORK_DATE || v_main.WORK_START_TIME,'yyyymmddhh24mi')+(5/(24*60)) then
           --       C_IS_LATE := 1;
           --    Else
           --       C_IS_LATE := 0;
           --    End If;
         --Else
         c_is_late := 0;
      --End If;
      EXCEPTION
         WHEN NO_DATA_FOUND
         THEN
            c_is_late := 1;
            c_pass_date := '';
            c_pass_time := '';
      END;

      itracepoint := 1100;

      INSERT INTO pmi_zot001_emp_clock
                  (company_code, work_date, is_holiday,
                   emp_no, shift_id, work_start_time,
                   work_end_time, org_level, org_id,
                   pass_date, pass_time, is_late, org_id_65,
                   org_id_60, org_id_55, org_id_50, org_id_45,
                   org_id_40
                  )
           VALUES (c_company_code, v_main.work_date, v_main.is_holiday,
                   v_main.emp_no, v_main.shift_id, v_main.work_start_time,
                   v_main.work_end_time, v_main.org_level, v_main.org_id,
                   c_pass_date, c_pass_time, c_is_late, c_org_id_65,
                   c_org_id_60, c_org_id_55, c_org_id_50, c_org_id_45,
                   c_org_id_40
                  );

      COMMIT;
	  itracepoint := 1200;
   END LOOP;

   CLOSE c_main;
EXCEPTION
   WHEN OTHERS
   THEN
      --有錯誤產生則寄mail
      cerrortext := SQLERRM ();
      mail_file_bidbdbadmin
                    (in_to_name      => 'ztchen@ms.usi.com.tw',
                     subject         => '[PMI] PL/SQL PLSQL_PMI_EPS001_process_raw_data ERROR',
                     MESSAGE         =>    '[PLSQL_PMI], The tracepoint is  '
                                        || itracepoint
                                        || ' and ErrorText= '
                                        || cerrortext
										|| to_char(iTracePoint)
                    );
END;
/

