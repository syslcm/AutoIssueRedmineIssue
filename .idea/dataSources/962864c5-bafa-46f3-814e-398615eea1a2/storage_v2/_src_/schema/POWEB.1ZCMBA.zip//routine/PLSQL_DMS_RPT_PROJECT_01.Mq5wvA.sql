create PROCEDURE "PLSQL_DMS_RPT_PROJECT_01"
/*
********************************************************************
  PROG-ID      : PLSQL_DMS_RPT_PROJECT_01
  PROG-ACTION  : 依 Dalek 邏輯計算 Project DMS (SHD /UMD)
  Author      : Minhorng
  Date         : 2009/01/05
  Remark      : 每週日執行

  DMS_RPT01_PROJECT_T01: 預估DM from DMS
  DMS_RPT01_PROJECT_T02: 預估DM from DMS(彙整 by project)
  DMS_RPT01_PROJECT_T03: 上月實際 DM [抓KPI_SAP001_COPA_TRX (COGS_MB_USD / NET_REVENUE_USD)]
  DMS_RPT01_PROJECT_T04: Inv. AMT (local currency) [抓VIEW_EGI0150_END_STORAGELOC(含正常品/HUB)]
  DMS_RPT01_PROJECT_T05: Inv. AMT (USD)
  DMS_RPT01_PROJECT_T06: project fcst revenue [from RWF_SAP001_REVENUE_FORECAST]
*********************************************************************
*/
is
	iTracePoint           integer;
	cErrorText            varchar2(500);
	t_PERIOD              DMM_RPT001_FG_W_MAX.PERIOD%TYPE;
	p_YYYYMM              varchar2(6);--上個年月
	min_YW_DATE           varchar2(8);
	f_DATE                varchar2(8);
	t_EX_RATE_USD         number(10,5);
	t_DM_RATE             DMS_RPT01_PROJECT_T07.DM_RATE%TYPE;
	t_DM_RATE_P           DMS_RPT01_PROJECT_T07.DM_RATE%TYPE;
	t_TURNOVER_DAY        DMS_RPT01_PROJECT_T07.TURNOVER_DAY%TYPE;
	t_TURNOVER_DAY2       DMS_RPT01_PROJECT_T07.TURNOVER_DAY%TYPE;
	prv_DATE              varchar2(8);
	t_DIFF_RATE           number(18,6);
BEGIN
	cErrorText := ' ';
	--(0) 抓DMM_RPT001_FG_W_MAX + DMM_UPL002_PROJECT max(PERIOD)
	iTracePoint := 0;
	t_PERIOD := null;
	min_YW_DATE := null;
	select * into t_PERIOD from (
		select max(a.PERIOD)
			from DMM_RPT001_FG_W_MAX a, DMM_UPL002_PROJECT b, DMM_UPL001_SELLING c
		where b.MFG_SITE = a.COMPANY_CODE
		and b.PLANT = a.PLANT
		and b.FG_MATERIAL_NO = a.FG
		and c.COMPANY_CODE = a.COMPANY_CODE
		and c.PLANT = a.PLANT
		and c.FG = a.FG
		and c.TO_DATE >= to_char(sysdate,'yyyymmdd')
	);
	iTracePoint := 3;
	select * into min_YW_DATE from (
		select min(YW_DATE)	from DMM_RPT001_FG_W
		where PERIOD = t_PERIOD
	);

	--(5) 抓上個年月
	iTracePoint := 5;
	p_YYYYMM := null;
	f_DATE := null;
	select * into p_YYYYMM, f_DATE from (
		select to_char(add_months(sysdate, -1),'yyyymm'),
			(to_char(sysdate,'yyyymm') || '01')
		from DUAL
	);
	--(50) 處理PCA - 1
	iTracePoint := 50;
	delete from DMS_RPT01_PROJECT_T00A;
	commit;
	--(53) 處理PCA 0000410105 (REVENUE)
	iTracePoint := 53;
	insert into DMS_RPT01_PROJECT_T00A (
		BU, ACCOUNT_NO, PROJECT_NAME, PRODUCT_TYPE, PROJECT, YYYYMM, QTY, AMOUNT_USD
	)
	select BU, ACCOUNT_NO, PROJECT_NAME, PRODUCT_TYPE,
		trim(PROJECT_NAME || '(' || PRODUCT_TYPE || ')') as PROJECT,
		PERIOD as YYYYMM,
		(round(sum(NET_QTY1),3) * -1) as QTY,
		(round(sum(NET_REVENUE_USD1),6) * -1) as AMOUNT_USD
	from (
		select distinct a.PERIOD, a.PCA_DOC_NO as COPA_DOC_NO, a.ACCOUNT_NO,
			a.COMPANY_CODE, a.PLANT_CODE as PLANT, a.PART_NO as FG,
			a.COGS_MB_USD as COGS_MB_USD1, a.NET_QTY as NET_QTY1,
			b.CUSTOMER_NAME, b.PROJECT_NAME, b.PRODUCT_TYPE,
			b.PRODUCT_LINE as BU, 0 as SELLING_PRICE,
			a.NET_REVENUE_USD as NET_REVENUE_USD1
		from KPI_SAP002_PCA_TRX a, DMM_UPL002_PROJECT b, DMM_UPL001_SELLING c
		where a.COMPANY_CODE = b.MFG_SITE
		and a.PLANT_CODE = b.PLANT
		and a.PART_NO = b.FG_MATERIAL_NO
		and a.PERIOD = p_YYYYMM
		and a.ACCOUNT_NO in ('0000410105')
		and a.PROFIT_CENTER = '0000000036'
		and a.PARTNER_PROFIT_CENTER = '0000000029'
		and b.MFG_SITE = c.COMPANY_CODE
		and b.PLANT = c.PLANT
		and b.FG_MATERIAL_NO = c.FG
		and b.PRODUCT_LINE != c.BU
	) group by BU, ACCOUNT_NO, PROJECT_NAME, PRODUCT_TYPE, PERIOD;
	commit;
	--(58) 處理PCA 0000410105 (COGS_MB)
	iTracePoint := 58;
	insert into DMS_RPT01_PROJECT_T00A (
		BU, ACCOUNT_NO, PROJECT_NAME, PRODUCT_TYPE, PROJECT, YYYYMM, QTY, AMOUNT_USD
	)
	select BU, ACCOUNT_NO, PROJECT_NAME, PRODUCT_TYPE,
		trim(PROJECT_NAME || '(' || PRODUCT_TYPE || ')') as PROJECT,
		PERIOD as YYYYMM,
		0 as QTY,
		(round(sum(COGS_MB_USD1),6) * -1) as AMOUNT_USD
	from (
		select distinct a.PERIOD, a.PCA_DOC_NO as COPA_DOC_NO, a.ACCOUNT_NO,
			a.COMPANY_CODE, a.PLANT_CODE as PLANT, a.PART_NO as FG,
			a.COGS_MB_USD as COGS_MB_USD1, a.NET_QTY as NET_QTY1,
			b.CUSTOMER_NAME, b.PROJECT_NAME, b.PRODUCT_TYPE,
			b.PRODUCT_LINE as BU, 0 as SELLING_PRICE,
			a.NET_REVENUE_USD as NET_REVENUE_USD1
		from KPI_SAP002_PCA_TRX a, DMM_UPL002_PROJECT b, DMM_UPL001_SELLING c
		where a.COMPANY_CODE = b.MFG_SITE
		and a.PLANT_CODE = b.PLANT
		and a.PART_NO = b.FG_MATERIAL_NO
		and a.PERIOD = p_YYYYMM
		and a.ACCOUNT_NO in ('0000510905')
		and a.PROFIT_CENTER = '0000000036'
		and a.PARTNER_PROFIT_CENTER = '0000000029'
		and b.MFG_SITE = c.COMPANY_CODE
		and b.PLANT = c.PLANT
		and b.FG_MATERIAL_NO = c.FG
		and b.PRODUCT_LINE != c.BU
	) group by BU, ACCOUNT_NO, PROJECT_NAME, PRODUCT_TYPE, PERIOD;
	commit;
	--(60) 處理PCA - 2
	iTracePoint := 60;
	delete from DMS_RPT01_PROJECT_T00B;
	commit;
	iTracePoint := 65;
	insert into DMS_RPT01_PROJECT_T00B (
		BU, PROJECT_NAME, PRODUCT_TYPE, PROJECT, YYYYMM, QTY, AMOUNT_USD, AVG_PRICE
	)
	select BU, PROJECT_NAME, PRODUCT_TYPE, PROJECT, YYYYMM,
		sum(QTY), sum(AMOUNT_USD), round(sum(AMOUNT_USD) / sum(QTY), 6)
	from DMS_RPT01_PROJECT_T00A
	group by BU, PROJECT_NAME, PRODUCT_TYPE, PROJECT, YYYYMM;
	commit;

	--(100) 處理 DMS_RPT01_PROJECT_T01 / DMS_RPT01_PROJECT_T02
	iTracePoint := 100;
	delete from DMS_RPT01_PROJECT_T01;
	commit;
	iTracePoint := 102;
	insert into DMS_RPT01_PROJECT_T01 (
		COMPANY_CODE, PLANT, FG, BU, CUSTOMER_NAME, PROJECT_NAME,
		PRODUCT_TYPE, PROJECT,
		SELLING_PRICE, PERIOD, YYYYWW, YW_DATE, FG_QTY,
		COST_USD,YYYYMM
	)
	select COMPANY_CODE, PLANT, FG, BU, CUSTOMER_NAME, PROJECT_NAME,
		PRODUCT_TYPE, trim(PROJECT_NAME || '(' || PRODUCT_TYPE || ')') as PROJECT,
		SELLING_PRICE, PERIOD, YYYYWW, YW_DATE, FG_QTY,
		sum(COST_MAC) as COST_USD, substr(YW_DATE,1,6) as YYYYMM
	from (
		select b.COMPANY_CODE, b.PLANT, b.FG, b.BU,
			a.CUSTOMER_NAME, a.PROJECT_NAME, a.PRODUCT_TYPE,
			b.SELLING_PRICE, c.PERIOD, c.YYYYWW, c.YW_DATE, c.FG_QTY, c.COST_MAC
		from DMM_UPL002_PROJECT a, DMM_UPL001_SELLING b, DMM_RPT001_FG_W c
		where a.MFG_SITE = b.COMPANY_CODE
		and a.PLANT = b.PLANT
		and a.FG_MATERIAL_NO = b.FG
		and b.FROM_DATE <= c.YW_DATE
		and b.TO_DATE >= c.YW_DATE
		and c.COMPANY_CODE = b.COMPANY_CODE
		and c.PLANT = b.PLANT
		and c.FG = b.FG
		and c.PERIOD = t_PERIOD
		union
		select b.COMPANY_CODE, b.PLANT, b.FG, b.BU,
			a.CUSTOMER_NAME, a.PROJECT_NAME, a.PRODUCT_TYPE,
			b.SELLING_PRICE, null as PERIOD, null as YYYYWW, c.DATE_KEY as YW_DATE,
			c.FG_QTY, c.COST_MAC
		from DMM_UPL002_PROJECT a, DMM_UPL001_SELLING b, DMM_RPT003_FG_D c
		where a.MFG_SITE = b.COMPANY_CODE
		and a.PLANT = b.PLANT
		and a.FG_MATERIAL_NO = b.FG
		and b.FROM_DATE <= c.DATE_KEY
		and b.TO_DATE >= c.DATE_KEY
		and c.COMPANY_CODE = b.COMPANY_CODE
		and c.PLANT = b.PLANT
		and c.FG = b.FG
		and c.DATE_KEY >= f_DATE
		and c.DATE_KEY < min_YW_DATE
	)
	where substr(YW_DATE,1,6) != p_YYYYMM
	group by COMPANY_CODE, PLANT, FG, BU, CUSTOMER_NAME, PROJECT_NAME,
		PRODUCT_TYPE, SELLING_PRICE, PERIOD, YYYYWW, YW_DATE, FG_QTY;
	commit;
	iTracePoint := 104;
	delete from DMS_RPT01_PROJECT_T02;
	commit;
	iTracePoint := 106;
	insert into DMS_RPT01_PROJECT_T02 (
		BU, PROJECT_NAME, PRODUCT_TYPE, PROJECT, YYYYMM, DMS_DM
	)
	select BU, PROJECT_NAME, PRODUCT_TYPE, PROJECT, YYYYMM, round(COSTING / SELLING,6)
	from (
		select BU, PROJECT_NAME, PRODUCT_TYPE, PROJECT, YYYYMM,
			sum(round(SELLING_PRICE * FG_QTY,6)) as SELLING,
			sum(round(COST_USD * FG_QTY,6)) as COSTING
		from(
			select a.BU, a.PROJECT_NAME, a.PRODUCT_TYPE, a.PROJECT, a.YYYYMM,
				a.SELLING_PRICE, a.FG_QTY,
				(a.COST_USD + nvl(b.AVG_PRICE,0)) as COST_USD
			from DMS_RPT01_PROJECT_T01 a, DMS_RPT01_PROJECT_T00B b
			where b.BU (+)= a.BU
			and b.PROJECT (+)= a.PROJECT
		) group by BU, PROJECT_NAME, PRODUCT_TYPE, PROJECT, YYYYMM
	) where SELLING != 0
	union
	select BU, PROJECT_NAME, PRODUCT_TYPE, PROJECT, YYYYMM, 0 as DM
	from (
		select BU, PROJECT_NAME, PRODUCT_TYPE, PROJECT, YYYYMM,
			sum(round(SELLING_PRICE * FG_QTY,6)) as SELLING,
			sum(round(COST_USD * FG_QTY,6)) as COSTING
		from(
			select a.BU, a.PROJECT_NAME, a.PRODUCT_TYPE, a.PROJECT, a.YYYYMM,
				a.SELLING_PRICE, a.FG_QTY,
				(a.COST_USD + nvl(b.AVG_PRICE,0)) as COST_USD
			from DMS_RPT01_PROJECT_T01 a, DMS_RPT01_PROJECT_T00B b
			where b.BU (+)= a.BU
			and b.PROJECT (+)= a.PROJECT
		) group by BU, PROJECT_NAME, PRODUCT_TYPE, PROJECT, YYYYMM
	) where SELLING = 0;
	commit;

	--(110) 處理 DMS_RPT01_PROJECT_T03 -- 上月實際 DM
	iTracePoint := 110;
	delete from DMS_RPT01_PROJECT_T03A;
	commit;
	iTracePoint := 112;
	insert into DMS_RPT01_PROJECT_T03A (
		ID, PERIOD, COPA_DOC_NO, COMPANY_CODE, PLANT, FG, COGS_MB_USD, NET_QTY,
		CUSTOMER_NAME, PROJECT_NAME, PRODUCT_TYPE, BU, SELLING_PRICE, NET_REVENUE_USD
	)
	--SO (1)
	select distinct 'A' as ID, a.PERIOD, a.COPA_DOC_NO,
		a.COMPANY_CODE, a.PLANT_CODE as PLANT, a.PART_NO as FG,
		a.COGS_MB_USD, a.NET_QTY,
		b.CUSTOMER_NAME, b.PROJECT_NAME, b.PRODUCT_TYPE, c.BU, c.SELLING_PRICE,
		round(a.NET_QTY * c.SELLING_PRICE, 6) as NET_REVENUE_USD
	from KPI_SAP001_COPA_TRX a, DMM_UPL002_PROJECT b, DMM_UPL001_SELLING c
	where a.COMPANY_CODE = b.MFG_SITE
	and a.PLANT_CODE = b.PLANT
	and a.PART_NO = b.FG_MATERIAL_NO
	and a.PERIOD = p_YYYYMM
	and a.MVTP in ('601','602','633','634','653','653','654')
	and nvl(a.COST_ELEMENT,'0000000000') not in ('0000510902','0000510909','0000510999')
	and a.NET_QTY != 0
	and b.MFG_SITE = c.COMPANY_CODE
	and b.PLANT = c.PLANT
	and b.FG_MATERIAL_NO = c.FG
	and c.FROM_DATE <= (p_YYYYMM || '15')
	and c.TO_DATE >= (p_YYYYMM || '15')
	--SO (2)
	union
	select distinct 'B' as ID, a.PERIOD, a.COPA_DOC_NO,
		a.COMPANY_CODE, a.PLANT_CODE as PLANT, a.PART_NO as FG,
		a.COGS_MB_USD, a.NET_QTY,
		b.CUSTOMER_NAME, b.PROJECT_NAME, b.PRODUCT_TYPE, c.BU, c.SELLING_PRICE,
		round(a.NET_QTY * c.SELLING_PRICE, 6) as NET_REVENUE_USD
	from KPI_SAP001_COPA_TRX a, DMM_UPL002_PROJECT b, DMM_UPL001_SELLING c
	where a.COMPANY_CODE = b.MFG_SITE
	and a.PLANT_CODE = b.PLANT
	and a.PART_NO = b.FG_MATERIAL_NO
	and a.PERIOD = p_YYYYMM
	and a.MVTP is null
	and a.AWTYP not in ('RMRP','PRCHG','COPA','MKPF')
	and nvl(a.COST_ELEMENT,'0000000000') not in ('0000510902','0000510909','0000510999')
	and a.NET_QTY != 0
	and b.MFG_SITE = c.COMPANY_CODE
	and b.PLANT = c.PLANT
	and b.FG_MATERIAL_NO = c.FG
	and c.FROM_DATE <= (p_YYYYMM || '15')
	and c.TO_DATE >= (p_YYYYMM || '15')
	--settle
	union
	select distinct 'C' as ID, a.PERIOD, a.COPA_DOC_NO,
		a.COMPANY_CODE, a.PLANT_CODE as PLANT, a.PART_NO as FG,
		a.COGS_MB_USD, a.NET_QTY,
		b.CUSTOMER_NAME, b.PROJECT_NAME, b.PRODUCT_TYPE,
		nvl(c.BU, b.PRODUCT_LINE) as BU, 0 as SELLING_PRICE,
		0 as NET_REVENUE_USD
	from KPI_SAP001_COPA_TRX a, DMM_UPL002_PROJECT b, DMM_UPL001_SELLING c
	where a.COMPANY_CODE = b.MFG_SITE
	and a.PLANT_CODE = b.PLANT
	and a.PART_NO = b.FG_MATERIAL_NO
	and a.PERIOD = p_YYYYMM
	and a.MVTP is null
	and a.AWTYP not in ('RMRP','PRCHG','COPA','MKPF')
	and a.COST_ELEMENT in ('0000510902')
	and a.NET_QTY = 0
	and c.COMPANY_CODE (+) = b.MFG_SITE
	and c.PLANT (+)= b.PLANT
	and c.FG (+)= b.FG_MATERIAL_NO
	-- PCA
	union
	select distinct 'D' as ID, a.YYYYMM as PERIOD, 'PCA' as COPA_DOC_NO,
		'0' as COMPANY_CODE, '0' as PLANT, 'FG' as FG,
		a.AMOUNT_USD as COGS_MB_USD, 0 as NET_QTY,
		'CUST' as CUSTOMER_NAME, a.PROJECT_NAME, a.PRODUCT_TYPE,
		a.BU, 0 as SELLING_PRICE,
		0 as NET_REVENUE_USD
	from DMS_RPT01_PROJECT_T00B a
	where a.YYYYMM = p_YYYYMM
	-- others
	union
	select distinct 'E' as ID, a.PERIOD, a.COPA_DOC_NO,
		a.COMPANY_CODE, a.PLANT_CODE as PLANT, a.PART_NO as FG,
		a.COGS_MB_USD, a.NET_QTY,
		b.CUSTOMER_NAME, b.PROJECT_NAME, b.PRODUCT_TYPE, b.PRODUCT_LINE as BU,
		0 as SELLING_PRICE,
		a.NET_REVENUE_USD
	from KPI_SAP001_COPA_TRX a, DMM_UPL002_PROJECT b
	where a.COMPANY_CODE = b.MFG_SITE
	and a.PLANT_CODE = b.PLANT
	and a.PART_NO = b.FG_MATERIAL_NO
	and a.PERIOD = p_YYYYMM
	and a.MVTP in ('601','602','633','634','653','653','654')
	and nvl(a.COST_ELEMENT,'0000000000') not in ('0000510902','0000510909','0000510999')
	and a.NET_QTY != 0
	and (b.MFG_SITE,b.PLANT,b.FG_MATERIAL_NO) not in (
		select c.COMPANY_CODE,c.PLANT,c.FG from DMM_UPL001_SELLING c
	);
	commit;
	iTracePoint := 115;
	delete from DMS_RPT01_PROJECT_T03;
	commit;
	iTracePoint := 117;
	insert into DMS_RPT01_PROJECT_T03 (
		BU, PROJECT_NAME, PRODUCT_TYPE, PROJECT, YYYYMM, ACT_DM
	)
	select BU, PROJECT_NAME, PRODUCT_TYPE,
		trim(PROJECT_NAME || '(' || PRODUCT_TYPE || ')'),
		PERIOD,
		round(COGS_MB_USD / NET_REVENUE_USD,6)
	from (
		select BU, PROJECT_NAME, PRODUCT_TYPE, PERIOD,
			sum(COGS_MB_USD) as COGS_MB_USD,
			sum(NET_REVENUE_USD) as NET_REVENUE_USD
		from (
			select * from DMS_RPT01_PROJECT_T03A
		)
		group by BU, PERIOD, PROJECT_NAME, PRODUCT_TYPE
	) where NET_REVENUE_USD != 0;
	commit;

	--(120) 處理 DMS_RPT01_PROJECT_T04A / DMS_RPT01_PROJECT_T04 -- Inv. AMT (local currency) / DMS_RPT01_PROJECT_T05
	iTracePoint := 120;
	delete from DMS_RPT01_PROJECT_T04A;
	commit;
	iTracePoint := 121;
	insert into DMS_RPT01_PROJECT_T04A (
		MFG_SITE, PLANT, MATERIAL, POST_DATE_YYYY, POST_DATE_MM,
		STORAGE_LOC, LOCAL_CURRENCY,
		UNRESTRICTED_USE_AMT, INSPECT_QTY_AMT, BLOCK_QTY_AMT, OPEN_ORDER_AMT,
		PROJECT_NAME, PRODUCT_TYPE, BU, SOURCE_TYPE
	)
	--正常品
	select distinct b.MFG_SITE, b.PLANT, b.MATERIAL, b.POST_DATE_YYYY, b.POST_DATE_MM,
		b.STORAGE_LOC, b.LOCAL_CURRENCY,
		b.UNRESTRICTED_USE_AMT, b.INSPECT_QTY_AMT, b.BLOCK_QTY_AMT, b.OPEN_ORDER_AMT,
		a.PROJECT_NAME, a.PRODUCT_TYPE, nvl(c.BU, a.PRODUCT_LINE) as BU, 'NORMAL' as SOURCE_TYPE
	from DMM_UPL002_PROJECT a, VIEW_EGI0150_END_STORAGELOC b, DMM_UPL001_SELLING c
	where a.FG_MATERIAL_NO = b.MATERIAL
	and ( (b.MFG_SITE = '1100' and b.PLANT in ('1110','1120','1130','1140'))
	or (b.MFG_SITE = '1500' and b.PLANT in ('1510','1511')) )
	and b.POST_DATE_YYYY = substr(p_YYYYMM,1,4)
	and b.POST_DATE_MM = substr(p_YYYYMM,5,2)
	and ( b.STORAGE_LOC like '0%' or b.STORAGE_LOC like '1%' )
	and c.COMPANY_CODE (+) = b.MFG_SITE
	and c.PLANT (+)= b.PLANT
	and c.FG (+)= b.MATERIAL
	--TW HUB
	union
	select distinct b.MFG_SITE, b.PLANT, b.MATERIAL, b.POST_DATE_YYYY, b.POST_DATE_MM,
		b.STORAGE_LOC, b.LOCAL_CURRENCY,
		b.UNRESTRICTED_USE_AMT, b.INSPECT_QTY_AMT, b.BLOCK_QTY_AMT, b.OPEN_ORDER_AMT,
		a.PROJECT_NAME, a.PRODUCT_TYPE, nvl(c.BU, a.PRODUCT_LINE) as BU, 'TW HUB' as SOURCE_TYPE
	from DMM_UPL002_PROJECT a, VIEW_EGI0150_END_STORAGELOC b, DMM_UPL001_SELLING c
	where b.MFG_SITE = '1100'
	and b.PLANT = '1190'
	and a.FG_MATERIAL_NO = b.MATERIAL
	and b.POST_DATE_YYYY = substr(p_YYYYMM,1,4)
	and b.POST_DATE_MM = substr(p_YYYYMM,5,2)
	and b.STORAGE_LOC != '2000'
	and b.STORAGE_LOC != '3000'
	and b.STORAGE_LOC != '0001'
	and c.COMPANY_CODE (+)= a.MFG_SITE
	and c.PLANT (+)= a.PLANT
	and c.FG (+)= a.FG_MATERIAL_NO
	--SH HUB
	union
	select distinct b.MFG_SITE, b.PLANT, b.MATERIAL, b.POST_DATE_YYYY, b.POST_DATE_MM,
		b.STORAGE_LOC, b.LOCAL_CURRENCY,
		b.UNRESTRICTED_USE_AMT, b.INSPECT_QTY_AMT, b.BLOCK_QTY_AMT, b.OPEN_ORDER_AMT,
		a.PROJECT_NAME, a.PRODUCT_TYPE, nvl(c.BU, a.PRODUCT_LINE) as BU, 'SH HUB' as SOURCE_TYPE
	from DMM_UPL002_PROJECT a, VIEW_EGI0150_END_STORAGELOC b, DMM_UPL001_SELLING c
	where b.MFG_SITE = '1500'
	and b.PLANT = '1591'
	and a.FG_MATERIAL_NO = b.MATERIAL
	and b.POST_DATE_YYYY = substr(p_YYYYMM,1,4)
	and b.POST_DATE_MM = substr(p_YYYYMM,5,2)
	and c.COMPANY_CODE (+)= a.MFG_SITE
	and c.PLANT (+)= a.PLANT
	and c.FG (+)= a.FG_MATERIAL_NO
	-- WIP
	union
	select distinct b.MFG_SITE, b.PLANT, b.MATERIAL, b.POST_DATE_YYYY, b.POST_DATE_MM,
		null as STORAGE_LOC, b.LOCAL_CURRENCY,
		b.LOCAL_AMOUNT as UNRESTRICTED_USE_AMT, 0 as INSPECT_QTY_AMT, 0 as BLOCK_QTY_AMT, 0 as OPEN_ORDER_AMT,
		a.PROJECT_NAME, a.PRODUCT_TYPE, nvl(c.BU, a.PRODUCT_LINE) as BU, 'WIP' as SOURCE_TYPE
	from DMM_UPL002_PROJECT a, VIEW_EGI0110_END_QTY_VALUE b, DMM_UPL001_SELLING c
	where a.FG_MATERIAL_NO = b.MATERIAL
	and ( (b.MFG_SITE = '1100' and b.PLANT in ('1110','1120','1130','1140'))
		or (b.MFG_SITE = '1500' and b.PLANT in ('1510','1511')) )
	and b.POST_DATE_YYYY = substr(p_YYYYMM,1,4)
	and b.POST_DATE_MM = substr(p_YYYYMM,5,2)
	and b.VALUATION_CLASS = 'WIP'
	and c.COMPANY_CODE (+)= b.MFG_SITE
	and c.PLANT (+)= b.PLANT
	and c.FG (+)= b.MATERIAL;
	commit;
	iTracePoint := 122;
	delete from DMS_RPT01_PROJECT_T04;
	commit;
	iTracePoint := 123;
	insert into DMS_RPT01_PROJECT_T04 (
		BU, PROJECT_NAME, PRODUCT_TYPE, PROJECT, YYYYMM, LOCAL_CURRENCY, INV_AMT
	)
	select BU, PROJECT_NAME, PRODUCT_TYPE,
		(PROJECT_NAME || '(' || PRODUCT_TYPE || ')') as PROJECT,
		(POST_DATE_YYYY || POST_DATE_MM) as YYYYMM,
		LOCAL_CURRENCY,
		round(sum(UNRESTRICTED_USE_AMT + INSPECT_QTY_AMT + BLOCK_QTY_AMT + OPEN_ORDER_AMT),6) as INV_AMT
	from (
		--正常品
		select * from DMS_RPT01_PROJECT_T04A
	)
	group by BU, PROJECT_NAME, PRODUCT_TYPE, POST_DATE_YYYY, POST_DATE_MM, LOCAL_CURRENCY;
	commit;
	iTracePoint := 124;
	delete from DMS_RPT01_PROJECT_T05;
	commit;
	iTracePoint := 126;
	insert into DMS_RPT01_PROJECT_T05 (
		BU, PROJECT_NAME, PRODUCT_TYPE, PROJECT, YYYYMM, INV_AMT_USD
	)
	select distinct
		BU, PROJECT_NAME, PRODUCT_TYPE, PROJECT, YYYYMM, 0
	from DMS_RPT01_PROJECT_T04;
	commit;
	iTracePoint := 128;
	for REC1 in (
		select BU, PROJECT_NAME, PRODUCT_TYPE, PROJECT, YYYYMM, LOCAL_CURRENCY,
			sum(INV_AMT) as INV_AMT_L
		from DMS_RPT01_PROJECT_T04
		group by BU, PROJECT_NAME, PRODUCT_TYPE, PROJECT, YYYYMM, LOCAL_CURRENCY
	) loop
		t_EX_RATE_USD := GET_EXCHANGE_RATE(SUBSTRB(REC1.YYYYMM,1,4),SUBSTRB(REC1.YYYYMM,5,2),REC1.LOCAL_CURRENCY,'USD','T');
		update DMS_RPT01_PROJECT_T05 set
			INV_AMT_USD = (INV_AMT_USD + round(REC1.INV_AMT_L * t_EX_RATE_USD,6))
		where BU = REC1.BU
		and PROJECT_NAME = REC1.PROJECT_NAME
		and PRODUCT_TYPE = REC1.PRODUCT_TYPE
		and PROJECT = REC1.PROJECT
		and YYYYMM = REC1.YYYYMM;
		commit;
	end loop;

	--(130) 處理 DMS_RPT01_PROJECT_T06 -- project fcst revenue
	iTracePoint := 130;
	delete from DMS_RPT01_PROJECT_T06;
	commit;
	iTracePoint := 132;
	insert into DMS_RPT01_PROJECT_T06 (
		BU, PROJECT, YYYYMM, NET_REVENUE_USD
	)
	select BU, PROJECT_NAME, trim(F_YEAR || RWF_MM), sum(NET_REVENUE_USD)
	from (
		select a.PROFIT_CENTER, a.PROJECT_NAME, a.F_YEAR, a.RWF_MM, a.NET_REVENUE_USD,
			(select distinct BU from DMM_OTH004_PROFIT_CENTER
				where COMPANY_CODE = a.COMPANY_CODE
				and PROFIT_CENTER = a.PROFIT_CENTER
			) as BU
		from RWF_SAP001_REVENUE_FORECAST a
		where (a.RWF_YYYY || a.RWF_WEEK) = (
			select MAX(x.RWF_YYYY || x.RWF_WEEK) from RWF_SAP001_REVENUE_FORECAST x
		)
		and a.RWF_MM = to_char(sysdate,'MM')
		and a.F_YEAR = to_char(sysdate,'YYYY')
	)
	group by BU, PROJECT_NAME, F_YEAR, RWF_MM;
	commit;
	--(135) 處理 DMS_RPT01_PROJECT_T06B -- project fcst revenue (下月後)
	iTracePoint := 135;
	delete from DMS_RPT01_PROJECT_T06B;
	commit;
	iTracePoint := 137;
	insert into DMS_RPT01_PROJECT_T06B (
		BU, PROJECT, YYYYMM, NET_REVENUE_USD
	)
	select BU, PROJECT_NAME, trim(F_YEAR || RWF_MM), sum(NET_REVENUE_USD)
	from (
		select a.PROFIT_CENTER, a.PROJECT_NAME, a.F_YEAR, a.RWF_MM, a.NET_REVENUE_USD,
			(select distinct BU from DMM_OTH004_PROFIT_CENTER
				where COMPANY_CODE = a.COMPANY_CODE
				and PROFIT_CENTER = a.PROFIT_CENTER
			) as BU
		from RWF_SAP001_REVENUE_FORECAST a
		where (a.RWF_YYYY || a.RWF_WEEK) = (
			select MAX(x.RWF_YYYY || x.RWF_WEEK) from RWF_SAP001_REVENUE_FORECAST x
		)
		and (a.F_YEAR || a.RWF_MM) >= to_char(sysdate,'YYYYMM')
	)
	group by BU, PROJECT_NAME, F_YEAR, RWF_MM;
	commit;

	--(200) temp report
	iTracePoint := 200;
	delete from DMS_RPT01_PROJECT_T07;
	commit;
	--(210) ACTUAL
	iTracePoint := 210;
	insert into DMS_RPT01_PROJECT_T07 (
		BU, PROJECT_NAME, PRODUCT_TYPE, PROJECT, YYYYMM, ACTUAL_FLAG, ORG_DM,
		INV_AMT_USD, NET_REVENUE_USD, TURNOVER_DAY, DM_RATE
	)
	select a.BU, a.PROJECT_NAME, a.PRODUCT_TYPE, a.PROJECT, a.YYYYMM, 'Y', a.ACT_DM,
		(select sum(nvl(INV_AMT_USD,0)) from DMS_RPT01_PROJECT_T05
			where BU = a.BU and PROJECT = a.PROJECT
		) as INV_AMT_USD,
		(select sum(nvl(NET_REVENUE_USD,0)) from DMS_RPT01_PROJECT_T06
			where BU = a.BU and PROJECT = a.PROJECT
		) as NET_REVENUE_USD,
		0, a.ACT_DM
	from DMS_RPT01_PROJECT_T03 a
	where (a.BU,a.PROJECT) in (
		select BU,PROJECT from DMS_RPT01_PROJECT_T02
	);
	commit;
	--(220)turnover day
	iTracePoint := 220;
	update DMS_RPT01_PROJECT_T07 set
		TURNOVER_DAY = ceil( ( nvl(INV_AMT_USD,0) / (NET_REVENUE_USD * ORG_DM) ) * 365 / 12	)
	where NET_REVENUE_USD != 0
	and ORG_DM != 0;
	commit;
	--(225)turnover day - 有 Inventory 但無 Fcst revenue, 故設成 999 天
	iTracePoint := 225;
	update DMS_RPT01_PROJECT_T07 set
		TURNOVER_DAY = 999
	where INV_AMT_USD > 0
	and nvl(NET_REVENUE_USD,0) = 0;
	commit;
	--(230)FORECAST
	iTracePoint := 230;
	insert into DMS_RPT01_PROJECT_T07 (
		BU, PROJECT_NAME, PRODUCT_TYPE, PROJECT, YYYYMM, ACTUAL_FLAG, ORG_DM,
		INV_AMT_USD, NET_REVENUE_USD, TURNOVER_DAY, DM_RATE
	)
	select a.BU, a.PROJECT_NAME, a.PRODUCT_TYPE, a.PROJECT, a.YYYYMM, 'N', a.DMS_DM,
		0 as INV_AMT_USD,
		--(select sum(nvl(INV_AMT_USD,0)) from DMS_RPT01_PROJECT_T05
		--	where BU = a.BU and PROJECT = a.PROJECT
		--) as INV_AMT_USD,
		(select nvl(sum(NET_REVENUE_USD),0) from DMS_RPT01_PROJECT_T06B
			where BU = a.BU and PROJECT = a.PROJECT and YYYYMM = a.YYYYMM
		) as NET_REVENUE_USD,
		0, a.DMS_DM
	from DMS_RPT01_PROJECT_T02 a
	where a.BU is not null and a.PROJECT is not null;
	--where (a.BU,a.PROJECT) in (
	--	select BU,PROJECT from DMS_RPT01_PROJECT_T03
	--);
	commit;
	--(240) update null 為 0
	iTracePoint := 240;
	update DMS_RPT01_PROJECT_T07 set
		INV_AMT_USD = 0
	where nvl(INV_AMT_USD,0) = 0;
	update DMS_RPT01_PROJECT_T07 set
		NET_REVENUE_USD = 0
	where nvl(NET_REVENUE_USD,0) = 0;
	commit;
	--(250) 計算 DM
	iTracePoint := 250;
	for REC1 in (
		select distinct BU, PROJECT, PROJECT_NAME, PRODUCT_TYPE from DMS_RPT01_PROJECT_T07
	) loop
		t_DM_RATE := 0;
		t_DM_RATE_P := 0;   --若該月 ORG_DM 為 0, 抓上個月的 DM_RATE來放
		t_TURNOVER_DAY := 0;
		for REC2 in (
			select YYYYMM, ACTUAL_FLAG, ORG_DM, DM_RATE, TURNOVER_DAY from DMS_RPT01_PROJECT_T07
			where BU = REC1.BU and PROJECT = REC1.PROJECT
			order by YYYYMM
		) loop
			if REC2.ACTUAL_FLAG = 'Y' then
				t_DM_RATE := REC2.DM_RATE;
				t_DM_RATE_P := REC2.DM_RATE;
				t_TURNOVER_DAY := abs(REC2.TURNOVER_DAY);
			else
				--Selling price差價比率
				prv_DATE := (to_char(to_date( REC2.YYYYMM || '01', 'yyyymmdd') - 1,'yyyymm') || '01');
				t_DIFF_RATE := 1;
				begin
					select * into t_DIFF_RATE from (
						select round( P1 / P2, 6) as DIFF_RATE
						from (
							select c2.BU, b.PROJECT_NAME, b.PRODUCT_TYPE,
								sum(c1.SELLING_PRICE) as P1, sum(c2.SELLING_PRICE) as P2
							from DMM_UPL002_PROJECT b, DMM_UPL001_SELLING c1, DMM_UPL001_SELLING c2
							where c2.BU = REC1.BU
							and b.PROJECT_NAME = REC1.PROJECT_NAME
							and b.PRODUCT_TYPE = REC1.PRODUCT_TYPE
							and b.MFG_SITE = c1.COMPANY_CODE
							and b.PLANT = c1.PLANT
							and b.FG_MATERIAL_NO = c1.FG
							and c1.FROM_DATE <= prv_DATE
							and c1.TO_DATE >= prv_DATE
							and b.MFG_SITE = c2.COMPANY_CODE
							and b.PLANT = c2.PLANT
							and b.FG_MATERIAL_NO = c2.FG
							and c2.FROM_DATE <= ( REC2.YYYYMM || '01' )
							and c2.TO_DATE >= ( REC2.YYYYMM || '01' )
							group by c2.BU, b.PROJECT_NAME, b.PRODUCT_TYPE
						)
					);
				exception
					when others then
						t_DIFF_RATE := 1;
				end;
				if t_TURNOVER_DAY >= 30 then
					t_TURNOVER_DAY := t_TURNOVER_DAY - 30;
					t_DM_RATE := round(t_DM_RATE_P * t_DIFF_RATE,6);  --turnover > 30 用上月DM + selling差距
					t_DM_RATE_P := t_DM_RATE;
					update DMS_RPT01_PROJECT_T07 set
						DM_RATE = t_DM_RATE,
						TURNOVER_DAY = t_TURNOVER_DAY
					where BU = REC1.BU and PROJECT = REC1.PROJECT
					and YYYYMM = REC2.YYYYMM;
				else
					-- 上月DM rate 為0, 則不用來計算
					if t_DM_RATE_P = 0 then
						t_TURNOVER_DAY := 0;
					else
						-- 非當月且 turnover day不足 20 補到 20 天
						if REC2.YYYYMM <> to_char(sysdate,'yyyymm') and t_TURNOVER_DAY < 20 then
							t_TURNOVER_DAY := 20;
						end if;
					end if;
					t_TURNOVER_DAY2 := 30 - t_TURNOVER_DAY;
					if REC2.ORG_DM <= 0 then   --若該月 ORG_DM 為 0, 抓上個月的 DM_RATE來放
						t_DM_RATE := round(((t_DM_RATE_P * t_DIFF_RATE * t_TURNOVER_DAY) + (t_DM_RATE_P * t_TURNOVER_DAY2)) / 30,6);
					else
						t_DM_RATE := round(((t_DM_RATE_P * t_DIFF_RATE * t_TURNOVER_DAY) + (REC2.ORG_DM * t_TURNOVER_DAY2)) / 30,6);
					end if;
					t_DM_RATE_P := t_DM_RATE;
					update DMS_RPT01_PROJECT_T07 set
						DM_RATE = t_DM_RATE,
						TURNOVER_DAY = 0
					where BU = REC1.BU and PROJECT = REC1.PROJECT
					and YYYYMM = REC2.YYYYMM;
					t_TURNOVER_DAY := 0;
				end if;
				commit;
			end if;
		end loop;
	end loop;

	--(270) 回覆 actual 該月正確的 NET_REVENUE_USD
	update DMS_RPT01_PROJECT_T07
		set NET_REVENUE_USD = (
			select nvl(sum(NET_REVENUE_USD),0) from DMS_RPT01_PROJECT_T03A
			where BU = DMS_RPT01_PROJECT_T07.BU
			and PROJECT_NAME = DMS_RPT01_PROJECT_T07.PROJECT_NAME
			and PRODUCT_TYPE = DMS_RPT01_PROJECT_T07.PRODUCT_TYPE
			and PERIOD = DMS_RPT01_PROJECT_T07.YYYYMM
		)
	where ACTUAL_FLAG = 'Y'
	and ( BU, PROJECT_NAME, PRODUCT_TYPE, YYYYMM ) in (
		select BU, PROJECT_NAME, PRODUCT_TYPE, PERIOD from DMS_RPT01_PROJECT_T03A
	);
	commit;

	--(300) 計算 Customer DM
	iTracePoint := 300;
	delete from DMS_RPT01_PROJECT_T08;
	commit;
	iTracePoint := 310;
	insert into DMS_RPT01_PROJECT_T08 (
		BU, PROJECT_NAME, PRODUCT_TYPE, PROJECT, YYYYMM, ACTUAL_FLAG,
		ORG_DM, INV_AMT_USD, NET_REVENUE_USD, TURNOVER_DAY, DM_RATE, CUSTOMER_NAME
	)
	select distinct a.BU, a.PROJECT_NAME, a.PRODUCT_TYPE, a.PROJECT, a.YYYYMM, a.ACTUAL_FLAG,
		a.ORG_DM, a.INV_AMT_USD, a.NET_REVENUE_USD, a.TURNOVER_DAY, a.DM_RATE,
		(
			select distinct b1.CUSTOMER_NAME from DMM_UPL002_PROJECT b1, DMM_UPL001_SELLING b2
			where b1.PROJECT_NAME = a.PROJECT_NAME
			and b1.PRODUCT_TYPE = a.PRODUCT_TYPE
			and nvl(b2.BU, b1.PRODUCT_LINE) = a.BU
			and b2.COMPANY_CODE (+)= b1.MFG_SITE
			and b2.PLANT (+)= b1.PLANT
			and b2.FG (+)= b1.FG_MATERIAL_NO
		) as CUSTOMER_NAME
	from DMS_RPT01_PROJECT_T07 a
	where a.DM_RATE != 0
	and ( a.PROJECT_NAME, a.PRODUCT_TYPE ) not in (  -- > PROJECT_NAME + PRODUCT_TYPE對到多Customer則不算
		select PROJECT_NAME, PRODUCT_TYPE from (
			select distinct PROJECT_NAME, PRODUCT_TYPE, CUSTOMER_NAME
			from DMM_UPL002_PROJECT
		) group by PROJECT_NAME, PRODUCT_TYPE
		having count(*) > 1
	);
	commit;
	iTracePoint := 320;
	delete from DMS_RPT01_PROJECT_T09;
	commit;
	iTracePoint := 330;
	insert into DMS_RPT01_PROJECT_T09 (
		BU, CUSTOMER_NAME, YYYYMM, DM_RATE, NET_COST, NET_REVENUE
	)
	select BU, CUSTOMER_NAME, YYYYMM,
		decode(NET_REVENUE,0,0,round(NET_COST / NET_REVENUE,6)) as DM_RATE,
		NET_COST, NET_REVENUE
	from (
		select BU, CUSTOMER_NAME, YYYYMM,
			sum(NET_REVENUE_USD) as NET_REVENUE,
			sum(NET_REVENUE_USD * DM_RATE) as NET_COST
		from (
			select * from DMS_RPT01_PROJECT_T08
		) group by BU, CUSTOMER_NAME, YYYYMM
	);
	commit;

	--(400) 計算 BU DM
	iTracePoint := 400;
	delete from DMS_RPT01_PROJECT_T10;
	commit;
	iTracePoint := 410;
	insert into DMS_RPT01_PROJECT_T10 (
		BU, YYYYMM, DM_RATE, REVENUE_ORG, COST_ORG, DM_RATE_ORG,
		REVENUE_ADD, COST_ADD
	)
	select BU, YYYYMM,
		decode((NET_REVENUE + NET_REVENUE2),0,0,round((NET_COST + NET_COST2) / (NET_REVENUE + NET_REVENUE2),6)) as DM_RATE,
		NET_REVENUE, NET_COST,
		decode(NET_REVENUE,0,0,round(NET_COST / NET_REVENUE,6)) as DM_RATE_ORG,
		NET_REVENUE2, NET_COST2
	from (
		select BU, YYYYMM,
			sum(NET_REVENUE_USD) as NET_REVENUE,
			sum(NET_REVENUE_USD * DM_RATE) as NET_COST,
			(
				select nvl(sum(AMOUNT),0) from DMM_UPL003_SHD_SPECIAL_COST
				where BU = DMS_RPT01_PROJECT_T07.BU
				and YYYYMM = DMS_RPT01_PROJECT_T07.YYYYMM
				and COST_OR_REVENUE = 'R'
			) as NET_REVENUE2,
			(
				select nvl(sum(AMOUNT),0) from DMM_UPL003_SHD_SPECIAL_COST
				where BU = DMS_RPT01_PROJECT_T07.BU
				and YYYYMM = DMS_RPT01_PROJECT_T07.YYYYMM
				and COST_OR_REVENUE = 'C'
			) as NET_COST2
		from DMS_RPT01_PROJECT_T07
		where DM_RATE != 0
		group by BU, YYYYMM
	);
	commit;

EXCEPTION
  WHEN OTHERS THEN
    cErrorText := SQLERRM() ;
    MAIL_FILE_BIDBDBADMIN(in_to_name=>'minhorng@ms.usi.com.tw',subject   => '[DMM]PL/SQL PLSQL_DMS_RPT_PROJECT_01 ERROR', message => '[PLSQL_DMS_RPT_PROJECT_01], The tracepoint is  ' || to_char(iTracePoint) || ' and ErrorText=' || cErrorText) ;
End PLSQL_DMS_RPT_PROJECT_01;
/

