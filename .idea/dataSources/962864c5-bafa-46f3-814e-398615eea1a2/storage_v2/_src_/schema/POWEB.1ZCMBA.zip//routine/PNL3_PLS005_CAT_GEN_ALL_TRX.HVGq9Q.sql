create PROCEDURE       PNL3_PLS005_CAT_GEN_ALL_TRX (
  --inCompany  in VARCHAR2,
  inPeriod in VARCHAR2
  --2008/10/15 Crate by wenrong
  --2008/11/6  要搬到collect_data時,不要再加上mtl_group,ship_to,bill_to,pn等資料,畢竟只是要計算出summary資料而已,不然在200810除了未分配有3萬筆,其他copa/pca/glaccount
  --加起來也2萬筆,卻跑出23萬筆的資料
  --2011/8/6 備份到PNL3_PLS005_CAT_GEN_ALL_TRX_V1,因為樓上那一塊常常有問題,檢查後都是會計自己在那裡加料,造成和SAP不合,所以直接抓會計的CUSTOMER MODEL最好了,有問題直接找會計
--2011/8/12 改了邏輯後,原本不滿意的變滿意了,但原本滿意的變不滿意了,有偷拿裡面的資料去做別的報表,所以要先回一版PNL3_PLS005_CAT_GEN_ALL_TRX_V1給USER,然後再回來此版本
--再叫USER以後用別的報表,不能用這個報表的資料當其他用途
)
AUTHID DEFINER
is

   

  
  --呆帳金額(待寫)
  
  a_AMOUNT_L       PNL3_TRX001_COPA.AMT_TWD%TYPE;
  a_AMOUNT_T       PNL3_TRX001_COPA.AMT_TWD%TYPE;
  a_AMOUNT_U       PNL3_TRX001_COPA.AMT_TWD%TYPE;
  Ex_AMOUNT_L      PNL3_TRX001_COPA.AMT_TWD%TYPE;
  Ex_AMOUNT_T      PNL3_TRX001_COPA.AMT_TWD%TYPE;
  Ex_AMOUNT_U      PNL3_TRX001_COPA.AMT_TWD%TYPE;
  a_COUNTER        INTEGER;
  a_Rate           Number(10,2);
  a_YEAR    PNL_MSA001_EM_DATA.YYYY%TYPE;
  a_MONTH   PNL_MSA001_EM_DATA.MONTH%TYPE;
  A_AMT     PNL3_TRX001_COPA.AMT_TWD%TYPE;
 BEGIN
 
    a_YEAR  := SUBSTRB(inPeriod,1,4);
    a_MONTH :=SUBSTRB(inPeriod,5,6); 
   
   --PNL2_PLS006_EM_TRX(inPeriod);  --將Earning Model資料產生至PNL2_TRX001_SUMMARY_DATA
   --以上PLSQL執行完後再由下段PLSQL執行搬至PNL2_TRX001_SUMMARY_DATA
   
   
   --PNL2_PLS002_REALIZED_GM_TRX;產生已實現資料,由WEB驅動PLSQL
   --PNL2_PLS001_BAD_DEBT_TRX :產生費用裡的-呆帳資料,由WEB驅動PLSQL


   
   DELETE FROM PNL3_TRX005_COLLECT_DETAIL_PN
   WHERE Period = inPeriod;
   Commit;


   INSERT INTO PNL3_TRX005_COLLECT_DETAIL_PN 
               (COMPANY_CODE,PERIOD,PROFIT_CENTER,SOURCE,BILL_TO_PARTY,MTL_GROUP,END_CUSTOMER_ID,
                SHIP_TO_PARTY,PART_NO,PLANT_CODE,COST_ELEMENT,MTL_TYPE,SEARCH_TERM,R_KIND,AREA1,AREA2,AREA3,PDM_PROJECT,
                AMT_LOCAL,AMT_TWD,AMT_USD,CREATE_DATE,NET_QTY,PROJECT_NAME,PROJECT_TYPE) 
        SELECT COMPANY_CODE,PERIOD,PROFIT_CENTER,SOURCE,BILL_TO_PARTY,MTL_GROUP,END_CUSTOMER_ID,
               SHIP_TO_PARTY,PART_NO,PLANT_CODE,COST_ELEMENT,MTL_TYPE,SEARCH_TERM,R_KIND,AREA1,AREA2,AREA3,PDM_PROJECT,
               AMT_LOCAL,AMT_TWD,AMT_USD,sysdate,NET_QTY,PROJECT_NAME,PROJECT_TYPE
          FROM PNL3_TRX001_COPA 
         WHERE PERIOD = inPeriod;
      


      
         
   PNL3_PLS011_EXPENSE_MAP_TRX(inPeriod);
   
   --以上是在存明細資料供user查看,以下將從明細搬資料至  PNL3_TRX005_COLLECT_PN
  --以下在計算加總
   DELETE FROM PNL3_TRX005_COLLECT_PN
   WHERE Period = inPeriod;
   Commit;

   FOR REC1 in (SELECT COMPANY_CODE,PERIOD,PROFIT_CENTER,END_CUSTOMER_ID,PROJECT_NAME,PROJECT_TYPE,R_KIND,AREA1,AREA2,AREA3,SOURCE,PART_NO,
                       SUM(AMT_LOCAL) AMT_LOCAL,SUM(AMT_USD) AMT_USD,SUM(AMT_TWD) AMT_TWD
                  FROM PNL3_TRX005_COLLECT_DETAIL_PN
                 WHERE  PERIOD = inPeriod 
              GROUP BY COMPANY_CODE,PERIOD,PROFIT_CENTER,END_CUSTOMER_ID,R_KIND,AREA1,AREA2,AREA3,SOURCE,PART_NO,PROJECT_NAME,PROJECT_TYPE) Loop

         Insert into PNL3_TRX005_COLLECT_PN (
                COMPANY_CODE    , PERIOD         , PROFIT_CENTER      , END_CUSTOMER_ID ,
                AMT_LOCAL      , AMT_USD            , AMT_TWD         , SOURCE          ,
                R_KIND          , AREA1          ,AREA2               , AREA3           ,
                CREATE_DATE     ,PART_NO         , PROJECT_NAME       , PROJECT_TYPE
                      ) VALUES (
                        REC1.COMPANY_CODE       , REC1.PERIOD       , REC1.PROFIT_CENTER      , REC1.END_CUSTOMER_ID ,
                        REC1.AMT_LOCAL          , REC1.AMT_USD      , REC1.AMT_TWD            , REC1.SOURCE          ,
                        REC1.R_KIND             , REC1.AREA1        , REC1.AREA2              , REC1.AREA3           ,
                        SYSDATE                 , REC1.PART_NO      , REC1.PROJECT_NAME       , REC1.PROJECT_TYPE);
          Commit;
   END LOOP;
   

   
   --從Revenue角度來看,但也得考慮到end customer可能沒有Revenue只有成本??雖然不大可能發生,仍要加入這條邏輯(寫在此LOOP後)
   
   FOR REC1 in (SELECT PROFIT_CENTER,END_CUSTOMER_ID,COMPANY_CODE,SOURCE,PART_NO,
                       SUM(AMT_LOCAL) AMT_LOCAL,SUM(AMT_USD) AMT_USD , SUM(AMT_TWD) AMT_TWD
               FROM PNL3_TRX005_COLLECT_DETAIL_PN
              WHERE R_KIND = 'PL01'
                AND PERIOD = inPeriod
                AND AREA1  = '1'
                AND AREA2  = '1'
                AND AREA3  = '0'
                GROUP BY PROFIT_CENTER,END_CUSTOMER_ID,COMPANY_CODE,SOURCE,PART_NO) Loop
         Insert into PNL3_TRX005_COLLECT_PN (
                COMPANY_CODE    , PERIOD         , PROFIT_CENTER      , END_CUSTOMER_ID ,
                AMT_LOCAL       ,AMT_USD         , AMT_TWD            , SOURCE          ,
                R_KIND          , AREA1          ,AREA2               , AREA3           ,
                CREATE_DATE     , TYPE           , PART_NO
                      ) VALUES (
                        REC1.COMPANY_CODE       , inPeriod          , REC1.PROFIT_CENTER      , REC1.END_CUSTOMER_ID ,
                        REC1.AMT_LOCAL          ,REC1.AMT_USD       , REC1.AMT_TWD            , REC1.SOURCE          ,
                        'PL01'                  , '1'                 , '4'                       , '0'           ,
                        SYSDATE                 ,'SUM'              , REC1.PART_NO);
          Commit;
          
   --Gross margin & COGS Subtotal


          a_AMOUNT_L := REC1.AMT_LOCAL;
          a_AMOUNT_T := REC1.AMT_TWD; 
          a_AMOUNT_U := REC1.AMT_USD; 
          FOR REC2 in (SELECT PROFIT_CENTER,END_CUSTOMER_ID,COMPANY_CODE,SOURCE,PART_NO,
                            NVL(SUM(AMT_LOCAL),0) AMT_LOCAL,NVL(SUM(AMT_USD),0) AMT_USD , NVL(SUM(AMT_TWD),0) AMT_TWD
                       FROM PNL3_TRX005_COLLECT_DETAIL_PN
                      WHERE R_KIND = 'PL01'
                        AND PERIOD = inPeriod
                        AND PROFIT_CENTER = REC1.PROFIT_CENTER
                        AND COMPANY_CODE = REC1.COMPANY_CODE
                        AND END_CUSTOMER_ID = REC1.END_CUSTOMER_ID
                        AND PART_NO = REC1.PART_NO
                        AND SOURCE = REC1.SOURCE
                        AND AREA1  = '2'
                        AND AREA2  IN ('2','3','4','5')
                        --AND AREA3  = '0'
                        GROUP BY PROFIT_CENTER,END_CUSTOMER_ID,COMPANY_CODE,SOURCE,PART_NO) Loop
                 a_AMOUNT_L := a_AMOUNT_L - REC2.AMT_LOCAL;     
                 a_AMOUNT_T := a_AMOUNT_T - REC2.AMT_TWD; 
                 a_AMOUNT_U := a_AMOUNT_U - REC2.AMT_USD;   
                 --COGS SubTotal
                 Insert into PNL3_TRX005_COLLECT_PN (
                        COMPANY_CODE    , PERIOD         , PROFIT_CENTER      , END_CUSTOMER_ID ,
                        AMT_LOCAL       ,AMT_USD         , AMT_TWD            , SOURCE          ,
                        R_KIND          , AREA1          ,AREA2               , AREA3           ,
                        CREATE_DATE     , TYPE           , PART_NO
                      ) VALUES (
                        REC2.COMPANY_CODE       , inPeriod          , REC2.PROFIT_CENTER      , REC2.END_CUSTOMER_ID ,
                        REC2.AMT_LOCAL          , REC2.AMT_USD      , REC2.AMT_TWD            , REC1.SOURCE          ,
                        'PL01'                  , '2'                 , '6'                       , '0'           ,
                        SYSDATE                 , 'SUM'             , REC2.PART_NO);
                 Commit;
                 

          END LOOP;
         --Gross margin 
         
         Insert into PNL3_TRX005_COLLECT_PN (
                COMPANY_CODE    , PERIOD         , PROFIT_CENTER      , END_CUSTOMER_ID ,
                AMT_LOCAL       ,AMT_USD         , AMT_TWD            , SOURCE          ,
                R_KIND          , AREA1          ,AREA2               , AREA3           ,
                CREATE_DATE     , TYPE           ,PART_NO
                      ) VALUES (
                        REC1.COMPANY_CODE       , inPeriod          , REC1.PROFIT_CENTER      , REC1.END_CUSTOMER_ID ,
                        a_AMOUNT_L              , a_AMOUNT_U        , a_AMOUNT_T              , REC1.SOURCE              ,
                        'PL01'                  , '3'                 , '0'                       , '0'           ,
                        SYSDATE                 , 'SUM'             , REC1.PART_NO);
          Commit;
   END LOOP;
   
   FOR REC1 in (SELECT PROFIT_CENTER,END_CUSTOMER_ID,COMPANY_CODE,PERIOD,SOURCE,PART_NO,
                            NVL(SUM(AMT_LOCAL),0) AMT_LOCAL,NVL(SUM(AMT_USD),0) AMT_USD , NVL(SUM(AMT_TWD),0) AMT_TWD
                       FROM PNL3_TRX005_COLLECT_DETAIL_PN
                      WHERE R_KIND = 'PL01'
                        AND PERIOD = inPeriod
                        --AND PROFIT_CENTER = REC1.PROFIT_CENTER
                        --AND COMPANY_CODE = REC1.COMPANY_CODE
                        --AND END_CUSTOMER_ID = REC1.END_CUSTOMER_ID
                        AND AREA1  = '2'
                        AND AREA2  IN ('2','3','4','5')
                        --AND AREA3  = '0'
                        GROUP BY PROFIT_CENTER,END_CUSTOMER_ID,COMPANY_CODE,PERIOD,SOURCE,PART_NO) Loop
         a_COUNTER := 0;
         a_AMOUNT_L := 0;
         a_AMOUNT_T := 0; 
         a_AMOUNT_U := 0; 
         BEGIN
           SELECT COUNT(*) INTO a_COUNTER
               FROM PNL3_TRX005_COLLECT_DETAIL_PN
              WHERE R_KIND = 'PL01'
                AND PERIOD = inPeriod
                AND AREA1  = '1'
                AND AREA2  = '1'
                AND AREA3  = '0'
                AND PROFIT_CENTER = REC1.PROFIT_CENTER
                AND END_CUSTOMER_ID = REC1.END_CUSTOMER_ID
                AND COMPANY_CODE = REC1.COMPANY_CODE
                AND SOURCE = REC1.SOURCE
                AND PART_NO = REC1.PART_NO
                GROUP BY PROFIT_CENTER,END_CUSTOMER_ID,COMPANY_CODE,SOURCE,PART_NO;
         IF SQL%NOTFOUND THEN
           a_COUNTER := 0;
         END IF;
         EXCEPTION
           WHEN OTHERS THEN
             a_COUNTER := 0;
         END;
         
         --表示此PC+SITE+END_CUSTOMER 沒有營收,只有成本
         IF a_COUNTER = 0 THEN
                 Insert into PNL3_TRX005_COLLECT_PN (
                        COMPANY_CODE    , PERIOD         , PROFIT_CENTER      , END_CUSTOMER_ID ,
                        AMT_LOCAL       ,AMT_USD         , AMT_TWD            , SOURCE          ,
                        R_KIND          , AREA1          ,AREA2               , AREA3           ,
                        CREATE_DATE     , TYPE           ,PART_NO
                      ) VALUES (
                        REC1.COMPANY_CODE       , REC1.PERIOD       , REC1.PROFIT_CENTER      , REC1.END_CUSTOMER_ID ,
                        REC1.AMT_LOCAL          , REC1.AMT_USD      , REC1.AMT_TWD            , REC1.SOURCE             ,
                        'PL01'                  , '2'                 , '6'                       , '0'           ,
                        SYSDATE                 , 'SUM'             , REC1.PART_NO);
                 Commit;
         --Gross margin 
                 a_AMOUNT_L := a_AMOUNT_L - REC1.AMT_LOCAL;
                 a_AMOUNT_T := a_AMOUNT_T - REC1.AMT_TWD; 
                 a_AMOUNT_U := a_AMOUNT_U - REC1.AMT_USD; 
                 Insert into PNL3_TRX005_COLLECT_PN (
                        COMPANY_CODE    , PERIOD         , PROFIT_CENTER      , END_CUSTOMER_ID ,
                        AMT_LOCAL       ,AMT_USD         , AMT_TWD            , SOURCE          ,
                        R_KIND          , AREA1          ,AREA2               , AREA3           ,
                        CREATE_DATE     , TYPE           , PART_NO
                      ) VALUES (
                        REC1.COMPANY_CODE       , REC1.PERIOD       , REC1.PROFIT_CENTER      , REC1.END_CUSTOMER_ID ,
                        a_AMOUNT_L              , a_AMOUNT_U      , a_AMOUNT_T                , REC1.SOURCE             ,
                        'PL01'                  , '3'                 , '0'                       , '0'           ,
                        SYSDATE                 , 'SUM'            , REC1.PART_NO);
                 Commit;
         END IF;
   END LOOP;
   

   
   --exp.的total 或 subtotal要計算完再加
   FOR REC1 in (SELECT PROFIT_CENTER,END_CUSTOMER_ID,COMPANY_CODE,PERIOD,SOURCE,PART_NO,
                            NVL(SUM(AMT_LOCAL),0) AMT_LOCAL,NVL(SUM(AMT_USD),0) AMT_USD , NVL(SUM(AMT_TWD),0) AMT_TWD
                       FROM PNL3_TRX005_COLLECT_DETAIL_PN
                      WHERE R_KIND = 'PL01'
                        AND PERIOD = inPeriod
                        AND AREA1  = '4'
                        AND AREA2  = '1'
                        AND AREA3 BETWEEN '1' AND '89'
                        GROUP BY PROFIT_CENTER,END_CUSTOMER_ID,COMPANY_CODE,PERIOD,SOURCE,PART_NO) Loop
                 Insert into PNL3_TRX005_COLLECT_PN (
                        COMPANY_CODE    , PERIOD         , PROFIT_CENTER      , END_CUSTOMER_ID ,
                        AMT_LOCAL       ,AMT_USD         , AMT_TWD            , SOURCE          ,
                        R_KIND          , AREA1          ,AREA2               , AREA3           ,
                        CREATE_DATE     , TYPE           ,PART_NO             
                      ) VALUES (
                        REC1.COMPANY_CODE       , REC1.PERIOD       , REC1.PROFIT_CENTER      , REC1.END_CUSTOMER_ID ,
                        REC1.AMT_LOCAL          , REC1.AMT_USD      , REC1.AMT_TWD            , REC1.SOURCE             ,
                        'PL01'                  , '4'                 , '1'                    , '90'           ,
                        SYSDATE                 , 'SUM'             , REC1.PART_NO);
                 Commit;
                 Insert into PNL3_TRX005_COLLECT_PN (
                        COMPANY_CODE    , PERIOD         , PROFIT_CENTER      , END_CUSTOMER_ID ,
                        AMT_LOCAL       ,AMT_USD         , AMT_TWD            , SOURCE          ,
                        R_KIND           , AREA1          ,AREA2               , AREA3           ,
                        CREATE_DATE     , TYPE           ,PART_NO
                      ) VALUES (
                        REC1.COMPANY_CODE       , REC1.PERIOD       , REC1.PROFIT_CENTER      , REC1.END_CUSTOMER_ID ,
                        0          , 0      , 0            , REC1.SOURCE             ,
                        'PL01'                  , '4'                 , '1'                    , '0'                    ,
                        SYSDATE                , 'SUM'              , REC1.PART_NO);
                 Commit;
   END LOOP;
   


   
   FOR REC1 in (SELECT PROFIT_CENTER,END_CUSTOMER_ID,COMPANY_CODE,PERIOD,SOURCE,PART_NO
                       FROM PNL3_TRX005_COLLECT_DETAIL_PN
                      WHERE R_KIND = 'PL01'
                        AND PERIOD = inPeriod
                        AND AREA1  = '4'
                        GROUP BY PROFIT_CENTER,END_CUSTOMER_ID,COMPANY_CODE,PERIOD,SOURCE,PART_NO) LOOP
                 Insert into PNL3_TRX005_COLLECT_PN (
                        COMPANY_CODE    , PERIOD         , PROFIT_CENTER      , END_CUSTOMER_ID ,
                        AMT_LOCAL       ,AMT_USD         , AMT_TWD            , SOURCE          ,
                        R_KIND          , AREA1          ,AREA2               , AREA3           ,
                        CREATE_DATE     , TYPE           , PART_NO
                      ) VALUES (
                        REC1.COMPANY_CODE       , REC1.PERIOD       , REC1.PROFIT_CENTER      , REC1.END_CUSTOMER_ID ,
                        0          , 0      , 0            , REC1.SOURCE             ,
                        'PL01'                  , '4'                 , '0'                    , '0'                    ,
                        SYSDATE                 , 'SUM'             , REC1.PART_NO);
                 Commit;
   END LOOP;
   
   FOR REC1 in (SELECT PROFIT_CENTER,END_CUSTOMER_ID,COMPANY_CODE,PERIOD,SOURCE,PART_NO,
                            NVL(SUM(AMT_LOCAL),0) AMT_LOCAL,NVL(SUM(AMT_USD),0) AMT_USD , NVL(SUM(AMT_TWD),0) AMT_TWD
                       FROM PNL3_TRX005_COLLECT_DETAIL_PN
                      WHERE R_KIND = 'PL01'
                        AND PERIOD = inPeriod
                        AND AREA1  = '4'
                        AND AREA2  = '2'
                        AND AREA3 BETWEEN '1' AND '89'
                        GROUP BY PROFIT_CENTER,END_CUSTOMER_ID,COMPANY_CODE,PERIOD,SOURCE,PART_NO) Loop
                 Insert into PNL3_TRX005_COLLECT_PN (
                        COMPANY_CODE    , PERIOD         , PROFIT_CENTER      , END_CUSTOMER_ID ,
                        AMT_LOCAL       ,AMT_USD         , AMT_TWD            , SOURCE          ,
                        R_KIND          , AREA1          ,AREA2               , AREA3           ,
                        CREATE_DATE     , TYPE           , PART_NO            
                      ) VALUES (
                        REC1.COMPANY_CODE       , REC1.PERIOD       , REC1.PROFIT_CENTER      , REC1.END_CUSTOMER_ID ,
                        REC1.AMT_LOCAL          , REC1.AMT_USD      , REC1.AMT_TWD            , REC1.SOURCE             ,
                        'PL01'                  , '4'                 , '2'                    , '90'           ,
                        SYSDATE                 , 'SUM'             , REC1.PART_NO);
                 Commit;
                 Insert into PNL3_TRX005_COLLECT_PN (
                        COMPANY_CODE    , PERIOD         , PROFIT_CENTER      , END_CUSTOMER_ID ,
                        AMT_LOCAL       ,AMT_USD         , AMT_TWD            , SOURCE          ,
                        R_KIND          , AREA1          ,AREA2               , AREA3           ,
                        CREATE_DATE     , TYPE            ,PART_NO
                      ) VALUES (
                        REC1.COMPANY_CODE       , REC1.PERIOD       , REC1.PROFIT_CENTER      , REC1.END_CUSTOMER_ID ,
                        0          , 0      , 0            , REC1.SOURCE             ,
                        'PL01'                  , '4'                 , '2'                    , '0'                    ,
                        SYSDATE                 , 'SUM'    , REC1.PART_NO);
                 Commit;
                 
   END LOOP;
   
   FOR REC1 in (SELECT PROFIT_CENTER,END_CUSTOMER_ID,COMPANY_CODE,PERIOD,SOURCE,PART_NO,
                            NVL(SUM(AMT_LOCAL),0) AMT_LOCAL,NVL(SUM(AMT_USD),0) AMT_USD , NVL(SUM(AMT_TWD),0) AMT_TWD
                       FROM PNL3_TRX005_COLLECT_DETAIL_PN
                      WHERE R_KIND = 'PL01'
                        AND PERIOD = inPeriod
                        AND AREA1  = '4'
                        AND AREA2  = '3'
                        AND AREA3 BETWEEN '1' AND '89'
                        GROUP BY PROFIT_CENTER,END_CUSTOMER_ID,COMPANY_CODE,PERIOD,SOURCE,PART_NO) Loop
                 Insert into PNL3_TRX005_COLLECT_PN (
                        COMPANY_CODE    , PERIOD         , PROFIT_CENTER      , END_CUSTOMER_ID ,
                        AMT_LOCAL       ,AMT_USD         , AMT_TWD            , SOURCE          ,
                        R_KIND          , AREA1          ,AREA2               , AREA3           ,
                        CREATE_DATE    , TYPE            , PART_NO
                      ) VALUES (
                        REC1.COMPANY_CODE       , REC1.PERIOD       , REC1.PROFIT_CENTER      , REC1.END_CUSTOMER_ID ,
                        REC1.AMT_LOCAL          , REC1.AMT_USD      , REC1.AMT_TWD            , REC1.SOURCE             ,
                        'PL01'                  , '4'                 , '3'                    , '90'           ,
                        SYSDATE                 , 'SUM'            , REC1.PART_NO);
                 Commit;
                 Insert into PNL3_TRX005_COLLECT_PN (
                        COMPANY_CODE    , PERIOD         , PROFIT_CENTER      , END_CUSTOMER_ID ,
                        AMT_LOCAL       ,AMT_USD         , AMT_TWD            , SOURCE          ,
                        R_KIND          , AREA1          ,AREA2               , AREA3           ,
                        CREATE_DATE     , TYPE           , PART_NO
                      ) VALUES (
                        REC1.COMPANY_CODE       , REC1.PERIOD       , REC1.PROFIT_CENTER      , REC1.END_CUSTOMER_ID ,
                        0          , 0      , 0            , REC1.SOURCE             ,
                        'PL01'                  , '4'                 , '3'                    , '0'                    ,
                        SYSDATE         ,'SUM'             , REC1.PART_NO);
                 Commit;
   END LOOP;

  FOR REC1 in (SELECT PROFIT_CENTER,END_CUSTOMER_ID,COMPANY_CODE,PERIOD,SOURCE,PART_NO,
                            NVL(SUM(AMT_LOCAL),0) AMT_LOCAL,NVL(SUM(AMT_USD),0) AMT_USD , NVL(SUM(AMT_TWD),0) AMT_TWD
                       FROM PNL3_TRX005_COLLECT_PN
                      WHERE R_KIND = 'PL01'
                        AND PERIOD = inPeriod
                        AND AREA1  = '4'
                        AND AREA3 = '90'
                        GROUP BY PROFIT_CENTER,END_CUSTOMER_ID,COMPANY_CODE,PERIOD,SOURCE,PART_NO) Loop
                 Insert into PNL3_TRX005_COLLECT_PN (
                        COMPANY_CODE    , PERIOD         , PROFIT_CENTER      , END_CUSTOMER_ID ,
                        AMT_LOCAL       ,AMT_USD         , AMT_TWD            , SOURCE          ,
                        R_KIND          , AREA1          ,AREA2               , AREA3           ,
                        CREATE_DATE     , TYPE           , PART_NO
                      ) VALUES (
                        REC1.COMPANY_CODE       , REC1.PERIOD       , REC1.PROFIT_CENTER      , REC1.END_CUSTOMER_ID ,
                        REC1.AMT_LOCAL          , REC1.AMT_USD      , REC1.AMT_TWD            , REC1.SOURCE             ,
                        'PL01'                  , '4'                 , '4'                    , '0'           ,
                        SYSDATE                 ,'SUM'              , REC1.PART_NO);
                 Commit;

   END LOOP;
      
   FOR REC1 in (SELECT COMPANY_CODE,PROFIT_CENTER,END_CUSTOMER_ID,PART_NO,
                      SUM(AMT_LOCAL) AMT_LOCAL, SUM(AMT_USD) AMT_USD, SUM(AMT_TWD) AMT_TWD
             FROM PNL3_TRX005_COLLECT_PN
            WHERE PERIOD = inPeriod
              AND R_KIND = 'PL01'
              AND AREA1 = '3'
              AND AREA2 = '0'
              AND AREA3 = '0'
            GROUP BY COMPANY_CODE,PROFIT_CENTER,END_CUSTOMER_ID,PART_NO ) LOOP
          a_COUNTER := 0;
          a_AMOUNT_L := REC1.AMT_LOCAL;
          a_AMOUNT_T := REC1.AMT_TWD; 
          a_AMOUNT_U := REC1.AMT_USD; 
          FOR REC2 in (SELECT PROFIT_CENTER,END_CUSTOMER_ID,COMPANY_CODE,PART_NO,
                            NVL(SUM(AMT_LOCAL),0) AMT_LOCAL,NVL(SUM(AMT_USD),0) AMT_USD , NVL(SUM(AMT_TWD),0) AMT_TWD
                       FROM PNL3_TRX005_COLLECT_PN
                      WHERE R_KIND = 'PL01'
                        AND PERIOD = inPeriod
                        AND PROFIT_CENTER = REC1.PROFIT_CENTER
                        AND COMPANY_CODE = REC1.COMPANY_CODE
                        AND END_CUSTOMER_ID = REC1.END_CUSTOMER_ID
                        AND PART_NO = REC1.PART_NO
                        AND AREA1  = '4'
                        AND AREA2  = '4'
                        AND AREA3  = '0'
                        GROUP BY PROFIT_CENTER,END_CUSTOMER_ID,COMPANY_CODE,PART_NO) Loop
                 a_AMOUNT_L := a_AMOUNT_L + REC2.AMT_LOCAL;     
                 a_AMOUNT_T := a_AMOUNT_T + REC2.AMT_TWD; 
                 a_AMOUNT_U := a_AMOUNT_U + REC2.AMT_USD;   
                 a_COUNTER := a_COUNTER + 1;
                 --COGS SubTotal
                 Insert into PNL3_TRX005_COLLECT_PN (
                        COMPANY_CODE    , PERIOD         , PROFIT_CENTER      , END_CUSTOMER_ID ,
                        AMT_LOCAL       ,AMT_USD         , AMT_TWD            , SOURCE          ,
                        R_KIND          , AREA1          ,AREA2               , AREA3           ,
                        CREATE_DATE     , TYPE           , PART_NO
                      ) VALUES (
                        REC2.COMPANY_CODE       , inPeriod          , REC2.PROFIT_CENTER      , REC2.END_CUSTOMER_ID ,
                        a_AMOUNT_L          , a_AMOUNT_U      , a_AMOUNT_T            , 'TOTAL'          ,
                        'PL01'                  , '4'                 , '5'                       , '0'           ,
                        SYSDATE                 ,'SUM'              , REC2.PART_NO);
                 Commit;
                 

          END LOOP;
          IF a_COUNTER = 0 THEN
                 Insert into PNL3_TRX005_COLLECT_PN (
                        COMPANY_CODE    , PERIOD         , PROFIT_CENTER      , END_CUSTOMER_ID ,
                        AMT_LOCAL       ,AMT_USD         , AMT_TWD            , SOURCE          ,
                        R_KIND          , AREA1          ,AREA2               , AREA3           ,
                        CREATE_DATE     , TYPE           , PART_NO
                      ) VALUES (
                        REC1.COMPANY_CODE       , inPeriod          , REC1.PROFIT_CENTER      , REC1.END_CUSTOMER_ID ,
                        a_AMOUNT_L              , a_AMOUNT_U      , a_AMOUNT_T            , 'TOTAL'          ,
                        'PL01'                  , '4'                 , '5'                       , '0'           ,
                        SYSDATE                 ,'SUM'              , REC1.PART_NO);
                 Commit;
          END IF;
   END LOOP;
   
   
   FOR REC2 in (SELECT PROFIT_CENTER,END_CUSTOMER_ID,COMPANY_CODE,PART_NO,
                            NVL(SUM(AMT_LOCAL),0) AMT_LOCAL,NVL(SUM(AMT_USD),0) AMT_USD , NVL(SUM(AMT_TWD),0) AMT_TWD
                       FROM PNL3_TRX005_COLLECT_PN
                      WHERE R_KIND = 'PL01'
                        AND PERIOD = inPeriod
                        AND AREA1  = '4'
                        AND AREA2  = '4'
                        AND AREA3  = '0'
                        GROUP BY PROFIT_CENTER,END_CUSTOMER_ID,COMPANY_CODE,PART_NO) Loop
          a_AMOUNT_L := REC2.AMT_LOCAL;
          a_AMOUNT_T := REC2.AMT_TWD; 
          a_AMOUNT_U := REC2.AMT_USD;
        a_COUNTER := 0;
        BEGIN
               SELECT COUNT(*) INTO a_COUNTER
                       FROM PNL3_TRX005_COLLECT_PN
                      WHERE R_KIND = 'PL01'
                        AND PERIOD = inPeriod
                        AND PROFIT_CENTER = REC2.PROFIT_CENTER
                        AND COMPANY_CODE = REC2.COMPANY_CODE
                        AND END_CUSTOMER_ID = REC2.END_CUSTOMER_ID
                        AND PART_NO = REC2.PART_NO
                        AND AREA1  = '3'
                        AND AREA2  = '0'
                        AND AREA3  = '0';
        EXCEPTION 
            WHEN OTHERS THEN
               a_COUNTER := 0;
        END;
          IF a_COUNTER = 0 THEN
                 Insert into PNL3_TRX005_COLLECT_PN (
                        COMPANY_CODE    , PERIOD         , PROFIT_CENTER      , END_CUSTOMER_ID ,
                        AMT_LOCAL       ,AMT_USD         , AMT_TWD            , SOURCE          ,
                        R_KIND          , AREA1          ,AREA2               , AREA3           ,
                        CREATE_DATE      , TYPE          , PART_NO
                      ) VALUES (
                        REC2.COMPANY_CODE       , inPeriod          , REC2.PROFIT_CENTER      , REC2.END_CUSTOMER_ID ,
                        a_AMOUNT_L              , a_AMOUNT_U      , a_AMOUNT_T            , 'TOTAL'          ,
                        'PL01'                  , '4'                 , '5'                       , '0'           ,
                        SYSDATE                  ,'SUM'             , REC2.PART_NO);
                 Commit;
          END IF;
   END LOOP;
   
  ---以下兩段UPDATE 指令在將金額由正轉負由負轉正
  UPDATE PNL3_TRX005_COLLECT_DETAIL_PN 
     SET ACCT_RATE = (SELECT RATE 
                        FROM PNL2_MAP001_ACCT_MAPPING 
                       WHERE R_KIND = PNL3_TRX005_COLLECT_DETAIL_PN.R_KIND 
                         AND AREA1 = PNL3_TRX005_COLLECT_DETAIL_PN.AREA1 
                         AND AREA2 = PNL3_TRX005_COLLECT_DETAIL_PN.AREA2 
                         AND AREA3 = PNL3_TRX005_COLLECT_DETAIL_PN.AREA3)
  WHERE PERIOD =  inPeriod;
  
    UPDATE PNL3_TRX005_COLLECT_DETAIL_PN 
     SET AMT_TWD = AMT_TWD * ACCT_RATE,
         AMT_USD = AMT_USD * ACCT_RATE,
         AMT_LOCAL = AMT_LOCAL * ACCT_RATE
                         
  WHERE PERIOD =  inPeriod;
  COMMIT;
  ---以下兩段UPDATE 指令在將金額由正轉負由負轉正
  UPDATE PNL3_TRX005_COLLECT_PN 
     SET ACCT_RATE = (SELECT RATE 
                        FROM PNL2_MAP001_ACCT_MAPPING 
                       WHERE R_KIND = PNL3_TRX005_COLLECT_PN.R_KIND 
                         AND AREA1 = PNL3_TRX005_COLLECT_PN.AREA1 
                         AND AREA2 = PNL3_TRX005_COLLECT_PN.AREA2 
                         AND AREA3 = PNL3_TRX005_COLLECT_PN.AREA3)
  WHERE PERIOD =  inPeriod;
  
    UPDATE PNL3_TRX005_COLLECT_PN 
     SET AMT_TWD = AMT_TWD * ACCT_RATE,
         AMT_USD = AMT_USD * ACCT_RATE,
         AMT_LOCAL = AMT_LOCAL * ACCT_RATE
                         
  WHERE PERIOD =  inPeriod;
  COMMIT;
   --額外的程式邏輯---要放在抓project其他屬性前
      UPDATE PNL3_TRX005_COLLECT_DETAIL_PN
      SET PROJECT_NAME = '材料轉售'
    WHERE period = inPeriod
      AND PROJECT_NAME IS NULL
      AND mtl_group BETWEEN '001' AND '059'
      AND mtl_type in ('RAW','Raw');
       commit;  
       
   UPDATE PNL3_TRX005_COLLECT_DETAIL_PN
      SET PROJECT_NAME = 'Service Charge'
    WHERE period = inPeriod
      AND PROJECT_NAME IS NULL
      AND mtl_type = 'SVC';
       commit;  

   UPDATE PNL3_TRX005_COLLECT_DETAIL_PN
      SET PROJECT_NAME = 'Not Assigned'
    WHERE period = inPeriod
      AND PROJECT_NAME IS NULL
      AND PART_NO IS NULL;
       commit; 

   UPDATE PNL3_TRX005_COLLECT_DETAIL_PN
      SET PROJECT_NAME = 'CA_PROJECT'
    WHERE period = inPeriod
      AND PROJECT_NAME IS NULL
      AND COMPANY_CODE = '2200';
       commit;

   UPDATE PNL3_TRX005_COLLECT_DETAIL_PN
      SET PROJECT_NAME = 'MX_PROJECT'
    WHERE period = inPeriod
      AND PROJECT_NAME IS NULL
      AND COMPANY_CODE = '2300';
       commit;
   

   UPDATE PNL3_TRX005_COLLECT_DETAIL_PN
      SET PJM =
             (SELECT PJM
                         FROM CEP_WEB002_PROJECT
                        WHERE PROJECT_NAME = PNL3_TRX005_COLLECT_DETAIL_PN.PROJECT_NAME)
    WHERE period = inPeriod;
   commit;   

   UPDATE PNL3_TRX005_COLLECT_DETAIL_PN
      SET PROJECT_L1 =
             (SELECT PROJECT_L1
                         FROM CEP_WEB002_PROJECT
                        WHERE PROJECT_NAME = PNL3_TRX005_COLLECT_DETAIL_PN.PROJECT_NAME)
    WHERE period = inPeriod;
       commit; 
         
   UPDATE PNL3_TRX005_COLLECT_DETAIL_PN
      SET PROJECT_L2 =
             (SELECT PROJECT_L2
                         FROM CEP_WEB002_PROJECT
                        WHERE PROJECT_NAME = PNL3_TRX005_COLLECT_DETAIL_PN.PROJECT_NAME)
    WHERE period = inPeriod;
       commit;
       
   UPDATE PNL3_TRX005_COLLECT_DETAIL_PN
      SET PROJECT_L3 =
             (SELECT PROJECT_L3
                         FROM CEP_WEB002_PROJECT
                        WHERE PROJECT_NAME = PNL3_TRX005_COLLECT_DETAIL_PN.PROJECT_NAME)
    WHERE period = inPeriod;
       commit;
       
   UPDATE PNL3_TRX005_COLLECT_DETAIL_PN
      SET PROJECT_L4 =
             (SELECT PROJECT_L4
                         FROM CEP_WEB002_PROJECT
                        WHERE PROJECT_NAME = PNL3_TRX005_COLLECT_DETAIL_PN.PROJECT_NAME)
    WHERE period = inPeriod;
       commit;
       
       
   UPDATE PNL3_TRX005_COLLECT_DETAIL_PN
      SET PROJECT_L5 =
             (SELECT PROJECT_L5
                         FROM CEP_WEB002_PROJECT
                        WHERE PROJECT_NAME = PNL3_TRX005_COLLECT_DETAIL_PN.PROJECT_NAME)
    WHERE period = inPeriod;
       commit;
       
   UPDATE PNL3_TRX005_COLLECT_DETAIL_PN
      SET PROJECT_L6 =
             (SELECT PROJECT_L6
                         FROM CEP_WEB002_PROJECT
                        WHERE PROJECT_NAME = PNL3_TRX005_COLLECT_DETAIL_PN.PROJECT_NAME)
    WHERE period = inPeriod;
       commit;
       


END PNL3_PLS005_CAT_GEN_ALL_TRX;
/

