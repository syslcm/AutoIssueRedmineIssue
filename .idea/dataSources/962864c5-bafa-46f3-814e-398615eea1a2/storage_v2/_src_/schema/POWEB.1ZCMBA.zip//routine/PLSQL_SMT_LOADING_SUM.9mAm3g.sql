create PROCEDURE PLSQL_SMT_LOADING_SUM(
  inCompany  in SMT_LOADING_SUM_T.COMPANY_CODE%TYPE,
  f_YYYYMMDD in VARCHAR2,
  t_YYYYMMDD in VARCHAR2
)
is
 iTracePoint  integer ;
 cErrorText varchar2(500);

BEGIN
  iTracePoint := '000';


  DELETE FROM SMT_LOADING_SUM WHERE COMPANY_CODE = inCompany AND D_TYPE = 'Planned'
     and YYYYWW IN (SELECT YYYYWW FROM SMT_LOADING_SUM_T WHERE COMPANY_CODE = inCompany AND D_TYPE = 'Planned' );

  iTracePoint := '100';
  Insert into SMT_LOADING_SUM (
        COMPANY_CODE , PD , DEPARTMENT , LINES , D_TYPE , IN_SUB , ITEMS , NUMER , DENO , RATE , QTY , MAC , VALUE , WORK_CENTER , YYYYWW , PLANT    )
   Select  COMPANY_CODE , PD , DEPARTMENT , LINES , D_TYPE , IN_SUB , ITEMS , NUMER , DENO , RATE , QTY , MAC , VALUE , WORK_CENTER , YYYYWW , PLANT
     from SMT_LOADING_SUM_T
    where COMPANY_CODE= inCompany AND D_TYPE = 'Planned';

   iTracePoint := '200';
   DELETE  from SMT_LOADING_SUM_T
    where COMPANY_CODE = inCompany AND D_TYPE = 'Planned';



   Commit;
EXCEPTION
   When OTHERS Then
    --有錯誤產生則寄mail
    cErrorText := SQLERRM();
    MAIL_FILE_BIDBDBADMIN(in_to_name => 'sam_chen@ms.usi.com.tw', subject => '[VRT] PL/SQL SMT_LOADING_SUM PLAN ERROR', message => '[SMT_LOADING_SMT PLAN], The tracepoint is  ' || iTracePoint || ' and ErrorText= ' || cErrorText) ;


END PLSQL_SMT_LOADING_SUM;
/

