create PROCEDURE         "VQA_PLSQL_SUM_AMT_MM" AUTHID DEFINER
IS
      /*--------------------------------------------------------------*
         CREATE DATE:  2008/02/29
         PLSQL      :  VQA_PLSQL_SUM_AMT_MM
         Author     :  Susan Lin
         Purpase    :  Amount Summary(By 每月執行一次)
                       TW/SZ/SH
      *---------------------------------------------------------------*

  */

  vYYYY                      varchar2(4);
  vMM                        varchar2(2);
  vYYYYQQ                    varchar2(6);
  vIR_AMT_TWD                PLD_KPI_IR_DETAIL.IR_AMT_TWD%TYPE;

  iTracePoint                varchar2(100);
  cErrorText                 varchar2(500);

BEGIN
  iTracePoint := '000';
  select * into vYYYY, vMM, vYYYYQQ from (
    select trim(to_char(add_months(SYSDATE,-1), 'YYYY')), trim(to_char(add_months(SYSDATE,-1), 'MM')),
           trim(trim(to_char(add_months(SYSDATE,-1), 'YYYY')) || 'Q' || trim(to_char(add_months(SYSDATE,-1), 'Q')))
      from dual
  );

  --刪除 VQA_SUM01_AMT_MATGP_M
  iTracePoint := '100';
  delete from VQA_SUM01_AMT_MATGP_M
   where YYYY = vYYYY
     and MM = vMM;
  commit;

  iTracePoint := '110';
  insert into VQA_SUM01_AMT_MATGP_M ( SITE, MANUF, MATGROUP, YYYY, MM, QUARTER, BUKRS, AMOUNT, DATE_TIME )
     select a.COMPANY_CODE as SITE, a.MFR_NAME as MANUF, a.MTL_GROUP as MATGROUP,
            vYYYY as YYYY, vMM as MM, vYYYYQQ as QUARTER, a.COMPANY_CODE as BUKRS, round(sum(a.IR_AMT_TWD),5) as AMOUNT,
            to_char(SYSDATE, 'yyyymmddhh24miss') as DATE_TIME
         from PLD_KPI_IR_DETAIL a, VRTN_COMPANY_SITE c
      where substr(a.IR_DATE,1,4) = vYYYY
        and substr(a.IR_DATE,5,2) = vMM
        and c.MFG_SITE = a.COMPANY_CODE
        and a.MTL_GROUP >= '001'
        and a.MTL_GROUP <= '059'
        and a.MFR_NAME IS NOT NULL
      group by a.COMPANY_CODE, a.MFR_NAME, a.MTL_GROUP;
  commit;

  iTracePoint := '120';  --MATGROUP, MANUF_NAME
  for REC1 in (
     select distinct MATGROUP, MANUF from VQA_SUM01_AMT_MATGP_M
      where YYYY = vYYYY and MM = vMM
  ) loop
     BEGIN
       select * into vIR_AMT_TWD from (
         select round(sum(AMOUNT),5) from VQA_SUM01_AMT_MATGP_M
          where YYYY = vYYYY
            and MM = vMM
            and MATGROUP = REC1.MATGROUP
            and MANUF = REC1.MANUF
       );
     EXCEPTION
       When OTHERS Then
         vIR_AMT_TWD := 0;
     END;
     Update VQA_SUM01_AMT_MATGP_M
        set GV_PER = round(AMOUNT / vIR_AMT_TWD, 5)
      where YYYY = vYYYY
        and MM = vMM
        and MATGROUP = REC1.MATGROUP
        and MANUF = REC1.MANUF;
     commit;
  end loop;

  iTracePoint := '130';  --SITE
  for REC1 in (
     select distinct SITE from VQA_SUM01_AMT_MATGP_M
      where YYYY = vYYYY and MM = vMM
  ) loop
     BEGIN
       select * into vIR_AMT_TWD from (
         select round(sum(AMOUNT),5) from VQA_SUM01_AMT_MATGP_M
          where YYYY = vYYYY
            and MM = vMM
            and SITE = REC1.SITE
       );
     EXCEPTION
       When OTHERS Then
         vIR_AMT_TWD := 0;
     END;
     Update VQA_SUM01_AMT_MATGP_M
        set SITE_PER = round(AMOUNT / vIR_AMT_TWD, 5)
      where YYYY = vYYYY
        and MM = vMM
        and SITE = REC1.SITE;
     commit;
  end loop;


  --刪除 VQA_SUM02_AMT_MF_M
  iTracePoint := '200';
  delete from VQA_SUM02_AMT_MF_M
   where YYYY = vYYYY
     and MM = vMM;
  commit;

  iTracePoint := '210';
  insert into VQA_SUM02_AMT_MF_M( SITE, MANUF, YYYY, MM, QUARTER, BUKRS, AMOUNT, DATE_TIME )
     select a.COMPANY_CODE as SITE, a.MFR_NAME as MANUF,
            vYYYY as YYYY, vMM as MM, vYYYYQQ as QUARTER, a.COMPANY_CODE as BUKRS, round(sum(a.IR_AMT_TWD),5) as AMOUNT,
            to_char(SYSDATE, 'yyyymmddhh24miss') as DATE_TIME
       from PLD_KPI_IR_DETAIL a, VRTN_COMPANY_SITE c
      where substr(a.IR_DATE,1,4) = vYYYY
        and substr(a.IR_DATE,5,2) = vMM
        and c.MFG_SITE = a.COMPANY_CODE
        and a.MTL_GROUP >= '001'
        and a.MTL_GROUP <= '059'
        and a.MFR_NAME IS NOT NULL
      group by a.COMPANY_CODE, a.MFR_NAME;
  commit;

  iTracePoint := '220';  --MANUF
  for REC1 in (
     select distinct MANUF from VQA_SUM02_AMT_MF_M
      where YYYY = vYYYY and MM = vMM
  ) loop
     BEGIN
       select * into vIR_AMT_TWD from (
         select round(sum(AMOUNT),5) from VQA_SUM02_AMT_MF_M
          where YYYY = vYYYY
            and MM = vMM
            and MANUF = REC1.MANUF
       );
     EXCEPTION
       When OTHERS Then
         vIR_AMT_TWD := 0;
     END;
     Update VQA_SUM02_AMT_MF_M
        set GV_PER = round(AMOUNT / vIR_AMT_TWD, 5)
      where YYYY = vYYYY
        and MM = vMM
        and MANUF = REC1.MANUF;
     commit;
  end loop;

  iTracePoint := '230';  --SITE
  for REC1 in (
     select distinct SITE from VQA_SUM02_AMT_MF_M
      where YYYY = vYYYY and MM = vMM
  ) loop
     BEGIN
       select * into vIR_AMT_TWD from (
         select round(sum(AMOUNT),5) from VQA_SUM02_AMT_MF_M
          where YYYY = vYYYY
            and MM = vMM
            and SITE = REC1.SITE
       );
     EXCEPTION
       When OTHERS Then
         vIR_AMT_TWD := 0;
     END;
     Update VQA_SUM02_AMT_MF_M
        set SITE_PER = round(AMOUNT / vIR_AMT_TWD, 5)
      where YYYY = vYYYY
        and MM = vMM
        and SITE = REC1.SITE;
     commit;
  end loop;



EXCEPTION
  When OTHERS Then
    --有錯誤產生則寄mail
    cErrorText := SQLERRM();
    MAIL_FILE_BIDBDBADMIN(in_to_name => 'shuchin_lin@usiglobal.com', subject => '[VQA] PL/SQL VQA_PLSQL_SUM_AMT_MM ERROR', message => '[VQA_PLSQL_SUM_AMT_MM], The tracepoint is  ' || iTracePoint || ' and ErrorText= ' || cErrorText) ;
END;
/

