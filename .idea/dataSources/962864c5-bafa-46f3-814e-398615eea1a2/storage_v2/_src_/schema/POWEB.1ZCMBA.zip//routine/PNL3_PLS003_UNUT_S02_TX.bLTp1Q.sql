create PROCEDURE       PNL3_PLS003_UNUT_S02_TX (
  inCOMPANY       in VARCHAR2,
  inPeriod        in VARCHAR2,
  inPROFIT_CENTER in VARCHAR2,
  inGLAccount     in VARCHAR ,
  inAMT           in Number,
  inRevenue       in Number,
  inRevenue_usd   in Number,
  inRevenue_twd   in Number,
  inCOGS          in Number,
  inCOGS_usd      in Number,
  inCOGS_twd      in Number,
  inDM            in Number,
  inDM_usd        in Number,
  inDM_twd        in Number,
  inDL            in Number,
  inDL_usd        in Number,
  inDL_twd        in Number, 
  inOH            in Number,
  inOH_usd        in Number,
  inOH_twd        in Number
   
  --2008/9/17 Create to Process get Amount in Local/USD/TWD
  --Trigger by PNL2_BAD_DEPT_UPLOAD.JSP
)
AUTHID DEFINER
is

  --2008/11/7 有發現  SUM(NET_REVENUE) <> 0 OR SUM(NET_COGS)  <> 0 條件成立但dm/dl/oh卻有值的戕況,因此不加入此條件
-- 在INSERT進資料庫時再排除金額=0的資料   
     a_Rate          number(20,10);
     a_TRate         number(20,10);
     a_ENDCUSTOMER   KPI_SAP001_COPA_TRX.END_CUSTOMER_ID%TYPE;
     a_NET_REVENUE   KPI_SAP001_COPA_TRX.NET_REVENUE%TYPE;
     a_REVENUE_LOCAL KPI_SAP001_COPA_TRX.NET_REVENUE%TYPE;
     a_REVENUE_TWD   KPI_SAP001_COPA_TRX.NET_REVENUE%TYPE;
     a_REVENUE_USD   KPI_SAP001_COPA_TRX.NET_REVENUE%TYPE;
     a_COGS_DM_LOCAL KPI_SAP001_COPA_TRX.NET_REVENUE%TYPE;
     a_COGS_DM_TWD   KPI_SAP001_COPA_TRX.NET_REVENUE%TYPE;
     a_COGS_DM_USD   KPI_SAP001_COPA_TRX.NET_REVENUE%TYPE;
     a_COGS_DL_LOCAL KPI_SAP001_COPA_TRX.NET_REVENUE%TYPE;
     a_COGS_DL_TWD   KPI_SAP001_COPA_TRX.NET_REVENUE%TYPE;
     a_COGS_DL_USD   KPI_SAP001_COPA_TRX.NET_REVENUE%TYPE;
     a_COGS_OH_LOCAL KPI_SAP001_COPA_TRX.NET_REVENUE%TYPE;
     a_COGS_OH_TWD   KPI_SAP001_COPA_TRX.NET_REVENUE%TYPE;
     a_COGS_OH_USD   KPI_SAP001_COPA_TRX.NET_REVENUE%TYPE;
     
 BEGIN
   


      a_TRate := 0;
      FOR REC1 in (SELECT END_CUSTOMER_ID,NVL(SUM(AMT_TWD),0) AMT_TWD FROM PNL3_TRX001_COPA 
                      WHERE PROFIT_CENTER = inPROFIT_CENTER
                        AND PERIOD = inPeriod
                        --AND SOURCE <> 'UPL001'
                        AND AREA1 = '1'
                        AND AREA2 = '1'
                        AND AREA3 = '0'
                        GROUP BY END_CUSTOMER_ID ORDER BY AMT_TWD DESC) Loop
          a_Rate := REC1.AMT_TWD / inAMT;
          IF a_Rate <> 0 THEN
               INSERT INTO PNL3_TRX003_UNUTILIZATION (
                  COMPANY_CODE         ,PERIOD       ,PROFIT_CENTER      ,
                  PART_NO              ,TOTAL_HRS    ,PN_HRS             ,         
                  NET_REVENUE          ,NET_REVENUE_TWD ,NET_REVENUE_USD ,
                  NET_COGS             ,NET_COGS_TWD    ,NET_COGS_USD    ,
                  COGS_MB              ,COGS_MB_TWD     ,COGS_MB_USD     ,
                  COGS_LB              ,COGS_LB_TWD     ,COGS_LB_USD     ,
                  COGS_OB              ,COGS_OB_TWD     ,COGS_OB_USD     ,
                  O_NET_REVENUE        ,O_NET_COGS      ,
                  RATE                 ,COST_ELEMENT    ,END_CUSTOMER_ID ,
                  SQL_METHOD           ,CUSTOMER_RATE   ,
                  CREATE_DATE     
               ) VALUES(
                  inCOMPANY            ,inPeriod     ,inPROFIT_CENTER    ,
                  NULL                 ,0            ,0                  ,
                  round(inRevenue * a_RATE , 5),
                  round(inRevenue_TWD * a_RATE , 5)  ,
                  round(inRevenue_USD * a_RATE , 5)  , 
                  round(inCOGS * a_RATE , 5)   ,
                  round(inCOGS_TWD * a_RATE , 5)     ,
                  round(inCOGS_USD * a_RATE , 5)     ,               
                  round(inDM * a_RATE , 5),
                  round(inDM_TWD * a_RATE , 5)  ,
                  round(inDM_USD * a_RATE , 5)  ,                
                  round(inDL * a_RATE , 5),
                  round(inDL_TWD * a_RATE , 5)  ,
                  round(inDL_USD * a_RATE , 5)  , 
                  round(inOH * a_RATE , 5),
                  round(inOH_TWD * a_RATE , 5)  ,
                  round(inOH_USD * a_RATE , 5)  , 
                  inRevenue_TWD,
                  inCOGS_TWD,
                  0,
                  inGLAccount, 
                  REC1.END_CUSTOMER_ID          , 
                  'WH=0/T_AMT<>0',
                  a_Rate         ,
                  SYSDATE
               );
               commit;
          END IF;
        
  
      END LOOP;

   
   
   
    
END PNL3_PLS003_UNUT_S02_TX;
/

