create PROCEDURE         "VQA_PLSQL_SUM5_LOC_MM" AUTHID DEFINER
IS
  /*
         CREATE DATE:  2008/03/02
         PLSQL      :  VQA_PLSQL_SUM5_LOC_MM
         Author     :  Susan Lin
         Purpase    :  Summary - Quality(By 每月執行一次)
                       TW/SZ/SH QA-70 Default,QB-0,QC-100,QD-70
  */

  vYYYY                      varchar2(4);
  vMM                        varchar2(2);

  Q0_VALUE                   VRTN_MAP060_LEVEL_DESC.VALUE%TYPE;
  QA_VALUE                   VRTN_MAP060_LEVEL_DESC.VALUE%TYPE;
  QB_VALUE                   VRTN_MAP060_LEVEL_DESC.VALUE%TYPE;
  QC_VALUE                   VRTN_MAP060_LEVEL_DESC.VALUE%TYPE;
  QD_VALUE                   VRTN_MAP060_LEVEL_DESC.VALUE%TYPE;

  iTracePoint                varchar2(100);
  cErrorText                 varchar2(500);

BEGIN
  iTracePoint := '000';
  select * into vYYYY, vMM from (
    select trim(to_char(add_months(SYSDATE,-1), 'YYYY')), trim(to_char(add_months(SYSDATE,-1), 'MM'))
      from dual
  );




  iTracePoint := '100';  --刪除 VRTN_SUM11_MM_MATGP
  delete from VQA_SUM11_MM_MATGP
   where YYYY = vYYYY
     and MM = vMM;
  commit;

  iTracePoint := '110';
  insert into VQA_SUM11_MM_MATGP ( SITE, MANUF, MATGROUP, YYYY, MM, QUARTER, BUKRS, AMOUNT, DATE_TIME,
                                    QB_GRADE, QC_GRADE, QD_GRADE, QA_GRADE )
     select SITE, MANUF, MATGROUP, YYYY, MM, QUARTER, BUKRS, AMOUNT, to_char(SYSDATE, 'yyyymmddhh24miss') as DATE_TIME,
            0, 100, 70,70
       from VQA_SUM01_AMT_MATGP_M a
      where YYYY = vYYYY
        and MM = vMM;
  commit;

  iTracePoint := '120';  --QA, QB, QC, QD
  for REC1 in (
     select distinct SITE, MANUF, MATGROUP, TYPE, YYYY, MM, GRADE_L4
       from VQA_MAP000_SUMMARY_GRAD
      where YYYY = vYYYY and MM = vMM and L4 is not null
  ) loop

     if REC1.TYPE = 'QA' then
       Update VQA_SUM11_MM_MATGP
          set QA_GRADE = REC1.GRADE_L4
        where YYYY = vYYYY        and MM = vMM
          and SITE = REC1.SITE    and MANUF = REC1.MANUF
          and MATGROUP = REC1.MATGROUP;
     elsif REC1.TYPE = 'QB' then
       Update VQA_SUM11_MM_MATGP
          set QB_GRADE = (QB_GRADE - abs(REC1.GRADE_L4))
        where YYYY = vYYYY        and MM = vMM
          and SITE = REC1.SITE    and MANUF = REC1.MANUF;
     elsif REC1.TYPE = 'QC' then
       Update VQA_SUM11_MM_MATGP
          set QC_GRADE = REC1.GRADE_L4
        where YYYY = vYYYY        and MM = vMM
          and SITE = REC1.SITE    and MANUF = REC1.MANUF;
     elsif REC1.TYPE = 'QD' then
       Update VQA_SUM11_MM_MATGP
          set QD_GRADE = REC1.GRADE_L4
        where YYYY = vYYYY        and MM = vMM
          and SITE = REC1.SITE    and MANUF = REC1.MANUF;
     end if;
     commit;
  end loop;


  iTracePoint := '200';  --Get VRTN_MAP060_LEVEL_DESC value
  Q0_VALUE := 0;
  QA_VALUE := 0;
  QB_VALUE := 0;
  QC_VALUE := 0;
  QD_VALUE := 0;

  for REC1 in (
     select distinct LEVEL_S, VALUE from VRTN_MAP060_LEVEL_DESC where VALUE is not null
  ) loop
     if REC1.LEVEL_S = 'Q0' then
       Q0_VALUE := REC1.VALUE;
     elsif REC1.LEVEL_S = 'QA' then
       QA_VALUE := REC1.VALUE;
     elsif REC1.LEVEL_S = 'QB' then
       QB_VALUE := REC1.VALUE;
     elsif REC1.LEVEL_S = 'QC' then
       QC_VALUE := REC1.VALUE;
     elsif REC1.LEVEL_S = 'QD' then
       QD_VALUE := REC1.VALUE;
     end if;
  end loop;

  iTracePoint := '211';  --Update VRTN_SUM11_MM_MATGP (Quality)
  Update VQA_SUM11_MM_MATGP
     set SUBTOT_Q = round( (nvl(QA_GRADE,0) * QA_VALUE) + (nvl(QB_GRADE,0) * QB_VALUE) + (nvl(QC_GRADE,0) * QC_VALUE) + (nvl(QD_GRADE,0) * QD_VALUE), 5)
   where YYYY = vYYYY    and MM = vMM
     and ( QA_GRADE is not null or QB_GRADE is not null or QC_GRADE is not null or QD_GRADE is not null );
  commit;





  iTracePoint := '300';  --刪除 VQA_SUM12_MM_MF
  delete from VQA_SUM12_MM_MF
   where YYYY = vYYYY
     and MM = vMM;
  commit;

  iTracePoint := '310';
  insert into VQA_SUM12_MM_MF ( SITE, MANUF , YYYY, MM, QUARTER, BUKRS, AMOUNT, QA_GRADE, QB_GRADE, QC_GRADE,
                                 QD_GRADE, SUBTOT_Q, DATE_TIME )
    select SITE, MANUF, YYYY, MM, QUARTER, BUKRS, sum(AMOUNT),
           round(sum(QA_GRADE * AMOUNT) / sum(AMOUNT),5),
           round(sum(QB_GRADE * AMOUNT) / sum(AMOUNT),5),
           round(sum(QC_GRADE * AMOUNT) / sum(AMOUNT),5),
           round(sum(QD_GRADE * AMOUNT) / sum(AMOUNT),5),
           round(sum(SUBTOT_Q * AMOUNT) / sum(AMOUNT),5),
           DATE_TIME
      from VQA_SUM11_MM_MATGP
     where YYYY = vYYYY    and MM = vMM
     group by SITE, MANUF, YYYY, MM, QUARTER, BUKRS, DATE_TIME;
  commit;

  iTracePoint := '400';  --刪除 VQA_SUM13_MM_COMBINE
  delete from VQA_SUM13_MM_COMBINE
   where YYYY = vYYYY
     and MM = vMM;
  commit;

  iTracePoint := '410';
  insert into VQA_SUM13_MM_COMBINE ( SITE, MANUF, MATGROUP, YYYY, MM, QUARTER, BUKRS, AMOUNT,
                                      QA_GRADE, QB_GRADE, QC_GRADE, QD_GRADE, SUBTOT_Q, DATE_TIME )
    select SITE, MANUF, MATGROUP, YYYY, MM, QUARTER, BUKRS, AMOUNT,
            QA_GRADE, QB_GRADE, QC_GRADE, QD_GRADE, SUBTOT_Q, DATE_TIME
      from VQA_SUM11_MM_MATGP
     where YYYY = vYYYY and MM = vMM
    union all
    select SITE, MANUF, '000' as  MATGROUP, YYYY, MM, QUARTER, BUKRS, AMOUNT,
            QA_GRADE, QB_GRADE, QC_GRADE, QD_GRADE, SUBTOT_Q, DATE_TIME
      from VQA_SUM12_MM_MF
     where YYYY = vYYYY and MM = vMM;
  commit;

EXCEPTION
  When OTHERS Then
    --有錯誤產生則寄mail
    cErrorText := SQLERRM();
    MAIL_FILE_BIDBDBADMIN(in_to_name => 'shuchin_lin@usiglobal.com', subject => '[VQA] PL/SQL VQA_PLSQL_SUM5_LOC_MM ERROR', message => '[VQA_PLSQL_SUM5_LOC_MM], The tracepoint is  ' || iTracePoint || ' and ErrorText= ' || cErrorText) ;
END;
/

