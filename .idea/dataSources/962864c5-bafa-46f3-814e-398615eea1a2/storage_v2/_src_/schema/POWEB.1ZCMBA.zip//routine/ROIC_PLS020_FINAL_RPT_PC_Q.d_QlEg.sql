create PROCEDURE       "ROIC_PLS020_FINAL_RPT_PC_Q" (
  in_YYYYMM1       IN   VARCHAR2,
  in_GRP_CODE      IN   VARCHAR2
)
AUTHID DEFINER
/* 
 ****************************************************************************************
  PROG-ID      :  ROIC_PLS020_FINAL_RPT_PC_Q
  PROG-ACTION  :   
  Author       : Asan Chang
  Date         : 2020/06/17
  OA No.       : SAI118761
  input data example -> 2020Q1, INC/UG
 ************************************************************************************
 * SAI118761 2020/08/21 Asan Changmodify (0-13)00090 	R&D-D&A-01
 ************************************************************************************
 */
is
   iReccnt              integer;
   In_YYYY              DIMENSION_DATE.YYYY%TYPE;
   In_Q                DIMENSION_DATE.MM%TYPE; 
   In_PERIOD            DIMENSION_DATE.YYYYMM%TYPE;
   From_PERIOD          DIMENSION_DATE.YYYYMM%TYPE; 
   DATE_TRANS           varchar2(10);
   sPROC_NAME           ROIC_PST000_LOG.PROC_NAME%TYPE;
   sRUN_SEQ             ROIC_PST000_LOG.RUN_SEQ%TYPE;
   sRUN_DESC            ROIC_PST000_LOG.RUN_DESC%TYPE;
   sPARAMETER_DESC      ROIC_PST000_LOG.PARAMETER_DESC%TYPE;   
   L_CNT                NUMBER(6);
   L_waers_loc2         varchar2(30);
   iTracePoint          integer ; 
   In_Q2               integer ;
   inCompany            ROA_PST004_FIXED_ASSETS.COMPANY_CODE%TYPE;
   STR01                varchar2(30);
   STR02                varchar2(30);
   STR03                varchar2(30);
   STR04                varchar2(30);
   STR06                varchar2(30); 
   STR07                varchar2(30); 
   REPLACE_PC           varchar2(10); 
   NOT_FOUND_STR        varchar2(10); 
   --GRP_CODE_STR         varchar2(30);   
   TMP_OPTION1          NUMBER(15,5); 
   TMP_OPTION2          NUMBER(15,5);   
   TMP_AMT1             NUMBER(15,5);
   TMP_AMT2             NUMBER(15,5); 
   TMP_AMT3             NUMBER(15,5);
   TMP_AMT4             NUMBER(15,5);   
BEGIN
--
  In_YYYY := SUBSTR( in_YYYYMM1, 1, 4);
  In_Q := SUBSTR( in_YYYYMM1, 5, 2); 
  --In_Q2 := In_Q;
  --DATE_TRANS := In_YYYY ||'-'|| In_MM || '-01';

  sPROC_NAME := 'ROIC_PLS020_FINAL_RPT_PC_Q';
  sRUN_SEQ   := '000010';
  sRUN_DESC  := 'Start';
  sPARAMETER_DESC := CONCAT(CONCAT(CONCAT('s_PERIOD=',in_YYYYMM1),';t_PERIOD='),in_YYYYMM1);
  REPLACE_PC := '0000000099';
  NOT_FOUND_STR := 'NO FOUND';

  if in_GRP_CODE = 'UG' Then
      TMP_OPTION1  := 1;  
      TMP_OPTION2  := 2;
  else
      TMP_OPTION1  := 2;  
      TMP_OPTION2  := 1;
  end if; 
  
  
  --Insert Log
  INSERT INTO ROIC_PST000_LOG
      ( PROC_NAME, RUN_SEQ, RUN_DESC, PARAMETER_DESC )
    VALUES
      ( sPROC_NAME, sRUN_SEQ, sRUN_DESC, sPARAMETER_DESC );
  Commit;

  --Delete old data
  delete ROIC_PST020_FINAL_RPT_PC_Q WHERE PERIOD = in_YYYYMM1 and GRP_CODE = in_GRP_CODE;
  COMMIT ;   
  
  --get from period
  /*for REC_PERIOD IN (
    (select TO_CHAR(add_months(TO_DATE(DATE_TRANS, 'YYYY-MM-DD'),-11),'YYYYMM') FROM_PERIOD from dual )
  )
  LOOP
    From_PERIOD := REC_PERIOD.FROM_PERIOD;                 
  END LOOP;
  */
  for REC_PERIOD IN (
    select In_YYYY || min(MM) quarter from DIMENSION_DATE_YYYYMM where YYYY = In_YYYY and quarter = In_Q
  )
  LOOP
    From_PERIOD := REC_PERIOD.quarter;                 
  END LOOP;
  for REC_PERIOD IN (
    select In_YYYY || max(MM) quarter from DIMENSION_DATE_YYYYMM where YYYY = In_YYYY and quarter = In_Q
  )
  LOOP
    In_PERIOD := REC_PERIOD.quarter;                 
  END LOOP;  

  
  /* ****************************************************************************************
      (0-1)00010	AR
  ************************************************************************************ */
      STR01 :=  '00010';
      for REC1 IN (
	        select PC ,S_DESC,GRP_CODE,
	        sum(AMOUNT_TWD)/3 AMOUNT_TWD, sum(AMOUNT_USD)/3 AMOUNT_USD, sum(AMOUNT_CNY)/3 AMOUNT_CNY
	        from ROIC_PST019_FINAL_RPT_PC
	        where

			( period <= In_PERIOD and period >= From_PERIOD )
			and S_DESC = STR01
			and GRP_CODE = in_GRP_CODE 
	        group by PC ,S_DESC,GRP_CODE
	        order by PC ,S_DESC,GRP_CODE	
      )
      LOOP
        INSERT INTO ROIC_PST020_FINAL_RPT_PC_Q
         ( PERIOD, PC, GRP_CODE,S_DESC, AMOUNT_TWD, AMOUNT_USD, AMOUNT_CNY) 
        VALUES
         ( in_YYYYMM1 , REC1.PC,in_GRP_CODE,STR01, REC1.AMOUNT_TWD, REC1.AMOUNT_USD, REC1.AMOUNT_CNY);    
	  END LOOP;  

  /* ****************************************************************************************
      (0-2)00020	INV
  ************************************************************************************ */
      STR01 :=  '00020';
      for REC1 IN (
	    --SQL
	        select PC ,S_DESC,GRP_CODE,
	        sum(AMOUNT_TWD)/3 AMOUNT_TWD, sum(AMOUNT_USD)/3 AMOUNT_USD, sum(AMOUNT_CNY)/3 AMOUNT_CNY
	        from ROIC_PST019_FINAL_RPT_PC
	        where

			( period <= In_PERIOD and period >= From_PERIOD )
			and S_DESC = STR01
			and GRP_CODE = in_GRP_CODE 			
	        group by PC ,S_DESC,GRP_CODE
	        order by PC ,S_DESC,GRP_CODE	
      )
      LOOP
        INSERT INTO ROIC_PST020_FINAL_RPT_PC_Q
         ( PERIOD, PC, GRP_CODE,S_DESC, AMOUNT_TWD, AMOUNT_USD, AMOUNT_CNY) 
        VALUES
         ( in_YYYYMM1 , REC1.PC,in_GRP_CODE,STR01, REC1.AMOUNT_TWD, REC1.AMOUNT_USD, REC1.AMOUNT_CNY);    
	  END LOOP;

  /* ****************************************************************************************
      (0-3)00030	AP
  ************************************************************************************ */
      STR01 :=  '00030';
      for REC1 IN (
	    --SQL
	        select PC ,S_DESC,GRP_CODE,
	        sum(AMOUNT_TWD)/3 AMOUNT_TWD, sum(AMOUNT_USD)/3 AMOUNT_USD, sum(AMOUNT_CNY)/3 AMOUNT_CNY
	        from ROIC_PST019_FINAL_RPT_PC
	        where

			( period <= In_PERIOD and period >= From_PERIOD )
			and S_DESC = STR01
			and GRP_CODE = in_GRP_CODE 			
	        group by PC ,S_DESC,GRP_CODE
	        order by PC ,S_DESC,GRP_CODE	
		
      )
      LOOP
        INSERT INTO ROIC_PST020_FINAL_RPT_PC_Q
         ( PERIOD, PC, GRP_CODE,S_DESC, AMOUNT_TWD, AMOUNT_USD, AMOUNT_CNY) 
        VALUES
         ( in_YYYYMM1, REC1.PC,in_GRP_CODE,STR01, REC1.AMOUNT_TWD, REC1.AMOUNT_USD, REC1.AMOUNT_CNY);    
	  END LOOP;  
	   
  /* ****************************************************************************************
      (0-4)00040 	FA-Land
  ************************************************************************************ */
      STR01 :=  '00040';
      for REC1 IN (
	    --SQL
	        select PC ,S_DESC,GRP_CODE,
	        sum(AMOUNT_TWD)/3 AMOUNT_TWD, sum(AMOUNT_USD)/3 AMOUNT_USD, sum(AMOUNT_CNY)/3 AMOUNT_CNY
	        from ROIC_PST019_FINAL_RPT_PC
	        where

			( period <= In_PERIOD and period >= From_PERIOD )
			and S_DESC = STR01
			and GRP_CODE = in_GRP_CODE 			
	        group by PC ,S_DESC,GRP_CODE
	        order by PC ,S_DESC,GRP_CODE		
		
      )
      LOOP
        INSERT INTO ROIC_PST020_FINAL_RPT_PC_Q
         ( PERIOD, PC, GRP_CODE,S_DESC, AMOUNT_TWD, AMOUNT_USD, AMOUNT_CNY) 
        VALUES
         ( in_YYYYMM1 , REC1.PC,in_GRP_CODE,STR01, REC1.AMOUNT_TWD, REC1.AMOUNT_USD, REC1.AMOUNT_CNY);    
	  END LOOP;  

  /* ****************************************************************************************
      (0-5)00041 	FA-Building
  ************************************************************************************ */
      STR01 :=  '00041';
      for REC1 IN (
	    --SQL
	        select PC ,S_DESC,GRP_CODE,
	        sum(AMOUNT_TWD)/3 AMOUNT_TWD, sum(AMOUNT_USD)/3 AMOUNT_USD, sum(AMOUNT_CNY)/3 AMOUNT_CNY
	        from ROIC_PST019_FINAL_RPT_PC
	        where

			( period <= In_PERIOD and period >= From_PERIOD )
			and S_DESC = STR01
			and GRP_CODE = in_GRP_CODE 			
	        group by PC ,S_DESC,GRP_CODE
	        order by PC ,S_DESC,GRP_CODE	
      )
      LOOP
        INSERT INTO ROIC_PST020_FINAL_RPT_PC_Q
         ( PERIOD, PC, GRP_CODE,S_DESC, AMOUNT_TWD, AMOUNT_USD, AMOUNT_CNY) 
        VALUES
         ( in_YYYYMM1 , REC1.PC,in_GRP_CODE,STR01, REC1.AMOUNT_TWD, REC1.AMOUNT_USD, REC1.AMOUNT_CNY);    
	  END LOOP; 

  /* ****************************************************************************************
      (0-6)00042 	FA-Equipment
  ************************************************************************************ */
      STR01 :=  '00042';
      for REC1 IN (
	    --SQL
	        select PC ,S_DESC,GRP_CODE,
	        sum(AMOUNT_TWD)/3 AMOUNT_TWD, sum(AMOUNT_USD)/3 AMOUNT_USD, sum(AMOUNT_CNY)/3 AMOUNT_CNY
	        from ROIC_PST019_FINAL_RPT_PC
	        where

			( period <= In_PERIOD and period >= From_PERIOD )
			and S_DESC = STR01
			and GRP_CODE = in_GRP_CODE 			
	        group by PC ,S_DESC,GRP_CODE
	        order by PC ,S_DESC,GRP_CODE			
      )
      LOOP
        INSERT INTO ROIC_PST020_FINAL_RPT_PC_Q
         ( PERIOD, PC, GRP_CODE,S_DESC, AMOUNT_TWD, AMOUNT_USD, AMOUNT_CNY) 
        VALUES
         ( in_YYYYMM1 , REC1.PC,in_GRP_CODE,STR01, REC1.AMOUNT_TWD, REC1.AMOUNT_USD, REC1.AMOUNT_CNY);    
	  END LOOP; 

  /* ****************************************************************************************
      (0-7)00043 	FA-Others
  ************************************************************************************ */
      STR01 :=  '00043';
      for REC1 IN (
	    --SQL
	        select PC ,S_DESC,GRP_CODE,
	        sum(AMOUNT_TWD)/3 AMOUNT_TWD, sum(AMOUNT_USD)/3 AMOUNT_USD, sum(AMOUNT_CNY)/3 AMOUNT_CNY
	        from ROIC_PST019_FINAL_RPT_PC
	        where

			( period <= In_PERIOD and period >= From_PERIOD )
			and S_DESC = STR01
			and GRP_CODE = in_GRP_CODE 			
	        group by PC ,S_DESC,GRP_CODE
	        order by PC ,S_DESC,GRP_CODE	
      )
      LOOP
        INSERT INTO ROIC_PST020_FINAL_RPT_PC_Q
         ( PERIOD, PC, GRP_CODE,S_DESC, AMOUNT_TWD, AMOUNT_USD, AMOUNT_CNY) 
        VALUES
         ( in_YYYYMM1 , REC1.PC,in_GRP_CODE,STR01, REC1.AMOUNT_TWD, REC1.AMOUNT_USD, REC1.AMOUNT_CNY);    
	   END LOOP;   

  /* ****************************************************************************************
      (0-8)00044	FA-Land Occupy	
  ************************************************************************************ */
      STR01 :=  '00044';
      for REC1 IN (
	        select PC ,S_DESC,GRP_CODE,
	        sum(AMOUNT_TWD)/3 AMOUNT_TWD, sum(AMOUNT_USD)/3 AMOUNT_USD, sum(AMOUNT_CNY)/3 AMOUNT_CNY
	        from ROIC_PST019_FINAL_RPT_PC
	        where

			( period <= In_PERIOD and period >= From_PERIOD )
			and S_DESC = STR01
			and GRP_CODE = in_GRP_CODE 			
	        group by PC ,S_DESC,GRP_CODE
	        order by PC ,S_DESC,GRP_CODE
		
      )
      LOOP
        INSERT INTO ROIC_PST020_FINAL_RPT_PC_Q
         ( PERIOD, PC, GRP_CODE,S_DESC, AMOUNT_TWD, AMOUNT_USD, AMOUNT_CNY) 
        VALUES
         ( in_YYYYMM1 , REC1.PC,in_GRP_CODE,STR01, REC1.AMOUNT_TWD, REC1.AMOUNT_USD, REC1.AMOUNT_CNY);    
	  END LOOP;  

  /* ****************************************************************************************
      (0-9)00050	REV
  ************************************************************************************ */
      STR01 :=  '00050';
      for REC1 IN (
	    --SQL
	        select PC ,S_DESC,GRP_CODE,
	        sum(AMOUNT_TWD) AMOUNT_TWD, sum(AMOUNT_USD) AMOUNT_USD, sum(AMOUNT_CNY) AMOUNT_CNY
	        from ROIC_PST019_FINAL_RPT_PC
	        where

			( period <= In_PERIOD and period >= From_PERIOD )
			and S_DESC = STR01
			and GRP_CODE = in_GRP_CODE 			
	        group by PC ,S_DESC,GRP_CODE
	        order by PC ,S_DESC,GRP_CODE	
		
      )
      LOOP
        INSERT INTO ROIC_PST020_FINAL_RPT_PC_Q
         ( PERIOD, PC, GRP_CODE,S_DESC, AMOUNT_TWD, AMOUNT_USD, AMOUNT_CNY) 
        VALUES
         ( in_YYYYMM1 , REC1.PC,in_GRP_CODE,STR01, REC1.AMOUNT_TWD, REC1.AMOUNT_USD, REC1.AMOUNT_CNY);    
	  END LOOP; 

  /* ****************************************************************************************
      (0-10)00060	COGS
  ************************************************************************************ */
      -- *(-1)
	  STR01 :=  '00060';
      for REC1 IN (
	    --SQL
	        select PC ,S_DESC,GRP_CODE,
	        sum(AMOUNT_TWD)* -1 AMOUNT_TWD, sum(AMOUNT_USD)* -1 AMOUNT_USD, sum(AMOUNT_CNY)* -1 AMOUNT_CNY
	        from ROIC_PST019_FINAL_RPT_PC
	        where

			( period <= In_PERIOD and period >= From_PERIOD )
			and S_DESC = STR01
			and GRP_CODE = in_GRP_CODE 			
	        group by PC ,S_DESC,GRP_CODE
	        order by PC ,S_DESC,GRP_CODE				
      )
      LOOP
        INSERT INTO ROIC_PST020_FINAL_RPT_PC_Q
         ( PERIOD, PC,GRP_CODE, S_DESC, AMOUNT_TWD, AMOUNT_USD, AMOUNT_CNY) 
        VALUES
         ( in_YYYYMM1, REC1.PC,in_GRP_CODE,STR01, (REC1.AMOUNT_TWD * -1), (REC1.AMOUNT_USD* -1), (REC1.AMOUNT_CNY* -1)); 
	  END LOOP;

  /* ****************************************************************************************
      (0-11)00070 	D&A
  ************************************************************************************ */
      -- *(-1)
      STR01 :=  '00070';
	  STR02 :=  'D'|| chr(38) ||'A';
      for REC1 IN (
	    --SQL
	        select PC ,S_DESC,GRP_CODE,
	        sum(AMOUNT_TWD)* -1 AMOUNT_TWD, sum(AMOUNT_USD)* -1 AMOUNT_USD, sum(AMOUNT_CNY)* -1 AMOUNT_CNY
	        from ROIC_PST019_FINAL_RPT_PC
	        where

			( period <= In_PERIOD and period >= From_PERIOD )
			and S_DESC = STR01
			and GRP_CODE = in_GRP_CODE 			
	        group by PC ,S_DESC,GRP_CODE
	        order by PC ,S_DESC,GRP_CODE		
      )
      LOOP
        INSERT INTO ROIC_PST020_FINAL_RPT_PC_Q
         ( PERIOD, PC,GRP_CODE, S_DESC, AMOUNT_TWD, AMOUNT_USD, AMOUNT_CNY) 
        VALUES
         ( in_YYYYMM1 , REC1.PC,in_GRP_CODE,STR01, (REC1.AMOUNT_TWD * -1), (REC1.AMOUNT_USD* -1), (REC1.AMOUNT_CNY* -1)); 
	  END LOOP;

  /* ****************************************************************************************
      (0-12)00080 	OH-D&A-01
  ************************************************************************************ */
      -- *(-1)
      STR01 :=  '00080';
	  STR02 :=  'OH-D'|| chr(38) ||'A-01';
      for REC1 IN (
	    --SQL
	        select PC ,S_DESC,GRP_CODE,
	        sum(AMOUNT_TWD)* -1 AMOUNT_TWD, sum(AMOUNT_USD)* -1 AMOUNT_USD, sum(AMOUNT_CNY)* -1 AMOUNT_CNY
	        from ROIC_PST019_FINAL_RPT_PC
	        where

			( period <= In_PERIOD and period >= From_PERIOD )
			and S_DESC = STR01
			and GRP_CODE = in_GRP_CODE 			
	        group by PC ,S_DESC,GRP_CODE
	        order by PC ,S_DESC,GRP_CODE	
      )
      LOOP
        INSERT INTO ROIC_PST020_FINAL_RPT_PC_Q
         ( PERIOD, PC,GRP_CODE, S_DESC, AMOUNT_TWD, AMOUNT_USD, AMOUNT_CNY) 
        VALUES
         ( in_YYYYMM1 , REC1.PC,in_GRP_CODE,STR01, (REC1.AMOUNT_TWD * -1), (REC1.AMOUNT_USD* -1), (REC1.AMOUNT_CNY* -1)); 
      END LOOP;
  /* ****************************************************************************************
      (0-13)00090 	R&D-D&A-01
  ************************************************************************************ */
      -- *(-1)
      STR01 :=  '00090';
	  STR02 :=  'R'|| chr(38) ||'D-D'|| chr(38) || 'A-01';
      for REC1 IN (
	    --SQL
	    
	        select PC ,S_DESC,GRP_CODE,
	        sum(AMOUNT_TWD)* -1 AMOUNT_TWD, sum(AMOUNT_USD)* -1 AMOUNT_USD, sum(AMOUNT_CNY)* -1 AMOUNT_CNY
	        from ROIC_PST019_FINAL_RPT_PC
	        where

			( period <= In_PERIOD and period >= From_PERIOD )
			and S_DESC = STR01
			and GRP_CODE = in_GRP_CODE 			
	        group by PC ,S_DESC,GRP_CODE
	        order by PC ,S_DESC,GRP_CODE		
      )
      LOOP
        INSERT INTO ROIC_PST020_FINAL_RPT_PC_Q
         ( PERIOD, PC,GRP_CODE, S_DESC, AMOUNT_TWD, AMOUNT_USD, AMOUNT_CNY) 
        VALUES
         ( in_YYYYMM1, REC1.PC,in_GRP_CODE,STR01, (REC1.AMOUNT_TWD * -1), (REC1.AMOUNT_USD* -1), (REC1.AMOUNT_CNY* -1)); 
	  END LOOP;

  /* ****************************************************************************************
      (0-14)00100 	SAL-D&A-01
  ************************************************************************************ */
      -- *(-1)
      STR01 :=  '00100';
	  STR02 :=  'SAL-D'|| chr(38) ||'A-01';
      for REC1 IN (
	    --SQL
	        select PC ,S_DESC,GRP_CODE,
	        sum(AMOUNT_TWD)* -1 AMOUNT_TWD, sum(AMOUNT_USD)* -1 AMOUNT_USD, sum(AMOUNT_CNY)* -1 AMOUNT_CNY
	        from ROIC_PST019_FINAL_RPT_PC
	        where

			( period <= In_PERIOD and period >= From_PERIOD )
			and S_DESC = STR01
			and GRP_CODE = in_GRP_CODE 			
	        group by PC ,S_DESC,GRP_CODE
	        order by PC ,S_DESC,GRP_CODE	
      )
      LOOP
        INSERT INTO ROIC_PST020_FINAL_RPT_PC_Q
         ( PERIOD, PC,GRP_CODE, S_DESC, AMOUNT_TWD, AMOUNT_USD, AMOUNT_CNY) 
        VALUES
         ( in_YYYYMM1 , REC1.PC,in_GRP_CODE,STR01, (REC1.AMOUNT_TWD * -1), (REC1.AMOUNT_USD* -1), (REC1.AMOUNT_CNY* -1)); 
	  END LOOP;

  /* ****************************************************************************************
      (0-15)00110 	ADM-D&A-01
  ************************************************************************************ */
      -- *(-1)
      STR01 :=  '00110';
	  STR02 :=  'ADM-D'|| chr(38) ||'A-01';
      for REC1 IN (
	    --SQL
	        select PC ,S_DESC,GRP_CODE,
	        sum(AMOUNT_TWD)* -1 AMOUNT_TWD, sum(AMOUNT_USD)* -1 AMOUNT_USD, sum(AMOUNT_CNY)* -1 AMOUNT_CNY
	        from ROIC_PST019_FINAL_RPT_PC
	        where

			( period <= In_PERIOD and period >= From_PERIOD )
			and S_DESC = STR01
			and GRP_CODE = in_GRP_CODE 			
	        group by PC ,S_DESC,GRP_CODE
	        order by PC ,S_DESC,GRP_CODE		
      )
      LOOP
        INSERT INTO ROIC_PST020_FINAL_RPT_PC_Q
         ( PERIOD, PC,GRP_CODE, S_DESC, AMOUNT_TWD, AMOUNT_USD, AMOUNT_CNY) 
        VALUES
         ( in_YYYYMM1, REC1.PC,in_GRP_CODE,STR01, (REC1.AMOUNT_TWD * -1), (REC1.AMOUNT_USD* -1), (REC1.AMOUNT_CNY* -1)); 
	  END LOOP;	

  /* ****************************************************************************************
      (0-16)00120 	SG&A
  ************************************************************************************ */
      -- 
      STR01 :=  '00120';
      for REC1 IN (
	    --SQL
	        select PC ,S_DESC,GRP_CODE,
	        sum(AMOUNT_TWD) AMOUNT_TWD, sum(AMOUNT_USD) AMOUNT_USD, sum(AMOUNT_CNY) AMOUNT_CNY
	        from ROIC_PST019_FINAL_RPT_PC
	        where

			( period <= In_PERIOD and period >= From_PERIOD )
			and S_DESC = STR01
			and GRP_CODE = in_GRP_CODE 			
	        group by PC ,S_DESC,GRP_CODE
	        order by PC ,S_DESC,GRP_CODE	
      )
      LOOP
        INSERT INTO ROIC_PST020_FINAL_RPT_PC_Q
         ( PERIOD, PC, GRP_CODE,S_DESC, AMOUNT_TWD, AMOUNT_USD, AMOUNT_CNY) 
        VALUES
         ( in_YYYYMM1, REC1.PC,in_GRP_CODE,STR01, REC1.AMOUNT_TWD, REC1.AMOUNT_USD, REC1.AMOUNT_CNY); 	  
	  END LOOP;		   
  
  
  /*****************************************************************************************
      (1)OPM
  ************************************************************************************ */
  --OPM=REV+COGS+SG&A
       
      STR01 :=  '00220';                 --OPM
	  STR02 :=  '00050';                 --REV
	  STR03 :=  '00060';                 --COGS
	  STR04 :=  '00120';                 --SG&A

	  
      for REC1 IN (
	    --SQL
        select  AA1.PC ,
        AA1.amount_twd+AA2.amount_twd+AA3.amount_twd amount_twd,
        AA1.amount_usd+AA2.amount_usd+AA3.amount_usd amount_usd,
        AA1.amount_cny+AA2.amount_cny+AA3.amount_cny amount_cny        
        
        from
        (
          SELECT a.PC,
            SUM (a.amount_twd)  amount_twd,
            SUM (a.amount_usd)  amount_usd,
            SUM (a.amount_cny)  amount_cny
          FROM ROIC_PST020_FINAL_RPT_PC_Q a
          WHERE a.S_DESC = STR02 and a.period = in_YYYYMM1
		  and GRP_CODE = in_GRP_CODE
          GROUP BY PC    

		  
        ) AA1,

        (
		
          SELECT a.PC,
            SUM (a.amount_twd)  amount_twd,
            SUM (a.amount_usd)  amount_usd,
            SUM (a.amount_cny)  amount_cny
          FROM ROIC_PST020_FINAL_RPT_PC_Q a
          WHERE a.S_DESC = STR03 and a.period = in_YYYYMM1
		  and GRP_CODE = in_GRP_CODE
          GROUP BY PC

		  
        ) AA2,

        (		
          SELECT a.PC,
            SUM (a.amount_twd)  amount_twd,
            SUM (a.amount_usd)  amount_usd,
            SUM (a.amount_cny)  amount_cny
          FROM ROIC_PST020_FINAL_RPT_PC_Q a
          WHERE a.S_DESC = STR04 and a.period = in_YYYYMM1
          and GRP_CODE = in_GRP_CODE
          GROUP BY PC
		  
		
        ) AA3   
        
        where  ( AA1.PC = AA2.PC and AA2.PC = AA3.PC  )         
      )
      LOOP
        INSERT INTO ROIC_PST020_FINAL_RPT_PC_Q
         ( PERIOD, PC, GRP_CODE,S_DESC, AMOUNT_TWD, AMOUNT_USD, AMOUNT_CNY) 
        VALUES
         ( in_YYYYMM1 , REC1.PC,in_GRP_CODE,STR01, REC1.AMOUNT_TWD, REC1.AMOUNT_USD, REC1.AMOUNT_CNY);  
      END LOOP;   
      
  /*****************************************************************************************
      (2)Min. Cash
  ************************************************************************************ */
  -- Min. Cash=-{(�H�H�HuCOGS )-(�H�H�HuD&A )+(�H�H�HuSG&A )}/3*12*30/365 
  
  
 
      STR01 :=  '00250';                 --Min. Cash
	  STR02 :=  '00060';                 --COGS
	  STR03 :=  '00070';                 --D&A
	  STR04 :=  '00120';                 --SG&A
	  
  
      for REC1 IN (
	    --SQL
        select  AA1.PC , 
        ( AA1.amount_twd - AA2.amount_twd + AA3.amount_twd ) / 3 * 12 * 30 / 365 *-1 amount_twd,
        ( AA1.amount_usd - AA2.amount_usd + AA3.amount_usd ) / 3 * 12 * 30 / 365 *-1 amount_usd,
        ( AA1.amount_cny - AA2.amount_cny + AA3.amount_cny ) / 3 * 12 * 30 / 365 *-1 amount_cny        
        
        from
        (
		  		  
          SELECT a.PC, 
            SUM (a.amount_twd)  amount_twd,
            SUM (a.amount_usd)  amount_usd,
            SUM (a.amount_cny)  amount_cny
          FROM ROIC_PST020_FINAL_RPT_PC_Q a
          WHERE a.S_DESC = STR02 and (a.period = in_YYYYMM1 )
		  and GRP_CODE = in_GRP_CODE
          GROUP BY PC		  

		  
        ) AA1,

        (

		
          SELECT a.PC,
            SUM (a.amount_twd)  amount_twd,
            SUM (a.amount_usd)  amount_usd,
            SUM (a.amount_cny)  amount_cny
          FROM ROIC_PST020_FINAL_RPT_PC_Q a
          WHERE a.S_DESC = STR03 and ( a.period = in_YYYYMM1 )
		  and GRP_CODE = in_GRP_CODE
          GROUP BY PC

		  
        ) AA2,

        (
		
          SELECT a.PC,
            SUM (a.amount_twd)  amount_twd,
            SUM (a.amount_usd)  amount_usd,
            SUM (a.amount_cny)  amount_cny
          FROM ROIC_PST020_FINAL_RPT_PC_Q a
          WHERE a.S_DESC = STR04 and ( a.period = in_YYYYMM1 )
		  and GRP_CODE = in_GRP_CODE
          GROUP BY PC
		  
		
        ) AA3   
        
        where ( AA1.PC = AA2.PC and AA2.PC = AA3.PC  )            
      )
      LOOP
        INSERT INTO ROIC_PST020_FINAL_RPT_PC_Q
         ( PERIOD, PC, GRP_CODE,S_DESC, AMOUNT_TWD, AMOUNT_USD, AMOUNT_CNY) 
        VALUES
         ( in_YYYYMM1 , REC1.PC,in_GRP_CODE,STR01, REC1.AMOUNT_TWD, REC1.AMOUNT_USD, REC1.AMOUNT_CNY);             
      END LOOP;   
 
  /*****************************************************************************************
      (3)Working Capital
  ************************************************************************************ */
      --Working Capital=(�H�H�Hu�H�H�H�HAR )+(�H�H�Hu�H�H�H�HINV )-(�H�H�Hu�H�H�H�HAP ) 

 
      STR01 :=  '00260';                 --Working Capital
	  STR02 :=  '00010';                 --AR
	  STR03 :=  '00020';                 --INV
	  STR04 :=  '00030';                 --AP

  
      for REC1 IN (
	    --SQL
        select  AA1.PC,
        ( AA1.amount_twd + AA2.amount_twd - AA3.amount_twd )  amount_twd,
        ( AA1.amount_usd + AA2.amount_usd - AA3.amount_usd )  amount_usd,
        ( AA1.amount_cny + AA2.amount_cny - AA3.amount_cny )  amount_cny        
        
        from
        (
          SELECT a.PC,
            SUM (a.amount_twd)  amount_twd,
            SUM (a.amount_usd)  amount_usd,
            SUM (a.amount_cny)  amount_cny
          FROM ROIC_PST020_FINAL_RPT_PC_Q a
          WHERE a.S_DESC = STR02 and ( a.period = in_YYYYMM1 )
		  and GRP_CODE = in_GRP_CODE
          GROUP BY PC
        ) AA1,

        (
          SELECT a.PC,
            SUM (a.amount_twd)  amount_twd,
            SUM (a.amount_usd)  amount_usd,
            SUM (a.amount_cny)  amount_cny
          FROM ROIC_PST020_FINAL_RPT_PC_Q a
          WHERE a.S_DESC = STR03 and ( a.period = in_YYYYMM1 )
		  and GRP_CODE = in_GRP_CODE
          GROUP BY PC
        ) AA2,

        (
          SELECT a.PC,
            SUM (a.amount_twd)  amount_twd,
            SUM (a.amount_usd)  amount_usd,
            SUM (a.amount_cny)  amount_cny
          FROM ROIC_PST020_FINAL_RPT_PC_Q a
          WHERE a.S_DESC = STR04 and ( a.period = in_YYYYMM1 )
		  and GRP_CODE = in_GRP_CODE
          GROUP BY PC
        ) AA3   
        
        where
        ( AA1.PC = AA2.PC and AA2.PC = AA3.PC  )          
      )
      LOOP
        INSERT INTO ROIC_PST020_FINAL_RPT_PC_Q
         ( PERIOD, PC, GRP_CODE,S_DESC, AMOUNT_TWD, AMOUNT_USD, AMOUNT_CNY) 
        VALUES
         ( in_YYYYMM1, REC1.PC,in_GRP_CODE,STR01, REC1.AMOUNT_TWD, REC1.AMOUNT_USD, REC1.AMOUNT_CNY);            
      END LOOP;  

  /*****************************************************************************************
      (4)PP&E
  ************************************************************************************ */
  -- PP&E=�H�H�Hu�H�H�H�H(FA-Land+FA-Building+Electricity+FA-Equitment +FA-Others+Right of use asset Land Occ Government)) 


     
 
      STR01 :=  '00270';	 --'PP&E' 
      for REC1 IN (
	    --SQL

          SELECT a.PC , 
            ( SUM (a.amount_twd))   amount_twd,
            ( SUM (a.amount_usd))   amount_usd,
            ( SUM (a.amount_cny))   amount_cny
          FROM ROIC_PST020_FINAL_RPT_PC_Q a
          WHERE a.S_DESC in ('00040','00041','00042','00043','00044') 
		  and ( a.period = in_YYYYMM1 )
		  and GRP_CODE = in_GRP_CODE
          GROUP BY PC
		
      )
      LOOP
        INSERT INTO ROIC_PST020_FINAL_RPT_PC_Q
         ( PERIOD, PC, GRP_CODE,S_DESC, AMOUNT_TWD, AMOUNT_USD, AMOUNT_CNY) 
        VALUES
         ( in_YYYYMM1, REC1.PC,in_GRP_CODE,STR01, REC1.AMOUNT_TWD, REC1.AMOUNT_USD, REC1.AMOUNT_CNY); 
	   END LOOP;  	  	  

    /*****************************************************************************************
      (5)Current NI ( after tax )
    ************************************************************************************ */
    --Current NI ( after tax )
	
      STR01 :=  '00230';                 --Current NI ( after tax )
	  STR02 :=  '00050';                 --REV
	  STR03 :=  '00060';                 --COGS
	  STR04 :=  '00120';                 --SG&A
	  --STR04 :=  'SG&A';
	  
      for REC1 IN (
	    --SQL
	        select PC ,S_DESC,GRP_CODE,
	        sum(AMOUNT_TWD) AMOUNT_TWD, sum(AMOUNT_USD) AMOUNT_USD, sum(AMOUNT_CNY) AMOUNT_CNY
	        from ROIC_PST019_FINAL_RPT_PC
	        where

			( period <= In_PERIOD and period >= From_PERIOD )
			and S_DESC = STR01
			and GRP_CODE = in_GRP_CODE 			
	        group by PC ,S_DESC,GRP_CODE
	        order by PC ,S_DESC,GRP_CODE  		
         
      )
      LOOP
        INSERT INTO ROIC_PST020_FINAL_RPT_PC_Q
         ( PERIOD, PC, GRP_CODE,S_DESC, AMOUNT_TWD, AMOUNT_USD, AMOUNT_CNY) 
        VALUES
         ( in_YYYYMM1 , REC1.PC,in_GRP_CODE,STR01, REC1.AMOUNT_TWD, REC1.AMOUNT_USD, REC1.AMOUNT_CNY);           
      END LOOP;

	  
    /*****************************************************************************************
      (6)NI �H]after tax�H^
    ************************************************************************************ */
    --'Current NI �H]after tax�H^=�H�H�HuCurrent NI �H]after tax�H^/3*12

	
      STR01 :=  '00240';    --NI  ( after tax )
	  STR02 :=  '00230';    

	  
      for REC1 IN (
	  
          SELECT a.PC , 
            SUM (a.amount_twd)/3*12  amount_twd,
            SUM (a.amount_usd)/3*12  amount_usd,
            SUM (a.amount_cny)/3*12  amount_cny
          FROM ROIC_PST020_FINAL_RPT_PC_Q a
          WHERE a.S_DESC = STR02 and ( a.period = in_YYYYMM1)
		  and GRP_CODE = in_GRP_CODE
          GROUP BY PC
		 
      )
      LOOP
        INSERT INTO ROIC_PST020_FINAL_RPT_PC_Q
         ( PERIOD, PC, GRP_CODE,S_DESC, AMOUNT_TWD, AMOUNT_USD, AMOUNT_CNY) 
        VALUES
         ( in_YYYYMM1 , REC1.PC,in_GRP_CODE,STR01, REC1.AMOUNT_TWD, REC1.AMOUNT_USD, REC1.AMOUNT_CNY);           
      END LOOP;


    /*****************************************************************************************
      (7)Subtotal
    ************************************************************************************ */
    --Subtotal = Min. Cash + Working Capital + PP&E

	
      STR01 :=  '00280';            --Subtotal
	  STR02 :=  '00250';            --Min. Cash             
	  STR03 :=  '00260';            -- Working Capital               
	  STR04 :=  '00270';            --PP&E

	  
      for REC1 IN (

        select  AA1.PC , 
        SUM ( AA1.amount_twd ) amount_twd,
        SUM ( AA1.amount_usd ) amount_usd,
        SUM ( AA1.amount_cny ) amount_cny
        FROM  ROIC_PST020_FINAL_RPT_PC_Q  AA1
        WHERE ( S_DESC = STR02	OR S_DESC = STR03 OR S_DESC = STR04 ) AND AA1.period = in_YYYYMM1
		and GRP_CODE = in_GRP_CODE
        GROUP BY AA1.PC
         
      )
      LOOP
        INSERT INTO ROIC_PST020_FINAL_RPT_PC_Q
         ( PERIOD, PC, GRP_CODE,S_DESC, AMOUNT_TWD, AMOUNT_USD, AMOUNT_CNY) 
        VALUES
         ( in_YYYYMM1 , REC1.PC,in_GRP_CODE,STR01, REC1.AMOUNT_TWD, REC1.AMOUNT_USD, REC1.AMOUNT_CNY);               
      END LOOP;	
        
    /*****************************************************************************************
      (8)ROIC
    ************************************************************************************ */
	   
  
  -----------------------------------------
  sRUN_SEQ   := '000020';
  sRUN_DESC  := 'End';

  --Insert Log
  INSERT INTO ROIC_PST000_LOG
      ( PROC_NAME, RUN_SEQ, RUN_DESC, PARAMETER_DESC )
    VALUES
      ( sPROC_NAME, sRUN_SEQ, sRUN_DESC, sPARAMETER_DESC );
  Commit;
  
END ROIC_PLS020_FINAL_RPT_PC_Q;
/

