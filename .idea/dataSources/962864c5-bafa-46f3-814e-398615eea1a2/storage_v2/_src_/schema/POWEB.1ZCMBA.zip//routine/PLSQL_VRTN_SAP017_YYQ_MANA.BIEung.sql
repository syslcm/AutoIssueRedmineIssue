create PROCEDURE         "PLSQL_VRTN_SAP017_YYQ_MANA" (
  inCompany  in VRTN_SAP017_YYQ_MANA.COMPANY_CODE%TYPE
  --f_YYYYMMDD in VARCHAR2,
  --t_YYYYMMDD in VARCHAR2
)
is
 iTracePoint  integer ;
 cErrorText varchar2(500);
 vPROCEE_YYYYQQ  varchar2(6);
 /*
  20180501 Susan 
  MX Site By vendor summary qq
*/
BEGIN
 
 
 --vPROCEE_YYYYQQ := '2018Q1';

 
   DELETE FROM VRTN_SAP017_YYQ_MANA WHERE COMPANY_CODE =inCompany
          and YYYYQQ IN (SELECT YYYYQQ FROM VRTN_SAP017_YYQ_MANA_T  WHERE  COMPANY_CODE =inCompany GROUP BY YYYYQQ);
  
   iTracePoint := 300;
   Insert into VRTN_SAP017_YYQ_MANA  (
           COMPANY_CODE ,  YYYYQQ ,  SITE  ,  YMDS ,  YMDE ,  GV_VENDOR , SCORE, ZTEXT, GRADE   )
   Select  COMPANY_CODE ,  YYYYQQ ,  SITE  ,  YMDS ,  YMDE ,  GV_VENDOR , SCORE, ZTEXT,
           (select b.GRADE as GRADE From VRTN_SUM23_MAPPING_GRADE b where b.RANGE_TYPE = 'SC' and b.RANGE_FROM <= SCORE and b.RANGE_TO >= SCORE ) as GRADE 
     from VRTN_SAP017_YYQ_MANA_T
    where COMPANY_CODE= inCompany
      and YYYYQQ  IN (SELECT YYYYQQ FROM VRTN_SAP017_YYQ_MANA_T  WHERE  COMPANY_CODE =inCompany GROUP BY YYYYQQ);




  iTracePoint := 400;
  -- DELETE  from VRTN_SAP017_YYQ_MANA_T
  --   where COMPANY_CODE = inCompany
  --     and YYYYQQ = vPROCEE_YYYYQQ; 

   Commit;
EXCEPTION
  When OTHERS Then
    --有錯誤產生則寄mail
    cErrorText := SQLERRM();
    MAIL_FILE_BIDBDBADMIN(in_to_name => 'shuchin_lin@usiglobal.com', subject => '[VRTN] PLSQL_VRTN_SAP017_YYQ_MANA ERROR', message => '[PLSQL_VATN014_MANUAL_SCORE], The tracepoint is  ' || iTracePoint || ' and ErrorText= ' || cErrorText) ;

END PLSQL_VRTN_SAP017_YYQ_MANA;
/

