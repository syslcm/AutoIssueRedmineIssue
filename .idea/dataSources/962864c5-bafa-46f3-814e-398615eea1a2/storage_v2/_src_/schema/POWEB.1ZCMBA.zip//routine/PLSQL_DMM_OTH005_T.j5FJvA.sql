create PROCEDURE "PLSQL_DMM_OTH005_T" (
  nCOMPANY_CODE in DMM_OTH005_TABLECOUNT_T.COMPANY_CODE%TYPE,
  f_YYYYMMDD    in VARCHAR2,
  t_YYYYMMDD    in VARCHAR2
)
/*
********************************************************************
  PROG-ID      : PLSQL_DMM_OTH005_T
  PROG-ACTION  : 處理 Table count 資料
  Author       : Minhorng
  Date         : 2009/01/14
*********************************************************************
*/
is
	iTracePoint           integer ;
	cErrorText            varchar2(500);
	cCREATE_DATE          varchar2(8);
	cTNAME                varchar2(40);
	cREC_COUNT            number(18,3);
	cCHK2                 varchar2(20);
BEGIN
	cErrorText := ' ';
	cCHK2 := ' ';
	iTracePoint := 90;
	delete from DMM_OTH005_TABLECOUNT_T
		where COMPANY_CODE = nCOMPANY_CODE
		and CREATE_DATE > to_char(sysdate,'yyyymmdd');
	commit;
	iTracePoint := 100;
	select * into cCREATE_DATE from (
		select max(CREATE_DATE) from DMM_OTH005_TABLECOUNT_T
		where COMPANY_CODE = nCOMPANY_CODE
	);
	iTracePoint := 110;
	delete from DMM_OTH005_TABLECOUNT
		where COMPANY_CODE = nCOMPANY_CODE
		and CREATE_DATE = cCREATE_DATE;
	commit;
	iTracePoint := 120;
	insert into DMM_OTH005_TABLECOUNT
	select * from DMM_OTH005_TABLECOUNT_T
		where COMPANY_CODE = nCOMPANY_CODE
		and CREATE_DATE = cCREATE_DATE;
	commit;
	iTracePoint := 130;
	delete from DMM_OTH005_TABLECOUNT_R
		where COMPANY_CODE = nCOMPANY_CODE
		and CREATE_DATE = cCREATE_DATE;
	commit;
	-- SAP
	iTracePoint := 200;
	for REC1 in (
		select COMPANY_CODE, CREATE_DATE, substr(TNAME,1,8) as TNAME1, sum(REC_COUNT) as REC_COUNT1
		from DMM_OTH005_TABLECOUNT
		where COMPANY_CODE = nCOMPANY_CODE and CREATE_DATE = cCREATE_DATE
		group by COMPANY_CODE, CREATE_DATE, substr(TNAME,1,8)
		order by substr(TNAME,1,8)
	) loop
		if REC1.TNAME1 = 'ZAPD443A' then
			cTNAME := 'BOM';
		elsif REC1.TNAME1 = 'ZAPD443B' then
			cTNAME := 'MAC';
		elsif REC1.TNAME1 = 'ZAPD443C' then
			cTNAME := 'Info Record';
		elsif REC1.TNAME1 = 'ZAPD443D' then
			cTNAME := 'PO';
		elsif REC1.TNAME1 = 'ZAPD443E' then
			cTNAME := 'Quota';
		elsif REC1.TNAME1 = 'ZAPD443F' then
			cTNAME := 'Demand';
		elsif REC1.TNAME1 = 'ZAPD443G' then
			cTNAME := 'FG 101';
		elsif REC1.TNAME1 = 'ZAPD443X' then
			cTNAME := 'Demand (Qty)';
		elsif REC1.TNAME1 = 'ZAPD443Y' then
			cTNAME := 'FG 101 (Qty)';
		end if;
		cCHK2 := cTNAME;
		if cTNAME = 'Quota' then
			insert into DMM_OTH005_TABLECOUNT_R (
				COMPANY_CODE, CREATE_DATE, TNAME, TSERVER, REC_COUNT
			)
			select COMPANY_CODE, CREATE_DATE, cTNAME, TSERVER, REC_COUNT
			from DMM_OTH005_TABLECOUNT_R
			where COMPANY_CODE = REC1.COMPANY_CODE and CREATE_DATE = REC1.CREATE_DATE
			and TNAME = 'Info Record'              and TSERVER = 'SAP';
		else
			insert into DMM_OTH005_TABLECOUNT_R (
				COMPANY_CODE, CREATE_DATE, TNAME, TSERVER, REC_COUNT
			) values (
				REC1.COMPANY_CODE,
				REC1.CREATE_DATE,
				cTNAME,
				'SAP',
				REC1.REC_COUNT1
			);
		end if;
		commit;
	end loop;
	--
	iTracePoint := 310;
	cREC_COUNT := 0;
	select * into cREC_COUNT from (
		select count(*) from DMM_TMP001_BOM
		where COMPANY_CODE = nCOMPANY_CODE and CREATE_DATE = cCREATE_DATE
	);
	insert into DMM_OTH005_TABLECOUNT_R (
		COMPANY_CODE, CREATE_DATE, TNAME, TSERVER, REC_COUNT
	) values (
		nCOMPANY_CODE,
		cCREATE_DATE,
		'BOM',
		'TEMP',
		cREC_COUNT
	);
	commit;
	iTracePoint := 315;
	cREC_COUNT := 0;
	select * into cREC_COUNT from (
		select count(*) from DMM_SAP001_BOM
		where COMPANY_CODE = nCOMPANY_CODE and CREATE_DATE = cCREATE_DATE
	);
	insert into DMM_OTH005_TABLECOUNT_R (
		COMPANY_CODE, CREATE_DATE, TNAME, TSERVER, REC_COUNT
	) values (
		nCOMPANY_CODE,
		cCREATE_DATE,
		'BOM',
		'BI',
		cREC_COUNT
	);
	commit;
	--
	iTracePoint := 320;
	cREC_COUNT := 0;
	select * into cREC_COUNT from (
		select count(*) from DMM_TMP002_INT_PART
		where COMPANY_CODE = nCOMPANY_CODE and CREATE_DATE = cCREATE_DATE
	);
	insert into DMM_OTH005_TABLECOUNT_R (
		COMPANY_CODE, CREATE_DATE, TNAME, TSERVER, REC_COUNT
	) values (
		nCOMPANY_CODE,
		cCREATE_DATE,
		'MAC',
		'TEMP',
		cREC_COUNT
	);
	commit;
	iTracePoint := 325;
	cREC_COUNT := 0;
	select * into cREC_COUNT from (
		select count(*) from DMM_SAP002_INT_PART
		where COMPANY_CODE = nCOMPANY_CODE and CREATE_DATE = cCREATE_DATE
	);
	insert into DMM_OTH005_TABLECOUNT_R (
		COMPANY_CODE, CREATE_DATE, TNAME, TSERVER, REC_COUNT
	) values (
		nCOMPANY_CODE,
		cCREATE_DATE,
		'MAC',
		'BI',
		cREC_COUNT
	);
	commit;
	--
	iTracePoint := 330;
	cREC_COUNT := 0;
	select * into cREC_COUNT from (
		select count(*) from DMM_TMP003_QTA_INF
		where COMPANY_CODE = nCOMPANY_CODE and CREATE_DATE = cCREATE_DATE
	);
	insert into DMM_OTH005_TABLECOUNT_R (
		COMPANY_CODE, CREATE_DATE, TNAME, TSERVER, REC_COUNT
	) values (
		nCOMPANY_CODE,
		cCREATE_DATE,
		'Info Record',
		'TEMP',
		cREC_COUNT
	);
	insert into DMM_OTH005_TABLECOUNT_R (
		COMPANY_CODE, CREATE_DATE, TNAME, TSERVER, REC_COUNT
	) values (
		nCOMPANY_CODE,
		cCREATE_DATE,
		'Quota',
		'TEMP',
		cREC_COUNT
	);
	commit;
	iTracePoint := 335;
	cREC_COUNT := 0;
	select * into cREC_COUNT from (
		select count(*) from DMM_SAP003_QTA_INF
		where COMPANY_CODE = nCOMPANY_CODE and CREATE_DATE = cCREATE_DATE
	);
	insert into DMM_OTH005_TABLECOUNT_R (
		COMPANY_CODE, CREATE_DATE, TNAME, TSERVER, REC_COUNT
	) values (
		nCOMPANY_CODE,
		cCREATE_DATE,
		'Info Record',
		'BI',
		cREC_COUNT
	);
	insert into DMM_OTH005_TABLECOUNT_R (
		COMPANY_CODE, CREATE_DATE, TNAME, TSERVER, REC_COUNT
	) values (
		nCOMPANY_CODE,
		cCREATE_DATE,
		'Quota',
		'BI',
		cREC_COUNT
	);
	commit;
	--
	iTracePoint := 340;
	cREC_COUNT := 0;
	select * into cREC_COUNT from (
		select count(*) from DMM_TMP004_PO
		where COMPANY_CODE = nCOMPANY_CODE and CREATE_DATE = cCREATE_DATE
	);
	insert into DMM_OTH005_TABLECOUNT_R (
		COMPANY_CODE, CREATE_DATE, TNAME, TSERVER, REC_COUNT
	) values (
		nCOMPANY_CODE,
		cCREATE_DATE,
		'PO',
		'TEMP',
		cREC_COUNT
	);
	commit;
	iTracePoint := 345;
	cREC_COUNT := 0;
	select * into cREC_COUNT from (
		select count(*) from DMM_SAP004_PO
		where COMPANY_CODE = nCOMPANY_CODE and CREATE_DATE = cCREATE_DATE
	);
	insert into DMM_OTH005_TABLECOUNT_R (
		COMPANY_CODE, CREATE_DATE, TNAME, TSERVER, REC_COUNT
	) values (
		nCOMPANY_CODE,
		cCREATE_DATE,
		'PO',
		'BI',
		cREC_COUNT
	);
	commit;
	--
	iTracePoint := 350;
	cREC_COUNT := 0;
	select * into cREC_COUNT from (
		select count(*) from DMM_TMP006_FGFCST
		where COMPANY_CODE = nCOMPANY_CODE and CREATE_DATE = cCREATE_DATE
	);
	insert into DMM_OTH005_TABLECOUNT_R (
		COMPANY_CODE, CREATE_DATE, TNAME, TSERVER, REC_COUNT
	) values (
		nCOMPANY_CODE,
		cCREATE_DATE,
		'Demand',
		'TEMP',
		cREC_COUNT
	);
	commit;
	iTracePoint := 355;
	cREC_COUNT := 0;
	select * into cREC_COUNT from (
		select count(*) from DMM_SAP006_FGFCST
		where COMPANY_CODE = nCOMPANY_CODE and CREATE_DATE = cCREATE_DATE
	);
	insert into DMM_OTH005_TABLECOUNT_R (
		COMPANY_CODE, CREATE_DATE, TNAME, TSERVER, REC_COUNT
	) values (
		nCOMPANY_CODE,
		cCREATE_DATE,
		'Demand',
		'BI',
		cREC_COUNT
	);
	commit;
	--
	iTracePoint := 360;
	cREC_COUNT := 0;
	select * into cREC_COUNT from (
		select count(*) from DMM_TMP007_FG101
		where COMPANY_CODE = nCOMPANY_CODE and CREATE_DATE = cCREATE_DATE
	);
	insert into DMM_OTH005_TABLECOUNT_R (
		COMPANY_CODE, CREATE_DATE, TNAME, TSERVER, REC_COUNT
	) values (
		nCOMPANY_CODE,
		cCREATE_DATE,
		'FG 101',
		'TEMP',
		cREC_COUNT
	);
	commit;
	iTracePoint := 365;
	cREC_COUNT := 0;
	select * into cREC_COUNT from (
		select count(*) from DMM_SAP007_FG101
		where COMPANY_CODE = nCOMPANY_CODE and CREATE_DATE = cCREATE_DATE
	);
	insert into DMM_OTH005_TABLECOUNT_R (
		COMPANY_CODE, CREATE_DATE, TNAME, TSERVER, REC_COUNT
	) values (
		nCOMPANY_CODE,
		cCREATE_DATE,
		'FG 101',
		'BI',
		cREC_COUNT
	);
	commit;
	--
	iTracePoint := 370;
	cREC_COUNT := 0;
	select * into cREC_COUNT from (
		select sum(QTY) from DMM_TMP006_FGFCST
		where COMPANY_CODE = nCOMPANY_CODE and CREATE_DATE = cCREATE_DATE
	);
	insert into DMM_OTH005_TABLECOUNT_R (
		COMPANY_CODE, CREATE_DATE, TNAME, TSERVER, REC_COUNT
	) values (
		nCOMPANY_CODE,
		cCREATE_DATE,
		'Demand (Qty)',
		'TEMP',
		cREC_COUNT
	);
	commit;
	iTracePoint := 375;
	cREC_COUNT := 0;
	select * into cREC_COUNT from (
		select sum(QTY) from DMM_SAP006_FGFCST
		where COMPANY_CODE = nCOMPANY_CODE and CREATE_DATE = cCREATE_DATE
	);
	insert into DMM_OTH005_TABLECOUNT_R (
		COMPANY_CODE, CREATE_DATE, TNAME, TSERVER, REC_COUNT
	) values (
		nCOMPANY_CODE,
		cCREATE_DATE,
		'Demand (Qty)',
		'BI',
		cREC_COUNT
	);
	commit;
	--
	iTracePoint := 380;
	cREC_COUNT := 0;
	select * into cREC_COUNT from (
		select sum(QTY) from DMM_TMP007_FG101
		where COMPANY_CODE = nCOMPANY_CODE and CREATE_DATE = cCREATE_DATE
	);
	insert into DMM_OTH005_TABLECOUNT_R (
		COMPANY_CODE, CREATE_DATE, TNAME, TSERVER, REC_COUNT
	) values (
		nCOMPANY_CODE,
		cCREATE_DATE,
		'FG 101 (Qty)',
		'TEMP',
		cREC_COUNT
	);
	commit;
	iTracePoint := 385;
	cREC_COUNT := 0;
	select * into cREC_COUNT from (
		select sum(QTY) from DMM_SAP007_FG101
		where COMPANY_CODE = nCOMPANY_CODE and CREATE_DATE = cCREATE_DATE
	);
	insert into DMM_OTH005_TABLECOUNT_R (
		COMPANY_CODE, CREATE_DATE, TNAME, TSERVER, REC_COUNT
	) values (
		nCOMPANY_CODE,
		cCREATE_DATE,
		'FG 101 (Qty)',
		'BI',
		cREC_COUNT
	);
	commit;
EXCEPTION
  WHEN OTHERS THEN
    cErrorText := trim(cCHK2) || '>' || SQLERRM() ;
    MAIL_FILE_BIDBDBADMIN(in_to_name=>'minhorng@ms.usi.com.tw',subject   => '[DMM]PL/SQL PLSQL_DMM_OTH005_T ERROR - Company: ' || nCOMPANY_CODE, message => '[PLSQL_DMM_OTH005_T], The tracepoint is  ' || to_char(iTracePoint) || ' and ErrorText=' || cErrorText) ;
End PLSQL_DMM_OTH005_T;
/

