create PROCEDURE PRODUTIVITY_MFG_REPORT2_H_TRX (
  inCompany  IN VARCHAR2,
  f_YYYYMMDD IN VARCHAR2,
  t_YYYYMMDD IN VARCHAR2
)
AUTHID DEFINER
IS
  --¿¿ ORGINAL ACCOUNT
  CURSOR C_ROUTING_T IS
    SELECT  COMPANY_CODE    ,
            PERIOD   ,
            USIPN        ,
            PLANT            ,
            GROUP_NUMBER        ,
            GROUP_COUNTER        ,
            TOTAL_HRS      ,
            TOTAL_RATE     ,
   DIVISION       ,
   PROFIT_CENTER  ,
   AVG_QTY        ,
   SUM_QTY        ,
   TOTAL_LH       ,
   TOTAL_LHFM     ,
   WORK_ORDER     ,
   CFM_QTY        ,
   ADD_HRS
      FROM PRODUTIVITY_MFG_REPORT2_H_T
           WHERE COMPANY_CODE = inCompany;


 BEGIN

   --(1)¿¿¿¿ KPI_MAP018_ORGANIZATION ¿¿
   DELETE FROM PRODUTIVITY_MFG_REPORT2_HEADER
   WHERE PERIOD IN (SELECT PERIOD FROM PRODUTIVITY_MFG_REPORT2_H_T WHERE COMPANY_CODE = inCompany GROUP BY PERIOD)
     AND COMPANY_CODE = inCompany ;
   COMMIT;

   FOR REC1 IN C_ROUTING_T LOOP
       --¿¿¿¿¿¿
       INSERT INTO PRODUTIVITY_MFG_REPORT2_HEADER (
                   COMPANY_CODE            , PERIOD                   , USIPN                , PLANT                 ,
                   GROUP_NUMBER            , GROUP_COUNTER            , TOTAL_HRS            , TOTAL_RATE            ,
       CREATEDATE              , DIVISION                 , PROFIT_CENTER        , AVG_QTY               ,
       SUM_QTY                 , TOTAL_LH                 , TOTAL_LHFM           , WORK_ORDER            ,
       CFM_QTY                 , ADD_HRS
                 ) VALUES (
                   TRIM(REC1.COMPANY_CODE) , TRIM(REC1.PERIOD)        , TRIM(REC1.USIPN)     , TRIM(REC1.PLANT)       ,
                   TRIM(REC1.GROUP_NUMBER) , TRIM(REC1.GROUP_COUNTER) , TRIM(REC1.TOTAL_HRS) , TRIM(REC1.TOTAL_RATE)  ,
       SYSDATE                 , TRIM(REC1.DIVISION)      , TRIM(REC1.PROFIT_CENTER),TRIM(REC1.AVG_QTY)   ,
       TRIM(REC1.SUM_QTY)      , TRIM(REC1.TOTAL_LH)      , TRIM(REC1.TOTAL_LHFM)   ,TRIM(REC1.WORK_ORDER),
       TRIM(REC1.CFM_QTY)      , TRIM(REC1.ADD_HRS));
       COMMIT;
   END LOOP;
   
   DELETE FROM PRODUTIVITY_MFG_REPORT2_H_T WHERE COMPANY_CODE = inCompany;
   COMMIT;
END PRODUTIVITY_MFG_REPORT2_H_TRX ;
/

