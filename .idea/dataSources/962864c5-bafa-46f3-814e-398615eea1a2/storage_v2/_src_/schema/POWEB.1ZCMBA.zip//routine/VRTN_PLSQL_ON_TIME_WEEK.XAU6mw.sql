create PROCEDURE         "VRTN_PLSQL_ON_TIME_WEEK" IS

   /*
    每週執行一次 By MatGroup
    1. 抓 PLD_KPI_VMI4A4_4A5_VIEW - VIEW 4a4/4a5 資料
	2. by 週清 VRTN_ZOT003_ONTIME_DELV_WEEK
    3. Insert to VRTN_ZOT003_ONTIME_DELV_WEEK table
	change date: 2007/04/30 by susan for delete by week
	 BY All site
   */


  vPROCEE_YYYYMMDD           varchar2(8);
  vPROCEE_YYYYMM             varchar2(6);
  vCFM_4A5_QTY               VRTN_ZOT003_ONTIME_DELV_WEEK.CFM_4A5_QTY%TYPE;
  vSITE                      VRTN_ZOT003_ONTIME_DELV_WEEK.SITE%TYPE;
  vSCORE                     VRTN_ZOT003_ONTIME_DELV_WEEK.SCORE%TYPE;
  vMATGROUP                  VRTN_ZOT003_ONTIME_DELV_WEEK.MATGROUP%TYPE;
  iTracePoint                varchar2(100);
  cErrorText                 varchar2(500);

BEGIN
    --抓上個月份
    iTracePoint := '100';
    --vPROCEE_YYYYMMDD := to_date(sysdate,'yyyymmdd');
	vPROCEE_YYYYMMDD  :=  to_char(sysdate,'YYYYMMDD');
	vPROCEE_YYYYMM :=  SUBSTRB(vPROCEE_YYYYMMDD,1,6);



   --BY 週清(上週), 先清舊的資料以避免重覆
    iTracePoint := '200' || vPROCEE_YYYYMM;
    DELETE FROM VRTN_ZOT003_ONTIME_DELV_WEEK
           WHERE p_week in (Select substrb(yyyyww,5,2) from DIMENSION_DATE Where date_key = to_char( sysdate -7, 'yyyymmdd'));
    commit;


    --放入上月分數
    iTracePoint := '300';
    for REC1 in (Select Substr(A_TEMP.YYYYMM,1,4) AS YEAR, Substr(A_TEMP.YYYYMM,5,2) AS MONTH ,Substr(A_TEMP.WEEK,5,2) AS WEEK, A_TEMP.QUARTER AS QUARTER,A_TEMP.COMPANY_CODE, A_TEMP.SITE, A_TEMP.VENDOR_CODE, A_TEMP.PO_NO, A_TEMP.ITEM_NO, A_TEMP.IM_PN, A_TEMP.PART_NO,
                   A_TEMP.DELIVERY_QTY, C_TEMP.PART_QTY, A_TEMP.CFM_4A5_QTY, A_TEMP.PLANT_CODE, A_TEMP.FORECAST_ID,
                   NVL(round( 1 - ( Abs ((C_TEMP.PART_QTY - A_TEMP.CFM_4A5_QTY) / (A_TEMP.CFM_4A5_QTY)) ),5) * 100 ,0) AS SCORE
                       FROM
     ( Select A.FORECAST_ID, A.COMPANY_CODE,
                   DECODE(A.COMPANY_CODE,A.COMPANY_CODE,A.COMPANY_CODE) AS SITE,
                   A.VENDOR_CODE, A.WEEK, A.PO_NO, A.ITEM_NO, A.PART_NO, A.PLANT_CODE, A.CTYPE, A.DELIVERY_QTY, A.CONFIRM_QTY_4A5 AS CFM_4A5_QTY,
                   DECODE(B.INT_PART_NO ,'',A.PART_NO,B.INT_PART_NO) AS IM_PN, D.YYYYMM, D.QUARTER
                   from PLD_KPI_VMI4A4_4A5_VIEW A, SAP_AMPL B, DIMENSION_DATE D
                   WHERE B.COMPANY_CODE (+)= A.COMPANY_CODE AND
				         B.PART_NO (+)= A.PART_NO  AND
				         D.DATE_KEY = TO_CHAR( sysdate,'YYYYMMDD')
                            ) A_TEMP,
     (Select C.COMPANY_CODE,
          DECODE(C.COMPANY_CODE,C.COMPANY_CODE,C.COMPANY_CODE) as SITE,
          C.VENDOR_ID,  PART_NO, PO_NO, PO_ITEM, SUM(C.PART_QTY) AS PART_QTY
          from PLD_KPI_SITE_GR_AMT C
            WHERE C.PO_TYPE = 'L' AND
                  C.PART_QTY <> 0 AND
                  to_date(C.GR_DATE,'yyyymmdd') between (sysdate - 7) and (sysdate - 1)
            GROUP BY C.COMPANY_CODE,
                     DECODE(C.COMPANY_CODE,C.COMPANY_CODE,C.COMPANY_CODE),
                     C.VENDOR_ID,
                     C.PO_NO,
                     C.PO_ITEM,
                     C.PART_NO
       ) C_TEMP
      WHERE  C_TEMP.COMPANY_CODE (+)= A_TEMP.COMPANY_CODE AND
             C_TEMP.COMPANY_CODE (+)= A_TEMP.SITE AND
             C_TEMP.VENDOR_ID (+)= A_TEMP.VENDOR_CODE AND
             C_TEMP.PO_NO (+)= A_TEMP.PO_NO AND
             C_TEMP.PO_ITEM (+)= A_TEMP.ITEM_NO AND
             C_TEMP.PART_NO (+)= A_TEMP.IM_PN
                             ) loop
      --放到 VRT_ZOT003_ONTIME_DELV_WEEK
      iTracePoint := '400-' || REC1.COMPANY_CODE || '-' || REC1.VENDOR_CODE || '-' || vPROCEE_YYYYMM;
       if REC1.SCORE < 0 then
          vSCORE := 0;
       else
          vSCORE := REC1.SCORE;
       end if;


    --Get MatGroup
	iTracePoint := '500-' || REC1.COMPANY_CODE || '-' || REC1.VENDOR_CODE || '-' || vPROCEE_YYYYMM;
    vMATGROUP := null;
BEGIN
     SELECT DISTINCT MTL_GROUP AS MATGROUP INTO vMATGROUP
                FROM PLD_KPI_PN_MTLGRP_SUBGRP
	           WHERE PART_NO = REC1.IM_PN;

EXCEPTION
  When OTHERS Then
       vMATGROUP := '999';
--     if vMATGROUP is null then
--         --若沒抓到資料
--         vMATGROUP := '999';
--     else

END;

      insert into VRTN_ZOT003_ONTIME_DELV_WEEK (
             P_YEAR, P_MONTH, P_WEEK, P_QUARTER, COMPANY_CODE, SITE, VENDOR_CODE, FORECAST_ID, PO, ITEM, PLANT, PART, IM_PN, MATGROUP, PTYPE, CFM_4A5_QTY, GR_QTY, SCORE,DATE_TIME
           ) values (
             REC1.YEAR,
             REC1.MONTH,
             --'09',
             REC1.WEEK,
             --'38',
             REC1.QUARTER,
             --'Q3',
             REC1.COMPANY_CODE,
             REC1.SITE,
             REC1.VENDOR_CODE,
             REC1.FORECAST_ID,
             REC1.PO_NO,
             REC1.ITEM_NO,
             REC1.PLANT_CODE,
             REC1.PART_NO,
             REC1.IM_PN,
			 vMATGROUP,
             'DB',
             REC1.CFM_4A5_QTY,
             REC1.PART_QTY,
             vSCORE,
             vPROCEE_YYYYMMDD
             --'20060927081000'
           );
      commit;
--	 end if;
    end loop;


EXCEPTION
  When OTHERS Then
    --有錯誤產生則寄mail
    cErrorText := SQLERRM();
    MAIL_FILE_BIDBDBADMIN(in_to_name => 'shuchin_lin@usiglobal.com', subject => '[VRTN] PL/SQL VRTN_PLSQL_ON_TIME_WEEK ERROR', message => '[VRT_ZOT003_ONTIME_DELV_WEEK], The tracepoint is  ' || iTracePoint || ' and ErrorText= ' || cErrorText) ;

END VRTN_PLSQL_ON_TIME_WEEK;
/

