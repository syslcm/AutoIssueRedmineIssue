create PROCEDURE PLSQL_DCF_RPT_WEEKLY_LOA_4 (
  outRES OUT VARCHAR2
)
AUTHID DEFINER
is
  --抓各料號的Description/Mfg/Mfg PN/Material Group...
  CURSOR C_DCF_USI_SITE_DATA is
    Select A.USI_PN,
           TRIM(B.DESCRIPTION) as USI_PART_DESC,
           TRIM(B.MANUFACTURE_NUMBER) as MFG,
           TRIM(B.MANUFACTURE_PART) as MFG_PN,
           TRIM(B.MATERIAL_GROUP) as MATERIAL_GROUP
      From DCF_USI_SITE_DATA A, EGI0010_MATL_MASTER B
     where TRIM(B.MFG_SITE) in ('1100','1200','1300','1500','2300')
       and TRIM(B.MATERIAL) = A.USI_PN
       and A.USI_PN is NOT NULL
     Group by A.USI_PN, B.DESCRIPTION, B.MANUFACTURE_NUMBER, B.MANUFACTURE_PART, B.MATERIAL_GROUP;

  --抓CW, RW (COMPANY: 1100)
  CURSOR C_SAP_MATERIAL_CLIENT is
    Select A.PART_NO, A.CW, A.RW
      From SAP_MATERIAL_CLIENT A, DCF_IBM_LOA_CURRENT B
     where A.PART_NO like B.USI_PN_LIKE || '%'
       and A.COMPANY_CODE = '1100'
     Group by A.PART_NO, A.CW, A.RW;

  --抓Manual key-in data
  CURSOR C_DCF_USI_MANUAL is
    Select distinct
           A.IBM_PN, A.IBM_VENDOR_NO,
           NVL(A.USI_PN,'NVL') as USI_PN, NVL(A.USI_VENDOR_NO,'NVL') as USI_VENDOR_NO,
           A.IBM_CUT_IN, A.USI_CUT_IN, A.PO_CUTIN_DATE, A.SHIP_CUTIN_DATE,
           A.IMPLEMENT_PO, A.SOURCER_COMMENT,
           A.CUSTOMER, A.BUYER_COMMENT, A.SALES_COMMENT,
           A.DATE_SP, A.DATE_MP, A.DATE_SD
      From DCF_USI_MANUAL A, DCF_RPT_WEEKLY_LOA B
     where NVL(A.USI_PN,'NVL') = NVL(B.USI_PN,'NVL')
       and NVL(A.USI_VENDOR_NO,'NVL') = NVL(B.USI_VENDOR_NO,'NVL')
       and A.IBM_PN = B.IBM_PN
       and A.IBM_VENDOR_NO = B.IBM_VENDOR_NO
       and ( A.BUYER_COMMENT is NOT Null or A.SALES_COMMENT is NOT Null
          or A.SOURCER_COMMENT is NOT Null
          or A.PO_CUTIN_DATE is NOT Null or A.SHIP_CUTIN_DATE is NOT Null
          );

  --抓DCF_CFM_PRICE
  CURSOR C_DCF_CFM_PRICE is
    Select USI_PN, USI_VENDOR_NO, CFM_CURRENCY, CFM_PRICE From DCF_CFM_PRICE
     where CFM_CURRENCY is Not Null
       and CFM_PRICE is Not Null
       and PRICE_DATE >= TO_CHAR(SYSDATE - 7, 'YYYYMMDD');

  --處理Quota exists or not
  CURSOR C_DCF_RPT_WEEKLY_LOA1 is
    Select IBM_PN From DCF_RPT_WEEKLY_LOA
     where NVL(QUOTA_TW,0) > 0
        or NVL(QUOTA_SZ,0) > 0
        or NVL(QUOTA_SH,0) > 0
        or NVL(QUOTA_MX,0) > 0
        or NVL(QUOTA_JP,0) > 0
     Group by IBM_PN;

  --處理 DCF_RPT_WEEKLY_LOA-NO
  CURSOR C_DCF_RPT_WEEKLY_LOA2 is
    Select IBM_PN, IBM_VENDOR_NO,
           NVL(USI_PN,'ZZZZZZZZZZZZZZZZZZ') as USI_PN,
           NVL(USI_VENDOR_NO,'ZZZZZZZZZZ') as USI_VENDOR_NO,
           CUSTOMER
      From DCF_RPT_WEEKLY_LOA
     Order by IBM_PN, CUSTOMER, IBM_VENDOR_NO, NVL(USI_PN,'ZZZZZZZZZZZZZZZZZZ'), NVL(USI_VENDOR_NO,'ZZZZZZZZZZ');

   nINT_PART_NO        DCF_RPT_WEEKLY_LOA.INT_PART_NO%TYPE;
   nNO                 DCF_RPT_WEEKLY_LOA.NO%TYPE;
   nBLOCKED            DCF_RPT_WEEKLY_LOA.BLOCKED%TYPE;
   nCOUNT              NUMBER(3);

 BEGIN
   outRES := 'START';

   --抓各料號的Description/Mfg/Mfg PN...
   nCOUNT := 0;
   FOR REC1 in C_DCF_USI_SITE_DATA LOOP
     outRES := 'C_DCF_USI_SITE_DATA:' || REC1.USI_PN;
     BEGIN
       Select * into nINT_PART_NO From (
         Select INT_PART_NO from SAP_AMPL
          where PART_NO = REC1.USI_PN
       ) Where ROWNUM <= 1;
     EXCEPTION
       WHEN OTHERS THEN
         nINT_PART_NO := REC1.USI_PN;
     END;
     nBLOCKED := NULL;
     BEGIN
       Select * into nBLOCKED From (
         Select 'X' from SAP_AMPL
          where PART_NO = REC1.USI_PN
            and ( BLOCKED is NOT NULL or DELE_FLAG is NOT NULL )
            and VALID_FROM <= TO_CHAR(SYSDATE,'YYYYMMDD')
            and VALID_TO >= TO_CHAR(SYSDATE,'YYYYMMDD')
       ) Where ROWNUM <= 1;
     EXCEPTION
       WHEN OTHERS THEN
         nBLOCKED := NULL;
     END;
     --DCF_RPT_WEEKLY_LOA
     Update DCF_RPT_WEEKLY_LOA
        set USI_PART_DESC = REC1.USI_PART_DESC,
            MFG = REC1.MFG,
            MFG_PN = REC1.MFG_PN,
            INT_PART_NO = nINT_PART_NO,
            BLOCKED = nBLOCKED
      where USI_PN = REC1.USI_PN
        and USI_PN is NOT Null;
     --DCF_USI_SITE_DATA
     Update DCF_USI_SITE_DATA
        set MATERIAL_GROUP = REC1.MATERIAL_GROUP
      where USI_PN = REC1.USI_PN
        and USI_PN is NOT Null;
   nCOUNT := nCOUNT + 1;
   If nCOUNT = 10 Then
       Commit;
       nCOUNT := 0;
     End If;
   END LOOP;
   Commit;
   outRES := 'UPDATE C_DCF_USI_SITE_DATA OK';

   --抓CW, RW
   nCOUNT := 0;
   FOR REC1 in C_SAP_MATERIAL_CLIENT LOOP
     outRES := 'C_SAP_MATERIAL_CLIENT:' || REC1.PART_NO;
     Update DCF_RPT_WEEKLY_LOA
        set CW = REC1.CW, RW = REC1.RW
      where USI_PN like REC1.PART_NO || '%'
        and USI_PN is NOT Null;
     nCOUNT := nCOUNT + 1;
     If nCOUNT = 10 Then
       Commit;
       nCOUNT := 0;
     End If;
   END LOOP;
   Commit;
   outRES := 'UPDATE C_SAP_MATERIAL_CLIENT OK';

   --抓Manual key-in data
   nCOUNT := 0;
   FOR REC1 in C_DCF_USI_MANUAL LOOP
     outRES := 'C_DCF_USI_MANUAL:' || REC1.IBM_PN || '<>' || REC1.IBM_VENDOR_NO || '<>' || REC1.USI_PN || '<>' || REC1.USI_VENDOR_NO;
     Update DCF_RPT_WEEKLY_LOA
        set USI_CUT_IN = REC1.USI_CUT_IN,
            PO_CUTIN_DATE = REC1.PO_CUTIN_DATE,
            SHIP_CUTIN_DATE = REC1.SHIP_CUTIN_DATE,
            SOURCER_COMMENT = REC1.SOURCER_COMMENT,
            BUYER_COMMENT = REC1.BUYER_COMMENT,
            SALES_COMMENT = REC1.SALES_COMMENT,
            DATE_SP = REC1.DATE_SP,
            DATE_MP = REC1.DATE_MP,
            DATE_SD = REC1.DATE_SD
      where IBM_PN = REC1.IBM_PN
        and IBM_VENDOR_NO = REC1.IBM_VENDOR_NO
        and CUSTOMER = REC1.CUSTOMER
        and NVL(USI_PN,'NVL') = REC1.USI_PN
        and NVL(USI_VENDOR_NO,'NVL') = REC1.USI_VENDOR_NO;
   nCOUNT := nCOUNT + 1;
   If nCOUNT = 10 Then
       Commit;
       nCOUNT := 0;
     End If;
   END LOOP;
   Commit;
   outRES := 'UPDATE C_DCF_USI_MANUAL OK';

   --抓DCF_CFM_PRICE
   nCOUNT := 0;
   FOR REC1 in C_DCF_CFM_PRICE LOOP
     outRES := 'C_DCF_CFM_PRICE:' || REC1.USI_PN || '<>' || REC1.USI_VENDOR_NO;
     Update DCF_RPT_WEEKLY_LOA
        set CFM_CURRENCY = REC1.CFM_CURRENCY,
            CFM_PRICE = REC1.CFM_PRICE
      where USI_PN = REC1.USI_PN
        and USI_VENDOR_NO = REC1.USI_VENDOR_NO;
     nCOUNT := nCOUNT + 1;
     If nCOUNT = 10 Then
       Commit;
       nCOUNT := 0;
     End If;
   END LOOP;
   Commit;
   outRES := 'UPDATE C_DCF_CFM_PRICE OK';

   --處理Quota exists or not
   nCOUNT := 0;
   FOR REC1 in C_DCF_RPT_WEEKLY_LOA1 LOOP
     outRES := 'C_DCF_RPT_WEEKLY_LOA1:' || REC1.IBM_PN;
     Update DCF_RPT_WEEKLY_LOA
        set QTA_FLAG = 'Y'
      where IBM_PN = REC1.IBM_PN;
   nCOUNT := nCOUNT + 1;
   If nCOUNT = 10 Then
       Commit;
       nCOUNT := 0;
     End If;
   END LOOP;
   Commit;
   Update DCF_RPT_WEEKLY_LOA
      set QTA_FLAG = 'N'
    where QTA_FLAG is NULL;
   Commit;
   outRES := 'UPDATE C_DCF_RPT_WEEKLY_LOA1 OK';

   --處理 DCF_RPT_WEEKLY_LOA-NO
   nCOUNT := 0;
   nNO := 0;
   FOR REC1 in C_DCF_RPT_WEEKLY_LOA2 LOOP
     outRES := 'C_DCF_RPT_WEEKLY_LOA2:' || REC1.IBM_PN || '<>' || REC1.IBM_VENDOR_NO || '<>' || REC1.USI_PN || '<>' || REC1.USI_VENDOR_NO;
     nNO := nNO + 1;
     Update DCF_RPT_WEEKLY_LOA
        set NO = nNO
      where IBM_PN = REC1.IBM_PN
        and IBM_VENDOR_NO = REC1.IBM_VENDOR_NO
        and NVL(USI_PN,'ZZZZZZZZZZZZZZZZZZ') = REC1.USI_PN
        and NVL(USI_VENDOR_NO,'ZZZZZZZZZZ') = REC1.USI_VENDOR_NO
        and CUSTOMER = REC1.CUSTOMER;
   nCOUNT := nCOUNT + 1;
   If nCOUNT = 10 Then
       Commit;
       nCOUNT := 0;
     End If;
   END LOOP;
   Commit;
   outRES := 'UPDATE C_DCF_RPT_WEEKLY_LOA2 OK';

   outRES := 'SUCCESS';
 EXCEPTION
   WHEN OTHERS THEN
     outRES := TRIM(outRES) || ' - ' || TRIM(SUBSTR(SQLERRM,1,100));
     Rollback;
 END PLSQL_DCF_RPT_WEEKLY_LOA_4;
/

