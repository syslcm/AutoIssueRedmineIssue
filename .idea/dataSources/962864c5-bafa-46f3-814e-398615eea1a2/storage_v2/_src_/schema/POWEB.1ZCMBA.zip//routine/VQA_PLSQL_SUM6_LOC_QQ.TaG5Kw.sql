create PROCEDURE         "VQA_PLSQL_SUM6_LOC_QQ" AUTHID DEFINER
IS
  /*
      CREATE DATE:  2008/03/02
      PLSQL      :  VQA_PLSQL_SUM6_LOC_QQ
      Author     :  Susan Lin
      Purpase    :  Summary - Quality - Local site(By 每月執行一次 For 季 )
                    TW/SZ/SH
  */

  vYYYYQQ                    varchar2(6);
  vYYYY                      varchar2(4);
  vQ                         varchar2(1);
  vMM1                       varchar2(2);
  vMM2                       varchar2(2);
  vMM3                       varchar2(2);
  vQ_RANKING                 number(5);
  vSITE                      VQA_SUM14_QQ_MATGP.SITE%TYPE;
  vMATGROUP                  VQA_SUM14_QQ_MATGP.MATGROUP%TYPE;

  Q0_VALUE                   VRTN_MAP060_LEVEL_DESC.VALUE%TYPE;
  QA_VALUE                   VRTN_MAP060_LEVEL_DESC.VALUE%TYPE;
  QB_VALUE                   VRTN_MAP060_LEVEL_DESC.VALUE%TYPE;
  QC_VALUE                   VRTN_MAP060_LEVEL_DESC.VALUE%TYPE;
  QD_VALUE                   VRTN_MAP060_LEVEL_DESC.VALUE%TYPE;

  iTracePoint                varchar2(100);
  cErrorText                 varchar2(500);

BEGIN
  iTracePoint := '000';
  select * into vYYYYQQ, vYYYY, vQ from (
    select trim(trim(to_char(add_months(SYSDATE,-1), 'YYYY')) || 'Q' || trim(to_char(add_months(SYSDATE,-1), 'Q'))),
           trim(to_char(add_months(SYSDATE,-1), 'YYYY')), trim(to_char(add_months(SYSDATE,-1), 'Q'))
      from dual
  );

  if vQ = '1' then
    vMM1 := '01';
    vMM2 := '02';
    vMM3 := '03';
  elsif vQ = '2' then
    vMM1 := '04';
    vMM2 := '05';
    vMM3 := '06';
  elsif vQ = '3' then
    vMM1 := '07';
    vMM2 := '08';
    vMM3 := '09';
  else
    vMM1 := '10';
    vMM2 := '11';
    vMM3 := '12';
  end if;

  iTracePoint := '050';  --Get VRTN_MAP060_LEVEL_DESC value
  Q0_VALUE := 0;
  QA_VALUE := 0;
  QB_VALUE := 0;
  QC_VALUE := 0;
  QD_VALUE := 0;

  for REC1 in (
     select distinct LEVEL_S, VALUE from VRTN_MAP060_LEVEL_DESC where VALUE is not null
  ) loop
     if REC1.LEVEL_S = 'Q0' then
       Q0_VALUE := REC1.VALUE;
     elsif REC1.LEVEL_S = 'QA' then
       QA_VALUE := REC1.VALUE;
     elsif REC1.LEVEL_S = 'QB' then
       QB_VALUE := REC1.VALUE;
     elsif REC1.LEVEL_S = 'QC' then
       QC_VALUE := REC1.VALUE;
     elsif REC1.LEVEL_S = 'QD' then
       QD_VALUE := REC1.VALUE;
     end if;
  end loop;


  iTracePoint := '100';  --刪除 VQA_SUM14_QQ_MATGP
  delete from VQA_SUM14_QQ_MATGP
   where QUARTER = vYYYYQQ;
  commit;

  iTracePoint := '110';
  insert into VQA_SUM14_QQ_MATGP ( SITE, MANUF, MATGROUP, QUARTER, BUKRS, Q_AMOUNT, FROM_DATE, TO_DATE, SITE_PER, AMT_SHARE_SITE, DATE_TIME,
           Q_QA_GRADE, Q_QB_GRADE, Q_QC_GRADE, Q_QD_GRADE, GV_PER )
    select a.SITE, a.MANUF, a.MATGROUP, a.QUARTER, a.BUKRS, sum(b.AMOUNT) as Q_AMOUNT,
           a.FROM_DATE, a.TO_DATE, '', '',
           to_char(SYSDATE, 'yyyymmddhh24miss') as DATE_TIME,
           round(sum(b.AMOUNT * b.QA_GRADE) / sum(b.AMOUNT),5) as Q_QA_GRADE,
           round(sum(b.AMOUNT * b.QB_GRADE) / sum(b.AMOUNT),5) as Q_QB_GRADE,
           round(sum(b.AMOUNT * b.QC_GRADE) / sum(b.AMOUNT),5) as Q_QC_GRADE,
           round(sum(b.AMOUNT * b.QD_GRADE) / sum(b.AMOUNT),5) as Q_QD_GRADE,
           a.GV_PER
      from VQA_SUM04_AMT_MATGP_Q a, VQA_SUM11_MM_MATGP b
     where a.SITE = b.SITE           and a.MANUF = b.MANUF
       and a.MATGROUP = b.MATGROUP   and a.QUARTER = b.QUARTER
       and a.BUKRS = b.BUKRS
       and a.QUARTER = vYYYYQQ
     group by a.SITE, a.MANUF, a.MATGROUP, a.QUARTER, a.BUKRS, a.FROM_DATE, a.TO_DATE, a.SITE_PER, a.GV_PER;
  commit;

  iTracePoint := '120';--Susan change SUBTOT_10_Q = REC1.SUBTOT_Q
  for REC1 in (
     select * from VQA_SUM11_MM_MATGP where YYYY = vYYYY and MM = vMM1
  ) loop
     Update VQA_SUM14_QQ_MATGP
        set QA_10_GRADE = REC1.QA_GRADE,
            QB_10_GRADE = REC1.QB_GRADE,
            QC_10_GRADE = REC1.QC_GRADE,
            QD_10_GRADE = REC1.QD_GRADE,
			SUBTOT_10_Q = REC1.SUBTOT_Q
      where SITE = REC1.SITE
        and MANUF = REC1.MANUF
        and MATGROUP = REC1.MATGROUP
        and QUARTER = REC1.QUARTER;
     commit;
  end loop;

  iTracePoint := '130';
  for REC1 in (
     select * from VQA_SUM11_MM_MATGP where YYYY = vYYYY and MM = vMM2
  ) loop
     Update VQA_SUM14_QQ_MATGP
        set QA_11_GRADE = REC1.QA_GRADE,
            QB_11_GRADE = REC1.QB_GRADE,
            QC_11_GRADE = REC1.QC_GRADE,
            QD_11_GRADE = REC1.QD_GRADE,
            SUBTOT_11_Q = REC1.SUBTOT_Q
      where SITE = REC1.SITE
        and MANUF = REC1.MANUF
        and MATGROUP = REC1.MATGROUP
        and QUARTER = REC1.QUARTER;
     commit;
  end loop;

  iTracePoint := '140';
  for REC1 in (
     select * from VQA_SUM11_MM_MATGP where YYYY = vYYYY and MM = vMM3
  ) loop
     Update VQA_SUM14_QQ_MATGP
        set QA_12_GRADE = REC1.QA_GRADE,
            QB_12_GRADE = REC1.QB_GRADE,
            QC_12_GRADE = REC1.QC_GRADE,
            QD_12_GRADE = REC1.QD_GRADE,
            SUBTOT_12_Q = REC1.SUBTOT_Q
      where SITE = REC1.SITE
        and MANUF = REC1.MANUF
        and MATGROUP = REC1.MATGROUP
        and QUARTER = REC1.QUARTER;
     commit;
  end loop;

  iTracePoint := '151';
  Update VQA_SUM14_QQ_MATGP
     set SUBTOT_Q = round( (nvl(Q_QA_GRADE,0) * QA_VALUE) + (nvl(Q_QB_GRADE,0) * QB_VALUE) + (nvl(Q_QC_GRADE,0) * QC_VALUE) + (nvl(Q_QD_GRADE,0) * QD_VALUE), 5)
   where QUARTER = vYYYYQQ
     and ( Q_QA_GRADE is not null or Q_QB_GRADE is not null or Q_QC_GRADE is not null or Q_QD_GRADE is not null );
  commit;



-- Susan Amount share in site
  iTracePoint := '170';
  for REC1 in (
     select a.SITE, a.MATGROUP, a.QUARTER, sum(Q_AMOUNT) as SITE_Q_AMOUNT
       from VQA_SUM14_QQ_MATGP a
      where a.QUARTER = vYYYYQQ
      group by a.SITE, a.MATGROUP, a.QUARTER
  ) loop
     Update VQA_SUM14_QQ_MATGP
        set AMT_SHARE_SITE = round(Q_AMOUNT / REC1.SITE_Q_AMOUNT, 5) * 100
      where SITE = REC1.SITE
        and MATGROUP = REC1.MATGROUP
        and QUARTER = REC1.QUARTER;
     commit;
  end loop;


  iTracePoint := '200';  --刪除 VQA_SUM15_QQ_MF
  delete from VQA_SUM15_QQ_MF
   where QUARTER = vYYYYQQ;
  commit;

  iTracePoint := '210';
  insert into VQA_SUM15_QQ_MF  ( SITE, MANUF, QUARTER, BUKRS, Q_AMOUNT, FROM_DATE, TO_DATE, SITE_PER, AMT_SHARE_SITE, DATE_TIME,
           Q_QA_GRADE, Q_QB_GRADE, Q_QC_GRADE, Q_QD_GRADE, GV_PER )
    select a.SITE, a.MANUF, a.QUARTER, a.BUKRS, sum(b.AMOUNT) as Q_AMOUNT,
           a.FROM_DATE, a.TO_DATE, '', '',
           to_char(SYSDATE, 'yyyymmddhh24miss') as DATE_TIME,
           round(sum(b.AMOUNT * b.QA_GRADE) / sum(b.AMOUNT),5) as Q_QA_GRADE,
           round(sum(b.AMOUNT * b.QB_GRADE) / sum(b.AMOUNT),5) as Q_QB_GRADE,
           round(sum(b.AMOUNT * b.QC_GRADE) / sum(b.AMOUNT),5) as Q_QC_GRADE,
           round(sum(b.AMOUNT * b.QD_GRADE) / sum(b.AMOUNT),5) as Q_QD_GRADE,
           a.GV_PER
      from VQA_SUM05_AMT_MF_Q a, VQA_SUM12_MM_MF b
     where a.SITE = b.SITE           and a.MANUF = b.MANUF
       and a.QUARTER = b.QUARTER
       and a.BUKRS = b.BUKRS
       and a.QUARTER = vYYYYQQ
     group by a.SITE, a.MANUF, a.QUARTER, a.BUKRS, a.FROM_DATE, a.TO_DATE, a.SITE_PER, a.GV_PER;
  commit;

  iTracePoint := '220';
  for REC1 in (
     select * from VQA_SUM12_MM_MF where YYYY = vYYYY and MM = vMM1
  ) loop
     Update VQA_SUM15_QQ_MF
        set QA_10_GRADE = REC1.QA_GRADE,
            QB_10_GRADE = REC1.QB_GRADE,
            QC_10_GRADE = REC1.QC_GRADE,
            QD_10_GRADE = REC1.QD_GRADE,
            SUBTOT_10_Q = REC1.SUBTOT_Q
      where SITE = REC1.SITE
        and MANUF = REC1.MANUF
        and QUARTER = REC1.QUARTER;
     commit;
  end loop;

  iTracePoint := '230';
  for REC1 in (
     select * from VQA_SUM12_MM_MF where YYYY = vYYYY and MM = vMM2
  ) loop
     Update VQA_SUM15_QQ_MF
        set QA_11_GRADE = REC1.QA_GRADE,
            QB_11_GRADE = REC1.QB_GRADE,
            QC_11_GRADE = REC1.QC_GRADE,
            QD_11_GRADE = REC1.QD_GRADE,
            SUBTOT_11_Q = REC1.SUBTOT_Q
      where SITE = REC1.SITE
        and MANUF = REC1.MANUF
        and QUARTER = REC1.QUARTER;
     commit;
  end loop;

  iTracePoint := '240';
  for REC1 in (
     select * from VQA_SUM12_MM_MF where YYYY = vYYYY and MM = vMM3
  ) loop
     Update VQA_SUM15_QQ_MF
        set QA_12_GRADE = REC1.QA_GRADE,
            QB_12_GRADE = REC1.QB_GRADE,
            QC_12_GRADE = REC1.QC_GRADE,
            QD_12_GRADE = REC1.QD_GRADE,
            SUBTOT_12_Q = REC1.SUBTOT_Q
      where SITE = REC1.SITE
        and MANUF = REC1.MANUF
        and QUARTER = REC1.QUARTER;
     commit;
  end loop;

  iTracePoint := '251';
  Update VQA_SUM15_QQ_MF
     set SUBTOT_Q = round( (nvl(Q_QA_GRADE,0) * QA_VALUE) + (nvl(Q_QB_GRADE,0) * QB_VALUE) + (nvl(Q_QC_GRADE,0) * QC_VALUE) + (nvl(Q_QD_GRADE,0) * QD_VALUE), 5)
   where QUARTER = vYYYYQQ
     and ( Q_QA_GRADE is not null or Q_QB_GRADE is not null or Q_QC_GRADE is not null or Q_QD_GRADE is not null );
  commit;


--Susan adjust Amount share in site
  iTracePoint := '270';
  for REC1 in (
     select a.SITE, a.QUARTER, sum(Q_AMOUNT) as SITE_Q_AMOUNT
       from VQA_SUM15_QQ_MF a
      where a.QUARTER = vYYYYQQ
      group by a.SITE, a.QUARTER
  ) loop
     Update VQA_SUM15_QQ_MF
        set AMT_SHARE_SITE = round(Q_AMOUNT / REC1.SITE_Q_AMOUNT, 5) * 100
      where SITE = REC1.SITE
        and QUARTER = REC1.QUARTER;
     commit;
  end loop;


-- iTracePoint := '300';  --刪除 VRTN_SUM16_QQ_COMBINE
-- delete from VRTN_SUM16_QQ_COMBINE
--  where QUARTER = vYYYYQQ;
-- commit;
--
-- iTracePoint := '310';
-- insert into VRTN_SUM16_QQ_COMBINE ( SITE, VENDOR, MATGROUP, QUARTER, GV_VENDOR, BUKRS, Q_GRADE, Q_RANKING, Q_AMOUNT,
--              FROM_DATE, TO_DATE, DATE_TIME, SITE_PER, AMT_SHARE_SITE, QA_10_GRADE, QA_11_GRADE, QA_12_GRADE, Q_QA_GRADE,
--              QB_10_GRADE, QB_11_GRADE, QB_12_GRADE, Q_QB_GRADE, QC_10_GRADE, QC_11_GRADE, QC_12_GRADE, Q_QC_GRADE,
--              QD_10_GRADE, QD_11_GRADE, QD_12_GRADE, Q_QD_GRADE, SUBTOT_10_Q, SUBTOT_11_Q, SUBTOT_12_Q, SUBTOT_Q,
--              CA_10_GRADE, CA_11_GRADE, CA_12_GRADE, Q_CA_GRADE, CB_10_GRADE, CB_11_GRADE, CB_12_GRADE, Q_CB_GRADE,
--              CC_10_GRADE, CC_11_GRADE, CC_12_GRADE, CC_GRADE, CD_10_GRADE, CD_11_GRADE, CD_12_GRADE, Q_CD_GRADE,
--              SUBTOT_10_C, SUBTOT_11_C, SUBTOT_12_C, SUBTOT_C, D1_10_GRADE, D1_11_GRADE, D1_12_GRADE, Q_D1_GRADE,
--              D2_10_GRADE, D2_11_GRADE, D2_12_GRADE, Q_D2_GRADE, DE_10_GRADE, DE_11_GRADE, DE_12_GRADE, Q_DE_GRADE,
--              DF_10_GRADE, DF_11_GRADE, DF_12_GRADE, Q_DF_GRADE, DG_10_GRADE, DG_11_GRADE, DG_12_GRADE, Q_DG_GRADE,
--              DH_10_GRADE, DH_11_GRADE, DH_12_GRADE, Q_DH_GRADE, DI_10_GRADE, DI_11_GRADE, DI_12_GRADE, Q_DI_GRADE,
--              DJ_10_GRADE, DJ_11_GRADE, DJ_12_GRADE, Q_DJ_GRADE, TOT_10_CQD, TOT_11_CQD, TOT_12_CQD, SUBTOT_10_D3,
--              SUBTOT_11_D3, SUBTOT_12_D3, SUBTOT_D3, Q_SUBTOT_D3, TOT_10_D, TOT_11_D, TOT_12_D, SUBTOT_10_D, SUBTOT_11_D,
--              SUBTOT_12_D, SUBTOT_D, Q_SUBTOT_D, TOT_10_QCD, TOT_11_QCD, TOT_12_QCD, Q_10_SCORE, Q_11_SCORE, Q_12_SCORE,
--              MM_SCORE, Q_MM_SCORE, GV_PER )
--   select SITE, VENDOR, MATGROUP, QUARTER, GV_VENDOR, BUKRS, Q_GRADE, Q_RANKING, Q_AMOUNT,
--          FROM_DATE, TO_DATE, DATE_TIME, SITE_PER, AMT_SHARE_SITE, QA_10_GRADE, QA_11_GRADE, QA_12_GRADE, Q_QA_GRADE,
--          QB_10_GRADE, QB_11_GRADE, QB_12_GRADE, Q_QB_GRADE, QC_10_GRADE, QC_11_GRADE, QC_12_GRADE, Q_QC_GRADE,
--          QD_10_GRADE, QD_11_GRADE, QD_12_GRADE, Q_QD_GRADE, SUBTOT_10_Q, SUBTOT_11_Q, SUBTOT_12_Q, SUBTOT_Q,
--          CA_10_GRADE, CA_11_GRADE, CA_12_GRADE, Q_CA_GRADE, CB_10_GRADE, CB_11_GRADE, CB_12_GRADE, Q_CB_GRADE,
--          CC_10_GRADE, CC_11_GRADE, CC_12_GRADE, CC_GRADE, CD_10_GRADE, CD_11_GRADE, CD_12_GRADE, Q_CD_GRADE,
--          SUBTOT_10_C, SUBTOT_11_C, SUBTOT_12_C, SUBTOT_C, D1_10_GRADE, D1_11_GRADE, D1_12_GRADE, Q_D1_GRADE,
--          D2_10_GRADE, D2_11_GRADE, D2_12_GRADE, Q_D2_GRADE, DE_10_GRADE, DE_11_GRADE, DE_12_GRADE, Q_DE_GRADE,
--          DF_10_GRADE, DF_11_GRADE, DF_12_GRADE, Q_DF_GRADE, DG_10_GRADE, DG_11_GRADE, DG_12_GRADE, Q_DG_GRADE,
--          DH_10_GRADE, DH_11_GRADE, DH_12_GRADE, Q_DH_GRADE, DI_10_GRADE, DI_11_GRADE, DI_12_GRADE, Q_DI_GRADE,
--          DJ_10_GRADE, DJ_11_GRADE, DJ_12_GRADE, Q_DJ_GRADE, TOT_10_CQD, TOT_11_CQD, TOT_12_CQD, SUBTOT_10_D3,
--          SUBTOT_11_D3, SUBTOT_12_D3, SUBTOT_D3, Q_SUBTOT_D3, TOT_10_D, TOT_11_D, TOT_12_D, SUBTOT_10_D, SUBTOT_11_D,
--          SUBTOT_12_D, SUBTOT_D, Q_SUBTOT_D, TOT_10_QCD, TOT_11_QCD, TOT_12_QCD, Q_10_SCORE, Q_11_SCORE, Q_12_SCORE,
--          MM_SCORE, Q_MM_SCORE, GV_PER
--     from VRTN_SUM14_QQ_MATGP where QUARTER = vYYYYQQ
--   union all
--   select SITE, VENDOR, '000' as MATGROUP, QUARTER, GV_VENDOR, BUKRS, Q_GRADE, Q_RANKING, Q_AMOUNT,
--          FROM_DATE, TO_DATE, DATE_TIME, SITE_PER, AMT_SHARE_SITE, QA_10_GRADE, QA_11_GRADE, QA_12_GRADE, Q_QA_GRADE,
--          QB_10_GRADE, QB_11_GRADE, QB_12_GRADE, Q_QB_GRADE, QC_10_GRADE, QC_11_GRADE, QC_12_GRADE, Q_QC_GRADE,
--          QD_10_GRADE, QD_11_GRADE, QD_12_GRADE, Q_QD_GRADE, SUBTOT_10_Q, SUBTOT_11_Q, SUBTOT_12_Q, SUBTOT_Q,
--          CA_10_GRADE, CA_11_GRADE, CA_12_GRADE, Q_CA_GRADE, CB_10_GRADE, CB_11_GRADE, CB_12_GRADE, Q_CB_GRADE,
--          CC_10_GRADE, CC_11_GRADE, CC_12_GRADE, CC_GRADE, CD_10_GRADE, CD_11_GRADE, CD_12_GRADE, Q_CD_GRADE,
--          SUBTOT_10_C, SUBTOT_11_C, SUBTOT_12_C, SUBTOT_C, D1_10_GRADE, D1_11_GRADE, D1_12_GRADE, Q_D1_GRADE,
--          D2_10_GRADE, D2_11_GRADE, D2_12_GRADE, Q_D2_GRADE, DE_10_GRADE, DE_11_GRADE, DE_12_GRADE, Q_DE_GRADE,
--          DF_10_GRADE, DF_11_GRADE, DF_12_GRADE, Q_DF_GRADE, DG_10_GRADE, DG_11_GRADE, DG_12_GRADE, Q_DG_GRADE,
--          DH_10_GRADE, DH_11_GRADE, DH_12_GRADE, Q_DH_GRADE, DI_10_GRADE, DI_11_GRADE, DI_12_GRADE, Q_DI_GRADE,
--          DJ_10_GRADE, DJ_11_GRADE, DJ_12_GRADE, Q_DJ_GRADE, TOT_10_CQD, TOT_11_CQD, TOT_12_CQD, SUBTOT_10_D3,
--          SUBTOT_11_D3, SUBTOT_12_D3, SUBTOT_D3, Q_SUBTOT_D3, TOT_10_D, TOT_11_D, TOT_12_D, SUBTOT_10_D, SUBTOT_11_D,
--          SUBTOT_12_D, SUBTOT_D, Q_SUBTOT_D, TOT_10_QCD, TOT_11_QCD, TOT_12_QCD, Q_10_SCORE, Q_11_SCORE, Q_12_SCORE,
--          MM_SCORE, Q_MM_SCORE, GV_PER
--     from VRTN_SUM15_QQ_VM where QUARTER = vYYYYQQ;
-- commit;

EXCEPTION
  When OTHERS Then
    --有錯誤產生則寄mail
    cErrorText := SQLERRM();
    MAIL_FILE_BIDBDBADMIN(in_to_name => 'shuchin_lin@usiglobal.com', subject => '[VRTN] PL/SQL VQA_PLSQL_SUM6_LOC_QQ ERROR', message => '[VQA_PLSQL_SUM6_LOC_QQ], The tracepoint is  ' || iTracePoint || ' and ErrorText= ' || cErrorText) ;
END;
/

