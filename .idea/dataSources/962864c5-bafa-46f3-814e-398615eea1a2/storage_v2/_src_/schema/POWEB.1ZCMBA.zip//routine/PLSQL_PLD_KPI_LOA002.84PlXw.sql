create PROCEDURE       PLSQL_PLD_KPI_LOA002 (
	inCompany  in VARCHAR2,
	f_YYYYMMDD in VARCHAR2,
	t_YYYYMMDD in VARCHAR2
)
AUTHID DEFINER
is
	iTracePoint         varchar2(3);
	cErrorText          varchar2(500);
	t_COMPANY_CODE      varchar2(4);
	a_EX_RATE_USD       number(10,5);
	a_EX_RATE_TWD       number(10,5);
	b_EX_RATE_USD       number(10,5);
	b_EX_RATE_TWD       number(10,5);
BEGIN
	--(000) 清除 Period 錯誤者
	iTracePoint := '000';
	delete from PLD_KPI_LOA002_SAP_GR_T
		where COMPANY_CODE = inCompany
		and ( POST_DATE < f_YYYYMMDD or POST_DATE > t_YYYYMMDD );
	commit;


	--(010) check data
	iTracePoint := '010';
	t_COMPANY_CODE := null;
	begin
		select * into t_COMPANY_CODE from (
			select COMPANY_CODE from PLD_KPI_LOA002_SAP_GR_T
			where COMPANY_CODE = inCompany
			group by COMPANY_CODE, PO_NO, PO_ITEM, GR_YEAR,GR_DOC_NO, GR_DOC_ITEM
			having count(*) > 1
		) where rownum <= 1;
	exception
		when others then
			t_COMPANY_CODE := null;
	end;
	if t_COMPANY_CODE is null then

		--(020) 匯率 / Amount
		iTracePoint := '020';
		for REC1 in (
			select distinct substr(POST_DATE,1,6) as PERIOD, DOC_CURR from PLD_KPI_LOA002_SAP_GR_T
			where COMPANY_CODE = inCompany
		) loop
			--計算匯率
			a_EX_RATE_TWD := Null;
			a_EX_RATE_USD := Null;
			a_EX_RATE_USD := GET_EXCHANGE_RATE(SUBSTRB(REC1.PERIOD,1,4),SUBSTRB(REC1.PERIOD,5,2),REC1.DOC_CURR,'USD','T') ;
			a_EX_RATE_TWD := GET_EXCHANGE_RATE(SUBSTRB(REC1.PERIOD,1,4),SUBSTRB(REC1.PERIOD,5,2),REC1.DOC_CURR,'TWD','T') ;
			--開始處理amount
			Update PLD_KPI_LOA002_SAP_GR_T set
				YYYYMM    = REC1.PERIOD,
				USD_AMT   = Round(DOC_AMT * a_EX_RATE_USD, 5),
				TWD_AMT   = Round(DOC_AMT * a_EX_RATE_TWD, 5)
			Where COMPANY_CODE = inCompany
			and substr(POST_DATE,1,6) = REC1.PERIOD
			and DOC_CURR = REC1.DOC_CURR;
			Commit;
		end loop;


		----(030) 清舊的 PLD_KPI_LOA002_SAP_GR
		--iTracePoint := '030';
		--delete from PLD_KPI_LOA002_SAP_GR
		--	where COMPANY_CODE = inCompany
		--	and ( POST_DATE >= f_YYYYMMDD and POST_DATE <= t_YYYYMMDD );
		--commit;

		----(040) move data
		--iTracePoint := '040';
		--insert into PLD_KPI_LOA002_SAP_GR
		--	select * from PLD_KPI_LOA002_SAP_GR_T
		--	where COMPANY_CODE = inCompany
        --    and ( POST_DATE >= f_YYYYMMDD and POST_DATE <= t_YYYYMMDD );
        --commit;

        for rec1 in (
            select (substr(min(POST_DATE),1,6) || '01') as MIN_DATE
            from PLD_KPI_LOA002_SAP_GR_T where COMPANY_CODE = inCompany
        ) loop
            --(030) 清舊的 PLD_KPI_LOA002_SAP_GR
            iTracePoint := '030';
            delete from PLD_KPI_LOA002_SAP_GR
                where COMPANY_CODE = inCompany
                and ( POST_DATE >= rec1.MIN_DATE and POST_DATE <= t_YYYYMMDD );
            commit;

            --(040) move data
            iTracePoint := '040';
            insert into PLD_KPI_LOA002_SAP_GR
                select * from PLD_KPI_LOA002_SAP_GR_T
                where COMPANY_CODE = inCompany
                and ( POST_DATE >= rec1.MIN_DATE and POST_DATE <= t_YYYYMMDD );
            commit;
        end loop;
    else
        MAIL_FILE_BIDBDBADMIN(in_to_name=>'minhorng_su@usiglobal.com',subject   => '[PLD KPI]PL/SQL PLSQL_PLD_KPI_LOA002 ERROR - Company: ' || inCompany, message => '[PLSQL_PLD_KPI_LOA002], DATA duplicate in PLD_KPI_LOA002_SAP_GR_T') ;
    end if;
EXCEPTION
    WHEN OTHERS THEN
        cErrorText := SQLERRM();
        rollback;
        MAIL_FILE_BIDBDBADMIN(in_to_name=>'minhorng_su@usiglobal.com',subject   => '[PLD KPI]PL/SQL PLSQL_PLD_KPI_LOA002 ERROR - Company: ' || inCompany, message => '[PLSQL_PLD_KPI_LOA002], The tracepoint is  ' || iTracePoint || ' and ErrorText=' || cErrorText) ;
END PLSQL_PLD_KPI_LOA002;
/

