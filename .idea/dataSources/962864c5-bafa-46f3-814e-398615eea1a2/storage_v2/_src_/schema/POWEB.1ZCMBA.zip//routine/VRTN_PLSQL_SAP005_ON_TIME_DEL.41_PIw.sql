create PROCEDURE         "VRTN_PLSQL_SAP005_ON_TIME_DEL" (
  inCompany  in VARCHAR2,
  f_YYYYMMDD in VARCHAR2,
  t_YYYYMMDD in VARCHAR2
)
AUTHID DEFINER
IS
  /*
    每月一號執行一次 
    1. 將資料從 VRTN_SAP005_ON_TIME_DELIVERY_T 搬到 VRTN_SAP005_ON_TIME_DELIVERY
    2. 從 ORRPRD.VRTN_VEW002_ORR_LIST 和 VRTN_SAP005_ON_TIME_DELIVERY 寫值到 VRTN_ZOT002_DELIVERY_COMPLIANC (DC)
    2.a 抓 VRTN_ZOT004_COMPLIANCE_WEEK 到 VRTN_ZOT002_DELIVERY_COMPLIANC (DD)
    3. 抓 VRTN_MAP020_RATE_INDEX - 各階層的分數比率 (D2)
    4. 抓 VRTN_ZOT002_DELIVERY_COMPLIANC 資料 (指標2: Compliance & Flexibility)
    5. 將計算後值放到 VRTN_MAP030_SUMMARY_GRAD
    (VRTN_MAP030_SUMMARY_GRAD-L1,L2,L3,L4 參考文件 VRTN_MAP060_LEVEL_DESC)
    2012/08/29 Susan add 4100
    2016/07/19 remark org. - re-run X
  */

  vPROCEE_YYYYMM             varchar2(6);
  vPERCENTAGE_L1             VRTN_MAP020_RATE_INDEX.PERCENTAGE%TYPE;
  vPERCENTAGE_L2             VRTN_MAP020_RATE_INDEX.PERCENTAGE%TYPE;
  vPERCENTAGE_L3             VRTN_MAP020_RATE_INDEX.PERCENTAGE%TYPE;

  iTracePoint                varchar2(100);
  cErrorText                 varchar2(500);

BEGIN

    iTracePoint := '100';
--20100917 20160719
--   vPROCEE_YYYYMM := substr(f_YYYYMMDD, 1, 6);
--抓上個月資料
     vPROCEE_YYYYMM := TO_CHAR(ADD_MONTHS(SYSDATE, -1), 'YYYYMM');
--


  --處理 VRTN_SAP005_ON_TIME_DELIVERY
  iTracePoint := '100';
  delete from VRTN_SAP005_ON_TIME_DELIVERY
   where YYYY = substr(f_YYYYMMDD, 1, 4)
     and MM = substr(f_YYYYMMDD, 5, 2)
     and COMPANY_CODE = inCompany;
  commit;
  iTracePoint := '110';
  insert into VRTN_SAP005_ON_TIME_DELIVERY
     select * from VRTN_SAP005_ON_TIME_DELIVERY_T
      where COMPANY_CODE = inCompany;
  commit;

  --處理 VRTN_ZOT002_DELIVERY_COMPLIANC
  iTracePoint := '200';
  delete from VRTN_ZOT002_DELIVERY_COMPLIANC
   where P_YEAR = substr(f_YYYYMMDD, 1, 4)
     and P_MONTH = substr(f_YYYYMMDD, 5, 2)
     and COMPANY_CODE = inCompany;
  commit;

  --先抓 ORR 的放到 VRTN_ZOT002_DELIVERY_COMPLIANC
  iTracePoint := '210';
  insert into VRTN_ZOT002_DELIVERY_COMPLIANC (
         P_YEAR, P_MONTH, P_QUARTER, COMPANY_CODE, SITE, VENDOR_CODE, MATGROUP, PTYPE, SCORES, TOTAL_CNT, COMPLIANCE_CNT )
     select YYYY, MM, QUARTER, COMPANY_CODE, SITE, VENDOR_CODE, MTL_GROUP, 'DC',
            round(sum(NOSEND_CNT + COM_CNT) / sum(TOT_CNT) * 100,5) as SCORES,
            sum(TOT_CNT) as TOTAL_CNT, sum(NOSEND_CNT + COM_CNT) as COMPLIANCE_CNT from (
        select b.YYYY, b.MM, b.QUARTER, a.COMPANY_CODE, a.SITE, c.MTL_GROUP,
               a.VENDOR_CODE, 1 as TOT_CNT, decode(a.MC_VERSION_1,null,1,0) as NOSEND_CNT,
               decode(a.VDR_VERSION,null,0,decode(trim(to_char(a.RES_QTY) || a.RES_DATE),trim(to_char(a.VDR_QTY_1) || a.VDR_DATE_1),1,0)) as COM_CNT
          from VRT_VEW002_ORR_LIST_V2@msqlorrprd a, DIMENSION_DATE b, PLD_KPI_PN_MTLGRP_SUBGRP c
         where to_char(a.CREATE_DATE,'YYYYMMDD') = b.DATE_KEY
           and b.YYYY = substr(f_YYYYMMDD, 1, 4)
           and b.MM = substr(f_YYYYMMDD, 5, 2)
           and a.COMPANY_CODE = inCompany
           and rtrim(a.PART_NO) = c.PART_NO
     ) group by YYYY, MM, QUARTER, COMPANY_CODE, SITE, VENDOR_CODE, MTL_GROUP;
  commit;

  --抓 VMI / Sch. 的放到 VRTN_ZOT002_DELIVERY_COMPLIANC (DD)
  iTracePoint := '215';
  insert into VRTN_ZOT002_DELIVERY_COMPLIANC (
         P_YEAR, P_MONTH, P_QUARTER, COMPANY_CODE, SITE, VENDOR_CODE, MATGROUP, PTYPE, SCORES, TOTAL_CNT, COMPLIANCE_CNT )
     select P_YEAR, P_MONTH, P_QUARTER, COMPANY_CODE, SITE, VENDOR_CODE, MATGROUP, PTYPE, (sum(SCORES) / sum(CNT)) as SCORES,
            null as TOTAL_CNT, null as COMPLIANCE_CNT from (
        select a.P_YEAR, a.P_MONTH, b.QUARTER as P_QUARTER,
               a.COMPANY_CODE, a.SITE, a.VENDOR_CODE, a.MATGROUP, a.PTYPE, a.SCORES, 1 as CNT
          from VRTN_ZOT004_COMPLIANCE_WEEK a, DIMENSION_DATE b
         where a.P_YEAR = substr(f_YYYYMMDD, 1, 4)
           and a.P_MONTH = substr(f_YYYYMMDD, 5, 2)
           and a.COMPANY_CODE = inCompany
           and b.DATE_KEY = f_YYYYMMDD
     ) group by P_YEAR, P_MONTH, P_QUARTER, COMPANY_CODE, SITE, VENDOR_CODE, MATGROUP, PTYPE;
  commit;

  --抓各階分數
  iTracePoint := '300';
  vPERCENTAGE_L1 := null;
  vPERCENTAGE_L2 := null;
  vPERCENTAGE_L3 := null;

  for REC1 in ( select LEVEL_S, PERCENTAGE from VRTN_MAP020_RATE_INDEX
                 where INDEX_KEY = 'DELIVERY' and TYPE = 'D2' ) loop
    if REC1.LEVEL_S = 'L1' then
      iTracePoint := '310';
      vPERCENTAGE_L1 := REC1.PERCENTAGE;
    elsif REC1.LEVEL_S = 'L2' then
      iTracePoint := '320';
      vPERCENTAGE_L2 := REC1.PERCENTAGE;
    elsif REC1.LEVEL_S = 'L3' then
      iTracePoint := '330';
      vPERCENTAGE_L3 := REC1.PERCENTAGE;
    end if;
  end loop;

  if vPERCENTAGE_L1 is null or vPERCENTAGE_L2 is null or vPERCENTAGE_L3 is null then
    --若沒抓到資料則寄 error mail
    iTracePoint := '350';
    cErrorText := 'vPERCENTAGE_L1 is ' || nvl(to_char(vPERCENTAGE_L1),'null') || ',vPERCENTAGE_L2 is ' || nvl(to_char(vPERCENTAGE_L2),'null') || ',vPERCENTAGE_L3 is ' || nvl(to_char(vPERCENTAGE_L3),'null');
    MAIL_FILE_BIDBDBADMIN(in_to_name => 'shuchin@ms.usi.com.tw', subject => '[VRTN] PL/SQL VRTN_PLSQL_SAP005_ON_TIME_DEL ERROR', message => '[VRTN_PLSQL_SAP005_ON_TIME_DEL], The tracepoint is  ' || iTracePoint || ' and ErrorText= ' || cErrorText) ;
  else
    --先清舊的資料以避免重覆
    iTracePoint := '380-' || vPROCEE_YYYYMM;
    delete from VRTN_MAP030_SUMMARY_GRAD where TYPE = 'D2' and BUKRS = inCompany
       and YYYY = substr(vPROCEE_YYYYMM,1,4) and MM = substr(vPROCEE_YYYYMM,5,2);
    commit;

    --放入上月分數
    iTracePoint := '400';
    for REC1 in ( select SITE, VENDOR_CODE, MATGROUP, P_YEAR, P_MONTH, P_QUARTER, COMPANY_CODE, round(sum(SCORES) / sum(CNT), 5) as SCORE
                    from ( select SITE, VENDOR_CODE, MATGROUP, P_YEAR, P_MONTH, P_QUARTER, COMPANY_CODE, SCORES, 1 as CNT
                             from VRTN_ZOT002_DELIVERY_COMPLIANC
                            where P_YEAR = substr(vPROCEE_YYYYMM,1,4)
                              and P_MONTH = substr(vPROCEE_YYYYMM,5,2)
                              and COMPANY_CODE = inCompany )
                   group by SITE, VENDOR_CODE, MATGROUP, P_YEAR, P_MONTH, P_QUARTER, COMPANY_CODE ) loop
      --放到 VRTN_MAP030_SUMMARY_GRAD
      iTracePoint := '400-' || REC1.SITE || '-' || REC1.VENDOR_CODE || '-' || vPROCEE_YYYYMM;
      insert into VRTN_MAP030_SUMMARY_GRAD (
             SITE, LIFNR, MATGROUP, TYPE, YYYY, MM, QUARTER, BUKRS, L1, GRADE_L1, L2, GRADE_L2, L3, GRADE_L3, L4, GRADE_L4
           ) values (
             REC1.SITE,
             REC1.VENDOR_CODE,
             REC1.MATGROUP,
             'D2',
             REC1.P_YEAR,
             REC1.P_MONTH,
             REC1.P_QUARTER,
             REC1.COMPANY_CODE,
             'S0',
             round(REC1.SCORE * vPERCENTAGE_L1, 5),
             'D0',
             round(REC1.SCORE * vPERCENTAGE_L2, 5),
             'D2',
             round(REC1.SCORE * vPERCENTAGE_L3, 5),
             null,
             null
           );
      commit;
    end loop;
  end if;

  if inCompany = '1100' then
    VRTN_PLSQL_ORR_REPLY_RATE;
  end if;


  --Add by susan 2007/05/01
  if inCompany = '1100' then
     VRTN_PLSQL_ZOT005_WH_DIF;
  end if;

  --Add by susan 2007/05/01
  if inCompany = '1100' then
     VRTN_PLSQL_SAP002_4A5_REPLY;
  end if;

  --Add by susan 2007/05/01
  if inCompany = '1100' then
     VRTN_PLSQL_PAYMENT_TERM;
  end if;




EXCEPTION
  When OTHERS Then
    --有錯誤產生則寄mail
    cErrorText := SQLERRM();
    MAIL_FILE_BIDBDBADMIN(in_to_name => 'shuchin_lin@usiglobal.com', subject => '[VRTN] PL/SQL VRTN_PLSQL_SAP005_ON_TIME_DEL ERROR', message => '[VRTN_PLSQL_SAP005_ON_TIME_DEL], The tracepoint is  ' || iTracePoint || ' and ErrorText= ' || cErrorText || ' and Company= ' || inCompany) ;
END;
/

