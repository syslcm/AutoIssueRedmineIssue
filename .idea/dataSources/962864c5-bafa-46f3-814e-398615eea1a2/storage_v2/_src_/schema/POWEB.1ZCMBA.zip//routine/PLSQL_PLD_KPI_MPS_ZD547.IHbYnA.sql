create PROCEDURE       PLSQL_PLD_KPI_MPS_ZD547
(
	inCompany  in VARCHAR2,
	f_YYYYMMDD in VARCHAR2,
	t_YYYYMMDD in VARCHAR2
)
AUTHID DEFINER
is
	/*
	KPI function 會每次清空不做備份
	處理 PLD_KPI_MPS_FG_RAW_ZD547 資料 (SAP ZD547)
	*/
	iTracePoint           varchar2(3);
	cErrorText            varchar2(500);
	t_MAX_LT_DAY          PLD_KPI_MPS_FG_SUM.MAX_LT_DAY%TYPE;
	t_LT_GT_MPS_CNT       PLD_KPI_MPS_FG_SUM.LT_GT_MPS_CNT%TYPE;
	t_MAX_CW_DAY          PLD_KPI_MPS_FG_SUM.MAX_CW_DAY%TYPE;
	t_NC_CNT              PLD_KPI_MPS_FG_SUM.NC_CNT%TYPE;
BEGIN
	--(000) 清除 create_date 錯誤者
	iTracePoint := '000';
	delete from PLD_KPI_MPS_FG_RAW_ZD547
		where COMPANY_CODE = inCompany
		and CREATE_DATE <> t_YYYYMMDD;
	commit;

	--(010) PC_TEXT
	iTracePoint := '010';
	for rec1 in (
		select PROFIT_CENTER, PC_DESC from KPI_MAP002_BG_MAP
		where COMPANY_CODE = inCompany
		and START_DATE <= sysdate and END_DATE >= sysdate
		group by PROFIT_CENTER, PC_DESC
	) loop
		update PLD_KPI_MPS_FG_RAW_ZD547 set PC_TEXT = rec1.PC_DESC
		where COMPANY_CODE = inCompany
		and PC_CODE = rec1.PROFIT_CENTER;
		commit;
	end loop;

	--(030) RAW data - client
	iTracePoint := '030';
	for rec1 in (
		select a.PART_NO, a.CW, a.RW from SAP_MATERIAL_CLIENT a
		where a.COMPANY_CODE = inCompany
		and exists (
			select b.COMPANY_CODE from PLD_KPI_MPS_FG_RAW_ZD547 b
			where b.COMPANY_CODE = inCompany
			and b.RAW_PN = a.PART_NO
		) group by a.PART_NO, a.CW, a.RW
	) loop
		update PLD_KPI_MPS_FG_RAW_ZD547 set
			RAW_CW = trim(rec1.CW), RAW_RW = trim(rec1.RW)
		where COMPANY_CODE = inCompany
		and RAW_PN = rec1.PART_NO;
		commit;
	end loop;

	--(050) RAW data - plant
	iTracePoint := '050';
	for rec1 in (
		select a.PART_NO, a.PLANT, a.LT, a.SUBGRP, ceil(a.LT / 7) as LT_WK
		from SAP_MATERIAL_PLANT a
		where a.COMPANY_CODE = inCompany
		and exists (
			select b.COMPANY_CODE from PLD_KPI_MPS_FG_RAW_ZD547 b
			where b.COMPANY_CODE = inCompany
			and b.RAW_PN = a.PART_NO
			and b.RAW_PLANT = a.PLANT
		) group by a.PART_NO, a.PLANT, a.LT, a.SUBGRP
	) loop
		update PLD_KPI_MPS_FG_RAW_ZD547 set
			RAW_LT = rec1.LT, SMTLGRP = rec1.SUBGRP, RAW_LT_WEEK = rec1.LT_WK
		where COMPANY_CODE = inCompany
		and RAW_PN = rec1.PART_NO
		and RAW_PLANT = rec1.PLANT;
		commit;
	end loop;

	--(070) CUSTOMER_NAME
	iTracePoint := '070';
	for rec1 in (
		select trim(a.FG_MATERIAL_NO) as FG_MATERIAL_NO1,
			trim(a.END_CUSTOMER_NAME) as END_CUSTOMER_NAME1
		from CEP_MAP009_PARTNO_CUSTOMER a
		where exists (
			select b.COMPANY_CODE from PLD_KPI_MPS_FG_RAW_ZD547 b
			where b.COMPANY_CODE = inCompany
			and b.FG = trim(a.FG_MATERIAL_NO) )
		and a.END_CUSTOMER_NAME is not null
		group by a.FG_MATERIAL_NO, a.END_CUSTOMER_NAME
	) loop
		update PLD_KPI_MPS_FG_RAW_ZD547 set
			CUSTOMER_NAME = rec1.END_CUSTOMER_NAME1
		where COMPANY_CODE = inCompany
		and FG = rec1.FG_MATERIAL_NO1;
		commit;
	end loop;

	--(090) PROJECT_NAME
	iTracePoint := '090';
	for rec1 in (
		select trim(a.FG_MATERIAL_NO) as FG_MATERIAL_NO1,
			trim(a.SAP_PROJECT_NAME) as SAP_PROJECT_NAME1
		from CEP_MAP010_PARTNO_PROJECT a
		where exists (
			select b.COMPANY_CODE from PLD_KPI_MPS_FG_RAW_ZD547 b
			where b.COMPANY_CODE = inCompany
			and b.FG = trim(a.FG_MATERIAL_NO) )
		and a.SAP_PROJECT_NAME is not null
		group by a.FG_MATERIAL_NO, a.SAP_PROJECT_NAME
	) loop
		update PLD_KPI_MPS_FG_RAW_ZD547 set
			PROJECT_NAME = rec1.SAP_PROJECT_NAME1
		where COMPANY_CODE = inCompany
		and FG = rec1.FG_MATERIAL_NO1;
		commit;
	end loop;

	--(100) 清除舊的 PLD_KPI_MPS_FG_SUM
	iTracePoint := '100';
	delete from PLD_KPI_MPS_FG_SUM
		where COMPANY_CODE = inCompany;
	commit;

	--(120) insert PLD_KPI_MPS_FG_SUM
	iTracePoint := '120';
	insert into PLD_KPI_MPS_FG_SUM (
        COMPANY_CODE, FG, FG_PLANT, FG_VSF_DATE, FG_VSF_WEEK,
        PC_CODE, PC_TEXT, CUSTOMER_NAME, PROJECT_NAME )
    select COMPANY_CODE, FG, FG_PLANT, FG_VSF_DATE, FG_VSF_WEEK,
        PC_CODE, PC_TEXT, CUSTOMER_NAME, PROJECT_NAME
    from PLD_KPI_MPS_FG_RAW_ZD547
    where COMPANY_CODE = inCompany
    group by COMPANY_CODE, FG, FG_PLANT, FG_VSF_DATE, FG_VSF_WEEK,
        PC_CODE, PC_TEXT, CUSTOMER_NAME, PROJECT_NAME;
    commit;

    --(150) update PLD_KPI_MPS_FG_SUM
    iTracePoint := '150';
    for rec1 in (
        select COMPANY_CODE, FG, FG_PLANT from PLD_KPI_MPS_FG_SUM
        where COMPANY_CODE = inCompany
        group by COMPANY_CODE, FG, FG_PLANT
    ) loop
        t_MAX_LT_DAY := 0;
        t_LT_GT_MPS_CNT := 0;
        t_MAX_CW_DAY := 0;
        t_NC_CNT := 0;
        -- (151) t_MAX_LT_DAY
        iTracePoint := '151';
        begin
            select * into t_MAX_LT_DAY from (
                select max(RAW_LT)
                from PLD_KPI_MPS_FG_RAW_ZD547
                where COMPANY_CODE = rec1.COMPANY_CODE
                and FG = rec1.FG
                and FG_PLANT = rec1.FG_PLANT
            ) where rownum <= 1;
        exception
        when others then
            t_MAX_LT_DAY := 0;
        end;
        -- (153) t_LT_GT_MPS_CNT
        iTracePoint := '153';
        begin
            select * into t_LT_GT_MPS_CNT from (
                select count(*)
                from PLD_KPI_MPS_FG_RAW_ZD547
                where COMPANY_CODE = rec1.COMPANY_CODE
                and FG = rec1.FG
                and FG_PLANT = rec1.FG_PLANT
                and FG_VSF_WEEK < RAW_LT_WEEK
            ) where rownum <= 1;
        exception
        when others then
            t_LT_GT_MPS_CNT := 0;
        end;
        -- (155) t_MAX_CW_DAY
        iTracePoint := '155';
        begin
            select * into t_MAX_CW_DAY from (
                select max(ceil(to_number(RAW_CW) / 7))
                from PLD_KPI_MPS_FG_RAW_ZD547
                where COMPANY_CODE = rec1.COMPANY_CODE
                and FG = rec1.FG
                and FG_PLANT = rec1.FG_PLANT
                and upper(RAW_CW) not like '%N%'
                and RAW_CW is not null
            ) where rownum <= 1;
        exception
        when others then
            t_MAX_CW_DAY := 0;
        end;
        -- (157) t_NC_CNT
        iTracePoint := '153';
        begin
            select * into t_NC_CNT from (
                select count(*)
                from PLD_KPI_MPS_FG_RAW_ZD547
                where COMPANY_CODE = rec1.COMPANY_CODE
                and FG = rec1.FG
                and FG_PLANT = rec1.FG_PLANT
                and upper(RAW_CW) like '%N%'
            ) where rownum <= 1;
        exception
        when others then
            t_NC_CNT := 0;
        end;
        --(159) update PLD_KPI_MPS_FG_SUM
        update PLD_KPI_MPS_FG_SUM set
            MAX_LT_DAY = t_MAX_LT_DAY,
            LT_GT_MPS_CNT = t_LT_GT_MPS_CNT,
            MAX_CW_DAY = t_MAX_CW_DAY,
            NC_CNT = t_NC_CNT
        where COMPANY_CODE = rec1.COMPANY_CODE
        and FG = rec1.FG
        and FG_PLANT = rec1.FG_PLANT;
        commit;
    end loop;
EXCEPTION
    WHEN OTHERS THEN
        cErrorText := SQLERRM();
        MAIL_FILE_BIDBDBADMIN(in_to_name=>'minhorng_su@usiglobal.com',subject   => '[PLD KPI]PL/SQL PLSQL_PLD_KPI_MPS_ZD547 ERROR - Company: ' || inCompany, message => '[PLSQL_PLD_KPI_MPS_ZD547], The tracepoint is  ' || iTracePoint || ' and ErrorText=' || cErrorText) ;
END PLSQL_PLD_KPI_MPS_ZD547;
/

