create PROCEDURE PLSQL_DCF_USI_RFQ_2 (
  outRES OUT VARCHAR2
)
AUTHID DEFINER
is
  CURSOR C_RFQ_QTA_ARR_PREV is
    Select A.COMPANY_CODE, A.PART_NO, A.VENDOR_ID, A.QUOTA, A.MPN_PART_NO
     From RFQ_QTA_ARR_PREV A
    where A.QUOTA is NOT NULL
    group by A.COMPANY_CODE, A.PART_NO, A.VENDOR_ID, A.QUOTA, A.MPN_PART_NO
    Order BY A.QUOTA;

  CURSOR C_RFQ_QTA_ARR_CURR is
    Select A.COMPANY_CODE, A.PART_NO, A.VENDOR_ID, A.QUOTA, A.MPN_PART_NO
     From RFQ_QTA_ARR_CURR A
    where A.QUOTA is NOT NULL
    group by A.COMPANY_CODE, A.PART_NO, A.VENDOR_ID, A.QUOTA, A.MPN_PART_NO
    Order BY A.QUOTA;

   nPART_NO       RFQ_PRICE.PART_NO%TYPE;
   nUSI_PN        DCF_USI_RFQ.USI_PN%TYPE;
   nCOUNT         NUMBER(5);
 BEGIN
   outRES := 'START';

   nCOUNT := 0;
   FOR REC1 in C_RFQ_QTA_ARR_PREV LOOP
     If REC1.MPN_PART_NO is Null or REC1.MPN_PART_NO = '' Then
       nPART_NO := REC1.PART_NO;
     Else
       nPART_NO := REC1.MPN_PART_NO;
     End If;
     --Check exist or not
     nUSI_PN := Null;
     BEGIN
       Select * into nUSI_PN From (
         Select USI_PN from DCF_USI_RFQ
          where USI_PN = nPART_NO
            and USI_VENDOR_NO = REC1.VENDOR_ID
       ) Where ROWNUM <= 1;
     EXCEPTION
       WHEN OTHERS THEN
         nUSI_PN := Null;
     END;
     If nUSI_PN is NULL Then
       outRES := 'Prev-Ins:' || REC1.COMPANY_CODE || '<>' || nPART_NO || '<>' || REC1.VENDOR_ID;
       If REC1.COMPANY_CODE = '1100' Then
         Insert into DCF_USI_RFQ (USI_PN,USI_VENDOR_NO,QUOTA_TW) values (nPART_NO,REC1.VENDOR_ID,REC1.QUOTA);
       ElsIf REC1.COMPANY_CODE = '1200' Then
         Insert into DCF_USI_RFQ (USI_PN,USI_VENDOR_NO,QUOTA_SZ) values (nPART_NO,REC1.VENDOR_ID,REC1.QUOTA);
       ElsIf REC1.COMPANY_CODE = '1300' Then
         Insert into DCF_USI_RFQ (USI_PN,USI_VENDOR_NO,QUOTA_JP) values (nPART_NO,REC1.VENDOR_ID,REC1.QUOTA);
       ElsIf REC1.COMPANY_CODE = '1500' Then
         Insert into DCF_USI_RFQ (USI_PN,USI_VENDOR_NO,QUOTA_SH) values (nPART_NO,REC1.VENDOR_ID,REC1.QUOTA);
       ElsIf REC1.COMPANY_CODE = '2300' Then
         Insert into DCF_USI_RFQ (USI_PN,USI_VENDOR_NO,QUOTA_MX) values (nPART_NO,REC1.VENDOR_ID,REC1.QUOTA);
       End If;
     Else
       outRES := 'Prev-Upd:' || REC1.COMPANY_CODE || '<>' || nPART_NO || '<>' || REC1.VENDOR_ID;
       If REC1.COMPANY_CODE = '1100' Then
         Update DCF_USI_RFQ set QUOTA_TW = REC1.QUOTA where USI_PN = nPART_NO and USI_VENDOR_NO = REC1.VENDOR_ID;
       ElsIf REC1.COMPANY_CODE = '1200' Then
         Update DCF_USI_RFQ set QUOTA_SZ = REC1.QUOTA where USI_PN = nPART_NO and USI_VENDOR_NO = REC1.VENDOR_ID;
       ElsIf REC1.COMPANY_CODE = '1300' Then
         Update DCF_USI_RFQ set QUOTA_JP = REC1.QUOTA where USI_PN = nPART_NO and USI_VENDOR_NO = REC1.VENDOR_ID;
       ElsIf REC1.COMPANY_CODE = '1500' Then
         Update DCF_USI_RFQ set QUOTA_SH = REC1.QUOTA where USI_PN = nPART_NO and USI_VENDOR_NO = REC1.VENDOR_ID;
       ElsIf REC1.COMPANY_CODE = '2300' Then
         Update DCF_USI_RFQ set QUOTA_MX = REC1.QUOTA where USI_PN = nPART_NO and USI_VENDOR_NO = REC1.VENDOR_ID;
       End If;
     End If;
     nCOUNT := nCOUNT + 1;
     If nCOUNT = 10 Then
       Commit;
       nCOUNT := 0;
     End If;
   END LOOP;
   Commit;

   nCOUNT := 0;
   FOR REC1 in C_RFQ_QTA_ARR_CURR LOOP
     If REC1.MPN_PART_NO is Null or REC1.MPN_PART_NO = '' Then
       nPART_NO := REC1.PART_NO;
     Else
       nPART_NO := REC1.MPN_PART_NO;
     End If;
     --Check exist or not
     nUSI_PN := Null;
     BEGIN
       Select * into nUSI_PN From (
         Select USI_PN from DCF_USI_RFQ
          where USI_PN = nPART_NO
            and USI_VENDOR_NO = REC1.VENDOR_ID
       ) Where ROWNUM <= 1;
     EXCEPTION
       WHEN OTHERS THEN
         nUSI_PN := Null;
     END;
     If nUSI_PN is NULL Then
       outRES := 'Curr-Ins:' || REC1.COMPANY_CODE || '<>' || nPART_NO || '<>' || REC1.VENDOR_ID;
       If REC1.COMPANY_CODE = '1100' Then
         Insert into DCF_USI_RFQ (USI_PN,USI_VENDOR_NO,QUOTA_TW) values (nPART_NO,REC1.VENDOR_ID,REC1.QUOTA);
       ElsIf REC1.COMPANY_CODE = '1200' Then
         Insert into DCF_USI_RFQ (USI_PN,USI_VENDOR_NO,QUOTA_SZ) values (nPART_NO,REC1.VENDOR_ID,REC1.QUOTA);
       ElsIf REC1.COMPANY_CODE = '1300' Then
         Insert into DCF_USI_RFQ (USI_PN,USI_VENDOR_NO,QUOTA_JP) values (nPART_NO,REC1.VENDOR_ID,REC1.QUOTA);
       ElsIf REC1.COMPANY_CODE = '1500' Then
         Insert into DCF_USI_RFQ (USI_PN,USI_VENDOR_NO,QUOTA_SH) values (nPART_NO,REC1.VENDOR_ID,REC1.QUOTA);
       ElsIf REC1.COMPANY_CODE = '2300' Then
         Insert into DCF_USI_RFQ (USI_PN,USI_VENDOR_NO,QUOTA_MX) values (nPART_NO,REC1.VENDOR_ID,REC1.QUOTA);
       End If;
     Else
       outRES := 'Curr-Upd:' || REC1.COMPANY_CODE || '<>' || nPART_NO || '<>' || REC1.VENDOR_ID;
       If REC1.COMPANY_CODE = '1100' Then
         Update DCF_USI_RFQ set QUOTA_TW = REC1.QUOTA where USI_PN = nPART_NO and USI_VENDOR_NO = REC1.VENDOR_ID;
       ElsIf REC1.COMPANY_CODE = '1200' Then
         Update DCF_USI_RFQ set QUOTA_SZ = REC1.QUOTA where USI_PN = nPART_NO and USI_VENDOR_NO = REC1.VENDOR_ID;
       ElsIf REC1.COMPANY_CODE = '1300' Then
         Update DCF_USI_RFQ set QUOTA_JP = REC1.QUOTA where USI_PN = nPART_NO and USI_VENDOR_NO = REC1.VENDOR_ID;
       ElsIf REC1.COMPANY_CODE = '1500' Then
         Update DCF_USI_RFQ set QUOTA_SH = REC1.QUOTA where USI_PN = nPART_NO and USI_VENDOR_NO = REC1.VENDOR_ID;
       ElsIf REC1.COMPANY_CODE = '2300' Then
         Update DCF_USI_RFQ set QUOTA_MX = REC1.QUOTA where USI_PN = nPART_NO and USI_VENDOR_NO = REC1.VENDOR_ID;
       End If;
     End If;
     nCOUNT := nCOUNT + 1;
     If nCOUNT = 10 Then
       Commit;
       nCOUNT := 0;
     End If;
   END LOOP;
   Commit;
   outRES := 'SUCCESS';
 EXCEPTION
   WHEN OTHERS THEN
     outRES := TRIM(outRES) || ' - ' || TRIM(SUBSTR(SQLERRM,1,100));
     Rollback;
 END PLSQL_DCF_USI_RFQ_2;
/

