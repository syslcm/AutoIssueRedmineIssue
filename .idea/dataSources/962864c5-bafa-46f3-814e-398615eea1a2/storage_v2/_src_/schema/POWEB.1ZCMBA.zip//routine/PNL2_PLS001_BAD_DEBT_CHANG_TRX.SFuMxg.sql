create PROCEDURE pnl2_pls001_bad_debt_chang_trx (
   incompany   IN   VARCHAR2,
   t_period    IN   VARCHAR2
--由pnl3_pls005_category_gen_trx 呼叫
--2008/9/17 Create to Process get Amount in Local/USD/TWD
--Trigger by PNL2_BAD_DEPT_UPLOAD.JSP
--2009/1/19 用customer id去對到PNL3_TRX001_COPA 的CUSTOMER ID來抓END CUSTOMER,(KYE:PC+SITE+CUSTOMER_ID)
--但會發生台灣BILLING後來在大陸發生呆帳的狀況
--註:材料轉售排除
--2009/2/11 發現2009/1/19的修改有bug,萬一copa的資料沒有進到PNL3_TRX001_COPA,則END_CUSTOMER_ID就全部變成OTHERS,因此
--要在PNL3_PLS005_CATEGORY_GEN_TRX再加入2009/1/19的邏輯
--2009/3/10 COMPANY CODE:1101歸給ABIT M/B
--2009/11/18 BILL_TO_PARTY = 480006歸到OTHERS去,因為是一次性客戶
--2010/09/23 wenrong BILL_TO_PARTY 0000012504   = Zarlink , 0000455661  = X-Rite, 0000456467 = Sagem,因為抓不到營收
--2011/1/28 wenrong BILL_TO_PARTY 0000456396 = CPT  因為2009為cmo,2010為cpt,但正確為cpt
--2011/8/7 為何在select 時沒有加上period???之前的資料沒有人在看了..不用更新了
--2012/09/12 kangi 更改程式錯誤抓pnl3_trx001_copa　的end_customer_id　需要先排序完再用ROWNUM = 1

)
AUTHID DEFINER
IS
   CURSOR c_pnl2_pls001_t
   IS
      SELECT   period, company_code, profit_center, customer_id
          FROM pnl2_upl002_bad_debt
         WHERE uploadsite = incompany
           AND PERIOD = t_period --2011/8/7
      GROUP BY period, company_code, profit_center, customer_id;

   a_customer   pnl2_upl002_bad_debt.end_customer_id%TYPE;
   a_period     pnl2_upl002_bad_debt.period%TYPE;
   p_period     STRING (4);
BEGIN
   p_period := SUBSTRB (t_period, 1, 4) - 1;

   FOR rec1 IN c_pnl2_pls001_t
   LOOP
      a_customer := 'OTHERS';

      IF rec1.company_code = '1101'
      THEN
         a_customer := 'ABIT M/B';
      ELSIF rec1.customer_id = '0000480006'
      THEN
         a_customer := 'OTHERS';
      ELSIF rec1.customer_id = '0000012504'
      THEN
         a_customer := 'ZARLINK';
      ELSIF rec1.customer_id = '0000455661'
      THEN
         a_customer := 'X-RITE';
      ELSIF rec1.customer_id = '0000456467'
      THEN
         a_customer := 'SAGEM';
      ELSIF rec1.customer_id = '0000456396'
      THEN
         a_customer := 'CPT';
      ELSE
         BEGIN
               --Modify kangi 20120912
               --SELECT DISTINCT end_customer_id, period
               --        INTO a_customer, a_period
               --        FROM pnl3_trx001_copa
               --       WHERE bill_to_party = rec1.customer_id
               --         AND profit_center = rec1.profit_center
               --         AND company_code = rec1.company_code
               --         AND (   period LIKE SUBSTRB (rec1.period, 1, 4) || '%'
               --              OR period LIKE p_period || '%'
               --             )
               --         AND ROWNUM = 1
               --         AND end_customer_id <> '其他-材料轉售'
               --    ORDER BY period DESC;

               SELECT end_customer_id, period INTO a_customer, a_period FROM
               (SELECT DISTINCT end_customer_id, period
                    FROM pnl3_trx001_copa
                   WHERE bill_to_party = rec1.customer_id
                     AND profit_center = rec1.profit_center
                     AND company_code = rec1.company_code
                     AND ( period LIKE SUBSTRB (rec1.period, 1, 4) || '%'
                           OR period LIKE p_period || '%'
                          )
                     AND end_customer_id <> '其他-材料轉售'
                     order by period desc )
                 WHERE ROWNUM = 1;
               --End Modify kangi 20120912

         EXCEPTION
            WHEN OTHERS
            THEN
               a_customer := 'OTHERS';
         END;

         IF a_customer = 'OTHERS'
         THEN
            BEGIN
               --Modify kangi 20120912
               --SELECT DISTINCT end_customer_id, period
               --           INTO a_customer, a_period
               --           FROM pnl3_trx001_copa
               --          WHERE bill_to_party = rec1.customer_id
               --            --AND PROFIT_CENTER = REC1.PROFIT_CENTER
               --            AND company_code = rec1.company_code
               --            AND (   period LIKE
               --                              SUBSTRB (rec1.period, 1, 4)
               --                              || '%'
               --                 OR period LIKE p_period || '%'
               --                )
               --            --AND period LIKE SUBSTRB (rec1.period, 1, 4) || '%'
               --            AND ROWNUM = 1
               --            AND end_customer_id <> '其他-材料轉售'
               --       ORDER BY period DESC;
               SELECT end_customer_id, period INTO a_customer, a_period FROM
                (SELECT DISTINCT end_customer_id, period
                    FROM pnl3_trx001_copa
                   WHERE bill_to_party = rec1.customer_id
                     --AND PROFIT_CENTER = REC1.PROFIT_CENTER
                     AND company_code = rec1.company_code
                     AND (   period LIKE
                             SUBSTRB (rec1.period, 1, 4)|| '%'
                             OR period LIKE p_period || '%'
                         )
                     --AND period LIKE SUBSTRB (rec1.period, 1, 4) || '%'
                     AND end_customer_id <> '其他-材料轉售'
                     order by period desc )
                 WHERE ROWNUM = 1;
                --End Modify kangi 20120912
            EXCEPTION
               WHEN OTHERS
               THEN
                  a_customer := 'OTHERS';
            END;
         END IF;

         IF a_customer = 'OTHERS'
         THEN
            BEGIN
               --Modify kangi 20120912
               --SELECT DISTINCT end_customer_id, period
               --           INTO a_customer, a_period
               --           FROM pnl3_trx001_copa
               --          WHERE bill_to_party = rec1.customer_id
               --            --AND PROFIT_CENTER = REC1.PROFIT_CENTER
               --            --AND COMPANY_CODE = REC1.COMPANY_CODE
               --            AND (   period LIKE
               --                              SUBSTRB (rec1.period, 1, 4)
               --                              || '%'
               --                 OR period LIKE p_period || '%'
               --                )
               --            --AND period LIKE SUBSTRB (rec1.period, 1, 4) || '%'
               --            AND ROWNUM = 1
               --            AND end_customer_id <> '其他-材料轉售'
               --       ORDER BY period DESC;
               SELECT end_customer_id, period INTO a_customer, a_period FROM
               (SELECT DISTINCT end_customer_id, period
                    FROM pnl3_trx001_copa
                   WHERE bill_to_party = rec1.customer_id
                     --AND PROFIT_CENTER = REC1.PROFIT_CENTER
                     --AND COMPANY_CODE = REC1.COMPANY_CODE
                     AND (   period LIKE
                                             SUBSTRB (rec1.period, 1, 4)
                                             || '%'
                              OR period LIKE p_period || '%'
                               )
                     --AND period LIKE SUBSTRB (rec1.period, 1, 4) || '%'
                     AND end_customer_id <> '其他-材料轉售'
                     order by period desc )
               WHERE ROWNUM = 1;
               --Modify kangi 20120912
            EXCEPTION
               WHEN OTHERS
               THEN
                  a_customer := 'OTHERS';
            END;
         END IF;
      END IF;

      UPDATE pnl2_upl002_bad_debt
         SET end_customer_id = a_customer
       WHERE company_code = rec1.company_code
         AND profit_center = rec1.profit_center
         AND period = rec1.period
         AND customer_id = rec1.customer_id;

      COMMIT;
   END LOOP;
END pnl2_pls001_bad_debt_chang_trx;
/

