create PROCEDURE PNL_PLS004_CAL_ASE_EXRATE_UL04 (
  sKEYIN_YYMM in PNL_UPL004_BG_ALL_FORECAST.KEYIN_YYMM%TYPE,
  sPROFIT_CENTER in PNL_UPL004_BG_ALL_FORECAST.PROFIT_CENTER%TYPE,
  sCOMPANY_CODE in PNL_UPL004_BG_ALL_FORECAST.COMPANY_CODE%TYPE
)
AUTHID DEFINER
/*********************************************************************
  ACTION       : Revenue Forecast 使用 ASE (RWF_MAP003_ASE_EX_RATE) 匯率 FOR TABLE PNL_UPL004_BG_ALL_FORECAST
  Author       : KANGI
  Date         : 2014/07/10
  OA           :  SAI045958
**********************************************************************/
/*********************************************************************
  ACTION       : 上傳格式改為 USD
  Author       : KANGI
  Date         : 20141229
  OA           :  SAI049288
**********************************************************************/
is
   sORG_CURRENCY       RWF_MAP003_ASE_EX_RATE.FROM_CURRENCY%TYPE ;
   --JAN(1)
   nJAN_TO_USD_RATE    PNL_UPL004_BG_ALL_FORECAST.JAN_EX_RATE_USD%TYPE ;
   nJAN_TO_CNY_RATE    PNL_UPL004_BG_ALL_FORECAST.JAN_EX_RATE_CNY%TYPE ;
   nJAN_TO_TWD_RATE    PNL_UPL004_BG_ALL_FORECAST.JAN_EX_RATE_TWD%TYPE ;
   --FEB(2)
   nFEB_TO_USD_RATE   PNL_UPL004_BG_ALL_FORECAST.FEB_EX_RATE_USD%TYPE ;
   nFEB_TO_CNY_RATE   PNL_UPL004_BG_ALL_FORECAST.FEB_EX_RATE_CNY%TYPE ;
   nFEB_TO_TWD_RATE   PNL_UPL004_BG_ALL_FORECAST.FEB_EX_RATE_TWD%TYPE ;
   --MAR(3)
   nMAR_TO_USD_RATE   PNL_UPL004_BG_ALL_FORECAST.MAR_EX_RATE_USD%TYPE ;
   nMAR_TO_CNY_RATE   PNL_UPL004_BG_ALL_FORECAST.MAR_EX_RATE_CNY%TYPE ;
   nMAR_TO_TWD_RATE   PNL_UPL004_BG_ALL_FORECAST.MAR_EX_RATE_TWD%TYPE ;
   --APR(4)
   nAPR_TO_USD_RATE   PNL_UPL004_BG_ALL_FORECAST.APR_EX_RATE_USD%TYPE ;
   nAPR_TO_CNY_RATE   PNL_UPL004_BG_ALL_FORECAST.APR_EX_RATE_CNY%TYPE ;
   nAPR_TO_TWD_RATE   PNL_UPL004_BG_ALL_FORECAST.APR_EX_RATE_TWD%TYPE ;
   --MAY(5)
   nMAY_TO_USD_RATE   PNL_UPL004_BG_ALL_FORECAST.MAY_EX_RATE_USD%TYPE ;
   nMAY_TO_CNY_RATE   PNL_UPL004_BG_ALL_FORECAST.MAY_EX_RATE_CNY%TYPE ;
   nMAY_TO_TWD_RATE   PNL_UPL004_BG_ALL_FORECAST.MAY_EX_RATE_TWD%TYPE ;
   --JUN(6)
   nJUN_TO_USD_RATE   PNL_UPL004_BG_ALL_FORECAST.JUN_EX_RATE_USD%TYPE ;
   nJUN_TO_CNY_RATE   PNL_UPL004_BG_ALL_FORECAST.JUN_EX_RATE_CNY%TYPE ;
   nJUN_TO_TWD_RATE   PNL_UPL004_BG_ALL_FORECAST.JUN_EX_RATE_TWD%TYPE ;
   --JUL(7)
   nJUL_TO_USD_RATE   PNL_UPL004_BG_ALL_FORECAST.JUL_EX_RATE_USD%TYPE ;
   nJUL_TO_CNY_RATE   PNL_UPL004_BG_ALL_FORECAST.JUL_EX_RATE_CNY%TYPE ;
   nJUL_TO_TWD_RATE   PNL_UPL004_BG_ALL_FORECAST.JUL_EX_RATE_TWD%TYPE ;
   --AUG(8)
   nAUG_TO_USD_RATE   PNL_UPL004_BG_ALL_FORECAST.AUG_EX_RATE_USD%TYPE ;
   nAUG_TO_CNY_RATE   PNL_UPL004_BG_ALL_FORECAST.AUG_EX_RATE_CNY%TYPE ;
   nAUG_TO_TWD_RATE   PNL_UPL004_BG_ALL_FORECAST.AUG_EX_RATE_TWD%TYPE ;
   --SEP(9)
   nSEP_TO_USD_RATE   PNL_UPL004_BG_ALL_FORECAST.SEP_EX_RATE_USD%TYPE ;
   nSEP_TO_CNY_RATE   PNL_UPL004_BG_ALL_FORECAST.SEP_EX_RATE_CNY%TYPE ;
   nSEP_TO_TWD_RATE   PNL_UPL004_BG_ALL_FORECAST.SEP_EX_RATE_TWD%TYPE ;
   --OCT(10)
   nOCT_TO_USD_RATE   PNL_UPL004_BG_ALL_FORECAST.OCT_EX_RATE_USD%TYPE ;
   nOCT_TO_CNY_RATE   PNL_UPL004_BG_ALL_FORECAST.OCT_EX_RATE_CNY%TYPE ;
   nOCT_TO_TWD_RATE   PNL_UPL004_BG_ALL_FORECAST.OCT_EX_RATE_TWD%TYPE ;
   --NOV(11)
   nNOV_TO_USD_RATE   PNL_UPL004_BG_ALL_FORECAST.NOV_EX_RATE_USD%TYPE ;
   nNOV_TO_CNY_RATE   PNL_UPL004_BG_ALL_FORECAST.NOV_EX_RATE_CNY%TYPE ;
   nNOV_TO_TWD_RATE   PNL_UPL004_BG_ALL_FORECAST.NOV_EX_RATE_TWD%TYPE ;
   --DEC(12)
   nDEC_TO_USD_RATE   PNL_UPL004_BG_ALL_FORECAST.DEC_EX_RATE_USD%TYPE ;
   nDEC_TO_CNY_RATE   PNL_UPL004_BG_ALL_FORECAST.DEC_EX_RATE_CNY%TYPE ;
   nDEC_TO_TWD_RATE   PNL_UPL004_BG_ALL_FORECAST.DEC_EX_RATE_TWD%TYPE ;
   sBDATE          RWF_MAP003_ASE_EX_RATE.BDATE%TYPE ;
   iTracePoint  integer ;
   cErrorText varchar2(500) ;
 BEGIN
  iTracePoint := 100 ;
  --Modify kangi 20141229
  --sORG_CURRENCY := 'CNY' ; Remark kangi 20141229
   sORG_CURRENCY := 'USD' ;
  --End Modify kangi 20141229

  iTracePoint := 200 ;


  iTracePoint := 300 ;
  --GET 最大的 sBDATE FROM RWF_MAP003_ASE_EX_RATE
  sBDATE := NULL ;
  BEGIN
      iTracePoint := 400 ;
      SELECT MAX(BDATE) INTO sBDATE FROM RWF_MAP003_ASE_EX_RATE ;
      iTracePoint := 500 ;
      EXCEPTION
          WHEN OTHERS THEN
          NULL  ;
  END ;
  iTracePoint := 600 ;
  IF sBDATE IS NOT NULL THEN
     iTracePoint := 700 ;
     --JAN(1)
     nJAN_TO_USD_RATE := 0 ;
     nJAN_TO_CNY_RATE := 0 ;
     nJAN_TO_TWD_RATE := 0 ;
     iTracePoint := 800 ;
     BEGIN
        iTracePoint := 900 ;
        SELECT TO_USD_RATE,TO_CNY_RATE,TO_TWD_RATE
             INTO nJAN_TO_USD_RATE,nJAN_TO_CNY_RATE,nJAN_TO_TWD_RATE
             FROM RWF_MAP003_ASE_EX_RATE
             WHERE FROM_CURRENCY = sORG_CURRENCY
               AND PERIOD = ( SELECT MAX(PERIOD) FROM RWF_MAP003_ASE_EX_RATE WHERE PERIOD <= SUBSTR(sKEYIN_YYMM,1,4)||'01' AND BDATE = sBDATE )
               AND BDATE = sBDATE  ;
        iTracePoint := 1000 ;
                  EXCEPTION
                  WHEN OTHERS THEN
        iTracePoint := 1100 ;
                     NULL  ;
     END ;
     iTracePoint := 1200 ;
     --FEB(2)
     nFEB_TO_USD_RATE := 0 ;
     nFEB_TO_CNY_RATE := 0 ;
     nFEB_TO_TWD_RATE := 0 ;
     BEGIN
        iTracePoint := 1300 ;
        SELECT TO_USD_RATE,TO_CNY_RATE,TO_TWD_RATE
             INTO nFEB_TO_USD_RATE,nFEB_TO_CNY_RATE,nFEB_TO_TWD_RATE
             FROM RWF_MAP003_ASE_EX_RATE
             WHERE FROM_CURRENCY = sORG_CURRENCY
               AND PERIOD = ( SELECT MAX(PERIOD) FROM RWF_MAP003_ASE_EX_RATE WHERE PERIOD <= SUBSTR(sKEYIN_YYMM,1,4)||'02' AND BDATE = sBDATE )
               AND BDATE = sBDATE  ;
        iTracePoint := 1400 ;
                  EXCEPTION
                  WHEN OTHERS THEN
        iTracePoint := 1500 ;
                     NULL  ;
     END ;
     iTracePoint := 1600 ;
     --MAR(3)
     nMAR_TO_USD_RATE := 0 ;
     nMAR_TO_CNY_RATE := 0 ;
     nMAR_TO_TWD_RATE := 0 ;
     iTracePoint := 1700 ;
     BEGIN
        iTracePoint := 1800 ;
        SELECT TO_USD_RATE,TO_CNY_RATE,TO_TWD_RATE
             INTO nMAR_TO_USD_RATE,nMAR_TO_CNY_RATE,nMAR_TO_TWD_RATE
             FROM RWF_MAP003_ASE_EX_RATE
             WHERE FROM_CURRENCY = sORG_CURRENCY
               AND PERIOD = ( SELECT MAX(PERIOD) FROM RWF_MAP003_ASE_EX_RATE WHERE PERIOD <= SUBSTR(sKEYIN_YYMM,1,4)||'03' AND BDATE = sBDATE )
               AND BDATE = sBDATE  ;
        iTracePoint := 1900 ;
                  EXCEPTION
                  WHEN OTHERS THEN
        iTracePoint := 2000 ;
                     NULL  ;
     END ;
     iTracePoint := 2100 ;
     --APR(4)
     nAPR_TO_USD_RATE := 0 ;
     nAPR_TO_CNY_RATE := 0 ;
     nAPR_TO_TWD_RATE := 0 ;
     iTracePoint := 2200 ;
     BEGIN
        iTracePoint := 2300 ;
        SELECT TO_USD_RATE,TO_CNY_RATE,TO_TWD_RATE
             INTO nAPR_TO_USD_RATE,nAPR_TO_CNY_RATE,nAPR_TO_TWD_RATE
             FROM RWF_MAP003_ASE_EX_RATE
             WHERE FROM_CURRENCY = sORG_CURRENCY
               AND PERIOD = ( SELECT MAX(PERIOD) FROM RWF_MAP003_ASE_EX_RATE WHERE PERIOD <= SUBSTR(sKEYIN_YYMM,1,4)||'04' AND BDATE = sBDATE )
               AND BDATE = sBDATE  ;
        iTracePoint := 2400 ;
                  EXCEPTION
                  WHEN OTHERS THEN
        iTracePoint := 2500 ;
                     NULL  ;
     END ;
     iTracePoint := 2600 ;
     --MAY(5)
     nMAY_TO_USD_RATE := 0 ;
     nMAY_TO_CNY_RATE := 0 ;
     nMAY_TO_TWD_RATE := 0 ;
     iTracePoint := 2700 ;
     BEGIN
        iTracePoint := 2800 ;
        SELECT TO_USD_RATE,TO_CNY_RATE,TO_TWD_RATE
             INTO nMAY_TO_USD_RATE,nMAY_TO_CNY_RATE,nMAY_TO_TWD_RATE
             FROM RWF_MAP003_ASE_EX_RATE
             WHERE FROM_CURRENCY = sORG_CURRENCY
               AND PERIOD = ( SELECT MAX(PERIOD) FROM RWF_MAP003_ASE_EX_RATE WHERE PERIOD <= SUBSTR(sKEYIN_YYMM,1,4)||'05' AND BDATE = sBDATE )
               AND BDATE = sBDATE  ;
        iTracePoint := 2900 ;
                  EXCEPTION
                  WHEN OTHERS THEN
        iTracePoint := 3000 ;
                     NULL  ;
     END ;
     iTracePoint := 3100 ;
     --JUN(6)
     nJUN_TO_USD_RATE := 0 ;
     nJUN_TO_CNY_RATE := 0 ;
     nJUN_TO_TWD_RATE := 0 ;
     iTracePoint := 3200 ;
     BEGIN
        iTracePoint := 3300 ;
        SELECT TO_USD_RATE,TO_CNY_RATE,TO_TWD_RATE
             INTO nJUN_TO_USD_RATE,nJUN_TO_CNY_RATE,nJUN_TO_TWD_RATE
             FROM RWF_MAP003_ASE_EX_RATE
             WHERE FROM_CURRENCY = sORG_CURRENCY
               AND PERIOD = ( SELECT MAX(PERIOD) FROM RWF_MAP003_ASE_EX_RATE WHERE PERIOD <= SUBSTR(sKEYIN_YYMM,1,4)||'06' AND BDATE = sBDATE )
               AND BDATE = sBDATE  ;
        iTracePoint := 3400 ;
                  EXCEPTION
                  WHEN OTHERS THEN
        iTracePoint := 3500 ;
                     NULL  ;
     END ;
     iTracePoint := 3600 ;
     --JUL(7)
     nJUL_TO_USD_RATE := 0 ;
     nJUL_TO_CNY_RATE := 0 ;
     nJUL_TO_TWD_RATE := 0 ;
     iTracePoint := 3700 ;
     BEGIN
        iTracePoint := 3800 ;
        SELECT TO_USD_RATE,TO_CNY_RATE,TO_TWD_RATE
             INTO nJUL_TO_USD_RATE,nJUL_TO_CNY_RATE,nJUL_TO_TWD_RATE
             FROM RWF_MAP003_ASE_EX_RATE
             WHERE FROM_CURRENCY = sORG_CURRENCY
               AND PERIOD = ( SELECT MAX(PERIOD) FROM RWF_MAP003_ASE_EX_RATE WHERE PERIOD <= SUBSTR(sKEYIN_YYMM,1,4)||'07' AND BDATE = sBDATE )
               AND BDATE = sBDATE  ;
        iTracePoint := 3900 ;
                  EXCEPTION
                  WHEN OTHERS THEN
        iTracePoint := 4000 ;
                     NULL  ;
     END ;
     --AUG(8)
     iTracePoint := 4100 ;
     nAUG_TO_USD_RATE := 0 ;
     nAUG_TO_CNY_RATE := 0 ;
     nAUG_TO_TWD_RATE := 0 ;
     iTracePoint := 4200 ;
     BEGIN
        iTracePoint := 4300 ;
        SELECT TO_USD_RATE,TO_CNY_RATE,TO_TWD_RATE
             INTO nAUG_TO_USD_RATE,nAUG_TO_CNY_RATE,nAUG_TO_TWD_RATE
             FROM RWF_MAP003_ASE_EX_RATE
             WHERE FROM_CURRENCY = sORG_CURRENCY
               AND PERIOD = ( SELECT MAX(PERIOD) FROM RWF_MAP003_ASE_EX_RATE WHERE PERIOD <= SUBSTR(sKEYIN_YYMM,1,4)||'08' AND BDATE = sBDATE )
               AND BDATE = sBDATE  ;
        iTracePoint := 4400 ;
                  EXCEPTION
                  WHEN OTHERS THEN
        iTracePoint := 4500 ;
                     NULL  ;
     END ;
     iTracePoint := 4600 ;
     --SEP(9)
     nSEP_TO_USD_RATE := 0 ;
     nSEP_TO_CNY_RATE := 0 ;
     nSEP_TO_TWD_RATE := 0 ;
     iTracePoint := 4700 ;
     BEGIN
        iTracePoint := 4800 ;
        SELECT TO_USD_RATE,TO_CNY_RATE,TO_TWD_RATE
             INTO nSEP_TO_USD_RATE,nSEP_TO_CNY_RATE,nSEP_TO_TWD_RATE
             FROM RWF_MAP003_ASE_EX_RATE
             WHERE FROM_CURRENCY = sORG_CURRENCY
               AND PERIOD = ( SELECT MAX(PERIOD) FROM RWF_MAP003_ASE_EX_RATE WHERE PERIOD <= SUBSTR(sKEYIN_YYMM,1,4)||'09' AND BDATE = sBDATE )
               AND BDATE = sBDATE  ;
        iTracePoint := 4900 ;
                  EXCEPTION
                  WHEN OTHERS THEN
        iTracePoint := 5000 ;
                     NULL  ;
     END ;
     iTracePoint := 5100 ;
     --OCT(10)
     nOCT_TO_USD_RATE := 0 ;
     nOCT_TO_CNY_RATE := 0 ;
     nOCT_TO_TWD_RATE := 0 ;
     iTracePoint := 5200 ;
     BEGIN
        iTracePoint := 5300 ;
        SELECT TO_USD_RATE,TO_CNY_RATE,TO_TWD_RATE
             INTO nOCT_TO_USD_RATE,nOCT_TO_CNY_RATE,nOCT_TO_TWD_RATE
             FROM RWF_MAP003_ASE_EX_RATE
             WHERE FROM_CURRENCY = sORG_CURRENCY
               AND PERIOD = ( SELECT MAX(PERIOD) FROM RWF_MAP003_ASE_EX_RATE WHERE PERIOD <= SUBSTR(sKEYIN_YYMM,1,4)||'10' AND BDATE = sBDATE )
               AND BDATE = sBDATE  ;
        iTracePoint := 5400 ;
                  EXCEPTION
                  WHEN OTHERS THEN
        iTracePoint := 5500 ;
                     NULL  ;
     END ;
     iTracePoint := 5600 ;
     --NOV(11)
     nNOV_TO_USD_RATE := 0 ;
     nNOV_TO_CNY_RATE := 0 ;
     nNOV_TO_TWD_RATE := 0 ;
     iTracePoint := 5700 ;
     BEGIN
        iTracePoint := 5800 ;
        SELECT TO_USD_RATE,TO_CNY_RATE,TO_TWD_RATE
             INTO nNOV_TO_USD_RATE,nNOV_TO_CNY_RATE,nNOV_TO_TWD_RATE
             FROM RWF_MAP003_ASE_EX_RATE
             WHERE FROM_CURRENCY = sORG_CURRENCY
               AND PERIOD = ( SELECT MAX(PERIOD) FROM RWF_MAP003_ASE_EX_RATE WHERE PERIOD <= SUBSTR(sKEYIN_YYMM,1,4)||'11' AND BDATE = sBDATE )
               AND BDATE = sBDATE  ;
        iTracePoint := 5900 ;
                  EXCEPTION
                  WHEN OTHERS THEN
        iTracePoint := 1000 ;
                     NULL  ;
     END ;
     iTracePoint := 6000 ;
     --DEC(12)
     nDEC_TO_USD_RATE := 0 ;
     nDEC_TO_CNY_RATE := 0 ;
     nDEC_TO_TWD_RATE := 0 ;
     iTracePoint := 6100 ;
     BEGIN
        iTracePoint := 6200 ;
        SELECT TO_USD_RATE,TO_CNY_RATE,TO_TWD_RATE
             INTO nDEC_TO_USD_RATE,nDEC_TO_CNY_RATE,nDEC_TO_TWD_RATE
             FROM RWF_MAP003_ASE_EX_RATE
             WHERE FROM_CURRENCY = sORG_CURRENCY
               AND PERIOD = ( SELECT MAX(PERIOD) FROM RWF_MAP003_ASE_EX_RATE WHERE PERIOD <= SUBSTR(sKEYIN_YYMM,1,4)||'12' AND BDATE = sBDATE )
               AND BDATE = sBDATE  ;
        iTracePoint := 6300 ;
                  EXCEPTION
                  WHEN OTHERS THEN
        iTracePoint := 6400 ;
                     NULL  ;
     END ;
     iTracePoint := 6500 ;
     IF nJAN_TO_USD_RATE <> 0 THEN
            iTracePoint := 6600 ;
            --更新PNL_UPL004_BG_ALL_FORECAST BY sKEYIN_YYMM,sPROFIT_CENTER,sCOMPANY_CODE
            BEGIN
              UPDATE PNL_UPL004_BG_ALL_FORECAST
              SET JAN_EX_RATE_TWD = nJAN_TO_TWD_RATE ,
                  JAN_EX_RATE_USD = nJAN_TO_USD_RATE ,
                  JAN_EX_RATE_CNY = nJAN_TO_CNY_RATE ,
                  FEB_EX_RATE_TWD = nFEB_TO_TWD_RATE ,
                  FEB_EX_RATE_USD = nFEB_TO_USD_RATE ,
                  FEB_EX_RATE_CNY = nFEB_TO_CNY_RATE ,
                  MAR_EX_RATE_TWD = nMAR_TO_TWD_RATE ,
                  MAR_EX_RATE_USD = nMAR_TO_USD_RATE ,
                  MAR_EX_RATE_CNY = nMAR_TO_CNY_RATE ,
                  APR_EX_RATE_TWD = nAPR_TO_TWD_RATE ,
                  APR_EX_RATE_USD = nAPR_TO_USD_RATE ,
                  APR_EX_RATE_CNY = nAPR_TO_CNY_RATE ,
                  MAY_EX_RATE_TWD = nMAY_TO_TWD_RATE ,
                  MAY_EX_RATE_USD = nMAY_TO_USD_RATE ,
                  MAY_EX_RATE_CNY = nMAY_TO_CNY_RATE ,
                  JUN_EX_RATE_TWD = nJUN_TO_TWD_RATE ,
                  JUN_EX_RATE_USD = nJUN_TO_USD_RATE ,
                  JUN_EX_RATE_CNY = nJUN_TO_CNY_RATE ,
                  JUL_EX_RATE_TWD = nJUL_TO_TWD_RATE ,
                  JUL_EX_RATE_USD = nJUL_TO_USD_RATE ,
                  JUL_EX_RATE_CNY = nJUL_TO_CNY_RATE ,
                  AUG_EX_RATE_TWD = nAUG_TO_TWD_RATE ,
                  AUG_EX_RATE_USD = nAUG_TO_USD_RATE ,
                  AUG_EX_RATE_CNY = nAUG_TO_CNY_RATE ,
                  SEP_EX_RATE_TWD = nSEP_TO_TWD_RATE ,
                  SEP_EX_RATE_USD = nSEP_TO_USD_RATE ,
                  SEP_EX_RATE_CNY = nSEP_TO_CNY_RATE ,
                  OCT_EX_RATE_TWD = nOCT_TO_TWD_RATE ,
                  OCT_EX_RATE_USD = nOCT_TO_USD_RATE ,
                  OCT_EX_RATE_CNY = nOCT_TO_CNY_RATE ,
                  NOV_EX_RATE_TWD = nNOV_TO_TWD_RATE ,
                  NOV_EX_RATE_USD = nNOV_TO_USD_RATE ,
                  NOV_EX_RATE_CNY = nNOV_TO_CNY_RATE ,
                  DEC_EX_RATE_TWD = nDEC_TO_TWD_RATE ,
                  DEC_EX_RATE_USD = nDEC_TO_USD_RATE ,
                  DEC_EX_RATE_CNY = nDEC_TO_CNY_RATE
              WHERE KEYIN_YYMM = sKEYIN_YYMM
                AND PROFIT_CENTER = sPROFIT_CENTER
                AND COMPANY_CODE = sCOMPANY_CODE  ;
              iTracePoint := 6700 ;
              EXCEPTION
              WHEN OTHERS THEN
              iTracePoint := 6800 ;
              NULL  ;
            END ;
       END IF;

  END IF;
  --COMMIT ;
  iTracePoint := 1800 ;
 EXCEPTION
     WHEN OTHERS THEN
            --rollback ;
            cErrorText := SQLERRM() ;
            MAIL_FILE_BIDBDBADMIN(in_to_name=>'kangi@ms.usi.com.tw',subject   => 'PL/SQL PNL_PLS004_CAL_ASE_EXRATE_UL04 ERROR', message => '[PNL_PLS004_CAL_ASE_EXRATE_UL04], The tracepoint is  ' || to_char(iTracePoint) || 'and ErrorText=' || cErrorText) ;
            DBMS_OUTPUT.PUT_LINE(SUBSTR(cErrorText,1,255));
            DBMS_OUTPUT.PUT_LINE(TO_CHAR(iTracePoint));
END PNL_PLS004_CAL_ASE_EXRATE_UL04;
/

