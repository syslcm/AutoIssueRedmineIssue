create PROCEDURE       ROA_PLS009_CLASS_RULE (
/* ********************************************************************
  PROG-ID      : ROA_SAP005_CLASS_RULE
  PROG-ACTION  : 
  Author       : Erin Cheng
  Date         : 2017/05/26
  OA Number    : SAI069977
*********************************************************************
* 2018/07/10 SAI085947 Erin Remove SOURCE_FROM = 'SAP'

********************************************************************* */
   incompany    IN   VARCHAR2,
   f_yyyymmdd   IN   VARCHAR2,
   t_yyyymmdd   IN   VARCHAR2
)
AUTHID DEFINER
IS
   CURSOR ROA_SAP005_CLASS_RULE_T
   IS
     SELECT TYPE, COMPANY_CODE, ASSET_CLASS, S_SEQ, S_DESC, ACCOUNT, SOURCE_FROM, CREATE_USER 
     FROM ROA_SAP005_CLASS_RULE_T
     where COMPANY_CODE = incompany;
   itracepoint   INTEGER;
BEGIN
     --(1)清除舊資料
     DELETE FROM ROA_SAP005_CLASS_RULE
     --where COMPANY_CODE = incompany and SOURCE_FROM = 'SAP';   --SAI085947 Remark
	 where COMPANY_CODE = incompany;
     COMMIT;  


   FOR REC1 IN ROA_SAP005_CLASS_RULE_T LOOP
    
   
   
   --(2)開始處理資料
       INSERT INTO ROA_SAP005_CLASS_RULE (
            TYPE,        COMPANY_CODE,   ASSET_CLASS,    S_SEQ,            
            S_DESC,      ACCOUNT,        SOURCE_FROM,    CREATE_USER,
            CREATE_DATE
            ) VALUES (
                 
            REC1.TYPE,   REC1.COMPANY_CODE, REC1.ASSET_CLASS,  REC1.S_SEQ,            
            REC1.S_DESC, REC1.ACCOUNT,      REC1.SOURCE_FROM,  REC1.CREATE_USER, 
            SYSDATE            
             );    
       COMMIT;

   END LOOP;

   --(3) 刪除資料
   DELETE FROM ROA_SAP005_CLASS_RULE_T
   where COMPANY_CODE = incompany And SOURCE_FROM = 'SAP';  
   COMMIT;


END ROA_PLS009_CLASS_RULE;
/

