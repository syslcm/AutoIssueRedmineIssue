create PROCEDURE       pnl3_pls015_custommodel_trx_V2 (
                                                        t_period IN VARCHAR2
--2011/8/6 原本使用 pnl3_pls001_copa_trx 的是從SAP下來的資料,但經管每次都有意見和會計的對不起來,所以就改用會計
--的資料,有問題直接找會計解釋即可,不用再去查哪裡有問題了,
--因為上傳的是台幣,所以local幣別是台幣,
--2011/8/16 INV LOST是從AM到AT但其中AQ和AS是負數的,所以要扣掉,而且也不能用判斷AM到AT有值就抓AU的 NET COGS,這樣會算到原本COGS的那一塊
--2011/9/26  AdjustCOGS 拆成進口運費, Loss Due to Market D 拆成slow moving
)
AUTHID DEFINER
IS
   CURSOR c_cusmodel_r
   IS
SELECT   company_code, period, pc as profit_center,DATASOURCE,
               customer_code AS bill_to_party, ship_to_party_code as ship_to_party, material_group as mtl_group,
               part_no, plant as plant_code, material_type mtl_type, '' as cost_element, search_term,end_customer,
               nvl(SUM (net_revenue),0) amt_local, nvl(SUM (net_cogs),0) COGS, nvl(SUM(ADJUST_COGS),0) AC,nvl(SUM(LOSS_DUE_TO_MARKET),0) SM,
               (nvl(SUM (PHYSICAL_COUNT),0) + nvl(SUM (LOSS_DUE_TO_MARKET),0) + nvl(SUM (INVENTORY_SCRAP),0) + nvl(SUM (RETURN_PO),0) + (nvl(SUM (CLAIM_INCOME_CUSTOM),0) * -1) + nvl(SUM (CLAIM_LOSS_CUSTOM),0) + (nvl(SUM (RESALE_INCOME_FORID),0) * -1) + nvl(SUM (RESALE_LOST_FORID),0) ) inv_lost,
               nvl(SUM (net_qty),0) net_qty
          FROM PNL3_TRX008_CUSTOMER_MODEL

         WHERE period = t_period
         GROUP BY COMPANY_CODE,PERIOD,PC,CUSTOMER_CODE,SHIP_TO_PARTY_CODE,MATERIAL_GROUP,PART_NO,PLANT,MATERIAL_TYPE,SEARCH_TERM,END_CUSTOMER,DATASOURCE;


--Update FG & END CUSTOMER Mapping
   a_counter   INTEGER;
   a_rate      NUMBER (20, 10);
   a_amount    pnl3_trx001_copa.amt_twd%TYPE;
   a_cogs      pnl3_trx001_copa.amt_twd%TYPE;
      --變數
   t_CURRENCY_LOCAL    KPI_SAP013_EXPENSE_ADJUST_TRX.CURRENCY_LOCAL%TYPE;
   p_CURRENCY_LOCAL    KPI_SAP012_EXPENSE_TRX.CURRENCY_LOCAL%TYPE;
   a_EX_RATE_USD       KPI_SAP013_EXPENSE_ADJUST_TRX.EX_RATE_USD%TYPE;
   a_EX_RATE_TWD       KPI_SAP013_EXPENSE_ADJUST_TRX.EX_RATE_TWD%TYPE;
BEGIN
   DELETE FROM pnl3_trx001_copa
         WHERE period = t_period;

   COMMIT;
       a_EX_RATE_TWD := Null;
       a_EX_RATE_USD := Null;

       a_EX_RATE_USD := GET_EXCHANGE_RATE(SUBSTRB(t_period,1,4),SUBSTRB(t_period,5,2),'TWD','USD','T') ;
       a_EX_RATE_TWD := GET_EXCHANGE_RATE(SUBSTRB(t_period,1,4),SUBSTRB(t_period,5,2),'TWD','TWD','T') ;
   FOR rec1 IN c_cusmodel_r
   LOOP
      IF rec1.amt_local <> 0
      THEN
      INSERT INTO pnl3_trx001_copa
                  (company_code, period, profit_center,
                   bill_to_party, ship_to_party, mtl_group,
                   part_no, plant_code, amt_local,
                   amt_twd,amt_usd,  SOURCE, mtl_type,
                   cost_element, r_kind, area1, area2, area3,
                   search_term, create_date, net_qty,end_customer_id
                  )
           VALUES (rec1.company_code, rec1.period, rec1.profit_center,
                   rec1.bill_to_party, rec1.ship_to_party, rec1.mtl_group,
                   rec1.part_no, rec1.plant_code, rec1.amt_local,
                   Round(REC1.AMT_LOCAL * a_EX_RATE_TWD, 5),Round(REC1.AMT_LOCAL * a_EX_RATE_USD, 5), rec1.datasource, rec1.mtl_type,
                   rec1.cost_element, 'PL01', '1', '1', '0',
                   rec1.search_term, SYSDATE, rec1.net_qty,rec1.end_customer
                  );

      COMMIT;

      END IF;
      a_cogs := rec1.cogs;
      --不管是庫存損失或是cogs,都用net_cogs的欄位,是因為發現inv_lost的金額和cogs都有差1,2塊
      IF rec1.inv_lost <> 0
      THEN
         a_cogs := a_cogs - rec1.inv_lost;
           INSERT INTO pnl3_trx001_copa
                     (company_code, period, profit_center,
                      bill_to_party, ship_to_party,
                      mtl_group, part_no, plant_code,
                      amt_local, amt_twd,amt_usd,
                       SOURCE, mtl_type,
                      cost_element, r_kind, area1, area2, area3,
                      search_term, create_date,net_qty,end_customer_id
                     )
              VALUES (rec1.company_code, rec1.period, rec1.profit_center,
                      rec1.bill_to_party, rec1.ship_to_party,
                      rec1.mtl_group, rec1.part_no, rec1.plant_code,
                      rec1.INV_LOST,Round(REC1.INV_LOST * a_EX_RATE_TWD, 5),Round(REC1.INV_LOST * a_EX_RATE_USD, 5), 
                      rec1.datasource, rec1.mtl_type,
                      rec1.cost_element, 'PL01', '2', '2', '2',
                      rec1.search_term, SYSDATE,rec1.net_qty,rec1.end_customer
                     );

           COMMIT;

      END IF;
      IF rec1.ac <> 0
      THEN
         a_cogs := a_cogs - rec1.ac;
           INSERT INTO pnl3_trx001_copa
                     (company_code, period, profit_center,
                      bill_to_party, ship_to_party,
                      mtl_group, part_no, plant_code,
                      amt_local, amt_twd,amt_usd,
                       SOURCE, mtl_type,
                      cost_element, r_kind, area1, area2, area3,
                      search_term, create_date,net_qty,end_customer_id
                     )
              VALUES (rec1.company_code, rec1.period, rec1.profit_center,
                      rec1.bill_to_party, rec1.ship_to_party,
                      rec1.mtl_group, rec1.part_no, rec1.plant_code,
                      rec1.AC,Round(REC1.AC * a_EX_RATE_TWD, 5),Round(REC1.AC * a_EX_RATE_USD, 5), 
                      rec1.datasource, rec1.mtl_type,
                      rec1.cost_element, 'PL01', '2', '2', '3',
                      rec1.search_term, SYSDATE,rec1.net_qty,rec1.end_customer
                     );

           COMMIT;

      END IF;
      IF rec1.SM <> 0
      THEN
         a_cogs := a_cogs - rec1.SM;
           INSERT INTO pnl3_trx001_copa
                     (company_code, period, profit_center,
                      bill_to_party, ship_to_party,
                      mtl_group, part_no, plant_code,
                      amt_local, amt_twd,amt_usd,
                       SOURCE, mtl_type,
                      cost_element, r_kind, area1, area2, area3,
                      search_term, create_date,net_qty,end_customer_id
                     )
              VALUES (rec1.company_code, rec1.period, rec1.profit_center,
                      rec1.bill_to_party, rec1.ship_to_party,
                      rec1.mtl_group, rec1.part_no, rec1.plant_code,
                      rec1.SM,Round(REC1.SM * a_EX_RATE_TWD, 5),Round(REC1.SM * a_EX_RATE_USD, 5), 
                      rec1.datasource, rec1.mtl_type,
                      rec1.cost_element, 'PL01', '2', '2', '4',
                      rec1.search_term, SYSDATE,rec1.net_qty,rec1.end_customer
                     );

           COMMIT;

      END IF;
         IF abs(a_cogs) > 1
         THEN
           INSERT INTO pnl3_trx001_copa
                     (company_code, period, profit_center,
                      bill_to_party, ship_to_party,
                      mtl_group, part_no, plant_code,
                      amt_local, amt_twd,amt_usd,
                       SOURCE, mtl_type,
                      cost_element, r_kind, area1, area2, area3,
                      search_term, create_date,net_qty,end_customer_id
                     )
              VALUES (rec1.company_code, rec1.period, rec1.profit_center,
                      rec1.bill_to_party, rec1.ship_to_party,
                      rec1.mtl_group, rec1.part_no, rec1.plant_code,
                      a_cogs,Round(a_cogs * a_EX_RATE_TWD, 5),Round(a_cogs * a_EX_RATE_USD, 5), 
                      rec1.datasource, rec1.mtl_type,
                      rec1.cost_element, 'PL01', '2', '2', '1',
                      rec1.search_term, SYSDATE,rec1.net_qty,rec1.end_customer
                     );

           COMMIT;
         END IF;





   END LOOP;

   UPDATE pnl3_trx001_copa
      SET end_customer_id =
             (SELECT DISTINCT TRIM (end_customer_name)
                         FROM cep_map009_partno_customer
                        WHERE fg_material_no =
                                      RPAD (pnl3_trx001_copa.part_no, 18, ' ')
                          AND last_modify_date <= SYSDATE)
    WHERE period = t_period;

   COMMIT;

   /*
    *  Profit center 20/21 且mtl group 001-059歸Lenovo
    *  其他不屬於20/21 但仍是001-059則歸  其他-材料轉售
    *  不屬於001-059的材料則用search term(但要考慮到如果是cogs-屬於特定cost element則不走這裡)
    *  空白料號-用SEarch term update
    * 2008/11/26 邏輯變動 只要是20/21的材料都叫LENOVO
    * 而其他的如果SEARCH TERM是LENOVO就叫LENOVO,分完後再來做其他-材料轉售
   */
   UPDATE pnl3_trx001_copa
      SET end_customer_id = 'LENOVO'
    WHERE period = t_period
      AND profit_center IN ('0000000020', '0000000021')
      AND mtl_group BETWEEN '001' AND '059'
      AND mtl_type = 'RAW'
      AND end_customer_id IS NULL;

   COMMIT;

   UPDATE pnl3_trx001_copa
      SET end_customer_id = 'LENOVO'
    WHERE period = t_period
      AND (   profit_center NOT IN ('0000000020', '0000000021')
           OR profit_center IS NULL
          )
      AND mtl_group BETWEEN '001' AND '059'
      AND search_term = 'LENOVO'
      AND mtl_type = 'RAW'
      AND end_customer_id IS NULL;

   COMMIT;

   UPDATE pnl3_trx001_copa
      SET end_customer_id = '其他-材料轉售'
    WHERE period = t_period
      AND (   profit_center NOT IN ('0000000020', '0000000021')
           OR profit_center IS NULL
          )
      AND mtl_group BETWEEN '001' AND '059'
      AND mtl_type = 'RAW'
      AND end_customer_id IS NULL;

   COMMIT;

    /*
   Update PNL3_TRX001_COPA
      Set END_CUSTOMER_ID = '其他-材料轉售'
     Where Period = t_Period
      AND PROFIT_CENTER IN ('0000000020','0000000021')
       AND MTL_GROUP NOT BETWEEN '001' AND '059'
       AND MTL_TYPE = 'RAW'
       AND END_CUSTOMER_ID IS NULL;
    commit;
    */
   UPDATE pnl3_trx001_copa
      SET end_customer_id = TRIM (search_term)
    WHERE period = t_period
      AND search_term IS NOT NULL
      AND end_customer_id IS NULL
      AND mtl_type = 'RAW';

   COMMIT;

   --2008/11/12 剩下的直接用SEARCH TERM UPDATE
   UPDATE pnl3_trx001_copa
      SET end_customer_id = TRIM (search_term)
    WHERE period = t_period
      AND search_term IS NOT NULL
      AND end_customer_id IS NULL
      AND (mtl_type <> 'RAW' OR mtl_type IS NULL);

   COMMIT;
   
   --2011/8/8 有的search term是亂碼,所以直接更新
   
   UPDATE pnl3_trx001_copa
      SET end_customer_id = '寶利佳塑料'
    WHERE period = t_period
      AND bill_to_party = '0000200094'
      AND ship_to_party = '0000200094'
      AND mtl_type ='RAW';

   COMMIT;
   
   UPDATE pnl3_trx001_copa
      SET end_customer_id = '深圳明欽電'
    WHERE period = t_period
      AND bill_to_party = '0000456196'
      AND mtl_type ='RAW';

   COMMIT;
   
   UPDATE pnl3_trx001_copa
      SET end_customer_id = '正隆偉業'
    WHERE period = t_period
      AND bill_to_party = '0000200144'
      AND ship_to_party = '0000200144'
      AND mtl_type ='RAW';

   COMMIT;

   UPDATE pnl3_trx001_copa
      SET end_customer_id = '華星光電'
    WHERE period = t_period
      AND bill_to_party = '0000456587'
      AND ship_to_party = '0000456587'
      AND mtl_type ='RAW';

   COMMIT;
   
   --UPDATE pnl3_trx001_copa
   --   SET end_customer_id = ''
   -- WHERE period = t_period
   --   AND bill_to_party = '0000200146'
   --   AND ship_to_party = '0000200146'
   --   AND mtl_type ='RAW';

   --COMMIT;
   
   --UPDATE pnl3_trx001_copa
   --   SET end_customer_id = ''
   -- WHERE period = t_period
   --   AND bill_to_party = '0000200172'
   --   AND ship_to_party = '0000200172'
   --   AND mtl_type ='RAW';

   --COMMIT;
   
   UPDATE pnl3_trx001_copa
      SET end_customer_id = '海秋'
    WHERE period = t_period
      AND bill_to_party = '0000200151'
      AND ship_to_party = '0000200151'
      AND mtl_type ='RAW';

   COMMIT;
   
   UPDATE pnl3_trx001_copa
      SET end_customer_id = '上海點濤'
    WHERE period = t_period
      AND bill_to_party = '0000200058'
      AND mtl_type ='RAW';

   COMMIT;
   
   UPDATE pnl3_trx001_copa
      SET end_customer_id = '普陽電子有限公司'
    WHERE period = t_period
      AND bill_to_party = '0000456427'
      AND mtl_type ='RAW';

   COMMIT;

   --pnl3_pls006_revenue_ratio_trx (t_period);

   --把Revenue ratio搬來這裡,因為上傳的revenue資料要使用
   --2011/8/8 流程改變,所以不用在這裡算
 

   UPDATE pnl3_trx001_copa
      SET project_name =
             (SELECT DISTINCT TRIM (sap_project_name)
                         FROM cep_map010_partno_project
                        WHERE fg_material_no =
                                      RPAD (pnl3_trx001_copa.part_no, 18, ' '))
    WHERE period = t_period;

   commit;
   
   UPDATE pnl3_trx001_copa
      SET project_TYPE =
             (SELECT DISTINCT TRIM (PROJECT_TYPE)
                         FROM CEP_WEB002_PROJECT
                        WHERE PROJECT_NAME = pnl3_trx001_copa.PROJECT_NAME)
                                     -- RPAD (pnl3_trx001_copa.PROJECT_NAME, 30, ' '))
    WHERE period = t_period;

   commit;
END pnl3_pls015_custommodel_trx_V2;
/

