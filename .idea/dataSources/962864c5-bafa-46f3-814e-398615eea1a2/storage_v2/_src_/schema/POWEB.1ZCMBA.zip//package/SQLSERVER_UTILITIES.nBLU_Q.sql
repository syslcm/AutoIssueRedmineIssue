create PACKAGE sqlserver_utilities AS
FUNCTION convert(dataType VARCHAR2,num NUMBER) RETURN NUMBER;
FUNCTION convert(dataType VARCHAR2,date DATE, num NUMBER ) RETURN VARCHAR2;
FUNCTION datediff(datepart VARCHAR2, start_datetime_expr VARCHAR2, end_datetime_expr VARCHAR2) RETURN NUMBER;
FUNCTION fetch_status(cursorfound IN BOOLEAN)  RETURN NUMBER;
END sqlserver_utilities;
/

