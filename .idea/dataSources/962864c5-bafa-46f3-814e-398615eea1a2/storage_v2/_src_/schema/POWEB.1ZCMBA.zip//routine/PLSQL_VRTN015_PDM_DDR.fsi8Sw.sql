create PROCEDURE         "PLSQL_VRTN015_PDM_DDR" (
  YYYYMM in VARCHAR2
)
is
 iTracePoint  integer ;
 cErrorText varchar2(500);

BEGIN
  iTracePoint := '100';
  DELETE   FROM VRTN_MAP030_SUMMARY_GRAD WHERE  TYPE ='QB'
            AND  YYYY = SUBSTRB(YYYYMM,1,4) AND MM = SUBSTRB(YYYYMM,5,2);

   iTracePoint := '200';
   EXECUTE IMMEDIATE 'INSERT INTO  VRTN_MAP030_SUMMARY_GRAD
   SELECT SITE, vendor_code AS LIFNR ,MATGROUP ,''QB'' AS TYPE  ,yyyy, mm,''Q''||to_char(TO_DATE(YYYYMM||''01'',''YYYYMMDD''),''Q'') QUARTER, company_code as burks , ''S0'' AS L1,
          SCORE*(SELECT percentage from VRTN_MAP020_RATE_INDEX where INDEX_KEY =''QUALITY'' AND TYPE =''QB'' AND LEVEL_S = ''L1'') GRADE_L1,''Q0'' AS L2,
          SCORE*(SELECT percentage from VRTN_MAP020_RATE_INDEX where INDEX_KEY =''QUALITY'' AND TYPE =''QB'' AND LEVEL_S = ''L2'') GRADE_L2,''QB'' AS L3,
	      SCORE*(SELECT percentage from VRTN_MAP020_RATE_INDEX where INDEX_KEY =''QUALITY'' AND TYPE =''QB'' AND LEVEL_S = ''L3'') GRADE_L3,''QB'' AS L4,
	      SCORE AS GRADE_L4
     FROM (SELECT SITE,MTL_GROUP AS MATGROUP,substr(yyyymm,1,4) as YYYY,  yyyymm,substr(yyyymm,5,2) as MM, vendor_code,
                  DECODE(SIGN((100-sum(SCORE))),-1,0,(100-sum(SCORE))) as SCORE ,COMPANY_CODE
             FROM VRTN_PDM_DDR_DATA a,PLD_KPI_PN_MTLGRP_SUBGRP b
            WHERE a.PART = b.PART_NO
              and YYYYMM  ='|| YYYYMM ||'
            GROUP BY SITE,substr(yyyymm,1,4),  yyyymm,substr(yyyymm,5,2), vendor_code,COMPANY_CODE,MTL_GROUP)';

   Commit;
EXCEPTION
   When OTHERS Then
    --有錯誤產生則寄mail
    cErrorText := SQLERRM();
    MAIL_FILE_BIDBDBADMIN(in_to_name => 'shuchin_lin@usiglobal.com', subject => '[VRT] PL/SQL VRTN015_PDM_DDR ERROR', message => '[VRTN015_PDM_DDR], The tracepoint is  ' || iTracePoint || ' and ErrorText= ' || cErrorText || ' and YYYYMM= ' || YYYYMM) ;


END PLSQL_VRTN015_PDM_DDR;
/

