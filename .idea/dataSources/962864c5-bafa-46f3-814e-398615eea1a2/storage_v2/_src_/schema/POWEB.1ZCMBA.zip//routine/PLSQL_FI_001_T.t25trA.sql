create PROCEDURE PLSQL_FI_001_T
  --f_YYYYMMDD in VARCHAR2

is
 iTracePoint  integer ;
 cErrorText varchar2(500);
 vYYYYMMDD varchar2(8);
 vYYYYMM varchar2(6);
 vYYYY varchar2(4);
 vMM varchar2(2);
 vDD varchar2(2);
 vDAYS_A varchar2(2);
 iDAYS_T integer;
 iDAYS_A integer;
 iRATE number(3,2);
 vPROCEE_YYYYMMDD varchar2(8);
BEGIN

  iTracePoint := '100';

  INSERT INTO Z_TABLE_SAM (WIP_DATE,DEPARTMENT) VALUES ('20070501','23');


   Commit;
EXCEPTION
   When OTHERS Then
    --有錯誤產生則寄mail
    cErrorText := SQLERRM();
    MAIL_FILE_BIDBDBADMIN(in_to_name => 'sam_chen@ms.usi.com.tw', subject => '[VRT] PL/SQL PLSQL_PP_MFG_VALUE ERROR', message => '[PLSQL_PP_MFG_VALUE], The tracepoint is  ' || iTracePoint || ' and ErrorText= ' || cErrorText) ;


END PLSQL_FI_001_T;
/

