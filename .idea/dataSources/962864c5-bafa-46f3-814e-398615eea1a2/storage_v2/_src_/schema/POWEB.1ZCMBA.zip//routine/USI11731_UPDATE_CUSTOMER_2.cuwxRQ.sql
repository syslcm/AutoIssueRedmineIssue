create PROCEDURE       USI11731_UPDATE_CUSTOMER_2 (
  inCompany  in VARCHAR2,
  t_Period in VARCHAR2
  --2008/9/17 Create to Process get Amount in Local/USD/TWD
  --Trigger by PNL2_BAD_DEPT_UPLOAD.JSP
)
AUTHID DEFINER
is
   


 BEGIN

     update KPI_SAP001_COPA_TRX_TEMP set PDM_CUSTOMER2 = NULL  where pdm_customer2 is not null;
     COMMIT;
     
      update KPI_SAP001_COPA_TRX_TEMP set pdm_customer2 =      (
            select distinct END_CUSTOMER_ID
            from KPI_MAP004_5_COMPOSITE_END_CUS
            where COMPANY_CODE = KPI_SAP001_COPA_TRX_TEMP.COMPANY_CODE
            and PROFIT_CENTER = KPI_SAP001_COPA_TRX_TEMP.PROFIT_CENTER
            --and MTL_GROUP = KPI_SAP001_COPA_TRX_TEMP.MTL_GROUP
            and CUSTOMER_ID = KPI_SAP001_COPA_TRX_TEMP.CUSTOMER_ID
            and SHIP_TO_PARTY = KPI_SAP001_COPA_TRX_TEMP.SHIP_TO_PARTY
            --AND SHIP_TO_PARTY IS NOT NULL
            --AND PRODUCT_FLAG IS NOT NULL
            and PRODUCT_NO = KPI_SAP001_COPA_TRX_TEMP.PART_NO
            and START_DATE <= TO_DATE(KPI_SAP001_COPA_TRX_TEMP.POSTING_DATE,'YYYYMMDD')
            and END_DATE >= TO_DATE(KPI_SAP001_COPA_TRX_TEMP.POSTING_DATE,'YYYYMMDD')
        )
    Where  pdm_customer2 is Null
      AND  MTL_TYPE <> 'RAW';
    Commit;
  
    
END USI11731_UPDATE_CUSTOMER_2;
/

