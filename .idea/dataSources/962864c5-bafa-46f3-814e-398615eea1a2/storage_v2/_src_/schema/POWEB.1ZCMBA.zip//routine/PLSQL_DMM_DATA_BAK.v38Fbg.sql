create PROCEDURE "PLSQL_DMM_DATA_BAK" (
  b_YYYYMMDD    in VARCHAR2
)
/*
*/
is
	iTracePoint           integer ;
	cErrorText            varchar2(500) ;
	cCHK1                 varchar2(100) ;
	cCHK2                 varchar2(100) ;
	b_YYYYWK              varchar2(6);
BEGIN
	iTracePoint := 0;
	cErrorText := ' ';
	cCHK1 := ' ';
	cCHK2 := ' ';

	b_YYYYWK := 'X';
	BEGIN
		select * into b_YYYYWK from (
			select YYYYWW from DIMENSION_DATE where DATE_KEY = b_YYYYMMDD
		) where rownum <= 1;
	EXCEPTION
		WHEN OTHERS THEN
			b_YYYYWK := 'X';
	END;

  if b_YYYYMMDD > '20120101' or b_YYYYWK = 'X' then
	MAIL_FILE_BIDBDBADMIN(in_to_name=>'minhorng@ms.usi.com.tw',subject   => '[DMM]PL/SQL PLSQL_DMM_DATA_BAK ERROR' , message => '[PLSQL_DMM_DATA_BAK], DATE ErrorText=' || b_YYYYMMDD) ;
  else
	-- DMM_UPL001_SELLING
	iTracePoint := 100;
	cCHK1 := ' ';
	cCHK2 := ' ';
	for REC1 in (
		select distinct COMPANY_CODE from DMM_UPL001_SELLING where TO_DATE <= b_YYYYMMDD
	) loop
		iTracePoint := 101;
		cCHK2 := REC1.COMPANY_CODE;
		/*
		insert into DMM_UPL001_SELLING_BK
			select * from DMM_UPL001_SELLING
			where COMPANY_CODE = REC1.COMPANY_CODE and TO_DATE <= b_YYYYMMDD;
		commit;
		*/
		iTracePoint := 102;
		delete from DMM_UPL001_SELLING where COMPANY_CODE = REC1.COMPANY_CODE and TO_DATE <= b_YYYYMMDD;
		commit;
	end loop;
	-- DMM_SAP001_BOM
	iTracePoint := 110;
	cCHK1 := ' ';
	cCHK2 := ' ';
	for REC1 in (
		select distinct COMPANY_CODE, PERIOD from DMM_SAP001_BOM where PERIOD <= b_YYYYWK
	) loop
		iTracePoint := 111;
		cCHK2 := REC1.COMPANY_CODE || '-' || REC1.PERIOD;
		/*
		insert into DMM_SAP001_BOM_BK
			select * from DMM_SAP001_BOM
			where COMPANY_CODE = REC1.COMPANY_CODE and PERIOD = REC1.PERIOD;
		commit;
		*/
		iTracePoint := 112;
		delete from DMM_SAP001_BOM where COMPANY_CODE = REC1.COMPANY_CODE and PERIOD = REC1.PERIOD;
		commit;
	end loop;
	-- DMM_SAP002_INT_PART
	iTracePoint := 120;
	cCHK1 := ' ';
	cCHK2 := ' ';
	for REC1 in (
		select distinct COMPANY_CODE, PERIOD from DMM_SAP002_INT_PART where PERIOD <= b_YYYYWK
	) loop
		iTracePoint := 121;
		cCHK2 := REC1.COMPANY_CODE || '-' || REC1.PERIOD;
		/*
		insert into DMM_SAP002_INT_PART_BK
			select * from DMM_SAP002_INT_PART
			where COMPANY_CODE = REC1.COMPANY_CODE and PERIOD = REC1.PERIOD;
		commit;
		*/
		iTracePoint := 122;
		delete from DMM_SAP002_INT_PART where COMPANY_CODE = REC1.COMPANY_CODE and PERIOD = REC1.PERIOD;
		commit;
	end loop;
	-- DMM_SAP003_QTA_INF
	iTracePoint := 130;
	cCHK1 := ' ';
	cCHK2 := ' ';
	for REC1 in (
		select distinct COMPANY_CODE, PERIOD from DMM_SAP003_QTA_INF where PERIOD <= b_YYYYWK
	) loop
		iTracePoint := 131;
		cCHK2 := REC1.COMPANY_CODE || '-' || REC1.PERIOD;
		/*
		insert into DMM_SAP003_QTA_INF_BK
			select * from DMM_SAP003_QTA_INF
			where COMPANY_CODE = REC1.COMPANY_CODE and PERIOD = REC1.PERIOD;
		commit;
		*/
		iTracePoint := 132;
		delete from DMM_SAP003_QTA_INF where COMPANY_CODE = REC1.COMPANY_CODE and PERIOD = REC1.PERIOD;
		commit;
	end loop;
	-- DMM_SAP004_PO
	iTracePoint := 140;
	cCHK1 := ' ';
	cCHK2 := ' ';
	for REC1 in (
		select distinct COMPANY_CODE, PERIOD from DMM_SAP004_PO where PERIOD <= b_YYYYWK
	) loop
		iTracePoint := 141;
		cCHK2 := REC1.COMPANY_CODE || '-' || REC1.PERIOD;
		/*
		insert into DMM_SAP004_PO_BK
			select * from DMM_SAP004_PO
			where COMPANY_CODE = REC1.COMPANY_CODE and PERIOD = REC1.PERIOD;
		commit;
		*/
		iTracePoint := 142;
		delete from DMM_SAP004_PO where COMPANY_CODE = REC1.COMPANY_CODE and PERIOD = REC1.PERIOD;
		commit;
	end loop;
	-- DMM_SAP005_MSG
	iTracePoint := 150;
	cCHK1 := ' ';
	cCHK2 := ' ';
	for REC1 in (
		select distinct COMPANY_CODE, PERIOD from DMM_SAP005_MSG where PERIOD <= b_YYYYWK
	) loop
		iTracePoint := 151;
		cCHK2 := REC1.COMPANY_CODE || '-' || REC1.PERIOD;
		/*
		insert into DMM_SAP005_MSG_BK
			select * from DMM_SAP005_MSG
			where COMPANY_CODE = REC1.COMPANY_CODE and PERIOD = REC1.PERIOD;
		commit;
		*/
		iTracePoint := 152;
		delete from DMM_SAP005_MSG where COMPANY_CODE = REC1.COMPANY_CODE and PERIOD = REC1.PERIOD;
		commit;
	end loop;
	-- DMM_SAP006_FGFCST
	iTracePoint := 160;
	cCHK1 := ' ';
	cCHK2 := ' ';
	for REC1 in (
		select distinct COMPANY_CODE, PERIOD from DMM_SAP006_FGFCST where PERIOD <= b_YYYYWK
	) loop
		iTracePoint := 161;
		cCHK2 := REC1.COMPANY_CODE || '-' || REC1.PERIOD;
		/*
		insert into DMM_SAP006_FGFCST_BK
			select * from DMM_SAP006_FGFCST
			where COMPANY_CODE = REC1.COMPANY_CODE and PERIOD = REC1.PERIOD;
		commit;
		*/
		iTracePoint := 162;
		delete from DMM_SAP006_FGFCST where COMPANY_CODE = REC1.COMPANY_CODE and PERIOD = REC1.PERIOD;
		commit;
	end loop;
	-- DMM_SAP007_FG101
	iTracePoint := 170;
	cCHK1 := ' ';
	cCHK2 := ' ';
	for REC1 in (
		select distinct COMPANY_CODE, DATE_KEY from DMM_SAP007_FG101 where DATE_KEY <= b_YYYYMMDD
	) loop
		iTracePoint := 171;
		cCHK2 := REC1.COMPANY_CODE || '-' || REC1.DATE_KEY;
		/*
		insert into DMM_SAP007_FG101_BK
			select * from DMM_SAP007_FG101
			where COMPANY_CODE = REC1.COMPANY_CODE and DATE_KEY = REC1.DATE_KEY;
		commit;
		*/
		iTracePoint := 172;
		delete from DMM_SAP007_FG101 where COMPANY_CODE = REC1.COMPANY_CODE and DATE_KEY = REC1.DATE_KEY;
		commit;
	end loop;
	-- DMM_RPT001_FG_W
	iTracePoint := 210;
	cCHK1 := ' ';
	cCHK2 := ' ';
	for REC1 in (
		select distinct COMPANY_CODE, PERIOD from DMM_RPT001_FG_W where PERIOD <= b_YYYYWK
	) loop
		iTracePoint := 211;
		cCHK2 := REC1.COMPANY_CODE || '-' || REC1.PERIOD;
		/*
		insert into DMM_RPT001_FG_W_BK
			select * from DMM_RPT001_FG_W
			where COMPANY_CODE = REC1.COMPANY_CODE and PERIOD = REC1.PERIOD;
		commit;
		*/
		iTracePoint := 212;
		delete from DMM_RPT001_FG_W where COMPANY_CODE = REC1.COMPANY_CODE and PERIOD = REC1.PERIOD;
		commit;
	end loop;
	-- DMM_RPT002_BOM_W
	iTracePoint := 220;
	cCHK1 := ' ';
	cCHK2 := ' ';
	for REC1 in (
		select distinct COMPANY_CODE, PERIOD from DMM_RPT002_BOM_W where PERIOD <= b_YYYYWK
	) loop
		iTracePoint := 221;
		cCHK2 := REC1.COMPANY_CODE || '-' || REC1.PERIOD;
		/*
		insert into DMM_RPT002_BOM_W_BK
			select * from DMM_RPT002_BOM_W
			where COMPANY_CODE = REC1.COMPANY_CODE and PERIOD = REC1.PERIOD;
		commit;
		*/
		iTracePoint := 222;
		delete from DMM_RPT002_BOM_W where COMPANY_CODE = REC1.COMPANY_CODE and PERIOD = REC1.PERIOD;
		commit;
	end loop;
	-- 改先清 DMM_RPT004_BOMMAC_D 在處理 DMM_RPT003_FG_D
	-- DMM_RPT004_BOMMAC_D
	iTracePoint := 240;
	cCHK1 := ' ';
	cCHK2 := ' ';
	insert into DMM_RPT004_BOMMAC_D_TMP2 ( DATE_KEY, COMPANY_CODE, PLANT, FG )
		select DATE_KEY, COMPANY_CODE, PLANT, FG from DMM_RPT004_BOMMAC_D
		where DATE_KEY <= b_YYYYMMDD
		group by DATE_KEY, COMPANY_CODE, PLANT, FG;
	iTracePoint := 242;
	for rec2 in (
		--select DATE_KEY, COMPANY_CODE, PLANT, FG
		--from DMM_RPT003_FG_D
		--where DATE_KEY <= b_YYYYMMDD
		--group by DATE_KEY, COMPANY_CODE, PLANT, FG
		select DATE_KEY, COMPANY_CODE, PLANT, FG from DMM_RPT004_BOMMAC_D_TMP2
	) loop
		iTracePoint := 245;
		cCHK2 := rec2.COMPANY_CODE || ':' || rec2.PLANT || ':' || rec2.FG || ':' || rec2.DATE_KEY;
		iTracePoint := 248;
		delete from DMM_RPT004_BOMMAC_D
			where DATE_KEY = rec2.DATE_KEY and COMPANY_CODE = rec2.COMPANY_CODE
			and PLANT = rec2.PLANT and FG = rec2.FG;
		commit;
	end loop;
	-- DMM_RPT003_FG_D
	iTracePoint := 230;
	cCHK1 := ' ';
	cCHK2 := ' ';
	for REC1 in (
		select distinct COMPANY_CODE, DATE_KEY from DMM_RPT003_FG_D where DATE_KEY <= b_YYYYMMDD
	) loop
		iTracePoint := 231;
		cCHK2 := REC1.COMPANY_CODE || '-' || REC1.DATE_KEY;
		/*
		insert into DMM_RPT003_FG_D_BK
			select * from DMM_RPT003_FG_D
			where COMPANY_CODE = REC1.COMPANY_CODE and DATE_KEY = REC1.DATE_KEY;
		commit;
		*/
		iTracePoint := 232;
		delete from DMM_RPT003_FG_D where COMPANY_CODE = REC1.COMPANY_CODE and DATE_KEY = REC1.DATE_KEY;
		commit;
	end loop;
	--
  end if;

	iTracePoint := 300;
	DBMS_STATS.GATHER_TABLE_STATS
	(
		ownname => 'POWEB',
		tabname => 'DMM_UPL001_SELLING',
		estimate_percent => DBMS_STATS.AUTO_SAMPLE_SIZE,
		method_opt => NULL,
		cascade => TRUE
	);
	iTracePoint := 301;
	DBMS_STATS.GATHER_TABLE_STATS
	(
		ownname => 'POWEB',
		tabname => 'DMM_SAP001_BOM',
		estimate_percent => DBMS_STATS.AUTO_SAMPLE_SIZE,
		method_opt => NULL,
		cascade => TRUE
	);
	iTracePoint := 302;
	DBMS_STATS.GATHER_TABLE_STATS
	(
		ownname => 'POWEB',
		tabname => 'DMM_SAP002_INT_PART',
		estimate_percent => DBMS_STATS.AUTO_SAMPLE_SIZE,
		method_opt => NULL,
		cascade => TRUE
	);
	iTracePoint := 303;
	DBMS_STATS.GATHER_TABLE_STATS
	(
		ownname => 'POWEB',
		tabname => 'DMM_SAP003_QTA_INF',
		estimate_percent => DBMS_STATS.AUTO_SAMPLE_SIZE,
		method_opt => NULL,
		cascade => TRUE
	);
	iTracePoint := 304;
	DBMS_STATS.GATHER_TABLE_STATS
	(
		ownname => 'POWEB',
		tabname => 'DMM_SAP004_PO',
		estimate_percent => DBMS_STATS.AUTO_SAMPLE_SIZE,
		method_opt => NULL,
		cascade => TRUE
	);
	iTracePoint := 305;
	DBMS_STATS.GATHER_TABLE_STATS
	(
		ownname => 'POWEB',
		tabname => 'DMM_SAP005_MSG',
		estimate_percent => DBMS_STATS.AUTO_SAMPLE_SIZE,
		method_opt => NULL,
		cascade => TRUE
	);
	iTracePoint := 306;
	DBMS_STATS.GATHER_TABLE_STATS
	(
		ownname => 'POWEB',
		tabname => 'DMM_SAP006_FGFCST',
		estimate_percent => DBMS_STATS.AUTO_SAMPLE_SIZE,
		method_opt => NULL,
		cascade => TRUE
	);
	iTracePoint := 307;
	DBMS_STATS.GATHER_TABLE_STATS
	(
		ownname => 'POWEB',
		tabname => 'DMM_SAP007_FG101',
		estimate_percent => DBMS_STATS.AUTO_SAMPLE_SIZE,
		method_opt => NULL,
		cascade => TRUE
	);
	iTracePoint := 308;
	DBMS_STATS.GATHER_TABLE_STATS
	(
		ownname => 'POWEB',
		tabname => 'DMM_RPT001_FG_W',
		estimate_percent => DBMS_STATS.AUTO_SAMPLE_SIZE,
		method_opt => NULL,
		cascade => TRUE
	);
	iTracePoint := 309;
	DBMS_STATS.GATHER_TABLE_STATS
	(
		ownname => 'POWEB',
		tabname => 'DMM_RPT002_BOM_W',
		estimate_percent => DBMS_STATS.AUTO_SAMPLE_SIZE,
		method_opt => NULL,
		cascade => TRUE
	);
	iTracePoint := 310;
	DBMS_STATS.GATHER_TABLE_STATS
	(
		ownname => 'POWEB',
		tabname => 'DMM_RPT003_FG_D',
		estimate_percent => DBMS_STATS.AUTO_SAMPLE_SIZE,
		method_opt => NULL,
		cascade => TRUE
	);
	iTracePoint := 311;
	DBMS_STATS.GATHER_TABLE_STATS
	(
		ownname => 'POWEB',
		tabname => 'DMM_RPT004_BOMMAC_D',
		estimate_percent => DBMS_STATS.AUTO_SAMPLE_SIZE,
		method_opt => NULL,
		cascade => TRUE
	);
	commit;
EXCEPTION
  WHEN OTHERS THEN
    cErrorText := trim(cCHK2) || '>' || SQLERRM() ;
	rollback;
    MAIL_FILE_BIDBDBADMIN(in_to_name=>'minhorng@ms.usi.com.tw',subject   => '[DMM]PL/SQL PLSQL_DMM_DATA_BAK ERROR' , message => '[PLSQL_DMM_DATA_BAK], The tracepoint is  ' || to_char(iTracePoint) || ' and ErrorText=' || cErrorText) ;
End PLSQL_DMM_DATA_BAK;
/

