create PROCEDURE PLSQL_SAP_ZBPRD392 (
	inCompany  in VARCHAR2,
	f_YYYYMMDD in VARCHAR2,
	t_YYYYMMDD in VARCHAR2
)
AUTHID DEFINER
is
	iTracePoint                varchar2(10);
	cErrorText                 varchar2(500);
	nCREATE_DATE               varchar2(8);
BEGIN
	iTracePoint := '010';
	select max(CREATE_DATE) into nCREATE_DATE
	from SAP_ZBPRD392_DATA_T
	where COMPANY_CODE = inCompany
	and CREATE_DATE = to_char(sysdate,'yyyymmdd');

	iTracePoint := '020';
	delete from SAP_ZBPRD392_DATA where COMPANY_CODE = inCompany and CREATE_DATE = nCREATE_DATE;
	commit;

	iTracePoint := '030';
	insert into SAP_ZBPRD392_DATA
	select * from SAP_ZBPRD392_DATA_T
	where COMPANY_CODE = inCompany
	and CREATE_DATE = nCREATE_DATE;
	commit;

EXCEPTION
	When OTHERS Then
		--有錯誤產生則寄mail
		cErrorText := SQLERRM();
		MAIL_FILE_BIDBDBADMIN(in_to_name => 'minhorng@ms.usi.com.tw', subject => '[BI] PL/SQL PLSQL_SAP_ZBPRD392 ERROR:' || inCompany, message => '[PLSQL_SAP_ZBPRD392], The tracepoint is  ' || iTracePoint || ' and ErrorText= ' || cErrorText) ;
END PLSQL_SAP_ZBPRD392;
/

