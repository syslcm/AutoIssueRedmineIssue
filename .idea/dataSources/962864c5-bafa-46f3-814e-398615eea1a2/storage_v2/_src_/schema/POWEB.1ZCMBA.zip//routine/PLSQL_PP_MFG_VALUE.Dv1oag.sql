create PROCEDURE PLSQL_PP_MFG_VALUE
  --f_YYYYMMDD in VARCHAR2

is
 iTracePoint  integer ;
 cErrorText varchar2(500);
 vYYYYMMDD varchar2(8);
 vYYYYMM varchar2(6);
 vYYYY varchar2(4);
 vMM varchar2(2);
 vDD varchar2(2);
 vDAYS_A varchar2(2);
 iDAYS_T integer;
 iDAYS_A integer;
 iRATE number(3,2);
 vPROCEE_YYYYMMDD varchar2(8);
BEGIN
  iTracePoint := '000';


  vPROCEE_YYYYMMDD  :=  to_char(sysdate,'YYYYMMDD');
  vYYYYMM := substr(vPROCEE_YYYYMMDD,1,6);
  vYYYY := substr(vPROCEE_YYYYMMDD,1,4);
  vMM := substr(vPROCEE_YYYYMMDD,5,2);
  vDD := substr(vPROCEE_YYYYMMDD,7,2);
  --vYYYY := substr(f_YYYYMMDD,1,4);
  --vMM := substr(f_YYYYMMDD,5,2);
  --vDD := substr(f_YYYYMMDD,7,2);
  iDAYS_T := to_number(vDD);

  --delete from PP_MFG_VALUE_DAYS where yyyymmdd =  vPROCEE_YYYYMMDD;
  delete from PP_MFG_VALUE_DAYS where yyyymm =  vYYYYMM;
  commit;

  iTracePoint := '100';

  select to_number(max(DD)) into iDAYS_A from dimension_date where yyyy = vYYYY and mm = vMM;

  iRATE := iDAYS_T / iDAYS_A;
  vDAYS_A := to_char(iDAYS_A);

  iTracePoint := '200';

  INSERT INTO PP_MFG_VALUE_DAYS (YYYYMM,YYYY,MM,DD,DAYS,RATE) VALUES (vYYYYMM,vYYYY,vMM,vDD,vDAYS_A,iRATE);


   Commit;
EXCEPTION
   When OTHERS Then
    --有錯誤產生則寄mail
    cErrorText := SQLERRM();
    MAIL_FILE_BIDBDBADMIN(in_to_name => 'sam_chen@ms.usi.com.tw', subject => '[VRT] PL/SQL PLSQL_PP_MFG_VALUE ERROR', message => '[PLSQL_PP_MFG_VALUE], The tracepoint is  ' || iTracePoint || ' and ErrorText= ' || cErrorText) ;


END PLSQL_PP_MFG_VALUE;
/

