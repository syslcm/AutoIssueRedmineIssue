create PROCEDURE       PNL3_PLS002_COGS_S01_TRX_V1 (
  --inCOMPANY       in VARCHAR2,
  inPeriod        in VARCHAR2,
  inPROFIT_CENTER in VARCHAR2,
  inAMT           in Number,
  inGLAccount     in VARCHAR
  --2008/9/17 Create to Process get Amount in Local/USD/TWD
  --Trigger by PNL2_BAD_DEPT_UPLOAD.JSP
)
AUTHID DEFINER
is
--2008/11/7 有發現  SUM(NET_REVENUE) <> 0 OR SUM(NET_COGS)  <> 0 條件成立但dm/dl/oh卻有值的戕況,因此不加入此條件
-- 在INSERT進資料庫時再排除金額=0的資料
     
     a_Rate          number(20,10);
     a_TRate         number(20,10);
     a_COUNTER       integer;
     --i_COUNTER       integer;
     a_ENDCUSTOMER   PNL3_TRX001_COPA.END_CUSTOMER_ID%TYPE;
     a_NET_REVENUE   PNL3_TRX001_COPA.AMT_TWD%TYPE;
     a_REVENUE_LOCAL PNL3_TRX001_COPA.AMT_TWD%TYPE;
     a_REVENUE_TWD   PNL3_TRX001_COPA.AMT_TWD%TYPE;
     a_REVENUE_USD   PNL3_TRX001_COPA.AMT_TWD%TYPE;
     a_COGS_DM_LOCAL PNL3_TRX001_COPA.AMT_TWD%TYPE;
     a_COGS_DM_TWD   PNL3_TRX001_COPA.AMT_TWD%TYPE;
     a_COGS_DM_USD   PNL3_TRX001_COPA.AMT_TWD%TYPE;
     a_COGS_DL_LOCAL PNL3_TRX001_COPA.AMT_TWD%TYPE;
     a_COGS_DL_TWD   PNL3_TRX001_COPA.AMT_TWD%TYPE;
     a_COGS_DL_USD   PNL3_TRX001_COPA.AMT_TWD%TYPE;
     a_COGS_OH_LOCAL PNL3_TRX001_COPA.AMT_TWD%TYPE;
     a_COGS_OH_TWD   PNL3_TRX001_COPA.AMT_TWD%TYPE;
     a_COGS_OH_USD   PNL3_TRX001_COPA.AMT_TWD%TYPE;
     
 BEGIN
   

    a_RATE  := 0;
    IF inAMT = 0 THEN --沒有營收,全部歸others
        a_RATE := 1;
        FOR REC2 in(
            SELECT COMPANY_CODE , CUSTOMER_ID AS BILL_TO_PARTY, SHIP_TO_PARTY, MTL_GROUP, PART_NO ,PLANT_CODE,MTL_TYPE,
                SUM(NET_REVENUE) NET_REVENUE , SUM(NET_REVENUE_USD) NET_REVENUE_USD, SUM(NET_REVENUE_TWD) NET_REVENUE_TWD,
                              SUM(COGS_MB) COGS_MB,SUM(COGS_MB_USD) COGS_MB_USD,SUM(COGS_MB_TWD) COGS_MB_TWD,
                              SUM(COGS_LB) COGS_LB,SUM(COGS_LB_USD) COGS_LB_USD,SUM(COGS_LB_TWD) COGS_LB_TWD,
                              SUM(COGS_OB) COGS_OB,SUM(COGS_OB_USD) COGS_OB_USD,SUM(COGS_OB_TWD) COGS_OB_TWD
                              --(SELECT TRIM(END_CUSTOMER_NAME) FROM CEP_MAP009_PARTNO_CUSTOMER where TRIM(FG_MATERIAL_NO) = TRIM(PART_NO) and LAST_MODIFY_DATE <= SYSDATE )
                              --END_CUSTOMER_ID
              FROM KPI_SAP001_COPA_TRX
             WHERE  PERIOD = inPeriod 
               AND  PROFIT_CENTER = inPROFIT_CENTER
               AND    ( NET_REVENUE <> 0 OR NET_COGS <>  0)
               AND    RELATED_PARTY <> 'Y'
               --AND    PART_NO IS NULL
               AND COST_ELEMENT = inGLAccount
          GROUP BY COMPANY_CODE,PROFIT_CENTER,PERIOD,CUSTOMER_ID,SHIP_TO_PARTY,MTL_GROUP,PART_NO,PLANT_CODE,MTL_TYPE) Loop
            --HAVING ( SUM(NET_REVENUE) <> 0 OR SUM(NET_COGS)  <> 0 )
           a_ENDCUSTOMER := NULL;
           a_RATE := 1;
           IF inPROFIT_CENTER = '0000000034' THEN
             a_ENDCUSTOMER := 'UABIT''S CUST';
                IF REC2.NET_REVENUE <> 0 THEN
                   INSERT INTO PNL3_TRX002_GLACCOUNT (
                       COMPANY_CODE         ,PERIOD       ,PROFIT_CENTER   ,COST_ELEMENT , BILL_TO_PARTY, SHIP_TO_PARTY, MTL_GROUP, PART_NO,PLANT_CODE,
                       END_CUSTOMER_ID      ,R_KIND       ,AREA1           ,AREA2        , MTL_TYPE,
                       AREA3                ,AMT_LOCAL    ,AMT_TWD         ,AMT_USD      , 
                       CREATE_DATE          ,SOURCE
                   ) VALUES(
                       REC2.COMPANY_CODE     ,inPeriod     ,inPROFIT_CENTER,inGLAccount   ,REC2.BILL_TO_PARTY, REC2.SHIP_TO_PARTY, REC2.MTL_GROUP, REC2.PART_NO,REC2.PLANT_CODE,
                       a_ENDCUSTOMER  ,'PL01'       ,'1'               ,'1'            ,REC2.MTL_TYPE,
                       '0'                    ,round(REC2.NET_REVENUE * a_RATE , 5)         ,
                       round(REC2.NET_REVENUE_TWD * a_RATE , 5)  ,
                       round(REC2.NET_REVENUE_USD * a_RATE , 5)  , SYSDATE             ,'2'
                   );
                   commit;
                 END IF;
               
                 IF REC2.COGS_MB <> 0 THEN
                   INSERT INTO PNL3_TRX002_GLACCOUNT (
                      COMPANY_CODE         ,PERIOD       ,PROFIT_CENTER   ,COST_ELEMENT ,BILL_TO_PARTY, SHIP_TO_PARTY, MTL_GROUP, PART_NO,PLANT_CODE,
                      END_CUSTOMER_ID      ,R_KIND       ,AREA1           ,AREA2        ,MTL_TYPE,
                      AREA3                ,AMT_LOCAL    ,AMT_TWD         ,AMT_USD      , 
                      CREATE_DATE          ,SOURCE
                   ) VALUES(
                      REC2.COMPANY_CODE     ,inPeriod     ,inPROFIT_CENTER,inGLAccount   ,REC2.BILL_TO_PARTY, REC2.SHIP_TO_PARTY, REC2.MTL_GROUP, REC2.PART_NO,REC2.PLANT_CODE,
                      a_ENDCUSTOMER  ,'PL01'       ,'2'               ,'2'            ,REC2.MTL_TYPE,
                      '0'                    ,round(REC2.COGS_MB * a_RATE , 5)         ,
                      round(REC2.COGS_MB_TWD * a_RATE , 5)  ,
                      round(REC2.COGS_MB_USD * a_RATE , 5)  , SYSDATE                  ,'2'
                   );
                   commit;
                 END IF;
               
                 IF REC2.COGS_LB <> 0 THEN
                   INSERT INTO PNL3_TRX002_GLACCOUNT (
                       COMPANY_CODE         ,PERIOD       ,PROFIT_CENTER   ,COST_ELEMENT ,BILL_TO_PARTY, SHIP_TO_PARTY, MTL_GROUP, PART_NO,PLANT_CODE,
                       END_CUSTOMER_ID      ,R_KIND       ,AREA1           ,AREA2        ,MTL_TYPE,
                       AREA3                ,AMT_LOCAL    ,AMT_TWD         ,AMT_USD      , 
                       CREATE_DATE          ,SOURCE
                   ) VALUES(
                       REC2.COMPANY_CODE     ,inPeriod     ,inPROFIT_CENTER,inGLAccount   ,REC2.BILL_TO_PARTY, REC2.SHIP_TO_PARTY, REC2.MTL_GROUP, REC2.PART_NO,REC2.PLANT_CODE,
                       a_ENDCUSTOMER  ,'PL01'       ,'2'               ,'3'            ,REC2.MTL_TYPE,
                       '0'                    ,round(REC2.COGS_LB * a_RATE , 5)         ,
                       round(REC2.COGS_LB_TWD * a_RATE , 5)  ,
                       round(REC2.COGS_LB_USD * a_RATE , 5)  , SYSDATE                  ,'2'
                   );
                   commit;
                 END IF;
               
                 IF REC2.COGS_OB <> 0 THEN
                   INSERT INTO PNL3_TRX002_GLACCOUNT (
                       COMPANY_CODE         ,PERIOD       ,PROFIT_CENTER   ,COST_ELEMENT ,BILL_TO_PARTY, SHIP_TO_PARTY, MTL_GROUP, PART_NO,PLANT_CODE,
                       END_CUSTOMER_ID      ,R_KIND       ,AREA1           ,AREA2        ,MTL_TYPE,
                       AREA3                ,AMT_LOCAL    ,AMT_TWD         ,AMT_USD      ,
                       CREATE_DATE          ,SOURCE
                   ) VALUES(
                       REC2.COMPANY_CODE     ,inPeriod     ,inPROFIT_CENTER,inGLAccount   ,REC2.BILL_TO_PARTY, REC2.SHIP_TO_PARTY, REC2.MTL_GROUP, REC2.PART_NO,REC2.PLANT_CODE,
                       a_ENDCUSTOMER  ,'PL01'       ,'2'               ,'4'            , REC2.MTL_TYPE,
                       '0'                    ,round(REC2.COGS_OB * a_RATE , 5)         ,
                       round(REC2.COGS_OB_TWD * a_RATE , 5)  ,
                       round(REC2.COGS_OB_USD * a_RATE , 5)  , SYSDATE                  ,'2'
                   );
                   commit;
                 END IF;
           ELSIF SUBSTR(inPROFIT_CENTER,1,9) = '000000009' THEN
             IF  SUBSTR(REC2.COMPANY_CODE,1,1) = '9' THEN
               a_ENDCUSTOMER := '投資公司';
                IF REC2.NET_REVENUE <> 0 THEN
                   INSERT INTO PNL3_TRX002_GLACCOUNT (
                       COMPANY_CODE         ,PERIOD       ,PROFIT_CENTER   ,COST_ELEMENT , BILL_TO_PARTY, SHIP_TO_PARTY, MTL_GROUP, PART_NO,PLANT_CODE,
                       END_CUSTOMER_ID      ,R_KIND       ,AREA1           ,AREA2        , MTL_TYPE,
                       AREA3                ,AMT_LOCAL    ,AMT_TWD         ,AMT_USD      , 
                       CREATE_DATE          ,SOURCE
                   ) VALUES(
                       REC2.COMPANY_CODE     ,inPeriod     ,inPROFIT_CENTER,inGLAccount   ,REC2.BILL_TO_PARTY, REC2.SHIP_TO_PARTY, REC2.MTL_GROUP, REC2.PART_NO,REC2.PLANT_CODE,
                       a_ENDCUSTOMER  ,'PL01'       ,'1'               ,'1'            ,REC2.MTL_TYPE,
                       '0'                    ,round(REC2.NET_REVENUE * a_RATE , 5)         ,
                       round(REC2.NET_REVENUE_TWD * a_RATE , 5)  ,
                       round(REC2.NET_REVENUE_USD * a_RATE , 5)  , SYSDATE             ,'2'
                   );
                   commit;
                 END IF;
               
                 IF REC2.COGS_MB <> 0 THEN
                   INSERT INTO PNL3_TRX002_GLACCOUNT (
                      COMPANY_CODE         ,PERIOD       ,PROFIT_CENTER   ,COST_ELEMENT ,BILL_TO_PARTY, SHIP_TO_PARTY, MTL_GROUP, PART_NO,PLANT_CODE,
                      END_CUSTOMER_ID      ,R_KIND       ,AREA1           ,AREA2        ,MTL_TYPE,
                      AREA3                ,AMT_LOCAL    ,AMT_TWD         ,AMT_USD      , 
                      CREATE_DATE          ,SOURCE
                   ) VALUES(
                      REC2.COMPANY_CODE     ,inPeriod     ,inPROFIT_CENTER,inGLAccount   ,REC2.BILL_TO_PARTY, REC2.SHIP_TO_PARTY, REC2.MTL_GROUP, REC2.PART_NO,REC2.PLANT_CODE,
                      a_ENDCUSTOMER  ,'PL01'       ,'2'               ,'2'            ,REC2.MTL_TYPE,
                      '0'                    ,round(REC2.COGS_MB * a_RATE , 5)         ,
                      round(REC2.COGS_MB_TWD * a_RATE , 5)  ,
                      round(REC2.COGS_MB_USD * a_RATE , 5)  , SYSDATE                  ,'2'
                   );
                   commit;
                 END IF;
               
                 IF REC2.COGS_LB <> 0 THEN
                   INSERT INTO PNL3_TRX002_GLACCOUNT (
                       COMPANY_CODE         ,PERIOD       ,PROFIT_CENTER   ,COST_ELEMENT ,BILL_TO_PARTY, SHIP_TO_PARTY, MTL_GROUP, PART_NO,PLANT_CODE,
                       END_CUSTOMER_ID      ,R_KIND       ,AREA1           ,AREA2        ,MTL_TYPE,
                       AREA3                ,AMT_LOCAL    ,AMT_TWD         ,AMT_USD      , 
                       CREATE_DATE          ,SOURCE
                   ) VALUES(
                       REC2.COMPANY_CODE     ,inPeriod     ,inPROFIT_CENTER,inGLAccount   ,REC2.BILL_TO_PARTY, REC2.SHIP_TO_PARTY, REC2.MTL_GROUP, REC2.PART_NO,REC2.PLANT_CODE,
                       a_ENDCUSTOMER  ,'PL01'       ,'2'               ,'3'            ,REC2.MTL_TYPE,
                       '0'                    ,round(REC2.COGS_LB * a_RATE , 5)         ,
                       round(REC2.COGS_LB_TWD * a_RATE , 5)  ,
                       round(REC2.COGS_LB_USD * a_RATE , 5)  , SYSDATE                  ,'2'
                   );
                   commit;
                 END IF;
               
                 IF REC2.COGS_OB <> 0 THEN
                   INSERT INTO PNL3_TRX002_GLACCOUNT (
                       COMPANY_CODE         ,PERIOD       ,PROFIT_CENTER   ,COST_ELEMENT ,BILL_TO_PARTY, SHIP_TO_PARTY, MTL_GROUP, PART_NO,PLANT_CODE,
                       END_CUSTOMER_ID      ,R_KIND       ,AREA1           ,AREA2        ,MTL_TYPE,
                       AREA3                ,AMT_LOCAL    ,AMT_TWD         ,AMT_USD      ,
                       CREATE_DATE          ,SOURCE
                   ) VALUES(
                       REC2.COMPANY_CODE     ,inPeriod     ,inPROFIT_CENTER,inGLAccount   ,REC2.BILL_TO_PARTY, REC2.SHIP_TO_PARTY, REC2.MTL_GROUP, REC2.PART_NO,REC2.PLANT_CODE,
                       a_ENDCUSTOMER  ,'PL01'       ,'2'               ,'4'            , REC2.MTL_TYPE,
                       '0'                    ,round(REC2.COGS_OB * a_RATE , 5)         ,
                       round(REC2.COGS_OB_TWD * a_RATE , 5)  ,
                       round(REC2.COGS_OB_USD * a_RATE , 5)  , SYSDATE                  ,'2'
                   );
                   commit;
                 END IF;
             ELSE
                a_COUNTER := 0 ;
                FOR REC1 IN (SELECT END_CUSTOMER_ID,RATE 
                           --FROM PNL3_MAP001_GLOBAL_CUST_RATE
                           FROM PNL3_MAP001_CUSTOMER_RATE 
                          WHERE R_KIND = 'PL01'  --隨便抓一筆來用,反正匯率都一樣
                            AND AREA1  = '4'
                            AND AREA2  = '1'
                            AND AREA3  = '1'
                          --AND COMPANY_CODE = REC1.COMPANY_CODE
                          AND PROFIT_CENTER = inPROFIT_CENTER
                            AND PERIOD = inPeriod) LOOP
                            a_COUNTER := 1;
                            a_RATE := REC1.RATE;
                            a_ENDCUSTOMER := REC1.END_CUSTOMER_ID;
                      IF REC2.NET_REVENUE <> 0 THEN
                        INSERT INTO PNL3_TRX002_GLACCOUNT (
                            COMPANY_CODE         ,PERIOD       ,PROFIT_CENTER   ,COST_ELEMENT , BILL_TO_PARTY, SHIP_TO_PARTY, MTL_GROUP, PART_NO,PLANT_CODE,
                            END_CUSTOMER_ID      ,R_KIND       ,AREA1           ,AREA2        , MTL_TYPE,
                            AREA3                ,AMT_LOCAL    ,AMT_TWD         ,AMT_USD      , 
                            CREATE_DATE          ,SOURCE
                        ) VALUES(
                            REC2.COMPANY_CODE     ,inPeriod     ,inPROFIT_CENTER,inGLAccount   ,REC2.BILL_TO_PARTY, REC2.SHIP_TO_PARTY, REC2.MTL_GROUP, REC2.PART_NO,REC2.PLANT_CODE,
                            a_ENDCUSTOMER  ,'PL01'       ,'1'               ,'1'            ,REC2.MTL_TYPE,
                            '0'                    ,round(REC2.NET_REVENUE * a_RATE , 5)         ,
                            round(REC2.NET_REVENUE_TWD * a_RATE , 5)  ,
                            round(REC2.NET_REVENUE_USD * a_RATE , 5)  , SYSDATE             ,'2'
                        );
                        commit;
                      END IF;
                      
                      IF REC2.COGS_MB <> 0 THEN
                        INSERT INTO PNL3_TRX002_GLACCOUNT (
                           COMPANY_CODE         ,PERIOD       ,PROFIT_CENTER   ,COST_ELEMENT ,BILL_TO_PARTY, SHIP_TO_PARTY, MTL_GROUP, PART_NO,PLANT_CODE,
                           END_CUSTOMER_ID      ,R_KIND       ,AREA1           ,AREA2        ,MTL_TYPE,
                           AREA3                ,AMT_LOCAL    ,AMT_TWD         ,AMT_USD      , 
                           CREATE_DATE          ,SOURCE
                        ) VALUES(
                           REC2.COMPANY_CODE     ,inPeriod     ,inPROFIT_CENTER,inGLAccount   ,REC2.BILL_TO_PARTY, REC2.SHIP_TO_PARTY, REC2.MTL_GROUP, REC2.PART_NO,REC2.PLANT_CODE,
                           a_ENDCUSTOMER  ,'PL01'       ,'2'               ,'2'            ,REC2.MTL_TYPE,
                           '0'                    ,round(REC2.COGS_MB * a_RATE , 5)         ,
                           round(REC2.COGS_MB_TWD * a_RATE , 5)  ,
                           round(REC2.COGS_MB_USD * a_RATE , 5)  , SYSDATE                  ,'2'
                        );
                        commit;
                      END IF;
                      
                      IF REC2.COGS_LB <> 0 THEN
                        INSERT INTO PNL3_TRX002_GLACCOUNT (
                            COMPANY_CODE         ,PERIOD       ,PROFIT_CENTER   ,COST_ELEMENT ,BILL_TO_PARTY, SHIP_TO_PARTY, MTL_GROUP, PART_NO,PLANT_CODE,
                            END_CUSTOMER_ID      ,R_KIND       ,AREA1           ,AREA2        ,MTL_TYPE,
                            AREA3                ,AMT_LOCAL    ,AMT_TWD         ,AMT_USD      , 
                            CREATE_DATE          ,SOURCE
                        ) VALUES(
                            REC2.COMPANY_CODE     ,inPeriod     ,inPROFIT_CENTER,inGLAccount   ,REC2.BILL_TO_PARTY, REC2.SHIP_TO_PARTY, REC2.MTL_GROUP, REC2.PART_NO,REC2.PLANT_CODE,
                            a_ENDCUSTOMER  ,'PL01'       ,'2'               ,'3'            ,REC2.MTL_TYPE,
                            '0'                    ,round(REC2.COGS_LB * a_RATE , 5)         ,
                            round(REC2.COGS_LB_TWD * a_RATE , 5)  ,
                            round(REC2.COGS_LB_USD * a_RATE , 5)  , SYSDATE                  ,'2'
                        );
                        commit;
                      END IF;
                      
                      IF REC2.COGS_OB <> 0 THEN
                        INSERT INTO PNL3_TRX002_GLACCOUNT (
                            COMPANY_CODE         ,PERIOD       ,PROFIT_CENTER   ,COST_ELEMENT ,BILL_TO_PARTY, SHIP_TO_PARTY, MTL_GROUP, PART_NO,PLANT_CODE,
                            END_CUSTOMER_ID      ,R_KIND       ,AREA1           ,AREA2        ,MTL_TYPE,
                            AREA3                ,AMT_LOCAL    ,AMT_TWD         ,AMT_USD      ,
                            CREATE_DATE          ,SOURCE
                        ) VALUES(
                            REC2.COMPANY_CODE     ,inPeriod     ,inPROFIT_CENTER,inGLAccount   ,REC2.BILL_TO_PARTY, REC2.SHIP_TO_PARTY, REC2.MTL_GROUP, REC2.PART_NO,REC2.PLANT_CODE,
                            a_ENDCUSTOMER  ,'PL01'       ,'2'               ,'4'            , REC2.MTL_TYPE,
                            '0'                    ,round(REC2.COGS_OB * a_RATE , 5)         ,
                            round(REC2.COGS_OB_TWD * a_RATE , 5)  ,
                            round(REC2.COGS_OB_USD * a_RATE , 5)  , SYSDATE                  ,'2'
                        );
                        commit;
                      END IF;
               
               END LOOP;
               IF a_COUNTER = 0 THEN
                FOR REC1 IN (SELECT END_CUSTOMER_ID,RATE 
                           FROM PNL3_MAP001_GLOBAL_CUST_RATE
                           --FROM PNL3_MAP001_CUSTOMER_RATE 
                          WHERE R_KIND = 'PL01'  --隨便抓一筆來用,反正匯率都一樣
                            AND AREA1  = '4'
                            AND AREA2  = '1'
                            AND AREA3  = '1'
                          --AND COMPANY_CODE = REC1.COMPANY_CODE
                          --AND PROFIT_CENTER = REC2.PROFIT_CENTER
                            AND PERIOD = inPeriod) LOOP
                            a_RATE := REC1.RATE;
                            a_ENDCUSTOMER := REC1.END_CUSTOMER_ID;
                      IF REC2.NET_REVENUE <> 0 THEN
                        INSERT INTO PNL3_TRX002_GLACCOUNT (
                            COMPANY_CODE         ,PERIOD       ,PROFIT_CENTER   ,COST_ELEMENT , BILL_TO_PARTY, SHIP_TO_PARTY, MTL_GROUP, PART_NO,PLANT_CODE,
                            END_CUSTOMER_ID      ,R_KIND       ,AREA1           ,AREA2        , MTL_TYPE,
                            AREA3                ,AMT_LOCAL    ,AMT_TWD         ,AMT_USD      , 
                            CREATE_DATE          ,SOURCE
                        ) VALUES(
                            REC2.COMPANY_CODE     ,inPeriod     ,inPROFIT_CENTER,inGLAccount   ,REC2.BILL_TO_PARTY, REC2.SHIP_TO_PARTY, REC2.MTL_GROUP, REC2.PART_NO,REC2.PLANT_CODE,
                            a_ENDCUSTOMER  ,'PL01'       ,'1'               ,'1'            ,REC2.MTL_TYPE,
                            '0'                    ,round(REC2.NET_REVENUE * a_RATE , 5)         ,
                            round(REC2.NET_REVENUE_TWD * a_RATE , 5)  ,
                            round(REC2.NET_REVENUE_USD * a_RATE , 5)  , SYSDATE             ,'2'
                        );
                        commit;
                      END IF;
                      
                      IF REC2.COGS_MB <> 0 THEN
                        INSERT INTO PNL3_TRX002_GLACCOUNT (
                           COMPANY_CODE         ,PERIOD       ,PROFIT_CENTER   ,COST_ELEMENT ,BILL_TO_PARTY, SHIP_TO_PARTY, MTL_GROUP, PART_NO,PLANT_CODE,
                           END_CUSTOMER_ID      ,R_KIND       ,AREA1           ,AREA2        ,MTL_TYPE,
                           AREA3                ,AMT_LOCAL    ,AMT_TWD         ,AMT_USD      , 
                           CREATE_DATE          ,SOURCE
                        ) VALUES(
                           REC2.COMPANY_CODE     ,inPeriod     ,inPROFIT_CENTER,inGLAccount   ,REC2.BILL_TO_PARTY, REC2.SHIP_TO_PARTY, REC2.MTL_GROUP, REC2.PART_NO,REC2.PLANT_CODE,
                           a_ENDCUSTOMER  ,'PL01'       ,'2'               ,'2'            ,REC2.MTL_TYPE,
                           '0'                    ,round(REC2.COGS_MB * a_RATE , 5)         ,
                           round(REC2.COGS_MB_TWD * a_RATE , 5)  ,
                           round(REC2.COGS_MB_USD * a_RATE , 5)  , SYSDATE                  ,'2'
                        );
                        commit;
                      END IF;
                      
                      IF REC2.COGS_LB <> 0 THEN
                        INSERT INTO PNL3_TRX002_GLACCOUNT (
                            COMPANY_CODE         ,PERIOD       ,PROFIT_CENTER   ,COST_ELEMENT ,BILL_TO_PARTY, SHIP_TO_PARTY, MTL_GROUP, PART_NO,PLANT_CODE,
                            END_CUSTOMER_ID      ,R_KIND       ,AREA1           ,AREA2        ,MTL_TYPE,
                            AREA3                ,AMT_LOCAL    ,AMT_TWD         ,AMT_USD      , 
                            CREATE_DATE          ,SOURCE
                        ) VALUES(
                            REC2.COMPANY_CODE     ,inPeriod     ,inPROFIT_CENTER,inGLAccount   ,REC2.BILL_TO_PARTY, REC2.SHIP_TO_PARTY, REC2.MTL_GROUP, REC2.PART_NO,REC2.PLANT_CODE,
                            a_ENDCUSTOMER  ,'PL01'       ,'2'               ,'3'            ,REC2.MTL_TYPE,
                            '0'                    ,round(REC2.COGS_LB * a_RATE , 5)         ,
                            round(REC2.COGS_LB_TWD * a_RATE , 5)  ,
                            round(REC2.COGS_LB_USD * a_RATE , 5)  , SYSDATE                  ,'2'
                        );
                        commit;
                      END IF;
                      
                      IF REC2.COGS_OB <> 0 THEN
                        INSERT INTO PNL3_TRX002_GLACCOUNT (
                            COMPANY_CODE         ,PERIOD       ,PROFIT_CENTER   ,COST_ELEMENT ,BILL_TO_PARTY, SHIP_TO_PARTY, MTL_GROUP, PART_NO,PLANT_CODE,
                            END_CUSTOMER_ID      ,R_KIND       ,AREA1           ,AREA2        ,MTL_TYPE,
                            AREA3                ,AMT_LOCAL    ,AMT_TWD         ,AMT_USD      ,
                            CREATE_DATE          ,SOURCE
                        ) VALUES(
                            REC2.COMPANY_CODE     ,inPeriod     ,inPROFIT_CENTER,inGLAccount   ,REC2.BILL_TO_PARTY, REC2.SHIP_TO_PARTY, REC2.MTL_GROUP, REC2.PART_NO,REC2.PLANT_CODE,
                            a_ENDCUSTOMER  ,'PL01'       ,'2'               ,'4'            , REC2.MTL_TYPE,
                            '0'                    ,round(REC2.COGS_OB * a_RATE , 5)         ,
                            round(REC2.COGS_OB_TWD * a_RATE , 5)  ,
                            round(REC2.COGS_OB_USD * a_RATE , 5)  , SYSDATE                  ,'2'
                        );
                        commit;
                      END IF;
               
                END LOOP;
               END IF;
             END IF;
           ELSE
               FOR REC1 IN (SELECT END_CUSTOMER_ID,RATE 
                           FROM PNL3_MAP001_SITE_RATE 
                          WHERE R_KIND = 'PL01'  --隨便抓一筆來用,反正匯率都一樣
                            AND AREA1  = '4'
                            AND AREA2  = '1'
                            AND AREA3  = '1'
                            AND COMPANY_CODE = REC2.COMPANY_CODE
                            AND PROFIT_CENTER = inPROFIT_CENTER
                            AND PERIOD = inPeriod) LOOP
                            a_RATE := REC1.RATE;
                            a_ENDCUSTOMER := REC1.END_CUSTOMER_ID;
                IF REC2.NET_REVENUE <> 0 THEN
                   INSERT INTO PNL3_TRX002_GLACCOUNT (
                       COMPANY_CODE         ,PERIOD       ,PROFIT_CENTER   ,COST_ELEMENT , BILL_TO_PARTY, SHIP_TO_PARTY, MTL_GROUP, PART_NO,PLANT_CODE,
                       END_CUSTOMER_ID      ,R_KIND       ,AREA1           ,AREA2        , MTL_TYPE,
                       AREA3                ,AMT_LOCAL    ,AMT_TWD         ,AMT_USD      , 
                       CREATE_DATE          ,SOURCE
                   ) VALUES(
                       REC2.COMPANY_CODE     ,inPeriod     ,inPROFIT_CENTER,inGLAccount   ,REC2.BILL_TO_PARTY, REC2.SHIP_TO_PARTY, REC2.MTL_GROUP, REC2.PART_NO,REC2.PLANT_CODE,
                       a_ENDCUSTOMER  ,'PL01'       ,'1'               ,'1'            ,REC2.MTL_TYPE,
                       '0'                    ,round(REC2.NET_REVENUE * a_RATE , 5)         ,
                       round(REC2.NET_REVENUE_TWD * a_RATE , 5)  ,
                       round(REC2.NET_REVENUE_USD * a_RATE , 5)  , SYSDATE             ,'2'
                   );
                   commit;
                 END IF;
               
                 IF REC2.COGS_MB <> 0 THEN
                   INSERT INTO PNL3_TRX002_GLACCOUNT (
                      COMPANY_CODE         ,PERIOD       ,PROFIT_CENTER   ,COST_ELEMENT ,BILL_TO_PARTY, SHIP_TO_PARTY, MTL_GROUP, PART_NO,PLANT_CODE,
                      END_CUSTOMER_ID      ,R_KIND       ,AREA1           ,AREA2        ,MTL_TYPE,
                      AREA3                ,AMT_LOCAL    ,AMT_TWD         ,AMT_USD      , 
                      CREATE_DATE          ,SOURCE
                   ) VALUES(
                      REC2.COMPANY_CODE     ,inPeriod     ,inPROFIT_CENTER,inGLAccount   ,REC2.BILL_TO_PARTY, REC2.SHIP_TO_PARTY, REC2.MTL_GROUP, REC2.PART_NO,REC2.PLANT_CODE,
                      a_ENDCUSTOMER  ,'PL01'       ,'2'               ,'2'            ,REC2.MTL_TYPE,
                      '0'                    ,round(REC2.COGS_MB * a_RATE , 5)         ,
                      round(REC2.COGS_MB_TWD * a_RATE , 5)  ,
                      round(REC2.COGS_MB_USD * a_RATE , 5)  , SYSDATE                  ,'2'
                   );
                   commit;
                 END IF;
               
                 IF REC2.COGS_LB <> 0 THEN
                   INSERT INTO PNL3_TRX002_GLACCOUNT (
                       COMPANY_CODE         ,PERIOD       ,PROFIT_CENTER   ,COST_ELEMENT ,BILL_TO_PARTY, SHIP_TO_PARTY, MTL_GROUP, PART_NO,PLANT_CODE,
                       END_CUSTOMER_ID      ,R_KIND       ,AREA1           ,AREA2        ,MTL_TYPE,
                       AREA3                ,AMT_LOCAL    ,AMT_TWD         ,AMT_USD      , 
                       CREATE_DATE          ,SOURCE
                   ) VALUES(
                       REC2.COMPANY_CODE     ,inPeriod     ,inPROFIT_CENTER,inGLAccount   ,REC2.BILL_TO_PARTY, REC2.SHIP_TO_PARTY, REC2.MTL_GROUP, REC2.PART_NO,REC2.PLANT_CODE,
                       a_ENDCUSTOMER  ,'PL01'       ,'2'               ,'3'            ,REC2.MTL_TYPE,
                       '0'                    ,round(REC2.COGS_LB * a_RATE , 5)         ,
                       round(REC2.COGS_LB_TWD * a_RATE , 5)  ,
                       round(REC2.COGS_LB_USD * a_RATE , 5)  , SYSDATE                  ,'2'
                   );
                   commit;
                 END IF;
               
                 IF REC2.COGS_OB <> 0 THEN
                   INSERT INTO PNL3_TRX002_GLACCOUNT (
                       COMPANY_CODE         ,PERIOD       ,PROFIT_CENTER   ,COST_ELEMENT ,BILL_TO_PARTY, SHIP_TO_PARTY, MTL_GROUP, PART_NO,PLANT_CODE,
                       END_CUSTOMER_ID      ,R_KIND       ,AREA1           ,AREA2        ,MTL_TYPE,
                       AREA3                ,AMT_LOCAL    ,AMT_TWD         ,AMT_USD      ,
                       CREATE_DATE          ,SOURCE
                   ) VALUES(
                       REC2.COMPANY_CODE     ,inPeriod     ,inPROFIT_CENTER,inGLAccount   ,REC2.BILL_TO_PARTY, REC2.SHIP_TO_PARTY, REC2.MTL_GROUP, REC2.PART_NO,REC2.PLANT_CODE,
                       a_ENDCUSTOMER  ,'PL01'       ,'2'               ,'4'            , REC2.MTL_TYPE,
                       '0'                    ,round(REC2.COGS_OB * a_RATE , 5)         ,
                       round(REC2.COGS_OB_TWD * a_RATE , 5)  ,
                       round(REC2.COGS_OB_USD * a_RATE , 5)  , SYSDATE                  ,'2'
                   );
                   commit;
                 END IF;
              END LOOP;
           END IF;
         END LOOP;
           
           /*  不要在這裡抓END_CUSTOMER會造成效能很不好,跑一個小時還跑不出來 在PNL3_PLS002_COGS_TRX 直接UPDATE即可
           IF REC2.PART_NO IS NOT NULL THEN
              BEGIN 
                select DISTINCT TRIM(END_CUSTOMER_NAME) into a_ENDCUSTOMER
			      from CEP_MAP009_PARTNO_CUSTOMER
			     where TRIM(FG_MATERIAL_NO) = TRIM(REC2.PART_NO)
			       and LAST_MODIFY_DATE <= SYSDATE;
              EXCEPTION 
                WHEN OTHERS THEN
                a_ENDCUSTOMER := NULL;
              END;
           END IF;
           */
        

    ELSE   -- 有營收
        a_ENDCUSTOMER := null;
        FOR REC2 in(
            SELECT COMPANY_CODE , CUSTOMER_ID AS BILL_TO_PARTY, SHIP_TO_PARTY, MTL_GROUP , PART_NO,PLANT_CODE,MTL_TYPE,
                   SUM(NET_REVENUE) NET_REVENUE , SUM(NET_REVENUE_USD) NET_REVENUE_USD, SUM(NET_REVENUE_TWD) NET_REVENUE_TWD,
                              SUM(COGS_MB) COGS_MB,SUM(COGS_MB_USD) COGS_MB_USD,SUM(COGS_MB_TWD) COGS_MB_TWD,
                              SUM(COGS_LB) COGS_LB,SUM(COGS_LB_USD) COGS_LB_USD,SUM(COGS_LB_TWD) COGS_LB_TWD,
                              SUM(COGS_OB) COGS_OB,SUM(COGS_OB_USD) COGS_OB_USD,SUM(COGS_OB_TWD) COGS_OB_TWD
                             -- (SELECT TRIM(END_CUSTOMER_NAME) FROM CEP_MAP009_PARTNO_CUSTOMER where TRIM(FG_MATERIAL_NO) = TRIM(PART_NO) and LAST_MODIFY_DATE <= SYSDATE )
                             -- END_CUSTOMER_ID
              FROM KPI_SAP001_COPA_TRX
             WHERE  PERIOD = inPeriod 
               AND  PROFIT_CENTER = inPROFIT_CENTER
               AND    ( NET_REVENUE <> 0 OR NET_COGS <>  0)
               AND    RELATED_PARTY <> 'Y'
               --AND    PART_NO IS NOT NULL
               AND COST_ELEMENT = inGLAccount
          GROUP BY COMPANY_CODE,PROFIT_CENTER,PERIOD,CUSTOMER_ID , SHIP_TO_PARTY, MTL_GROUP , PART_NO, PLANT_CODE,MTL_TYPE) Loop
            --HAVING ( SUM(NET_REVENUE) <> 0 OR SUM(NET_COGS)  <> 0 )
           /*  不要在這裡抓END_CUSTOMER會造成效能很不好,跑一個小時還跑不出來
               在PNL3_PLS002_COGS_TRX 直接UPDATE即可
           */
          
           
           IF REC2.NET_REVENUE <> 0 THEN
             INSERT INTO PNL3_TRX002_GLACCOUNT_T (
                 COMPANY_CODE         ,PERIOD       ,PROFIT_CENTER   ,COST_ELEMENT , BILL_TO_PARTY, SHIP_TO_PARTY, MTL_GROUP , PART_NO,PLANT_CODE,
                 END_CUSTOMER_ID      ,R_KIND       ,AREA1           ,AREA2        ,MTL_TYPE,
                 AREA3                ,AMT_LOCAL    ,AMT_TWD         ,AMT_USD      ,
                 CUSTOMER_REVENUE     ,PC_REVENUE   ,RATE            ,
                 CREATE_DATE          
             ) VALUES(
                 REC2.COMPANY_CODE     ,inPeriod     ,inPROFIT_CENTER,inGLAccount   ,REC2.BILL_TO_PARTY, REC2.SHIP_TO_PARTY, REC2.MTL_GROUP, REC2.PART_NO,REC2.PLANT_CODE,
                 a_ENDCUSTOMER  ,'PL01'        ,'1'               ,'1'            , REC2.MTL_TYPE,
                 '0'                    ,REC2.NET_REVENUE         ,
                 REC2.NET_REVENUE_TWD   ,
                 REC2.NET_REVENUE_USD   ,
                 inAMT                ,REC2.NET_REVENUE_TWD  ,1  ,
                 SYSDATE
             );
             commit;
           END IF;
        
           IF REC2.COGS_MB <> 0 THEN
             INSERT INTO PNL3_TRX002_GLACCOUNT_T (
                COMPANY_CODE         ,PERIOD       ,PROFIT_CENTER   ,COST_ELEMENT ,BILL_TO_PARTY, SHIP_TO_PARTY, MTL_GROUP , PART_NO,PLANT_CODE,
                END_CUSTOMER_ID      ,R_KIND       ,AREA1           ,AREA2        ,MTL_TYPE,
                AREA3                ,AMT_LOCAL    ,AMT_TWD         ,AMT_USD      ,
                CUSTOMER_REVENUE     ,PC_REVENUE   ,RATE            ,
                CREATE_DATE
             ) VALUES(
                REC2.COMPANY_CODE     ,inPeriod     ,inPROFIT_CENTER,inGLAccount   ,REC2.BILL_TO_PARTY, REC2.SHIP_TO_PARTY, REC2.MTL_GROUP, REC2.PART_NO,REC2.PLANT_CODE,
                a_ENDCUSTOMER  ,'PL01'       ,'2'               ,'2'            , REC2.MTL_TYPE,
                '0'                    ,REC2.COGS_MB          ,
                REC2.COGS_MB_TWD  ,
                REC2.COGS_MB_USD  ,
                inAMT                ,REC2.NET_REVENUE_TWD  ,1          ,
                SYSDATE
             );
             commit;
           END IF;
        
           IF REC2.COGS_LB <> 0 THEN
           INSERT INTO PNL3_TRX002_GLACCOUNT_T (
               COMPANY_CODE         ,PERIOD       ,PROFIT_CENTER   ,COST_ELEMENT ,BILL_TO_PARTY, SHIP_TO_PARTY, MTL_GROUP , PART_NO,PLANT_CODE,
               END_CUSTOMER_ID      ,R_KIND       ,AREA1           ,AREA2        ,MTL_TYPE,
               AREA3                ,AMT_LOCAL    ,AMT_TWD         ,AMT_USD      ,
               CUSTOMER_REVENUE     ,PC_REVENUE   ,RATE            ,
               CREATE_DATE
           ) VALUES(
               REC2.COMPANY_CODE     ,inPeriod     ,inPROFIT_CENTER,inGLAccount   ,REC2.BILL_TO_PARTY, REC2.SHIP_TO_PARTY, REC2.MTL_GROUP, REC2.PART_NO,REC2.PLANT_CODE,
               a_ENDCUSTOMER  ,'PL01'       ,'2'               ,'3'            , REC2.MTL_TYPE,
               '0'                    ,REC2.COGS_LB          ,
               REC2.COGS_LB_TWD  ,
               REC2.COGS_LB_USD   , 
               inAMT                ,REC2.NET_REVENUE_TWD  ,1          ,
               SYSDATE
           );
           commit;
           END IF;
        
           IF REC2.COGS_OB <> 0 THEN
           INSERT INTO PNL3_TRX002_GLACCOUNT_T (
               COMPANY_CODE         ,PERIOD       ,PROFIT_CENTER   ,COST_ELEMENT ,BILL_TO_PARTY, SHIP_TO_PARTY, MTL_GROUP , PART_NO,PLANT_CODE,
               END_CUSTOMER_ID      ,R_KIND       ,AREA1           ,AREA2        , MTL_TYPE,
               AREA3                ,AMT_LOCAL    ,AMT_TWD         ,AMT_USD      ,
               CUSTOMER_REVENUE     ,PC_REVENUE   ,RATE            ,
               CREATE_DATE
           ) VALUES(
               REC2.COMPANY_CODE     ,inPeriod     ,inPROFIT_CENTER,inGLAccount   ,REC2.BILL_TO_PARTY, REC2.SHIP_TO_PARTY, REC2.MTL_GROUP, REC2.PART_NO,REC2.PLANT_CODE,
               a_ENDCUSTOMER  ,'PL01'       ,'2'               ,'4'            , REC2.MTL_TYPE,
               '0'                    ,REC2.COGS_OB          ,
               REC2.COGS_OB_TWD   ,
               REC2.COGS_OB_USD  , 
               inAMT                ,REC2.NET_REVENUE_TWD  ,1          ,
               SYSDATE
           );
           commit;
           END IF;
         END LOOP;              

   END IF;
   
   
   
    
END PNL3_PLS002_COGS_S01_TRX_V1;
/

