create PROCEDURE       PNL2_PLS006_EM_S01_TRX (
  inCOMPANY_CODE  in VARCHAR2,
  inPROFIT_CENTER in VARCHAR2,
  inPeriod        in VARCHAR2,
  inAMT           in number,
  inAMT_USD       in number,
  inAREA1         in integer,
  inAREA2         in integer,
  inAREA3         in integer
  
  
  --2008/9/17 Create to Process get Amount in Local/USD/TWD
  --Trigger by PNL2_BAD_DEPT_UPLOAD.JSP
)
AUTHID DEFINER
is
   cursor PNL_EM is
      SELECT SITE COMPANY_CODE,
             PROFIT_CENTER,
             END_CUSTOMER_ID,
             R_KIND,
             AREA1,
             AREA2,
             AREA3,
             YEARMONTH PERIOD,
             RATE FROM PNL2_UPL001_PC_CUS_RATE_DETAIL
       WHERE SITE = inCOMPANY_CODE
         AND PROFIT_CENTER = inPROFIT_CENTER
         AND YEARMONTH   = inPERIOD
         AND R_KIND = 'PL01'
         AND AREA1  = inAREA1
         AND AREA2  = inAREA2
         AND AREA3  = inAREA3;


     
 BEGIN
   

      FOR REC1 in PNL_EM Loop


        INSERT INTO PNL2_TRX001_SUMMARY_DATA (
           COMPANY_CODE         ,PROFIT_CENTER      ,PERIOD  ,
           END_CUSTOMER_ID      ,R_KIND             ,AREA1   ,
           AREA2                ,AREA3              ,
           AMT_TWD              ,
           AMT_USD              ,
           SOURCE               ,
           CREATE_DATE 
        )
        VALUES (
           REC1.COMPANY_CODE    ,REC1.PROFIT_CENTER ,REC1.PERIOD ,
           REC1.END_CUSTOMER_ID ,REC1.R_KIND        ,REC1.AREA1  , 
           REC1.AREA2           ,REC1.AREA3         ,
           round(inAMT * REC1.RATE,5),
           round(inAMT_USD * REC1.RATE,5),
           'EM',
           SYSDATE
        );
        


                       
      END LOOP;
 
   
   
   
    
END PNL2_PLS006_EM_S01_TRX;
/

