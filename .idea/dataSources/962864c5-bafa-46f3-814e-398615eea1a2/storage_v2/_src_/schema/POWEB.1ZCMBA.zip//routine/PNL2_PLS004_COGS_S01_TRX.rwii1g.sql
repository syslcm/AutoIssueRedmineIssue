create PROCEDURE       PNL2_PLS004_COGS_S01_TRX (
  --inCOMPANY       in VARCHAR2,
  inPeriod        in VARCHAR2,
  inPROFIT_CENTER in VARCHAR2,
  inAMT           in Number,
  inGLAccount     in VARCHAR
  --2008/9/17 Create to Process get Amount in Local/USD/TWD
  --Trigger by PNL2_BAD_DEPT_UPLOAD.JSP
)
AUTHID DEFINER
is

     
     a_Rate          number(20,10);
     a_TRate         number(20,10);
     --a_COUNTER       integer;
     --i_COUNTER       integer;
     a_ENDCUSTOMER   KPI_SAP001_COPA_TRX.END_CUSTOMER_ID%TYPE;
     a_NET_REVENUE   KPI_SAP001_COPA_TRX.NET_REVENUE%TYPE;
     a_REVENUE_LOCAL KPI_SAP001_COPA_TRX.NET_REVENUE%TYPE;
     a_REVENUE_TWD   KPI_SAP001_COPA_TRX.NET_REVENUE%TYPE;
     a_REVENUE_USD   KPI_SAP001_COPA_TRX.NET_REVENUE%TYPE;
     a_COGS_DM_LOCAL KPI_SAP001_COPA_TRX.NET_REVENUE%TYPE;
     a_COGS_DM_TWD   KPI_SAP001_COPA_TRX.NET_REVENUE%TYPE;
     a_COGS_DM_USD   KPI_SAP001_COPA_TRX.NET_REVENUE%TYPE;
     a_COGS_DL_LOCAL KPI_SAP001_COPA_TRX.NET_REVENUE%TYPE;
     a_COGS_DL_TWD   KPI_SAP001_COPA_TRX.NET_REVENUE%TYPE;
     a_COGS_DL_USD   KPI_SAP001_COPA_TRX.NET_REVENUE%TYPE;
     a_COGS_OH_LOCAL KPI_SAP001_COPA_TRX.NET_REVENUE%TYPE;
     a_COGS_OH_TWD   KPI_SAP001_COPA_TRX.NET_REVENUE%TYPE;
     a_COGS_OH_USD   KPI_SAP001_COPA_TRX.NET_REVENUE%TYPE;
     
 BEGIN
   

    a_RATE  := 0;
    IF inAMT = 0 THEN --沒有營收,全部歸others
        a_RATE := 1;
        FOR REC2 in(
            SELECT COMPANY_CODE , SUM(NET_REVENUE) NET_REVENUE , SUM(NET_REVENUE_USD) NET_REVENUE_USD, SUM(NET_REVENUE_TWD) NET_REVENUE_TWD,
                              SUM(COGS_MB) COGS_MB,SUM(COGS_MB_USD) COGS_MB_USD,SUM(COGS_MB_TWD) COGS_MB_TWD,
                              SUM(COGS_LB) COGS_LB,SUM(COGS_LB_USD) COGS_LB_USD,SUM(COGS_LB_TWD) COGS_LB_TWD,
                              SUM(COGS_OB) COGS_OB,SUM(COGS_OB_USD) COGS_OB_USD,SUM(COGS_OB_TWD) COGS_OB_TWD
              FROM KPI_SAP001_COPA_TRX
             WHERE  PERIOD = inPeriod 
               AND  PROFIT_CENTER = inPROFIT_CENTER
               AND    ( NET_REVENUE <> 0 OR NET_COGS <>  0)
               AND    RELATED_PARTY <> 'Y'
               AND    END_CUSTOMER_ID IS NULL
               AND COST_ELEMENT = inGLAccount
          GROUP BY COMPANY_CODE,PROFIT_CENTER,PERIOD
            HAVING ( SUM(NET_REVENUE) <> 0 OR SUM(NET_COGS)  <> 0 )) Loop

        
           IF REC2.NET_REVENUE <> 0 THEN
             INSERT INTO PNL2_TRX002_GLACCOUNT (
                 COMPANY_CODE         ,PERIOD       ,PROFIT_CENTER   ,COST_ELEMENT ,
                 END_CUSTOMER_ID      ,R_KIND       ,AREA1           ,AREA2        ,
                 AREA3                ,AMT_LOCAL    ,AMT_TWD         ,AMT_USD      ,
                 CREATE_DATE
             ) VALUES(
                 REC2.COMPANY_CODE     ,inPeriod     ,inPROFIT_CENTER,inGLAccount   ,
                 NULL                  ,'PL01'       ,'1'               ,'1'            ,
                 '0'                    ,round(REC2.NET_REVENUE * a_RATE , 5)         ,
                 round(REC2.NET_REVENUE_TWD * a_RATE , 5)  ,
                 round(REC2.NET_REVENUE_USD * a_RATE , 5)  , SYSDATE
             );
             commit;
           END IF;
        
           IF REC2.COGS_MB <> 0 THEN
             INSERT INTO PNL2_TRX002_GLACCOUNT (
                COMPANY_CODE         ,PERIOD       ,PROFIT_CENTER   ,COST_ELEMENT ,
                END_CUSTOMER_ID      ,R_KIND       ,AREA1           ,AREA2        ,
                AREA3                ,AMT_LOCAL    ,AMT_TWD         ,AMT_USD      ,
                CREATE_DATE
             ) VALUES(
                REC2.COMPANY_CODE     ,inPeriod     ,inPROFIT_CENTER,inGLAccount   ,
                NULL                  ,'PL01'       ,'2'               ,'2'            ,
                '0'                    ,round(REC2.COGS_MB * a_RATE , 5)         ,
                round(REC2.COGS_MB_TWD * a_RATE , 5)  ,
                round(REC2.COGS_MB_USD * a_RATE , 5)  , SYSDATE
             );
             commit;
           END IF;
        
           IF REC2.COGS_LB <> 0 THEN
           INSERT INTO PNL2_TRX002_GLACCOUNT (
               COMPANY_CODE         ,PERIOD       ,PROFIT_CENTER   ,COST_ELEMENT ,
               END_CUSTOMER_ID      ,R_KIND       ,AREA1           ,AREA2        ,
               AREA3                ,AMT_LOCAL    ,AMT_TWD         ,AMT_USD      ,
               CREATE_DATE
           ) VALUES(
               REC2.COMPANY_CODE     ,inPeriod     ,inPROFIT_CENTER,inGLAccount   ,
               NULL                  ,'PL01'       ,'2'               ,'3'            ,
               '0'                    ,round(REC2.COGS_LB * a_RATE , 5)         ,
               round(REC2.COGS_LB_TWD * a_RATE , 5)  ,
               round(REC2.COGS_LB_USD * a_RATE , 5)  , SYSDATE
           );
           commit;
           END IF;
        
           IF REC2.COGS_OB <> 0 THEN
           INSERT INTO PNL2_TRX002_GLACCOUNT (
               COMPANY_CODE         ,PERIOD       ,PROFIT_CENTER   ,COST_ELEMENT ,
               END_CUSTOMER_ID      ,R_KIND       ,AREA1           ,AREA2        ,
               AREA3                ,AMT_LOCAL    ,AMT_TWD         ,AMT_USD      ,
               CREATE_DATE
           ) VALUES(
               REC2.COMPANY_CODE     ,inPeriod     ,inPROFIT_CENTER,inGLAccount   ,
               NULL                  ,'PL01'       ,'2'               ,'4'            ,
               '0'                    ,round(REC2.COGS_OB * a_RATE , 5)         ,
               round(REC2.COGS_OB_TWD * a_RATE , 5)  ,
               round(REC2.COGS_OB_USD * a_RATE , 5)  , SYSDATE
           );
           commit;
           END IF;
         END LOOP;
    ELSE
      a_TRate := 1;
      /*a_COUNTER := 0;
      FOR REC1 in (SELECT END_CUSTOMER_ID,SUM(NET_REVENUE_TWD) AMT_TWD FROM KPI_SAP001_COPA_TRX 
                      WHERE PROFIT_CENTER = inPROFIT_CENTER
                        AND PERIOD = inPeriod
                        AND RELATED_PARTY <> 'Y'
                        AND NET_REVENUE <> 0
                        GROUP BY END_CUSTOMER_ID ORDER BY AMT_TWD DESC) Loop  
        a_COUNTER := a_COUNTER + 1;                
      END LOOP; 
      */   
      --i_COUNTER := 0;
      FOR REC1 in (SELECT END_CUSTOMER_ID,SUM(NET_REVENUE_TWD) AMT_TWD FROM KPI_SAP001_COPA_TRX 
                      WHERE PROFIT_CENTER = inPROFIT_CENTER
                        AND PERIOD = inPeriod
                        AND RELATED_PARTY <> 'Y'
                        AND NET_REVENUE <> 0
                        GROUP BY END_CUSTOMER_ID ORDER BY AMT_TWD DESC) Loop
        a_Rate := REC1.AMT_TWD / inAMT;
        a_TRate := a_TRate - a_Rate;
        a_REVENUE_LOCAL := 0;
        a_REVENUE_TWD   := 0;
        a_REVENUE_USD   := 0;
        a_COGS_DM_LOCAL := 0;
        a_COGS_DM_TWD   := 0;
        a_COGS_DM_USD   := 0;
        a_COGS_DL_LOCAL := 0;
        a_COGS_DL_TWD   := 0;
        a_COGS_DL_USD   := 0;
        a_COGS_OH_LOCAL := 0;
        a_COGS_OH_TWD   := 0;
        a_COGS_OH_USD   := 0;
        --i_COUNTER := i_COUNTER + 1;
        --IF a_TRate < 0 THEN
        --  a_Rate = 0;
        --END IF;
        --if a_COUNTER = i_COUNTER THEN
        --if a_TRate > 0 THEN
        --   a_Rate = a_Rate + a_Trate;
        --ELSIF a_TRate < 0 THEN
        --   a_Rate = a_Rate + a_Trate;
        --END IF;
        
        --END IF;
        FOR REC2 in(
            SELECT COMPANY_CODE , SUM(NET_REVENUE) NET_REVENUE , SUM(NET_REVENUE_USD) NET_REVENUE_USD, SUM(NET_REVENUE_TWD) NET_REVENUE_TWD,
                              SUM(COGS_MB) COGS_MB,SUM(COGS_MB_USD) COGS_MB_USD,SUM(COGS_MB_TWD) COGS_MB_TWD,
                              SUM(COGS_LB) COGS_LB,SUM(COGS_LB_USD) COGS_LB_USD,SUM(COGS_LB_TWD) COGS_LB_TWD,
                              SUM(COGS_OB) COGS_OB,SUM(COGS_OB_USD) COGS_OB_USD,SUM(COGS_OB_TWD) COGS_OB_TWD
              FROM KPI_SAP001_COPA_TRX
             WHERE  PERIOD = inPeriod 
               AND  PROFIT_CENTER = inPROFIT_CENTER
               AND    ( NET_REVENUE <> 0 OR NET_COGS <>  0)
               AND    RELATED_PARTY <> 'Y'
               AND    END_CUSTOMER_ID IS NULL
               AND COST_ELEMENT = inGLAccount
          GROUP BY COMPANY_CODE,PROFIT_CENTER,PERIOD
            HAVING ( SUM(NET_REVENUE) <> 0 OR SUM(NET_COGS)  <> 0 )) Loop

        
           IF REC2.NET_REVENUE <> 0 THEN
             INSERT INTO PNL2_TRX002_GLACCOUNT (
                 COMPANY_CODE         ,PERIOD       ,PROFIT_CENTER   ,COST_ELEMENT ,
                 END_CUSTOMER_ID      ,R_KIND       ,AREA1           ,AREA2        ,
                 AREA3                ,AMT_LOCAL    ,AMT_TWD         ,AMT_USD      ,
                 CUSTOMER_REVENUE     ,PC_REVENUE   ,RATE            ,
                 CREATE_DATE          
             ) VALUES(
                 REC2.COMPANY_CODE     ,inPeriod     ,inPROFIT_CENTER,inGLAccount   ,
                 REC1.END_CUSTOMER_ID ,'PL01'        ,'1'               ,'1'            ,
                 '0'                    ,round(REC2.NET_REVENUE * a_RATE , 5)         ,
                 round(REC2.NET_REVENUE_TWD * a_RATE , 5)  ,
                 round(REC2.NET_REVENUE_USD * a_RATE , 5)  ,
                 inAMT                ,REC1.AMT_TWD  ,a_Rate  ,
                 SYSDATE
             );
             commit;
           END IF;
        
           IF REC2.COGS_MB <> 0 THEN
             INSERT INTO PNL2_TRX002_GLACCOUNT (
                COMPANY_CODE         ,PERIOD       ,PROFIT_CENTER   ,COST_ELEMENT ,
                END_CUSTOMER_ID      ,R_KIND       ,AREA1           ,AREA2        ,
                AREA3                ,AMT_LOCAL    ,AMT_TWD         ,AMT_USD      ,
                CUSTOMER_REVENUE     ,PC_REVENUE   ,RATE            ,
                CREATE_DATE
             ) VALUES(
                REC2.COMPANY_CODE     ,inPeriod     ,inPROFIT_CENTER,inGLAccount   ,
                REC1.END_CUSTOMER_ID ,'PL01'       ,'2'               ,'2'            ,
                '0'                    ,round(REC2.COGS_MB * a_RATE , 5)         ,
                round(REC2.COGS_MB_TWD * a_RATE , 5)  ,
                round(REC2.COGS_MB_USD * a_RATE , 5)  ,
                inAMT                ,REC1.AMT_TWD  ,a_Rate          ,
                SYSDATE
             );
             commit;
           END IF;
        
           IF REC2.COGS_LB <> 0 THEN
           INSERT INTO PNL2_TRX002_GLACCOUNT (
               COMPANY_CODE         ,PERIOD       ,PROFIT_CENTER   ,COST_ELEMENT ,
               END_CUSTOMER_ID      ,R_KIND       ,AREA1           ,AREA2        ,
               AREA3                ,AMT_LOCAL    ,AMT_TWD         ,AMT_USD      ,
               CUSTOMER_REVENUE     ,PC_REVENUE   ,RATE            ,
               CREATE_DATE
           ) VALUES(
               REC2.COMPANY_CODE     ,inPeriod     ,inPROFIT_CENTER,inGLAccount   ,
               REC1.END_CUSTOMER_ID ,'PL01'       ,'2'               ,'3'            ,
               '0'                    ,round(REC2.COGS_LB * a_RATE , 5)         ,
               round(REC2.COGS_LB_TWD * a_RATE , 5)  ,
               round(REC2.COGS_LB_USD * a_RATE , 5)  , 
               inAMT                ,REC1.AMT_TWD  ,a_Rate          ,
               SYSDATE
           );
           commit;
           END IF;
        
           IF REC2.COGS_OB <> 0 THEN
           INSERT INTO PNL2_TRX002_GLACCOUNT (
               COMPANY_CODE         ,PERIOD       ,PROFIT_CENTER   ,COST_ELEMENT ,
               END_CUSTOMER_ID      ,R_KIND       ,AREA1           ,AREA2        ,
               AREA3                ,AMT_LOCAL    ,AMT_TWD         ,AMT_USD      ,
               CUSTOMER_REVENUE     ,PC_REVENUE   ,RATE            ,
               CREATE_DATE
           ) VALUES(
               REC2.COMPANY_CODE     ,inPeriod     ,inPROFIT_CENTER,inGLAccount   ,
               REC1.END_CUSTOMER_ID ,'PL01'       ,'2'               ,'4'            ,
               '0'                    ,round(REC2.COGS_OB * a_RATE , 5)         ,
               round(REC2.COGS_OB_TWD * a_RATE , 5)  ,
               round(REC2.COGS_OB_USD * a_RATE , 5)  , 
               inAMT                ,REC1.AMT_TWD  ,a_Rate          ,
               SYSDATE
           );
           commit;
           END IF;
         END LOOP;              
      END LOOP;
   END IF;
   
   
   
    
END PNL2_PLS004_COGS_S01_TRX;
/

