create FUNCTION vqa_get_mat_grp(cmfr_name IN vqa_pdm_mfr_data.mfr_name%TYPE,cvendor_code IN vqa_vew001_ir_data.GLOBAL_VENDOR_CODE%TYPE) RETURN VARCHAR2
/*********************************************************************
  PROG-ID      : VQA GET MATERIAL GROUP
  Author       : Shuya
  Date         : 2008/01/17
**********************************************************************/ 
IS CURSOR category_cur IS
    SELECT distinct al2.mat_grp
      FROM poweb.vqa_pdm_mfr_data al1,
        poweb.vqa_pdm_pn_data al2,
        poweb.vqa_vew001_ir_data al3
     WHERE(al2.usi_pn = al3.part_no
       AND al2.mfr_name = al1.mfr_name)
       AND al2.mat_grp is not null
       AND AL3.GLOBAL_VENDOR_CODE = cvendor_code
       AND al1.mfr_name = cmfr_name       
     order by al2.mat_grp;

cmessage VARCHAR2(5000);
BEGIN
  cmessage := '';
  FOR active_rec IN category_cur  LOOP
    IF cmessage IS NOT NULL THEN
         cmessage := cmessage || ',';
      END IF;
    cmessage := cmessage || active_rec.mat_grp;
  END LOOP;

  RETURN cmessage;
END vqa_get_mat_grp;
/

