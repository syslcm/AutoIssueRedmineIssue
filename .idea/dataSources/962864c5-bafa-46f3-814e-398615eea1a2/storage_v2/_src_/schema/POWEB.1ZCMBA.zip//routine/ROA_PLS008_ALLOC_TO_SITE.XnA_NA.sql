create PROCEDURE       ROA_PLS008_ALLOC_TO_SITE (
/* ********************************************************************
  PROG-ID      : ROA_PLS008_ALLOC_TO_SITE
  PROG-ACTION  : 
  Author       : Jeff Hsieh
  Date         : 2017/05/26
  OA Number    : SAI071717
*********************************************************************

********************************************************************* */
   incompany    IN   VARCHAR2,
   f_yyyymmdd   IN   VARCHAR2,
   t_yyyymmdd   IN   VARCHAR2
)
AUTHID DEFINER
IS
   CURSOR ROA_UPL008_ALLOC_TO_SITE_T
   IS
      SELECT COMPANY_CODE,TO_COMPANY_CODE,COST_CENTER,CREATE_USER,CREATE_DATE
      FROM ROA_UPL008_ALLOC_TO_SITE_T
      where COMPANY_CODE = incompany;


   itracepoint   INTEGER;
BEGIN
     --(1)清除舊資料
     DELETE FROM ROA_UPL008_ALLOC_TO_SITE
     where COMPANY_CODE = incompany;
     COMMIT;  


   FOR REC1 IN ROA_UPL008_ALLOC_TO_SITE_T LOOP
      
   --(2)開始處理資料
       INSERT INTO ROA_UPL008_ALLOC_TO_SITE (
            COMPANY_CODE,
            TO_COMPANY_CODE,
            COST_CENTER,
            CREATE_USER,
            CREATE_DATE
            ) VALUES (
            REC1.COMPANY_CODE,
            REC1.TO_COMPANY_CODE,
            trim(REC1.COST_CENTER),
            'SYSTEM',
            SYSDATE   
            );    
       COMMIT;

   END LOOP;

   --(3) 刪除資料
   DELETE FROM ROA_UPL008_ALLOC_TO_SITE_T
   where COMPANY_CODE = incompany;
   COMMIT;


END ROA_PLS008_ALLOC_TO_SITE;
/

