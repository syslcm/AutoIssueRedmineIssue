create PROCEDURE       PLSQL_PLD_KPI_MPS_ZF451
(
	inCompany  in VARCHAR2,
	f_YYYYMMDD in VARCHAR2,
	t_YYYYMMDD in VARCHAR2
)
AUTHID DEFINER
is
	/*
	SAI017582 : MPS Dynamic Analysis  - 2010/09/09 Minhorng
		1. 處理 PLD_KPI_MPS_ANALYSIS_ZF451 資料 (SAP ZF451) (backup)
		2. 彙整到 PLD_KPI_MPS_ANALYSIS_LIST
	*/
	iTracePoint           varchar2(3);
	cErrorText            varchar2(500);
	yyyymm_max          PLD_KPI_MPS_ANALYSIS_ZF451_T.YYYYMM%TYPE;  --max
	date_ver_max        PLD_KPI_MPS_ANALYSIS_ZF451_T.DATE_VER%TYPE;
	yyyymm_min          PLD_KPI_MPS_ANALYSIS_ZF451_T.YYYYMM%TYPE;  --min (only use with 01th)
	date_ver_min        PLD_KPI_MPS_ANALYSIS_ZF451_T.DATE_VER%TYPE;
	yyyymm_tmp          PLD_KPI_MPS_ANALYSIS_ZF451_T.YYYYMM%TYPE;  --temp
	date_ver_tmp        PLD_KPI_MPS_ANALYSIS_ZF451_T.DATE_VER%TYPE;
	t_D01_QTY           PLD_KPI_MPS_ANALYSIS_LIST.D01_QTY%TYPE;
	t_D08_QTY           PLD_KPI_MPS_ANALYSIS_LIST.D08_QTY%TYPE;
	t_D15_QTY           PLD_KPI_MPS_ANALYSIS_LIST.D15_QTY%TYPE;
	t_D22_QTY           PLD_KPI_MPS_ANALYSIS_LIST.D22_QTY%TYPE;
	t_END_QTY           PLD_KPI_MPS_ANALYSIS_LIST.END_QTY%TYPE;
	t_ACHIEVE_RATE      PLD_KPI_MPS_ANALYSIS_LIST.ACHIEVE_RATE%TYPE;
BEGIN
	-- 清除 create_date 錯誤者
	iTracePoint := '000';
	delete from PLD_KPI_MPS_ANALYSIS_ZF451_T
		where COMPANY_CODE = inCompany
		and CREATE_DATE <> t_YYYYMMDD;
	commit;

	-- get DATE_VER
	iTracePoint := '030';
	yyyymm_max := null;
	date_ver_max := null;
	yyyymm_min := null;
	date_ver_min := null;
	yyyymm_tmp := null;
	date_ver_tmp := null;
	iTracePoint := '033';   -- max
	select * into yyyymm_max, date_ver_max from (
		select substr(T_KEY,1,6), substr(T_KEY,7) from (
			select max(YYYYMM || DATE_VER) as T_KEY from PLD_KPI_MPS_ANALYSIS_ZF451_T
			where COMPANY_CODE = inCompany
		)
	);
	iTracePoint := '036';   -- min (only use with 01th)
	select * into yyyymm_min, date_ver_min from (
		select substr(T_KEY,1,6), substr(T_KEY,7) from (
			select min(YYYYMM || DATE_VER) as T_KEY from PLD_KPI_MPS_ANALYSIS_ZF451_T
			where COMPANY_CODE = inCompany
		)
	);

	-- move PLD_KPI_MPS_ANALYSIS_ZF451_T to PLD_KPI_MPS_ANALYSIS_ZF451 (backup)
	iTracePoint := '060';
	for rec1 in (
		select distinct COMPANY_CODE, YYYYMM, DATE_VER from PLD_KPI_MPS_ANALYSIS_ZF451_T
		where COMPANY_CODE = inCompany
	) loop
		-- delete old
		delete from PLD_KPI_MPS_ANALYSIS_ZF451
		where COMPANY_CODE = rec1.COMPANY_CODE
		and YYYYMM = rec1.YYYYMM
		and DATE_VER = rec1.DATE_VER;
		-- insert new
		insert into PLD_KPI_MPS_ANALYSIS_ZF451
		select distinct * from PLD_KPI_MPS_ANALYSIS_ZF451_T
		where COMPANY_CODE = rec1.COMPANY_CODE
		and YYYYMM = rec1.YYYYMM
		and DATE_VER = rec1.DATE_VER;
		-- commit
		commit;
	end loop;

	-- 開始處理 PLD_KPI_MPS_ANALYSIS_LIST
	iTracePoint := '100';
	t_D01_QTY := null;
	t_D08_QTY := null;
	t_D15_QTY := null;
	t_D22_QTY := null;
	t_END_QTY := null;
	yyyymm_tmp := yyyymm_max;
	date_ver_tmp := date_ver_max;
	-- 01th 特別處理本月的資料
	if date_ver_max = '01th' then
		-- xxxx_tmp 放 min. 處理上月 end 資料
		yyyymm_tmp := yyyymm_min;
		date_ver_tmp := date_ver_min;
		-- 先清掉 PLD_KPI_MPS_ANALYSIS_LIST 該月的資料
		iTracePoint := '130';
		delete from PLD_KPI_MPS_ANALYSIS_LIST
		where COMPANY_CODE = inCompany
		and YYYYMM = yyyymm_max;
		commit;
		-- 資料新增入 PLD_KPI_MPS_ANALYSIS_LIST (plan - new)
		iTracePoint := '160';
		insert into PLD_KPI_MPS_ANALYSIS_LIST (
			COMPANY_CODE, YYYYMM, PART_NO, PLANT, WO_TYPE,
			MAC_USD, D01_QTY, D01_REV, DATA_TYPE, MAC_NEW,
			PROFIT_CENTER, BU_NAME, PC_NAME, CUSTOMER_NAME )
		select distinct a.COMPANY_CODE, a.YYYYMM, a.PART_NO, a.PLANT, a.WO_TYPE,
			a.MAC_USD, a.QTY, round(a.MAC_NEW * a.QTY,6), 'Origin', a.MAC_NEW,
			a.PROFIT_CENTER,
			(select BG_DESC from KPI_MAP002_BG_MAP where COMPANY_CODE = a.COMPANY_CODE
			and PROFIT_CENTER = a.PROFIT_CENTER and START_DATE <= sysdate
			and END_DATE >= sysdate and rownum <= 1),
			(select PC_DESC from KPI_MAP002_BG_MAP where COMPANY_CODE = a.COMPANY_CODE
			and PROFIT_CENTER = a.PROFIT_CENTER and START_DATE <= sysdate
			and END_DATE >= sysdate and rownum <= 1),
			(select trim(END_CUSTOMER_NAME) from CEP_MAP009_PARTNO_CUSTOMER
			where trim(FG_MATERIAL_NO) = a.PART_NO and rownum <= 1)
		from PLD_KPI_MPS_ANALYSIS_ZF451_T a
		where a.COMPANY_CODE = inCompany
		and a.YYYYMM = yyyymm_max
		and a.DATE_VER = date_ver_max;
		commit;
	end if;

	-- 處理 PLD_KPI_MPS_ANALYSIS_LIST (exists data)
	iTracePoint := '200';
	for rec1 in (
		select distinct a.*, b.D01_QTY, b.D08_QTY, b.D15_QTY, b.D22_QTY,
			(select BG_DESC from KPI_MAP002_BG_MAP where COMPANY_CODE = a.COMPANY_CODE
			and PROFIT_CENTER = a.PROFIT_CENTER and START_DATE <= sysdate
			and END_DATE >= sysdate and rownum <= 1) as BU_NAME,
			(select PC_DESC from KPI_MAP002_BG_MAP where COMPANY_CODE = a.COMPANY_CODE
			and PROFIT_CENTER = a.PROFIT_CENTER and START_DATE <= sysdate
			and END_DATE >= sysdate and rownum <= 1) as PC_NAME,
			(select trim(END_CUSTOMER_NAME) from CEP_MAP009_PARTNO_CUSTOMER
			where trim(FG_MATERIAL_NO) = a.PART_NO and rownum <= 1) as CUSTOMER_NAME
		from PLD_KPI_MPS_ANALYSIS_ZF451_T a, PLD_KPI_MPS_ANALYSIS_LIST b
		where a.COMPANY_CODE = inCompany
		and a.YYYYMM = yyyymm_tmp
		and a.DATE_VER = date_ver_tmp
		and b.COMPANY_CODE = a.COMPANY_CODE
		and b.YYYYMM = a.YYYYMM
		and b.PART_NO = a.PART_NO
		and b.PLANT = a.PLANT
		and b.WO_TYPE = a.WO_TYPE
	) loop
		iTracePoint := '230';
		t_D01_QTY := rec1.D01_QTY;
		t_D08_QTY := rec1.D08_QTY;
		t_D15_QTY := rec1.D15_QTY;
		t_D22_QTY := rec1.D22_QTY;
		t_END_QTY := null;
		t_ACHIEVE_RATE := null;
		case date_ver_max
			when '01th' then -- 01th  
				t_END_QTY := rec1.QTY;
				if t_D01_QTY > 0 then
					t_ACHIEVE_RATE := round(t_END_QTY / t_D01_QTY, 4);
				end if;
			when '08th' then -- 08th
				t_D08_QTY := rec1.QTY;
			when '15th' then -- 15th
				t_D15_QTY := rec1.QTY;
			when '22th' then -- 22th
				t_D22_QTY := rec1.QTY;
		end case;
		iTracePoint := '260';
		update PLD_KPI_MPS_ANALYSIS_LIST set
			PROFIT_CENTER = rec1.PROFIT_CENTER,
			BU_NAME = rec1.BU_NAME,
			PC_NAME = rec1.PC_NAME,
			CUSTOMER_NAME = rec1.CUSTOMER_NAME,
			MAC_USD = rec1.MAC_USD,
			D01_QTY = t_D01_QTY,
			D01_REV = round(t_D01_QTY * rec1.MAC_NEW,6),
			D08_QTY = t_D08_QTY,
			D08_REV = round(t_D08_QTY * rec1.MAC_NEW,6),
			D08_DELTA = (round(t_D08_QTY * rec1.MAC_NEW,6) - round(nvl(t_D01_QTY,0) * rec1.MAC_NEW,6)),
			D15_QTY = t_D15_QTY,
			D15_REV = round(t_D15_QTY * rec1.MAC_NEW,6),
			D15_DELTA = (round(t_D15_QTY * rec1.MAC_NEW,6) - round(nvl(t_D01_QTY,0) * rec1.MAC_NEW,6)),
			D22_QTY = t_D22_QTY,
			D22_REV = round(t_D22_QTY * rec1.MAC_NEW,6),
			D22_DELTA = (round(t_D22_QTY * rec1.MAC_NEW,6) - round(nvl(t_D01_QTY,0) * rec1.MAC_NEW,6)),
			END_QTY = t_END_QTY,
			END_REV = round(t_END_QTY * rec1.MAC_NEW,6),
			END_DELTA = (round(t_END_QTY * rec1.MAC_NEW,6) - round(nvl(t_D01_QTY,0) * rec1.MAC_NEW,6)),
			ACHIEVE_RATE = t_ACHIEVE_RATE,
			MAC_NEW = rec1.MAC_NEW
		where COMPANY_CODE = rec1.COMPANY_CODE
		and YYYYMM = rec1.YYYYMM
		and PART_NO = rec1.PART_NO
		and PLANT = rec1.PLANT
		and WO_TYPE = rec1.WO_TYPE;
		commit;
	end loop;
	-- 處理 PLD_KPI_MPS_ANALYSIS_LIST (new - not exists)
	iTracePoint := '300';
	for rec1 in (
		select distinct a.*,
			(select BG_DESC from KPI_MAP002_BG_MAP where COMPANY_CODE = a.COMPANY_CODE
			and PROFIT_CENTER = a.PROFIT_CENTER and START_DATE <= sysdate
			and END_DATE >= sysdate and rownum <= 1) as BU_NAME,
			(select PC_DESC from KPI_MAP002_BG_MAP where COMPANY_CODE = a.COMPANY_CODE
			and PROFIT_CENTER = a.PROFIT_CENTER and START_DATE <= sysdate
			and END_DATE >= sysdate and rownum <= 1) as PC_NAME,
			(select trim(END_CUSTOMER_NAME) from CEP_MAP009_PARTNO_CUSTOMER
			where trim(FG_MATERIAL_NO) = a.PART_NO and rownum <= 1) as CUSTOMER_NAME
		from PLD_KPI_MPS_ANALYSIS_ZF451_T a
		where a.COMPANY_CODE = inCompany
		and a.YYYYMM = yyyymm_tmp
		and a.DATE_VER = date_ver_tmp
		and not exists (
			select COMPANY_CODE from PLD_KPI_MPS_ANALYSIS_LIST
			where COMPANY_CODE = a.COMPANY_CODE
			and YYYYMM = a.YYYYMM
			and PART_NO = a.PART_NO
			and PLANT = a.PLANT
			and WO_TYPE = a.WO_TYPE
		)
	) loop
		iTracePoint := '330';
		t_D01_QTY := null;
		t_D08_QTY := null;
		t_D15_QTY := null;
		t_D22_QTY := null;
		t_END_QTY := null;
		t_ACHIEVE_RATE := null;
		case date_ver_max
			when '01th' then -- 01th  
				t_END_QTY := rec1.QTY;
			when '08th' then -- 08th
				t_D08_QTY := rec1.QTY;
			when '15th' then -- 15th
				t_D15_QTY := rec1.QTY;
			when '22th' then -- 22th
				t_D22_QTY := rec1.QTY;
		end case;
		iTracePoint := '360';
		insert into PLD_KPI_MPS_ANALYSIS_LIST (
			COMPANY_CODE, YYYYMM, PART_NO, PLANT,
			WO_TYPE, PROFIT_CENTER, BU_NAME, PC_NAME,
			CUSTOMER_NAME, MAC_USD, D01_QTY, D01_REV,
			D08_QTY, D08_REV, D08_DELTA, D15_QTY, D15_REV, D15_DELTA,
			D22_QTY, D22_REV, D22_DELTA, END_QTY, END_REV, END_DELTA,
			DATA_TYPE, MAC_NEW
		) values (
			rec1.COMPANY_CODE, rec1.YYYYMM, rec1.PART_NO, rec1.PLANT,
			rec1.WO_TYPE, rec1.PROFIT_CENTER, rec1.BU_NAME, rec1.PC_NAME,
			rec1.CUSTOMER_NAME, rec1.MAC_USD,
			t_D01_QTY,
			round(t_D01_QTY * rec1.MAC_NEW,6),
			t_D08_QTY,
			round(t_D08_QTY * rec1.MAC_NEW,6),
			(round(t_D08_QTY * rec1.MAC_NEW,6) - round(nvl(t_D01_QTY,0) * rec1.MAC_NEW,6)),
			t_D15_QTY,
			round(t_D15_QTY * rec1.MAC_NEW,6),
			(round(t_D15_QTY * rec1.MAC_NEW,6) - round(nvl(t_D01_QTY,0) * rec1.MAC_NEW,6)),
			t_D22_QTY,
			round(t_D22_QTY * rec1.MAC_NEW,6),
			(round(t_D22_QTY * rec1.MAC_NEW,6) - round(nvl(t_D01_QTY,0) * rec1.MAC_NEW,6)),
			t_END_QTY,
			round(t_END_QTY * rec1.MAC_NEW,6),
			(round(t_END_QTY * rec1.MAC_NEW,6) - round(nvl(t_D01_QTY,0) * rec1.MAC_NEW,6)),
			'New',
			rec1.MAC_NEW
		);
		commit;
	end loop;
	iTracePoint := '999';
EXCEPTION
	WHEN OTHERS THEN
		cErrorText := SQLERRM();
		MAIL_FILE_BIDBDBADMIN(in_to_name=>'tw.sys.biadm@usiglobal.com',subject   => '[PLD KPI]PL/SQL PLSQL_PLD_KPI_MPS_ZF451 ERROR - Company: ' || inCompany, message => '[PLSQL_PLD_KPI_MPS_ZF451], The tracepoint is  ' || iTracePoint || ' and ErrorText=' || cErrorText);
END PLSQL_PLD_KPI_MPS_ZF451;
/

