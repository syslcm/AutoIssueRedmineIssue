create PROCEDURE TLM_PLS002_SAP001_TEMP_TO_PRD(
  inCompany  in VARCHAR2,
  f_YYYYMMDD in VARCHAR2,
  t_YYYYMMDD in VARCHAR2
)
/*********************************************************************
  PROG-ID      : TLM_PLS002_SAP001_TEMP_TO_PRD
  PROG-ACTION  : MOVE TLM_SAP001_ASSET_LIST_T TO TLM_SAP001_ASSET_LIST_TEMP
  Author       : KANGI
  Date         : 20141204
*******************************************************/
--KEY_IN_DATE = CREATE_DATE (UPLOAD_DATE)
is
   CURSOR ACTIVE_TLM_SAP001_CUR
   is
    SELECT
    COMPANY_CODE,SAP_ASSET_NO,TOOLING_NO,
    TOOLING_KEEPER,SCRAP_DATE,COST_CENTER,
    CREATE_DATE
	FROM TLM_SAP001_ASSET_LIST_T
    WHERE COMPANY_CODE = inCompany	;
   cMessage     LONG ;
   iTracePoint  integer ;
   cErrorText char(500) ;
   iFind_Flag   integer ;          ----1=>find , 0=>dosen't find
   iSuccess_Flag   integer ;       ----1=>Success , 0=>Failure
   iProcess_Flag     integer ;     ----1=>Yes , 0=>NO
   sql_stmt     varchar2(400);

BEGIN

     iTracePoint := 100 ;

	 --DELETE TLM_SAP001_ASSET_LIST  ;
	 DELETE TLM_SAP001_ASSET_LIST WHERE COMPANY_CODE = inCompany ;
	 iTracePoint := 200 ;
     FOR ACTIVE_TLM_SAP001_REC in ACTIVE_TLM_SAP001_CUR  LOOP
        iTracePoint := 200 ;
        INSERT INTO TLM_SAP001_ASSET_LIST
		(COMPANY_CODE,SAP_ASSET_NO,TOOLING_NO,
         TOOLING_KEEPER,SCRAP_DATE,COST_CENTER,
         CREATE_DATE )
		 VALUES
		(ACTIVE_TLM_SAP001_REC.COMPANY_CODE,ACTIVE_TLM_SAP001_REC.SAP_ASSET_NO,ACTIVE_TLM_SAP001_REC.TOOLING_NO,
         ACTIVE_TLM_SAP001_REC.TOOLING_KEEPER,ACTIVE_TLM_SAP001_REC.SCRAP_DATE,ACTIVE_TLM_SAP001_REC.COST_CENTER,
         ACTIVE_TLM_SAP001_REC.CREATE_DATE );
         iTracePoint := 300 ;
     END LOOP ;
	 iTracePoint := 400 ;
	 --TLM_SAP001_ASSET_LIST_T
	 DELETE TLM_SAP001_ASSET_LIST_T WHERE COMPANY_CODE = inCompany ;
	 iTracePoint := 500 ;
	 COMMIT ;

	 ------EXECUTE TLM_PLS003_UPD_SAP_TO_UPL001
	 TLM_PLS003_UPD_SAP_TO_UPL001 ;

     iTracePoint := 600 ;
End TLM_PLS002_SAP001_TEMP_TO_PRD;
/

