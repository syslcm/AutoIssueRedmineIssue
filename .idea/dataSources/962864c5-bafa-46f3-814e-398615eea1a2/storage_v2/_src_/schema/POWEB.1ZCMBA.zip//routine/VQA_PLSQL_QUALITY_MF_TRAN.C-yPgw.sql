create PROCEDURE         "VQA_PLSQL_QUALITY_MF_TRAN" IS
      /*--------------------------------------------------------------*
         CREATE DATE:  2008/03/05
         PLSQL      :  VQA_PLSQL_QUALITY_MF_TRAN
         Author     :  Susan Lin
         Purpase    :  VQA QUALITY SCORE(By 每季執行一次)
      *---------------------------------------------------------------*
      */


 vMANUF  VQA_SUM22_GV_QQ_COMBINE.MANUF%TYPE;
 vPROCEE_YYYYMMDD varchar2(8);
 vPROCEE_YYYYMM   varchar2(6);
 vCURRENT_QUARTER varchar2(8);
 vCURRENT_YYYYMM  varchar2(6);
 vQUARTER         varchar2(8);
 iTracePoint      varchar2(100);
 cErrorText       varchar2(500);

BEGIN

    vPROCEE_YYYYMM := null;
    vQUARTER := null;
    vCURRENT_QUARTER := null;
    vMANUF := null;

 -- --抓當月份系統日期
 -- iTracePoint := '100';
 -- vPROCEE_YYYYMMDD  :=  to_char(sysdate,'YYYYMMDD');
 -- vPROCEE_YYYYMM :=  SUBSTRB(vPROCEE_YYYYMMDD,1,6);

  --上個月資料
     iTracePoint := '100';
     vPROCEE_YYYYMM := TO_CHAR(ADD_MONTHS(SYSDATE, -1), 'YYYYMM');

  --上季資料
      for REC1 in (Select QUARTER
                          FROM DIMENSION_DATE
                          WHERE YYYY = SUBSTRB(vPROCEE_YYYYMM,1,4)
                            AND MM = SUBSTRB(vPROCEE_YYYYMM,5,2)
                            ) loop
         vQUARTER := SUBSTRB(vPROCEE_YYYYMM,1,4) || REC1.QUARTER;
      end loop;

   --當月資料
   --   iTracePoint := '100';
      vCURRENT_YYYYMM := TO_CHAR(ADD_MONTHS(SYSDATE, -0), 'YYYYMM');

   --當季資料
       for REC1 in (Select QUARTER
                           FROM DIMENSION_DATE
                           WHERE YYYY = SUBSTRB(vCURRENT_YYYYMM,1,4)
                             AND MM = SUBSTRB(vCURRENT_YYYYMM,5,2)
                             ) loop
          vCURRENT_QUARTER := SUBSTRB(vPROCEE_YYYYMM,1,4) || REC1.QUARTER;
       end loop;

  for REC1 in (
               select distinct a.MANUF, a.MATGROUP,a.SUBTOT_Q, a.QUARTER
                       from VQA_SUM22_GV_QQ_COMBINE a, VQA_VEW003_VRT_QUARTER_TEST b
                       where a.QUARTER = b.Q4 AND
                             a.MATGROUP <> '000'
                       order by MANUF
                       ) loop
    if REC1.MANUF is not null then
      iTracePoint := '110';
      vMANUF := REC1.MANUF;
    end if;
  end loop;

  if vMANUF is null then
    --若沒抓到資料則寄 error mail
    iTracePoint := '120';
    cErrorText := 'No data!';
    MAIL_FILE_BIDBDBADMIN(in_to_name => 'shuchin@ms.usi.com.tw', subject => '[VQA] PL/SQL VQA_PLSQL_QUALITY_MF_TRAN ERROR', message => '[VQA_PLSQL_QUALITY_MF_TRAN], The tracepoint is  ' || iTracePoint || ' and ErrorText= ' || cErrorText) ;
  else

  --清除重覆資料
    DELETE FROM VQA_070_QUALITY_MATGROUP  WHERE QUARTER = vCURRENT_QUARTER;

--  COMPANY_CODE, QUARTER, MANUF, MATGROUP, LAST_Q4, SCORE_Q4, LAST_Q3, SCORE_Q3, LAST_Q2, SCORE_Q2, LAST_Q1, SCORE_Q1, DATE_TIME
    iTracePoint := '200'; -- WW - MATGROUP - LAST_Q4
    Insert into VQA_070_QUALITY_MATGROUP (
                COMPANY_CODE, QUARTER, MANUF, MATGROUP, LAST_Q1, SCORE_Q1,DATE_TIME )
    select '0000', a.QUARTER, a.MANUF, a.MATGROUP, b.Q4 as LAST_Q4, a.SUBTOT_Q as LAST_Q4_SCORE
			       , to_char(SYSDATE, 'yyyymmddhh24miss') as DATETIME
          from VQA_SUM22_GV_QQ_COMBINE a, VQA_VEW003_VRT_QUARTER_TEST b
                               where a.QUARTER = b.Q4 AND
                                     a.MATGROUP <> '000'
                               order by MANUF, QUARTER;
        commit;



  end if;

-- select '0000', a.QUARTER, a.MANUF, a.MATGROUP, b.Q4 as LAST_Q4, a.SUBTOT_Q as LAST_Q4_SCORE
--              ,(  select c.QUARTER || 'D' || c.SUBTOT_Q as LAST_Q3_SCORE from VQA_SUM22_GV_QQ_COMBINE c, VQA_VEW003_VRT_QUARTER_TEST d
--                           where c.QUARTER = d.Q3 AND
--                                 c.MATGROUP <> '000' AND
--      			                 c.MATGROUP =+ a.MATGROUP AND
--								 c.MANUF =+ a.MANUF
--				 )  as LAST_Q3_SCORE
--                 , to_char(SYSDATE, 'yyyymmddhh24miss') as DATETIME
--        from VQA_SUM22_GV_QQ_COMBINE a, VQA_VEW003_VRT_QUARTER_TEST b
--                             where a.QUARTER = b.Q4 AND
--                                   a.MATGROUP <> '000'

EXCEPTION
   When OTHERS Then
    --有錯誤產生則寄mail
    cErrorText := SQLERRM();
    MAIL_FILE_BIDBDBADMIN(in_to_name => 'shuchin_lin@usiglobal.com', subject => '[VQA] PL/SQL VQA_PLSQL_QUALITY_MF_TRAN ERROR', message => '[VQA_PLSQL_QUALITY_MF_TRAN], The tracepoint is  ' || iTracePoint || ' and ErrorText= ' || cErrorText) ;



END VQA_PLSQL_QUALITY_MF_TRAN;
/

