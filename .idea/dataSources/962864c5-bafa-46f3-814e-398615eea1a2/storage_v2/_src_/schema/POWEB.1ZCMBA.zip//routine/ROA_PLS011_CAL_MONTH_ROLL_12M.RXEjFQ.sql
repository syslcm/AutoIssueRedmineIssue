create PROCEDURE       "ROA_PLS011_CAL_MONTH_ROLL_12M" (
  in_YYYYMM1  in VARCHAR2
  ,in_Kind1 in VARCHAR2
)
AUTHID DEFINER
/* ****************************************************************************************
  PROG-ID      : ROA_PLS011_CAL_MONTH_ROLL_12M
  PROG-ACTION  :   
  Author       : Asan Chang
  Date         : 2018/08/22
  OA No.       : SAI065848
 ========================================================================================== 
 
 2018/10/18 SAI089808 Asan Chang 因應ASE 要求新增cash & rolling 12 months 為計算ROAROE比例基礎,
 請修改USI(NO Bravo)公式. ROAROE\99_BHQCOROA4007
 ==
 *************************************************************************************/
is
   iReccnt              integer;
   In_YYYY              DIMENSION_DATE.YYYY%TYPE;
   In_MM                DIMENSION_DATE.MM%TYPE; 
   In_PERIOD            DIMENSION_DATE.YYYYMM%TYPE;
   From_PERIOD          DIMENSION_DATE.YYYYMM%TYPE;
   DATE_TRANS           varchar2(10);
   In_KIND              varchar2(2); 
   USI_KIND             varchar2(2);
   PC_KIND              varchar2(2);
   This_ACC             varchar2(6);
   L_CNT                NUMBER(6);
   iTracePoint          integer ; 
   In_MM2               integer ;
   inCompany            ROA_PST004_FIXED_ASSETS.COMPANY_CODE%TYPE;
   STR01                varchar2(30);
   STR02                varchar2(30);
   STR03                varchar2(10);
   STR04                varchar2(2);
   STR06                varchar2(20); 
   STR07                varchar2(20); 
   STR08                varchar2(20);  
   STR09                varchar2(800);
   STR10                varchar2(250);
BEGIN
--
  In_YYYY := SUBSTR( in_YYYYMM1, 1, 4);
  In_MM := SUBSTR( in_YYYYMM1, 5, 2); 
  --In_MM2 := In_MM;
  In_MM2 := 12;
  In_PERIOD := In_YYYY || In_MM;
  In_KIND := in_Kind1;
  DATE_TRANS := In_YYYY ||'-'|| In_MM || '-01';

  delete ROA_PST005_MONTH_DATA_ROLL_12M WHERE PERIOD = In_PERIOD AND D_KIND = In_KIND ;
  COMMIT ;   
  
  --get from period
  for REC_PERIOD IN (
    (select TO_CHAR(add_months(TO_DATE(DATE_TRANS, 'YYYY-MM-DD'),-11),'YYYYMM') FROM_PERIOD from dual )
  )
  LOOP
    From_PERIOD := REC_PERIOD.FROM_PERIOD;                 
  END LOOP;
  
                   
  /*****************************************************************************************
      (1)Kind = 01-PC
  ************************************************************************************ */
  if In_KIND IN ('01') THEN 
      iTracePoint := 100 ;  
 
   --(1-01-A) --------  
      STR01 :=  'A00200';
      STR02 :=  'Net Mfg Revenues';
      STR06 :=  'USI'; 
      STR07 :=  'USI(No Bravo)';      
      
      for REC1 IN (
          
          select STR01 D_ACC, TT2.PC,(TT2.AMOUNT/12/30*1000*CCC.DAYS) AMOUNT from
            (
            select TT.PC, sum( TT.amount  ) AMOUNT from
              ( select LPAD(a.pc, 10, '0') PC, a.YYYY||a.Month period , sum( a.amount ) AMOUNT from PNL_MSA001_EM_DATA a
              where 
              --YYYY = In_YYYY and Month = In_MM AND 
              acct_id<> ' ' AND ACCT_NAME = STR02
              GROUP BY PC,a.YYYY||a.Month ORDER BY PC,a.YYYY||a.Month
              ) TT
            where period <= In_PERIOD and period >= From_PERIOD
            GROUP BY PC ORDER BY PC
            )TT2, ROA_UPL010_CCC_DAYS CCC
            WHERE TT2.PC = CCC.PC AND CCC.PERIOD = In_PERIOD          
            
      )
      LOOP
        INSERT INTO ROA_PST005_MONTH_DATA_ROLL_12M
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,REC1.PC ,REC1.D_ACC, (REC1.AMOUNT));                 
      END LOOP; 
 
 
      
  --(1-01-B) --------      
      STR01 :=  'A00800';
      for REC1 IN (
          SELECT STR01 D_ACC, pc, sum( upl_amt ) AMOUNT FROM ROA_UPL004_AR_AP_INV_DATA WHERE
          PERIOD = In_PERIOD AND TYPE IN ( 'AR' )
          GROUP BY PC ORDER BY PC    
      )
      LOOP
        INSERT INTO ROA_PST005_MONTH_DATA_ROLL_12M
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,REC1.PC ,REC1.D_ACC, REC1.AMOUNT);                 
      END LOOP;    
      
--(1-02) --------  
      STR01 :=  'A00900';
      for REC1 IN (
          SELECT STR01 D_ACC, pc, sum( upl_amt ) AMOUNT FROM ROA_UPL004_AR_AP_INV_DATA WHERE
          PERIOD = In_PERIOD AND TYPE IN  ( 'INV', 'ADJ INV' ) 
          GROUP BY PC ORDER BY PC    
      )
      LOOP
        INSERT INTO ROA_PST005_MONTH_DATA_ROLL_12M
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,REC1.PC ,REC1.D_ACC, REC1.AMOUNT);                 
      END LOOP; 
           
  --(1-03) --------  
      STR01 :=  'A01500';
      for REC1 IN (
          SELECT STR01 D_ACC, pc, sum( upl_amt ) AMOUNT FROM ROA_UPL004_AR_AP_INV_DATA WHERE
          PERIOD = In_PERIOD AND TYPE IN  ( 'AP' ) 
          GROUP BY PC ORDER BY PC    
      )
      LOOP
        INSERT INTO ROA_PST005_MONTH_DATA_ROLL_12M
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,REC1.PC ,REC1.D_ACC, REC1.AMOUNT);                 
      END LOOP;       

  --(1-04) --------  
      STR01 :=  'A01000';
      for REC1 IN (
          SELECT STR01 D_ACC, pc, sum( UPL_AMT_LOC  * EX_RATE_TWD ) AMOUNT FROM ROA_PST004_FIXED_ASSETS WHERE
          PERIOD = In_PERIOD AND S_SEQ IN ( '10' ) AND TYPE ='2'
          GROUP BY PC ORDER BY PC    
      )
      LOOP
        INSERT INTO ROA_PST005_MONTH_DATA_ROLL_12M
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,REC1.PC ,REC1.D_ACC, REC1.AMOUNT);                 
      END LOOP; 

  --(1-05) --------  
      STR01 :=  'A01100';
      for REC1 IN (
          SELECT STR01 D_ACC, pc, sum( UPL_AMT_LOC  * EX_RATE_TWD ) AMOUNT FROM ROA_PST004_FIXED_ASSETS WHERE
          PERIOD = In_PERIOD AND S_SEQ IN ( '20' ) AND TYPE ='2'
          GROUP BY PC ORDER BY PC    
      )
      LOOP
        INSERT INTO ROA_PST005_MONTH_DATA_ROLL_12M
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,REC1.PC ,REC1.D_ACC, REC1.AMOUNT);                 
      END LOOP;    

  --(1-06) --------  
      STR01 :=  'A03000';
      for REC1 IN (
          SELECT STR01 D_ACC, pc, sum( UPL_AMT_LOC  * EX_RATE_TWD ) AMOUNT FROM ROA_PST004_FIXED_ASSETS WHERE
          PERIOD = In_PERIOD AND S_SEQ IN ( '20' ) AND TYPE ='2'
          GROUP BY PC ORDER BY PC    
      )
      LOOP
        INSERT INTO ROA_PST005_MONTH_DATA_ROLL_12M
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,REC1.PC ,REC1.D_ACC, REC1.AMOUNT);                 
      END LOOP; 
          


  --(1-07) --------  
      STR01 :=  'A01200';
      for REC1 IN (
          SELECT STR01 D_ACC, pc, sum( UPL_AMT_LOC  * EX_RATE_TWD ) AMOUNT FROM ROA_PST004_FIXED_ASSETS WHERE
          PERIOD = In_PERIOD AND S_SEQ IN ( '30','40' ) AND TYPE ='2'
          GROUP BY PC ORDER BY PC    
      )
      LOOP
        INSERT INTO ROA_PST005_MONTH_DATA_ROLL_12M
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,REC1.PC ,REC1.D_ACC, REC1.AMOUNT);                 
      END LOOP;  
           
  --(1-08) --------  
      STR01 :=  'A03200';
      for REC1 IN (
          SELECT STR01 D_ACC, pc, sum( UPL_AMT_LOC  * EX_RATE_TWD ) AMOUNT FROM ROA_PST004_FIXED_ASSETS WHERE
          PERIOD = In_PERIOD AND S_SEQ IN ( '20','30','40' ) AND TYPE ='2'
          GROUP BY PC ORDER BY PC    
      )
      LOOP
        INSERT INTO ROA_PST005_MONTH_DATA_ROLL_12M
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,REC1.PC ,REC1.D_ACC, REC1.AMOUNT);                 
      END LOOP;      

  --(1-09) --------  
      STR01 :=  'A02900';
      for REC1 IN (
          SELECT STR01 D_ACC, pc, sum( UPL_AMT_LOC  * EX_RATE_TWD ) AMOUNT FROM ROA_PST004_FIXED_ASSETS WHERE
          PERIOD = In_PERIOD AND S_SEQ IN ( '10','20','30','40' ) AND TYPE ='2'
          GROUP BY PC ORDER BY PC    
      )
      LOOP
        INSERT INTO ROA_PST005_MONTH_DATA_ROLL_12M
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,REC1.PC ,REC1.D_ACC, REC1.AMOUNT);                 
      END LOOP;
      
  --(1-10) --------  
      STR01 :=  'A02100';
      STR02 :=  'Net Mfg Revenues';
      for REC1 IN (
          SELECT STR01 D_ACC, LPAD(pc, 10, '0') PC, sum( amount ) AMOUNT FROM PNL_MSA001_EM_DATA WHERE
          YYYY = In_YYYY AND MONTH = In_MM AND acct_id<> ' ' AND ACCT_NAME = STR02
          GROUP BY PC ORDER BY PC    
      )
      LOOP
        INSERT INTO ROA_PST005_MONTH_DATA_ROLL_12M
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,REC1.PC ,REC1.D_ACC, (REC1.AMOUNT * 1000 ));                 
      END LOOP; 
      
  --(1-11) --------  
      STR01 :=  'A02200';
      STR02 :=  '07.050';
      for REC1 IN (
          SELECT STR01 D_ACC, LPAD(pc, 10, '0') PC, sum( amount ) AMOUNT FROM PNL_MSA001_EM_DATA WHERE
          YYYY = In_YYYY AND MONTH = In_MM AND acct_id <> ' ' AND acct_id <= STR02
          GROUP BY PC ORDER BY PC    
      )
      LOOP
        INSERT INTO ROA_PST005_MONTH_DATA_ROLL_12M
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,REC1.PC ,REC1.D_ACC, (REC1.AMOUNT * 1000 ));                 
      END LOOP;       

  --(1-12) --------  
      STR01 :=  'A04000';
      for REC1 IN (
          SELECT STR01 D_ACC, pc, sum( UPL_AMT_LOC  * EX_RATE_TWD ) AMOUNT FROM ROA_PST004_FIXED_ASSETS WHERE
          PERIOD = In_PERIOD AND S_SEQ IN ( '10' ) AND TYPE ='1'
          GROUP BY PC ORDER BY PC    
      )
      LOOP
        INSERT INTO ROA_PST005_MONTH_DATA_ROLL_12M
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,REC1.PC ,REC1.D_ACC, REC1.AMOUNT);                 
      END LOOP;

  --(1-13) --------  
      STR01 :=  'A03600';
      for REC1 IN (
          SELECT STR01 D_ACC, pc, sum( UPL_AMT_LOC  * EX_RATE_TWD ) AMOUNT FROM ROA_PST004_FIXED_ASSETS WHERE
          PERIOD = In_PERIOD AND S_SEQ IN ( '20' ) AND TYPE ='1'
          GROUP BY PC ORDER BY PC    
      )
      LOOP
        INSERT INTO ROA_PST005_MONTH_DATA_ROLL_12M
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,REC1.PC ,REC1.D_ACC, REC1.AMOUNT);                 
      END LOOP;

  --(1-13) --------  
      STR01 :=  'A04100';
      for REC1 IN (
          SELECT STR01 D_ACC, pc, sum( UPL_AMT_LOC  * EX_RATE_TWD ) AMOUNT FROM ROA_PST004_FIXED_ASSETS WHERE
          PERIOD = In_PERIOD AND S_SEQ IN ( '20' ) AND TYPE ='1'
          GROUP BY PC ORDER BY PC    
      )
      LOOP
        INSERT INTO ROA_PST005_MONTH_DATA_ROLL_12M
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,REC1.PC ,REC1.D_ACC, REC1.AMOUNT);                 
      END LOOP;
                
  --(1-14) --------  
      STR01 :=  'A04200';
      for REC1 IN (
          SELECT STR01 D_ACC, pc, sum( UPL_AMT_LOC  * EX_RATE_TWD ) AMOUNT FROM ROA_PST004_FIXED_ASSETS WHERE
          PERIOD = In_PERIOD AND S_SEQ IN ( '30','40' ) AND TYPE ='1'
          GROUP BY PC ORDER BY PC    
      )
      LOOP
        INSERT INTO ROA_PST005_MONTH_DATA_ROLL_12M
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,REC1.PC ,REC1.D_ACC, REC1.AMOUNT);                 
      END LOOP;             

  --(1-15) --------  
      STR01 :=  'A03800';
      for REC1 IN (
          SELECT STR01 D_ACC, pc, sum( UPL_AMT_LOC  * EX_RATE_TWD ) AMOUNT FROM ROA_PST004_FIXED_ASSETS WHERE
          PERIOD = In_PERIOD AND S_SEQ IN ( '20','30','40' ) AND TYPE ='1'
          GROUP BY PC ORDER BY PC    
      )
      LOOP
        INSERT INTO ROA_PST005_MONTH_DATA_ROLL_12M
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,REC1.PC ,REC1.D_ACC, REC1.AMOUNT);                 
      END LOOP; 
  
  --* 2017/07/20 SAI065848 Asan Chang By PC -> subtotal無公式(A01400)
  --(1-16) --------      
      STR01 :=  'A01400';
      for REC1 IN (              
          SELECT D_KEY,   SUM( D_AMOUNT ) AMOUNT
          FROM ROA_PST005_MONTH_DATA_ROLL_12M
          WHERE PERIOD = In_PERIOD
          AND D_KIND = D_KIND AND D_ACC in ( 'A00200','A00300','A00400','A00500','A00600', 'A00700',
                                             'A00800','A00900','A01000','A01100','A01200', 'A01300')
          GROUP BY D_KEY
          order by D_KEY

      )
      LOOP
        INSERT INTO ROA_PST005_MONTH_DATA_ROLL_12M
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,REC1.D_KEY ,STR01, REC1.AMOUNT);                 
      END LOOP;
  
    --(1-16_2) --------  
      STR01 :=  'A03400';
      for REC1 IN (              
          SELECT D_KEY,   SUM( D_AMOUNT ) AMOUNT
          FROM ROA_PST005_MONTH_DATA_ROLL_12M
          WHERE PERIOD = In_PERIOD
          AND D_KIND = D_KIND AND D_ACC in ( 'A00200','A00800','A00900','A04000','A04100','A04200')
          GROUP BY D_KEY
          order by D_KEY

      )
      LOOP
        INSERT INTO ROA_PST005_MONTH_DATA_ROLL_12M
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,REC1.D_KEY ,STR01, REC1.AMOUNT);                 
      END LOOP;
      
 
     --(1-16_3) --------  
      STR01 :=  'A04400';
      for REC1 IN (              
          SELECT D_KEY,   SUM( D_AMOUNT ) AMOUNT
          FROM ROA_PST005_MONTH_DATA_ROLL_12M
          WHERE PERIOD = In_PERIOD
          AND D_KIND = D_KIND AND D_ACC in ( 'A00200','A00800','A00900','A01000','A01100','A01200')
          GROUP BY D_KEY
          order by D_KEY

      )
      LOOP
        INSERT INTO ROA_PST005_MONTH_DATA_ROLL_12M
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,REC1.D_KEY ,STR01, REC1.AMOUNT);              
      END LOOP;

    --(1-16_4) --------  
      STR01 :=  'A04600';
      for REC1 IN (              
          SELECT D_KEY,   SUM( D_AMOUNT ) AMOUNT
          FROM ROA_PST005_MONTH_DATA_ROLL_12M
          WHERE PERIOD = In_PERIOD
          AND D_KIND = D_KIND AND D_ACC in ( 'A00200','A00800','A00900','A04000','A04100','A04200')
          GROUP BY D_KEY
          order by D_KEY

      )
      LOOP
        INSERT INTO ROA_PST005_MONTH_DATA_ROLL_12M
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,REC1.D_KEY ,STR01, REC1.AMOUNT);                 
      END LOOP; 
      
    --(1-17) -------- 
      STR01 :=  'A01700';
      for REC1 IN (              
           select b.pc , (a.AMOUNT1 - b.AMOUNT2) AMOUNT from
          (
          SELECT D_KEY,   SUM( D_AMOUNT ) AMOUNT1
          FROM ROA_PST005_MONTH_DATA_ROLL_12M
          WHERE PERIOD = In_PERIOD
          AND D_KIND = D_KIND AND D_ACC in ( 'A01400')
          GROUP BY D_KEY
          order by D_KEY
          ) a,
          (
          SELECT  pc, sum( upl_amt ) AMOUNT2 FROM ROA_UPL004_AR_AP_INV_DATA WHERE
          PERIOD = In_PERIOD AND TYPE IN  ( 'AP' )
          GROUP BY PC ORDER BY PC
          ) b
          where a.D_KEY = b.PC
      )
      LOOP
        INSERT INTO ROA_PST005_MONTH_DATA_ROLL_12M
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,REC1.PC,STR01, REC1.AMOUNT);                 
      END LOOP;


  --(1-18) --------  
      STR01 :=  'C_NIB_Y_22';
      --STR02 :=  In_YYYY || '01';
      for REC1 IN (
        SELECT D_KEY,  (( SUM( D_AMOUNT ) / In_MM2 ) * 12)  AMOUNT
        FROM ROA_PST005_MONTH_DATA_ROLL_12M
        WHERE PERIOD >= From_PERIOD and  PERIOD <= In_PERIOD
        AND D_KIND = In_KIND AND D_ACC = 'A02200'
      GROUP BY D_KEY
      order by D_KEY
  
      )
      LOOP
        INSERT INTO ROA_PST005_MONTH_DATA_ROLL_12M
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND, REC1.D_KEY ,STR01, REC1.AMOUNT);                 
      END LOOP; 

  --(1-19) --------  
      STR01 :=  'C_SUB_A_14';
      --STR02 :=  In_YYYY || '01';
      for REC1 IN (
        SELECT D_KEY,  ( SUM( D_AMOUNT ) / In_MM2 )  AMOUNT
        FROM ROA_PST005_MONTH_DATA_ROLL_12M
        WHERE PERIOD >= From_PERIOD and  PERIOD <= In_PERIOD
        AND D_KIND = In_KIND AND D_ACC = 'A01400'
      GROUP BY D_KEY
      order by D_KEY
  
      )
      LOOP
        INSERT INTO ROA_PST005_MONTH_DATA_ROLL_12M
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND, REC1.D_KEY ,STR01, REC1.AMOUNT);                 
      END LOOP; 

  --(1-20) --------  
      STR01 :=  'C_EQU_A_17';
      --STR02 :=  In_YYYY || '01';
      for REC1 IN (
        SELECT D_KEY,  ( SUM( D_AMOUNT ) / In_MM2 )  AMOUNT
        FROM ROA_PST005_MONTH_DATA_ROLL_12M
        WHERE PERIOD >= From_PERIOD and  PERIOD <= In_PERIOD
        AND D_KIND = In_KIND AND D_ACC = 'A01700'
      GROUP BY D_KEY
      order by D_KEY
  
      )
      LOOP
        INSERT INTO ROA_PST005_MONTH_DATA_ROLL_12M
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND, REC1.D_KEY ,STR01, REC1.AMOUNT);                 
      END LOOP;

  --(1-21) --------  
      STR01 :=  'C_REV_Y_21';
      --STR02 :=  In_YYYY || '01';
      for REC1 IN (
        SELECT D_KEY,  (( SUM( D_AMOUNT ) / In_MM2 )* 12)  AMOUNT
        FROM ROA_PST005_MONTH_DATA_ROLL_12M
        WHERE PERIOD >= From_PERIOD and  PERIOD <= In_PERIOD
        AND D_KIND = In_KIND AND D_ACC = 'A02100'
      GROUP BY D_KEY
      order by D_KEY
  
      )
      LOOP
        INSERT INTO ROA_PST005_MONTH_DATA_ROLL_12M
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND, REC1.D_KEY ,STR01, REC1.AMOUNT);                 
      END LOOP;

  --(1-22) --------  
      STR01 :=  'C_SFA_A_10N12';
      --STR02 :=  In_YYYY || '01';
      for REC1 IN (
        SELECT D_KEY,  ( SUM( D_AMOUNT ) / In_MM2 )  AMOUNT
        FROM ROA_PST005_MONTH_DATA_ROLL_12M
        WHERE PERIOD >= From_PERIOD and  PERIOD <= In_PERIOD
        AND D_KIND = In_KIND AND D_ACC in ( 'A01000', 'A01100', 'A01200')
      GROUP BY D_KEY
      order by D_KEY
  
      )
      LOOP
        INSERT INTO ROA_PST005_MONTH_DATA_ROLL_12M
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND, REC1.D_KEY ,STR01, REC1.AMOUNT);                 
      END LOOP;

  --(1-23) --------  
      STR01 :=  'C_BV1_A_30';
      --STR02 :=  In_YYYY || '01';
      for REC1 IN (
        SELECT D_KEY,  ( SUM( D_AMOUNT ) / In_MM2 )  AMOUNT
        FROM ROA_PST005_MONTH_DATA_ROLL_12M
        WHERE PERIOD >= From_PERIOD and  PERIOD <= In_PERIOD
        AND D_KIND = In_KIND AND D_ACC in ( 'A03000' )
      GROUP BY D_KEY
      order by D_KEY
  
      )
      LOOP
        INSERT INTO ROA_PST005_MONTH_DATA_ROLL_12M
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND, REC1.D_KEY ,STR01, REC1.AMOUNT);                 
      END LOOP;

  --(1-24) --------  
      STR01 :=  'C_BV2_A_32';
      --STR02 :=  In_YYYY || '01';
      for REC1 IN (
        SELECT D_KEY,  ( SUM( D_AMOUNT ) / In_MM2 )  AMOUNT
        FROM ROA_PST005_MONTH_DATA_ROLL_12M
        WHERE PERIOD >= From_PERIOD and  PERIOD <= In_PERIOD
        AND D_KIND = In_KIND AND D_ACC in ( 'A03200' )
      GROUP BY D_KEY
      order by D_KEY
  
      )
      LOOP
        INSERT INTO ROA_PST005_MONTH_DATA_ROLL_12M
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND, REC1.D_KEY ,STR01, REC1.AMOUNT);                 
      END LOOP;

  --(1-25) --------  
      STR01 :=  'C_OV1_A_34';
      --STR02 :=  In_YYYY || '01';
      for REC1 IN (
        SELECT D_KEY,  ( SUM( D_AMOUNT ) / In_MM2 )  AMOUNT
        FROM ROA_PST005_MONTH_DATA_ROLL_12M
        WHERE PERIOD >= From_PERIOD and  PERIOD <= In_PERIOD
        AND D_KIND = In_KIND AND D_ACC in ( 'A03400' )
      GROUP BY D_KEY
      order by D_KEY
  
      )
      LOOP
        INSERT INTO ROA_PST005_MONTH_DATA_ROLL_12M
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND, REC1.D_KEY ,STR01, REC1.AMOUNT);                 
      END LOOP;


  --(1-26) --------  
      STR01 :=  'C_OV2_A_36';
      --STR02 :=  In_YYYY || '01';
      for REC1 IN (
        SELECT D_KEY,  ( SUM( D_AMOUNT ) / In_MM2 )  AMOUNT
        FROM ROA_PST005_MONTH_DATA_ROLL_12M
        WHERE PERIOD >= From_PERIOD and  PERIOD <= In_PERIOD
        AND D_KIND = In_KIND AND D_ACC in ( 'A03600' )
      GROUP BY D_KEY
      order by D_KEY
  
      )
      LOOP
        INSERT INTO ROA_PST005_MONTH_DATA_ROLL_12M
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND, REC1.D_KEY ,STR01, REC1.AMOUNT);                 
      END LOOP;

  --(1-27) --------  
      STR01 :=  'C_OV3_A_38';
      --STR02 :=  In_YYYY || '01';
      for REC1 IN (
        SELECT D_KEY,  ( SUM( D_AMOUNT ) / In_MM2 )  AMOUNT
        FROM ROA_PST005_MONTH_DATA_ROLL_12M
        WHERE PERIOD >= From_PERIOD and  PERIOD <= In_PERIOD
        AND D_KIND = In_KIND AND D_ACC in ( 'A03800' )
      GROUP BY D_KEY
      order by D_KEY
  
      )
      LOOP
        INSERT INTO ROA_PST005_MONTH_DATA_ROLL_12M
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND, REC1.D_KEY ,STR01, REC1.AMOUNT);                 
      END LOOP;
      
  --(1-28) --------  
      STR01 :=  'C_BV3_A_44';
      --STR02 :=  In_YYYY || '01';
      for REC1 IN (
        SELECT D_KEY,  ( SUM( D_AMOUNT ) / In_MM2 )  AMOUNT
        FROM ROA_PST005_MONTH_DATA_ROLL_12M
        WHERE PERIOD >= From_PERIOD and  PERIOD <= In_PERIOD
        AND D_KIND = In_KIND AND D_ACC in ( 'A04400' )
      GROUP BY D_KEY
      order by D_KEY
  
      )
      LOOP
        INSERT INTO ROA_PST005_MONTH_DATA_ROLL_12M
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND, REC1.D_KEY ,STR01, REC1.AMOUNT);                 
      END LOOP;   

  --(1-29) --------  
      STR01 :=  'C_OV4_A_46';
      --STR02 :=  In_YYYY || '01';
      for REC1 IN (
        SELECT D_KEY,  ( SUM( D_AMOUNT ) / In_MM2 )  AMOUNT
        FROM ROA_PST005_MONTH_DATA_ROLL_12M
        WHERE PERIOD >= From_PERIOD and  PERIOD <= In_PERIOD
        AND D_KIND = In_KIND AND D_ACC in ( 'A04600' )
      GROUP BY D_KEY
      order by D_KEY
  
      )
      LOOP
        INSERT INTO ROA_PST005_MONTH_DATA_ROLL_12M
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND, REC1.D_KEY ,STR01, REC1.AMOUNT);                 
      END LOOP;       

      delete  FROM   ROA_PST005_MONTH_DATA_ROLL_12M WHERE ( D_KEY = STR06 OR D_KEY = STR07 ) AND D_KIND = In_KIND AND PERIOD = In_PERIOD;
      COMMIT; 


/*****************************************************************************************
      (3)Kind = 09-USI
  ************************************************************************************ */    
  ELSIF In_KIND IN ('09') THEN
    In_KIND := '09'; 
    STR06 :=  'USI';


  --(3-26) --------      
      STR01 :=  'A00200';
      for REC1 IN (
          select SUM(a.upl_amt * b.WEIGHTS ) Amount from ROA_UPL003_BS_DATA a join ROA_MAP002_BS_ACCOUNT b
          on b.S_DESC = a.S_DESC where b.account = 'Cash' and PERIOD = In_PERIOD 
          and company_code = STR06               
      )
      LOOP
        INSERT INTO ROA_PST005_MONTH_DATA_ROLL_12M
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR06 ,STR01, REC1.AMOUNT);                 
      END LOOP;  
      
  --(3-27) --------      
      STR01 :=  'A00400';
      for REC1 IN (
          select SUM(a.upl_amt * b.WEIGHTS ) Amount from ROA_UPL003_BS_DATA a join ROA_MAP002_BS_ACCOUNT b
          on b.S_DESC = a.S_DESC where b.account = 'Financial Asset' and PERIOD = In_PERIOD
          and company_code = STR06                 
      )
      LOOP
        INSERT INTO ROA_PST005_MONTH_DATA_ROLL_12M
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR06 ,STR01, REC1.AMOUNT);                 
      END LOOP;

  --(3-28) --------      
      STR01 :=  'A00500';
      for REC1 IN (
          select SUM(a.upl_amt * b.WEIGHTS ) Amount from ROA_UPL003_BS_DATA a join ROA_MAP002_BS_ACCOUNT b
          on b.S_DESC = a.S_DESC where b.account = 'Others Receivable' and PERIOD = In_PERIOD  
          and company_code = STR06               
      )
      LOOP
        INSERT INTO ROA_PST005_MONTH_DATA_ROLL_12M
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR06 ,STR01, REC1.AMOUNT);                 
      END LOOP;
      
  --(3-29) --------      
      STR01 :=  'A00600';
      for REC1 IN (
          select SUM(a.upl_amt * b.WEIGHTS ) Amount from ROA_UPL003_BS_DATA a join ROA_MAP002_BS_ACCOUNT b
          on b.S_DESC = a.S_DESC where b.account = 'Deferred Tax' and PERIOD = In_PERIOD  
          and company_code = STR06               
      )
      LOOP
        INSERT INTO ROA_PST005_MONTH_DATA_ROLL_12M
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR06 ,STR01, REC1.AMOUNT);                 
      END LOOP;      
      
  --(3-30) --------      
      STR01 :=  'A00700';
      for REC1 IN (
          select SUM(a.upl_amt * b.WEIGHTS ) Amount from ROA_UPL003_BS_DATA a join ROA_MAP002_BS_ACCOUNT b
          on b.S_DESC = a.S_DESC where b.account = 'Deferred charges' and PERIOD = In_PERIOD 
          and company_code = STR06                
      )
      LOOP
        INSERT INTO ROA_PST005_MONTH_DATA_ROLL_12M
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR06 ,STR01, REC1.AMOUNT);                 
      END LOOP;

  --(3-31) --------      
      STR01 :=  'A01400';
      for REC1 IN (
          select SUM(a.upl_amt * b.WEIGHTS ) Amount from ROA_UPL003_BS_DATA a join ROA_MAP002_BS_ACCOUNT b
          on b.S_DESC = a.S_DESC where b.account = 'Total assets' and PERIOD = In_PERIOD 
          and company_code = STR06                
      )
      LOOP
        INSERT INTO ROA_PST005_MONTH_DATA_ROLL_12M
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR06 ,STR01, REC1.AMOUNT);                 
      END LOOP;

  --(3-32) --------      
      STR01 :=  'A01700';
      for REC1 IN (
          select SUM(a.upl_amt * b.WEIGHTS ) Amount from ROA_UPL003_BS_DATA a join ROA_MAP002_BS_ACCOUNT b
          on b.S_DESC = a.S_DESC where b.account = 'Equity' and PERIOD = In_PERIOD 
          and company_code = STR06                
      )
      LOOP
        INSERT INTO ROA_PST005_MONTH_DATA_ROLL_12M
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR06 ,STR01, REC1.AMOUNT);                 
      END LOOP;
      
   --(3-33) --------      
      STR01 :=  'A01800';
      for REC1 IN (              
          select (Amount1-Amount2) Amount from
          (
          select SUM(a.upl_amt * b.WEIGHTS ) Amount1 from ROA_UPL003_BS_DATA a join ROA_MAP002_BS_ACCOUNT b
          on b.S_DESC = a.S_DESC where b.account = 'Total liabilities' and PERIOD = In_PERIOD
          and company_code = STR06  ),
          (
          select SUM(a.upl_amt * b.WEIGHTS ) Amount2 from ROA_UPL003_BS_DATA a join ROA_MAP002_BS_ACCOUNT b
          on b.S_DESC = a.S_DESC where b.account = 'AP-3rd' and PERIOD = In_PERIOD
          and company_code = STR06   )


      )
      LOOP
        INSERT INTO ROA_PST005_MONTH_DATA_ROLL_12M
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR06 ,STR01, REC1.AMOUNT);                 
      END LOOP;     
                
  --(3-01) --------      
      STR01 :=  'A00800';
      for REC1 IN (
          select SUM(a.upl_amt * b.WEIGHTS ) Amount from ROA_UPL003_BS_DATA a join ROA_MAP002_BS_ACCOUNT b
          on b.S_DESC = a.S_DESC where b.account = 'AR-3rd' and PERIOD = In_PERIOD  
          and company_code = STR06             
      )
      LOOP
        INSERT INTO ROA_PST005_MONTH_DATA_ROLL_12M
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR06 ,STR01, REC1.AMOUNT);                 
      END LOOP;   
      
--(3-02) --------  
      STR01 :=  'A00900';
      for REC1 IN (
          --select SUM(a.upl_amt * b.WEIGHTS ) Amount from ROA_UPL003_BS_DATA a join ROA_MAP002_BS_ACCOUNT b
          --on b.S_DESC = a.S_DESC where b.account = 'INV' and PERIOD = In_PERIOD     
          --and company_code = STR06     
          select a.AMOUNT1+b.AMOUNT2 Amount from
          (select SUM(a.upl_amt * b.WEIGHTS ) AMOUNT1 from ROA_UPL003_BS_DATA a join ROA_MAP002_BS_ACCOUNT b
          on b.S_DESC = a.S_DESC where b.account = 'INV' and PERIOD = In_PERIOD
          and company_code = STR06 ) a,
          (SELECT  decode(sum(upl_amt),null,0,sum(upl_amt)) AMOUNT2 FROM ROA_UPL004_AR_AP_INV_DATA WHERE
          PERIOD = In_PERIOD AND TYPE IN  ( 'ADJ INV' )) b       
      )
      LOOP
        INSERT INTO ROA_PST005_MONTH_DATA_ROLL_12M
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR06 ,STR01, REC1.AMOUNT);                 
      END LOOP; 
           
  --(3-03) --------  
      STR01 :=  'A01500';
      for REC1 IN (
          select SUM(a.upl_amt * b.WEIGHTS ) Amount from ROA_UPL003_BS_DATA a join ROA_MAP002_BS_ACCOUNT b
          on b.S_DESC = a.S_DESC where b.account = 'AP-3rd' and PERIOD = In_PERIOD   
          and company_code = STR06              
      )
      LOOP
        INSERT INTO ROA_PST005_MONTH_DATA_ROLL_12M
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR06 ,STR01, REC1.AMOUNT);                 
      END LOOP;      

  --(3-04) --------  
      STR01 :=  'A01000';
      for REC1 IN (
          SELECT STR01 D_ACC,  sum( UPL_AMT_LOC  * EX_RATE_TWD ) AMOUNT FROM ROA_PST004_FIXED_ASSETS WHERE
          PERIOD = In_PERIOD AND S_SEQ IN ( '10' ) AND TYPE ='2'    
              
      )
      LOOP
        INSERT INTO ROA_PST005_MONTH_DATA_ROLL_12M
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR06 ,REC1.D_ACC, REC1.AMOUNT);                 
      END LOOP; 

  --(3-05) --------  
      STR01 :=  'A01100';
      for REC1 IN (
          SELECT STR01 D_ACC,  sum( UPL_AMT_LOC  * EX_RATE_TWD ) AMOUNT FROM ROA_PST004_FIXED_ASSETS WHERE
          PERIOD = In_PERIOD AND S_SEQ IN ( '20' ) AND TYPE ='2'
              
      )
      LOOP
        INSERT INTO ROA_PST005_MONTH_DATA_ROLL_12M
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR06 ,REC1.D_ACC, REC1.AMOUNT);                 
      END LOOP;    

  --(3-06) --------  
      STR01 :=  'A03000';
      for REC1 IN (
          SELECT STR01 D_ACC,  sum( UPL_AMT_LOC  * EX_RATE_TWD ) AMOUNT FROM ROA_PST004_FIXED_ASSETS WHERE
          PERIOD = In_PERIOD AND S_SEQ IN ( '20' ) AND TYPE ='2'
              
      )
      LOOP
        INSERT INTO ROA_PST005_MONTH_DATA_ROLL_12M
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR06 ,REC1.D_ACC, REC1.AMOUNT);                 
      END LOOP;   
      

      
      
  --(3-07) --------  
      STR01 :=  'A01200';
      for REC1 IN (
          SELECT STR01 D_ACC,  sum( UPL_AMT_LOC  * EX_RATE_TWD ) AMOUNT FROM ROA_PST004_FIXED_ASSETS WHERE
          PERIOD = In_PERIOD AND S_SEQ IN ( '30','40' ) AND TYPE ='2'
              
      )
      LOOP
        INSERT INTO ROA_PST005_MONTH_DATA_ROLL_12M
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR06 ,REC1.D_ACC, REC1.AMOUNT);                 
      END LOOP;  
           
  --(3-08) --------  
      STR01 :=  'A03200';
      for REC1 IN (
          SELECT STR01 D_ACC,  sum( UPL_AMT_LOC  * EX_RATE_TWD ) AMOUNT FROM ROA_PST004_FIXED_ASSETS WHERE
          PERIOD = In_PERIOD AND S_SEQ IN ( '20','30','40' ) AND TYPE ='2'
              
      )
      LOOP
        INSERT INTO ROA_PST005_MONTH_DATA_ROLL_12M
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR06 ,REC1.D_ACC, REC1.AMOUNT);                 
      END LOOP;      

  --(3-09) --------  
      STR01 :=  'A02900';
      for REC1 IN (
          SELECT STR01 D_ACC,  sum( UPL_AMT_LOC  * EX_RATE_TWD ) AMOUNT FROM ROA_PST004_FIXED_ASSETS WHERE
          PERIOD = In_PERIOD AND S_SEQ IN ( '10','20','30','40' ) AND TYPE ='2'
              
      )
      LOOP
        INSERT INTO ROA_PST005_MONTH_DATA_ROLL_12M
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR06 ,REC1.D_ACC, REC1.AMOUNT);                 
      END LOOP;
      
  --(3-10) --------  
      STR01 :=  'A02100';
      STR02 :=  'Net Mfg Revenues';
      for REC1 IN (
          SELECT STR01 D_ACC,   sum( amount ) AMOUNT FROM PNL_MSA001_EM_DATA WHERE
          YYYY = In_YYYY AND MONTH = In_MM AND acct_id<> ' ' AND ACCT_NAME = STR02
              
      )
      LOOP
        INSERT INTO ROA_PST005_MONTH_DATA_ROLL_12M
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR06 ,REC1.D_ACC, (REC1.AMOUNT * 1000 ));                 
      END LOOP; 
      
  --(3-11) --------  
      STR01 :=  'A02200';
      STR02 :=  '07.050';
      for REC1 IN (
          SELECT STR01 D_ACC,   sum( amount ) AMOUNT FROM PNL_MSA001_EM_DATA WHERE
          YYYY = In_YYYY AND MONTH = In_MM AND acct_id <> ' ' AND acct_id <= STR02
              
      )
      LOOP
        INSERT INTO ROA_PST005_MONTH_DATA_ROLL_12M
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR06 ,REC1.D_ACC, (REC1.AMOUNT * 1000 ));                 
      END LOOP;       

  --(3-12) --------  
      STR01 :=  'A04000';
      for REC1 IN (
          SELECT STR01 D_ACC,  sum( UPL_AMT_LOC  * EX_RATE_TWD ) AMOUNT FROM ROA_PST004_FIXED_ASSETS WHERE
          PERIOD = In_PERIOD AND S_SEQ IN ( '10' ) AND TYPE ='1'
              
      )
      LOOP
        INSERT INTO ROA_PST005_MONTH_DATA_ROLL_12M
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR06 ,REC1.D_ACC, REC1.AMOUNT);                 
      END LOOP;

  --(3-13) --------  
      STR01 :=  'A03600';
      for REC1 IN (
          SELECT STR01 D_ACC,  sum( UPL_AMT_LOC  * EX_RATE_TWD ) AMOUNT FROM ROA_PST004_FIXED_ASSETS WHERE
          PERIOD = In_PERIOD AND S_SEQ IN ( '20' ) AND TYPE ='1'
              
      )
      LOOP
        INSERT INTO ROA_PST005_MONTH_DATA_ROLL_12M
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR06 ,REC1.D_ACC, REC1.AMOUNT);                 
      END LOOP;

  --(3-13) --------  
      STR01 :=  'A04100';
      for REC1 IN (
          SELECT STR01 D_ACC,  sum( UPL_AMT_LOC  * EX_RATE_TWD ) AMOUNT FROM ROA_PST004_FIXED_ASSETS WHERE
          PERIOD = In_PERIOD AND S_SEQ IN ( '20' ) AND TYPE ='1'
              
      )
      LOOP
        INSERT INTO ROA_PST005_MONTH_DATA_ROLL_12M
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR06 ,REC1.D_ACC, REC1.AMOUNT);                 
      END LOOP;
                
  --(3-14) --------  
      STR01 :=  'A04200';
      for REC1 IN (
          SELECT STR01 D_ACC,  sum( UPL_AMT_LOC  * EX_RATE_TWD ) AMOUNT FROM ROA_PST004_FIXED_ASSETS WHERE
          PERIOD = In_PERIOD AND S_SEQ IN ( '30','40' ) AND TYPE ='1'
              
      )
      LOOP
        INSERT INTO ROA_PST005_MONTH_DATA_ROLL_12M
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR06 ,REC1.D_ACC, REC1.AMOUNT);                 
      END LOOP;             

  --(3-15) --------  
      STR01 :=  'A03800';
      for REC1 IN (
          SELECT STR01 D_ACC,  sum( UPL_AMT_LOC  * EX_RATE_TWD ) AMOUNT FROM ROA_PST004_FIXED_ASSETS WHERE
          PERIOD = In_PERIOD AND S_SEQ IN ( '20','30','40' ) AND TYPE ='1'
              
      )
      LOOP
        INSERT INTO ROA_PST005_MONTH_DATA_ROLL_12M
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR06 ,REC1.D_ACC, REC1.AMOUNT);                 
      END LOOP; 

  --(3-16_2) --------  
      STR01 :=  'A03400';
      for REC1 IN (
          select (a.AMOUNT1 - b.AMOUNT2 + c.AMOUNT3 ) AMOUNT from
          ( select SUM(a.upl_amt * b.WEIGHTS ) AMOUNT1 from ROA_UPL003_BS_DATA a join ROA_MAP002_BS_ACCOUNT b
          on b.S_DESC = a.S_DESC where b.account = 'Total assets' and PERIOD = In_PERIOD
          and company_code = STR06
          ) a,
          (SELECT SUM( D_AMOUNT ) AMOUNT2
          FROM ROA_PST005_MONTH_DATA_ROLL_12M
          WHERE PERIOD = In_PERIOD
          AND D_KIND = In_KIND AND D_ACC in ( 'A01000','A01100','A01200')
          ) b,
          (SELECT SUM( D_AMOUNT ) AMOUNT3
          FROM ROA_PST005_MONTH_DATA_ROLL_12M
          WHERE PERIOD = In_PERIOD
          AND D_KIND = In_KIND AND D_ACC in ( 'A04000','A04100','A04200')
          ) c                         
      )
      LOOP
        INSERT INTO ROA_PST005_MONTH_DATA_ROLL_12M
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR06 ,STR01, REC1.AMOUNT);                 
      END LOOP;

    --(3-16_3) --------  
      STR01 :=  'A04400';
      for REC1 IN (              
          SELECT SUM( D_AMOUNT ) AMOUNT
          FROM ROA_PST005_MONTH_DATA_ROLL_12M
          WHERE PERIOD = In_PERIOD
          AND D_KIND = In_KIND AND D_ACC in ( 'A00200','A00800','A00900','A01000','A01100','A01200')
      )
      LOOP
        INSERT INTO ROA_PST005_MONTH_DATA_ROLL_12M
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR06 ,STR01, REC1.AMOUNT);              
      END LOOP;

    --(3-16_4) --------  
      STR01 :=  'A04600';
      for REC1 IN (              
          SELECT SUM( D_AMOUNT ) AMOUNT
          FROM ROA_PST005_MONTH_DATA_ROLL_12M
          WHERE PERIOD = In_PERIOD
          AND D_KIND = In_KIND AND D_ACC in ( 'A00200','A00800','A00900','A04000','A04100','A04200')

      )
      LOOP
        INSERT INTO ROA_PST005_MONTH_DATA_ROLL_12M
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR06 ,STR01, REC1.AMOUNT);                  
      END LOOP; 

  --(3-16) --------  
      STR01 :=  'C_NIB_Y_22';
      --STR02 :=  In_YYYY || '01';
      for REC1 IN (
        SELECT (( SUM( D_AMOUNT ) / In_MM2 ) * 12)  AMOUNT
        FROM ROA_PST005_MONTH_DATA_ROLL_12M
        WHERE PERIOD >= From_PERIOD and  PERIOD <= In_PERIOD
        AND D_KIND = In_KIND AND D_ACC = 'A02200' 
      )
      LOOP
        INSERT INTO ROA_PST005_MONTH_DATA_ROLL_12M
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND, STR06 ,STR01, REC1.AMOUNT);                 
      END LOOP; 

  --(3-17) --------  
      STR01 :=  'C_SUB_A_14';
      --STR02 :=  In_YYYY || '01';
      for REC1 IN (
        SELECT ( SUM( D_AMOUNT ) / In_MM2 )  AMOUNT
        FROM ROA_PST005_MONTH_DATA_ROLL_12M
        WHERE PERIOD >= From_PERIOD and  PERIOD <= In_PERIOD
        AND D_KIND = In_KIND AND D_ACC = 'A01400'  
      )
      LOOP
        INSERT INTO ROA_PST005_MONTH_DATA_ROLL_12M
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND, STR06 ,STR01, REC1.AMOUNT);                 
      END LOOP; 

  --(3-18) --------  
      STR01 :=  'C_EQU_A_17';
      --STR02 :=  In_YYYY || '01';
      for REC1 IN (
        SELECT ( SUM( D_AMOUNT ) / In_MM2 )  AMOUNT
        FROM ROA_PST005_MONTH_DATA_ROLL_12M
        WHERE PERIOD >= From_PERIOD and  PERIOD <= In_PERIOD
        AND D_KIND = In_KIND AND D_ACC = 'A01700'  
      )
      LOOP
        INSERT INTO ROA_PST005_MONTH_DATA_ROLL_12M
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND, STR06 ,STR01, REC1.AMOUNT);                 
      END LOOP;

  --(3-19) --------  
      STR01 :=  'C_REV_Y_21';
      --STR02 :=  In_YYYY || '01';
      for REC1 IN (
        SELECT   (( SUM( D_AMOUNT ) / In_MM2 )* 12)  AMOUNT
        FROM ROA_PST005_MONTH_DATA_ROLL_12M
        WHERE PERIOD >= From_PERIOD and  PERIOD <= In_PERIOD
        AND D_KIND = In_KIND AND D_ACC = 'A02100'  
      )
      LOOP
        INSERT INTO ROA_PST005_MONTH_DATA_ROLL_12M
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND, STR06 ,STR01, REC1.AMOUNT);                 
      END LOOP;

  --(3-20) --------  
      STR01 :=  'C_SFA_A_10N12';
      --STR02 :=  In_YYYY || '01';
      for REC1 IN (
        SELECT   ( SUM( D_AMOUNT ) / In_MM2 )  AMOUNT
        FROM ROA_PST005_MONTH_DATA_ROLL_12M
        WHERE PERIOD >= From_PERIOD and  PERIOD <= In_PERIOD
        AND D_KIND = In_KIND AND D_ACC in ( 'A01000', 'A01100', 'A01200')  
      )
      LOOP
        INSERT INTO ROA_PST005_MONTH_DATA_ROLL_12M
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND, STR06 ,STR01, REC1.AMOUNT);                 
      END LOOP;

  --(3-21) --------  
      STR01 :=  'C_BV1_A_30';
      --STR02 :=  In_YYYY || '01';
      for REC1 IN (
        SELECT ( SUM( D_AMOUNT ) / In_MM2 )  AMOUNT
        FROM ROA_PST005_MONTH_DATA_ROLL_12M
        WHERE PERIOD >= From_PERIOD and  PERIOD <= In_PERIOD
        AND D_KIND = In_KIND AND D_ACC in ( 'A03000' )  
      )
      LOOP
        INSERT INTO ROA_PST005_MONTH_DATA_ROLL_12M
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND, STR06 ,STR01, REC1.AMOUNT);                 
      END LOOP;

  --(3-22) --------  
      STR01 :=  'C_BV2_A_32';
      --STR02 :=  In_YYYY || '01';
      for REC1 IN (
        SELECT ( SUM( D_AMOUNT ) / In_MM2 )  AMOUNT
        FROM ROA_PST005_MONTH_DATA_ROLL_12M
        WHERE PERIOD >= From_PERIOD and  PERIOD <= In_PERIOD
        AND D_KIND = In_KIND AND D_ACC in ( 'A03200' )
      )
      LOOP
        INSERT INTO ROA_PST005_MONTH_DATA_ROLL_12M
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND, STR06 ,STR01, REC1.AMOUNT);                 
      END LOOP;

  --(3-23) --------  
      STR01 :=  'C_OV1_A_34';
      --STR02 :=  In_YYYY || '01';
      for REC1 IN (
        SELECT ( SUM( D_AMOUNT ) / In_MM2 )  AMOUNT
        FROM ROA_PST005_MONTH_DATA_ROLL_12M
        WHERE PERIOD >= From_PERIOD and  PERIOD <= In_PERIOD
        AND D_KIND = In_KIND AND D_ACC in ( 'A03400' )  
      )
      LOOP
        INSERT INTO ROA_PST005_MONTH_DATA_ROLL_12M
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND, STR06 ,STR01, REC1.AMOUNT);                 
      END LOOP;


  --(3-24) --------  
      STR01 :=  'C_OV2_A_36';
      --STR02 :=  In_YYYY || '01';
      for REC1 IN (
        SELECT ( SUM( D_AMOUNT ) / In_MM2 )  AMOUNT
        FROM ROA_PST005_MONTH_DATA_ROLL_12M
        WHERE PERIOD >= From_PERIOD and  PERIOD <= In_PERIOD
        AND D_KIND = In_KIND AND D_ACC in ( 'A03600' )  
      )
      LOOP
        INSERT INTO ROA_PST005_MONTH_DATA_ROLL_12M
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND, STR06 ,STR01, REC1.AMOUNT);                 
      END LOOP;

  --(3-25) --------  
      STR01 :=  'C_OV3_A_38';
      --STR02 :=  In_YYYY || '01';
      for REC1 IN (
        SELECT  ( SUM( D_AMOUNT ) / In_MM2 )  AMOUNT
        FROM ROA_PST005_MONTH_DATA_ROLL_12M
        WHERE PERIOD >= From_PERIOD and  PERIOD <= In_PERIOD
        AND D_KIND = In_KIND AND D_ACC in ( 'A03800' )  
      )
      LOOP
        INSERT INTO ROA_PST005_MONTH_DATA_ROLL_12M
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND, STR06 ,STR01, REC1.AMOUNT);                 
      END LOOP;
  
  --(3-26) --------  
      STR01 :=  'C_BV3_A_44';
      --STR02 :=  In_YYYY || '01';
      for REC1 IN (
        SELECT  ( SUM( D_AMOUNT ) / In_MM2 )  AMOUNT
        FROM ROA_PST005_MONTH_DATA_ROLL_12M
        WHERE PERIOD >= From_PERIOD and  PERIOD <= In_PERIOD
        AND D_KIND = In_KIND AND D_ACC in ( 'A04400' )  
      )
      LOOP
        INSERT INTO ROA_PST005_MONTH_DATA_ROLL_12M
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND, STR06 ,STR01, REC1.AMOUNT);                 
      END LOOP; 
      
  --(3-27) --------  
      STR01 :=  'C_OV4_A_46';
      --STR02 :=  In_YYYY || '01';
      for REC1 IN (
        SELECT  ( SUM( D_AMOUNT ) / In_MM2 )  AMOUNT
        FROM ROA_PST005_MONTH_DATA_ROLL_12M
        WHERE PERIOD >= From_PERIOD and  PERIOD <= In_PERIOD
        AND D_KIND = In_KIND AND D_ACC in ( 'A04600' )  
      )
      LOOP
        INSERT INTO ROA_PST005_MONTH_DATA_ROLL_12M
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND, STR06 ,STR01, REC1.AMOUNT);                 
      END LOOP;  
              
      delete  FROM   ROA_PST005_MONTH_DATA_ROLL_12M WHERE D_KEY = STR06 AND D_KIND <> In_KIND AND PERIOD = In_PERIOD;
      COMMIT;  
         
  /*****************************************************************************************
      (2)Kind = 08-USI(no Bravo)
  ************************************************************************************ */
  ELSIF In_KIND IN ('08') THEN    
    In_KIND := '08'; 
    USI_KIND := '09';
    PC_KIND := '01';
    STR06 :=  'USI'; 
    STR07 :=  'USI(No Bravo)';
    
    select PC INTO STR03 FROM ROA_UPL009_EXCLUDE_PC_LISTS WHERE D_KIND = In_KIND ;
    STR04 := SUBSTR(STR03, 9, 2) ;
    
    --STR03 :=  '0000000080';     
    --STR04 :=  '80';
        
  --(2-26) --------      
      STR01 :=  'A00200';
      for REC1 IN (
          --select SUM(a.upl_amt * b.WEIGHTS ) Amount from ROA_UPL003_BS_DATA a join ROA_MAP002_BS_ACCOUNT b
          --on b.S_DESC = a.S_DESC where b.account = 'Cash' and PERIOD = In_PERIOD 
          --and company_code = STR06  
          --SAI089808 Asan Chang 2018/10/22 modify 
          select A1.Amount1-A2.Amount2 Amount from
          (select SUM(a.upl_amt * b.WEIGHTS ) Amount1 from ROA_UPL003_BS_DATA a join ROA_MAP002_BS_ACCOUNT b
          on b.S_DESC = a.S_DESC where b.account = 'Cash' and PERIOD = In_PERIOD
          and company_code = STR06 ) A1,
          (SELECT D_AMOUNT  Amount2 FROM ROA_PST005_MONTH_DATA_ROLL_12M where D_KEY = STR03
          AND D_KIND = PC_KIND AND D_ACC = STR01 AND PERIOD = In_PERIOD) A2                       
      )
      LOOP
        INSERT INTO ROA_PST005_MONTH_DATA_ROLL_12M
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR07 ,STR01, REC1.AMOUNT);                 
      END LOOP;  
      
  --(2-27) --------      
      STR01 :=  'A00400';
      for REC1 IN (
          select SUM(a.upl_amt * b.WEIGHTS ) Amount from ROA_UPL003_BS_DATA a join ROA_MAP002_BS_ACCOUNT b
          on b.S_DESC = a.S_DESC where b.account = 'Financial Asset' and PERIOD = In_PERIOD
          and company_code = STR06                 
      )
      LOOP
        INSERT INTO ROA_PST005_MONTH_DATA_ROLL_12M
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR07 ,STR01, REC1.AMOUNT);                 
      END LOOP;

  --(2-28) --------      
      STR01 :=  'A00500';
      for REC1 IN (
          select SUM(a.upl_amt * b.WEIGHTS ) Amount from ROA_UPL003_BS_DATA a join ROA_MAP002_BS_ACCOUNT b
          on b.S_DESC = a.S_DESC where b.account = 'Others Receivable' and PERIOD = In_PERIOD  
          and company_code = STR06               
      )
      LOOP
        INSERT INTO ROA_PST005_MONTH_DATA_ROLL_12M
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR07 ,STR01, REC1.AMOUNT);                 
      END LOOP;
      
  --(2-29) --------      
      STR01 :=  'A00600';
      for REC1 IN (
          select SUM(a.upl_amt * b.WEIGHTS ) Amount from ROA_UPL003_BS_DATA a join ROA_MAP002_BS_ACCOUNT b
          on b.S_DESC = a.S_DESC where b.account = 'Deferred Tax' and PERIOD = In_PERIOD  
          and company_code = STR06               
      )
      LOOP
        INSERT INTO ROA_PST005_MONTH_DATA_ROLL_12M
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR07 ,STR01, REC1.AMOUNT);                 
      END LOOP;      
      
  --(2-30) --------      
      STR01 :=  'A00700';
      for REC1 IN (
          select SUM(a.upl_amt * b.WEIGHTS ) Amount from ROA_UPL003_BS_DATA a join ROA_MAP002_BS_ACCOUNT b
          on b.S_DESC = a.S_DESC where b.account = 'Deferred charges' and PERIOD = In_PERIOD 
          and company_code = STR06                
      )
      LOOP
        INSERT INTO ROA_PST005_MONTH_DATA_ROLL_12M
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR07 ,STR01, REC1.AMOUNT);                 
      END LOOP;
     
  --(2-31) --------     
      STR01 :=  'A01400';
      for REC1 IN ( 
          select b.D_AMOUNT-a.AMOUNT AMOUNT from
          ( SELECT  SUM( D_AMOUNT ) AMOUNT FROM ROA_PST005_MONTH_DATA_ROLL_12M WHERE PERIOD = In_PERIOD
          AND D_KIND = D_KIND AND D_ACC in ( 'A00200','A00300','A00400','A00500','A00600', 'A00700',
                                             'A00800','A00900','A01000','A01100','A01200', 'A01300')
          and D_KEY = STR03 ) a ,
          ( select SUM(a.upl_amt * b.WEIGHTS ) D_AMOUNT from ROA_UPL003_BS_DATA a join ROA_MAP002_BS_ACCOUNT b
          on b.S_DESC = a.S_DESC where b.account = 'Total assets' and PERIOD = In_PERIOD 
          and company_code = STR06 ) b              
      )
      LOOP
        INSERT INTO ROA_PST005_MONTH_DATA_ROLL_12M
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR07 ,STR01, REC1.AMOUNT);                 
      END LOOP;

  --(2-32) --------      
      STR01 :=  'A01700';
      for REC1 IN (
          select b.D_AMOUNT-a.AMOUNT AMOUNT from
          ( SELECT  SUM( D_AMOUNT ) AMOUNT FROM ROA_PST005_MONTH_DATA_ROLL_12M WHERE PERIOD = In_PERIOD
          AND D_KIND = D_KIND AND D_ACC = STR01
          and D_KEY = STR03 ) a ,
          ( select SUM(a.upl_amt * b.WEIGHTS ) D_AMOUNT from ROA_UPL003_BS_DATA a join ROA_MAP002_BS_ACCOUNT b
          on b.S_DESC = a.S_DESC where b.account = 'Equity' and PERIOD = In_PERIOD 
          and company_code = STR06 ) b                 
      )
      LOOP
        INSERT INTO ROA_PST005_MONTH_DATA_ROLL_12M
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR07 ,STR01, REC1.AMOUNT);                 
      END LOOP;   
      
   --(2-33) --------      
      STR01 :=  'A01800';
      for REC1 IN (              
          select (Amount1-Amount2) Amount from
          (
          select SUM(a.upl_amt * b.WEIGHTS ) Amount1 from ROA_UPL003_BS_DATA a join ROA_MAP002_BS_ACCOUNT b
          on b.S_DESC = a.S_DESC where b.account = 'Total liabilities' and PERIOD = In_PERIOD
          and company_code = STR06  ),
          (
          select SUM(a.upl_amt * b.WEIGHTS ) Amount2 from ROA_UPL003_BS_DATA a join ROA_MAP002_BS_ACCOUNT b
          on b.S_DESC = a.S_DESC where b.account = 'AP-3rd' and PERIOD = In_PERIOD
          and company_code = STR06   )


      )
      LOOP
        INSERT INTO ROA_PST005_MONTH_DATA_ROLL_12M
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR07 ,STR01, REC1.AMOUNT);                 
      END LOOP;        
    
  --(2-01) --------  
  --    
      STR01 :=  'A00800';
      for REC1 IN ( 
          select b.D_AMOUNT-a.AMOUNT AMOUNT from
          ( SELECT sum( upl_amt ) AMOUNT FROM ROA_UPL004_AR_AP_INV_DATA WHERE
          PERIOD = In_PERIOD AND TYPE IN ( 'AR' )  AND  ( PC = STR03 ) ) a ,
          ( select D_AMOUNT from ROA_PST005_MONTH_DATA_ROLL_12M where period = In_PERIOD
          and D_KIND = USI_KIND and D_KEY = STR06 and D_ACC = STR01) b              
      )
      LOOP
        INSERT INTO ROA_PST005_MONTH_DATA_ROLL_12M
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR07 ,STR01, REC1.AMOUNT);                 
      END LOOP;    
      
--(2-02) --------  
      STR01 :=  'A00900';
      for REC1 IN (  
          select b.D_AMOUNT-a.AMOUNT AMOUNT from
          ( SELECT sum( upl_amt ) AMOUNT FROM ROA_UPL004_AR_AP_INV_DATA WHERE
          PERIOD = In_PERIOD AND TYPE IN  ( 'INV', 'ADJ INV' ) AND ( PC = STR03 )  ) a ,
          ( select D_AMOUNT from ROA_PST005_MONTH_DATA_ROLL_12M where period = In_PERIOD
          and D_KIND = USI_KIND and D_KEY = STR06 and D_ACC = STR01) b             
      )
      LOOP
        INSERT INTO ROA_PST005_MONTH_DATA_ROLL_12M
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR07 ,STR01, REC1.AMOUNT);                  
      END LOOP; 
  --(2-03) --------  
      STR01 :=  'A01500';
      for REC1 IN (       
          select b.D_AMOUNT-a.AMOUNT AMOUNT from
          ( SELECT sum( upl_amt ) AMOUNT FROM ROA_UPL004_AR_AP_INV_DATA WHERE
          PERIOD = In_PERIOD AND TYPE IN  ( 'AP' ) AND ( PC = STR03 )  ) a ,
          ( select SUM(a.upl_amt * b.WEIGHTS ) D_AMOUNT from ROA_UPL003_BS_DATA a join ROA_MAP002_BS_ACCOUNT b
          on b.S_DESC = a.S_DESC where b.account = 'AP-3rd' and PERIOD = In_PERIOD   
          and company_code = STR06 ) b       
      )
      LOOP
        INSERT INTO ROA_PST005_MONTH_DATA_ROLL_12M
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR07 ,STR01, REC1.AMOUNT);                   
      END LOOP;        

  --(2-04) --------  
      STR01 :=  'A01000';
      for REC1 IN (    
          select b.D_AMOUNT-a.AMOUNT AMOUNT from
          ( SELECT sum( UPL_AMT_LOC  * EX_RATE_TWD ) AMOUNT FROM ROA_PST004_FIXED_ASSETS WHERE
          PERIOD = In_PERIOD AND S_SEQ IN ( '10' ) AND TYPE ='2' AND ( PC = STR03 ) ) a, 
          ( select D_AMOUNT from ROA_PST005_MONTH_DATA_ROLL_12M where period = In_PERIOD
          and D_KIND = USI_KIND and D_KEY = STR06 and D_ACC = STR01 ) b          
            
      )
      LOOP
        INSERT INTO ROA_PST005_MONTH_DATA_ROLL_12M
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR07 ,STR01, REC1.AMOUNT);                  
      END LOOP; 

  --(2-05) --------  
      STR01 :=  'A01100';
      for REC1 IN (  
          select b.D_AMOUNT-a.AMOUNT AMOUNT from
          ( SELECT sum( UPL_AMT_LOC  * EX_RATE_TWD ) AMOUNT FROM ROA_PST004_FIXED_ASSETS WHERE
          PERIOD = In_PERIOD AND S_SEQ IN ( '20' ) AND TYPE ='2' AND ( PC = STR03 ) ) a, 
          ( select D_AMOUNT from ROA_PST005_MONTH_DATA_ROLL_12M where period = In_PERIOD
          and D_KIND = USI_KIND and D_KEY = STR06 and D_ACC = STR01 ) b    
      )
      LOOP
        INSERT INTO ROA_PST005_MONTH_DATA_ROLL_12M
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR07 ,STR01, REC1.AMOUNT);               
      END LOOP;    

  --(2-06) --------  
      STR01 :=  'A03000';
      for REC1 IN (  
          select b.D_AMOUNT-a.AMOUNT AMOUNT from 
          ( SELECT STR01 D_ACC,  sum( UPL_AMT_LOC  * EX_RATE_TWD ) AMOUNT FROM ROA_PST004_FIXED_ASSETS WHERE
          PERIOD = In_PERIOD AND S_SEQ IN ( '20' ) AND TYPE ='2' AND ( PC = STR03 ) ) a, 
          ( select D_AMOUNT from ROA_PST005_MONTH_DATA_ROLL_12M where period = In_PERIOD
          and D_KIND = USI_KIND and D_KEY = STR06 and D_ACC = STR01 ) b   
      )
      LOOP
        INSERT INTO ROA_PST005_MONTH_DATA_ROLL_12M
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR07 ,STR01, REC1.AMOUNT);                
      END LOOP;  
       

  --(2-07) --------  
      STR01 :=  'A01200';
      for REC1 IN (
          select b.D_AMOUNT-a.AMOUNT AMOUNT from
          ( SELECT sum( UPL_AMT_LOC  * EX_RATE_TWD ) AMOUNT FROM ROA_PST004_FIXED_ASSETS WHERE
          PERIOD = In_PERIOD AND S_SEQ IN ( '30','40' ) AND TYPE ='2' AND ( PC = STR03 )  ) a, 
          ( select D_AMOUNT from ROA_PST005_MONTH_DATA_ROLL_12M where period = In_PERIOD
          and D_KIND = USI_KIND and D_KEY = STR06 and D_ACC = STR01 ) b  
      )
      LOOP
        INSERT INTO ROA_PST005_MONTH_DATA_ROLL_12M
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR07 ,STR01, REC1.AMOUNT);                
      END LOOP;  
           
  --(2-08) --------  
      STR01 :=  'A03200';
      for REC1 IN (  
          select b.D_AMOUNT-a.AMOUNT AMOUNT from
          ( SELECT sum( UPL_AMT_LOC  * EX_RATE_TWD ) AMOUNT FROM ROA_PST004_FIXED_ASSETS WHERE
          PERIOD = In_PERIOD AND S_SEQ IN ( '20','30','40' ) AND TYPE ='2'  AND ( PC = STR03 ) ) a, 
          ( select D_AMOUNT from ROA_PST005_MONTH_DATA_ROLL_12M where period = In_PERIOD
          and D_KIND = USI_KIND and D_KEY = STR06 and D_ACC = STR01 ) b     
      )
      LOOP
        INSERT INTO ROA_PST005_MONTH_DATA_ROLL_12M
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR07 ,STR01, REC1.AMOUNT);                
      END LOOP;      

  --(2-09) --------  
      STR01 :=  'A02900';
      for REC1 IN ( 
          select b.D_AMOUNT-a.AMOUNT AMOUNT from
          ( SELECT sum( UPL_AMT_LOC  * EX_RATE_TWD ) AMOUNT FROM ROA_PST004_FIXED_ASSETS WHERE
          PERIOD = In_PERIOD AND S_SEQ IN ( '10','20','30','40' ) AND TYPE ='2' AND ( PC = STR03 )) a, 
          ( select D_AMOUNT from ROA_PST005_MONTH_DATA_ROLL_12M where period = In_PERIOD
          and D_KIND = USI_KIND and D_KEY = STR06 and D_ACC = STR01 ) b    
      )
      LOOP
        INSERT INTO ROA_PST005_MONTH_DATA_ROLL_12M
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR07 ,STR01, REC1.AMOUNT);                
      END LOOP;
      
  --(2-10) --------  
      STR01 :=  'A02100';
      STR02 :=  'Net Mfg Revenues';
      for REC1 IN (  
          select a.amount1 - b.amount2 amount from
          ( SELECT sum( amount ) AMOUNT1  FROM PNL_MSA001_EM_DATA WHERE
          YYYY = In_YYYY AND MONTH = In_MM AND acct_id <> ' ' AND ACCT_NAME = STR02 ) a,
          ( SELECT sum( amount ) AMOUNT2  FROM PNL_MSA001_EM_DATA WHERE
          YYYY = In_YYYY AND MONTH = In_MM AND acct_id <> ' ' AND ACCT_NAME = STR02 AND ( PC = STR04 ) ) b
      )
      LOOP
        INSERT INTO ROA_PST005_MONTH_DATA_ROLL_12M
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR07 ,STR01, (REC1.AMOUNT * 1000 ));                
      END LOOP; 
      
  --(2-11) --------  
      STR01 :=  'A02200';
      STR02 :=  '07.050';
      for REC1 IN (        
          select a.amount1 - b.amount2 amount from
          ( SELECT sum( amount ) AMOUNT1  FROM PNL_MSA001_EM_DATA WHERE
          YYYY = In_YYYY AND MONTH = In_MM AND acct_id <> ' ' AND acct_id <= STR02 ) a,
          ( SELECT sum( amount ) AMOUNT2  FROM PNL_MSA001_EM_DATA WHERE
          YYYY = In_YYYY AND MONTH = In_MM AND acct_id <> ' ' AND acct_id <= STR02 AND ( PC = STR04 ) ) b             
      )
      LOOP
        INSERT INTO ROA_PST005_MONTH_DATA_ROLL_12M
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR07 ,STR01, (REC1.AMOUNT * 1000) );                 
      END LOOP;       

  --(2-12) --------  
      STR01 :=  'A04000';
      for REC1 IN (
          select b.D_AMOUNT-a.AMOUNT AMOUNT from
          ( SELECT sum( UPL_AMT_LOC  * EX_RATE_TWD ) AMOUNT FROM ROA_PST004_FIXED_ASSETS WHERE
          PERIOD = In_PERIOD AND S_SEQ IN ( '10' ) AND TYPE ='1' AND ( PC = STR03 ) ) a, 
          ( select D_AMOUNT from ROA_PST005_MONTH_DATA_ROLL_12M where period = In_PERIOD
          and D_KIND = USI_KIND and D_KEY = STR06 and D_ACC = STR01 ) b     
      )
      LOOP
        INSERT INTO ROA_PST005_MONTH_DATA_ROLL_12M
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR07 ,STR01, REC1.AMOUNT);                 
      END LOOP;

  --(2-13) --------  
      STR01 :=  'A03600';
      for REC1 IN ( 
          select b.D_AMOUNT-a.AMOUNT AMOUNT from
          ( SELECT sum( UPL_AMT_LOC  * EX_RATE_TWD ) AMOUNT FROM ROA_PST004_FIXED_ASSETS WHERE
          PERIOD = In_PERIOD AND S_SEQ IN ( '20' ) AND TYPE ='1' AND ( PC = STR03 ) ) a, 
          ( select D_AMOUNT from ROA_PST005_MONTH_DATA_ROLL_12M where period = In_PERIOD
          and D_KIND = USI_KIND and D_KEY = STR06 and D_ACC = STR01 ) b     
      )
      LOOP
        INSERT INTO ROA_PST005_MONTH_DATA_ROLL_12M
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR07 ,STR01, REC1.AMOUNT);                 
      END LOOP;

  --(2-13) --------  
      STR01 :=  'A04100';
      for REC1 IN (
          select b.D_AMOUNT-a.AMOUNT AMOUNT from
          ( SELECT sum( UPL_AMT_LOC  * EX_RATE_TWD ) AMOUNT FROM ROA_PST004_FIXED_ASSETS WHERE
          PERIOD = In_PERIOD AND S_SEQ IN ( '20' ) AND TYPE ='1' AND ( PC = STR03 ) ) a, 
          ( select D_AMOUNT from ROA_PST005_MONTH_DATA_ROLL_12M where period = In_PERIOD
          and D_KIND = USI_KIND and D_KEY = STR06 and D_ACC = STR01 ) b               
      )
      LOOP
        INSERT INTO ROA_PST005_MONTH_DATA_ROLL_12M
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR07 ,STR01, REC1.AMOUNT);               
      END LOOP;
                
  --(2-14) --------  
      STR01 :=  'A04200';
      for REC1 IN (   
          select b.D_AMOUNT-a.AMOUNT AMOUNT from
          ( SELECT sum( UPL_AMT_LOC  * EX_RATE_TWD ) AMOUNT FROM ROA_PST004_FIXED_ASSETS WHERE
          PERIOD = In_PERIOD AND S_SEQ IN ( '30','40' ) AND TYPE ='1'  AND ( PC = STR03 )) a, 
          ( select D_AMOUNT from ROA_PST005_MONTH_DATA_ROLL_12M where period = In_PERIOD
          and D_KIND = USI_KIND and D_KEY = STR06 and D_ACC = STR01 ) b   
      )
      LOOP
        INSERT INTO ROA_PST005_MONTH_DATA_ROLL_12M
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR07 ,STR01, REC1.AMOUNT);               
      END LOOP;             

  --(2-15) --------  
      STR01 :=  'A03800';
      for REC1 IN ( 
          select b.D_AMOUNT-a.AMOUNT AMOUNT from
          ( SELECT sum( UPL_AMT_LOC  * EX_RATE_TWD ) AMOUNT FROM ROA_PST004_FIXED_ASSETS WHERE
          PERIOD = In_PERIOD AND S_SEQ IN ( '20','30','40' ) AND TYPE ='1'  AND ( PC = STR03 )) a,
          ( select D_AMOUNT from ROA_PST005_MONTH_DATA_ROLL_12M where period = In_PERIOD
          and D_KIND = USI_KIND and D_KEY = STR06 and D_ACC = STR01 ) b             
      )
      LOOP
        INSERT INTO ROA_PST005_MONTH_DATA_ROLL_12M
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR07 ,STR01, REC1.AMOUNT);                
      END LOOP; 

  --(2-15_2) --------       
      STR01 :=  'A03400';
      for REC1 IN (
          select b.D_AMOUNT-a.AMOUNT AMOUNT from
          ( SELECT SUM( D_AMOUNT )  AMOUNT FROM ROA_PST005_MONTH_DATA_ROLL_12M
          WHERE PERIOD = In_PERIOD 
          AND D_KIND = PC_KIND AND D_ACC in ( 'A03400' ) AND D_KEY = STR03 ) a ,
          ( SELECT SUM( D_AMOUNT )  D_AMOUNT FROM ROA_PST005_MONTH_DATA_ROLL_12M
          WHERE PERIOD = In_PERIOD 
          AND D_KIND = USI_KIND AND D_ACC in ( 'A03400' ) ) b                 
      )
      LOOP
        INSERT INTO ROA_PST005_MONTH_DATA_ROLL_12M
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR07 ,STR01, REC1.AMOUNT);                 
      END LOOP;                   

  --(2-16) --------  
      STR01 :=  'C_NIB_Y_22';
      --STR02 :=  In_YYYY || '01';
      for REC1 IN (  
         select b.D_AMOUNT-a.D_AMOUNT AMOUNT from       
         ( select D_AMOUNT from ROA_PST005_MONTH_DATA_ROLL_12M where period = In_PERIOD
         and D_KIND = PC_KIND and D_KEY = STR03 and D_ACC = STR01 ) a,      
         ( select D_AMOUNT from ROA_PST005_MONTH_DATA_ROLL_12M where period = In_PERIOD
         and D_KIND = USI_KIND and D_KEY = STR06 and D_ACC = STR01 ) b
  
      )
      LOOP
        INSERT INTO ROA_PST005_MONTH_DATA_ROLL_12M
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR07 ,STR01, REC1.AMOUNT);                 
      END LOOP; 

  --(2-17) --------  
      STR01 :=  'C_SUB_A_14';
      --STR02 :=  In_YYYY || '01';
      for REC1 IN (  
         select b.D_AMOUNT-a.D_AMOUNT AMOUNT from       
         ( select D_AMOUNT from ROA_PST005_MONTH_DATA_ROLL_12M where period = In_PERIOD
         and D_KIND = PC_KIND and D_KEY = STR03 and D_ACC = STR01 ) a,      
         ( select D_AMOUNT from ROA_PST005_MONTH_DATA_ROLL_12M where period = In_PERIOD
         and D_KIND = USI_KIND and D_KEY = STR06 and D_ACC = STR01 ) b
  
      )
      LOOP
        INSERT INTO ROA_PST005_MONTH_DATA_ROLL_12M
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR07 ,STR01, REC1.AMOUNT);                 
      END LOOP; 

  --(2-18) --------  
      STR01 :=  'C_EQU_A_17';
      --STR02 :=  In_YYYY || '01';
      for REC1 IN (  
         select b.D_AMOUNT-a.D_AMOUNT AMOUNT from       
         ( select D_AMOUNT from ROA_PST005_MONTH_DATA_ROLL_12M where period = In_PERIOD
         and D_KIND = PC_KIND and D_KEY = STR03 and D_ACC = STR01 ) a,      
         ( select D_AMOUNT from ROA_PST005_MONTH_DATA_ROLL_12M where period = In_PERIOD
         and D_KIND = USI_KIND and D_KEY = STR06 and D_ACC = STR01 ) b
  
      )
      LOOP
        INSERT INTO ROA_PST005_MONTH_DATA_ROLL_12M
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR07 ,STR01, REC1.AMOUNT);                 
      END LOOP;

  --(2-19) --------  
      STR01 :=  'C_REV_Y_21';
      --STR02 :=  In_YYYY || '01';
      for REC1 IN (  
         select b.D_AMOUNT-a.D_AMOUNT AMOUNT from       
         ( select D_AMOUNT from ROA_PST005_MONTH_DATA_ROLL_12M where period = In_PERIOD
         and D_KIND = PC_KIND and D_KEY = STR03 and D_ACC = STR01 ) a,      
         ( select D_AMOUNT from ROA_PST005_MONTH_DATA_ROLL_12M where period = In_PERIOD
         and D_KIND = USI_KIND and D_KEY = STR06 and D_ACC = STR01 ) b
  
      )
      LOOP
        INSERT INTO ROA_PST005_MONTH_DATA_ROLL_12M
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR07 ,STR01, REC1.AMOUNT);                 
      END LOOP;

  --(2-20) --------  
      STR01 :=  'C_SFA_A_10N12';
      --STR02 :=  In_YYYY || '01';
      for REC1 IN (  
         select b.D_AMOUNT-a.D_AMOUNT AMOUNT from       
         ( select D_AMOUNT from ROA_PST005_MONTH_DATA_ROLL_12M where period = In_PERIOD
         and D_KIND = PC_KIND and D_KEY = STR03 and D_ACC = STR01 ) a,      
         ( select D_AMOUNT from ROA_PST005_MONTH_DATA_ROLL_12M where period = In_PERIOD
         and D_KIND = USI_KIND and D_KEY = STR06 and D_ACC = STR01 ) b
  
      )
      LOOP
        INSERT INTO ROA_PST005_MONTH_DATA_ROLL_12M
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR07 ,STR01, REC1.AMOUNT);                 
      END LOOP;

  --(2-21) --------  
      STR01 :=  'C_BV1_A_30';
      --STR02 :=  In_YYYY || '01';
      for REC1 IN (  
         select b.D_AMOUNT-a.D_AMOUNT AMOUNT from       
         ( select D_AMOUNT from ROA_PST005_MONTH_DATA_ROLL_12M where period = In_PERIOD
         and D_KIND = PC_KIND and D_KEY = STR03 and D_ACC = STR01 ) a,      
         ( select D_AMOUNT from ROA_PST005_MONTH_DATA_ROLL_12M where period = In_PERIOD
         and D_KIND = USI_KIND and D_KEY = STR06 and D_ACC = STR01 ) b
  
      )
      LOOP
        INSERT INTO ROA_PST005_MONTH_DATA_ROLL_12M
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR07 ,STR01, REC1.AMOUNT);                 
      END LOOP;

  --(2-22) --------  
      STR01 :=  'C_BV2_A_32';
      --STR02 :=  In_YYYY || '01';
      for REC1 IN (  
         select b.D_AMOUNT-a.D_AMOUNT AMOUNT from       
         ( select D_AMOUNT from ROA_PST005_MONTH_DATA_ROLL_12M where period = In_PERIOD
         and D_KIND = PC_KIND and D_KEY = STR03 and D_ACC = STR01 ) a,      
         ( select D_AMOUNT from ROA_PST005_MONTH_DATA_ROLL_12M where period = In_PERIOD
         and D_KIND = USI_KIND and D_KEY = STR06 and D_ACC = STR01 ) b
  
      )
      LOOP
        INSERT INTO ROA_PST005_MONTH_DATA_ROLL_12M
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR07 ,STR01, REC1.AMOUNT);                 
      END LOOP;

  --(2-23) --------  
      STR01 :=  'C_OV1_A_34';
      --STR02 :=  In_YYYY || '01';
      for REC1 IN (  
         select b.D_AMOUNT-a.D_AMOUNT AMOUNT from       
         ( select D_AMOUNT from ROA_PST005_MONTH_DATA_ROLL_12M where period = In_PERIOD
         and D_KIND = PC_KIND and D_KEY = STR03 and D_ACC = STR01 ) a,      
         ( select D_AMOUNT from ROA_PST005_MONTH_DATA_ROLL_12M where period = In_PERIOD
         and D_KIND = USI_KIND and D_KEY = STR06 and D_ACC = STR01 ) b
  
      )
      LOOP
        INSERT INTO ROA_PST005_MONTH_DATA_ROLL_12M
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR07 ,STR01, REC1.AMOUNT);                 
      END LOOP;


  --(2-24) --------  
      STR01 :=  'C_OV2_A_36';
      --STR02 :=  In_YYYY || '01';
      for REC1 IN (  
         select b.D_AMOUNT-a.D_AMOUNT AMOUNT from       
         ( select D_AMOUNT from ROA_PST005_MONTH_DATA_ROLL_12M where period = In_PERIOD
         and D_KIND = PC_KIND and D_KEY = STR03 and D_ACC = STR01 ) a,      
         ( select D_AMOUNT from ROA_PST005_MONTH_DATA_ROLL_12M where period = In_PERIOD
         and D_KIND = USI_KIND and D_KEY = STR06 and D_ACC = STR01 ) b
  
      )
      LOOP
        INSERT INTO ROA_PST005_MONTH_DATA_ROLL_12M
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR07 ,STR01, REC1.AMOUNT);                 
      END LOOP;

  --(2-25) --------  
      STR01 :=  'C_OV3_A_38';
      --STR02 :=  In_YYYY || '01';
      for REC1 IN (  
         select b.D_AMOUNT-a.D_AMOUNT AMOUNT from       
         ( select D_AMOUNT from ROA_PST005_MONTH_DATA_ROLL_12M where period = In_PERIOD
         and D_KIND = PC_KIND and D_KEY = STR03 and D_ACC = STR01 ) a,      
         ( select D_AMOUNT from ROA_PST005_MONTH_DATA_ROLL_12M where period = In_PERIOD
         and D_KIND = USI_KIND and D_KEY = STR06 and D_ACC = STR01 ) b
  
      )
      LOOP
        INSERT INTO ROA_PST005_MONTH_DATA_ROLL_12M
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR07 ,STR01, REC1.AMOUNT);                 
      END LOOP;   
    
  --(2-99) --------      
      STR01 :=  'C_BV3_A_44';
      for REC1 IN (
          select b.D_AMOUNT-a.AMOUNT AMOUNT from
          ( SELECT SUM( D_AMOUNT )  AMOUNT FROM ROA_PST005_MONTH_DATA_ROLL_12M
          WHERE PERIOD = In_PERIOD 
          AND D_KIND = PC_KIND AND D_ACC in ( 'C_BV3_A_44' ) AND D_KEY = STR03 ) a ,
          ( SELECT SUM( D_AMOUNT )  D_AMOUNT FROM ROA_PST005_MONTH_DATA_ROLL_12M
          WHERE PERIOD = In_PERIOD 
          AND D_KIND = USI_KIND AND D_ACC in ( 'C_BV3_A_44' ) ) b
                
      )
      LOOP
        INSERT INTO ROA_PST005_MONTH_DATA_ROLL_12M
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR07 ,STR01, REC1.AMOUNT);                 
      END LOOP;    
      
  --(2-98) --------      
      STR01 :=  'C_OV4_A_46';
      for REC1 IN (
          select b.D_AMOUNT-a.AMOUNT AMOUNT from
          ( SELECT SUM( D_AMOUNT )  AMOUNT FROM ROA_PST005_MONTH_DATA_ROLL_12M
          WHERE PERIOD = In_PERIOD 
          AND D_KIND = PC_KIND AND D_ACC in ( 'C_OV4_A_46' ) AND D_KEY = STR03 ) a ,
          ( SELECT SUM( D_AMOUNT )  D_AMOUNT FROM ROA_PST005_MONTH_DATA_ROLL_12M
          WHERE PERIOD = In_PERIOD 
          AND D_KIND = USI_KIND AND D_ACC in ( 'C_OV4_A_46' ) ) b                 
      )
      LOOP
        INSERT INTO ROA_PST005_MONTH_DATA_ROLL_12M
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR07 ,STR01, REC1.AMOUNT);                 
      END LOOP;   
 

  --(2-97) --------      
      STR01 :=  'A04400';
      for REC1 IN (
          select b.D_AMOUNT-a.AMOUNT AMOUNT from
          ( SELECT SUM( D_AMOUNT )  AMOUNT FROM ROA_PST005_MONTH_DATA_ROLL_12M
          WHERE PERIOD = In_PERIOD 
          AND D_KIND = PC_KIND AND D_ACC in ( 'A04400' ) AND D_KEY = STR03 ) a ,
          ( SELECT SUM( D_AMOUNT )  D_AMOUNT FROM ROA_PST005_MONTH_DATA_ROLL_12M
          WHERE PERIOD = In_PERIOD 
          AND D_KIND = USI_KIND AND D_ACC in ( 'A04400' ) ) b                 
      )
      LOOP
        INSERT INTO ROA_PST005_MONTH_DATA_ROLL_12M
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR07 ,STR01, REC1.AMOUNT);                 
      END LOOP;   

  --(2-97) --------      
      STR01 :=  'A04600';
      for REC1 IN (
          select b.D_AMOUNT-a.AMOUNT AMOUNT from
          ( SELECT SUM( D_AMOUNT )  AMOUNT FROM ROA_PST005_MONTH_DATA_ROLL_12M
          WHERE PERIOD = In_PERIOD 
          AND D_KIND = PC_KIND AND D_ACC in ( 'A04600' ) AND D_KEY = STR03 ) a ,
          ( SELECT SUM( D_AMOUNT )  D_AMOUNT FROM ROA_PST005_MONTH_DATA_ROLL_12M
          WHERE PERIOD = In_PERIOD 
          AND D_KIND = USI_KIND AND D_ACC in ( 'A04600' ) ) b                 
      )
      LOOP
        INSERT INTO ROA_PST005_MONTH_DATA_ROLL_12M
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR07 ,STR01, REC1.AMOUNT);                 
      END LOOP; 
      
      delete  FROM   ROA_PST005_MONTH_DATA_ROLL_12M WHERE D_KEY = STR07 AND D_KIND <> In_KIND AND PERIOD = In_PERIOD;
      COMMIT;   
  
  /*****************************************************************************************
      (4)Kind = 10-USI-COMMON
  ************************************************************************************ */
  ELSIF In_KIND IN ('10') THEN    
    In_KIND := '10'; 
    USI_KIND := '09';
    PC_KIND := '01';
    STR06 :=  'USI'; 
    STR08 :=  'USI-COMMON';
   
    --STR09 := '';
    --STR10 := '';
    --FOR REC IN (select PC FROM ROA_UPL009_EXCLUDE_PC_LISTS WHERE D_KIND = In_KIND )
    --LOOP 
    --  STR03 := REC.PC;
    --  STR04 := SUBSTR(REC.PC, 9, 2) ;
    --  STR09 := STR09 || '''' || STR03 || ''',';
    --  STR10 := STR10 || '''' || STR04 || ''','; 
    --END LOOP;
    
    --STR09 := SUBSTR(STR09, 0, LENGTH(STR09) - 1);
    --STR10 := SUBSTR(STR10, 0, LENGTH(STR10) - 1);
    
    --STR09 := '(' || STR09 ||')';
    --STR10 := '(' || STR10 ||')';    
    --STR09 := '(''0000000011'',''0000000012'',''0000000013'',''0000000014'',''0000000015'', ''0000000016'', ''0000000020'',''0000000021'', ''0000000022'',''0000000023'',''0000000024'',''0000000025'',''0000000026'',''0000000028'',''0000000029'',''0000000030'',''0000000031'',''0000000032'',''0000000033'',''0000000034'',''0000000035'',''0000000036'',''0000000038'',''0000000039'',''0000000041'',''0000000045'',''0000000046'',''0000000047'',''0000000048'',''0000000050'',''0000000051'',''0000000052'',''0000000054'',''0000000055'',''0000000058'',''0000000080'', ''0000000081'' )';

    
  --(4-26) --------      
      STR01 :=  'A00200';
      for REC1 IN (
          
          --select SUM(a.upl_amt * b.WEIGHTS ) Amount from ROA_UPL003_BS_DATA a join ROA_MAP002_BS_ACCOUNT b
          --on b.S_DESC = a.S_DESC where b.account = 'Cash' and PERIOD = In_PERIOD 
          --and company_code = STR06  
          --扣除PC cash 20180926
          --扣除9開頭PC 20180927
          
           select (T1.AMOUNT1-T2.AMOUNT2) AMOUNT from
          (select SUM(a.upl_amt * b.WEIGHTS ) AMOUNT1 from ROA_UPL003_BS_DATA a join ROA_MAP002_BS_ACCOUNT b
          on b.S_DESC = a.S_DESC where b.account = 'Cash' and PERIOD = In_PERIOD
          and company_code = STR06 ) T1,
          ( SELECT  SUM( D_AMOUNT ) AMOUNT2 FROM ROA_PST005_MONTH_DATA_ROLL_12M WHERE PERIOD = In_PERIOD
          AND D_KIND = PC_KIND AND D_ACC in ( 'A00200') and D_KEY not like '000000009%' )  T2                       
      )
      LOOP
        INSERT INTO ROA_PST005_MONTH_DATA_ROLL_12M
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR08 ,STR01, REC1.AMOUNT);                 
      END LOOP;  
      
  --(4-27) --------      
      STR01 :=  'A00400';
      for REC1 IN (
          select SUM(a.upl_amt * b.WEIGHTS ) Amount from ROA_UPL003_BS_DATA a join ROA_MAP002_BS_ACCOUNT b
          on b.S_DESC = a.S_DESC where b.account = 'Financial Asset' and PERIOD = In_PERIOD
          and company_code = STR06                 
      )
      LOOP
        INSERT INTO ROA_PST005_MONTH_DATA_ROLL_12M
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR08 ,STR01, REC1.AMOUNT);                 
      END LOOP;

  --(4-28) --------      
      STR01 :=  'A00500';
      for REC1 IN (
          select SUM(a.upl_amt * b.WEIGHTS ) Amount from ROA_UPL003_BS_DATA a join ROA_MAP002_BS_ACCOUNT b
          on b.S_DESC = a.S_DESC where b.account = 'Others Receivable' and PERIOD = In_PERIOD  
          and company_code = STR06               
      )
      LOOP
        INSERT INTO ROA_PST005_MONTH_DATA_ROLL_12M
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR08 ,STR01, REC1.AMOUNT);                 
      END LOOP;
      
  --(4-29) --------      
      STR01 :=  'A00600';
      for REC1 IN (
          select SUM(a.upl_amt * b.WEIGHTS ) Amount from ROA_UPL003_BS_DATA a join ROA_MAP002_BS_ACCOUNT b
          on b.S_DESC = a.S_DESC where b.account = 'Deferred Tax' and PERIOD = In_PERIOD  
          and company_code = STR06               
      )
      LOOP
        INSERT INTO ROA_PST005_MONTH_DATA_ROLL_12M
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR08 ,STR01, REC1.AMOUNT);                 
      END LOOP;      
      
  --(4-30) --------      
      STR01 :=  'A00700';
      for REC1 IN (
          select SUM(a.upl_amt * b.WEIGHTS ) Amount from ROA_UPL003_BS_DATA a join ROA_MAP002_BS_ACCOUNT b
          on b.S_DESC = a.S_DESC where b.account = 'Deferred charges' and PERIOD = In_PERIOD 
          and company_code = STR06                
      )
      LOOP
        INSERT INTO ROA_PST005_MONTH_DATA_ROLL_12M
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR08 ,STR01, REC1.AMOUNT);                 
      END LOOP;
     
  --(4-31) --------     
      STR01 :=  'A01400';
      for REC1 IN ( 
          select b.D_AMOUNT-a.AMOUNT AMOUNT from
          ( SELECT  SUM( D_AMOUNT ) AMOUNT FROM ROA_PST005_MONTH_DATA_ROLL_12M WHERE PERIOD = In_PERIOD
          AND D_KIND = D_KIND AND D_ACC in ( 'A00200','A00300','A00400','A00500','A00600', 'A00700',
                                             'A00800','A00900','A01000','A01100','A01200', 'A01300')
          and D_KEY IN  ( select PC FROM ROA_UPL009_EXCLUDE_PC_LISTS WHERE D_KIND = In_KIND ) ) a ,
          ( select SUM(a.upl_amt * b.WEIGHTS ) D_AMOUNT from ROA_UPL003_BS_DATA a join ROA_MAP002_BS_ACCOUNT b
          on b.S_DESC = a.S_DESC where b.account = 'Total assets' and PERIOD = In_PERIOD 
          and company_code = STR06 ) b       
          --select b.D_AMOUNT-a.AMOUNT AMOUNT from
          --( SELECT  SUM( D_AMOUNT ) AMOUNT FROM ROA_PST005_MONTH_DATA_ROLL_12M WHERE PERIOD = In_PERIOD
          --AND D_KIND = PC_KIND AND D_ACC = STR01
          --and D_KEY IN  ( select PC FROM ROA_UPL009_EXCLUDE_PC_LISTS WHERE D_KIND = In_KIND ) ) a ,
          --( SELECT  SUM( D_AMOUNT ) AMOUNT FROM ROA_PST005_MONTH_DATA_ROLL_12M WHERE PERIOD = In_PERIOD
          --AND D_KIND = USI_KIND AND D_ACC = STR01 ) b                
      )
      LOOP
        INSERT INTO ROA_PST005_MONTH_DATA_ROLL_12M
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR08 ,STR01, REC1.AMOUNT);                 
      END LOOP;

  --(4-32) --------      
      STR01 :=  'A01700';
      for REC1 IN (
          select b.D_AMOUNT-a.AMOUNT AMOUNT from
          ( SELECT  SUM( D_AMOUNT ) AMOUNT FROM ROA_PST005_MONTH_DATA_ROLL_12M WHERE PERIOD = In_PERIOD
          AND D_KIND = D_KIND AND D_ACC = STR01
          and D_KEY IN  ( select PC FROM ROA_UPL009_EXCLUDE_PC_LISTS WHERE D_KIND = In_KIND ) ) a ,
          ( select SUM(a.upl_amt * b.WEIGHTS ) D_AMOUNT from ROA_UPL003_BS_DATA a join ROA_MAP002_BS_ACCOUNT b
          on b.S_DESC = a.S_DESC where b.account = 'Equity' and PERIOD = In_PERIOD 
          and company_code = STR06 ) b                 
      )
      LOOP
        INSERT INTO ROA_PST005_MONTH_DATA_ROLL_12M
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR08 ,STR01, REC1.AMOUNT);                 
      END LOOP;   
      
   --(4-33) --------      
      STR01 :=  'A01800';
      for REC1 IN (              
          select (Amount1-Amount2) Amount from
          (
          select SUM(a.upl_amt * b.WEIGHTS ) Amount1 from ROA_UPL003_BS_DATA a join ROA_MAP002_BS_ACCOUNT b
          on b.S_DESC = a.S_DESC where b.account = 'Total liabilities' and PERIOD = In_PERIOD
          and company_code = STR06  ),
          (
          select SUM(a.upl_amt * b.WEIGHTS ) Amount2 from ROA_UPL003_BS_DATA a join ROA_MAP002_BS_ACCOUNT b
          on b.S_DESC = a.S_DESC where b.account = 'AP-3rd' and PERIOD = In_PERIOD
          and company_code = STR06   )


      )
      LOOP
        INSERT INTO ROA_PST005_MONTH_DATA_ROLL_12M
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR08 ,STR01, REC1.AMOUNT);                 
      END LOOP;        
    
  --(4-01) --------  
  --    
      STR01 :=  'A00800';
      for REC1 IN ( 
          select b.D_AMOUNT-a.AMOUNT AMOUNT from
          ( SELECT sum( upl_amt ) AMOUNT FROM ROA_UPL004_AR_AP_INV_DATA WHERE
          PERIOD = In_PERIOD AND TYPE IN ( 'AR' )  AND  ( PC IN  ( select PC FROM ROA_UPL009_EXCLUDE_PC_LISTS WHERE D_KIND = In_KIND ) ) ) a ,
          ( select D_AMOUNT from ROA_PST005_MONTH_DATA_ROLL_12M where period = In_PERIOD
          and D_KIND = USI_KIND and D_KEY = STR06 and D_ACC = STR01) b              
      )
      LOOP
        INSERT INTO ROA_PST005_MONTH_DATA_ROLL_12M
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR08 ,STR01, REC1.AMOUNT);                 
      END LOOP;    
      
--(4-02) --------  
      STR01 :=  'A00900';
      for REC1 IN (  
          select b.D_AMOUNT-a.AMOUNT AMOUNT from
          ( SELECT sum( upl_amt ) AMOUNT FROM ROA_UPL004_AR_AP_INV_DATA WHERE
          PERIOD = In_PERIOD AND TYPE IN  ( 'INV', 'ADJ INV' ) AND ( PC IN  ( select PC FROM ROA_UPL009_EXCLUDE_PC_LISTS WHERE D_KIND = In_KIND ) )  ) a ,
          ( select D_AMOUNT from ROA_PST005_MONTH_DATA_ROLL_12M where period = In_PERIOD
          and D_KIND = USI_KIND and D_KEY = STR06 and D_ACC = STR01) b             
      )
      LOOP
        INSERT INTO ROA_PST005_MONTH_DATA_ROLL_12M
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR08 ,STR01, REC1.AMOUNT);                  
      END LOOP; 
  --(4-03) --------  
      STR01 :=  'A01500';
      for REC1 IN (       
          select b.D_AMOUNT-a.AMOUNT AMOUNT from
          ( SELECT sum( upl_amt ) AMOUNT FROM ROA_UPL004_AR_AP_INV_DATA WHERE
          PERIOD = In_PERIOD AND TYPE IN  ( 'AP' ) AND ( PC IN  ( select PC FROM ROA_UPL009_EXCLUDE_PC_LISTS WHERE D_KIND = In_KIND ) )  ) a ,
          ( select SUM(a.upl_amt * b.WEIGHTS ) D_AMOUNT from ROA_UPL003_BS_DATA a join ROA_MAP002_BS_ACCOUNT b
          on b.S_DESC = a.S_DESC where b.account = 'AP-3rd' and PERIOD = In_PERIOD   
          and company_code = STR06 ) b       
      )
      LOOP
        INSERT INTO ROA_PST005_MONTH_DATA_ROLL_12M
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR08 ,STR01, REC1.AMOUNT);                   
      END LOOP;        

  --(4-04) --------  
      STR01 :=  'A01000';
      for REC1 IN (    
          select b.D_AMOUNT-a.AMOUNT AMOUNT from
          ( SELECT sum( UPL_AMT_LOC  * EX_RATE_TWD ) AMOUNT FROM ROA_PST004_FIXED_ASSETS WHERE
          PERIOD = In_PERIOD AND S_SEQ IN ( '10' ) AND TYPE ='2' AND ( PC IN  ( select PC FROM ROA_UPL009_EXCLUDE_PC_LISTS WHERE D_KIND = In_KIND ) ) ) a, 
          ( select D_AMOUNT from ROA_PST005_MONTH_DATA_ROLL_12M where period = In_PERIOD
          and D_KIND = USI_KIND and D_KEY = STR06 and D_ACC = STR01 ) b          
            
      )
      LOOP
        INSERT INTO ROA_PST005_MONTH_DATA_ROLL_12M
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR08 ,STR01, REC1.AMOUNT);                  
      END LOOP; 

  --(4-05) --------  
      STR01 :=  'A01100';
      for REC1 IN (  
          select b.D_AMOUNT-a.AMOUNT AMOUNT from
          ( SELECT sum( UPL_AMT_LOC  * EX_RATE_TWD ) AMOUNT FROM ROA_PST004_FIXED_ASSETS WHERE
          PERIOD = In_PERIOD AND S_SEQ IN ( '20' ) AND TYPE ='2' AND ( PC IN  ( select PC FROM ROA_UPL009_EXCLUDE_PC_LISTS WHERE D_KIND = In_KIND ) ) ) a, 
          ( select D_AMOUNT from ROA_PST005_MONTH_DATA_ROLL_12M where period = In_PERIOD
          and D_KIND = USI_KIND and D_KEY = STR06 and D_ACC = STR01 ) b    
      )
      LOOP
        INSERT INTO ROA_PST005_MONTH_DATA_ROLL_12M
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR08 ,STR01, REC1.AMOUNT);               
      END LOOP;    

  --(4-06) --------  
      STR01 :=  'A03000';
      for REC1 IN (  
          select b.D_AMOUNT-a.AMOUNT AMOUNT from 
          ( SELECT STR01 D_ACC,  sum( UPL_AMT_LOC  * EX_RATE_TWD ) AMOUNT FROM ROA_PST004_FIXED_ASSETS WHERE
          PERIOD = In_PERIOD AND S_SEQ IN ( '20' ) AND TYPE ='2' AND ( PC IN  ( select PC FROM ROA_UPL009_EXCLUDE_PC_LISTS WHERE D_KIND = In_KIND ) ) ) a, 
          ( select D_AMOUNT from ROA_PST005_MONTH_DATA_ROLL_12M where period = In_PERIOD
          and D_KIND = USI_KIND and D_KEY = STR06 and D_ACC = STR01 ) b   
      )
      LOOP
        INSERT INTO ROA_PST005_MONTH_DATA_ROLL_12M
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR08 ,STR01, REC1.AMOUNT);                
      END LOOP;  
       

  --(4-07) --------  
      STR01 :=  'A01200';
      for REC1 IN (
          select b.D_AMOUNT-a.AMOUNT AMOUNT from
          ( SELECT sum( UPL_AMT_LOC  * EX_RATE_TWD ) AMOUNT FROM ROA_PST004_FIXED_ASSETS WHERE
          PERIOD = In_PERIOD AND S_SEQ IN ( '30','40' ) AND TYPE ='2' AND ( PC IN  ( select PC FROM ROA_UPL009_EXCLUDE_PC_LISTS WHERE D_KIND = In_KIND ) )  ) a, 
          ( select D_AMOUNT from ROA_PST005_MONTH_DATA_ROLL_12M where period = In_PERIOD
          and D_KIND = USI_KIND and D_KEY = STR06 and D_ACC = STR01 ) b  
      )
      LOOP
        INSERT INTO ROA_PST005_MONTH_DATA_ROLL_12M
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR08 ,STR01, REC1.AMOUNT);                
      END LOOP;  
           
  --(4-08) --------  
      STR01 :=  'A03200';
      for REC1 IN (  
          select b.D_AMOUNT-a.AMOUNT AMOUNT from
          ( SELECT sum( UPL_AMT_LOC  * EX_RATE_TWD ) AMOUNT FROM ROA_PST004_FIXED_ASSETS WHERE
          PERIOD = In_PERIOD AND S_SEQ IN ( '20','30','40' ) AND TYPE ='2'  AND ( PC IN  ( select PC FROM ROA_UPL009_EXCLUDE_PC_LISTS WHERE D_KIND = In_KIND ) ) ) a, 
          ( select D_AMOUNT from ROA_PST005_MONTH_DATA_ROLL_12M where period = In_PERIOD
          and D_KIND = USI_KIND and D_KEY = STR06 and D_ACC = STR01 ) b     
      )
      LOOP
        INSERT INTO ROA_PST005_MONTH_DATA_ROLL_12M
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR08 ,STR01, REC1.AMOUNT);                
      END LOOP;      

  --(4-09) --------  
      STR01 :=  'A02900';
      for REC1 IN ( 
          select b.D_AMOUNT-a.AMOUNT AMOUNT from
          ( SELECT sum( UPL_AMT_LOC  * EX_RATE_TWD ) AMOUNT FROM ROA_PST004_FIXED_ASSETS WHERE
          PERIOD = In_PERIOD AND S_SEQ IN ( '10','20','30','40' ) AND TYPE ='2' AND ( PC IN  ( select PC FROM ROA_UPL009_EXCLUDE_PC_LISTS WHERE D_KIND = In_KIND ) )) a, 
          ( select D_AMOUNT from ROA_PST005_MONTH_DATA_ROLL_12M where period = In_PERIOD
          and D_KIND = USI_KIND and D_KEY = STR06 and D_ACC = STR01 ) b    
      )
      LOOP
        INSERT INTO ROA_PST005_MONTH_DATA_ROLL_12M
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR08 ,STR01, REC1.AMOUNT);                
      END LOOP;
      
  --(4-10) --------  
      STR01 :=  'A02100';
      STR02 :=  'Net Mfg Revenues';
      for REC1 IN (  
          select a.amount1 - b.amount2 amount from
          ( SELECT sum( amount ) AMOUNT1  FROM PNL_MSA001_EM_DATA WHERE
          YYYY = In_YYYY AND MONTH = In_MM AND acct_id <> ' ' AND ACCT_NAME = STR02 ) a,
          ( SELECT sum( amount ) AMOUNT2  FROM PNL_MSA001_EM_DATA WHERE
          YYYY = In_YYYY AND MONTH = In_MM AND acct_id <> ' ' AND ACCT_NAME = STR02 AND ( PC IN  ( select SUBSTR(PC, 9, 2) FROM ROA_UPL009_EXCLUDE_PC_LISTS WHERE D_KIND = In_KIND ) ) ) b
      )
      LOOP
        INSERT INTO ROA_PST005_MONTH_DATA_ROLL_12M
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR08 ,STR01, (REC1.AMOUNT * 1000 ));                
      END LOOP; 
      
  --(4-11) --------  
      STR01 :=  'A02200';
      STR02 :=  '07.050';
      for REC1 IN (        
          select a.amount1 - b.amount2 amount from
          ( SELECT sum( amount ) AMOUNT1  FROM PNL_MSA001_EM_DATA WHERE
          YYYY = In_YYYY AND MONTH = In_MM AND acct_id <> ' ' AND acct_id <= STR02 ) a,
          ( SELECT sum( amount ) AMOUNT2  FROM PNL_MSA001_EM_DATA WHERE
          YYYY = In_YYYY AND MONTH = In_MM AND acct_id <> ' ' AND acct_id <= STR02 AND ( PC IN  ( select SUBSTR(PC, 9, 2) FROM ROA_UPL009_EXCLUDE_PC_LISTS WHERE D_KIND = In_KIND ) ) ) b             
      )
      LOOP
        INSERT INTO ROA_PST005_MONTH_DATA_ROLL_12M
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR08 ,STR01, (REC1.AMOUNT * 1000) );                 
      END LOOP;       

  --(4-12) --------  
      STR01 :=  'A04000';
      for REC1 IN (
          select b.D_AMOUNT-a.AMOUNT AMOUNT from
          ( SELECT sum( UPL_AMT_LOC  * EX_RATE_TWD ) AMOUNT FROM ROA_PST004_FIXED_ASSETS WHERE
          PERIOD = In_PERIOD AND S_SEQ IN ( '10' ) AND TYPE ='1' AND ( PC IN  ( select PC FROM ROA_UPL009_EXCLUDE_PC_LISTS WHERE D_KIND = In_KIND ) ) ) a, 
          ( select D_AMOUNT from ROA_PST005_MONTH_DATA_ROLL_12M where period = In_PERIOD
          and D_KIND = USI_KIND and D_KEY = STR06 and D_ACC = STR01 ) b     
      )
      LOOP
        INSERT INTO ROA_PST005_MONTH_DATA_ROLL_12M
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR08 ,STR01, REC1.AMOUNT);                 
      END LOOP;

  --(4-13) --------  
      STR01 :=  'A03600';
      for REC1 IN ( 
          select b.D_AMOUNT-a.AMOUNT AMOUNT from
          ( SELECT sum( UPL_AMT_LOC  * EX_RATE_TWD ) AMOUNT FROM ROA_PST004_FIXED_ASSETS WHERE
          PERIOD = In_PERIOD AND S_SEQ IN ( '20' ) AND TYPE ='1' AND ( PC IN  ( select PC FROM ROA_UPL009_EXCLUDE_PC_LISTS WHERE D_KIND = In_KIND ) ) ) a, 
          ( select D_AMOUNT from ROA_PST005_MONTH_DATA_ROLL_12M where period = In_PERIOD
          and D_KIND = USI_KIND and D_KEY = STR06 and D_ACC = STR01 ) b     
      )
      LOOP
        INSERT INTO ROA_PST005_MONTH_DATA_ROLL_12M
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR08 ,STR01, REC1.AMOUNT);                 
      END LOOP;

  --(4-13) --------  
      STR01 :=  'A04100';
      for REC1 IN (
          select b.D_AMOUNT-a.AMOUNT AMOUNT from
          ( SELECT sum( UPL_AMT_LOC  * EX_RATE_TWD ) AMOUNT FROM ROA_PST004_FIXED_ASSETS WHERE
          PERIOD = In_PERIOD AND S_SEQ IN ( '20' ) AND TYPE ='1' AND ( PC IN  ( select PC FROM ROA_UPL009_EXCLUDE_PC_LISTS WHERE D_KIND = In_KIND ) ) ) a, 
          ( select D_AMOUNT from ROA_PST005_MONTH_DATA_ROLL_12M where period = In_PERIOD
          and D_KIND = USI_KIND and D_KEY = STR06 and D_ACC = STR01 ) b               
      )
      LOOP
        INSERT INTO ROA_PST005_MONTH_DATA_ROLL_12M
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR08 ,STR01, REC1.AMOUNT);               
      END LOOP;
                
  --(4-14) --------  
      STR01 :=  'A04200';
      for REC1 IN (   
          select b.D_AMOUNT-a.AMOUNT AMOUNT from
          ( SELECT sum( UPL_AMT_LOC  * EX_RATE_TWD ) AMOUNT FROM ROA_PST004_FIXED_ASSETS WHERE
          PERIOD = In_PERIOD AND S_SEQ IN ( '30','40' ) AND TYPE ='1'  AND ( PC IN  ( select PC FROM ROA_UPL009_EXCLUDE_PC_LISTS WHERE D_KIND = In_KIND ) )) a, 
          ( select D_AMOUNT from ROA_PST005_MONTH_DATA_ROLL_12M where period = In_PERIOD
          and D_KIND = USI_KIND and D_KEY = STR06 and D_ACC = STR01 ) b   
      )
      LOOP
        INSERT INTO ROA_PST005_MONTH_DATA_ROLL_12M
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR08 ,STR01, REC1.AMOUNT);               
      END LOOP;             

  --(4-15) --------  
      STR01 :=  'A03800';
      for REC1 IN ( 
          select b.D_AMOUNT-a.AMOUNT AMOUNT from
          ( SELECT sum( UPL_AMT_LOC  * EX_RATE_TWD ) AMOUNT FROM ROA_PST004_FIXED_ASSETS WHERE
          PERIOD = In_PERIOD AND S_SEQ IN ( '20','30','40' ) AND TYPE ='1'  AND ( PC IN  ( select PC FROM ROA_UPL009_EXCLUDE_PC_LISTS WHERE D_KIND = In_KIND ) )) a,
          ( select D_AMOUNT from ROA_PST005_MONTH_DATA_ROLL_12M where period = In_PERIOD
          and D_KIND = USI_KIND and D_KEY = STR06 and D_ACC = STR01 ) b             
      )
      LOOP
        INSERT INTO ROA_PST005_MONTH_DATA_ROLL_12M
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR08 ,STR01, REC1.AMOUNT);                
      END LOOP; 

  --(4-15_2) --------       
      STR01 :=  'A03400';
      for REC1 IN (
          select b.D_AMOUNT-a.AMOUNT AMOUNT from
          ( SELECT SUM( D_AMOUNT )  AMOUNT FROM ROA_PST005_MONTH_DATA_ROLL_12M
          WHERE PERIOD = In_PERIOD 
          AND D_KIND = PC_KIND AND D_ACC in ( 'A03400' ) AND D_KEY IN  ( select PC FROM ROA_UPL009_EXCLUDE_PC_LISTS WHERE D_KIND = In_KIND ) ) a ,
          ( SELECT SUM( D_AMOUNT )  D_AMOUNT FROM ROA_PST005_MONTH_DATA_ROLL_12M
          WHERE PERIOD = In_PERIOD 
          AND D_KIND = USI_KIND AND D_ACC in ( 'A03400' ) ) b                 
      )
      LOOP
        INSERT INTO ROA_PST005_MONTH_DATA_ROLL_12M
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR08 ,STR01, REC1.AMOUNT);                 
      END LOOP;                   

  --(4-16) --------  
      STR01 :=  'C_NIB_Y_22';
      --STR02 :=  In_YYYY || '01';
      for REC1 IN (  
         select b.D_AMOUNT-a.D_AMOUNT AMOUNT from       
         ( select SUM(D_AMOUNT) D_AMOUNT from ROA_PST005_MONTH_DATA_ROLL_12M where period = In_PERIOD
         and D_KIND = PC_KIND and D_KEY IN  ( select PC FROM ROA_UPL009_EXCLUDE_PC_LISTS WHERE D_KIND = In_KIND ) and D_ACC = STR01 ) a,      
         ( select D_AMOUNT from ROA_PST005_MONTH_DATA_ROLL_12M where period = In_PERIOD
         and D_KIND = USI_KIND and D_KEY = STR06 and D_ACC = STR01 ) b
  
      )
      LOOP
        INSERT INTO ROA_PST005_MONTH_DATA_ROLL_12M
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR08 ,STR01, REC1.AMOUNT);                 
      END LOOP; 

  --(4-17) --------  
      STR01 :=  'C_SUB_A_14';
      --STR02 :=  In_YYYY || '01';
      for REC1 IN (  
         select b.D_AMOUNT-a.D_AMOUNT AMOUNT from       
         ( select SUM(D_AMOUNT) D_AMOUNT from ROA_PST005_MONTH_DATA_ROLL_12M where period = In_PERIOD
         and D_KIND = PC_KIND and D_KEY IN  ( select PC FROM ROA_UPL009_EXCLUDE_PC_LISTS WHERE D_KIND = In_KIND ) and D_ACC = STR01 ) a,      
         ( select D_AMOUNT from ROA_PST005_MONTH_DATA_ROLL_12M where period = In_PERIOD
         and D_KIND = USI_KIND and D_KEY = STR06 and D_ACC = STR01 ) b
  
      )
      LOOP
        INSERT INTO ROA_PST005_MONTH_DATA_ROLL_12M
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR08 ,STR01, REC1.AMOUNT);                 
      END LOOP; 

  --(4-18) --------  
      STR01 :=  'C_EQU_A_17';
      --STR02 :=  In_YYYY || '01';
      for REC1 IN (  
         select b.D_AMOUNT-a.D_AMOUNT AMOUNT from       
         ( select SUM(D_AMOUNT) D_AMOUNT from ROA_PST005_MONTH_DATA_ROLL_12M where period = In_PERIOD
         and D_KIND = PC_KIND and D_KEY IN  ( select PC FROM ROA_UPL009_EXCLUDE_PC_LISTS WHERE D_KIND = In_KIND ) and D_ACC = STR01 ) a,      
         ( select D_AMOUNT from ROA_PST005_MONTH_DATA_ROLL_12M where period = In_PERIOD
         and D_KIND = USI_KIND and D_KEY = STR06 and D_ACC = STR01 ) b
  
      )
      LOOP
        INSERT INTO ROA_PST005_MONTH_DATA_ROLL_12M
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR08 ,STR01, REC1.AMOUNT);                 
      END LOOP;

  --(4-19) --------  
      STR01 :=  'C_REV_Y_21';
      --STR02 :=  In_YYYY || '01';
      for REC1 IN (  
         select b.D_AMOUNT-a.D_AMOUNT AMOUNT from       
         ( select SUM(D_AMOUNT) D_AMOUNT from ROA_PST005_MONTH_DATA_ROLL_12M where period = In_PERIOD
         and D_KIND = PC_KIND and D_KEY IN  ( select PC FROM ROA_UPL009_EXCLUDE_PC_LISTS WHERE D_KIND = In_KIND ) and D_ACC = STR01 ) a,      
         ( select D_AMOUNT from ROA_PST005_MONTH_DATA_ROLL_12M where period = In_PERIOD
         and D_KIND = USI_KIND and D_KEY = STR06 and D_ACC = STR01 ) b
  
      )
      LOOP
        INSERT INTO ROA_PST005_MONTH_DATA_ROLL_12M
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR08 ,STR01, REC1.AMOUNT);                 
      END LOOP;

  --(4-20) --------  
      STR01 :=  'C_SFA_A_10N12';
      --STR02 :=  In_YYYY || '01';
      for REC1 IN (  
         select b.D_AMOUNT-a.D_AMOUNT AMOUNT from       
         ( select SUM(D_AMOUNT) D_AMOUNT from ROA_PST005_MONTH_DATA_ROLL_12M where period = In_PERIOD
         and D_KIND = PC_KIND and D_KEY IN  ( select PC FROM ROA_UPL009_EXCLUDE_PC_LISTS WHERE D_KIND = In_KIND ) and D_ACC = STR01 ) a,      
         ( select D_AMOUNT from ROA_PST005_MONTH_DATA_ROLL_12M where period = In_PERIOD
         and D_KIND = USI_KIND and D_KEY = STR06 and D_ACC = STR01 ) b
  
      )
      LOOP
        INSERT INTO ROA_PST005_MONTH_DATA_ROLL_12M
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR08 ,STR01, REC1.AMOUNT);                 
      END LOOP;

  --(4-21) --------  
      STR01 :=  'C_BV1_A_30';
      --STR02 :=  In_YYYY || '01';
      for REC1 IN (  
         select b.D_AMOUNT-a.D_AMOUNT AMOUNT from       
         ( select SUM(D_AMOUNT) D_AMOUNT from ROA_PST005_MONTH_DATA_ROLL_12M where period = In_PERIOD
         and D_KIND = PC_KIND and D_KEY IN  ( select PC FROM ROA_UPL009_EXCLUDE_PC_LISTS WHERE D_KIND = In_KIND ) and D_ACC = STR01 ) a,      
         ( select D_AMOUNT from ROA_PST005_MONTH_DATA_ROLL_12M where period = In_PERIOD
         and D_KIND = USI_KIND and D_KEY = STR06 and D_ACC = STR01 ) b
  
      )
      LOOP
        INSERT INTO ROA_PST005_MONTH_DATA_ROLL_12M
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR08 ,STR01, REC1.AMOUNT);                 
      END LOOP;

  --(4-22) --------  
      STR01 :=  'C_BV2_A_32';
      --STR02 :=  In_YYYY || '01';
      for REC1 IN (  
         select b.D_AMOUNT-a.D_AMOUNT AMOUNT from       
         ( select SUM(D_AMOUNT) D_AMOUNT from ROA_PST005_MONTH_DATA_ROLL_12M where period = In_PERIOD
         and D_KIND = PC_KIND and D_KEY IN  ( select PC FROM ROA_UPL009_EXCLUDE_PC_LISTS WHERE D_KIND = In_KIND ) and D_ACC = STR01 ) a,      
         ( select D_AMOUNT from ROA_PST005_MONTH_DATA_ROLL_12M where period = In_PERIOD
         and D_KIND = USI_KIND and D_KEY = STR06 and D_ACC = STR01 ) b
  
      )
      LOOP
        INSERT INTO ROA_PST005_MONTH_DATA_ROLL_12M
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR08 ,STR01, REC1.AMOUNT);                 
      END LOOP;

  --(4-23) --------  
      STR01 :=  'C_OV1_A_34';
      --STR02 :=  In_YYYY || '01';
      for REC1 IN (  
         select b.D_AMOUNT-a.D_AMOUNT AMOUNT from       
         ( select SUM(D_AMOUNT) D_AMOUNT from ROA_PST005_MONTH_DATA_ROLL_12M where period = In_PERIOD
         and D_KIND = PC_KIND and D_KEY IN  ( select PC FROM ROA_UPL009_EXCLUDE_PC_LISTS WHERE D_KIND = In_KIND ) and D_ACC = STR01 ) a,      
         ( select D_AMOUNT from ROA_PST005_MONTH_DATA_ROLL_12M where period = In_PERIOD
         and D_KIND = USI_KIND and D_KEY = STR06 and D_ACC = STR01 ) b
  
      )
      LOOP
        INSERT INTO ROA_PST005_MONTH_DATA_ROLL_12M
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR08 ,STR01, REC1.AMOUNT);                 
      END LOOP;


  --(4-24) --------  
      STR01 :=  'C_OV2_A_36';
      --STR02 :=  In_YYYY || '01';
      for REC1 IN (  
         select b.D_AMOUNT-a.D_AMOUNT AMOUNT from       
         ( select SUM(D_AMOUNT) D_AMOUNT from ROA_PST005_MONTH_DATA_ROLL_12M where period = In_PERIOD
         and D_KIND = PC_KIND and D_KEY IN  ( select PC FROM ROA_UPL009_EXCLUDE_PC_LISTS WHERE D_KIND = In_KIND ) and D_ACC = STR01 ) a,      
         ( select D_AMOUNT from ROA_PST005_MONTH_DATA_ROLL_12M where period = In_PERIOD
         and D_KIND = USI_KIND and D_KEY = STR06 and D_ACC = STR01 ) b
  
      )
      LOOP
        INSERT INTO ROA_PST005_MONTH_DATA_ROLL_12M
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR08 ,STR01, REC1.AMOUNT);                 
      END LOOP;

  --(4-25) --------  
      STR01 :=  'C_OV3_A_38';
      --STR02 :=  In_YYYY || '01';
      for REC1 IN (  
         select b.D_AMOUNT-a.D_AMOUNT AMOUNT from       
         ( select SUM(D_AMOUNT) D_AMOUNT from ROA_PST005_MONTH_DATA_ROLL_12M where period = In_PERIOD
         and D_KIND = PC_KIND and D_KEY IN  ( select PC FROM ROA_UPL009_EXCLUDE_PC_LISTS WHERE D_KIND = In_KIND ) and D_ACC = STR01 ) a,      
         ( select D_AMOUNT from ROA_PST005_MONTH_DATA_ROLL_12M where period = In_PERIOD
         and D_KIND = USI_KIND and D_KEY = STR06 and D_ACC = STR01 ) b
  
      )
      LOOP
        INSERT INTO ROA_PST005_MONTH_DATA_ROLL_12M
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR08 ,STR01, REC1.AMOUNT);                 
      END LOOP;   
    
  --(4-99) --------      
      STR01 :=  'C_BV3_A_44';
      for REC1 IN (
          select b.D_AMOUNT-a.AMOUNT AMOUNT from
          ( SELECT SUM( D_AMOUNT )  AMOUNT FROM ROA_PST005_MONTH_DATA_ROLL_12M
          WHERE PERIOD = In_PERIOD 
          AND D_KIND = PC_KIND AND D_ACC in ( 'C_BV3_A_44' ) AND D_KEY IN  ( select PC FROM ROA_UPL009_EXCLUDE_PC_LISTS WHERE D_KIND = In_KIND ) ) a ,
          ( SELECT SUM( D_AMOUNT )  D_AMOUNT FROM ROA_PST005_MONTH_DATA_ROLL_12M
          WHERE PERIOD = In_PERIOD 
          AND D_KIND = USI_KIND AND D_ACC in ( 'C_BV3_A_44' ) ) b
                
      )
      LOOP
        INSERT INTO ROA_PST005_MONTH_DATA_ROLL_12M
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR08 ,STR01, REC1.AMOUNT);                 
      END LOOP;    
      
  --(4-98) --------      
      STR01 :=  'C_OV4_A_46';
      for REC1 IN (
          select b.D_AMOUNT-a.AMOUNT AMOUNT from
          ( SELECT SUM( D_AMOUNT )  AMOUNT FROM ROA_PST005_MONTH_DATA_ROLL_12M
          WHERE PERIOD = In_PERIOD 
          AND D_KIND = PC_KIND AND D_ACC in ( 'C_OV4_A_46' ) AND D_KEY IN  ( select PC FROM ROA_UPL009_EXCLUDE_PC_LISTS WHERE D_KIND = In_KIND ) ) a ,
          ( SELECT SUM( D_AMOUNT )  D_AMOUNT FROM ROA_PST005_MONTH_DATA_ROLL_12M
          WHERE PERIOD = In_PERIOD 
          AND D_KIND = USI_KIND AND D_ACC in ( 'C_OV4_A_46' ) ) b                 
      )
      LOOP
        INSERT INTO ROA_PST005_MONTH_DATA_ROLL_12M
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR08 ,STR01, REC1.AMOUNT);                 
      END LOOP;   
 

  --(4-97) --------      
      STR01 :=  'A04400';
      for REC1 IN (
          select b.D_AMOUNT-a.AMOUNT AMOUNT from
          ( SELECT SUM( D_AMOUNT )  AMOUNT FROM ROA_PST005_MONTH_DATA_ROLL_12M
          WHERE PERIOD = In_PERIOD 
          AND D_KIND = PC_KIND AND D_ACC in ( 'A04400' ) AND D_KEY IN  ( select PC FROM ROA_UPL009_EXCLUDE_PC_LISTS WHERE D_KIND = In_KIND ) ) a ,
          ( SELECT SUM( D_AMOUNT )  D_AMOUNT FROM ROA_PST005_MONTH_DATA_ROLL_12M
          WHERE PERIOD = In_PERIOD 
          AND D_KIND = USI_KIND AND D_ACC in ( 'A04400' ) ) b                 
      )
      LOOP
        INSERT INTO ROA_PST005_MONTH_DATA_ROLL_12M
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR08 ,STR01, REC1.AMOUNT);                 
      END LOOP;   

  --(4-97) --------      
      STR01 :=  'A04600';
      for REC1 IN (
          select b.D_AMOUNT-a.AMOUNT AMOUNT from
          ( SELECT SUM( D_AMOUNT )  AMOUNT FROM ROA_PST005_MONTH_DATA_ROLL_12M
          WHERE PERIOD = In_PERIOD 
          AND D_KIND = PC_KIND AND D_ACC in ( 'A04600' ) AND D_KEY IN  ( select PC FROM ROA_UPL009_EXCLUDE_PC_LISTS WHERE D_KIND = In_KIND ) ) a ,
          ( SELECT SUM( D_AMOUNT )  D_AMOUNT FROM ROA_PST005_MONTH_DATA_ROLL_12M
          WHERE PERIOD = In_PERIOD 
          AND D_KIND = USI_KIND AND D_ACC in ( 'A04600' ) ) b                 
      )
      LOOP
        INSERT INTO ROA_PST005_MONTH_DATA_ROLL_12M
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR08 ,STR01, REC1.AMOUNT);                 
      END LOOP; 
      delete  FROM   ROA_PST005_MONTH_DATA_ROLL_12M WHERE D_KEY = STR08 AND D_KIND <> In_KIND AND PERIOD = In_PERIOD;
      COMMIT;      
  END IF;       
  
  
END ROA_PLS011_CAL_MONTH_ROLL_12M;
/

