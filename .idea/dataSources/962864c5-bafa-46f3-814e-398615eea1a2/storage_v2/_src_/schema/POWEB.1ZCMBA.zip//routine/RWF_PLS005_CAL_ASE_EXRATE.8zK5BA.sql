create PROCEDURE RWF_PLS005_CAL_ASE_EXRATE (
  sRWF_YYYY in RWF_SAP001_REVENUE_FORECAST.RWF_YYYY%TYPE,
  sRWF_WEEK in RWF_SAP001_REVENUE_FORECAST.RWF_WEEK%TYPE
)
AUTHID DEFINER
/*********************************************************************
  ACTION       : Revenue Forecast 使用 ASE (RWF_MAP003_ASE_EX_RATE) 匯率 FOR TABLE RWF_SAP001_REVENUE_FORECAST
  Author       : KANGI
  Date         : 2014/07/10
  OA           :  SAI045958
**********************************************************************/
--20140724 改由美金上傳
is
   --處理 (周別) RWF_SAP001_REVENUE_FORECAST
   CURSOR RWF_SAP001_CUR is
   SELECT F_YEAR,RWF_MM FROM RWF_SAP001_REVENUE_FORECAST
    WHERE RWF_YYYY = sRWF_YYYY AND RWF_WEEK = sRWF_WEEK
    GROUP BY F_YEAR,RWF_MM ;

   sORG_CURRENCY   RWF_MAP003_ASE_EX_RATE.FROM_CURRENCY%TYPE ;
   nTO_USD_RATE    RWF_MAP003_ASE_EX_RATE.TO_USD_RATE%TYPE ;
   nTO_CNY_RATE    RWF_MAP003_ASE_EX_RATE.TO_CNY_RATE%TYPE ;
   nTO_TWD_RATE    RWF_MAP003_ASE_EX_RATE.TO_TWD_RATE%TYPE ;
   sBDATE          RWF_MAP003_ASE_EX_RATE.BDATE%TYPE ;
   iTracePoint  integer ;
   cErrorText varchar2(500) ;
 BEGIN
  iTracePoint := 100 ;
  sORG_CURRENCY := 'USD' ;

  iTracePoint := 200 ;


  iTracePoint := 300 ;
  --GET 最大的 sBDATE FROM RWF_MAP003_ASE_EX_RATE
  sBDATE := NULL ;
  BEGIN
      iTracePoint := 400 ;
      SELECT MAX(BDATE) INTO sBDATE FROM RWF_MAP003_ASE_EX_RATE ;
      iTracePoint := 500 ;
      EXCEPTION
          WHEN OTHERS THEN
          NULL  ;
  END ;
  iTracePoint := 600 ;
  IF sBDATE IS NOT NULL THEN
     iTracePoint := 700 ;
     FOR RWF_SAP001_REC in RWF_SAP001_CUR LOOP
         iTracePoint := 800 ;
         nTO_USD_RATE := 0 ;
         nTO_TWD_RATE := 0 ;
         nTO_CNY_RATE := 0 ;
         iTracePoint := 900 ;
         BEGIN
            iTracePoint := 400 ;
            SELECT TO_USD_RATE,TO_CNY_RATE,TO_TWD_RATE
              INTO nTO_USD_RATE,nTO_CNY_RATE,nTO_TWD_RATE
              FROM RWF_MAP003_ASE_EX_RATE
             WHERE FROM_CURRENCY = sORG_CURRENCY
               AND PERIOD = ( SELECT MAX(PERIOD) FROM RWF_MAP003_ASE_EX_RATE WHERE PERIOD <= RWF_SAP001_REC.F_YEAR||RWF_SAP001_REC.RWF_MM AND BDATE = sBDATE )
               AND BDATE = sBDATE  ;
            iTracePoint := 1000 ;
                  EXCEPTION
                  WHEN OTHERS THEN
                     iTracePoint := 1100 ;
                     NULL  ;
         END ;
         iTracePoint := 1200 ;

         IF nTO_TWD_RATE <> 0 THEN
            iTracePoint := 1300 ;
            --更新RWF_SAP001_REVENUE_FORECAST BY sRWF_YYYY,sRWF_WEEK
            BEGIN
              UPDATE RWF_SAP001_REVENUE_FORECAST
              SET NET_REVENUE_USD = NET_REVENUE * nTO_USD_RATE ,
                  NET_REVENUE_TWD = NET_REVENUE * nTO_TWD_RATE ,
                  NET_REVENUE_CNY = NET_REVENUE * nTO_CNY_RATE
              WHERE RWF_YYYY = sRWF_YYYY
                AND RWF_WEEK = sRWF_WEEK
                AND F_YEAR = RWF_SAP001_REC.F_YEAR
                AND RWF_MM = RWF_SAP001_REC.RWF_MM ;
              iTracePoint := 1400 ;
              EXCEPTION
              WHEN OTHERS THEN
              iTracePoint := 1500 ;
              NULL  ;
            END ;
         END IF;
         iTracePoint := 1600 ;
     END LOOP ;
     iTracePoint := 1700 ;
  END IF;
  --COMMIT ;
  iTracePoint := 1800 ;
 EXCEPTION
     WHEN OTHERS THEN
            --rollback ;
            cErrorText := SQLERRM() ;
            MAIL_FILE_BIDBDBADMIN(in_to_name=>'kangi@ms.usi.com.tw',subject   => 'PL/SQL RWF_PLS005_CAL_ASE_EXRATE ERROR', message => '[RWF_PLS005_CAL_ASE_EXRATE], The tracepoint is  ' || to_char(iTracePoint) || 'and ErrorText=' || cErrorText) ;
            DBMS_OUTPUT.PUT_LINE(SUBSTR(cErrorText,1,255));
            DBMS_OUTPUT.PUT_LINE(TO_CHAR(iTracePoint));
END RWF_PLS005_CAL_ASE_EXRATE;
/

