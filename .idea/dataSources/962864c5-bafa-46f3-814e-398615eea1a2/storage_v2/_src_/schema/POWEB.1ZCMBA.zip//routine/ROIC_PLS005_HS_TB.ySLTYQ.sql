create PROCEDURE       ROIC_PLS005_HS_TB (
  t_YYYYMMDD in VARCHAR2,
  w_USER     in VARCHAR2
)
AUTHID DEFINER
is
/*********************************************************************
  PROG-ID      : ROIC_PLS005_HS_TB_BTO
  PROG-ACTION  : Trial Balance - 投資架構依持股比例合併計算
  Author       : Patty
  Date         : 2019/02/26
  OA No.       : SAI095603
  Process      : Excute Procedure ROIC_PLS005_HS_TB_BTO &
                                  ROIC_PLS005_HS_TB_G1_BTO
**********************************************************************/
/*---------------------------------------------------------------------
---------------------------------------------------------------------*/
  sPROC_NAME         ROIC_PST000_LOG.PROC_NAME%TYPE;
  sRUN_SEQ           ROIC_PST000_LOG.RUN_SEQ%TYPE;
  sRUN_DESC          ROIC_PST000_LOG.RUN_DESC%TYPE;
  sPARAMETER_DESC    ROIC_PST000_LOG.PARAMETER_DESC%TYPE;       
  t_PERIOD           ROIC_SAP003_TB_DATA.PERIOD%TYPE;  

             
BEGIN

  t_PERIOD := SUBSTR(t_YYYYMMDD,1,6);

  sPROC_NAME := 'ROIC_PLS005_HS_TB';
  sRUN_SEQ   := '000010';
  sRUN_DESC  := 'Start';
  sPARAMETER_DESC := CONCAT(CONCAT(CONCAT('t_PERIOD=',t_PERIOD),';w_USER='),w_USER);
 
  --Insert Log
  INSERT INTO ROIC_PST000_LOG
      ( PROC_NAME, RUN_SEQ, RUN_DESC, PARAMETER_DESC )
    VALUES
      ( sPROC_NAME, sRUN_SEQ, sRUN_DESC, sPARAMETER_DESC );
  Commit;

  --Exec Store Procedure
  ROIC_PLS005_HS_TB_BTO(t_PERIOD);

  ROIC_PLS005_HS_TB_G1_BTO(t_PERIOD);

  sRUN_SEQ   := '000020';
  sRUN_DESC  := 'End';

  --Insert Log
  INSERT INTO ROIC_PST000_LOG
      ( PROC_NAME, RUN_SEQ, RUN_DESC, PARAMETER_DESC )
    VALUES
      ( sPROC_NAME, sRUN_SEQ, sRUN_DESC, sPARAMETER_DESC );
  Commit;

END ROIC_PLS005_HS_TB;
/

