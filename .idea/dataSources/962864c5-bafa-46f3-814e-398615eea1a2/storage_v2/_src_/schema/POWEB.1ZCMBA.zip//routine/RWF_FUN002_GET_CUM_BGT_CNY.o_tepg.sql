create Function RWF_FUN002_GET_CUM_BGT_CNY(cRWF_YYYY in RWF_SAP001_REVENUE_FORECAST.RWF_YYYY%TYPE,cCOMPANY_CODE in RWF_SAP001_REVENUE_FORECAST.COMPANY_CODE%TYPE,cPROFIT_CENTER in RWF_SAP001_REVENUE_FORECAST.PROFIT_CENTER%TYPE)
/*********************************************************************
*新增/修改日期 :  2007-01-10
*Programmer    :  Kangi
*申請單號      :  SAI005398
*新增原因      :  GET 'BUDGET' SUMMARY BY YEAR FROM RWF_ZOT001_REVENUE_BUDGET
**********************************************************************/
/*********************************************************************
--Add Date : 20111230
--Add User : kangi
--Add Reason : Add RWF_FUN002_GET_CUM_BGT_CNY Function
--OA         : SAI028442
**********************************************************************/
return RWF_SAP001_REVENUE_FORECAST.NET_REVENUE%TYPE
is
cBUDGET_NET_REVENUE_CNY  RWF_SAP001_REVENUE_FORECAST.NET_REVENUE%TYPE ;
Begin

       SELECT NVL(SUM(NET_REVENUE_CNY),'0') INTO cBUDGET_NET_REVENUE_CNY FROM RWF_ZOT001_REVENUE_BUDGET
              WHERE RWF_YYYY = cRWF_YYYY
                AND COMPANY_CODE = cCOMPANY_CODE
                AND PROFIT_CENTER = cPROFIT_CENTER ;

       return cBUDGET_NET_REVENUE_CNY ;
End RWF_FUN002_GET_CUM_BGT_CNY;
/

