create PROCEDURE       USI11731_CUSTOMER (
  inCompany  in VARCHAR2,
  t_Period in VARCHAR2
  --2008/9/17 Create to Process get Amount in Local/USD/TWD
  --Trigger by PNL2_BAD_DEPT_UPLOAD.JSP
)
AUTHID DEFINER
is
   
  CURSOR C_PNL2_PLS003_COGS is
  SELECT COMPANY_CODE,PERIOD,PART_NO,PROFIT_CENTER,CUSTOMER_ID,SHIP_TO_PARTY,MTL_GROUP,COST_ELEMENT,MTL_TYPE,END_CUSTOMER_ID,PLANT_CODE
  FROM KPI_SAP001_COPA_TRX_TEMP
   WHERE  NET_COGS <> 0
   --AND   COMPANY_CODE = inCompany
   AND   PERIOD = t_period
   AND COST_ELEMENT IN ('0000510101','0000510102','0000510103','0000510104','0000510201','0000510301','0000510401','0000510501','0000510901','0000510902','0000510903','0000510909','0000510999')
   GROUP BY COMPANY_CODE,PERIOD,PART_NO,PROFIT_CENTER,CUSTOMER_ID,SHIP_TO_PARTY,MTL_GROUP,COST_ELEMENT,MTL_TYPE,END_CUSTOMER_ID,PLANT_CODE;

 
 aEND_CUSTOMER_ID                KPI_SAP001_COPA_TRX_TEMP.END_CUSTOMER_ID%TYPE;

 BEGIN


    /** Insert COGS**/
     FOR REC1 in C_PNL2_PLS003_COGS Loop
         IF  REC1.COST_ELEMENT = '0000510101' THEN
           IF REC1.END_CUSTOMER_ID IS NULL THEN
             UPDATE KPI_SAP001_COPA_TRX_TEMP SET END_CUSTOMER_ID = 'Others',PDM_CUSTOMER1 = 'Others' 
                 where COMPANY_CODE = REC1.COMPANY_CODE
                   and PERIOD = REC1.PERIOD
                   and NVL(PART_NO,NULL) = NVL(REC1.PART_NO,NULL)
                   and PROFIT_CENTER = REC1.PROFIT_CENTER
                   and NVL(CUSTOMER_ID,NULL) = NVL(REC1.CUSTOMER_ID,NULL)
                   and NVL(SHIP_TO_PARTY,NULL) = NVL(REC1.SHIP_TO_PARTY,NULL)
                   and NVL(MTL_GROUP,NULL) = NVL(REC1.MTL_GROUP,NULL)
                   and NVL(COST_ELEMENT,NULL) = NVL(REC1.COST_ELEMENT,NULL)
                   and NVL(MTL_TYPE,NULL)     = NVL(REC1.MTL_TYPE,NULL)
                   and NVL(END_CUSTOMER_ID,NULL) = NVL(REC1.END_CUSTOMER_ID,NULL)
                   and NVL(PLANT_CODE,NULL)      = NVL(REC1.PLANT_CODE,NULL);
             Commit;
           ELSE
             UPDATE KPI_SAP001_COPA_TRX_TEMP SET PDM_CUSTOMER1 = REC1.END_CUSTOMER_ID
                 where COMPANY_CODE = REC1.COMPANY_CODE
                   and PERIOD = REC1.PERIOD
                   and NVL(PART_NO,NULL) = NVL(REC1.PART_NO,NULL)
                   and PROFIT_CENTER = REC1.PROFIT_CENTER
                   and NVL(CUSTOMER_ID,NULL) = NVL(REC1.CUSTOMER_ID,NULL)
                   and NVL(SHIP_TO_PARTY,NULL) = NVL(REC1.SHIP_TO_PARTY,NULL)
                   and NVL(MTL_GROUP,NULL) = NVL(REC1.MTL_GROUP,NULL)
                   and NVL(COST_ELEMENT,NULL) = NVL(REC1.COST_ELEMENT,NULL)
                   and NVL(MTL_TYPE,NULL)     = NVL(REC1.MTL_TYPE,NULL)
                   and NVL(END_CUSTOMER_ID,NULL) = NVL(REC1.END_CUSTOMER_ID,NULL)
                   and NVL(PLANT_CODE,NULL)      = NVL(REC1.PLANT_CODE,NULL);
             Commit;
           END IF;
         ELSIF REC1.COST_ELEMENT = '0000510102' THEN
          IF REC1.END_CUSTOMER_ID IS NULL THEN
             UPDATE KPI_SAP001_COPA_TRX_TEMP SET END_CUSTOMER_ID = 'Others',PDM_CUSTOMER1 = 'Others' 
                 where COMPANY_CODE = REC1.COMPANY_CODE
                   and PERIOD = REC1.PERIOD
                   and NVL(PART_NO,NULL) = NVL(REC1.PART_NO,NULL)
                   and PROFIT_CENTER = REC1.PROFIT_CENTER
                   and NVL(CUSTOMER_ID,NULL) = NVL(REC1.CUSTOMER_ID,NULL)
                   and NVL(SHIP_TO_PARTY,NULL) = NVL(REC1.SHIP_TO_PARTY,NULL)
                   and NVL(MTL_GROUP,NULL) = NVL(REC1.MTL_GROUP,NULL)
                   and NVL(COST_ELEMENT,NULL) = NVL(REC1.COST_ELEMENT,NULL)
                   and NVL(MTL_TYPE,NULL)     = NVL(REC1.MTL_TYPE,NULL)
                   and NVL(END_CUSTOMER_ID,NULL) = NVL(REC1.END_CUSTOMER_ID,NULL)
                   and NVL(PLANT_CODE,NULL)      = NVL(REC1.PLANT_CODE,NULL);
             Commit;
           ELSE
             UPDATE KPI_SAP001_COPA_TRX_TEMP SET PDM_CUSTOMER1 = REC1.END_CUSTOMER_ID
                 where COMPANY_CODE = REC1.COMPANY_CODE
                   and PERIOD = REC1.PERIOD
                   and NVL(PART_NO,NULL) = NVL(REC1.PART_NO,NULL)
                   and PROFIT_CENTER = REC1.PROFIT_CENTER
                   and NVL(CUSTOMER_ID,NULL) = NVL(REC1.CUSTOMER_ID,NULL)
                   and NVL(SHIP_TO_PARTY,NULL) = NVL(REC1.SHIP_TO_PARTY,NULL)
                   and NVL(MTL_GROUP,NULL) = NVL(REC1.MTL_GROUP,NULL)
                   and NVL(COST_ELEMENT,NULL) = NVL(REC1.COST_ELEMENT,NULL)
                   and NVL(MTL_TYPE,NULL)     = NVL(REC1.MTL_TYPE,NULL)
                   and NVL(END_CUSTOMER_ID,NULL) = NVL(REC1.END_CUSTOMER_ID,NULL)
                   and NVL(PLANT_CODE,NULL)      = NVL(REC1.PLANT_CODE,NULL);
             Commit;
           END IF;
         ELSIF REC1.COST_ELEMENT = '0000510103' THEN
           IF REC1.END_CUSTOMER_ID IS NULL THEN
                UPDATE KPI_SAP001_COPA_TRX_TEMP SET END_CUSTOMER_ID = 'Others',PDM_CUSTOMER1 = 'Others' 
                 where COMPANY_CODE = REC1.COMPANY_CODE
                   and PERIOD = REC1.PERIOD
                   and NVL(PART_NO,NULL) = NVL(REC1.PART_NO,NULL)
                   and PROFIT_CENTER = REC1.PROFIT_CENTER
                   and NVL(CUSTOMER_ID,NULL) = NVL(REC1.CUSTOMER_ID,NULL)
                   and NVL(SHIP_TO_PARTY,NULL) = NVL(REC1.SHIP_TO_PARTY,NULL)
                   and NVL(MTL_GROUP,NULL) = NVL(REC1.MTL_GROUP,NULL)
                   and NVL(COST_ELEMENT,NULL) = NVL(REC1.COST_ELEMENT,NULL)
                   and NVL(MTL_TYPE,NULL)     = NVL(REC1.MTL_TYPE,NULL)
                   and NVL(END_CUSTOMER_ID,NULL) = NVL(REC1.END_CUSTOMER_ID,NULL)
                   and NVL(PLANT_CODE,NULL)      = NVL(REC1.PLANT_CODE,NULL);
                Commit;
            ELSE
                UPDATE KPI_SAP001_COPA_TRX_TEMP SET  PDM_CUSTOMER1 = REC1.END_CUSTOMER_ID
                 where COMPANY_CODE = REC1.COMPANY_CODE
                   and PERIOD = REC1.PERIOD
                   and NVL(PART_NO,NULL) = NVL(REC1.PART_NO,NULL)
                   and PROFIT_CENTER = REC1.PROFIT_CENTER
                   and NVL(CUSTOMER_ID,NULL) = NVL(REC1.CUSTOMER_ID,NULL)
                   and NVL(SHIP_TO_PARTY,NULL) = NVL(REC1.SHIP_TO_PARTY,NULL)
                   and NVL(MTL_GROUP,NULL) = NVL(REC1.MTL_GROUP,NULL)
                   and NVL(COST_ELEMENT,NULL) = NVL(REC1.COST_ELEMENT,NULL)
                   and NVL(MTL_TYPE,NULL)     = NVL(REC1.MTL_TYPE,NULL)
                   and NVL(END_CUSTOMER_ID,NULL) = NVL(REC1.END_CUSTOMER_ID,NULL)
                   and NVL(PLANT_CODE,NULL)      = NVL(REC1.PLANT_CODE,NULL);
                Commit;
            END IF;
         ELSIF REC1.COST_ELEMENT = '0000510104' THEN
            IF REC1.END_CUSTOMER_ID IS NULL THEN
             UPDATE KPI_SAP001_COPA_TRX_TEMP SET END_CUSTOMER_ID = 'Others',PDM_CUSTOMER1 = 'Others' 
                 where COMPANY_CODE = REC1.COMPANY_CODE
                   and PERIOD = REC1.PERIOD
                   and NVL(PART_NO,NULL) = NVL(REC1.PART_NO,NULL)
                   and PROFIT_CENTER = REC1.PROFIT_CENTER
                   and NVL(CUSTOMER_ID,NULL) = NVL(REC1.CUSTOMER_ID,NULL)
                   and NVL(SHIP_TO_PARTY,NULL) = NVL(REC1.SHIP_TO_PARTY,NULL)
                   and NVL(MTL_GROUP,NULL) = NVL(REC1.MTL_GROUP,NULL)
                   and NVL(COST_ELEMENT,NULL) = NVL(REC1.COST_ELEMENT,NULL)
                   and NVL(MTL_TYPE,NULL)     = NVL(REC1.MTL_TYPE,NULL)
                   and NVL(END_CUSTOMER_ID,NULL) = NVL(REC1.END_CUSTOMER_ID,NULL)
                   and NVL(PLANT_CODE,NULL)      = NVL(REC1.PLANT_CODE,NULL);
             Commit;
            ELSE
                UPDATE KPI_SAP001_COPA_TRX_TEMP SET  PDM_CUSTOMER1 = REC1.END_CUSTOMER_ID
                 where COMPANY_CODE = REC1.COMPANY_CODE
                   and PERIOD = REC1.PERIOD
                   and NVL(PART_NO,NULL) = NVL(REC1.PART_NO,NULL)
                   and PROFIT_CENTER = REC1.PROFIT_CENTER
                   and NVL(CUSTOMER_ID,NULL) = NVL(REC1.CUSTOMER_ID,NULL)
                   and NVL(SHIP_TO_PARTY,NULL) = NVL(REC1.SHIP_TO_PARTY,NULL)
                   and NVL(MTL_GROUP,NULL) = NVL(REC1.MTL_GROUP,NULL)
                   and NVL(COST_ELEMENT,NULL) = NVL(REC1.COST_ELEMENT,NULL)
                   and NVL(MTL_TYPE,NULL)     = NVL(REC1.MTL_TYPE,NULL)
                   and NVL(END_CUSTOMER_ID,NULL) = NVL(REC1.END_CUSTOMER_ID,NULL)
                   and NVL(PLANT_CODE,NULL)      = NVL(REC1.PLANT_CODE,NULL);
                Commit;
            END IF;
         ELSIF REC1.COST_ELEMENT = '0000510107' THEN
           IF REC1.END_CUSTOMER_ID IS NULL THEN
             UPDATE KPI_SAP001_COPA_TRX_TEMP SET END_CUSTOMER_ID = 'Others',PDM_CUSTOMER1 = 'Others' 
                 where COMPANY_CODE = REC1.COMPANY_CODE
                   and PERIOD = REC1.PERIOD
                   and NVL(PART_NO,NULL) = NVL(REC1.PART_NO,NULL)
                   and PROFIT_CENTER = REC1.PROFIT_CENTER
                   and NVL(CUSTOMER_ID,NULL) = NVL(REC1.CUSTOMER_ID,NULL)
                   and NVL(SHIP_TO_PARTY,NULL) = NVL(REC1.SHIP_TO_PARTY,NULL)
                   and NVL(MTL_GROUP,NULL) = NVL(REC1.MTL_GROUP,NULL)
                   and NVL(COST_ELEMENT,NULL) = NVL(REC1.COST_ELEMENT,NULL)
                   and NVL(MTL_TYPE,NULL)     = NVL(REC1.MTL_TYPE,NULL)
                   and NVL(END_CUSTOMER_ID,NULL) = NVL(REC1.END_CUSTOMER_ID,NULL)
                   and NVL(PLANT_CODE,NULL)      = NVL(REC1.PLANT_CODE,NULL);
             Commit;
            ELSE
                UPDATE KPI_SAP001_COPA_TRX_TEMP SET  PDM_CUSTOMER1 = REC1.END_CUSTOMER_ID
                 where COMPANY_CODE = REC1.COMPANY_CODE
                   and PERIOD = REC1.PERIOD
                   and NVL(PART_NO,NULL) = NVL(REC1.PART_NO,NULL)
                   and PROFIT_CENTER = REC1.PROFIT_CENTER
                   and NVL(CUSTOMER_ID,NULL) = NVL(REC1.CUSTOMER_ID,NULL)
                   and NVL(SHIP_TO_PARTY,NULL) = NVL(REC1.SHIP_TO_PARTY,NULL)
                   and NVL(MTL_GROUP,NULL) = NVL(REC1.MTL_GROUP,NULL)
                   and NVL(COST_ELEMENT,NULL) = NVL(REC1.COST_ELEMENT,NULL)
                   and NVL(MTL_TYPE,NULL)     = NVL(REC1.MTL_TYPE,NULL)
                   and NVL(END_CUSTOMER_ID,NULL) = NVL(REC1.END_CUSTOMER_ID,NULL)
                   and NVL(PLANT_CODE,NULL)      = NVL(REC1.PLANT_CODE,NULL);
                Commit;
            END IF;
         ELSIF REC1.COST_ELEMENT = '0000510109' THEN
           IF REC1.END_CUSTOMER_ID IS NULL THEN
             UPDATE KPI_SAP001_COPA_TRX_TEMP SET END_CUSTOMER_ID = 'INTEL',PDM_CUSTOMER1 = 'INTEL' 
                 where COMPANY_CODE = REC1.COMPANY_CODE
                   and PERIOD = REC1.PERIOD
                   and NVL(PART_NO,NULL) = NVL(REC1.PART_NO,NULL)
                   and PROFIT_CENTER = REC1.PROFIT_CENTER
                   and NVL(CUSTOMER_ID,NULL) = NVL(REC1.CUSTOMER_ID,NULL)
                   and NVL(SHIP_TO_PARTY,NULL) = NVL(REC1.SHIP_TO_PARTY,NULL)
                   and NVL(MTL_GROUP,NULL) = NVL(REC1.MTL_GROUP,NULL)
                   and NVL(COST_ELEMENT,NULL) = NVL(REC1.COST_ELEMENT,NULL)
                   and NVL(MTL_TYPE,NULL)     = NVL(REC1.MTL_TYPE,NULL)
                   and NVL(END_CUSTOMER_ID,NULL) = NVL(REC1.END_CUSTOMER_ID,NULL)
                   and NVL(PLANT_CODE,NULL)      = NVL(REC1.PLANT_CODE,NULL);
             Commit;
            ELSE
                UPDATE KPI_SAP001_COPA_TRX_TEMP SET  PDM_CUSTOMER1 = REC1.END_CUSTOMER_ID
                 where COMPANY_CODE = REC1.COMPANY_CODE
                   and PERIOD = REC1.PERIOD
                   and NVL(PART_NO,NULL) = NVL(REC1.PART_NO,NULL)
                   and PROFIT_CENTER = REC1.PROFIT_CENTER
                   and NVL(CUSTOMER_ID,NULL) = NVL(REC1.CUSTOMER_ID,NULL)
                   and NVL(SHIP_TO_PARTY,NULL) = NVL(REC1.SHIP_TO_PARTY,NULL)
                   and NVL(MTL_GROUP,NULL) = NVL(REC1.MTL_GROUP,NULL)
                   and NVL(COST_ELEMENT,NULL) = NVL(REC1.COST_ELEMENT,NULL)
                   and NVL(MTL_TYPE,NULL)     = NVL(REC1.MTL_TYPE,NULL)
                   and NVL(END_CUSTOMER_ID,NULL) = NVL(REC1.END_CUSTOMER_ID,NULL)
                   and NVL(PLANT_CODE,NULL)      = NVL(REC1.PLANT_CODE,NULL);
                Commit;
            END IF;
         ELSIF REC1.COST_ELEMENT = '0000510110' THEN
           IF REC1.END_CUSTOMER_ID IS NULL THEN
             UPDATE KPI_SAP001_COPA_TRX_TEMP SET END_CUSTOMER_ID = 'SMC',PDM_CUSTOMER1 = 'SMC' 
                 where COMPANY_CODE = REC1.COMPANY_CODE
                   and PERIOD = REC1.PERIOD
                   and NVL(PART_NO,NULL) = NVL(REC1.PART_NO,NULL)
                   and PROFIT_CENTER = REC1.PROFIT_CENTER
                   and NVL(CUSTOMER_ID,NULL) = NVL(REC1.CUSTOMER_ID,NULL)
                   and NVL(SHIP_TO_PARTY,NULL) = NVL(REC1.SHIP_TO_PARTY,NULL)
                   and NVL(MTL_GROUP,NULL) = NVL(REC1.MTL_GROUP,NULL)
                   and NVL(COST_ELEMENT,NULL) = NVL(REC1.COST_ELEMENT,NULL)
                   and NVL(MTL_TYPE,NULL)     = NVL(REC1.MTL_TYPE,NULL)
                   and NVL(END_CUSTOMER_ID,NULL) = NVL(REC1.END_CUSTOMER_ID,NULL)
                   and NVL(PLANT_CODE,NULL)      = NVL(REC1.PLANT_CODE,NULL);
             Commit;
            ELSE
                UPDATE KPI_SAP001_COPA_TRX_TEMP SET  PDM_CUSTOMER1 = REC1.END_CUSTOMER_ID
                 where COMPANY_CODE = REC1.COMPANY_CODE
                   and PERIOD = REC1.PERIOD
                   and NVL(PART_NO,NULL) = NVL(REC1.PART_NO,NULL)
                   and PROFIT_CENTER = REC1.PROFIT_CENTER
                   and NVL(CUSTOMER_ID,NULL) = NVL(REC1.CUSTOMER_ID,NULL)
                   and NVL(SHIP_TO_PARTY,NULL) = NVL(REC1.SHIP_TO_PARTY,NULL)
                   and NVL(MTL_GROUP,NULL) = NVL(REC1.MTL_GROUP,NULL)
                   and NVL(COST_ELEMENT,NULL) = NVL(REC1.COST_ELEMENT,NULL)
                   and NVL(MTL_TYPE,NULL)     = NVL(REC1.MTL_TYPE,NULL)
                   and NVL(END_CUSTOMER_ID,NULL) = NVL(REC1.END_CUSTOMER_ID,NULL)
                   and NVL(PLANT_CODE,NULL)      = NVL(REC1.PLANT_CODE,NULL);
                Commit;
           END IF;
          /** 510201 , 510301 , 510401 , 510501 等bu UPLOAD **/
         ELSIF REC1.COST_ELEMENT = '0000510201' THEN
           IF REC1.END_CUSTOMER_ID IS NOT NULL THEN
                UPDATE KPI_SAP001_COPA_TRX_TEMP SET  PDM_CUSTOMER1 = REC1.END_CUSTOMER_ID
                 where COMPANY_CODE = REC1.COMPANY_CODE
                   and PERIOD = REC1.PERIOD
                   and NVL(PART_NO,NULL) = NVL(REC1.PART_NO,NULL)
                   and PROFIT_CENTER = REC1.PROFIT_CENTER
                   and NVL(CUSTOMER_ID,NULL) = NVL(REC1.CUSTOMER_ID,NULL)
                   and NVL(SHIP_TO_PARTY,NULL) = NVL(REC1.SHIP_TO_PARTY,NULL)
                   and NVL(MTL_GROUP,NULL) = NVL(REC1.MTL_GROUP,NULL)
                   and NVL(COST_ELEMENT,NULL) = NVL(REC1.COST_ELEMENT,NULL)
                   and NVL(MTL_TYPE,NULL)     = NVL(REC1.MTL_TYPE,NULL)
                   and NVL(END_CUSTOMER_ID,NULL) = NVL(REC1.END_CUSTOMER_ID,NULL)
                   and NVL(PLANT_CODE,NULL)      = NVL(REC1.PLANT_CODE,NULL);
                Commit;
           END IF;
         ELSIF REC1.COST_ELEMENT = '0000510301' THEN
           IF REC1.END_CUSTOMER_ID IS NOT NULL THEN
                UPDATE KPI_SAP001_COPA_TRX_TEMP SET  PDM_CUSTOMER1 = REC1.END_CUSTOMER_ID
                 where COMPANY_CODE = REC1.COMPANY_CODE
                   and PERIOD = REC1.PERIOD
                   and NVL(PART_NO,NULL) = NVL(REC1.PART_NO,NULL)
                   and PROFIT_CENTER = REC1.PROFIT_CENTER
                   and NVL(CUSTOMER_ID,NULL) = NVL(REC1.CUSTOMER_ID,NULL)
                   and NVL(SHIP_TO_PARTY,NULL) = NVL(REC1.SHIP_TO_PARTY,NULL)
                   and NVL(MTL_GROUP,NULL) = NVL(REC1.MTL_GROUP,NULL)
                   and NVL(COST_ELEMENT,NULL) = NVL(REC1.COST_ELEMENT,NULL)
                   and NVL(MTL_TYPE,NULL)     = NVL(REC1.MTL_TYPE,NULL)
                   and NVL(END_CUSTOMER_ID,NULL) = NVL(REC1.END_CUSTOMER_ID,NULL)
                   and NVL(PLANT_CODE,NULL)      = NVL(REC1.PLANT_CODE,NULL);
                Commit;
           END IF;
         ELSIF REC1.COST_ELEMENT = '0000510401' THEN
           IF REC1.END_CUSTOMER_ID IS NOT NULL THEN
                UPDATE KPI_SAP001_COPA_TRX_TEMP SET  PDM_CUSTOMER1 = REC1.END_CUSTOMER_ID
                 where COMPANY_CODE = REC1.COMPANY_CODE
                   and PERIOD = REC1.PERIOD
                   and NVL(PART_NO,NULL) = NVL(REC1.PART_NO,NULL)
                   and PROFIT_CENTER = REC1.PROFIT_CENTER
                   and NVL(CUSTOMER_ID,NULL) = NVL(REC1.CUSTOMER_ID,NULL)
                   and NVL(SHIP_TO_PARTY,NULL) = NVL(REC1.SHIP_TO_PARTY,NULL)
                   and NVL(MTL_GROUP,NULL) = NVL(REC1.MTL_GROUP,NULL)
                   and NVL(COST_ELEMENT,NULL) = NVL(REC1.COST_ELEMENT,NULL)
                   and NVL(MTL_TYPE,NULL)     = NVL(REC1.MTL_TYPE,NULL)
                   and NVL(END_CUSTOMER_ID,NULL) = NVL(REC1.END_CUSTOMER_ID,NULL)
                   and NVL(PLANT_CODE,NULL)      = NVL(REC1.PLANT_CODE,NULL);
                Commit;
           END IF;
         ELSIF REC1.COST_ELEMENT = '0000510501' THEN
           IF REC1.END_CUSTOMER_ID IS NOT NULL THEN
                UPDATE KPI_SAP001_COPA_TRX_TEMP SET  PDM_CUSTOMER1 = REC1.END_CUSTOMER_ID
                 where COMPANY_CODE = REC1.COMPANY_CODE
                   and PERIOD = REC1.PERIOD
                   and NVL(PART_NO,NULL) = NVL(REC1.PART_NO,NULL)
                   and PROFIT_CENTER = REC1.PROFIT_CENTER
                   and NVL(CUSTOMER_ID,NULL) = NVL(REC1.CUSTOMER_ID,NULL)
                   and NVL(SHIP_TO_PARTY,NULL) = NVL(REC1.SHIP_TO_PARTY,NULL)
                   and NVL(MTL_GROUP,NULL) = NVL(REC1.MTL_GROUP,NULL)
                   and NVL(COST_ELEMENT,NULL) = NVL(REC1.COST_ELEMENT,NULL)
                   and NVL(MTL_TYPE,NULL)     = NVL(REC1.MTL_TYPE,NULL)
                   and NVL(END_CUSTOMER_ID,NULL) = NVL(REC1.END_CUSTOMER_ID,NULL)
                   and NVL(PLANT_CODE,NULL)      = NVL(REC1.PLANT_CODE,NULL);
                Commit;
           END IF;
           
           
         ELSIF REC1.COST_ELEMENT = '0000510901' THEN
           IF REC1.END_CUSTOMER_ID IS NULL THEN
             IF REC1.PART_NO IS NULL THEN
                 UPDATE KPI_SAP001_COPA_TRX_TEMP SET END_CUSTOMER_ID = 'Others',PDM_CUSTOMER1 = 'Others' 
                     where COMPANY_CODE = REC1.COMPANY_CODE
                       and PERIOD = REC1.PERIOD
                   and NVL(PART_NO,NULL) = NVL(REC1.PART_NO,NULL)
                   and PROFIT_CENTER = REC1.PROFIT_CENTER
                   and NVL(CUSTOMER_ID,NULL) = NVL(REC1.CUSTOMER_ID,NULL)
                   and NVL(SHIP_TO_PARTY,NULL) = NVL(REC1.SHIP_TO_PARTY,NULL)
                   and NVL(MTL_GROUP,NULL) = NVL(REC1.MTL_GROUP,NULL)
                   and NVL(COST_ELEMENT,NULL) = NVL(REC1.COST_ELEMENT,NULL)
                   and NVL(MTL_TYPE,NULL)     = NVL(REC1.MTL_TYPE,NULL)
                   and NVL(END_CUSTOMER_ID,NULL) = NVL(REC1.END_CUSTOMER_ID,NULL)
                   and NVL(PLANT_CODE,NULL)      = NVL(REC1.PLANT_CODE,NULL);
                 Commit;
             ELSE
                aEND_CUSTOMER_ID := null;
                aEND_CUSTOMER_ID := PNL2_GET_END_CUSTOMER_ID(REC1.COMPANY_CODE,REC1.PERIOD,REC1.PART_NO,REC1.PROFIT_CENTER,REC1.CUSTOMER_ID,REC1.SHIP_TO_PARTY,REC1.MTL_GROUP,REC1.PLANT_CODE);
                IF aEND_CUSTOMER_ID is null THEN
                   UPDATE KPI_SAP001_COPA_TRX_TEMP SET END_CUSTOMER_ID = 'Others',PDM_CUSTOMER1 = 'Others' 
                       where COMPANY_CODE = REC1.COMPANY_CODE
                         and PERIOD = REC1.PERIOD
                   and NVL(PART_NO,NULL) = NVL(REC1.PART_NO,NULL)
                   and PROFIT_CENTER = REC1.PROFIT_CENTER
                   and NVL(CUSTOMER_ID,NULL) = NVL(REC1.CUSTOMER_ID,NULL)
                   and NVL(SHIP_TO_PARTY,NULL) = NVL(REC1.SHIP_TO_PARTY,NULL)
                   and NVL(MTL_GROUP,NULL) = NVL(REC1.MTL_GROUP,NULL)
                   and NVL(COST_ELEMENT,NULL) = NVL(REC1.COST_ELEMENT,NULL)
                   and NVL(MTL_TYPE,NULL)     = NVL(REC1.MTL_TYPE,NULL)
                   and NVL(END_CUSTOMER_ID,NULL) = NVL(REC1.END_CUSTOMER_ID,NULL)
                   and NVL(PLANT_CODE,NULL)      = NVL(REC1.PLANT_CODE,NULL);
                    Commit;
                 ELSE
                   UPDATE KPI_SAP001_COPA_TRX_TEMP SET END_CUSTOMER_ID = aEND_CUSTOMER_ID,PDM_CUSTOMER1 = aEND_CUSTOMER_ID 
                       where COMPANY_CODE = REC1.COMPANY_CODE
                         and PERIOD = REC1.PERIOD
                   and NVL(PART_NO,NULL) = NVL(REC1.PART_NO,NULL)
                   and PROFIT_CENTER = REC1.PROFIT_CENTER
                   and NVL(CUSTOMER_ID,NULL) = NVL(REC1.CUSTOMER_ID,NULL)
                   and NVL(SHIP_TO_PARTY,NULL) = NVL(REC1.SHIP_TO_PARTY,NULL)
                   and NVL(MTL_GROUP,NULL) = NVL(REC1.MTL_GROUP,NULL)
                   and NVL(COST_ELEMENT,NULL) = NVL(REC1.COST_ELEMENT,NULL)
                   and NVL(MTL_TYPE,NULL)     = NVL(REC1.MTL_TYPE,NULL)
                   and NVL(END_CUSTOMER_ID,NULL) = NVL(REC1.END_CUSTOMER_ID,NULL)
                   and NVL(PLANT_CODE,NULL)      = NVL(REC1.PLANT_CODE,NULL);
                    Commit;
                 END IF;
             END IF;
           ELSE
                UPDATE KPI_SAP001_COPA_TRX_TEMP SET  PDM_CUSTOMER1 = REC1.END_CUSTOMER_ID
                 where COMPANY_CODE = REC1.COMPANY_CODE
                   and PERIOD = REC1.PERIOD
                   and NVL(PART_NO,NULL) = NVL(REC1.PART_NO,NULL)
                   and PROFIT_CENTER = REC1.PROFIT_CENTER
                   and NVL(CUSTOMER_ID,NULL) = NVL(REC1.CUSTOMER_ID,NULL)
                   and NVL(SHIP_TO_PARTY,NULL) = NVL(REC1.SHIP_TO_PARTY,NULL)
                   and NVL(MTL_GROUP,NULL) = NVL(REC1.MTL_GROUP,NULL)
                   and NVL(COST_ELEMENT,NULL) = NVL(REC1.COST_ELEMENT,NULL)
                   and NVL(MTL_TYPE,NULL)     = NVL(REC1.MTL_TYPE,NULL)
                   and NVL(END_CUSTOMER_ID,NULL) = NVL(REC1.END_CUSTOMER_ID,NULL)
                   and NVL(PLANT_CODE,NULL)      = NVL(REC1.PLANT_CODE,NULL);
                Commit;
           END IF;
         ELSIF REC1.COST_ELEMENT = '0000510902' THEN
           IF REC1.END_CUSTOMER_ID IS NULL THEN
             IF REC1.PART_NO IS NULL THEN
                 UPDATE KPI_SAP001_COPA_TRX_TEMP SET END_CUSTOMER_ID = 'Others',PDM_CUSTOMER1 = 'Others' 
                     where COMPANY_CODE = REC1.COMPANY_CODE
                       and PERIOD = REC1.PERIOD
                   and NVL(PART_NO,NULL) = NVL(REC1.PART_NO,NULL)
                   and PROFIT_CENTER = REC1.PROFIT_CENTER
                   and NVL(CUSTOMER_ID,NULL) = NVL(REC1.CUSTOMER_ID,NULL)
                   and NVL(SHIP_TO_PARTY,NULL) = NVL(REC1.SHIP_TO_PARTY,NULL)
                   and NVL(MTL_GROUP,NULL) = NVL(REC1.MTL_GROUP,NULL)
                   and NVL(COST_ELEMENT,NULL) = NVL(REC1.COST_ELEMENT,NULL)
                   and NVL(MTL_TYPE,NULL)     = NVL(REC1.MTL_TYPE,NULL)
                   and NVL(END_CUSTOMER_ID,NULL) = NVL(REC1.END_CUSTOMER_ID,NULL)
                   and NVL(PLANT_CODE,NULL)      = NVL(REC1.PLANT_CODE,NULL);
                 Commit;
             ELSE
                IF REC1.MTL_TYPE = 'RAW' THEN
                    UPDATE KPI_SAP001_COPA_TRX_TEMP SET END_CUSTOMER_ID = 'Others',PDM_CUSTOMER1 = 'Others' 
                       where COMPANY_CODE = REC1.COMPANY_CODE
                         and PERIOD = REC1.PERIOD
                   and NVL(PART_NO,NULL) = NVL(REC1.PART_NO,NULL)
                   and PROFIT_CENTER = REC1.PROFIT_CENTER
                   and NVL(CUSTOMER_ID,NULL) = NVL(REC1.CUSTOMER_ID,NULL)
                   and NVL(SHIP_TO_PARTY,NULL) = NVL(REC1.SHIP_TO_PARTY,NULL)
                   and NVL(MTL_GROUP,NULL) = NVL(REC1.MTL_GROUP,NULL)
                   and NVL(COST_ELEMENT,NULL) = NVL(REC1.COST_ELEMENT,NULL)
                   and NVL(MTL_TYPE,NULL)     = NVL(REC1.MTL_TYPE,NULL)
                   and NVL(END_CUSTOMER_ID,NULL) = NVL(REC1.END_CUSTOMER_ID,NULL)
                   and NVL(PLANT_CODE,NULL)      = NVL(REC1.PLANT_CODE,NULL);
                ELSE
                  aEND_CUSTOMER_ID := null;
                  aEND_CUSTOMER_ID := PNL2_GET_END_CUSTOMER_ID(REC1.COMPANY_CODE,REC1.PERIOD,REC1.PART_NO,REC1.PROFIT_CENTER,REC1.CUSTOMER_ID,REC1.SHIP_TO_PARTY,REC1.MTL_GROUP,REC1.PLANT_CODE);
                  IF aEND_CUSTOMER_ID is null THEN
                    UPDATE KPI_SAP001_COPA_TRX_TEMP SET END_CUSTOMER_ID = 'Others',PDM_CUSTOMER1 = 'Others' 
                       where COMPANY_CODE = REC1.COMPANY_CODE
                         and PERIOD = REC1.PERIOD
                   and NVL(PART_NO,NULL) = NVL(REC1.PART_NO,NULL)
                   and PROFIT_CENTER = REC1.PROFIT_CENTER
                   and NVL(CUSTOMER_ID,NULL) = NVL(REC1.CUSTOMER_ID,NULL)
                   and NVL(SHIP_TO_PARTY,NULL) = NVL(REC1.SHIP_TO_PARTY,NULL)
                   and NVL(MTL_GROUP,NULL) = NVL(REC1.MTL_GROUP,NULL)
                   and NVL(COST_ELEMENT,NULL) = NVL(REC1.COST_ELEMENT,NULL)
                   and NVL(MTL_TYPE,NULL)     = NVL(REC1.MTL_TYPE,NULL)
                   and NVL(END_CUSTOMER_ID,NULL) = NVL(REC1.END_CUSTOMER_ID,NULL)
                   and NVL(PLANT_CODE,NULL)      = NVL(REC1.PLANT_CODE,NULL);
                    Commit;
                  ELSE
                    UPDATE KPI_SAP001_COPA_TRX_TEMP SET END_CUSTOMER_ID = aEND_CUSTOMER_ID,PDM_CUSTOMER1 = aEND_CUSTOMER_ID 
                       where COMPANY_CODE = REC1.COMPANY_CODE
                         and PERIOD = REC1.PERIOD
                   and NVL(PART_NO,NULL) = NVL(REC1.PART_NO,NULL)
                   and PROFIT_CENTER = REC1.PROFIT_CENTER
                   and NVL(CUSTOMER_ID,NULL) = NVL(REC1.CUSTOMER_ID,NULL)
                   and NVL(SHIP_TO_PARTY,NULL) = NVL(REC1.SHIP_TO_PARTY,NULL)
                   and NVL(MTL_GROUP,NULL) = NVL(REC1.MTL_GROUP,NULL)
                   and NVL(COST_ELEMENT,NULL) = NVL(REC1.COST_ELEMENT,NULL)
                   and NVL(MTL_TYPE,NULL)     = NVL(REC1.MTL_TYPE,NULL)
                   and NVL(END_CUSTOMER_ID,NULL) = NVL(REC1.END_CUSTOMER_ID,NULL)
                   and NVL(PLANT_CODE,NULL)      = NVL(REC1.PLANT_CODE,NULL);
                    Commit;
                  END IF;
                END IF;
             END IF;
           ELSE
                UPDATE KPI_SAP001_COPA_TRX_TEMP SET  PDM_CUSTOMER1 = REC1.END_CUSTOMER_ID
                 where COMPANY_CODE = REC1.COMPANY_CODE
                   and PERIOD = REC1.PERIOD
                   and NVL(PART_NO,NULL) = NVL(REC1.PART_NO,NULL)
                   and PROFIT_CENTER = REC1.PROFIT_CENTER
                   and NVL(CUSTOMER_ID,NULL) = NVL(REC1.CUSTOMER_ID,NULL)
                   and NVL(SHIP_TO_PARTY,NULL) = NVL(REC1.SHIP_TO_PARTY,NULL)
                   and NVL(MTL_GROUP,NULL) = NVL(REC1.MTL_GROUP,NULL)
                   and NVL(COST_ELEMENT,NULL) = NVL(REC1.COST_ELEMENT,NULL)
                   and NVL(MTL_TYPE,NULL)     = NVL(REC1.MTL_TYPE,NULL)
                   and NVL(END_CUSTOMER_ID,NULL) = NVL(REC1.END_CUSTOMER_ID,NULL)
                   and NVL(PLANT_CODE,NULL)      = NVL(REC1.PLANT_CODE,NULL);
                Commit;
           END IF;
           
           
         ELSIF REC1.COST_ELEMENT = '0000510903' THEN
           IF REC1.END_CUSTOMER_ID IS NULL THEN
             IF REC1.PART_NO IS NULL THEN
                 UPDATE KPI_SAP001_COPA_TRX_TEMP SET END_CUSTOMER_ID = 'Others',PDM_CUSTOMER1 = 'Others' 
                     where COMPANY_CODE = REC1.COMPANY_CODE
                       and PERIOD = REC1.PERIOD
                   and NVL(PART_NO,NULL) = NVL(REC1.PART_NO,NULL)
                   and PROFIT_CENTER = REC1.PROFIT_CENTER
                   and NVL(CUSTOMER_ID,NULL) = NVL(REC1.CUSTOMER_ID,NULL)
                   and NVL(SHIP_TO_PARTY,NULL) = NVL(REC1.SHIP_TO_PARTY,NULL)
                   and NVL(MTL_GROUP,NULL) = NVL(REC1.MTL_GROUP,NULL)
                   and NVL(COST_ELEMENT,NULL) = NVL(REC1.COST_ELEMENT,NULL)
                   and NVL(MTL_TYPE,NULL)     = NVL(REC1.MTL_TYPE,NULL)
                   and NVL(END_CUSTOMER_ID,NULL) = NVL(REC1.END_CUSTOMER_ID,NULL)
                   and NVL(PLANT_CODE,NULL)      = NVL(REC1.PLANT_CODE,NULL);
                 Commit;
             ELSE
                IF REC1.MTL_TYPE = 'RAW' THEN
                  aEND_CUSTOMER_ID := null;
                  aEND_CUSTOMER_ID := PNL2_GET_END_CUSTOMER_ID(REC1.COMPANY_CODE,REC1.PERIOD,REC1.PART_NO,REC1.PROFIT_CENTER,REC1.CUSTOMER_ID,REC1.SHIP_TO_PARTY,REC1.MTL_GROUP,REC1.PLANT_CODE);
                  IF aEND_CUSTOMER_ID is null THEN
                    UPDATE KPI_SAP001_COPA_TRX_TEMP SET END_CUSTOMER_ID = 'Others',PDM_CUSTOMER1 = 'Others' 
                       where COMPANY_CODE = REC1.COMPANY_CODE
                         and PERIOD = REC1.PERIOD
                   and NVL(PART_NO,NULL) = NVL(REC1.PART_NO,NULL)
                   and PROFIT_CENTER = REC1.PROFIT_CENTER
                   and NVL(CUSTOMER_ID,NULL) = NVL(REC1.CUSTOMER_ID,NULL)
                   and NVL(SHIP_TO_PARTY,NULL) = NVL(REC1.SHIP_TO_PARTY,NULL)
                   and NVL(MTL_GROUP,NULL) = NVL(REC1.MTL_GROUP,NULL)
                   and NVL(COST_ELEMENT,NULL) = NVL(REC1.COST_ELEMENT,NULL)
                   and NVL(MTL_TYPE,NULL)     = NVL(REC1.MTL_TYPE,NULL)
                   and NVL(END_CUSTOMER_ID,NULL) = NVL(REC1.END_CUSTOMER_ID,NULL)
                   and NVL(PLANT_CODE,NULL)      = NVL(REC1.PLANT_CODE,NULL);
                    Commit;
                  ELSE
                    UPDATE KPI_SAP001_COPA_TRX_TEMP SET END_CUSTOMER_ID = aEND_CUSTOMER_ID,PDM_CUSTOMER1 = aEND_CUSTOMER_ID 
                       where COMPANY_CODE = REC1.COMPANY_CODE
                         and PERIOD = REC1.PERIOD
                   and NVL(PART_NO,NULL) = NVL(REC1.PART_NO,NULL)
                   and PROFIT_CENTER = REC1.PROFIT_CENTER
                   and NVL(CUSTOMER_ID,NULL) = NVL(REC1.CUSTOMER_ID,NULL)
                   and NVL(SHIP_TO_PARTY,NULL) = NVL(REC1.SHIP_TO_PARTY,NULL)
                   and NVL(MTL_GROUP,NULL) = NVL(REC1.MTL_GROUP,NULL)
                   and NVL(COST_ELEMENT,NULL) = NVL(REC1.COST_ELEMENT,NULL)
                   and NVL(MTL_TYPE,NULL)     = NVL(REC1.MTL_TYPE,NULL)
                   and NVL(END_CUSTOMER_ID,NULL) = NVL(REC1.END_CUSTOMER_ID,NULL)
                   and NVL(PLANT_CODE,NULL)      = NVL(REC1.PLANT_CODE,NULL);
                    Commit;
                  END IF;
                ELSE
                    UPDATE KPI_SAP001_COPA_TRX_TEMP SET END_CUSTOMER_ID = 'Others',PDM_CUSTOMER1 = 'Others' 
                       where COMPANY_CODE = REC1.COMPANY_CODE
                         and PERIOD = REC1.PERIOD
                   and NVL(PART_NO,NULL) = NVL(REC1.PART_NO,NULL)
                   and PROFIT_CENTER = REC1.PROFIT_CENTER
                   and NVL(CUSTOMER_ID,NULL) = NVL(REC1.CUSTOMER_ID,NULL)
                   and NVL(SHIP_TO_PARTY,NULL) = NVL(REC1.SHIP_TO_PARTY,NULL)
                   and NVL(MTL_GROUP,NULL) = NVL(REC1.MTL_GROUP,NULL)
                   and NVL(COST_ELEMENT,NULL) = NVL(REC1.COST_ELEMENT,NULL)
                   and NVL(MTL_TYPE,NULL)     = NVL(REC1.MTL_TYPE,NULL)
                   and NVL(END_CUSTOMER_ID,NULL) = NVL(REC1.END_CUSTOMER_ID,NULL)
                   and NVL(PLANT_CODE,NULL)      = NVL(REC1.PLANT_CODE,NULL);

                END IF;
             END IF;
           ELSE
                UPDATE KPI_SAP001_COPA_TRX_TEMP SET  PDM_CUSTOMER1 = REC1.END_CUSTOMER_ID
                 where COMPANY_CODE = REC1.COMPANY_CODE
                   and PERIOD = REC1.PERIOD
                   and NVL(PART_NO,NULL) = NVL(REC1.PART_NO,NULL)
                   and PROFIT_CENTER = REC1.PROFIT_CENTER
                   and NVL(CUSTOMER_ID,NULL) = NVL(REC1.CUSTOMER_ID,NULL)
                   and NVL(SHIP_TO_PARTY,NULL) = NVL(REC1.SHIP_TO_PARTY,NULL)
                   and NVL(MTL_GROUP,NULL) = NVL(REC1.MTL_GROUP,NULL)
                   and NVL(COST_ELEMENT,NULL) = NVL(REC1.COST_ELEMENT,NULL)
                   and NVL(MTL_TYPE,NULL)     = NVL(REC1.MTL_TYPE,NULL)
                   and NVL(END_CUSTOMER_ID,NULL) = NVL(REC1.END_CUSTOMER_ID,NULL)
                   and NVL(PLANT_CODE,NULL)      = NVL(REC1.PLANT_CODE,NULL);
                Commit;
           END IF;

        ELSIF REC1.COST_ELEMENT = '0000510909' THEN
           IF REC1.END_CUSTOMER_ID IS NULL THEN
             IF REC1.PART_NO IS NULL THEN
                 UPDATE KPI_SAP001_COPA_TRX_TEMP SET END_CUSTOMER_ID = 'Others',PDM_CUSTOMER1 = 'Others' 
                     where COMPANY_CODE = REC1.COMPANY_CODE
                       and PERIOD = REC1.PERIOD
                   and NVL(PART_NO,NULL) = NVL(REC1.PART_NO,NULL)
                   and PROFIT_CENTER = REC1.PROFIT_CENTER
                   and NVL(CUSTOMER_ID,NULL) = NVL(REC1.CUSTOMER_ID,NULL)
                   and NVL(SHIP_TO_PARTY,NULL) = NVL(REC1.SHIP_TO_PARTY,NULL)
                   and NVL(MTL_GROUP,NULL) = NVL(REC1.MTL_GROUP,NULL)
                   and NVL(COST_ELEMENT,NULL) = NVL(REC1.COST_ELEMENT,NULL)
                   and NVL(MTL_TYPE,NULL)     = NVL(REC1.MTL_TYPE,NULL)
                   and NVL(END_CUSTOMER_ID,NULL) = NVL(REC1.END_CUSTOMER_ID,NULL)
                   and NVL(PLANT_CODE,NULL)      = NVL(REC1.PLANT_CODE,NULL);
                 Commit;
             ELSE
                IF REC1.PLANT_CODE = '1150' THEN
                  UPDATE KPI_SAP001_COPA_TRX_TEMP SET END_CUSTOMER_ID = 'SMC',PDM_CUSTOMER1 = 'SMC' 
                     where COMPANY_CODE = REC1.COMPANY_CODE
                       and PERIOD = REC1.PERIOD
                   and NVL(PART_NO,NULL) = NVL(REC1.PART_NO,NULL)
                   and PROFIT_CENTER = REC1.PROFIT_CENTER
                   and NVL(CUSTOMER_ID,NULL) = NVL(REC1.CUSTOMER_ID,NULL)
                   and NVL(SHIP_TO_PARTY,NULL) = NVL(REC1.SHIP_TO_PARTY,NULL)
                   and NVL(MTL_GROUP,NULL) = NVL(REC1.MTL_GROUP,NULL)
                   and NVL(COST_ELEMENT,NULL) = NVL(REC1.COST_ELEMENT,NULL)
                   and NVL(MTL_TYPE,NULL)     = NVL(REC1.MTL_TYPE,NULL)
                   and NVL(END_CUSTOMER_ID,NULL) = NVL(REC1.END_CUSTOMER_ID,NULL)
                   and NVL(PLANT_CODE,NULL)      = NVL(REC1.PLANT_CODE,NULL);
                  Commit;
                ELSE
                  IF REC1.MTL_TYPE = 'FG' THEN
                    aEND_CUSTOMER_ID := null;
                    aEND_CUSTOMER_ID := PNL2_GET_END_CUSTOMER_ID(REC1.COMPANY_CODE,REC1.PERIOD,REC1.PART_NO,REC1.PROFIT_CENTER,REC1.CUSTOMER_ID,REC1.SHIP_TO_PARTY,REC1.MTL_GROUP,REC1.PLANT_CODE);
                    IF aEND_CUSTOMER_ID is null THEN
                      UPDATE KPI_SAP001_COPA_TRX_TEMP SET END_CUSTOMER_ID = 'Others',PDM_CUSTOMER1 = 'Others' 
                       where COMPANY_CODE = REC1.COMPANY_CODE
                         and PERIOD = REC1.PERIOD
                   and NVL(PART_NO,NULL) = NVL(REC1.PART_NO,NULL)
                   and PROFIT_CENTER = REC1.PROFIT_CENTER
                   and NVL(CUSTOMER_ID,NULL) = NVL(REC1.CUSTOMER_ID,NULL)
                   and NVL(SHIP_TO_PARTY,NULL) = NVL(REC1.SHIP_TO_PARTY,NULL)
                   and NVL(MTL_GROUP,NULL) = NVL(REC1.MTL_GROUP,NULL)
                   and NVL(COST_ELEMENT,NULL) = NVL(REC1.COST_ELEMENT,NULL)
                   and NVL(MTL_TYPE,NULL)     = NVL(REC1.MTL_TYPE,NULL)
                   and NVL(END_CUSTOMER_ID,NULL) = NVL(REC1.END_CUSTOMER_ID,NULL)
                   and NVL(PLANT_CODE,NULL)      = NVL(REC1.PLANT_CODE,NULL);
                      Commit;
                    ELSE
                      UPDATE KPI_SAP001_COPA_TRX_TEMP SET END_CUSTOMER_ID = aEND_CUSTOMER_ID,PDM_CUSTOMER1 = aEND_CUSTOMER_ID 
                       where COMPANY_CODE = REC1.COMPANY_CODE
                         and PERIOD = REC1.PERIOD
                   and NVL(PART_NO,NULL) = NVL(REC1.PART_NO,NULL)
                   and PROFIT_CENTER = REC1.PROFIT_CENTER
                   and NVL(CUSTOMER_ID,NULL) = NVL(REC1.CUSTOMER_ID,NULL)
                   and NVL(SHIP_TO_PARTY,NULL) = NVL(REC1.SHIP_TO_PARTY,NULL)
                   and NVL(MTL_GROUP,NULL) = NVL(REC1.MTL_GROUP,NULL)
                   and NVL(COST_ELEMENT,NULL) = NVL(REC1.COST_ELEMENT,NULL)
                   and NVL(MTL_TYPE,NULL)     = NVL(REC1.MTL_TYPE,NULL)
                   and NVL(END_CUSTOMER_ID,NULL) = NVL(REC1.END_CUSTOMER_ID,NULL)
                   and NVL(PLANT_CODE,NULL)      = NVL(REC1.PLANT_CODE,NULL);
                      Commit;
                    END IF;
                  ELSE
                    UPDATE KPI_SAP001_COPA_TRX_TEMP SET END_CUSTOMER_ID = 'Others',PDM_CUSTOMER1 = 'Others' 
                       where COMPANY_CODE = REC1.COMPANY_CODE
                         and PERIOD = REC1.PERIOD
                   and NVL(PART_NO,NULL) = NVL(REC1.PART_NO,NULL)
                   and PROFIT_CENTER = REC1.PROFIT_CENTER
                   and NVL(CUSTOMER_ID,NULL) = NVL(REC1.CUSTOMER_ID,NULL)
                   and NVL(SHIP_TO_PARTY,NULL) = NVL(REC1.SHIP_TO_PARTY,NULL)
                   and NVL(MTL_GROUP,NULL) = NVL(REC1.MTL_GROUP,NULL)
                   and NVL(COST_ELEMENT,NULL) = NVL(REC1.COST_ELEMENT,NULL)
                   and NVL(MTL_TYPE,NULL)     = NVL(REC1.MTL_TYPE,NULL)
                   and NVL(END_CUSTOMER_ID,NULL) = NVL(REC1.END_CUSTOMER_ID,NULL)
                   and NVL(PLANT_CODE,NULL)      = NVL(REC1.PLANT_CODE,NULL);

                  END IF;
                END IF;
             END IF;
           ELSE
                UPDATE KPI_SAP001_COPA_TRX_TEMP SET  PDM_CUSTOMER1 = REC1.END_CUSTOMER_ID
                 where COMPANY_CODE = REC1.COMPANY_CODE
                   and PERIOD = REC1.PERIOD
                   and NVL(PART_NO,NULL) = NVL(REC1.PART_NO,NULL)
                   and PROFIT_CENTER = REC1.PROFIT_CENTER
                   and NVL(CUSTOMER_ID,NULL) = NVL(REC1.CUSTOMER_ID,NULL)
                   and NVL(SHIP_TO_PARTY,NULL) = NVL(REC1.SHIP_TO_PARTY,NULL)
                   and NVL(MTL_GROUP,NULL) = NVL(REC1.MTL_GROUP,NULL)
                   and NVL(COST_ELEMENT,NULL) = NVL(REC1.COST_ELEMENT,NULL)
                   and NVL(MTL_TYPE,NULL)     = NVL(REC1.MTL_TYPE,NULL)
                   and NVL(END_CUSTOMER_ID,NULL) = NVL(REC1.END_CUSTOMER_ID,NULL)
                   and NVL(PLANT_CODE,NULL)      = NVL(REC1.PLANT_CODE,NULL);
                Commit;
           END IF; 
           
        ELSIF REC1.COST_ELEMENT = '0000510999' THEN
           IF REC1.END_CUSTOMER_ID IS NULL THEN
             IF REC1.PART_NO IS NULL THEN
                 UPDATE KPI_SAP001_COPA_TRX_TEMP SET END_CUSTOMER_ID = 'Others',PDM_CUSTOMER1 = 'Others' 
                     where COMPANY_CODE = REC1.COMPANY_CODE
                       and PERIOD = REC1.PERIOD
                   and NVL(PART_NO,NULL) = NVL(REC1.PART_NO,NULL)
                   and PROFIT_CENTER = REC1.PROFIT_CENTER
                   and NVL(CUSTOMER_ID,NULL) = NVL(REC1.CUSTOMER_ID,NULL)
                   and NVL(SHIP_TO_PARTY,NULL) = NVL(REC1.SHIP_TO_PARTY,NULL)
                   and NVL(MTL_GROUP,NULL) = NVL(REC1.MTL_GROUP,NULL)
                   and NVL(COST_ELEMENT,NULL) = NVL(REC1.COST_ELEMENT,NULL)
                   and NVL(MTL_TYPE,NULL)     = NVL(REC1.MTL_TYPE,NULL)
                   and NVL(END_CUSTOMER_ID,NULL) = NVL(REC1.END_CUSTOMER_ID,NULL)
                   and NVL(PLANT_CODE,NULL)      = NVL(REC1.PLANT_CODE,NULL);
                 Commit;
             ELSE
                  IF REC1.MTL_TYPE = 'FG' THEN
                    aEND_CUSTOMER_ID := null;
                    aEND_CUSTOMER_ID := PNL2_GET_END_CUSTOMER_ID(REC1.COMPANY_CODE,REC1.PERIOD,REC1.PART_NO,REC1.PROFIT_CENTER,REC1.CUSTOMER_ID,REC1.SHIP_TO_PARTY,REC1.MTL_GROUP,REC1.PLANT_CODE);
                    IF aEND_CUSTOMER_ID is null THEN
                      UPDATE KPI_SAP001_COPA_TRX_TEMP SET END_CUSTOMER_ID = 'Others',PDM_CUSTOMER1 = 'Others' 
                       where COMPANY_CODE = REC1.COMPANY_CODE
                         and PERIOD = REC1.PERIOD
                   and NVL(PART_NO,NULL) = NVL(REC1.PART_NO,NULL)
                   and PROFIT_CENTER = REC1.PROFIT_CENTER
                   and NVL(CUSTOMER_ID,NULL) = NVL(REC1.CUSTOMER_ID,NULL)
                   and NVL(SHIP_TO_PARTY,NULL) = NVL(REC1.SHIP_TO_PARTY,NULL)
                   and NVL(MTL_GROUP,NULL) = NVL(REC1.MTL_GROUP,NULL)
                   and NVL(COST_ELEMENT,NULL) = NVL(REC1.COST_ELEMENT,NULL)
                   and NVL(MTL_TYPE,NULL)     = NVL(REC1.MTL_TYPE,NULL)
                   and NVL(END_CUSTOMER_ID,NULL) = NVL(REC1.END_CUSTOMER_ID,NULL)
                   and NVL(PLANT_CODE,NULL)      = NVL(REC1.PLANT_CODE,NULL);
                      Commit;
                    ELSE
                      UPDATE KPI_SAP001_COPA_TRX_TEMP SET END_CUSTOMER_ID = aEND_CUSTOMER_ID,PDM_CUSTOMER1 = aEND_CUSTOMER_ID 
                       where COMPANY_CODE = REC1.COMPANY_CODE
                         and PERIOD = REC1.PERIOD
                   and NVL(PART_NO,NULL) = NVL(REC1.PART_NO,NULL)
                   and PROFIT_CENTER = REC1.PROFIT_CENTER
                   and NVL(CUSTOMER_ID,NULL) = NVL(REC1.CUSTOMER_ID,NULL)
                   and NVL(SHIP_TO_PARTY,NULL) = NVL(REC1.SHIP_TO_PARTY,NULL)
                   and NVL(MTL_GROUP,NULL) = NVL(REC1.MTL_GROUP,NULL)
                   and NVL(COST_ELEMENT,NULL) = NVL(REC1.COST_ELEMENT,NULL)
                   and NVL(MTL_TYPE,NULL)     = NVL(REC1.MTL_TYPE,NULL)
                   and NVL(END_CUSTOMER_ID,NULL) = NVL(REC1.END_CUSTOMER_ID,NULL)
                   and NVL(PLANT_CODE,NULL)      = NVL(REC1.PLANT_CODE,NULL);
                      Commit;
                    END IF;
                  ELSE
                    UPDATE KPI_SAP001_COPA_TRX_TEMP SET END_CUSTOMER_ID = 'Others',PDM_CUSTOMER1 = 'Others' 
                       where COMPANY_CODE = REC1.COMPANY_CODE
                         and PERIOD = REC1.PERIOD
                   and NVL(PART_NO,NULL) = NVL(REC1.PART_NO,NULL)
                   and PROFIT_CENTER = REC1.PROFIT_CENTER
                   and NVL(CUSTOMER_ID,NULL) = NVL(REC1.CUSTOMER_ID,NULL)
                   and NVL(SHIP_TO_PARTY,NULL) = NVL(REC1.SHIP_TO_PARTY,NULL)
                   and NVL(MTL_GROUP,NULL) = NVL(REC1.MTL_GROUP,NULL)
                   and NVL(COST_ELEMENT,NULL) = NVL(REC1.COST_ELEMENT,NULL)
                   and NVL(MTL_TYPE,NULL)     = NVL(REC1.MTL_TYPE,NULL)
                   and NVL(END_CUSTOMER_ID,NULL) = NVL(REC1.END_CUSTOMER_ID,NULL)
                   and NVL(PLANT_CODE,NULL)      = NVL(REC1.PLANT_CODE,NULL);

                  END IF;
             END IF;
           ELSE
                UPDATE KPI_SAP001_COPA_TRX_TEMP SET  PDM_CUSTOMER1 = REC1.END_CUSTOMER_ID
                 where COMPANY_CODE = REC1.COMPANY_CODE
                   and PERIOD = REC1.PERIOD
                   and NVL(PART_NO,NULL) = NVL(REC1.PART_NO,NULL)
                   and PROFIT_CENTER = REC1.PROFIT_CENTER
                   and NVL(CUSTOMER_ID,NULL) = NVL(REC1.CUSTOMER_ID,NULL)
                   and NVL(SHIP_TO_PARTY,NULL) = NVL(REC1.SHIP_TO_PARTY,NULL)
                   and NVL(MTL_GROUP,NULL) = NVL(REC1.MTL_GROUP,NULL)
                   and NVL(COST_ELEMENT,NULL) = NVL(REC1.COST_ELEMENT,NULL)
                   and NVL(MTL_TYPE,NULL)     = NVL(REC1.MTL_TYPE,NULL)
                   and NVL(END_CUSTOMER_ID,NULL) = NVL(REC1.END_CUSTOMER_ID,NULL)
                   and NVL(PLANT_CODE,NULL)      = NVL(REC1.PLANT_CODE,NULL);
                Commit;
           END IF;    
         END IF;
    END LOOP;
END USI11731_CUSTOMER;
/

