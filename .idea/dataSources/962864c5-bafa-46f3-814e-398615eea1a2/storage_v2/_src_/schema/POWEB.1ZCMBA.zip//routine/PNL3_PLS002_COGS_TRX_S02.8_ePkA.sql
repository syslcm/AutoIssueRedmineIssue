create PROCEDURE       pnl3_pls002_cogs_trx_s02 (
   --inCOMPANY       in VARCHAR2,
   inperiod          IN   VARCHAR2,
   inprofit_center   IN   VARCHAR2,
   inamt             IN   NUMBER,
   inglaccount       IN   VARCHAR
--2008/9/17 Create to Process get Amount in Local/USD/TWD
--2009/6/16 修改邏輯,原本只有32分SITE,現在是全部分SITE,但像22這種特殊的在2300只有成本的要額外處理
)
AUTHID DEFINER
IS
--2008/11/7 有發現  SUM(NET_REVENUE) <> 0 OR SUM(NET_COGS)  <> 0 條件成立但dm/dl/oh卻有值的戕況,因此不加入此條件
-- 在INSERT進資料庫時再排除金額=0的資料
   a_rate            NUMBER (20, 10);
   a_trate           NUMBER (20, 10);
   --a_COUNTER       integer;
   --i_COUNTER       integer;
   a_amount          pnl3_trx001_copa.amt_twd%TYPE;
   a_endcustomer     pnl3_trx001_copa.end_customer_id%TYPE;
   a_net_revenue     pnl3_trx001_copa.amt_twd%TYPE;
   a_revenue_local   pnl3_trx001_copa.amt_twd%TYPE;
   a_revenue_twd     pnl3_trx001_copa.amt_twd%TYPE;
   a_revenue_usd     pnl3_trx001_copa.amt_twd%TYPE;
   a_cogs_dm_local   pnl3_trx001_copa.amt_twd%TYPE;
   a_cogs_dm_twd     pnl3_trx001_copa.amt_twd%TYPE;
   a_cogs_dm_usd     pnl3_trx001_copa.amt_twd%TYPE;
   a_cogs_dl_local   pnl3_trx001_copa.amt_twd%TYPE;
   a_cogs_dl_twd     pnl3_trx001_copa.amt_twd%TYPE;
   a_cogs_dl_usd     pnl3_trx001_copa.amt_twd%TYPE;
   a_cogs_oh_local   pnl3_trx001_copa.amt_twd%TYPE;
   a_cogs_oh_twd     pnl3_trx001_copa.amt_twd%TYPE;
   a_cogs_oh_usd     pnl3_trx001_copa.amt_twd%TYPE;
BEGIN
   a_rate := 0;

   IF inamt <> 0
   THEN                                             --有營收,沒有營收早已處理
      a_trate := 1;

      --2008/11/27  Profit center 32有發生狀況為CA是OK的,但成本都發生在MX,如果不拆SITE,則營收佔大多數的CA會分到MX的COGS
      --但大部份都是有Revenue的,所以不能只控32,而是要檢查成本或revenue的邏輯,先做有revenue的site,再做沒有revenue卻有COGS的site
         FOR rec1 IN (SELECT   company_code, end_customer_id,
                               SUM (amt_twd) amt_twd
                          FROM pnl3_trx001_copa
                         WHERE profit_center = inprofit_center
                           AND period = inperiod
                           AND area1 = '1'
                           AND area2 = '1'
                           AND area3 = '0'
                           AND amt_twd <> 0
                      --AND SOURCE <> 'UPL001'
                      GROUP BY company_code, end_customer_id
                      ORDER BY amt_twd DESC)
         LOOP
            a_amount := 0;

            BEGIN
               SELECT SUM (amt_twd)
                 INTO a_amount
                 FROM pnl3_trx001_copa
                WHERE profit_center = inprofit_center
                  AND period = inperiod
                  AND company_code = rec1.company_code
                  AND area1 = '1'
                  AND area2 = '1'
                  AND area3 = '0'
                  AND amt_twd <> 0;
            EXCEPTION
               WHEN OTHERS
               THEN
                  a_amount := 0;
            END;

            IF a_amount = 0
            THEN
               a_rate := 0;
            ELSE
               a_rate := rec1.amt_twd / a_amount;
            END IF;

            a_trate := a_trate - a_rate;
            a_revenue_local := 0;
            a_revenue_twd := 0;
            a_revenue_usd := 0;
            a_cogs_dm_local := 0;
            a_cogs_dm_twd := 0;
            a_cogs_dm_usd := 0;
            a_cogs_dl_local := 0;
            a_cogs_dl_twd := 0;
            a_cogs_dl_usd := 0;
            a_cogs_oh_local := 0;
            a_cogs_oh_twd := 0;
            a_cogs_oh_usd := 0;

            FOR rec2 IN (SELECT *
                           FROM pnl3_trx002_glaccount_t
                          WHERE period = inperiod
                            AND profit_center = inprofit_center
                            AND company_code = rec1.company_code
                            AND end_customer_id IS NULL
                            AND cost_element = inglaccount)
            LOOP
               --HAVING ( SUM(NET_REVENUE) <> 0 OR SUM(NET_COGS)  <> 0 )
               INSERT INTO pnl3_trx002_glaccount
                           (company_code, period, profit_center,
                            cost_element, bill_to_party,
                            ship_to_party, mtl_group,
                            part_no, plant_code,
                            end_customer_id, r_kind, area1,
                            area2, mtl_type, area3,
                            amt_local,
                            amt_twd,
                            amt_usd, customer_revenue,
                            pc_revenue, rate, create_date
                           )
                    VALUES (rec2.company_code, inperiod, inprofit_center,
                            inglaccount, rec2.bill_to_party,
                            rec2.ship_to_party, rec2.mtl_group,
                            rec2.part_no, rec2.plant_code,
                            rec1.end_customer_id, rec2.r_kind, rec2.area1,
                            rec2.area2, rec2.mtl_type, rec2.area3,
                            ROUND (rec2.amt_local * a_rate, 5),
                            ROUND (rec2.amt_twd * a_rate, 5),
                            ROUND (rec2.amt_usd * a_rate, 5), rec1.amt_twd,
                            inamt, a_rate, SYSDATE
                           );

               COMMIT;
            END LOOP;
         END LOOP;
         
         --不能用pnl3_trx001_copa,因為GLACCOUNT的資料不在裡面會誤判
         FOR rec99 IN (SELECT   company_code, nvl(SUM (net_cogs_twd),0) net_cogs_twd
                         FROM kpi_sap001_copa_trx
                        WHERE period = inperiod
                          AND profit_center = inprofit_center
                          AND net_cogs_twd <> 0
                          AND related_party <> 'Y'
                          AND    cost_element  IN
                             ( '0000510110', '0000510101',
                               '0000510103', '0000510104', '0000510107',
                               '0000510901', '0000510902', '0000510903', '0000510909',
                               '0000510999')
                          AND ( VV006 = 0 AND VV007 = 0  AND VV014 = 0 AND VV015 = 0 AND VV016 = 0 AND VV017 = 0 AND VV018 = 0 AND VV019 = 0 )
                          group by company_code)
         
         /*SELECT   company_code, SUM (amt_twd) amt_twd
                          FROM pnl3_trx001_copa
                         WHERE profit_center = inprofit_center
                           AND period = inperiod
                           AND area1 = '2'
                           AND amt_twd <> 0
                      --AND SOURCE <> 'UPL001'
                      GROUP BY company_code
                      ORDER BY amt_twd DESC)*/
         LOOP
            a_amount := 0;

            BEGIN
               SELECT nvl(SUM (amt_twd),0)
                 INTO a_amount
                 FROM pnl3_trx001_copa
                WHERE profit_center = inprofit_center
                  AND period = inperiod
                  AND company_code = rec99.company_code
                  AND area1 = '1'
                  AND area2 = '1'
                  AND area3 = '0'
                  AND amt_twd <> 0;
            EXCEPTION
               WHEN OTHERS
               THEN
                  a_amount := 0;
            END;

            --表示有成本但卻沒有營收
            IF a_amount = 0
            THEN
               FOR rec1 IN (SELECT   end_customer_id, SUM (amt_twd) amt_twd
                                FROM pnl3_trx001_copa
                               WHERE profit_center = inprofit_center
                                 AND period = inperiod
                                 --AND COMPANY_CODE = REC99.COMPANY_CODE
                                 AND area1 = '1'
                                 AND area2 = '1'
                                 AND area3 = '0'
                                 AND amt_twd <> 0
                            --AND SOURCE <> 'UPL001'
                            GROUP BY end_customer_id
                            ORDER BY amt_twd DESC)
               LOOP
                  a_rate := rec1.amt_twd / inamt;
                  a_trate := a_trate - a_rate;
                  a_revenue_local := 0;
                  a_revenue_twd := 0;
                  a_revenue_usd := 0;
                  a_cogs_dm_local := 0;
                  a_cogs_dm_twd := 0;
                  a_cogs_dm_usd := 0;
                  a_cogs_dl_local := 0;
                  a_cogs_dl_twd := 0;
                  a_cogs_dl_usd := 0;
                  a_cogs_oh_local := 0;
                  a_cogs_oh_twd := 0;
                  a_cogs_oh_usd := 0;

                  FOR rec2 IN (SELECT *
                                 FROM pnl3_trx002_glaccount_t
                                WHERE period = inperiod
                                  AND profit_center = inprofit_center
                                  AND COMPANY_CODE = REC99.COMPANY_CODE
                                  AND end_customer_id IS NULL
                                  AND cost_element = inglaccount)
                  LOOP
                     --HAVING ( SUM(NET_REVENUE) <> 0 OR SUM(NET_COGS)  <> 0 )
                     INSERT INTO pnl3_trx002_glaccount
                                 (company_code, period,
                                  profit_center, cost_element,
                                  bill_to_party, ship_to_party,
                                  mtl_group, part_no,
                                  plant_code, end_customer_id,
                                  r_kind, area1, area2,
                                  mtl_type, area3,
                                  amt_local,
                                  amt_twd,
                                  amt_usd,
                                  customer_revenue, pc_revenue, rate,
                                  create_date,SOURCE
                                 )
                          VALUES (rec2.company_code, inperiod,
                                  inprofit_center, inglaccount,
                                  rec2.bill_to_party, rec2.ship_to_party,
                                  rec2.mtl_group, rec2.part_no,
                                  rec2.plant_code, rec1.end_customer_id,
                                  rec2.r_kind, rec2.area1, rec2.area2,
                                  rec2.mtl_type, rec2.area3,
                                  ROUND (rec2.amt_local * a_rate, 5),
                                  ROUND (rec2.amt_twd * a_rate, 5),
                                  ROUND (rec2.amt_usd * a_rate, 5),
                                  rec1.amt_twd, inamt, a_rate,
                                  SYSDATE,'REV=0'
                                 );

                     COMMIT;
                  END LOOP;
               END LOOP;
            END IF;
         END LOOP;


      FOR rec2 IN (SELECT *
                     FROM pnl3_trx002_glaccount_t
                    WHERE period = inperiod
                      AND profit_center = inprofit_center
                      AND end_customer_id IS NOT NULL
                      AND cost_element = inglaccount)
      LOOP
         --HAVING ( SUM(NET_REVENUE) <> 0 OR SUM(NET_COGS)  <> 0 )
         INSERT INTO pnl3_trx002_glaccount
                     (company_code, period, profit_center,
                      cost_element, bill_to_party, ship_to_party,
                      mtl_group, part_no, plant_code,
                      end_customer_id, r_kind, area1,
                      area2, mtl_type, area3, amt_local,
                      amt_twd, amt_usd, customer_revenue, pc_revenue, rate,
                      create_date
                     )
              VALUES (rec2.company_code, inperiod, inprofit_center,
                      inglaccount, rec2.bill_to_party, rec2.ship_to_party,
                      rec2.mtl_group, rec2.part_no, rec2.plant_code,
                      rec2.end_customer_id, rec2.r_kind, rec2.area1,
                      rec2.area2, rec2.mtl_type, rec2.area3, rec2.amt_local,
                      rec2.amt_twd, rec2.amt_usd, 0, inamt, 1,
                      SYSDATE
                     );

         COMMIT;
      END LOOP;
   END IF;
END pnl3_pls002_cogs_trx_s02;
/

