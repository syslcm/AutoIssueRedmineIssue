create PACKAGE BODY         "SQLSERVER_UTILITIES" AS
FUNCTION cnv_to_timestamp(datetime_expr VARCHAR2) 
RETURN TIMESTAMP
IS
    temp_val NUMBER;
    temp_exp VARCHAR2(20);
    format_str VARCHAR2(20) := NULL;
 BEGIN
    temp_exp := TRIM(datetime_expr);
/*        
    IF REGEXP_INSTR(temp_exp, '^[[:digit:]]{6,8}$') = 1 THEN -- unseparated string format
       IF LENGTH(temp_exp) = 6 THEN
          format_str := 'YYMMDD';
       ELSE
          format_str := 'YYYYMMDD';
       END IF;
    ELSIF REGEXP_INSTR(temp_exp, '[-/\.]') = 0 THEN --  alphanumeric date format
       IF REGEXP_INSTR(temp_exp, 
             '^([[:alpha:]]+)[[:space:]]+([[:digit:]]{1,2})?,?[[:space:]]+([[:digit:]]{2,4})$') = 1 THEN 
          temp_exp := REGEXP_REPLACE(temp_exp, 
                    '^([[:alpha:]]+)[[:space:]]+([[:digit:]]{1,2})?,?[[:space:]]+([[:digit:]]{2,4})$', 
                   '(\2) \1 \3');
       ELSIF REGEXP_INSTR(temp_exp,
                  '^([[:alpha:]]+)[[:space:]]+([[:digit:]]{2,4})([[:space:]]+)?([[:digit:]]{1,2})?$') = 1 THEN
      temp_exp := REGEXP_REPLACE(temp_exp, 
                       '^([[:alpha:]]+)[[:space:]]+([[:digit:]]{2,4})([[:space:]]+)?([[:digit:]]{1,2})?$', 
                   '(\4) \1 \2');         
       ELSIF REGEXP_INSTR(temp_exp,
                  '^([[:digit:]]{1,2})?[[:space:]]+([[:alpha:]]+),?[[:space:]]+([[:digit:]]{2,4})$') = 1 THEN
          temp_exp := REGEXP_REPLACE(temp_exp, 
                       '^([[:digit:]]{1,2})?[[:space:]]+([[:alpha:]]+),?[[:space:]]+([[:digit:]]{2,4})$', 
                   '(\1) \2 \3'); 
          temp_exp := REPLACE(temp_exp, ',', '');
    ELSIF REGEXP_INSTR(temp_exp,
                  '^([[:digit:]]{1,2})?[[:space:]]+([[:digit:]]{2,4})[[:space:]]+([[:alpha:]]+)$') = 1 THEN
          temp_exp := REGEXP_REPLACE(temp_exp, 
                         '^([[:digit:]]{1,2})?[[:space:]]+([[:digit:]]{2,4})[[:space:]]+([[:alpha:]]+)$',
                         '(\1) \3 \2');
       ELSIF REGEXP_INSTR(temp_exp,
                  '^([[:digit:]]{2,4})[[:space:]]+([[:alpha:]]+)([[:space:]]+)?([[:digit:]]{1,2})?$') = 1 THEN
          temp_exp := REGEXP_REPLACE(temp_exp,
                         '^([[:digit:]]{2,4})[[:space:]]+([[:alpha:]]+)([[:space:]]+)?([[:digit:]]{1,2})?$',
                         '(\4) \2 \1');
       ELSIF REGEXP_INSTR(temp_exp,
                  '^([[:digit:]]{2,4})[[:space:]]+([[:digit:]]{1,2})?[[:space:]]+([[:alpha:]]+)$') = 1 THEN
          temp_exp := REGEXP_REPLACE(temp_exp,
                         '^([[:digit:]]{2,4})[[:space:]]+([[:digit:]]{1,2})?[[:space:]]+([[:alpha:]]+)$',
                         '(\2) \3 \1');
       END IF;            
     
       temp_exp := REPLACE(temp_exp, '()', '(1)');
       format_str := '(DD) MON YYYY';
    ELSE -- numeric date format
       -- require the setting for SET FORMAT to determine the interpretation of the numeric date format,
       -- default is mdy
       IF REGEXP_INSTR(temp_exp, 
             '^([[:digit:]]{1,2})[-/\.]([[:digit:]]{1,2})[-/\.]([[:digit:]]{2,4})$') = 1 THEN
          temp_exp := REGEXP_REPLACE(temp_exp,
                         '^([[:digit:]]{1,2})[-/\.]([[:digit:]]{1,2})[-/\.]([[:digit:]]{2,4})$',
                         '\1/\2/\3');           
       ELSIF REGEXP_INSTR(temp_exp, 
                  '^([[:digit:]]{1,2})[-/\.]([[:digit:]]{2,4})[-/\.]([[:digit:]]{1,2})$') = 1 THEN
          temp_exp := REGEXP_REPLACE(temp_exp,
                         '^([[:digit:]]{1,2})[-/\.]([[:digit:]]{2,4})[-/\.]([[:digit:]]{1,2})$',
                         '\1/\3/\2');                               
       ELSIF REGEXP_INSTR(temp_exp, 
                  '^([[:digit:]]{2,4})[-/\.]([[:digit:]]{1,2})[-/\.]([[:digit:]]{1,2})$') = 1 THEN
          temp_exp := REGEXP_REPLACE(temp_exp,
                         '^([[:digit:]]{2,4})[-/\.]([[:digit:]]{1,2})[-/\.]([[:digit:]]{1,2})$',
                         '\2/\3/\1'); 
       END IF;
     
       temp_val := TO_NUMBER(SUBSTR(temp_exp, 1, INSTR(temp_exp, '/') - 1));
       IF temp_val > 12 THEN
          format_str := 'DD/MM/';
       ELSE
          format_str := 'MM/DD/';
       END IF;   
          
       format_str := RPAD(format_str, 
                        LENGTH(SUBSTR(temp_exp, INSTR(temp_exp, '/', 1, 2) + 1)),
                        'Y');   
    END IF;
    
    IF format_str IS NOT NULL THEN
       RETURN TO_TIMESTAMP(datetime_expr, format_str);
    ELSE 
       RETURN NULL;
    END IF;
*/
 EXCEPTION
    WHEN OTHERS THEN
       RETURN NULL;
END cnv_to_timestamp;
FUNCTION convert(dataType VARCHAR2,date DATE, num NUMBER ) RETURN VARCHAR2
IS
BEGIN
   RETURN to_char(date);
END convert;
FUNCTION convert(dataType VARCHAR2,num NUMBER) RETURN NUMBER
IS
BEGIN
   IF(dataType = 'NUMBER(19, 2)') THEN -- tsql money
     RETURN num;
   END IF;
   RETURN num;
 END convert;
FUNCTION datediff(datepart VARCHAR2, start_datetime TIMESTAMP, end_datetime TIMESTAMP)
RETURN NUMBER
IS
  ret_value NUMBER;
  part VARCHAR2(15);
BEGIN
    part := UPPER(datepart);
 
    IF part IN ('YEAR', 'YY', 'YYYY') THEN
       ret_value := TO_CHAR(end_datetime, 'YYYY') - TO_CHAR(start_datetime, 'YYYY');
    ELSIF part IN ('QUARTER', 'QQ', 'Q') THEN
       ret_value := TO_CHAR(end_datetime, 'Q') - TO_CHAR(start_datetime, 'Q');
    ELSIF part IN ('MONTH', 'MM', 'M') THEN
       ret_value := TO_CHAR(end_datetime, 'MM') - TO_CHAR(start_datetime, 'MM');
    ElSIF part IN ('DAYOFYEAR', 'DY', 'Y') THEN
       ret_value := TO_CHAR(end_datetime, 'DDD') - TO_CHAR(start_datetime, 'DDD');
    ElSIF part IN ('DAY', 'DD', 'D') THEN
       ret_value := TO_CHAR(end_datetime, 'DD') - TO_CHAR(start_datetime, 'DD');
    ElSIF part IN ('WEEK', 'WK', 'WW') THEN
       ret_value := TO_CHAR(end_datetime, 'IW') - TO_CHAR(start_datetime, 'IW');
    ELSIF part IN ('WEEKDAY', 'DW', 'W') THEN
       ret_value := TO_CHAR(end_datetime, 'D') - TO_CHAR(start_datetime, 'D');
    ElSIF part IN ('HOUR', 'HH') THEN
       ret_value := TO_CHAR(end_datetime, 'HH24') - TO_CHAR(start_datetime, 'HH24');
    ElSIF part IN ('MINUTE', 'MI', 'N') THEN
       ret_value := TO_CHAR(end_datetime, 'MI') - TO_CHAR(start_datetime, 'MI');
    ElSIF part IN ('SECOND', 'SS', 'S') THEN
       ret_value := TO_CHAR(end_datetime, 'SS') - TO_CHAR(start_datetime, 'SS');
    ElSIF part IN ('MILLISECOND', 'MS') THEN
       ret_value := TO_CHAR(end_datetime, 'FF3') - TO_CHAR(start_datetime, 'FF3');
    END IF;
    
    RETURN ret_value;
 EXCEPTION
   WHEN OTHERS THEN
      RETURN NULL;  
 END datediff;
FUNCTION datediff(datepart VARCHAR2, start_datetime_expr VARCHAR2, end_datetime_expr VARCHAR2)
RETURN NUMBER
IS
BEGIN
  RETURN datediff(datepart, cnv_to_timestamp(start_datetime_expr), cnv_to_timestamp(end_datetime_expr));
EXCEPTION
  WHEN OTHERS THEN
    RETURN NULL; 
END datediff;
FUNCTION fetch_status(cursorfound IN BOOLEAN) 
RETURN NUMBER
IS
   v_fetch_status NUMBER := 0;
BEGIN
 CASE
   WHEN cursorfound THEN
      v_fetch_status := 0;
   ELSE
      v_fetch_status := -1;
   END CASE;
   return v_fetch_status;
END fetch_status;
END sqlserver_utilities;
/

