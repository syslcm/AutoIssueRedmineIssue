create PROCEDURE       tmp_redo_Week_Month(
  inCompany  in VARCHAR2,  --invalid
  f_YYYYMMDD in VARCHAR2,  --invalid
  t_YYYYMMDD in VARCHAR2   --invalid
)
is
 iTracePoint  integer ;
 cErrorText varchar2(500);

 C_COMPANY  PMI_SFC001_SITE_FPY.COMPANY_CODE%TYPE;
 C_PASS NUMBER(10);
 C_FAIL NUMBER(10);
 C_RATE NUMBER(10,6);
 C_FPY NUMBER (10,6);
 C_SEQ NUMBER(2);
BEGIN
  iTracePoint := 0;
  ------------------------------------------------------------------------------------------------------------------------  
  --20070202 BY GENE.
  --(1) 計算 Weekly 的資料  (只保留 12 週)
  Delete FROM PMI_SFC001_SITE_FPY_WEEKLY
  COMMIT;
  
  
  iTracePoint := 410;      
  C_COMPANY :='1100';
  FOR rec_profit in (SELECT WORK_YEAR, WORK_WEEK, COMPANY_CODE, PROFIT_CENTER
                       FROM PMI_SFC001_SITE_FPY 
                       WHERE COMPANY_CODE= C_COMPANY 
                       GROUP BY WORK_YEAR, WORK_WEEK, COMPANY_CODE, PROFIT_CENTER )
  LOOP                                  
    C_FPY := 1;       
    C_PASS := 0;
    C_FAIL := 0;
    for rec_GRP in (SELECT MAP_GROUP_NAME, SUM(PASS_QTY) AS S_PASS, SUM(FAIL_QTY) AS S_FAIL FROM PMI_SFC001_SITE_FPY
                  WHERE  WORK_YEAR=rec_Profit.WORK_YEAR 
                     AND WORK_WEEK = rec_Profit.WORK_WEEK    
                     AND COMPANY_CODE=rec_Profit.COMPANY_CODE
                     AND PROFIT_CENTER = rec_Profit.PROFIT_CENTER
                  GROUP BY MAP_GROUP_NAME)
    Loop
      C_Rate := (rec_GRP.S_PASS/(rec_GRP.S_PASS+rec_GRP.S_FAIL));
      
      C_SEQ := 0;
      IF rec_GRP.MAP_GROUP_NAME='SMT1' then
        C_SEQ:= 1;
      ELSIF rec_GRP.MAP_GROUP_NAME='SMT2' then
        C_SEQ:= 2;      
      ELSIF rec_GRP.MAP_GROUP_NAME='ASM' then
        C_SEQ:= 3;      
      ELSIF rec_GRP.MAP_GROUP_NAME='ICT' then
        C_SEQ:= 4;      
      ELSIF rec_GRP.MAP_GROUP_NAME='FCT' then
        C_SEQ:= 5;      
      END IF;      
      
      INSERT INTO PMI_SFC001_SITE_FPY_WEEKLY
       (COMPANY_CODE,PROFIT_CENTER, WORK_YEAR, WORK_WEEK, MAP_GROUP_NAME, GROUP_SEQ, PASS_QTY, FAIL_QTY, YIELD_RATE, CREATE_TIME)
      VALUES
       (rec_Profit.COMPANY_CODE, rec_Profit.PROFIT_CENTER, rec_Profit.WORK_YEAR, rec_Profit.WORK_WEEK, rec_GRP.MAP_GROUP_NAME, C_SEQ,
        rec_GRP.S_PASS, rec_GRP.S_FAIL,C_RATE ,SYSDATE);         
      COMMIT;
        
       --***** FPY = SMT1 * SMT2 * ASM * ICT * FCT (各站良率相乘) 
       C_FPY := C_FPY * C_RATE;       
       C_PASS :=C_PASS + rec_GRP.S_PASS;
       C_FAIL := C_FAIL +  rec_GRP.S_FAIL;  
       --***** --------------------------------------------------
    
    End Loop; --rec_Grp
    --Save FPY      
    C_SEQ:= 6;          
    INSERT INTO PMI_SFC001_SITE_FPY_WEEKLY
       (COMPANY_CODE,PROFIT_CENTER, WORK_YEAR, WORK_WEEK, MAP_GROUP_NAME, GROUP_SEQ, PASS_QTY, FAIL_QTY, YIELD_RATE, CREATE_TIME)
    VALUES
       (rec_Profit.COMPANY_CODE, rec_Profit.PROFIT_CENTER, rec_Profit.WORK_YEAR, rec_Profit.WORK_WEEK, 'FPY', C_SEQ,
        C_PASS, C_FAIL,C_FPY ,SYSDATE);             
    COMMIT;
  END LOOP;  -- rec_Profit
  ------------------------------------------------------------------------------------------------------------------------

  --(1) 計算 Monthly 的資料
  Delete FROM PMI_SFC001_SITE_FPY_MONTHLY
    WHERE COMPANY_CODE=C_COMPANY ;
  COMMIT;
  
  iTracePoint := 420;  
  FOR rec_profit in (SELECT COMPANY_CODE, PROFIT_CENTER, WORK_YEAR, WORK_MONTH
                       FROM PMI_SFC001_SITE_FPY 
                       WHERE COMPANY_CODE= C_COMPANY 
                       GROUP BY COMPANY_CODE, PROFIT_CENTER, WORK_YEAR, WORK_MONTH )
  LOOP                                  
    C_FPY := 1;       
    C_PASS := 0;
    C_FAIL := 0;
    for rec_GRP in (SELECT MAP_GROUP_NAME, SUM(PASS_QTY) AS S_PASS, SUM(FAIL_QTY) AS S_FAIL FROM PMI_SFC001_SITE_FPY
                  WHERE  WORK_YEAR=rec_Profit.WORK_YEAR 
                     AND WORK_MONTH = rec_Profit.WORK_MONTH    
                     AND COMPANY_CODE=rec_Profit.COMPANY_CODE
                     AND PROFIT_CENTER = rec_Profit.PROFIT_CENTER
                  GROUP BY MAP_GROUP_NAME)
    Loop
      C_Rate := (rec_GRP.S_PASS/(rec_GRP.S_PASS+rec_GRP.S_FAIL)); 
      C_SEQ := 0;
      IF rec_GRP.MAP_GROUP_NAME='SMT1' then
        C_SEQ:= 1;
      ELSIF rec_GRP.MAP_GROUP_NAME='SMT2' then
        C_SEQ:= 2;      
      ELSIF rec_GRP.MAP_GROUP_NAME='ASM' then
        C_SEQ:= 3;      
      ELSIF rec_GRP.MAP_GROUP_NAME='ICT' then
        C_SEQ:= 4;      
      ELSIF rec_GRP.MAP_GROUP_NAME='FCT' then
        C_SEQ:= 5;      
      END IF;       
      
      INSERT INTO PMI_SFC001_SITE_FPY_MONTHLY
       (COMPANY_CODE,PROFIT_CENTER, WORK_YEAR, WORK_MONTH, MAP_GROUP_NAME, GROUP_SEQ, PASS_QTY, FAIL_QTY, YIELD_RATE, CREATE_TIME)
      VALUES
       (rec_Profit.COMPANY_CODE, rec_Profit.PROFIT_CENTER, rec_Profit.WORK_YEAR, rec_Profit.WORK_MONTH, rec_GRP.MAP_GROUP_NAME, C_SEQ,
        rec_GRP.S_PASS, rec_GRP.S_FAIL,C_RATE ,SYSDATE);  
       COMMIT;       
        
       --***** FPY = SMT1 * SMT2 * ASM * ICT * FCT (各站良率相乘) 
       C_FPY := C_FPY * C_RATE;       
       C_PASS :=C_PASS + rec_GRP.S_PASS;
       C_FAIL := C_FAIL +  rec_GRP.S_FAIL;  
       --***** --------------------------------------------------
    
    End Loop; --rec_Grp
    --Save FPY
    C_SEQ:= 6;      
    INSERT INTO PMI_SFC001_SITE_FPY_MONTHLY
       (COMPANY_CODE,PROFIT_CENTER, WORK_YEAR, WORK_MONTH, MAP_GROUP_NAME, GROUP_SEQ, PASS_QTY, FAIL_QTY, YIELD_RATE, CREATE_TIME)
    VALUES
       (rec_Profit.COMPANY_CODE, rec_Profit.PROFIT_CENTER, rec_Profit.WORK_YEAR, rec_Profit.WORK_MONTH, 'FPY', C_SEQ,
        C_PASS, C_FAIL,C_FPY ,SYSDATE);             
    COMMIT;
  END LOOP;  -- rec_Profit
  ------------------------------------------------------------------------------------------------------------------------
  
  --刪除一年半前的資料
  DELETE FROM PMI_SFC001_SITE_FPY
   WHERE SHIFT_DATE <= TO_CHAR( (SYSDATE-(18*30)),'YYYYMMDD');
    COMMIT;

  iTracePoint := 500;

EXCEPTION
   When OTHERS Then
    --有錯誤產生則寄mail
    cErrorText := SQLERRM();
    MAIL_FILE_BIDBDBADMIN(in_to_name => 'gene@ms.usi.com.tw', subject => '[PMI] PL/SQL PLSQL_PMI_FPY001_INSP01 ERROR', message => '[PLSQL_PMI_FPY001_INSP01], The tracepoint is  ' || iTracePoint || ' and ErrorText= ' || cErrorText) ;
END ;
/

