create PROCEDURE         "VRTN_PLSQL_COMPLIANCE_WEEK1400" (
 inCompany  in VRTN_SAP006_COMPLIANCE_WEEK_T.COMPANY_CODE%TYPE,
 f_YYYYMMDD in VARCHAR2,
 t_YYYYMMDD in VARCHAR2
)
IS

    /*
     每週執行一次 By MatGroup
     1. 抓 VRTN_SAP006_COMPLIANCE_WEEK_T 資料
     2. Insert to VRTN_ZOT004_COMPLIANCE_WEEK table
         By Susan 2007/04/30
	   TW,SZ,SH
	  * 補1400 sap to VRTN_SAP006_COMPLIANCE_WEEK_T 
    */

 vVENDOR_CODE   VRTN_SAP006_COMPLIANCE_WEEK_T.VENDOR_CODE%TYPE;
 vCompany_code  VRTN_SAP006_COMPLIANCE_WEEK_T.Company_code%TYPE;
 vSITE          VRTN_SAP006_COMPLIANCE_WEEK_T.SITE%TYPE;
 vPROCEE_YYYYMMDD varchar2(8);
 vPROCEE_YYYYMM   varchar2(6);
 iTracePoint      varchar2(100);
 cErrorText       varchar2(500);

BEGIN

  --抓當月份系統日期
  iTracePoint := '100';
  vPROCEE_YYYYMM := TO_CHAR(ADD_MONTHS(SYSDATE, -1), 'YYYYMM');
 -- vPROCEE_YYYYMMDD  :=  to_char(sysdate,'YYYYMMDD');
 -- vPROCEE_YYYYMM :=  SUBSTRB(vPROCEE_YYYYMMDD,1,6);


  for REC1 in ( select P_YEAR, P_MONTH, P_WEEK, P_QUARTER, COMPANY_CODE, SITE, VENDOR_CODE, MATGROUP, PTYPE, SCORES, COMPLIANCE_CNT, TOTAL_4A4_CNT, DATE_TIME
                 from VRTN_SAP006_COMPLIANCE_WEEK_T
                 where COMPANY_CODE = inCompany 
            --     and p_week in (Select substrb(yyyyww,5,2) from DIMENSION_DATE Where date_key = to_char( sysdate - 7, 'yyyymmdd'))
                       ) loop
    if REC1.COMPANY_CODE is not null then
      iTracePoint := '110';
      vCompany_code := REC1.Company_code;
      vSITE := REC1.SITE;
    end if;
  end loop;

  if vCOMPANY_CODE is null then
    --若沒抓到資料則寄 error mail
    iTracePoint := '450';
    cErrorText := 'No data!';
    MAIL_FILE_BIDBDBADMIN(in_to_name => 'shuchin@ms.usi.com.tw', subject => '[VRTN] PL/SQL VRTN_PLSQL_COMPLIANCE_WEEK ERROR', message => '[VRTN_SAP006_COMPLIANCE_WEEK_T], The tracepoint is  ' || iTracePoint || ' and ErrorText= ' || cErrorText) ;
  else

 --清除重覆資料
 --  DELETE FROM VRTN_ZOT004_COMPLIANCE_WEEK WHERE COMPANY_CODE =inCompany
 --          and p_week in (Select substrb(yyyyww,5,2) from DIMENSION_DATE Where date_key = to_char( sysdate - 7, 'yyyymmdd'));

  iTracePoint := '200';
  Insert into VRTN_ZOT004_COMPLIANCE_WEEK (
                   P_YEAR, P_MONTH, P_WEEK, P_QUARTER, COMPANY_CODE, SITE, VENDOR_CODE, MATGROUP, PTYPE, SCORES, COMPLIANCE_CNT, TOTAL_4A4_CNT, DATE_TIME)
      Select P_YEAR, P_MONTH, P_WEEK, P_QUARTER, COMPANY_CODE, SITE, VENDOR_CODE, MATGROUP, PTYPE, SCORES, COMPLIANCE_CNT, TOTAL_4A4_CNT, DATE_TIME
             from VRTN_SAP006_COMPLIANCE_WEEK_T
             where COMPANY_CODE = inCompany            
     --          and p_week in (Select substrb(yyyyww,5,2) from DIMENSION_DATE Where date_key = to_char( sysdate - 7, 'yyyymmdd'));
                 ;

  iTracePoint := '300';
  --DELETE from VRTN_SAP006_COMPLIANCE_WEEK_T
  --       where COMPANY_CODE = inCompany
  --         and p_week in (Select substrb(yyyyww,5,2) from DIMENSION_DATE Where date_key = to_char( sysdate - 7, 'yyyymmdd'));
  Commit;

  end if;

  --Add by susan 2007/05/03 for all site
  if inCompany = '1100' then
     VRTN_PLSQL_ON_TIME_WEEK;
  end if;

EXCEPTION
   When OTHERS Then
    --有錯誤產生則寄mail
    cErrorText := SQLERRM();
    MAIL_FILE_BIDBDBADMIN(in_to_name => 'shuchin@ms.usi.com.tw', subject => '[VRTN] PL/SQL VRTN_PLSQL_COMPLIANCE_WEEK ERROR', message => '[VRTN_ZOT004_COMPLIANCE_WEEK], The tracepoint is  ' || iTracePoint || ' and ErrorText= ' || cErrorText) ;

END VRTN_PLSQL_COMPLIANCE_WEEK1400;
/

