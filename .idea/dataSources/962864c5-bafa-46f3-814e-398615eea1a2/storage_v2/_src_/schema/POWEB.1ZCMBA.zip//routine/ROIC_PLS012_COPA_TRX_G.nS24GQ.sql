create PROCEDURE       ROIC_PLS012_COPA_TRX_G (
  inCompany  in VARCHAR2,
  f_YYYYMMDD in VARCHAR2,
  t_YYYYMMDD in VARCHAR2
)
AUTHID DEFINER
is
/*********************************************************************
  PROG-ID      : ROIC_PLS012_COPA_TRX_G
  PROG-ACTION  : COPA Summary Process
  Author       : Patty
  Date         : 2019/09/25 
  OA No.       : SAI105401
**********************************************************************/
  f_PERIOD           VARCHAR2(6);
  t_PERIOD           VARCHAR2(6);
  
  CURSOR C_TRX is
       Select COMPANY_CODE, 
              PERIOD,
              CURRENCY_LOCAL,
              RELATED_PARTY,
              MTL_TYPE,
              ACCOUNT_ASSIGNMENT,
              NVL(PROFIT_CENTER,' ') AS PROFIT_CENTER,
              CUSTOMER_ID,
              NVL(SUM(NET_REVENUE),0) AS NET_REVENUE,
              NVL(SUM(NET_COGS),0) AS NET_COGS,
              NVL(SUM(NET_REVENUE_TWD),0) AS NET_REVENUE_TWD,
              NVL(SUM(NET_COGS_TWD),0) AS NET_COGS_TWD,
              NVL(SUM(NET_REVENUE_USD),0) AS NET_REVENUE_USD,
              NVL(SUM(NET_COGS_USD),0) AS NET_COGS_USD,
              NVL(SUM(NET_REVENUE_CNY),0) AS NET_REVENUE_CNY,
              NVL(SUM(NET_COGS_CNY),0) AS NET_COGS_CNY            
         From ( Select /*+INDEX (KPI_SAP001_COPA_TRX KPI_SAP001_INDEX6) */
                       A.COMPANY_CODE AS COMPANY_CODE, 
                       A.PERIOD AS PERIOD, 
                       A.CURRENCY_LOCAL AS CURRENCY_LOCAL,
                       A.RELATED_PARTY AS RELATED_PARTY,
                       A.MTL_TYPE AS MTL_TYPE,
                       A.ACCOUNT_ASSIGNMENT AS ACCOUNT_ASSIGNMENT,
                       A.PROFIT_CENTER AS PROFIT_CENTER,
                       A.CUSTOMER_ID AS CUSTOMER_ID,
                       A.NET_REVENUE AS NET_REVENUE,
                       A.NET_COGS AS NET_COGS,
                       A.NET_REVENUE_TWD AS NET_REVENUE_TWD,
                       A.NET_COGS_TWD AS NET_COGS_TWD,
                       A.NET_REVENUE_USD AS NET_REVENUE_USD,
                       A.NET_COGS_USD AS NET_COGS_USD,
                       A.NET_REVENUE_CNY AS NET_REVENUE_CNY,
                       A.NET_COGS_CNY AS NET_COGS_CNY      
                  from KPI_SAP001_COPA_TRX A  
                 where A.COMPANY_CODE = inCompany
                   and A.PERIOD >= SUBSTRB(f_YYYYMMDD,1,6) 
                   and A.PERIOD <= SUBSTRB(t_YYYYMMDD,1,6) 
         ) Group by COMPANY_CODE, PERIOD, CURRENCY_LOCAL, RELATED_PARTY, MTL_TYPE, ACCOUNT_ASSIGNMENT, PROFIT_CENTER, CUSTOMER_ID ;

BEGIN
  f_PERIOD := SUBSTRB(f_YYYYMMDD,1,6);
  t_PERIOD := SUBSTRB(t_YYYYMMDD,1,6);

  --Delete Old Data-- 
  Delete from ROIC_PST013_COPA_TRX_G WHERE COMPANY_CODE = inCompany
                                     AND PERIOD >= f_PERIOD 
                                     AND PERIOD <= t_PERIOD; 
  Commit;

  --Insert data
  FOR REC in C_TRX Loop
    INSERT INTO ROIC_PST013_COPA_TRX_G
      ( COMPANY_CODE, PERIOD, CURRENCY_LOCAL, RELATED_PARTY, MTL_TYPE, ACCOUNT_ASSIGNMENT, PROFIT_CENTER, CUSTOMER_ID, 
        NET_REVENUE, NET_COGS, NET_REVENUE_TWD, NET_COGS_TWD, NET_REVENUE_USD, NET_COGS_USD, NET_REVENUE_CNY, NET_COGS_CNY
     ) values ( REC.COMPANY_CODE, REC.PERIOD, REC.CURRENCY_LOCAL, REC.RELATED_PARTY, REC.MTL_TYPE, REC.ACCOUNT_ASSIGNMENT, REC.PROFIT_CENTER, REC.CUSTOMER_ID, 
        REC.NET_REVENUE, REC.NET_COGS, REC.NET_REVENUE_TWD, REC.NET_COGS_TWD, REC.NET_REVENUE_USD, REC.NET_COGS_USD, REC.NET_REVENUE_CNY, REC.NET_COGS_CNY );
  End Loop;
  Commit;
      
END ROIC_PLS012_COPA_TRX_G;
/

