create PROCEDURE       ROIC_PLS001_AM_LIST (
/* ********************************************************************
  PROG-ID      : ROIC_PLS001_AM_LIST
  PROG-ACTION  : 
  Author       : Asan Chang
  Date         : 201/01/29
  OA Number    : SAI091153
*********************************************************************  
* 2019/05/07 SAI099185 Asan Chang �����R���y�k
* 2019/06/19 SAI101453 Asan Chang �����R���y�k-cancel
********************************************************************* 
*/
   incompany    IN   VARCHAR2,
   f_yyyymmdd   IN   VARCHAR2,
   t_yyyymmdd   IN   VARCHAR2
)
AUTHID DEFINER
IS
   CURSOR ROIC_SAP001_AM_LIST_T
   IS
      SELECT COMPANY_CODE, PERIOD, ASSET_CLASS, ASSET_NO , ASSET_SUB_NO,    
      COST_CENTER, EV_GRP5 ,EV_GRP5_TEXT, CAP_DATE , ASSET_NAME, FYE_ACQ_VAL,     
      CUM_ACQ_VAL, ASSET_VAL_TRANS, VAL_ADJTRANS_FYE, CUM_ORD_DEPREC, 
      ORD_DEP_PSTD, PSTD_UNPL_DEP, CUM_UNPLND_DEP, CUR_NET_BOOK_VAL, 
      INVENTORY_NOTE, SOURCE_FROM               
      FROM ROIC_SAP001_AM_LIST_T
      where COMPANY_CODE = incompany;


   itracepoint   INTEGER;
   t_CURRENCY_LOCAL    pld_kpi_non_bom_ir.IR_CURRENCY%TYPE;
   p_CURRENCY_LOCAL    pld_kpi_non_bom_ir.IR_CURRENCY%TYPE; 
   t_PERIOD            ROIC_SAP001_AM_LIST.PERIOD%TYPE; 

BEGIN
   

     --(1)�M��������
     DELETE FROM ROIC_SAP001_AM_LIST
	 --2019/05/07 SAI099185 Asan Chang
     where PERIOD IN  (SELECT PERIOD FROM ROIC_SAP001_AM_LIST_T WHERE   COMPANY_CODE = incompany)
	 --where PERIOD  = t_yyyymmdd
     AND   COMPANY_CODE = incompany;
     COMMIT;  
     select COMPANY_CURR INTO t_CURRENCY_LOCAL FROM PNL_MAP006_SITE_MAPPING WHERE COMPANY_CODE = incompany;



   FOR REC1 IN ROIC_SAP001_AM_LIST_T LOOP
   
            
     
   --(3)�}�l�B�z����
       INSERT INTO ROIC_SAP001_AM_LIST (
          COMPANY_CODE,        PERIOD,                 ASSET_CLASS,          ASSET_NO , 
          ASSET_SUB_NO,        COST_CENTER,            EV_GRP5 ,             EV_GRP5_TEXT, 
          CAP_DATE ,           ASSET_NAME,             FYE_ACQ_VAL,          CUM_ACQ_VAL, 
          ASSET_VAL_TRANS,     VAL_ADJTRANS_FYE,       CUM_ORD_DEPREC,       ORD_DEP_PSTD, 
          PSTD_UNPL_DEP,       CUM_UNPLND_DEP,         CUR_NET_BOOK_VAL,     INVENTORY_NOTE,
          SOURCE_FROM,         CURRENCY            
          ) VALUES (
                 
          REC1.COMPANY_CODE,   REC1.PERIOD,            REC1.ASSET_CLASS,     REC1.ASSET_NO , 
          REC1.ASSET_SUB_NO,   REC1.COST_CENTER,       REC1.EV_GRP5 ,        REC1.EV_GRP5_TEXT, 
          REC1.CAP_DATE ,      REC1.ASSET_NAME,        REC1.FYE_ACQ_VAL,     REC1.CUM_ACQ_VAL, 
          REC1.ASSET_VAL_TRANS,REC1.VAL_ADJTRANS_FYE,  REC1.CUM_ORD_DEPREC,  REC1.ORD_DEP_PSTD, 
          REC1.PSTD_UNPL_DEP,  REC1.CUM_UNPLND_DEP,    REC1.CUR_NET_BOOK_VAL,REC1.INVENTORY_NOTE,
          'SAP',               t_CURRENCY_LOCAL                 
           );   
       COMMIT;

   END LOOP;

   --(3) �R������
   DELETE FROM ROIC_SAP001_AM_LIST_T
   where COMPANY_CODE = incompany;
   COMMIT;
   
   
END ROIC_PLS001_AM_LIST;
/

