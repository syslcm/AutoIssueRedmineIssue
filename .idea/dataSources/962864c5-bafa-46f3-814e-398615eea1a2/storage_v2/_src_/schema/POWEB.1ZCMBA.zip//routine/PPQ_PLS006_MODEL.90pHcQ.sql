create PROCEDURE       PPQ_PLS006_MODEL
/* ********************************************************************
  PROG-ID      : PPQ_PLS006_MODEL
  PROG-ACTION  : 
  Author       : Asan Chang
  Date         : 2017/10/06
  OA Number    : SAI074906
********************************************************************* */

AUTHID DEFINER
IS
   CURSOR PPQ_TABLE006_MODEL_t
   IS
   SELECT a.model, a.bom_revision, a.bom_file_name, a.usi_pn, a.quote_date,
          a.quarter, a.smc_pn, a.description, a.mfg, mfg_pn, a.qty,
          a.unit_price, a.create_user, a.create_date, a.effective_date,
          a.contract_price, a.cmpt_buyer, a.price_difference
     FROM ppq_view03_smc_bom a,
          (SELECT   smc_pn, usi_pn, MAX (quote_date) AS quote_date
               FROM ppq_upl001_smc_bom
           GROUP BY smc_pn, usi_pn) b
    WHERE NVL (a.smc_pn, 'NULL') = NVL (b.smc_pn, 'NULL')
      AND a.usi_pn = b.usi_pn
      AND a.quote_date = b.quote_date;


   itracepoint   INTEGER;
BEGIN
     --(1)清除舊資料
     DELETE FROM PPQ_TABLE006_MODEL;
     COMMIT;  

   FOR REC1 IN PPQ_TABLE006_MODEL_t LOOP
     
   --(2)開始處理資料
       INSERT INTO PPQ_TABLE006_MODEL (
            MODEL,              BOM_REVISION,         BOM_FILE_NAME,               USI_PN,
            QUOTE_DATE,         QUARTER,              SMC_PN,                      DESCRIPTION,       
            MFG,                MFG_PN,               QTY,                         UNIT_PRICE,        
            CREATE_USER,        CREATE_DATE,          EFFECTIVE_DATE,              CONTRACT_PRICE,   
            CMPT_BUYER,         PRICE_DIFFERENCE
            ) VALUES (                
            REC1.MODEL,         REC1.BOM_REVISION,     REC1.BOM_FILE_NAME,             REC1.USI_PN,            
            REC1.QUOTE_DATE,    REC1.QUARTER,          REC1.SMC_PN,                    REC1.DESCRIPTION, 
            REC1.MFG,           REC1.MFG_PN,           REC1.QTY,                       REC1.UNIT_PRICE, 
            REC1.CREATE_USER,   REC1.CREATE_DATE,      REC1.EFFECTIVE_DATE,            REC1.CONTRACT_PRICE, 
            REC1.CMPT_BUYER,    REC1.PRICE_DIFFERENCE       
             );    
       COMMIT;

   END LOOP;




END PPQ_PLS006_MODEL;
/

