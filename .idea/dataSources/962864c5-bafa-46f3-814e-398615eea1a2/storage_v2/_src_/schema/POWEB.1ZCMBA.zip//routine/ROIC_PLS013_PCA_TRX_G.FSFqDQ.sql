create PROCEDURE       ROIC_PLS013_PCA_TRX_G (
  inCompany  in VARCHAR2,
  f_YYYYMMDD in VARCHAR2,
  t_YYYYMMDD in VARCHAR2
)
AUTHID DEFINER
is
/*********************************************************************
  PROG-ID      : ROIC_PLS013_PCA_TRX_G
  PROG-ACTION  : PCA Summary Process
  Author       : Patty
  Date         : 2019/09/25 
  OA No.       : SAI105401
**********************************************************************/
-- 2020/01/08 SAI113102 Patty NET_REVENUE 乘以 -1
-----------------------------------------------------------------------
  f_PERIOD           VARCHAR2(6);
  t_PERIOD           VARCHAR2(6);
  
  CURSOR C_TRX is
       Select COMPANY_CODE, 
              PERIOD,
              TRNX_TYPE,
              CURRENCY_LOCAL,
              MTL_TYPE,
              NVL(PROFIT_CENTER,' ') AS PROFIT_CENTER,
              NVL(PARTNER_PROFIT_CENTER,' ') AS PARTNER_PROFIT_CENTER,
              CUSTOMER_ID,
              NVL(SUM(NET_REVENUE * -1),0) AS NET_REVENUE,                     -- SAI113102 Modify
              NVL(SUM(NET_COGS),0) AS NET_COGS,
              NVL(SUM(NET_REVENUE_TWD * -1),0) AS NET_REVENUE_TWD,             -- SAI113102 Modify
              NVL(SUM(NET_COGS_TWD),0) AS NET_COGS_TWD,
              NVL(SUM(NET_REVENUE_USD * -1),0) AS NET_REVENUE_USD,             -- SAI113102 Modify
              NVL(SUM(NET_COGS_USD),0) AS NET_COGS_USD,
              NVL(SUM(NET_REVENUE_CNY * -1),0) AS NET_REVENUE_CNY,             -- SAI113102 Modify
              NVL(SUM(NET_COGS_CNY),0) AS NET_COGS_CNY            
         From ( Select A.COMPANY_CODE AS COMPANY_CODE, 
                       A.PERIOD AS PERIOD, 
                       A.TRNX_TYPE AS TRNX_TYPE,
                       A.CURRENCY_LOCAL AS CURRENCY_LOCAL,
                       A.MTL_TYPE AS MTL_TYPE,
                       A.PROFIT_CENTER AS PROFIT_CENTER,
                       A.PARTNER_PROFIT_CENTER AS PARTNER_PROFIT_CENTER,
                       A.CUSTOMER_ID AS CUSTOMER_ID,
                       A.NET_REVENUE AS NET_REVENUE,
                       A.NET_COGS AS NET_COGS,
                       A.NET_REVENUE_TWD AS NET_REVENUE_TWD,
                       A.NET_COGS_TWD AS NET_COGS_TWD,
                       A.NET_REVENUE_USD AS NET_REVENUE_USD,
                       A.NET_COGS_USD AS NET_COGS_USD,
                       A.NET_REVENUE_CNY AS NET_REVENUE_CNY,
                       A.NET_COGS_CNY AS NET_COGS_CNY      
                  from KPI_SAP002_PCA_TRX A  
                 where A.COMPANY_CODE = inCompany
                   and A.PERIOD >= SUBSTRB(f_YYYYMMDD,1,6) 
                   and A.PERIOD <= SUBSTRB(t_YYYYMMDD,1,6) 
         ) Group by COMPANY_CODE, PERIOD, TRNX_TYPE, CURRENCY_LOCAL, MTL_TYPE, PROFIT_CENTER, PARTNER_PROFIT_CENTER, CUSTOMER_ID ;

BEGIN
  f_PERIOD := SUBSTRB(f_YYYYMMDD,1,6);
  t_PERIOD := SUBSTRB(t_YYYYMMDD,1,6);

  --Delete Old Data-- 
  Delete from ROIC_PST014_PCA_TRX_G WHERE COMPANY_CODE = inCompany
                                     AND PERIOD >= f_PERIOD 
                                     AND PERIOD <= t_PERIOD; 
  Commit;

  --Insert data
  FOR REC in C_TRX Loop
    INSERT INTO ROIC_PST014_PCA_TRX_G
      ( COMPANY_CODE, PERIOD, TRNX_TYPE, CURRENCY_LOCAL, MTL_TYPE, PROFIT_CENTER, PARTNER_PROFIT_CENTER, CUSTOMER_ID, 
        NET_REVENUE, NET_COGS, NET_REVENUE_TWD, NET_COGS_TWD, NET_REVENUE_USD, NET_COGS_USD, NET_REVENUE_CNY, NET_COGS_CNY
     ) values ( REC.COMPANY_CODE, REC.PERIOD, REC.TRNX_TYPE, REC.CURRENCY_LOCAL, REC.MTL_TYPE, REC.PROFIT_CENTER, REC.PARTNER_PROFIT_CENTER, REC.CUSTOMER_ID, 
        REC.NET_REVENUE, REC.NET_COGS, REC.NET_REVENUE_TWD, REC.NET_COGS_TWD, REC.NET_REVENUE_USD, REC.NET_COGS_USD, REC.NET_REVENUE_CNY, REC.NET_COGS_CNY );
  End Loop;
  Commit;
      
END ROIC_PLS013_PCA_TRX_G;
/

