create PROCEDURE         "VRTN_PLSQL_SUM_AMT_QQ" AUTHID DEFINER
IS
  /*
    每季執行一次
    2010/07/08 Susan add UGSZ/USI SZ  
    2012/12/04 Susan add KS  
               'H00479' 201905                      
  */

  vFROM_DATE                 varchar2(8);
  vTO_DATE                   varchar2(8);
  vIR_AMT_TWD                NUMBER(17,5); 
  vYYYY                      varchar2(4);
  vYYYYQQ                    varchar2(6);
  vQ                         varchar2(1);

  iTracePoint                varchar2(100);
  cErrorText                 varchar2(500);

BEGIN
  iTracePoint := '000';
  select * into vYYYY, vYYYYQQ, vQ from (
    select trim(to_char(add_months(SYSDATE,-1), 'YYYY')),
           trim(trim(to_char(add_months(SYSDATE,-1), 'YYYY')) || 'Q' || trim(to_char(add_months(SYSDATE,-1), 'Q'))),
           trim(to_char(add_months(SYSDATE,-1), 'Q'))
      from dual
  );

  iTracePoint := '010';
  if vQ = '1' then
    vFROM_DATE := vYYYY || '0101';
    vTO_DATE := vYYYY || '0331';
  elsif vQ = '2' then
    vFROM_DATE := vYYYY || '0401';
    vTO_DATE := vYYYY || '0630';
  elsif vQ = '3' then
    vFROM_DATE := vYYYY || '0701';
    vTO_DATE := vYYYY || '0930';
  else
    vFROM_DATE := vYYYY || '1001';
    vTO_DATE := vYYYY || '1231';
  end if;

  --刪除 VRTN_SUM04_AMT_MATGP_Q
  iTracePoint := '100';
  delete from VRTN_SUM04_AMT_MATGP_Q
   where QUARTER = vYYYYQQ;
  commit;

  iTracePoint := '110';
  insert into VRTN_SUM04_AMT_MATGP_Q ( SITE, VENDOR, GV_VENDOR, MATGROUP, QUARTER, BUKRS, Q_AMOUNT, FROM_DATE, TO_DATE, DATE_TIME )
    select a.COMPANY_CODE as SITE, a.VENDOR_ID as VENDOR, d.GLOBAL_VENDOR_CODE as GV_VENDOR, a.MTL_GROUP as MATGROUP,
           vYYYYQQ as QUARTER, a.COMPANY_CODE as BUKRS, round(sum(a.IR_AMT_TWD),5) as Q_AMOUNT,
           vFROM_DATE as FROM_DATE, vTO_DATE as TO_DATE, to_char(SYSDATE, 'yyyymmddhh24miss') as DATE_TIME
      from PLD_KPI_IR_DETAIL a, PLD_KPI_VENDOR_MASTER b, VRTN_COMPANY_SITE c, GVM032_GLOBAL_VENDOR_ITEM d
     where a.IR_DATE >= vFROM_DATE
       and a.IR_DATE <= vTO_DATE
       and c.MFG_SITE = a.COMPANY_CODE
       and a.GLOBAL_VENDOR_CODE not in ('H00000','H00001','H00002') 
       and a.MTL_GROUP >= '001'
       and a.MTL_GROUP <= '059'
       and a.MTL_GROUP IS NOT NULL 
       and b.COMPANY_CODE = a.COMPANY_CODE
       and b.VENDOR_ID = a.VENDOR_ID      
       and d.COMPANY_CODE = a.COMPANY_CODE
       and d.SAP_VENDOR_CODE = a.VENDOR_ID
       and d.GLOBAL_VENDOR_CODE not in ('H00000','H00001','H00002')
     group by a.COMPANY_CODE, a.VENDOR_ID, d.GLOBAL_VENDOR_CODE, a.MTL_GROUP;
  commit;

  iTracePoint := '120';  --MATGROUP, GV_VENDOR
  for REC1 in (
     select distinct MATGROUP, GV_VENDOR from VRTN_SUM04_AMT_MATGP_Q
      where QUARTER = vYYYYQQ
  ) loop
     BEGIN
       select * into vIR_AMT_TWD from (
         select round(sum(Q_AMOUNT),5) from VRTN_SUM04_AMT_MATGP_Q
          where QUARTER = vYYYYQQ
            and MATGROUP = REC1.MATGROUP
            and GV_VENDOR = REC1.GV_VENDOR
       );
     EXCEPTION
       When OTHERS Then
         vIR_AMT_TWD := 0;
     END;
     Update VRTN_SUM04_AMT_MATGP_Q
        set GV_PER = round(Q_AMOUNT / vIR_AMT_TWD, 5)
      where QUARTER = vYYYYQQ
        and MATGROUP = REC1.MATGROUP
        and GV_VENDOR = REC1.GV_VENDOR;
     commit;
  end loop;

  iTracePoint := '130';  --SITE
  for REC1 in (
     select distinct SITE from VRTN_SUM04_AMT_MATGP_Q
      where QUARTER = vYYYYQQ
  ) loop
     BEGIN
       select * into vIR_AMT_TWD from (
         select round(sum(Q_AMOUNT),5) from VRTN_SUM04_AMT_MATGP_Q
          where QUARTER = vYYYYQQ
            and SITE = REC1.SITE
       );
     EXCEPTION
       When OTHERS Then
         vIR_AMT_TWD := 0;
     END;
     Update VRTN_SUM04_AMT_MATGP_Q
        set SITE_PER = round(Q_AMOUNT / vIR_AMT_TWD, 5)
      where QUARTER = vYYYYQQ
        and SITE = REC1.SITE;
     commit;
  end loop;


  --刪除 VRTN_SUM05_AMT_VM_Q
  iTracePoint := '200';
  delete from VRTN_SUM05_AMT_VM_Q
   where QUARTER = vYYYYQQ;
  commit;

  iTracePoint := '210';
  insert into VRTN_SUM05_AMT_VM_Q ( SITE, VENDOR, GV_VENDOR, QUARTER, BUKRS, Q_AMOUNT, FROM_DATE, TO_DATE, DATE_TIME )
    select a.COMPANY_CODE as SITE, a.VENDOR_ID as VENDOR, d.GLOBAL_VENDOR_CODE as GV_VENDOR,
           vYYYYQQ as QUARTER, a.COMPANY_CODE as BUKRS, round(sum(a.IR_AMT_TWD),5) as Q_AMOUNT,
           vFROM_DATE as FROM_DATE, vTO_DATE as TO_DATE, to_char(SYSDATE, 'yyyymmddhh24miss') as DATE_TIME
      from PLD_KPI_IR_DETAIL a, PLD_KPI_VENDOR_MASTER b, VRTN_COMPANY_SITE c, GVM032_GLOBAL_VENDOR_ITEM d
     where a.IR_DATE >= vFROM_DATE
       and a.IR_DATE <= vTO_DATE
       and c.MFG_SITE = a.COMPANY_CODE
       and a.GLOBAL_VENDOR_CODE not in ('H00000','H00001','H00002') 
       and a.MTL_GROUP IS NOT NULL 
       and a.MTL_GROUP >= '001'
       and a.MTL_GROUP <= '059'
       and b.COMPANY_CODE = a.COMPANY_CODE
       and b.VENDOR_ID = a.VENDOR_ID     --   and b.REC_ACCOUNT <> '0000214202'
       and d.COMPANY_CODE = a.COMPANY_CODE
       and d.SAP_VENDOR_CODE = a.VENDOR_ID
       and d.GLOBAL_VENDOR_CODE not in ('H00000','H00001','H00002')
     group by a.COMPANY_CODE, a.VENDOR_ID, d.GLOBAL_VENDOR_CODE;
  commit;

  iTracePoint := '220';  --GV_VENDOR
  for REC1 in (
     select distinct GV_VENDOR from VRTN_SUM05_AMT_VM_Q
      where QUARTER = vYYYYQQ
  ) loop
     BEGIN
       select * into vIR_AMT_TWD from (
         select round(sum(Q_AMOUNT),5) from VRTN_SUM05_AMT_VM_Q
          where QUARTER = vYYYYQQ
            and GV_VENDOR = REC1.GV_VENDOR
       );
     EXCEPTION
       When OTHERS Then
         vIR_AMT_TWD := 0;
     END;
     Update VRTN_SUM05_AMT_VM_Q
        set GV_PER = round(Q_AMOUNT / vIR_AMT_TWD, 5)
      where QUARTER = vYYYYQQ
        and GV_VENDOR = REC1.GV_VENDOR;
     commit;
  end loop;

  iTracePoint := '230';  --SITE
  for REC1 in (
     select distinct SITE from VRTN_SUM05_AMT_VM_Q
      where QUARTER = vYYYYQQ
  ) loop
     BEGIN
       select * into vIR_AMT_TWD from (
         select round(sum(Q_AMOUNT),5) from VRTN_SUM05_AMT_VM_Q
          where QUARTER = vYYYYQQ
            and SITE = REC1.SITE
       );
     EXCEPTION
       When OTHERS Then
         vIR_AMT_TWD := 0;
     END;
     Update VRTN_SUM05_AMT_VM_Q
        set SITE_PER = round(Q_AMOUNT / vIR_AMT_TWD, 5)
      where QUARTER = vYYYYQQ
        and SITE = REC1.SITE;
     commit;
  end loop;


  --刪除 VRTN_SUM06_AMT_SITE_Q
  --iTracePoint := '300';
  --delete from VRTN_SUM06_AMT_SITE_Q
  -- where QUARTER = vYYYYQQ;
  --commit;

 -- iTracePoint := '310';
 -- insert into VRTN_SUM06_AMT_SITE_Q ( SITE, QUARTER, BUKRS, Q_AMOUNT, GV_PER, FROM_DATE, TO_DATE, DATE_TIME )
 -- select SITE, QUARTER, BUKRS, Q_AMOUNT, round(Q_AMOUNT / G_AMT,5), FROM_DATE, TO_DATE, to_char(SYSDATE, 'yyyymmddhh24miss') from (
 --   select a.COMPANY_CODE as SITE, vYYYYQQ as QUARTER, a.COMPANY_CODE as BUKRS, round(sum(a.IR_AMT_TWD),5) as Q_AMOUNT, vFROM_DATE as FROM_DATE, vTO_DATE as TO_DATE,
 --          ( select round(sum(a1.IR_AMT_TWD),5) from PLD_KPI_IR_DETAIL a1, PLD_KPI_VENDOR_MASTER b1, VRTN_COMPANY_SITE c1, GVM032_GLOBAL_VENDOR_ITEM d1
 --             where a1.IR_DATE >= vFROM_DATE
 --               and a1.IR_DATE <= vTO_DATE
 --               and c1.MFG_SITE = a1.COMPANY_CODE
 --               and a1.GLOBAL_VENDOR_CODE not in ('H00000','H00001','H00002') 
 --               and a1.MTL_GROUP >= '001'
 --               and a1.MTL_GROUP <= '059'
 --               and a1.MTL_GROUP IS NOT NULL 
 --               and b1.COMPANY_CODE = a1.COMPANY_CODE
 --               and b1.VENDOR_ID = a1.VENDOR_ID   --and b1.REC_ACCOUNT <> '0000214202'
 --               and d1.COMPANY_CODE = a1.COMPANY_CODE
 --               and d1.SAP_VENDOR_CODE = a1.VENDOR_ID
 --               and d1.GLOBAL_VENDOR_CODE not in ('H00000','H00001','H00002') ) as G_AMT
 --     from PLD_KPI_IR_DETAIL a, PLD_KPI_VENDOR_MASTER b, VRTN_COMPANY_SITE c, GVM032_GLOBAL_VENDOR_ITEM d
 --    where a.IR_DATE >= vFROM_DATE
 --      and a.IR_DATE <= vTO_DATE
 --      and c.MFG_SITE = a.COMPANY_CODE
 --      and a.GLOBAL_VENDOR_CODE not in ('H00000','H00001','H00002') 
 --      and a.MTL_GROUP >= '001'
 --      and a.MTL_GROUP <= '059'
 --      and a.MTL_GROUP IS NOT NULL
 --      and b.COMPANY_CODE = a.COMPANY_CODE
 --      and b.VENDOR_ID = a.VENDOR_ID    -- and b.REC_ACCOUNT <> '0000214202'
 --      and d.COMPANY_CODE = a.COMPANY_CODE
 --      and d.SAP_VENDOR_CODE = a.VENDOR_ID
 --      and d.GLOBAL_VENDOR_CODE not in ('H00000','H00001','H00002')
 --    group by a.COMPANY_CODE );
 -- commit;


EXCEPTION
  When OTHERS Then
    --有錯誤產生則寄mail
    cErrorText := SQLERRM();
    MAIL_FILE_BIDBDBADMIN(in_to_name => 'shuchin_lin@usiglobal.com', subject => '[VRTN] PL/SQL VRTN_PLSQL_SUM_AMT_QQ ERROR', message => '[VRTN_PLSQL_SUM_AMT_QQ], The tracepoint is  ' || iTracePoint || ' and ErrorText= ' || cErrorText) ;
END;
/

