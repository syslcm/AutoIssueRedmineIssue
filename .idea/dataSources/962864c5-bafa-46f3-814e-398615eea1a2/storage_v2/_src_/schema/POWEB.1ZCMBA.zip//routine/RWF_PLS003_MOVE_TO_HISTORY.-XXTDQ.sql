create PROCEDURE RWF_PLS003_MOVE_TO_HISTORY
/*********************************************************************
  PROG-ID      : RWF_PLS003_MOVE_TO_HISTORY
  PROG-ACTION  : MOVE RWF_SAP001_REVENUE_FORECAST_H TO RWF_SAP001_REVENUE_FORECAST
                 Keep two years data.
  Author       : KANGI
  Date         : 2011/12/05
**********************************************************************/
is
   CURSOR ACTIVE_RWF_CUR
   is
    SELECT RWF_YYYY,RWF_WEEK
      FROM RWF_SAP001_REVENUE_FORECAST
     WHERE RWF_YYYY NOT IN (TO_CHAR(SYSDATE,'YYYY'),TO_CHAR(ADD_MONTHS(TO_DATE(TO_CHAR(SYSDATE,'YYYY')||'0101','YYYYMMDD'),-1),'YYYY'))
     GROUP BY RWF_YYYY,RWF_WEEK ;

   cMessage     LONG ;
   iTracePoint  integer ;
   cErrorText char(500) ;
   iFind_Flag   integer ;          ----1=>find , 0=>dosen't find
   iSuccess_Flag   integer ;       ----1=>Success , 0=>Failure
   iProcess_Flag     integer ;     ----1=>Yes , 0=>NO
   sql_stmt     varchar2(400);

BEGIN

     iTracePoint := 1500 ;
     iSuccess_Flag := 0 ;

     FOR ACTIVE_RWF_REC in ACTIVE_RWF_CUR  LOOP

        INSERT INTO RWF_SAP001_REVENUE_FORECAST_H
        SELECT * FROM RWF_SAP001_REVENUE_FORECAST
        WHERE RWF_YYYY = ACTIVE_RWF_REC.RWF_YYYY
          AND RWF_WEEK = ACTIVE_RWF_REC.RWF_WEEK  ;
        -------------------------------------------
        DELETE RWF_SAP001_REVENUE_FORECAST
             WHERE RWF_YYYY = ACTIVE_RWF_REC.RWF_YYYY
               AND RWF_WEEK = ACTIVE_RWF_REC.RWF_WEEK  ;
        COMMIT ;

     END LOOP ;
     iTracePoint := 2100 ;
End RWF_PLS003_MOVE_TO_HISTORY;
/

