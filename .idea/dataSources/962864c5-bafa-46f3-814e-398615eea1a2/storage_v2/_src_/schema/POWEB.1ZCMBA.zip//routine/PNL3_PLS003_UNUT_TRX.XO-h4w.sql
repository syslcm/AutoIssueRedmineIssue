create PROCEDURE       pnl3_pls003_unut_trx (
--2008/12/29 新增邏輯,只要cost center有維護在PNL3_MAP005_UNT_COST_CETNER的就到KPI_SAP012_EXPENSE_HISTORY
--抓取金額後直接歸客戶,剩下的再用工時分
--由PNL3_PLS003_UNUT_TRX_v1回復
--UN UTILIZATION 末分配  備份2008/12/22資料
--採用工時分攤,不透過另一個費用科目分攤
--2009/1/14增加邏輯,針對9開頭(沒有工時)一律分給usi-untuilization
--2009/1/20 增加project name,project type
--2010/12/24 在抓2010/11月份的資料時,1200 有四筆資料不要抓,在會計的earning model裡有手動調過,但系統無法做到,調的原因是因為usi-sz有作,ug-sz也有作,重覆了
--2010/12/27 續12/24問題,原來是這兩邊的帳都要拿掉,不然成本會增加,如果兩邊都在會NET掉,但是BY SITE看會有某邊虛增或虛減,所以1400的PC 99也要拿掉
--2010/12/28  在1400又發現除了99有做之外,23也有做,原來是做了2張,1100001076是99的,而1100001089則有99和23,所以我要拿掉23的,99的會NET掉
                                                        --inCompany  in VARCHAR2,

                                                        --inPC in VARCHAR2,
                                                        --inGL in VARCHAR2,
                                                        inperiod IN VARCHAR2
                                                                            --2008/9/17 Create to Process get Amount in Local/USD/TWD
                                                                            --Trigger by PNL2_BAD_DEPT_UPLOAD.JSP
)
AUTHID DEFINER
IS
    --2008/11/7 有發現  SUM(NET_REVENUE) <> 0 OR SUM(NET_COGS)  <> 0 條件成立但dm/dl/oh卻有值的戕況,因此不加入此條件
-- 在INSERT進資料庫時再排除金額=0的資料
   CURSOR c_pnl2_util
   IS
      SELECT   company_code, profit_center, cost_element, period,
               SUM (net_revenue) net_revenue,
               SUM (net_revenue_usd) net_revenue_usd,
               SUM (net_revenue_twd) net_revenue_twd, SUM (net_cogs)
                                                                    net_cogs,
               SUM (net_cogs_usd) net_cogs_usd,
               SUM (net_cogs_twd) net_cogs_twd, SUM (cogs_mb) cogs_mb,
               SUM (cogs_mb_usd) cogs_mb_usd, SUM (cogs_mb_twd) cogs_mb_twd,
               SUM (cogs_lb) cogs_lb, SUM (cogs_lb_usd) cogs_lb_usd,
               SUM (cogs_lb_twd) cogs_lb_twd, SUM (cogs_ob) cogs_ob,
               SUM (cogs_ob_usd) cogs_ob_usd, SUM (cogs_ob_twd) cogs_ob_twd,
               SUM (net_revenue), SUM (net_cogs)
          FROM kpi_sap001_copa_trx
         WHERE period = inperiod
           AND (net_revenue <> 0 OR net_cogs <> 0)
           AND related_party <> 'Y'
           --AND COMPANY_CODE = '1500'--inCOMPANY
           --AND PROFIT_CENTER = '0000000038'
           --AND COST_ELEMENT = '0000510201'
           AND NOT (COPA_DOC_NO = '0205010616' AND ZB026_DOC_NO = '3100001918')
           AND NOT (COPA_DOC_NO = '0205010617' AND ZB026_DOC_NO = '3100001918')
           AND NOT (COPA_DOC_NO = '0205010618' AND ZB026_DOC_NO = '3100001918')
           AND NOT (COPA_DOC_NO = '0205010619' AND ZB026_DOC_NO = '3100001918')
           AND NOT (COPA_DOC_NO = '0200158522' AND ZB026_DOC_NO = '1100001089')
           AND NOT (COPA_DOC_NO = '0200158523' AND ZB026_DOC_NO = '1100001089')
           AND NOT (COPA_DOC_NO = '0200158524' AND ZB026_DOC_NO = '1100001089')
           AND NOT (COPA_DOC_NO = '0200158525' AND ZB026_DOC_NO = '1100001089')

           AND cost_element IN
                     ('0000510201', '0000510301', '0000510401', '0000510501')
      GROUP BY company_code, profit_center, cost_element, period;

   --HAVING ( SUM(NET_REVENUE) <> 0 OR SUM(NET_COGS)  <> 0 );
   a_tamount       kpi_sap001_copa_trx.net_revenue%TYPE;
   a_rate          pnl2_upl003_realized_gm.ex_rate_usd%TYPE;
   a_endcustomer   kpi_sap001_copa_trx.end_customer_id%TYPE;
   a_total_hrs     pnl2_trx003_un_utilization.total_hrs%TYPE;
   a_counter       INTEGER;
BEGIN
   DELETE FROM pnl3_trx003_unutilization
         WHERE period = inperiod;

   COMMIT;

   FOR rec1 IN c_pnl2_util
   LOOP
      -- Get Total HRS
      a_total_hrs := 0;

      BEGIN
         SELECT NVL (SUM (total_hrs), 0)
           INTO a_total_hrs
           FROM kpi_sap012_expense_history
          WHERE period = rec1.period
            AND company_code = rec1.company_code
            AND profit_center = rec1.profit_center
            AND TRANSACTION = 'RKL';

         IF SQL%NOTFOUND
         THEN
            a_total_hrs := 0;
         END IF;
      EXCEPTION
         WHEN OTHERS
         THEN
            a_total_hrs := 0;
      END;

      a_tamount := 0;

      BEGIN
         SELECT NVL (SUM (amt_twd), 0)
           INTO a_tamount
           FROM pnl3_trx001_copa
          WHERE period = rec1.period
            --AND SOURCE <> 'UPL001'
            AND area1 = '1'
            AND area2 = '1'
            AND area3 = '0'
            AND profit_center = rec1.profit_center;

         IF SQL%NOTFOUND
         THEN
            a_tamount := 0;
         END IF;
      EXCEPTION
         WHEN OTHERS
         THEN
            a_tamount := 0;
      END;

      IF a_total_hrs = 0
      THEN    --抓不到工時分攤,PROFICE CENTER 9X的有這種狀況,全部用Revenue去分
         IF a_tamount = 0
         THEN   --沒有營收,全部歸OTHERS ,Profit center 34即沒有營收也沒有工時
            IF rec1.profit_center = '0000000034'
            THEN
               INSERT INTO pnl3_trx003_unutilization
                           (company_code, period,
                            profit_center, part_no, total_hrs, pn_hrs,
                            net_revenue, net_revenue_twd,
                            net_revenue_usd, net_cogs,
                            net_cogs_twd, net_cogs_usd,
                            cogs_mb, cogs_mb_twd,
                            cogs_mb_usd, cogs_lb,
                            cogs_lb_twd, cogs_lb_usd,
                            cogs_ob, cogs_ob_twd,
                            cogs_ob_usd, o_net_revenue,
                            o_net_cogs, rate, cost_element,
                            end_customer_id, sql_method, customer_rate,
                            create_date
                           )
                    VALUES (rec1.company_code, rec1.period,
                            rec1.profit_center, NULL, 0, 0,
                            rec1.net_revenue, rec1.net_revenue_twd,
                            rec1.net_revenue_usd, rec1.net_cogs,
                            rec1.net_cogs_twd, rec1.net_cogs_usd,
                            rec1.cogs_mb, rec1.cogs_mb_twd,
                            rec1.cogs_mb_usd, rec1.cogs_lb,
                            rec1.cogs_lb_twd, rec1.cogs_lb_usd,
                            rec1.cogs_ob, rec1.cogs_ob_twd,
                            rec1.cogs_ob_usd, rec1.net_revenue_twd,
                            rec1.net_cogs_twd, 0, rec1.cost_element,
                            'UABIT''S CUST', 'WH=0/T_AMT=0', 0,
                            SYSDATE
                           );

               COMMIT;
            ELSIF SUBSTR (rec1.profit_center, 1, 9) = '000000009'
            THEN
               IF SUBSTR (rec1.company_code, 1, 1) = '9'
               THEN
                  INSERT INTO pnl3_trx003_unutilization
                              (company_code, period,
                               profit_center, part_no, total_hrs, pn_hrs,
                               net_revenue, net_revenue_twd,
                               net_revenue_usd, net_cogs,
                               net_cogs_twd, net_cogs_usd,
                               cogs_mb, cogs_mb_twd,
                               cogs_mb_usd, cogs_lb,
                               cogs_lb_twd, cogs_lb_usd,
                               cogs_ob, cogs_ob_twd,
                               cogs_ob_usd, o_net_revenue,
                               o_net_cogs, rate, cost_element,
                               end_customer_id, sql_method, customer_rate,
                               create_date
                              )
                       VALUES (rec1.company_code, rec1.period,
                               rec1.profit_center, NULL, 0, 0,
                               rec1.net_revenue, rec1.net_revenue_twd,
                               rec1.net_revenue_usd, rec1.net_cogs,
                               rec1.net_cogs_twd, rec1.net_cogs_usd,
                               rec1.cogs_mb, rec1.cogs_mb_twd,
                               rec1.cogs_mb_usd, rec1.cogs_lb,
                               rec1.cogs_lb_twd, rec1.cogs_lb_usd,
                               rec1.cogs_ob, rec1.cogs_ob_twd,
                               rec1.cogs_ob_usd, rec1.net_revenue_twd,
                               rec1.net_cogs_twd, 0, rec1.cost_element,
                               '投資公司', 'WH=0/T_AMT=0', 0,
                               SYSDATE
                              );

                  COMMIT;
               ELSE
                  INSERT INTO pnl3_trx003_unutilization
                              (company_code, period,
                               profit_center, part_no, total_hrs, pn_hrs,
                               net_revenue, net_revenue_twd,
                               net_revenue_usd, net_cogs,
                               net_cogs_twd, net_cogs_usd,
                               cogs_mb, cogs_mb_twd,
                               cogs_mb_usd, cogs_lb,
                               cogs_lb_twd, cogs_lb_usd,
                               cogs_ob, cogs_ob_twd,
                               cogs_ob_usd, o_net_revenue,
                               o_net_cogs, rate, cost_element,
                               end_customer_id, sql_method, customer_rate,
                               create_date
                              )
                       VALUES (rec1.company_code, rec1.period,
                               rec1.profit_center, NULL, 0, 0,
                               rec1.net_revenue, rec1.net_revenue_twd,
                               rec1.net_revenue_usd, rec1.net_cogs,
                               rec1.net_cogs_twd, rec1.net_cogs_usd,
                               rec1.cogs_mb, rec1.cogs_mb_twd,
                               rec1.cogs_mb_usd, rec1.cogs_lb,
                               rec1.cogs_lb_twd, rec1.cogs_lb_usd,
                               rec1.cogs_ob, rec1.cogs_ob_twd,
                               rec1.cogs_ob_usd, rec1.net_revenue_twd,
                               rec1.net_cogs_twd, 0, rec1.cost_element,
                               'USI-UNUTILIZATION', 'WH=0/T_AMT=0', 0,
                               SYSDATE
                              );

                  COMMIT;
               END IF;
            ELSE
               /*
                   INSERT INTO PNL3_TRX003_UNUTILIZATION (
                      COMPANY_CODE         ,PERIOD                 ,PROFIT_CENTER       ,
                      PART_NO              ,TOTAL_HRS              ,PN_HRS              ,
                      NET_REVENUE          ,NET_REVENUE_TWD        ,NET_REVENUE_USD     ,
                      NET_COGS             ,NET_COGS_TWD           ,NET_COGS_USD        ,
                      COGS_MB              ,COGS_MB_TWD            ,COGS_MB_USD         ,
                      COGS_LB              ,COGS_LB_TWD            ,COGS_LB_USD         ,
                      COGS_OB              ,COGS_OB_TWD            ,COGS_OB_USD         ,
                      O_NET_REVENUE        ,O_NET_COGS             ,
                      RATE                 ,COST_ELEMENT           ,END_CUSTOMER_ID ,
                      SQL_METHOD           ,CUSTOMER_RATE          ,
                      CREATE_DATE
                   ) VALUES(
                      REC1.COMPANY_CODE    ,REC1.PERIOD           ,REC1.PROFIT_CENTER    ,
                      NULL                 ,0                     ,0                     ,
                      REC1.NET_REVENUE     ,REC1.NET_REVENUE_TWD  ,REC1.NET_REVENUE_USD  ,
                      REC1.NET_COGS        ,REC1.NET_COGS_TWD     ,REC1.NET_COGS_USD     ,
                      REC1.COGS_MB         ,REC1.COGS_MB_TWD      ,REC1.COGS_MB_USD      ,
                      REC1.COGS_LB         ,REC1.COGS_LB_TWD      ,REC1.COGS_LB_USD      ,
                      REC1.COGS_OB         ,REC1.COGS_OB_TWD      ,REC1.COGS_OB_USD      ,
                      REC1.NET_REVENUE_TWD ,REC1.NET_COGS_TWD     ,
                      0                    ,REC1.COST_ELEMENT     ,NULL             ,
                      'WH=0/T_AMT=0'       ,0                     ,
                      SYSDATE
                   );
                   commit;
                   */
               a_counter := 0;

               FOR rec2 IN (SELECT end_customer_id, rate
                              FROM pnl3_map001_customer_rate
                             WHERE r_kind =
                                        'PL01'
                                              --隨便抓一筆來用,反正匯率都一樣
                               AND area1 = '4'
                               AND area2 = '1'
                               AND area3 = '1'
                               --AND COMPANY_CODE = REC1.COMPANY_CODE
                               AND profit_center = rec1.profit_center
                               AND period = inperiod)
               LOOP
                  a_counter := 1;

                  INSERT INTO pnl3_trx003_unutilization
                              (company_code, period,
                               profit_center, part_no, total_hrs, pn_hrs,
                               net_revenue,
                               net_revenue_twd,
                               net_revenue_usd,
                               net_cogs,
                               net_cogs_twd,
                               net_cogs_usd,
                               cogs_mb,
                               cogs_mb_twd,
                               cogs_mb_usd,
                               cogs_lb,
                               cogs_lb_twd,
                               cogs_lb_usd,
                               cogs_ob,
                               cogs_ob_twd,
                               cogs_ob_usd,
                               o_net_revenue,
                               o_net_cogs, rate,
                               cost_element, end_customer_id,
                               sql_method, customer_rate, create_date
                              )
                       VALUES (rec1.company_code, rec1.period,
                               rec1.profit_center, NULL, 0, 0,
                               ROUND (rec1.net_revenue * rec2.rate, 5),
                               ROUND (rec1.net_revenue_twd * rec2.rate, 5),
                               ROUND (rec1.net_revenue_usd * rec2.rate, 5),
                               ROUND (rec1.net_cogs * rec2.rate, 5),
                               ROUND (rec1.net_cogs_twd * rec2.rate, 5),
                               ROUND (rec1.net_cogs_usd * rec2.rate, 5),
                               ROUND (rec1.cogs_mb * rec2.rate, 5),
                               ROUND (rec1.cogs_mb_twd * rec2.rate, 5),
                               ROUND (rec1.cogs_mb_usd * rec2.rate, 5),
                               ROUND (rec1.cogs_lb * rec2.rate, 5),
                               ROUND (rec1.cogs_lb_twd * rec2.rate, 5),
                               ROUND (rec1.cogs_lb_usd * rec2.rate, 5),
                               ROUND (rec1.cogs_ob * rec2.rate, 5),
                               ROUND (rec1.cogs_ob_twd * rec2.rate, 5),
                               ROUND (rec1.cogs_ob_usd * rec2.rate, 5),
                               ROUND (rec1.net_revenue_twd * rec2.rate, 5),
                               ROUND (rec1.net_cogs_twd * rec2.rate, 5), 0,
                               rec1.cost_element, rec2.end_customer_id,
                               'WH=0/T_AMT=0', 0, SYSDATE
                              );
               END LOOP;

               IF a_counter = 0
               THEN
                  FOR rec2 IN
                     (SELECT end_customer_id, rate
                        FROM pnl3_map001_global_cust_rate
                       WHERE r_kind = 'PL01'  --隨便抓一筆來用,反正匯率都一樣
                         AND area1 = '4'
                         AND area2 = '1'
                         AND area3 = '1'
                         --AND COMPANY_CODE = REC1.COMPANY_CODE
                         --AND PROFIT_CENTER = REC1.PROFIT_CENTER
                         AND period = inperiod)
                  LOOP
                     INSERT INTO pnl3_trx003_unutilization
                                 (company_code, period,
                                  profit_center, part_no, total_hrs, pn_hrs,
                                  net_revenue,
                                  net_revenue_twd,
                                  net_revenue_usd,
                                  net_cogs,
                                  net_cogs_twd,
                                  net_cogs_usd,
                                  cogs_mb,
                                  cogs_mb_twd,
                                  cogs_mb_usd,
                                  cogs_lb,
                                  cogs_lb_twd,
                                  cogs_lb_usd,
                                  cogs_ob,
                                  cogs_ob_twd,
                                  cogs_ob_usd,
                                  o_net_revenue,
                                  o_net_cogs,
                                  rate, cost_element,
                                  end_customer_id, sql_method,
                                  customer_rate, create_date
                                 )
                          VALUES (rec1.company_code, rec1.period,
                                  rec1.profit_center, NULL, 0, 0,
                                  ROUND (rec1.net_revenue * rec2.rate, 5),
                                  ROUND (rec1.net_revenue_twd * rec2.rate, 5),
                                  ROUND (rec1.net_revenue_usd * rec2.rate, 5),
                                  ROUND (rec1.net_cogs * rec2.rate, 5),
                                  ROUND (rec1.net_cogs_twd * rec2.rate, 5),
                                  ROUND (rec1.net_cogs_usd * rec2.rate, 5),
                                  ROUND (rec1.cogs_mb * rec2.rate, 5),
                                  ROUND (rec1.cogs_mb_twd * rec2.rate, 5),
                                  ROUND (rec1.cogs_mb_usd * rec2.rate, 5),
                                  ROUND (rec1.cogs_lb * rec2.rate, 5),
                                  ROUND (rec1.cogs_lb_twd * rec2.rate, 5),
                                  ROUND (rec1.cogs_lb_usd * rec2.rate, 5),
                                  ROUND (rec1.cogs_ob * rec2.rate, 5),
                                  ROUND (rec1.cogs_ob_twd * rec2.rate, 5),
                                  ROUND (rec1.cogs_ob_usd * rec2.rate, 5),
                                  ROUND (rec1.net_revenue_twd * rec2.rate, 5),
                                  ROUND (rec1.net_cogs_twd * rec2.rate, 5),
                                  0, rec1.cost_element,
                                  rec2.end_customer_id, 'WH=0/T_AMT=0',
                                  0, SYSDATE
                                 );
                  END LOOP;
               END IF;
            END IF;
         ELSE                            --有營收,用END_CUSTOMER 的REVENUE去分
            pnl3_pls003_unut_trx_s02 (rec1.company_code,
                                      rec1.period,
                                      rec1.profit_center,
                                      rec1.cost_element,
                                      a_tamount,
                                      rec1.net_revenue,
                                      rec1.net_revenue_usd,
                                      rec1.net_revenue_twd,
                                      rec1.net_cogs,
                                      rec1.net_cogs_usd,
                                      rec1.net_cogs_twd,
                                      rec1.cogs_mb,
                                      rec1.cogs_mb_usd,
                                      rec1.cogs_mb_twd,
                                      rec1.cogs_lb,
                                      rec1.cogs_lb_usd,
                                      rec1.cogs_lb_twd,
                                      rec1.cogs_ob,
                                      rec1.cogs_ob_usd,
                                      rec1.cogs_ob_twd
                                     );
         END IF;
      ELSE                                               --有工時,以料號來分別
         pnl3_pls003_unut_trx_s01 (rec1.company_code,
                                   rec1.period,
                                   rec1.profit_center,
                                   rec1.cost_element,
                                   a_tamount,
                                   a_total_hrs,
                                   rec1.net_revenue,
                                   rec1.net_revenue_usd,
                                   rec1.net_revenue_twd,
                                   rec1.net_cogs,
                                   rec1.net_cogs_usd,
                                   rec1.net_cogs_twd,
                                   rec1.cogs_mb,
                                   rec1.cogs_mb_usd,
                                   rec1.cogs_mb_twd,
                                   rec1.cogs_lb,
                                   rec1.cogs_lb_usd,
                                   rec1.cogs_lb_twd,
                                   rec1.cogs_ob,
                                   rec1.cogs_ob_usd,
                                   rec1.cogs_ob_twd
                                  );
      END IF;
   END LOOP;
   
         UPDATE PNL3_TRX003_UNUTILIZATION
      SET project_name =
             (SELECT DISTINCT TRIM (sap_project_name)
                         FROM cep_map010_partno_project
                        WHERE fg_material_no = 
                                      RPAD (PNL3_TRX003_UNUTILIZATION.part_no, 18, ' '))
    WHERE period = inperiod;

   commit;
   
   UPDATE PNL3_TRX003_UNUTILIZATION
      SET project_TYPE =
             (SELECT DISTINCT TRIM (PROJECT_TYPE)
                         FROM CEP_WEB002_PROJECT
                        WHERE PROJECT_NAME = PNL3_TRX003_UNUTILIZATION.PROJECT_NAME)
                                      --RPAD (PNL3_TRX003_UNUTILIZATION.PROJECT_NAME, 30, ' '))
    WHERE period = inperiod;

   commit;
END pnl3_pls003_unut_trx;
/

