create PROCEDURE         "VQA_PLSQL_STS_MM_MANFU_PN" AUTHID DEFINER
IS

      /*--------------------------------------------------------------*
         CREATE DATE:  2008/02/25
         PLSQL      :  VQA_PLSQL_STS_MM_MANFU_PN
         Author     :  Susan Lin
         Purpase    :  STS RATE(By 每月執行一次)
                       TW/SZ/SH
      *---------------------------------------------------------------*
      */


 vVENDOR_CODE  VQA_050_STS_WEEKLY_MANFU_PN.MANUF%TYPE;
 vCompany_code VQA_050_STS_WEEKLY_MANFU_PN.Company_code%TYPE;
 vPROCEE_YYYYMMDD varchar2(8);
 vPROCEE_YYYYMM   varchar2(6);
 iTracePoint      varchar2(100);
 cErrorText       varchar2(500);

BEGIN

 --抓上月份By系統日期
  iTracePoint := '000';
   select * into vPROCEE_YYYYMM, vPROCEE_YYYYMMDD  from (
          select trim(to_char(add_months(SYSDATE,-1), 'YYYYMM')), trim(to_char(add_months(SYSDATE,-1), 'YYYYMM')) || '01'
                 from dual
   );


  for REC1 in ( select COMPANY_CODE, YYYY, MM, WEEK, MANUF, PART_NO, PTYPE, MATGROUP, STS_LOT_CNT, LOT_CNT, PERCENTAGE, DATE_TIME, YYYY || MM AS YYYYMM, FSI, TOT_LOT
                 from VQA_050_STS_WEEKLY_MANFU_PN
                      where YYYY =  substr(vPROCEE_YYYYMM,1,4)
                        and MM =   substr(vPROCEE_YYYYMM,5,2)
                       ) loop
    if REC1.COMPANY_CODE is not null then
      iTracePoint := '100';
      vCompany_code := REC1.Company_code;
    end if;
  end loop;

  if vCOMPANY_CODE is null then
    --若沒抓到資料則寄 error mail
    iTracePoint := '200';
    cErrorText := 'No data!';
    MAIL_FILE_BIDBDBADMIN(in_to_name => 'shuchin@ms.usi.com.tw', subject => '[VQA] PL/SQL VQA_PLSQL_STS_MM_MANFU_PN ERROR', message => '[VQA_050_STS_WEEKLY_MANFU_PN], The tracepoint is  ' || iTracePoint || ' and ErrorText= ' || cErrorText) ;
  else

  --清除重覆資料 VQA_051_STS_MONTHLY_MANFU_PN
      DELETE FROM VQA_051_STS_MONTHLY_MANFU_PN where YYYY =  substr(vPROCEE_YYYYMM,1,4)
                                                 and MM =   substr(vPROCEE_YYYYMM,5,2);
    Commit;

  --抓 Weekly 資料放到 VQA_051_STS_MONTHLY_MANFU_PN -Monthly
  iTracePoint := '300';
    insert into VQA_051_STS_MONTHLY_MANFU_PN ( COMPANY_CODE, YYYY, MM, QUARTER, MANUF, PART_NO, PTYPE, MATGROUP, STS_LOT_CNT, LOT_CNT, PERCENTAGE, DATE_TIME, YYYYMM, FSI, TOT_LOT )
    Select COMPANY_CODE, YYYY, MM,  QUARTER, MANUF, PART_NO, PTYPE, MATGROUP, sum(STS_LOT_CNT), sum(LOT_CNT), (sum(STS_LOT_CNT) / sum(LOT_CNT) * 100 ) as PERCENTAGE, to_char(SYSDATE, 'yyyymmddhh24miss') as DATE_TIME, YYYY || MM as YYYYMM, sum(FSI), sum(TOT_LOT)
                 from (
     Select a.COMPANY_CODE, a.YYYY, a.MM, b.QUARTER, a.MANUF, a.PART_NO, a.PTYPE, a.MATGROUP, a.STS_LOT_CNT, a.LOT_CNT, a.PERCENTAGE, a.DATE_TIME,  a.YYYY || a.MM, a.FSI, a.TOT_LOT
       from VQA_050_STS_WEEKLY_MANFU_PN  a, DIMENSION_DATE b
         where a.YYYY = substr(vPROCEE_YYYYMM,1,4)
           and a.MM = substr(vPROCEE_YYYYMM,5,2)
           and b.DATE_KEY = substr(vPROCEE_YYYYMMDD,1,8)
       ) group by COMPANY_CODE, YYYY, MM, QUARTER, MANUF, PART_NO, PTYPE, MATGROUP;
       commit;



--計算 月- STS WW 資料
  VQA_PLSQL_STS_MM_MANFU_PN_WW;

  end if;



EXCEPTION
   When OTHERS Then
    --有錯誤產生則寄mail
    cErrorText := SQLERRM();
    MAIL_FILE_BIDBDBADMIN(in_to_name => 'shuchin_lin@usiglobal.com', subject => '[VQA] PL/SQL VQA_PLSQL_STS_MM_MANFU_PN ERROR', message => '[VQA_050_STS_WEEKLY_MANFU_PN], The tracepoint is  ' || iTracePoint || ' and ErrorText= ' || cErrorText) ;

END VQA_PLSQL_STS_MM_MANFU_PN;
/

