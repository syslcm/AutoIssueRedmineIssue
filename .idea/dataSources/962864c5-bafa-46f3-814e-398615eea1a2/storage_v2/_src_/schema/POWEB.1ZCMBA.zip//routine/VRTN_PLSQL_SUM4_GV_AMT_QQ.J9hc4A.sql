create PROCEDURE         "VRTN_PLSQL_SUM4_GV_AMT_QQ" IS

    /*
     每季執行一次
     1. 抓 PLD_KPI_IR_DETAIL 資料
     2. Insert to VRTN_SUM09_AMT_GV_MATGP_Q table&
                  VRTN_SUM10_AMT_GV_VM_Q table
         By Susan 2007/06/27
     */


 vPROCEE_YYYYMMDD varchar2(8);
 vPROCEE_YYYYMM   varchar2(6);
 iTracePoint      varchar2(100);
 cErrorText       varchar2(500);
 vCOMPANY_CODE    varchar2(4);
 vYYYYMM          varchar2(6);
 vSTART_DATE      varchar2(8);
 vEND_DATE        varchar2(8);
 vQUARTER         varchar2(8);
 vCK_GV_VENDOR    varchar2(10);

BEGIN
    vCOMPANY_CODE := null;
    vYYYYMM := null;
    vSTART_DATE := null;
    vEND_DATE := null;
    vQUARTER := null;
	vCK_GV_VENDOR := null;

   --抓上個月資料
     iTracePoint := '100';
     vPROCEE_YYYYMM := TO_CHAR(ADD_MONTHS(SYSDATE, -1), 'YYYYMM');
   --抓季資料
      for REC1 in (Select QUARTER
                          FROM DIMENSION_DATE
                          WHERE YYYY = SUBSTRB(vPROCEE_YYYYMM,1,4)
                            AND MM = SUBSTRB(vPROCEE_YYYYMM,5,2)
                            ) loop
         vQUARTER := SUBSTRB(vPROCEE_YYYYMM,1,4) || REC1.QUARTER;
      end loop;
    --抓季起始區間資料
         for REC1 in (Select MIN(DATE_KEY) AS DATE_KEY
                             FROM DIMENSION_DATE
                             WHERE QUARTER = SUBSTRB(vQUARTER,5,2)
                               AND YYYY = SUBSTRB(vQUARTER,1,4)
                               ) loop
            vSTART_DATE := REC1.DATE_KEY;
         end loop;
    --抓季終上區間資料
        for REC1 in (Select MAX(DATE_KEY) AS DATE_KEY
                            FROM DIMENSION_DATE
                            WHERE QUARTER = SUBSTRB(vQUARTER,5,2)
                              AND YYYY = SUBSTRB(vQUARTER,1,4)
                             ) loop
            vEND_DATE := REC1.DATE_KEY;
        end loop;



  if vQUARTER is null then
     --若沒抓到資料則寄 error mail
     iTracePoint := '110';
     cErrorText := 'QUARTER error!';
     MAIL_FILE_BIDBDBADMIN(in_to_name => 'shuchin_lin@usiglobal.com', subject => '[VRT] PL/SQL VRTN_PLSQL_SUM4_GV_AMT_QQ ERROR', message => '[VRTN_PLSQL_SUM4_GV_AMT_QQ], The tracepoint is  ' || iTracePoint || ' and ErrorText= ' || cErrorText) ;
  else

     --清除舊的 VRTN_SUM09_AMT_GV_MATGP_Q 資料
       iTracePoint := '200';
       DELETE FROM VRTN_SUM09_AMT_GV_MATGP_Q WHERE QUARTER = SUBSTRB(vQUARTER,1,6);

     --放入季Amount
       iTracePoint := '210';
        for REC1 in ( Select GV_VENDOR, MATGROUP, QUARTER, round(SUM(AMOUNT), 2) as Q_AMOUNT
                             from VRTN_SUM07_AMT_GV_MATGP_M
                             where GV_VENDOR is Not Null
                               and MATGROUP is Not Null
                               and QUARTER = SUBSTRB(vQUARTER,1,6)
                    Group by GV_VENDOR, MATGROUP, QUARTER
                    ) loop
      --放到 VRTN_SUM09_AMT_GV_MATGP_Q
      iTracePoint := '220-' || REC1.GV_VENDOR || '-' || REC1.MATGROUP || '-' || vPROCEE_YYYYMM || REC1.QUARTER;
      insert into VRTN_SUM09_AMT_GV_MATGP_Q (
                  GV_VENDOR, MATGROUP, QUARTER, Q_AMOUNT, FROM_DATE, TO_DATE, VENDOR, SITE, DATE_TIME
           ) values (
           REC1.GV_VENDOR,
           REC1.MATGROUP,
           REC1.QUARTER,
           REC1.Q_AMOUNT,
           vSTART_DATE,
           vEND_DATE,
           '',
           '',
           to_char(sysdate,'YYYYMMDD')
           );
      commit;
    end loop;
  end if;


  --Process By Vendor
   iTracePoint := '300';
   for REC1 in ( Select GV_VENDOR, QUARTER
                        from VRTN_SUM09_AMT_GV_MATGP_Q
                        where GV_VENDOR is Not Null
                          and MATGROUP is Not Null
                          and QUARTER = SUBSTRB(vQUARTER,1,6)
                    ) loop
     vCK_GV_VENDOR := REC1.GV_VENDOR;
   end loop;
  if vCK_GV_VENDOR is null then
     --若沒抓到資料則寄 error mail
     iTracePoint := '400';
     cErrorText := 'VRTN_SUM09_AMT_GV_MATGP_Q - NO DATA!';
     MAIL_FILE_BIDBDBADMIN(in_to_name => 'shuchin_lin@usiglobal.com', subject => '[VRT] PL/SQL VRTN_PLSQL_SUM4_GV_AMT_QQ ERROR', message => '[VRTN_PLSQL_SUM4_GV_AMT_QQ], The tracepoint is  ' || iTracePoint || ' and ErrorText= ' || cErrorText) ;
  else

     --清除舊的 VRTN_SUM10_AMT_GV_VM_Q 資料
       iTracePoint := '500';
       DELETE FROM VRTN_SUM10_AMT_GV_VM_Q WHERE QUARTER = SUBSTRB(vQUARTER,1,6);

     --抓季Amount
       iTracePoint := '510';
        for REC1 in ( Select GV_VENDOR, QUARTER, round(SUM(Q_AMOUNT), 2) as Q_AMOUNT
                             from VRTN_SUM09_AMT_GV_MATGP_Q
                             where GV_VENDOR is Not Null
                               and MATGROUP is Not Null
                               and QUARTER = SUBSTRB(vQUARTER,1,6)
                    Group by GV_VENDOR, QUARTER
                    ) loop
      --放到 VRTN_SUM10_AMT_GV_VM_Q
      iTracePoint := '520-' || REC1.GV_VENDOR || '-' || vPROCEE_YYYYMM || REC1.QUARTER;
      insert into VRTN_SUM10_AMT_GV_VM_Q(
                  GV_VENDOR, QUARTER, Q_AMOUNT, FROM_DATE, TO_DATE, VENDOR, SITE, DATE_TIME
           ) values (
           REC1.GV_VENDOR,
           REC1.QUARTER,
           REC1.Q_AMOUNT,
           vSTART_DATE,
           vEND_DATE,
           '',
           '',
           to_char(sysdate,'YYYYMMDD')
           );
      commit;
    end loop;
  end if;


EXCEPTION
   When OTHERS Then
    --有錯誤產生則寄mail
      cErrorText := SQLERRM();
      MAIL_FILE_BIDBDBADMIN(in_to_name => 'shuchin_lin@usiglobal.com', subject => '[VRT] PL/SQL VRTN_PLSQL_SUM4_GV_AMT_QQ ERROR', message => '[VRTN_PLSQL_SUM4_GV_AMT_QQ], The tracepoint is  ' || iTracePoint || ' and ErrorText= ' || cErrorText);


END VRTN_PLSQL_SUM4_GV_AMT_QQ;
/

