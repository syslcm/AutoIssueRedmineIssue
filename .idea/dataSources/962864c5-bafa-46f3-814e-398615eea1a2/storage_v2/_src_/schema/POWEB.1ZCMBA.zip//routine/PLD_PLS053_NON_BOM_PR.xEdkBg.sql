create PROCEDURE       PLD_PLS053_NON_BOM_PR (
/* ********************************************************************
  PROG-ID      : PLD_PLS053_NON_BOM_PR
  PROG-ACTION  : 
  Author       : Asan Chang
  Date         : 2016/07/26
  OA Number    : SAI061837
********************************************************************* */
   incompany    IN   VARCHAR2,
   f_yyyymmdd   IN   VARCHAR2,
   t_yyyymmdd   IN   VARCHAR2
)
AUTHID DEFINER
IS
   CURSOR pld_kpi_non_bom_pr_t
   IS
      SELECT COMPANY_CODE, REQ_DATE, RELEASE_DATE, PR_NO, PR_ITEM , MATERIAL, ITEM_CATEGORY ,   
      ACCOUNT_ASSIGN_CATEGORY, MATERIAL_GROUP, RELEASE_QTY, PR_UNIT, PO_DATE, PO_NO, PO_ITEM ,         
      ORDERED_QTY, PO_UNIT, BUYER_CODE, GL_ACCOUNT, COST_CENTER, PROFIT_CENTER, MAIN_ASSET_NO,     
      ITEM_TXT, SO_NO, SO_ITEM, SHORT_TEXT, PR_ITEM_TEXT1, PR_ITEM_TEXT2, PR_ITEM_TEXT3, PR_ITEM_TEXT4 ,   
      PR_ITEM_TEXT5, PR_ITEM_TEXT6, PR_ITEM_NOTE1, PR_ITEM_NOTE2, PR_ITEM_NOTE3, PR_ITEM_NOTE4, 
      PR_ITEM_NOTE5, PR_ITEM_NOTE6, MM03_MAT_PO_TEXT1, MM03_MAT_PO_TEXT2, MM03_MAT_PO_TEXT3, 
      MM03_MAT_PO_TEXT4, MM03_MAT_PO_TEXT5, MM03_MAT_PO_TEXT6, MFRPN, PR_PO_QTY, OVER_DAYS,
      PR_REQUISITIONER, BUYER_NAME
        
                 

      FROM pld_kpi_non_bom_pr_t
      where COMPANY_CODE = incompany;


   itracepoint   INTEGER;
BEGIN


   --(1)清除舊的 pld_kpi_non_bom_pr 資料

   DELETE FROM pld_kpi_non_bom_pr
   where CREATE_DATE <> sysdate
   AND COMPANY_CODE = incompany;
   COMMIT;


   FOR REC1 IN pld_kpi_non_bom_pr_t LOOP
   
 
   
   
   --(3)開始處理資料
       INSERT INTO pld_kpi_non_bom_pr (
          COMPANY_CODE,          REQ_DATE,            RELEASE_DATE,                 PR_NO, 
          PR_ITEM ,              MATERIAL,            ITEM_CATEGORY ,               ACCOUNT_ASSIGN_CATEGORY, 
          MATERIAL_GROUP,        RELEASE_QTY,         PR_UNIT,                      PO_DATE, 
          PO_NO,                 PO_ITEM ,            ORDERED_QTY,                  PO_UNIT, 
          BUYER_CODE,            GL_ACCOUNT,          COST_CENTER,                  PROFIT_CENTER, 
          MAIN_ASSET_NO,         ITEM_TXT,            SO_NO,                        SO_ITEM, 
          SHORT_TEXT,            PR_ITEM_TEXT1,       PR_ITEM_TEXT2,                PR_ITEM_TEXT3, 
          PR_ITEM_TEXT4 ,        PR_ITEM_TEXT5,       PR_ITEM_TEXT6,                PR_ITEM_NOTE1, 
          PR_ITEM_NOTE2,         PR_ITEM_NOTE3,       PR_ITEM_NOTE4,                PR_ITEM_NOTE5, 
          PR_ITEM_NOTE6,         MM03_MAT_PO_TEXT1,   MM03_MAT_PO_TEXT2,            MM03_MAT_PO_TEXT3, 
          MM03_MAT_PO_TEXT4,     MM03_MAT_PO_TEXT5,   MM03_MAT_PO_TEXT6,            MFRPN, 
          PR_PO_QTY,             OVER_DAYS,           PR_REQUISITIONER,             BUYER_NAME
          ) VALUES (
                 
          REC1.COMPANY_CODE,to_date(REC1.REQ_DATE, 'yyyy/mm/dd'),to_date(REC1.RELEASE_DATE, 'yyyy/mm/dd'),REC1.PR_NO, 
          REC1.PR_ITEM ,         REC1.MATERIAL,       REC1.ITEM_CATEGORY ,          REC1.ACCOUNT_ASSIGN_CATEGORY, 
          REC1.MATERIAL_GROUP,   REC1.RELEASE_QTY,    REC1.PR_UNIT,                 REC1.PO_DATE, 
          REC1.PO_NO,            REC1.PO_ITEM ,       REC1.ORDERED_QTY,             REC1.PO_UNIT, 
          REC1.BUYER_CODE,       REC1.GL_ACCOUNT,     REC1.COST_CENTER,             REC1.PROFIT_CENTER, 
          REC1.MAIN_ASSET_NO,    REC1.ITEM_TXT,       REC1.SO_NO,                   REC1.SO_ITEM, 
          REC1.SHORT_TEXT,       REC1.PR_ITEM_TEXT1,  REC1.PR_ITEM_TEXT2,           REC1.PR_ITEM_TEXT3, 
          REC1.PR_ITEM_TEXT4 ,   REC1.PR_ITEM_TEXT5,  REC1.PR_ITEM_TEXT6,           REC1.PR_ITEM_NOTE1, 
          REC1.PR_ITEM_NOTE2,    REC1.PR_ITEM_NOTE3,  REC1.PR_ITEM_NOTE4,           REC1.PR_ITEM_NOTE5, 
          REC1.PR_ITEM_NOTE6,    REC1.MM03_MAT_PO_TEXT1,REC1.MM03_MAT_PO_TEXT2,     REC1.MM03_MAT_PO_TEXT3, 
          REC1.MM03_MAT_PO_TEXT4,REC1.MM03_MAT_PO_TEXT5,REC1.MM03_MAT_PO_TEXT6,     REC1.MFRPN, 
          REC1.PR_PO_QTY,        REC1.OVER_DAYS,      REC1.PR_REQUISITIONER,        REC1.BUYER_NAME
           );    
       COMMIT;

   END LOOP;

   --(4) 刪除資料


   DELETE FROM pld_kpi_non_bom_pr_t
   WHERE COMPANY_CODE = incompany;
   COMMIT;

   --(4) Send Mail
END PLD_PLS053_NON_BOM_PR;
/

