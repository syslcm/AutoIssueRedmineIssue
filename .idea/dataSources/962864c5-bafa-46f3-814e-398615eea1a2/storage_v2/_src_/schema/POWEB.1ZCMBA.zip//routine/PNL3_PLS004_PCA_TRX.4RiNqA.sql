create PROCEDURE       PNL3_PLS004_PCA_TRX (
  --inCompany  in VARCHAR2,
  t_Period in VARCHAR2
  --2008/11/4 ADD KPI_UPL001_REVENUE_TRX 
  --2009/1/20 User要新增數量欄位,考慮到程式將REVENUE/COGS拆成四筆,數量不能四筆都塞會變成4倍,因此只放在REVENEU即可,原本只有AMT<>0的才會寫到資料庫,修改成REVENUE不控此<>0條件
--保證QTY都會寫到REVENUE那筆去
--2009/1/20 增加project name,project type
--2011/5/18 END CUSTOMER ID都是空白,檢查後發現沒有by company 會抓到兩筆,改加入COMPANY CODE, 是因為distinct的問題,所以變成exception 嗎???
)
AUTHID DEFINER
is
  CURSOR C_PNL3_PLS001_R is
      SELECT COMPANY_CODE,PERIOD,PROFIT_CENTER,PARTNER_PROFIT_CENTER,CUSTOMER_ID as BILL_TO_PARTY,MTL_GROUP,PART_NO,PLANT_CODE,MTL_TYPE,TRNX_TYPE,
             nvl(SUM(NET_REVENUE),0) AMT_LOCAL,nvl(SUM(NET_REVENUE_USD),0) AMT_USD,nvl(SUM(NET_REVENUE_TWD),0) AMT_TWD,
             nvl(SUM(COGS_MB),0) COGS_DM_LOCAL,nvl(SUM(COGS_MB_USD),0) COGS_DM_USD,nvl(SUM(COGS_MB_TWD),0) COGS_DM_TWD,
             nvl(SUM(COGS_LB),0) COGS_DL_LOCAL,nvl(SUM(COGS_LB_USD),0) COGS_DL_USD,nvl(SUM(COGS_LB_TWD),0) COGS_DL_TWD,
             nvl(SUM(COGS_OB),0) COGS_OH_LOCAL,nvl(SUM(COGS_OB_USD),0) COGS_OH_USD,nvl(SUM(COGS_OB_TWD),0) COGS_OH_TWD,
             nvl(SUM(NET_QTY),0) NET_QTY
                     FROM KPI_SAP002_PCA_TRX
       WHERE  PERIOD = t_Period 
         AND    ( NET_REVENUE <> 0 OR NET_COGS <>  0)
    GROUP BY COMPANY_CODE,PERIOD,PROFIT_CENTER,PARTNER_PROFIT_CENTER,CUSTOMER_ID,MTL_GROUP,PART_NO,PLANT_CODE,MTL_TYPE,TRNX_TYPE
      HAVING ( SUM(NET_REVENUE) <> 0 OR SUM(NET_COGS)  <> 0 );

  a_ENDCUSTOMER   PNL3_TRX001_COPA.END_CUSTOMER_ID%TYPE;
      
 BEGIN
   DELETE FROM PNL3_TRX004_PCA
   WHERE Period = t_Period ;
   Commit;
    FOR REC1 in C_PNL3_PLS001_R Loop
      IF REC1.TRNX_TYPE = 'PCA' THEN
         a_ENDCUSTOMER := NULL;
         BEGIN
           SELECT DISTINCT END_CUSTOMER_ID INTO a_ENDCUSTOMER
             FROM KPI_MAP011_PROFIT_CENTER_MAP
            WHERE PARTNER_PROFIT_CENTER = REC1.PARTNER_PROFIT_CENTER
              AND COMPANY_CODE = REC1.COMPANY_CODE --2011/5/18
              AND TO_CHAR(START_DATE,'YYYYMM') <= REC1.PERIOD 
              AND TO_CHAR(END_DATE,'YYYYMM') >= REC1.PERIOD;
         EXCEPTION
            WHEN OTHERS Then
              a_ENDCUSTOMER := NULL;
         END;
      ELSIF REC1.TRNX_TYPE = 'PRG' THEN
         IF REC1.PROFIT_CENTER = 'USI-COMMON' THEN
           a_ENDCUSTOMER := NULL;
           BEGIN
             SELECT DISTINCT END_CUSTOMER_ID INTO a_ENDCUSTOMER
               FROM KPI_MAP011_PROFIT_CENTER_MAP  --2011/5/18
              WHERE PARTNER_PROFIT_CENTER = REC1.PARTNER_PROFIT_CENTER
                AND COMPANY_CODE = REC1.COMPANY_CODE
                AND TO_CHAR(START_DATE,'YYYYMM') <= REC1.PERIOD 
                AND TO_CHAR(END_DATE,'YYYYMM') >= REC1.PERIOD;
           EXCEPTION
               WHEN OTHERS Then
                a_ENDCUSTOMER := NULL;
           END;
         ELSE
           a_ENDCUSTOMER := NULL;
           BEGIN
             SELECT DISTINCT END_CUSTOMER_ID INTO a_ENDCUSTOMER
               FROM KPI_MAP011_PROFIT_CENTER_MAP --2011/5/18
              WHERE PARTNER_PROFIT_CENTER = REC1.PROFIT_CENTER
                AND COMPANY_CODE = REC1.COMPANY_CODE
                AND TO_CHAR(START_DATE,'YYYYMM') <= REC1.PERIOD 
                AND TO_CHAR(END_DATE,'YYYYMM') >= REC1.PERIOD;
           EXCEPTION
               WHEN OTHERS Then
                a_ENDCUSTOMER := NULL;
           END;
         END IF;
      END IF;
         --IF REC1.AMT_LOCAL <> 0 THEN
           Insert into PNL3_TRX004_PCA (
                COMPANY_CODE    , PERIOD         , PROFIT_CENTER      , BILL_TO_PARTY ,  MTL_GROUP, PART_NO,PLANT_CODE,
                AMT_LOCAL      , AMT_USD            , AMT_TWD         , SOURCE          ,MTL_TYPE, END_CUSTOMER_ID,
                R_KIND          , AREA1          ,AREA2               , AREA3            ,NET_QTY,
                CREATE_DATE
                      ) VALUES (
                        REC1.COMPANY_CODE       , REC1.PERIOD       , REC1.PROFIT_CENTER      , REC1.BILL_TO_PARTY , REC1.MTL_GROUP, REC1.PART_NO,REC1.PLANT_CODE,
                        REC1.AMT_LOCAL * -1   , REC1.AMT_USD * -1            , REC1.AMT_TWD * -1            , 'PCA'               ,REC1.MTL_TYPE,a_ENDCUSTOMER,
                        'PL01'                  , '1'                 ,'1'                       , '0'      ,REC1.NET_QTY                 ,
                        SYSDATE );
            Commit;
          --END IF;
          IF REC1.COGS_DM_LOCAL <> 0 THEN
            Insert into PNL3_TRX004_PCA (
                   COMPANY_CODE    , PERIOD         , PROFIT_CENTER      , BILL_TO_PARTY ,  MTL_GROUP, PART_NO,PLANT_CODE,
                   AMT_LOCAL      , AMT_USD            , AMT_TWD         , SOURCE          ,MTL_TYPE,END_CUSTOMER_ID,
                   R_KIND          , AREA1          ,AREA2               , AREA3            ,
                   CREATE_DATE
                   ) VALUES (
                        REC1.COMPANY_CODE       , REC1.PERIOD       , REC1.PROFIT_CENTER      , REC1.BILL_TO_PARTY ,  REC1.MTL_GROUP, REC1.PART_NO,REC1.PLANT_CODE,
                        REC1.COGS_DM_LOCAL, REC1.COGS_DM_USD        , REC1.COGS_DM_TWD        , 'PCA'               ,REC1.MTL_TYPE,a_ENDCUSTOMER,
                        'PL01'                  , '2'                 , '2'                       , '0'                    ,
                        SYSDATE 
                   );
             Commit;
          END IF;
          
          IF REC1.COGS_DL_LOCAL <> 0 THEN
            Insert into PNL3_TRX004_PCA (
                   COMPANY_CODE    , PERIOD         , PROFIT_CENTER      , BILL_TO_PARTY ,  MTL_GROUP, PART_NO,PLANT_CODE,
                   AMT_LOCAL      , AMT_USD            , AMT_TWD         , SOURCE          ,MTL_TYPE,END_CUSTOMER_ID,
                   R_KIND          , AREA1          ,AREA2               , AREA3            ,
                   CREATE_DATE
                   ) VALUES (
                        REC1.COMPANY_CODE       , REC1.PERIOD       , REC1.PROFIT_CENTER      , REC1.BILL_TO_PARTY ,  REC1.MTL_GROUP, REC1.PART_NO,REC1.PLANT_CODE,
                        REC1.COGS_DL_LOCAL, REC1.COGS_DL_USD        , REC1.COGS_DL_TWD        , 'PCA'               ,REC1.MTL_TYPE,a_ENDCUSTOMER,
                        'PL01'                  , '2'                 , '3'                       , '0'                    ,
                        SYSDATE 
                   );
             Commit;
          END IF;
          
          
          IF REC1.COGS_OH_LOCAL <> 0 THEN
            Insert into PNL3_TRX004_PCA (
                   COMPANY_CODE    , PERIOD         , PROFIT_CENTER      , BILL_TO_PARTY ,  MTL_GROUP, PART_NO,PLANT_CODE,
                   AMT_LOCAL      , AMT_USD            , AMT_TWD         , SOURCE          ,MTL_TYPE, END_CUSTOMER_ID,
                   R_KIND          , AREA1          ,AREA2               , AREA3            ,
                   CREATE_DATE
                   ) VALUES (
                        REC1.COMPANY_CODE       , REC1.PERIOD       , REC1.PROFIT_CENTER      , REC1.BILL_TO_PARTY , REC1.MTL_GROUP, REC1.PART_NO,REC1.PLANT_CODE,
                        REC1.COGS_OH_LOCAL, REC1.COGS_OH_USD        , REC1.COGS_OH_TWD        , 'PCA'               ,REC1.MTL_TYPE,a_ENDCUSTOMER,
                        'PL01'                  , '2'                 , '4'                      , '0'                    ,
                        SYSDATE 
                   );
             Commit;
          END IF;

    END LOOP;

       UPDATE PNL3_TRX004_PCA
      SET project_name =
             (SELECT DISTINCT TRIM (sap_project_name)
                         FROM cep_map010_partno_project
                        WHERE fg_material_no =
                                      RPAD (PNL3_TRX004_PCA.part_no, 18, ' '))
    WHERE period = t_period;

   commit;
   
   UPDATE PNL3_TRX004_PCA
      SET project_TYPE =
             (SELECT DISTINCT TRIM (PROJECT_TYPE)
                         FROM CEP_WEB002_PROJECT
                        WHERE PROJECT_NAME = PNL3_TRX004_PCA.PROJECT_NAME)
                                      --RPAD (PNL3_TRX004_PCA.PROJECT_NAME, 30, ' '))
    WHERE period = t_period;

   commit;
END PNL3_PLS004_PCA_TRX;
/

