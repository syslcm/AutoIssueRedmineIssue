create PROCEDURE       PNL2_PLS004_COGS_S01_TRX_V1 (
  inCOMPANY       in VARCHAR2,
  inPeriod        in VARCHAR2,
  inPROFIT_CENTER in VARCHAR2,
  inAMT           in Number,
  inGLAccount     in VARCHAR
  -----------------------------------------
  --Keep 2008/10/16 Version
  -----------------------------------------
)
AUTHID DEFINER
is

     
     a_Rate          PNL2_UPL003_REALIZED_GM.EX_RATE_USD%TYPE;
     a_ENDCUSTOMER   KPI_SAP001_COPA_TRX.END_CUSTOMER_ID%TYPE;
     a_NET_REVENUE   KPI_SAP001_COPA_TRX.NET_REVENUE%TYPE;
     a_REVENUE_LOCAL KPI_SAP001_COPA_TRX.NET_REVENUE%TYPE;
     a_REVENUE_TWD   KPI_SAP001_COPA_TRX.NET_REVENUE%TYPE;
     a_REVENUE_USD   KPI_SAP001_COPA_TRX.NET_REVENUE%TYPE;
     a_COGS_DM_LOCAL KPI_SAP001_COPA_TRX.NET_REVENUE%TYPE;
     a_COGS_DM_TWD   KPI_SAP001_COPA_TRX.NET_REVENUE%TYPE;
     a_COGS_DM_USD   KPI_SAP001_COPA_TRX.NET_REVENUE%TYPE;
     a_COGS_DL_LOCAL KPI_SAP001_COPA_TRX.NET_REVENUE%TYPE;
     a_COGS_DL_TWD   KPI_SAP001_COPA_TRX.NET_REVENUE%TYPE;
     a_COGS_DL_USD   KPI_SAP001_COPA_TRX.NET_REVENUE%TYPE;
     a_COGS_OH_LOCAL KPI_SAP001_COPA_TRX.NET_REVENUE%TYPE;
     a_COGS_OH_TWD   KPI_SAP001_COPA_TRX.NET_REVENUE%TYPE;
     a_COGS_OH_USD   KPI_SAP001_COPA_TRX.NET_REVENUE%TYPE;
     
 BEGIN
   

      a_RATE  := 0;
      FOR REC1 in (SELECT END_CUSTOMER_ID,SUM(NET_REVENUE_TWD) AMT_TWD FROM KPI_SAP001_COPA_TRX 
                      WHERE COMPANY_CODE = inCOMPANY 
                        AND PROFIT_CENTER = inPROFIT_CENTER
                        AND PERIOD = inPeriod
                        AND RELATED_PARTY <> 'Y'
                        AND NET_REVENUE <> 0
                        GROUP BY END_CUSTOMER_ID) Loop
        a_Rate := REC1.AMT_TWD / inAMT;
        a_REVENUE_LOCAL := 0;
        a_REVENUE_TWD   := 0;
        a_REVENUE_USD   := 0;
        a_COGS_DM_LOCAL := 0;
        a_COGS_DM_TWD   := 0;
        a_COGS_DM_USD   := 0;
        a_COGS_DL_LOCAL := 0;
        a_COGS_DL_TWD   := 0;
        a_COGS_DL_USD   := 0;
        a_COGS_OH_LOCAL := 0;
        a_COGS_OH_TWD   := 0;
        a_COGS_OH_USD   := 0;
        BEGIN
            SELECT SUM(NET_REVENUE), SUM(NET_REVENUE_USD), SUM(NET_REVENUE_TWD) ,
                              SUM(COGS_MB) ,SUM(COGS_MB_USD) ,SUM(COGS_MB_TWD) ,
                              SUM(COGS_LB) ,SUM(COGS_LB_USD) ,SUM(COGS_LB_TWD) ,
                              SUM(COGS_OB) ,SUM(COGS_OB_USD) ,SUM(COGS_OB_TWD) 
              INTO a_REVENUE_LOCAL,a_REVENUE_USD,a_REVENUE_TWD,
                   a_COGS_DM_LOCAL,a_COGS_DM_USD,a_COGS_DM_TWD,
                   a_COGS_DL_LOCAL,a_COGS_DL_USD,a_COGS_DL_TWD,
                   a_COGS_OH_LOCAL,a_COGS_OH_USD,a_COGS_OH_TWD
              FROM KPI_SAP001_COPA_TRX
             WHERE  PERIOD = inPeriod 
               AND  COMPANY_CODE = inCOMPANY
               AND  PROFIT_CENTER = inPROFIT_CENTER
               AND    ( NET_REVENUE <> 0 OR NET_COGS <>  0)
               AND    RELATED_PARTY <> 'Y'
               AND    END_CUSTOMER_ID IS NULL
               AND COST_ELEMENT = inGLAccount
          GROUP BY COMPANY_CODE,PROFIT_CENTER,PERIOD
            HAVING ( SUM(NET_REVENUE) <> 0 OR SUM(NET_COGS)  <> 0 );
        EXCEPTION
          WHEN OTHERS Then
             a_REVENUE_LOCAL := 0;
             a_REVENUE_TWD   := 0;
             a_REVENUE_USD   := 0;
             a_COGS_DM_LOCAL := 0;
             a_COGS_DM_TWD   := 0;
             a_COGS_DM_USD   := 0;
             a_COGS_DL_LOCAL := 0;
             a_COGS_DL_TWD   := 0;
             a_COGS_DL_USD   := 0;
             a_COGS_OH_LOCAL := 0;
             a_COGS_OH_TWD   := 0;
             a_COGS_OH_USD   := 0;
        END;
        
        IF a_REVENUE_LOCAL <> 0 THEN
           INSERT INTO PNL2_TRX002_GLACCOUNT (
               COMPANY_CODE         ,PERIOD       ,PROFIT_CENTER   ,COST_ELEMENT ,
               END_CUSTOMER_ID      ,R_KIND       ,AREA1           ,AREA2        ,
               AREA3                ,AMT_LOCAL    ,AMT_TWD         ,AMT_USD      ,
               CREATE_DATE
           ) VALUES(
               inCOMPANY            ,inPeriod     ,inPROFIT_CENTER,inGLAccount   ,
               REC1.END_CUSTOMER_ID ,'PL01'       ,1               ,1            ,
               0                    ,round(a_REVENUE_LOCAL * a_RATE , 5)         ,
               round(a_REVENUE_TWD * a_RATE , 5)  ,
               round(a_REVENUE_USD * a_RATE , 5)  , SYSDATE
           );
           commit;
        END IF;
        
        IF a_COGS_DM_LOCAL <> 0 THEN
           INSERT INTO PNL2_TRX002_GLACCOUNT (
               COMPANY_CODE         ,PERIOD       ,PROFIT_CENTER   ,COST_ELEMENT ,
               END_CUSTOMER_ID      ,R_KIND       ,AREA1           ,AREA2        ,
               AREA3                ,AMT_LOCAL    ,AMT_TWD         ,AMT_USD      ,
               CREATE_DATE
           ) VALUES(
               inCOMPANY            ,inPeriod     ,inPROFIT_CENTER,inGLAccount   ,
               REC1.END_CUSTOMER_ID ,'PL01'       ,2               ,2            ,
               0                    ,round(a_COGS_DM_LOCAL * a_RATE , 5)         ,
               round(a_COGS_DM_TWD * a_RATE , 5)  ,
               round(a_COGS_DM_USD * a_RATE , 5)  , SYSDATE
           );
           commit;
        END IF;
        
        IF a_COGS_DL_LOCAL <> 0 THEN
           INSERT INTO PNL2_TRX002_GLACCOUNT (
               COMPANY_CODE         ,PERIOD       ,PROFIT_CENTER   ,COST_ELEMENT ,
               END_CUSTOMER_ID      ,R_KIND       ,AREA1           ,AREA2        ,
               AREA3                ,AMT_LOCAL    ,AMT_TWD         ,AMT_USD      ,
               CREATE_DATE
           ) VALUES(
               inCOMPANY            ,inPeriod     ,inPROFIT_CENTER,inGLAccount   ,
               REC1.END_CUSTOMER_ID ,'PL01'       ,2               ,3            ,
               0                    ,round(a_COGS_DL_LOCAL * a_RATE , 5)         ,
               round(a_COGS_DL_TWD * a_RATE , 5)  ,
               round(a_COGS_DL_USD * a_RATE , 5)  , SYSDATE
           );
           commit;
        END IF;
        
        IF a_COGS_OH_LOCAL <> 0 THEN
           INSERT INTO PNL2_TRX002_GLACCOUNT (
               COMPANY_CODE         ,PERIOD       ,PROFIT_CENTER   ,COST_ELEMENT ,
               END_CUSTOMER_ID      ,R_KIND       ,AREA1           ,AREA2        ,
               AREA3                ,AMT_LOCAL    ,AMT_TWD         ,AMT_USD      ,
               CREATE_DATE
           ) VALUES(
               inCOMPANY            ,inPeriod     ,inPROFIT_CENTER,inGLAccount   ,
               REC1.END_CUSTOMER_ID ,'PL01'       ,2               ,4            ,
               0                    ,round(a_COGS_OH_LOCAL * a_RATE , 5)         ,
               round(a_COGS_OH_TWD * a_RATE , 5)  ,
               round(a_COGS_OH_USD * a_RATE , 5)  , SYSDATE
           );
           commit;
        END IF;
                       
      END LOOP;
 
   
   
   
    
END PNL2_PLS004_COGS_S01_TRX_V1;
/

