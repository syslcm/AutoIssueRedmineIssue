create PROCEDURE "VRTN_TEST1"
IS

    /*
         TEST SITE DATA
         By Susan 2007/08/17
     */


 vPROCEE_YYYYMMDD varchar2(8);
 vPROCEE_YYYYMM   varchar2(6);
 iTracePoint      varchar2(100);
 cErrorText       varchar2(500);
 vCOMPANY_CODE    varchar2(4);
 vYYYYMM          varchar2(6);
 vSTART_DATE      varchar2(8);
 vEND_DATE        varchar2(8);
 vQUARTER         varchar2(8);
 vCK_GV_VENDOR    varchar2(10);
 vIR_AMT_TWD                PLD_KPI_IR_DETAIL.IR_AMT_TWD%TYPE;

 vTW_SITE  VRTN_SUM14_QQ_MATGP.SITE%TYPE;
 vSZ_SITE  VRTN_SUM14_QQ_MATGP.SITE%TYPE;
 vSH_SITE  VRTN_SUM14_QQ_MATGP.SITE%TYPE;
 vTW_VENDOR  VRTN_SUM14_QQ_MATGP.VENDOR%TYPE;
 vSZ_VENDOR  VRTN_SUM14_QQ_MATGP.VENDOR%TYPE;
 vSH_VENDOR  VRTN_SUM14_QQ_MATGP.VENDOR%TYPE;

BEGIN
    vCOMPANY_CODE := null;
    vYYYYMM := null;
    vSTART_DATE := null;
    vEND_DATE := null;
    vQUARTER := null;
    vCK_GV_VENDOR := null;

--   --抓上個月資料
--     iTracePoint := '100';
--     vPROCEE_YYYYMM := TO_CHAR(ADD_MONTHS(SYSDATE, -1), 'YYYYMM');
--   --抓季資料
--      for REC1 in (Select QUARTER
--                          FROM DIMENSION_DATE
--                          WHERE YYYY = SUBSTRB(vPROCEE_YYYYMM,1,4)
--                            AND MM = SUBSTRB(vPROCEE_YYYYMM,5,2)
--                            ) loop
--         vQUARTER := SUBSTRB(vPROCEE_YYYYMM,1,4) || REC1.QUARTER;
--      end loop;
--    --抓季起始區間資料
--         for REC1 in (Select MIN(DATE_KEY) AS DATE_KEY
--                             FROM DIMENSION_DATE
--                             WHERE QUARTER = SUBSTRB(vQUARTER,5,2)
--                               AND YYYY = SUBSTRB(vQUARTER,1,4)
--                               ) loop
--            vSTART_DATE := REC1.DATE_KEY;
--         end loop;
--    --抓季終上區間資料
--        for REC1 in (Select MAX(DATE_KEY) AS DATE_KEY
--                            FROM DIMENSION_DATE
--                            WHERE QUARTER = SUBSTRB(vQUARTER,5,2)
--                              AND YYYY = SUBSTRB(vQUARTER,1,4)
--                             ) loop
--            vEND_DATE := REC1.DATE_KEY;
--        end loop;

  vQUARTER := '2007Q3';


  if vQUARTER is null then
     --若沒抓到資料則寄 error mail
     iTracePoint := '110';
     cErrorText := 'QUARTER error!';
     MAIL_FILE_BIDBDBADMIN(in_to_name => 'shuchin@ms.usi.com.tw', subject => '[VRTN] PL/SQL VRTN_TEST1 ERROR', message => '[VRTN_TEST1], The tracepoint is  ' || iTracePoint || ' and ErrorText= ' || cErrorText) ;
  else

     for REC1 in (
           select distinct MATGROUP, GV_VENDOR from VRTN_SUM20_GV_QQ_MATGP
                 where QUARTER = vQUARTER
       ) loop
          BEGIN
           vTW_SITE := '1100';
           vSZ_SITE := '1200';
           vSH_SITE := '1500';
           vTW_VENDOR := '';
           vSZ_VENDOR := '';
           vSH_VENDOR := '';
           select * into vTW_VENDOR from (
                  select VENDOR from VRTN_SUM14_QQ_MATGP
                           where QUARTER = vQUARTER
                             and MATGROUP = REC1.MATGROUP
                             and GV_VENDOR = REC1.GV_VENDOR
                             and SITE = vTW_SITE
                                      );
           select * into vSZ_VENDOR from (
                 select VENDOR from VRTN_SUM14_QQ_MATGP
                          where QUARTER = vQUARTER
                            and MATGROUP = REC1.MATGROUP
                            and GV_VENDOR = REC1.GV_VENDOR
                            and SITE = vSZ_SITE
                                     );
           select * into vSH_VENDOR from (
                 select VENDOR from VRTN_SUM14_QQ_MATGP
                          where QUARTER = vQUARTER
                            and MATGROUP = REC1.MATGROUP
                            and GV_VENDOR = REC1.GV_VENDOR
                            and SITE = vSH_SITE
                                     );
          EXCEPTION
             When OTHERS Then
                  vTW_VENDOR := '';
                  vSZ_VENDOR := '';
                  vSH_VENDOR := '';
          END;

          Update VRTN_SUM20_GV_QQ_MATGP
            set TW_VENDOR = vTW_VENDOR,
                SZ_VENDOR = vSZ_VENDOR,
                SH_VENDOR = vSH_VENDOR
          where GV_VENDOR = REC1.GV_VENDOR
            and MATGROUP = REC1.MATGROUP
            and QUARTER = vQUARTER;
          commit;

       end loop;


  end if;

EXCEPTION
   When OTHERS Then
    --有錯誤產生則寄mail
      cErrorText := SQLERRM();
      MAIL_FILE_BIDBDBADMIN(in_to_name => 'shuchin@ms.usi.com.tw', subject => '[VRT] PL/SQL VRTN_TEST1 ERROR', message => '[VRTN_TEST1], The tracepoint is  ' || iTracePoint || ' and ErrorText= ' || cErrorText);


END VRTN_TEST1;
/

