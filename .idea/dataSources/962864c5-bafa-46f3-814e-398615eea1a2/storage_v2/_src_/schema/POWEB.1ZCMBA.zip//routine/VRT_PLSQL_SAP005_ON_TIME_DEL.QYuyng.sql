create PROCEDURE         "VRT_PLSQL_SAP005_ON_TIME_DEL" (
  inCompany  in VARCHAR2,
  f_YYYYMMDD in VARCHAR2,
  t_YYYYMMDD in VARCHAR2
)
AUTHID DEFINER
IS
  /*
    每月一號執行一次(RUN AMOUNT SHARE Tx)
    1. 將資料從 VRT_SAP005_ON_TIME_DELIVERY_T 搬到 VRT_SAP005_ON_TIME_DELIVERY
    2. 從 ORRPRD.VRT_VEW002_ORR_LIST 和 VRT_SAP005_ON_TIME_DELIVERY 寫值到 VRT_ZOT002_DELIVERY_COMPLIANCE (DC)
    2.a 抓 VRT_ZOT004_COMPLIANCE_WEEK 到 VRT_ZOT002_DELIVERY_COMPLIANCE (DD)
    3. 抓 VRT_MAP020_RATE_INDEX - 各階層的分數比率 (D2)
    4. 抓 VRT_ZOT002_DELIVERY_COMPLIANCE 資料 (指標2: Compliance & Flexibility)
    5. 將計算後值放到 VRT_MAP030_SUMMARY_GRAD
    (VRT_MAP030_SUMMARY_GRAD-L1,L2,L3,L4 參考文件 VRT_MAP060_LEVEL_DESC)
  */

  vPROCEE_YYYYMM             varchar2(6);
  vPERCENTAGE_L1             VRT_MAP020_RATE_INDEX.PERCENTAGE%TYPE;
  vPERCENTAGE_L2             VRT_MAP020_RATE_INDEX.PERCENTAGE%TYPE;
  vPERCENTAGE_L3             VRT_MAP020_RATE_INDEX.PERCENTAGE%TYPE;

  iTracePoint                varchar2(100);
  cErrorText                 varchar2(500);

BEGIN
  vPROCEE_YYYYMM := substr(f_YYYYMMDD, 1, 6);

--  --處理 VRT_SAP005_ON_TIME_DELIVERY
--  iTracePoint := '100';
--  delete from VRT_SAP005_ON_TIME_DELIVERY
--   where YYYY = substr(f_YYYYMMDD, 1, 4)
--     and MM = substr(f_YYYYMMDD, 5, 2)
--     and COMPANY_CODE = inCompany;
--  commit;
--  iTracePoint := '110';
--  insert into VRT_SAP005_ON_TIME_DELIVERY
--     select * from VRT_SAP005_ON_TIME_DELIVERY_T
--      where COMPANY_CODE = inCompany
--            and YYYY = substr(f_YYYYMMDD, 1, 4)
--        and MM = substr(f_YYYYMMDD, 5, 2);
--  commit;
--
--  --處理 VRT_ZOT002_DELIVERY_COMPLIANCE
--  iTracePoint := '200';
--  delete from VRT_ZOT002_DELIVERY_COMPLIANCE
--   where P_YEAR = substr(f_YYYYMMDD, 1, 4)
--     and P_MONTH = substr(f_YYYYMMDD, 5, 2)
--     and COMPANY_CODE = inCompany;
--  commit;
--
--  --先抓 ORR 的放到 VRT_ZOT002_DELIVERY_COMPLIANCE
--  iTracePoint := '210';
--  insert into VRT_ZOT002_DELIVERY_COMPLIANCE (
--         P_YEAR, P_MONTH, P_QUARTER, COMPANY_CODE, SITE, VENDOR_CODE, PTYPE, SCORES, TOTAL_CNT, COMPLIANCE_CNT )
--     select YYYY, MM, QUARTER, COMPANY_CODE, SITE, VENDOR_CODE, 'DC',
--            round(sum(NOSEND_CNT + COM_CNT) / sum(TOT_CNT) * 100,5) as SCORES,
--            sum(TOT_CNT) as TOTAL_CNT, sum(NOSEND_CNT + COM_CNT) as COMPLIANCE_CNT from (
--        select b.YYYY, b.MM, b.QUARTER, a.COMPANY_CODE, a.SITE,
--               a.VENDOR_CODE, 1 as TOT_CNT, decode(a.MC_VERSION_1,null,1,0) as NOSEND_CNT,
--               decode(a.VDR_VERSION,null,0,decode(trim(to_char(a.RES_QTY) || a.RES_DATE),trim(to_char(a.VDR_QTY_1) || a.VDR_DATE_1),1,0)) as COM_CNT
--          from VRT_VEW002_ORR_LIST@msqlorrprd a, DIMENSION_DATE b
--         where to_char(a.CREATE_DATE,'YYYYMMDD') = b.DATE_KEY
--           and b.YYYY = substr(f_YYYYMMDD, 1, 4)
--           and b.MM = substr(f_YYYYMMDD, 5, 2)
--           and a.COMPANY_CODE = inCompany
--     ) group by YYYY, MM, QUARTER, COMPANY_CODE, SITE, VENDOR_CODE;
--  commit;
--
--  --抓 VMI / Sch. 的放到 VRT_ZOT002_DELIVERY_COMPLIANCE (DD)
--  iTracePoint := '215';
--  insert into VRT_ZOT002_DELIVERY_COMPLIANCE (
--         P_YEAR, P_MONTH, P_QUARTER, COMPANY_CODE, SITE, VENDOR_CODE, PTYPE, SCORES, TOTAL_CNT, COMPLIANCE_CNT )
--     select P_YEAR, P_MONTH, P_QUARTER, COMPANY_CODE, SITE, VENDOR_CODE, PTYPE, (sum(SCORES) / sum(CNT)) as SCORES,
--            null as TOTAL_CNT, null as COMPLIANCE_CNT from (
--        select a.P_YEAR, a.P_MONTH, b.QUARTER as P_QUARTER,
--               a.COMPANY_CODE, a.SITE, a.VENDOR_CODE, a.PTYPE, a.SCORES, 1 as CNT
--          from VRT_ZOT004_COMPLIANCE_WEEK a, DIMENSION_DATE b
--         where a.P_YEAR = substr(f_YYYYMMDD, 1, 4)
--           and a.P_MONTH = substr(f_YYYYMMDD, 5, 2)
--           and a.COMPANY_CODE = inCompany
--           and b.DATE_KEY = f_YYYYMMDD
--     ) group by P_YEAR, P_MONTH, P_QUARTER, COMPANY_CODE, SITE, VENDOR_CODE, PTYPE;
--  commit;
--
--  --再抓 VRT_SAP005_ON_TIME_DELIVERY 的放到 VRT_ZOT002_DELIVERY_COMPLIANCE ( ZD173 )
--    --針對 ORR / schLine 未上線的供應商
--  iTracePoint := '220';
--  insert into VRT_ZOT002_DELIVERY_COMPLIANCE (
--         P_YEAR, P_MONTH, P_QUARTER, COMPANY_CODE, SITE, VENDOR_CODE, PTYPE, SCORES, TOTAL_CNT, COMPLIANCE_CNT )
--     select a.YYYY, a.MM, b.QUARTER, a.COMPANY_CODE, a.COMPANY_CODE, a.LIFNR, a.PTYPE, a.SCORE, null, null
--       from VRT_SAP005_ON_TIME_DELIVERY a, DIMENSION_DATE b
--      where a.YYYY = substr(f_YYYYMMDD, 1, 4)
--        and a.MM = substr(f_YYYYMMDD, 5, 2)
--        and a.COMPANY_CODE = inCompany
--        and ( a.YYYY || a.MM || '01' ) = b.DATE_KEY
--        and not exists (
--              select x.VENDOR_CODE from VRT_ZOT002_DELIVERY_COMPLIANCE x
--               where x.P_YEAR = a.YYYY
--                 and x.P_MONTH = a.MM
--                 and x.COMPANY_CODE = a.COMPANY_CODE
--                 and x.SITE = a.COMPANY_CODE
--                 and x.VENDOR_CODE = a.LIFNR );
--  commit;
--  -- company_code 若為 1100, 需在加一筆SITE TT - 1110
--  if inCompany = '1100' then
--     iTracePoint := '225';
--     insert into VRT_ZOT002_DELIVERY_COMPLIANCE (
--            P_YEAR, P_MONTH, P_QUARTER, COMPANY_CODE, SITE, VENDOR_CODE, PTYPE, SCORES, TOTAL_CNT, COMPLIANCE_CNT )
--        select a.YYYY, a.MM, b.QUARTER, a.COMPANY_CODE, '1110', a.LIFNR, a.PTYPE, a.SCORE, null, null
--          from VRT_SAP005_ON_TIME_DELIVERY a, DIMENSION_DATE b
--         where a.YYYY = substr(f_YYYYMMDD, 1, 4)
--           and a.MM = substr(f_YYYYMMDD, 5, 2)
--           and a.COMPANY_CODE = inCompany
--           and ( a.YYYY || a.MM || '01' ) = b.DATE_KEY
--           and not exists (
--                 select x.VENDOR_CODE from VRT_ZOT002_DELIVERY_COMPLIANCE x
--                  where x.P_YEAR = a.YYYY
--                    and x.P_MONTH = a.MM
--                    and x.COMPANY_CODE = a.COMPANY_CODE
--                    and x.SITE = '1110'
--                    and x.VENDOR_CODE = a.LIFNR );
--     commit;
--  end if;
--
--  --抓各階分數
--  iTracePoint := '300';
--  vPERCENTAGE_L1 := null;
--  vPERCENTAGE_L2 := null;
--  vPERCENTAGE_L3 := null;
--
--  for REC1 in ( select LEVEL_S, PERCENTAGE from VRT_MAP020_RATE_INDEX
--                 where INDEX_KEY = 'DELIVERY' and TYPE = 'D2' ) loop
--    if REC1.LEVEL_S = 'L1' then
--      iTracePoint := '310';
--      vPERCENTAGE_L1 := REC1.PERCENTAGE;
--    elsif REC1.LEVEL_S = 'L2' then
--      iTracePoint := '320';
--      vPERCENTAGE_L2 := REC1.PERCENTAGE;
--    elsif REC1.LEVEL_S = 'L3' then
--      iTracePoint := '330';
--      vPERCENTAGE_L3 := REC1.PERCENTAGE;
--    end if;
--  end loop;
--
--  if vPERCENTAGE_L1 is null or vPERCENTAGE_L2 is null or vPERCENTAGE_L3 is null then
--    --若沒抓到資料則寄 error mail
--    iTracePoint := '350';
--    cErrorText := 'vPERCENTAGE_L1 is ' || nvl(to_char(vPERCENTAGE_L1),'null') || ',vPERCENTAGE_L2 is ' || nvl(to_char(vPERCENTAGE_L2),'null') || ',vPERCENTAGE_L3 is ' || nvl(to_char(vPERCENTAGE_L3),'null');
--    MAIL_FILE_BIDBDBADMIN(in_to_name => 'minhorng@ms.usi.com.tw', subject => '[VRT] PL/SQL VRT_PLSQL_SAP005_ON_TIME_DEL ERROR', message => '[VRT_PLSQL_SAP005_ON_TIME_DEL], The tracepoint is  ' || iTracePoint || ' and ErrorText= ' || cErrorText) ;
--  else
--    --先清舊的資料以避免重覆
--    iTracePoint := '380-' || vPROCEE_YYYYMM;
--    delete from VRT_MAP030_SUMMARY_GRAD where TYPE = 'D2' and BUKRS = inCompany
--       and YYYY = substr(vPROCEE_YYYYMM,1,4) and MM = substr(vPROCEE_YYYYMM,5,2);
--    commit;
--
--    --放入上月分數
--    iTracePoint := '400';
--    for REC1 in ( select SITE, VENDOR_CODE, P_YEAR, P_MONTH, P_QUARTER, COMPANY_CODE, round(sum(SCORES) / sum(CNT), 5) as SCORE
--                    from ( select SITE, VENDOR_CODE, P_YEAR, P_MONTH, P_QUARTER, COMPANY_CODE, SCORES, 1 as CNT
--                             from VRT_ZOT002_DELIVERY_COMPLIANCE
--                            where P_YEAR = substr(vPROCEE_YYYYMM,1,4)
--                              and P_MONTH = substr(vPROCEE_YYYYMM,5,2)
--                              and COMPANY_CODE = inCompany )
--                   group by SITE, VENDOR_CODE, P_YEAR, P_MONTH, P_QUARTER, COMPANY_CODE ) loop
--      --放到 VRT_MAP030_SUMMARY_GRAD
--      iTracePoint := '400-' || REC1.SITE || '-' || REC1.VENDOR_CODE || '-' || vPROCEE_YYYYMM;
--      insert into VRT_MAP030_SUMMARY_GRAD (
--             SITE, LIFNR, TYPE, YYYY, MM, QUARTER, BUKRS, L1, GRADE_L1, L2, GRADE_L2, L3, GRADE_L3, L4, GRADE_L4
--           ) values (
--             REC1.SITE,
--             REC1.VENDOR_CODE,
--             'D2',
--             REC1.P_YEAR,
--             REC1.P_MONTH,
--             REC1.P_QUARTER,
--             REC1.COMPANY_CODE,
--             'S0',
--             round(REC1.SCORE * vPERCENTAGE_L1, 5),
--             'D0',
--             round(REC1.SCORE * vPERCENTAGE_L2, 5),
--             'D2',
--             round(REC1.SCORE * vPERCENTAGE_L3, 5),
--             null,
--             null
--           );
--      commit;
--    end loop;
--  end if;
--
--  if inCompany = '1100' then
--    VRT_PLSQL_ORR_REPLY_RATE;
--  end if;
--
--  --Add by susan 2006/11/15
--  if inCompany = '1100' then
--     VRT_PLSQL_ZOT005_WH_DIF;
--  end if;
--
--  --Add by susan 2006/11/15
--  if inCompany = '1100' then
--     VRT_PLSQL_SAP002_4A5_REPLY;
--  end if;
--
--  --Add by susan 2006/11/22
--  if inCompany = '1100' then
--     VRT_PLSQL_PAYMENT_TERM;
--  end if;

     --Add by susan 2008/02/12 VRT Monthly Amount TX
     if inCompany = '1100' then
--VRTN 交易比重
        VRTN_PLSQL_SUM_AMT_MM;
        VRTN_PLSQL_SUM_AMT_QQ;
     --
     --   VRTN_PLSQL_SUM_AMT_MM_MX;
--AMT        
        VRTN_PLSQL_SUM3_GV_AMT_MM;
        VRTN_PLSQL_SUM4_GV_AMT_QQ;
--VQA
		VQA_PLSQL_SUM_AMT_MM;
		VQA_PLSQL_SUM2_AMT_QQ;
     end if;


EXCEPTION
  When OTHERS Then
    --有錯誤產生則寄mail
    cErrorText := SQLERRM();
    MAIL_FILE_BIDBDBADMIN(in_to_name => 'shuchin_lin@usiglobal.com', subject => '[VRT] PL/SQL VRT_PLSQL_SAP005_ON_TIME_DEL ERROR', message => '[VRT_PLSQL_SAP005_ON_TIME_DEL], The tracepoint is  ' || iTracePoint || ' and ErrorText= ' || cErrorText || ' and Company= ' || inCompany) ;
END;
/

