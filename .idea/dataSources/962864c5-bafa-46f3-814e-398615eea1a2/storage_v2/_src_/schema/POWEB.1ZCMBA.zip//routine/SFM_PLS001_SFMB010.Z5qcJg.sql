create PROCEDURE SFM_PLS001_SFMB010
AUTHID DEFINER
is

  -- SFMB010-PREV_SALSE_FUNNEL
  CURSOR C_PREV_SALSE_FUNNEL is
    Select A.BG, A.BU, A.CUSTOMER, A.PROD_CATEGORY, A.PROJECT_NAME, B.YYYY, SUM(B.REVENUE) as REVENUE, A.REGION
      from SFMA030 A, SFMA031 B
     where A.YYYYWW = B.YYYYWW               and A.BG = B.BG
       and A.BU = B.BU                       and A.CUSTOMER = B.CUSTOMER
       and A.PROD_CATEGORY = B.PROD_CATEGORY and A.PROJECT_NAME = B.PROJECT_NAME
       and A.REGION = B.REGION
       and NVL(A.CONFIDENCE,0) <> 1
     GROUP BY A.BG, A.BU, A.CUSTOMER, A.PROD_CATEGORY, A.PROJECT_NAME, B.YYYY, A.REGION;

  -- SFMB010-DESIGN_WON
  CURSOR C_DESIGN_WON is
    Select A.BG, A.BU, A.CUSTOMER, A.PROD_CATEGORY, A.PROJECT_NAME, B.YYYY, SUM(B.REVENUE) as REVENUE, A.REGION
      from SFMA020 A, SFMA021 B
     where A.YYYYWW = B.YYYYWW               and A.BG = B.BG
       and A.BU = B.BU                       and A.CUSTOMER = B.CUSTOMER
       and A.PROD_CATEGORY = B.PROD_CATEGORY and A.PROJECT_NAME = B.PROJECT_NAME
       and A.REGION = B.REGION
       and A.CONFIDENCE = 1
       and EXISTS ( select C.BG from SFMA030 C where C.BG = A.BG and C.BU = A.BU
                       and C.CUSTOMER = A.CUSTOMER and C.PROD_CATEGORY = A.PROD_CATEGORY
                       and C.PROJECT_NAME = A.PROJECT_NAME
                       and C.REGION = A.REGION
                       and C.CONFIDENCE <> 1 )
     GROUP BY A.BG, A.BU, A.CUSTOMER, A.PROD_CATEGORY, A.PROJECT_NAME, B.YYYY, A.REGION;

  -- SFMB010-DESIGN_LOST
  CURSOR C_DESIGN_LOST is
    Select A.BG, A.BU, A.CUSTOMER, A.PROD_CATEGORY, A.PROJECT_NAME, B.YYYY, SUM(B.REVENUE) as REVENUE, A.REGION
      from SFMA030 A, SFMA031 B
     where A.YYYYWW = B.YYYYWW               and A.BG = B.BG
       and A.BU = B.BU                       and A.CUSTOMER = B.CUSTOMER
       and A.PROD_CATEGORY = B.PROD_CATEGORY and A.PROJECT_NAME = B.PROJECT_NAME
       and A.REGION = B.REGION
       and A.CONFIDENCE <> 1
       and NOT EXISTS ( select C.BG from SFMA020 C where C.BG = A.BG and C.BU = A.BU
                           and C.CUSTOMER = A.CUSTOMER and C.PROD_CATEGORY = A.PROD_CATEGORY
                           and C.PROJECT_NAME = A.PROJECT_NAME
                           and C.REGION = A.REGION )
     GROUP BY A.BG, A.BU, A.CUSTOMER, A.PROD_CATEGORY, A.PROJECT_NAME, B.YYYY, A.REGION;

  -- SFMB010-NEW_RFQ
  CURSOR C_NEW_RFQ is
    Select A.BG, A.BU, A.CUSTOMER, A.PROD_CATEGORY, A.PROJECT_NAME, B.YYYY, SUM(B.REVENUE) as REVENUE, A.REGION
      from SFMA020 A, SFMA021 B
     where A.YYYYWW = B.YYYYWW               and A.BG = B.BG
       and A.BU = B.BU                       and A.CUSTOMER = B.CUSTOMER
       and A.PROD_CATEGORY = B.PROD_CATEGORY and A.PROJECT_NAME = B.PROJECT_NAME
       and A.REGION = B.REGION
       and A.CONFIDENCE <> 1
       and NOT EXISTS ( select C.BG from SFMA030 C where C.BG = A.BG and C.BU = A.BU
                           and C.CUSTOMER = A.CUSTOMER and C.PROD_CATEGORY = A.PROD_CATEGORY
                           and C.PROJECT_NAME = A.PROJECT_NAME
                           and C.REGION = A.REGION )
     GROUP BY A.BG, A.BU, A.CUSTOMER, A.PROD_CATEGORY, A.PROJECT_NAME, B.YYYY, A.REGION;

  -- SFMB010-PROJECT_ADJ (1)
  CURSOR C_PROJECT_ADJ_1 is
    Select A.BG, A.BU, A.CUSTOMER, A.PROD_CATEGORY, A.PROJECT_NAME, B.YYYY, SUM(B.REVENUE) as REVENUE, A.REGION
      from SFMA020 A, SFMA021 B
     where A.YYYYWW = B.YYYYWW               and A.BG = B.BG
       and A.BU = B.BU                       and A.CUSTOMER = B.CUSTOMER
       and A.PROD_CATEGORY = B.PROD_CATEGORY and A.PROJECT_NAME = B.PROJECT_NAME
       and A.REGION = B.REGION
       and A.CONFIDENCE <> 1
       and EXISTS ( select C.BG from SFMA030 C where C.BG = A.BG and C.BU = A.BU
                       and C.CUSTOMER = A.CUSTOMER and C.PROD_CATEGORY = A.PROD_CATEGORY
                       and C.PROJECT_NAME = A.PROJECT_NAME
                       and C.REGION = A.REGION
                       and C.CONFIDENCE = 1 )
     GROUP BY A.BG, A.BU, A.CUSTOMER, A.PROD_CATEGORY, A.PROJECT_NAME, B.YYYY, A.REGION;

  -- SFMB010-PROJECT_ADJ (2)
  CURSOR C_PROJECT_ADJ_2 is
    Select A.BG, A.BU, A.CUSTOMER, A.PROD_CATEGORY, A.PROJECT_NAME, B.YYYY, SUM(B.REVENUE - D.REVENUE) as REVENUE, A.REGION
      from SFMA020 A, SFMA021 B, SFMA030 C, SFMA031 D
     where A.YYYYWW = B.YYYYWW               and A.BG = B.BG
       and A.BU = B.BU                       and A.CUSTOMER = B.CUSTOMER
       and A.PROD_CATEGORY = B.PROD_CATEGORY and A.PROJECT_NAME = B.PROJECT_NAME
       and A.REGION = B.REGION
       and A.CONFIDENCE <> 1
       and C.YYYYWW = D.YYYYWW               and C.BG = D.BG
       and C.BU = D.BU                       and C.CUSTOMER = D.CUSTOMER
       and C.PROD_CATEGORY = D.PROD_CATEGORY and C.PROJECT_NAME = D.PROJECT_NAME
       and C.REGION = A.REGION
       and C.CONFIDENCE <> 1
       and A.BG = C.BG                       and A.BU = C.BU
       and A.CUSTOMER = C.CUSTOMER           and A.PROD_CATEGORY = C.PROD_CATEGORY
       and A.PROJECT_NAME = C.PROJECT_NAME   and B.YYYY = D.YYYY
       and A.REGION = C.REGION
     GROUP BY A.BG, A.BU, A.CUSTOMER, A.PROD_CATEGORY, A.PROJECT_NAME, B.YYYY, A.REGION;

  -- SFMB010-CURR_SALES_FUNNEL
  CURSOR C_CURR_SALES_FUNNEL is
    Select A.BG, A.BU, A.CUSTOMER, A.PROD_CATEGORY, A.PROJECT_NAME, B.YYYY, SUM(B.REVENUE) as REVENUE, A.REGION
      from SFMA020 A, SFMA021 B
     where A.YYYYWW = B.YYYYWW               and A.BG = B.BG
       and A.BU = B.BU                       and A.CUSTOMER = B.CUSTOMER
       and A.PROD_CATEGORY = B.PROD_CATEGORY and A.PROJECT_NAME = B.PROJECT_NAME
       and A.REGION = B.REGION
       and NVL(A.CONFIDENCE,0) <> 1
     GROUP BY A.BG, A.BU, A.CUSTOMER, A.PROD_CATEGORY, A.PROJECT_NAME, B.YYYY, A.REGION;

  --處理 SFMA050
  CURSOR C_SFMA050 is
    Select REGION from (
      Select A.REGION from SFMA020 A
       UNION ALL
      Select B.REGION from SFMA030 B
    ) Group by REGION;

  nCOUNT              NUMBER(5);

BEGIN
  --清舊的SFMB010
  Delete from SFMB010;
  Commit;

  --建立SFMB010的key
  Insert into SFMB010 ( BG, BU, CUSTOMER, PROD_CATEGORY, PROJECT_NAME, YYYY, REGION )
     Select BG, BU, CUSTOMER, PROD_CATEGORY, PROJECT_NAME, YYYY, REGION from (
       select A.BG, A.BU, A.CUSTOMER, A.PROD_CATEGORY, A.PROJECT_NAME, B.YYYY, A.REGION
         from SFMA020 A, SFMA021 B where A.YYYYWW = B.YYYYWW and A.BG = B.BG and A.BU = B.BU
          and A.CUSTOMER = B.CUSTOMER and A.PROD_CATEGORY = B.PROD_CATEGORY and A.PROJECT_NAME = B.PROJECT_NAME
          and A.REGION = B.REGION
       UNION
       select A.BG, A.BU, A.CUSTOMER, A.PROD_CATEGORY, A.PROJECT_NAME, B.YYYY, A.REGION
         from SFMA030 A, SFMA031 B where A.YYYYWW = B.YYYYWW and A.BG = B.BG and A.BU = B.BU
          and A.CUSTOMER = B.CUSTOMER and A.PROD_CATEGORY = B.PROD_CATEGORY and A.PROJECT_NAME = B.PROJECT_NAME
          and A.REGION = B.REGION
     ) GROUP BY BG, BU, CUSTOMER, PROD_CATEGORY, PROJECT_NAME, YYYY, REGION;
  Commit;

  --Update PREV_SALSE_FUNNEL
  FOR REC1 in C_PREV_SALSE_FUNNEL Loop
    Update SFMB010
       set PREV_SALSE_FUNNEL = REC1.REVENUE
     where BG = REC1.BG                     and BU = REC1.BU
       and CUSTOMER = REC1.CUSTOMER         and PROD_CATEGORY = REC1.PROD_CATEGORY
       and PROJECT_NAME = REC1.PROJECT_NAME and YYYY = REC1.YYYY
       and REGION = REC1.REGION;
    Commit;
  END LOOP;
  Update SFMB010 set PREV_SALSE_FUNNEL = 0 where PREV_SALSE_FUNNEL is null;
  Commit;

  --Update DESIGN_WON
  FOR REC1 in C_DESIGN_WON Loop
    Update SFMB010
       set DESIGN_WON = REC1.REVENUE
     where BG = REC1.BG                     and BU = REC1.BU
       and CUSTOMER = REC1.CUSTOMER         and PROD_CATEGORY = REC1.PROD_CATEGORY
       and PROJECT_NAME = REC1.PROJECT_NAME and YYYY = REC1.YYYY
       and REGION = REC1.REGION;
    Commit;
  END LOOP;
  Update SFMB010 set DESIGN_WON = 0 where DESIGN_WON is null;
  Commit;

  --Update DESIGN_LOST
  FOR REC1 in C_DESIGN_LOST Loop
    Update SFMB010
       set DESIGN_LOST = REC1.REVENUE
     where BG = REC1.BG                     and BU = REC1.BU
       and CUSTOMER = REC1.CUSTOMER         and PROD_CATEGORY = REC1.PROD_CATEGORY
       and PROJECT_NAME = REC1.PROJECT_NAME and YYYY = REC1.YYYY
       and REGION = REC1.REGION;
    Commit;
  END LOOP;
  Update SFMB010 set DESIGN_LOST = 0 where DESIGN_LOST is null;
  Commit;

  --Update NEW_RFQ
  FOR REC1 in C_NEW_RFQ Loop
    Update SFMB010
       set NEW_RFQ = REC1.REVENUE
     where BG = REC1.BG                     and BU = REC1.BU
       and CUSTOMER = REC1.CUSTOMER         and PROD_CATEGORY = REC1.PROD_CATEGORY
       and PROJECT_NAME = REC1.PROJECT_NAME and YYYY = REC1.YYYY
       and REGION = REC1.REGION;
    Commit;
  END LOOP;
  Update SFMB010 set NEW_RFQ = 0 where NEW_RFQ is null;
  Commit;

  --Update PROJECT_ADJ (1)
  FOR REC1 in C_PROJECT_ADJ_1 Loop
    Update SFMB010
       set PROJECT_ADJ = REC1.REVENUE
     where BG = REC1.BG                     and BU = REC1.BU
       and CUSTOMER = REC1.CUSTOMER         and PROD_CATEGORY = REC1.PROD_CATEGORY
       and PROJECT_NAME = REC1.PROJECT_NAME and YYYY = REC1.YYYY
       and REGION = REC1.REGION;
    Commit;
  END LOOP;
  Update SFMB010 set PROJECT_ADJ = 0 where PROJECT_ADJ is null;
  Commit;

  --Update PROJECT_ADJ (2)
  FOR REC1 in C_PROJECT_ADJ_2 Loop
    Update SFMB010
       set PROJECT_ADJ = ( PROJECT_ADJ + REC1.REVENUE )
     where BG = REC1.BG                     and BU = REC1.BU
       and CUSTOMER = REC1.CUSTOMER         and PROD_CATEGORY = REC1.PROD_CATEGORY
       and PROJECT_NAME = REC1.PROJECT_NAME and YYYY = REC1.YYYY
       and REGION = REC1.REGION;
    Commit;
  END LOOP;

  --Update CURR_SALES_FUNNEL
  FOR REC1 in C_CURR_SALES_FUNNEL Loop
    Update SFMB010
       set CURR_SALES_FUNNEL = REC1.REVENUE
     where BG = REC1.BG                     and BU = REC1.BU
       and CUSTOMER = REC1.CUSTOMER         and PROD_CATEGORY = REC1.PROD_CATEGORY
       and PROJECT_NAME = REC1.PROJECT_NAME and YYYY = REC1.YYYY
       and REGION = REC1.REGION;
    Commit;
  END LOOP;
  Update SFMB010 set CURR_SALES_FUNNEL = 0 where CURR_SALES_FUNNEL is null;
  Commit;

  --處理SFMA050
  nCOUNT := 0;
  Delete from SFMA050;
  Commit;
  FOR REC1 in C_SFMA050 Loop
    nCOUNT := nCOUNT + 1;
    Insert into SFMA050 ( REGION, NO )
         values ( REC1.REGION, TO_CHAR( nCOUNT, '00') );
  END LOOP;
  Commit;

END SFM_PLS001_SFMB010;
/

