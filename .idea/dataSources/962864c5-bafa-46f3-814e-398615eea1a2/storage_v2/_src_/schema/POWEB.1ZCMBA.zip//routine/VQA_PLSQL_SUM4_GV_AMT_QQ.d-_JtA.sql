create PROCEDURE         "VQA_PLSQL_SUM4_GV_AMT_QQ" IS

     /*--------------------------------------------------------------*
         CREATE DATE:  2008/02/29
         PLSQL      :  VQA_PLSQL_SUM4_GV_AMT_QQ
         Author     :  Susan Lin
         Purpase    :  Amount Summary-WW(By 每月執行一次 for 季資料 )
                       TW/SZ/SH
                       Insert to VQA_SUM09_AMT_GV_MATGP_Q table&
                                 VQA_SUM10_AMT_GV_MF_Q table
      *---------------------------------------------------------------*
      */


 vPROCEE_YYYYMMDD varchar2(8);
 vPROCEE_YYYYMM   varchar2(6);
 iTracePoint      varchar2(100);
 cErrorText       varchar2(500);
 vCOMPANY_CODE    varchar2(4);
 vYYYYMM          varchar2(6);
 vSTART_DATE      varchar2(8);
 vEND_DATE        varchar2(8);
 vQUARTER         varchar2(8);
 vCK_MANUF        varchar2(10);

BEGIN
    vCOMPANY_CODE := null;
    vYYYYMM := null;
    vSTART_DATE := null;
    vEND_DATE := null;
    vQUARTER := null;
    vCK_MANUF := null;

   --抓上個月資料
     iTracePoint := '100';
     vPROCEE_YYYYMM := TO_CHAR(ADD_MONTHS(SYSDATE, -1), 'YYYYMM');

   --抓季資料
      for REC1 in (Select QUARTER
                          FROM DIMENSION_DATE
                          WHERE YYYY = SUBSTRB(vPROCEE_YYYYMM,1,4)
                            AND MM = SUBSTRB(vPROCEE_YYYYMM,5,2)
                            ) loop
         vQUARTER := SUBSTRB(vPROCEE_YYYYMM,1,4) || REC1.QUARTER;
      end loop;
    --抓季起始區間資料
         for REC1 in (Select MIN(DATE_KEY) AS DATE_KEY
                             FROM DIMENSION_DATE
                             WHERE QUARTER = SUBSTRB(vQUARTER,5,2)
                               AND YYYY = SUBSTRB(vQUARTER,1,4)
                               ) loop
            vSTART_DATE := REC1.DATE_KEY;
         end loop;
    --抓季終上區間資料
        for REC1 in (Select MAX(DATE_KEY) AS DATE_KEY
                            FROM DIMENSION_DATE
                            WHERE QUARTER = SUBSTRB(vQUARTER,5,2)
                              AND YYYY = SUBSTRB(vQUARTER,1,4)
                             ) loop
            vEND_DATE := REC1.DATE_KEY;
        end loop;



  if vQUARTER is null then
     --若沒抓到資料則寄 error mail
     iTracePoint := '110';
     cErrorText := 'QUARTER error!';
     MAIL_FILE_BIDBDBADMIN(in_to_name => 'shuchin@ms.usi.com.tw', subject => '[VQA] PL/SQL VQA_PLSQL_SUM4_GV_AMT_QQ ERROR', message => '[VQA_PLSQL_SUM4_GV_AMT_QQ], The tracepoint is  ' || iTracePoint || ' and ErrorText= ' || cErrorText) ;
  else

     --清除舊的 VQA_SUM09_AMT_GV_MATGP_Q 資料
       iTracePoint := '200';
       DELETE FROM VQA_SUM09_AMT_GV_MATGP_Q WHERE QUARTER = SUBSTRB(vQUARTER,1,6);

     --放入季Amount
       iTracePoint := '210';
        for REC1 in ( Select MANUF, MATGROUP, QUARTER, round(SUM(AMOUNT), 2) as Q_AMOUNT
                             from VQA_SUM07_AMT_GV_MF_MATGP_M
                             where MANUF is Not Null
                               and MATGROUP is Not Null
                               and QUARTER = SUBSTRB(vQUARTER,1,6)
                    Group by MANUF, MATGROUP, QUARTER
                    ) loop
      --放到 VQA_SUM09_AMT_GV_MATGP_Q
      iTracePoint := '220-' || REC1.MANUF || '-' || REC1.MATGROUP || '-' || vPROCEE_YYYYMM || REC1.QUARTER;
      insert into VQA_SUM09_AMT_GV_MATGP_Q (
                  MANUF, MATGROUP, QUARTER, Q_AMOUNT, FROM_DATE, TO_DATE, SITE, DATE_TIME
           ) values (
           REC1.MANUF,
           REC1.MATGROUP,
           REC1.QUARTER,
           REC1.Q_AMOUNT,
           vSTART_DATE,
           vEND_DATE,
           '',
           to_char(SYSDATE, 'yyyymmddhh24miss')
           );
      commit;
    end loop;
  end if;


  --Process By Manufacture name
   iTracePoint := '300';
   for REC1 in ( Select MANUF, QUARTER
                        from VQA_SUM09_AMT_GV_MATGP_Q
                        where MANUF is Not Null
                          and MATGROUP is Not Null
                          and QUARTER = SUBSTRB(vQUARTER,1,6)
                    ) loop
     vCK_MANUF := REC1.MANUF;
   end loop;
  if vCK_MANUF is null then
     --若沒抓到資料則寄 error mail
     iTracePoint := '400';
     cErrorText := 'VQA_SUM09_AMT_GV_MATGP_Q- NO DATA!';
     MAIL_FILE_BIDBDBADMIN(in_to_name => 'shuchin@ms.usi.com.tw', subject => '[VQA] PL/SQL VRTN_PLSQL_SUM4_GV_AMT_QQ ERROR', message => '[VRTN_PLSQL_SUM4_GV_AMT_QQ], The tracepoint is  ' || iTracePoint || ' and ErrorText= ' || cErrorText) ;
  else

     --清除舊的 VQA_SUM10_AMT_GV_MF_Q資料
       iTracePoint := '500';
       DELETE FROM VQA_SUM10_AMT_GV_MF_Q WHERE QUARTER = SUBSTRB(vQUARTER,1,6);

     --抓季Amount
       iTracePoint := '510';
        for REC1 in ( Select MANUF, QUARTER, round(SUM(Q_AMOUNT), 2) as Q_AMOUNT
                             from VQA_SUM09_AMT_GV_MATGP_Q
                             where MANUF is Not Null
                               and MATGROUP is Not Null
                               and QUARTER = SUBSTRB(vQUARTER,1,6)
                    Group by MANUF, QUARTER
                    ) loop
      --放到 VQA_SUM10_AMT_GV_MF_Q
      iTracePoint := '520-' || REC1.MANUF || '-' || vPROCEE_YYYYMM || REC1.QUARTER;
      insert into VQA_SUM10_AMT_GV_MF_Q (
                  MANUF, QUARTER, Q_AMOUNT, FROM_DATE, TO_DATE, SITE, DATE_TIME
           ) values (
           REC1.MANUF,
           REC1.QUARTER,
           REC1.Q_AMOUNT,
           vSTART_DATE,
           vEND_DATE,
           '',
           to_char(SYSDATE, 'yyyymmddhh24miss')
           );
      commit;
    end loop;
  end if;


EXCEPTION
   When OTHERS Then
    --有錯誤產生則寄mail
      cErrorText := SQLERRM();
      MAIL_FILE_BIDBDBADMIN(in_to_name => 'shuchin_lin@usiglobal.com', subject => '[VQA] PL/SQL VQA_PLSQL_SUM4_GV_AMT_QQ ERROR', message => '[VQA_PLSQL_SUM4_GV_AMT_QQ], The tracepoint is  ' || iTracePoint || ' and ErrorText= ' || cErrorText);


END VQA_PLSQL_SUM4_GV_AMT_QQ;
/

