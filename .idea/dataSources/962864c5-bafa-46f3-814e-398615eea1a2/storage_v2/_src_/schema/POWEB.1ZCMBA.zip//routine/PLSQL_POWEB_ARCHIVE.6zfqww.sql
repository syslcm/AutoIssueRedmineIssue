create PROCEDURE "PLSQL_POWEB_ARCHIVE" (
  b_YYYYMMDD    in VARCHAR2
)
/*
*/
is
	iTracePoint           integer ;
	cErrorText            varchar2(500) ;
	cCHK1                 varchar2(100) ;
	cCHK2                 varchar2(100) ;
	b_YYYYMM              varchar2(6);
BEGIN
	iTracePoint := 0;
	cErrorText := ' ';
	cCHK1 := ' ';
	cCHK2 := ' ';

	b_YYYYMM := 'X';
	BEGIN
		select * into b_YYYYMM from (
			select YYYYMM from DIMENSION_DATE where DATE_KEY = b_YYYYMMDD
		) where rownum <= 1;
	EXCEPTION
		WHEN OTHERS THEN
			b_YYYYMM := 'X';
	END;

  if b_YYYYMMDD >= '20070101' or b_YYYYMM = 'X' then
	MAIL_FILE_BIDBDBADMIN(in_to_name=>'minhorng@ms.usi.com.tw',subject   => '[DMM]PL/SQL PLSQL_POWEB_ARCHIVE ERROR' , message => '[PLSQL_DMM_DATA_BAK], DATE ErrorText=' || b_YYYYMMDD) ;
  else
	-- POWEB_MONTH_PR
	iTracePoint := 100;
	cCHK1 := ' ';
	cCHK2 := ' ';
	for REC1 in (
		select distinct COMPANY_CODE, VERSION from POWEB_MONTH_PR where VERSION <= b_YYYYMM
	) loop
		iTracePoint := 101;
		cCHK2 := REC1.COMPANY_CODE || '-' || REC1.VERSION;
		delete from POWEB_MONTH_PR where COMPANY_CODE = REC1.COMPANY_CODE and VERSION <= REC1.VERSION;
		commit;
	end loop;
	-- POWEB_MONTH_PO
	iTracePoint := 200;
	cCHK1 := ' ';
	cCHK2 := ' ';
	for REC1 in (
		select distinct COMPANY_CODE, VERSION from POWEB_MONTH_PO where VERSION <= b_YYYYMM
	) loop
		iTracePoint := 201;
		cCHK2 := REC1.COMPANY_CODE || '-' || REC1.VERSION;
		delete from POWEB_MONTH_PO where COMPANY_CODE = REC1.COMPANY_CODE and VERSION <= REC1.VERSION;
		commit;
	end loop;
  end if;
EXCEPTION
  WHEN OTHERS THEN
    cErrorText := trim(cCHK2) || '>' || SQLERRM() ;
	rollback;
    MAIL_FILE_BIDBDBADMIN(in_to_name=>'minhorng@ms.usi.com.tw',subject   => '[DMM]PL/SQL PLSQL_POWEB_ARCHIVE ERROR' , message => '[PLSQL_POWEB_ARCHIVE], The tracepoint is  ' || to_char(iTracePoint) || ' and ErrorText=' || cErrorText) ;
End PLSQL_POWEB_ARCHIVE;
/

