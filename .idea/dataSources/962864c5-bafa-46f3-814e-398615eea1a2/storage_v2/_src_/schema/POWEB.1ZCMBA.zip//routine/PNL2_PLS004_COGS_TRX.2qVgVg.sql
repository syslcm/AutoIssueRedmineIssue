create PROCEDURE       PNL2_PLS004_COGS_TRX (
  --inCompany  in VARCHAR2,
  inPeriod in VARCHAR2
  --inPC in VARCHAR2
  --2008/9/17 Create to Process get Amount in Local/USD/TWD
  --Trigger by PNL2_BAD_DEPT_UPLOAD.JSP
)
AUTHID DEFINER
is
  CURSOR C_PNL2_DIRECT is
   --不會有NET_REVENUE資料
    SELECT COMPANY_CODE,PROFIT_CENTER,COST_ELEMENT,
           SUM(NET_REVENUE) AMT_LOCAL,SUM(NET_REVENUE_USD) AMT_USD,SUM(NET_REVENUE_TWD) AMT_TWD,
           SUM(COGS_MB) COGS_DM_LOCAL,SUM(COGS_MB_USD) COGS_DM_USD,SUM(COGS_MB_TWD) COGS_DM_TWD,
           SUM(COGS_LB) COGS_DL_LOCAL,SUM(COGS_LB_USD) COGS_DL_USD,SUM(COGS_LB_TWD) COGS_DL_TWD,
           SUM(COGS_OB) COGS_OH_LOCAL,SUM(COGS_OB_USD) COGS_OH_USD,SUM(COGS_OB_TWD) COGS_OH_TWD
    FROM KPI_SAP001_COPA_TRX
    WHERE  PERIOD = inPeriod 
      AND    ( NET_REVENUE <> 0 OR NET_COGS <>  0)
      AND    RELATED_PARTY <> 'Y'
      --AND PROFIT_CENTER = inPC
      --AND    END_CUSTOMER_ID IS NULL
      --2008/10/8 V.3.0  Exclude '0000510102'
      --AND     COST_ELEMENT IN ('0000510107','0000510109','0000510110','0000510201',
      --                            '0000510301','0000510401','0000510501')
      AND COST_ELEMENT IN ('0000510109','0000510110')
    GROUP BY COMPANY_CODE,PROFIT_CENTER,COST_ELEMENT
    HAVING ( SUM(NET_REVENUE) <> 0 OR SUM(NET_COGS)  <> 0 );
  
  --Revenue 只能以profit center觀點來看,不要加入company_code,像22 在CA只有成本,沒有營收,所以就會漏掉
  CURSOR C_PNL2_REVENUE is
     SELECT PROFIT_CENTER,SUM(NET_REVENUE_TWD) AMT_TWD
     FROM  KPI_SAP001_COPA_TRX
     WHERE PERIOD = inPeriod 
       AND RELATED_PARTY <> 'Y'
      -- AND PROFIT_CENTER = inPC
       --AND NET_REVENUE <> 0
     GROUP BY PROFIT_CENTER;
     
     a_Rate          PNL2_UPL003_REALIZED_GM.EX_RATE_USD%TYPE;
     a_ENDCUSTOMER   KPI_SAP001_COPA_TRX.END_CUSTOMER_ID%TYPE;
     
 BEGIN
   DELETE FROM PNL2_TRX002_GLACCOUNT
   WHERE Period = inPeriod ;
   Commit;
   
   FOR REC1 in C_PNL2_REVENUE Loop
      --IF REC1.AMT_TWD <> 0 THEN  --某些Profit center沒有營收,例34/9X
        PNL2_PLS004_COGS_S01_TRX(inPeriod,REC1.PROFIT_CENTER,REC1.AMT_TWD,'0000510101');
        PNL2_PLS004_COGS_S01_TRX(inPeriod,REC1.PROFIT_CENTER,REC1.AMT_TWD,'0000510103');
        PNL2_PLS004_COGS_S01_TRX(inPeriod,REC1.PROFIT_CENTER,REC1.AMT_TWD,'0000510104');
        PNL2_PLS004_COGS_S01_TRX(inPeriod,REC1.PROFIT_CENTER,REC1.AMT_TWD,'0000510107');
        PNL2_PLS004_COGS_S01_TRX(inPeriod,REC1.PROFIT_CENTER,REC1.AMT_TWD,'0000510901');
        PNL2_PLS004_COGS_S01_TRX(inPeriod,REC1.PROFIT_CENTER,REC1.AMT_TWD,'0000510902');
        PNL2_PLS004_COGS_S01_TRX(inPeriod,REC1.PROFIT_CENTER,REC1.AMT_TWD,'0000510903');
        PNL2_PLS004_COGS_S01_TRX(inPeriod,REC1.PROFIT_CENTER,REC1.AMT_TWD,'0000510909');
        PNL2_PLS004_COGS_S01_TRX(inPeriod,REC1.PROFIT_CENTER,REC1.AMT_TWD,'0000510999');
      --END IF;
   END LOOP;
   
   
   FOR REC2 in C_PNL2_DIRECT Loop
      IF REC2.COST_ELEMENT = '0000510109' THEN
        a_ENDCUSTOMER := 'INTEL';
      ELSE
        a_ENDCUSTOMER := 'SMC';
      END IF;
      
        IF REC2.AMT_LOCAL <> 0 THEN
           INSERT INTO PNL2_TRX002_GLACCOUNT (
               COMPANY_CODE         ,PERIOD            ,PROFIT_CENTER      ,COST_ELEMENT      ,
               END_CUSTOMER_ID      ,R_KIND            ,AREA1              ,AREA2             ,
               AREA3                ,AMT_LOCAL         ,AMT_TWD            ,AMT_USD           ,
               CREATE_DATE
           ) VALUES(
               REC2.COMPANY_CODE    ,inPeriod          ,REC2.PROFIT_CENTER ,REC2.COST_ELEMENT ,
               a_ENDCUSTOMER        ,'PL01'            ,'1'                  ,'1'                 ,
               '0'                    ,REC2.AMT_LOCAL    , REC2.AMT_TWD      ,REC2.AMT_USD           ,
               SYSDATE
           );
           commit;
        END IF;
        
        IF REC2.COGS_DM_LOCAL <> 0 THEN
           INSERT INTO PNL2_TRX002_GLACCOUNT (
               COMPANY_CODE         ,PERIOD                ,PROFIT_CENTER      ,COST_ELEMENT ,
               END_CUSTOMER_ID      ,R_KIND                ,AREA1              ,AREA2        ,
               AREA3                ,AMT_LOCAL             ,AMT_TWD            ,AMT_USD      ,
               CREATE_DATE
           ) VALUES(
               REC2.COMPANY_CODE    ,inPeriod              ,REC2.PROFIT_CENTER ,REC2.COST_ELEMENT ,
               a_ENDCUSTOMER        ,'PL01'                ,'2'                 ,'2'                 ,
               '0'                    ,REC2.COGS_DM_LOCAL    , REC2.COGS_DM_TWD  ,REC2.COGS_DM_USD           ,
               SYSDATE
           );
           commit;
        END IF;
        
        IF REC2.COGS_DL_LOCAL <> 0 THEN
           INSERT INTO PNL2_TRX002_GLACCOUNT (
               COMPANY_CODE         ,PERIOD                ,PROFIT_CENTER      ,COST_ELEMENT ,
               END_CUSTOMER_ID      ,R_KIND                ,AREA1              ,AREA2        ,
               AREA3                ,AMT_LOCAL             ,AMT_TWD            ,AMT_USD      ,
               CREATE_DATE
           ) VALUES(
               REC2.COMPANY_CODE    ,inPeriod              ,REC2.PROFIT_CENTER ,REC2.COST_ELEMENT ,
               a_ENDCUSTOMER        ,'PL01'                ,'2'                  ,'3'                 ,
               '0'                    ,REC2.COGS_DL_LOCAL    , REC2.COGS_DL_TWD  ,REC2.COGS_DL_USD           ,
               SYSDATE
           );
           commit;
        END IF;
        
        IF REC2.COGS_OH_LOCAL <> 0 THEN
           INSERT INTO PNL2_TRX002_GLACCOUNT (
               COMPANY_CODE         ,PERIOD       ,PROFIT_CENTER   ,COST_ELEMENT ,
               END_CUSTOMER_ID      ,R_KIND       ,AREA1           ,AREA2        ,
               AREA3                ,AMT_LOCAL    ,AMT_TWD         ,AMT_USD      ,
               CREATE_DATE
           ) VALUES(
               REC2.COMPANY_CODE    ,inPeriod              ,REC2.PROFIT_CENTER ,REC2.COST_ELEMENT ,
               a_ENDCUSTOMER        ,'PL01'                ,'2'                  ,'4'                 ,
               '0'                    ,REC2.COGS_OH_LOCAL    , REC2.COGS_OH_TWD  ,REC2.COGS_OH_USD           ,
               SYSDATE
           );
           commit;
        END IF;
   END LOOP;
    
END PNL2_PLS004_COGS_TRX;
/

