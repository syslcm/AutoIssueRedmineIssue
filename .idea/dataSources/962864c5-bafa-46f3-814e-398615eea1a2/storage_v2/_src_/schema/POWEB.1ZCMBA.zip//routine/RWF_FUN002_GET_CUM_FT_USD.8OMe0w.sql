create Function RWF_FUN002_GET_CUM_FT_USD(cRWF_YYYY in RWF_SAP001_REVENUE_FORECAST.RWF_YYYY%TYPE,cRWF_WEEK in RWF_SAP001_REVENUE_FORECAST.RWF_WEEK%TYPE,cRWF_MM in RWF_SAP001_REVENUE_FORECAST.RWF_MM%TYPE,cCOMPANY_CODE in RWF_SAP001_REVENUE_FORECAST.COMPANY_CODE%TYPE,cPROFIT_CENTER in RWF_SAP001_REVENUE_FORECAST.PROFIT_CENTER%TYPE)
/*********************************************************************
*新增/修改日期 :  2007-01-10
*Programmer    :  Kangi
*申請單號      :  SAI005398
*新增原因      :  GET 小於 cRWF_MM 'ACTUAL' + 大於等於 cRWF_MM 'FORECAST'
**********************************************************************/
/*********************************************************************
*修改日期 :  2007-02-09
*Programmer    :  Kangi
*申請單號      :  SAI005398
*修改原因      :  全部只抓 'FORECAST'
**********************************************************************/
/*********************************************************************
*修改日期 :  2007-02-15
*Programmer    :  Kangi
*申請單號      :  SAI005398
*修改原因      :  放棄全部只抓 'FORECAST',改回原來
**********************************************************************/
/*********************************************************************
--Add Date : 20111230
--Add User : kangi
--Add Reason : 原 Table RWF_SAP001_REVENUE_FORECAST 改抓 View RWF_VIEW002_REVENUE_FORECAST
--OA         : SAI028442
**********************************************************************/
return RWF_SAP001_REVENUE_FORECAST.NET_REVENUE%TYPE
is
cFORECAST_NET_REVENUE_USD  RWF_SAP001_REVENUE_FORECAST.NET_REVENUE%TYPE ;
cACTUAL_NET_REVENUE_USD  RWF_SAP001_REVENUE_FORECAST.NET_REVENUE%TYPE ;
Begin

       --Modify kangi 20111229
       --SELECT NVL(SUM(NET_REVENUE_USD),'0') INTO cFORECAST_NET_REVENUE_USD FROM RWF_SAP001_REVENUE_FORECAST Remark kangi 20111229
         SELECT NVL(SUM(NET_REVENUE_USD),'0') INTO cFORECAST_NET_REVENUE_USD FROM RWF_VIEW002_REVENUE_FORECAST
       --End Modify kangi 20111229
              WHERE RWF_YYYY = cRWF_YYYY
                AND RWF_WEEK = cRWF_WEEK
                AND COMPANY_CODE = cCOMPANY_CODE
                AND PROFIT_CENTER = cPROFIT_CENTER
                AND RWF_MM >= cRWF_MM
       --Modify kangi 20111229
       --       AND RWF_YYYY = F_YEAR  Remark kangi 20111229
       --End Modify kangi 20111229
                ;
       SELECT NVL(SUM(NET_REVENUE_USD),'0') INTO cACTUAL_NET_REVENUE_USD FROM RWF_SAP002_REVENUE_ACTUAL
              WHERE RWF_YYYY = cRWF_YYYY
                AND COMPANY_CODE = cCOMPANY_CODE
                AND PROFIT_CENTER = cPROFIT_CENTER
                AND RWF_MM < cRWF_MM ;
       return cFORECAST_NET_REVENUE_USD + cACTUAL_NET_REVENUE_USD ;
End RWF_FUN002_GET_CUM_FT_USD;
/

