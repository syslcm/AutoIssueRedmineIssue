create PROCEDURE PLSQL_DCF_MATERIAL (
  inCOMPANY_CODE IN SAP_MATERIAL_CLIENT.COMPANY_CODE%TYPE
)
AUTHID DEFINER
is
  iTracePoint                varchar2(100);
  cErrorText                 varchar2(500);

BEGIN

  iTracePoint := '100';
  FOR REC1 in (
    select b.* from SAP_MATERIAL_CLIENT a, SAP_MATERIAL_CLIENT_T b
     where a.COMPANY_CODE = inCOMPANY_CODE
       and a.COMPANY_CODE = b.COMPANY_CODE and a.PART_NO = b.PART_NO
       and ( nvl(a.MFR_PART_PROFILE,'null') <> nvl(b.MFR_PART_PROFILE,'null')
          or nvl(a.CW,'null') <> nvl(b.CW,'null')
          or nvl(a.RW,'null') <> nvl(b.RW,'null')
          or nvl(a.GP,'null') <> nvl(b.GP,'null')
          or nvl(a.DELE_FLAG,'null') <> nvl(b.DELE_FLAG,'null') )
  ) LOOP
     Update SAP_MATERIAL_CLIENT
        Set MFR_PART_PROFILE = REC1.MFR_PART_PROFILE,
            CW = REC1.CW,
            RW = REC1.RW,
            GP = REC1.GP,
            DELE_FLAG = REC1.DELE_FLAG
      Where COMPANY_CODE = REC1.COMPANY_CODE and PART_NO = REC1.PART_NO;

     Commit;
  END LOOP;

  iTracePoint := '150';
  insert into SAP_MATERIAL_CLIENT
    select * from SAP_MATERIAL_CLIENT_T
     where COMPANY_CODE = inCOMPANY_CODE
     and ( COMPANY_CODE, PART_NO ) not in (
       select COMPANY_CODE, PART_NO from SAP_MATERIAL_CLIENT
        where COMPANY_CODE = inCOMPANY_CODE );
  commit;


  iTracePoint := '200';
  FOR REC1 in (
    select b.* from SAP_MATERIAL_PLANT a, SAP_MATERIAL_PLANT_T b
     where a.COMPANY_CODE = inCOMPANY_CODE
       and a.COMPANY_CODE = b.COMPANY_CODE and a.PART_NO = b.PART_NO and a.PLANT = b.PLANT
       and ( nvl(a.SPEC_PROCUREMENT,'null') <> nvl(b.SPEC_PROCUREMENT,'null')
          or nvl(a.LT, -999) <> nvl(b.LT,-999)
          or nvl(a.MOQ,-99999) <> nvl(b.MOQ,-99999)
          or nvl(a.MPQ,-99999) <> nvl(b.MPQ,-99999)
          or nvl(a.MRP_CONT,'null') <> nvl(b.MRP_CONT,'null')
          or nvl(a.BUYER_CODE,'null') <> nvl(b.BUYER_CODE,'null')
          or nvl(a.DELE_FLAG,'null') <> nvl(b.DELE_FLAG,'null')
          or nvl(a.PC,'null') <> nvl(b.PC,'null')
		  or nvl(a.SUBGRP,'null') <> nvl(b.SUBGRP,'null')
		  )
  ) LOOP
     Update SAP_MATERIAL_PLANT
        Set SPEC_PROCUREMENT = REC1.SPEC_PROCUREMENT,
            LT = REC1.LT,
            MOQ = REC1.MOQ,
            MPQ = REC1.MPQ,
            MRP_CONT = REC1.MRP_CONT,
            BUYER_CODE = REC1.BUYER_CODE,
            DELE_FLAG = REC1.DELE_FLAG,
            PC = REC1.PC,
			SUBGRP = REC1.SUBGRP
      Where COMPANY_CODE = REC1.COMPANY_CODE and PART_NO = REC1.PART_NO and PLANT = REC1.PLANT;

     Commit;
  END LOOP;

  iTracePoint := '250';
  insert into SAP_MATERIAL_PLANT
    select * from SAP_MATERIAL_PLANT_T
     where COMPANY_CODE = inCOMPANY_CODE
     and ( COMPANY_CODE, PART_NO, PLANT ) not in (
       select COMPANY_CODE, PART_NO, PLANT from SAP_MATERIAL_PLANT
        where COMPANY_CODE = inCOMPANY_CODE );
  commit;


  iTracePoint := '300';
  FOR REC1 in (
    select b.* from SAP_AMPL a, SAP_AMPL_T b
     where a.COMPANY_CODE = inCOMPANY_CODE
       and a.COMPANY_CODE = b.COMPANY_CODE and a.PART_NO = b.PART_NO
       and ( nvl(a.INT_PART_NO,'null') <> nvl(b.INT_PART_NO,'null')
          or nvl(a.VALID_FROM,'null') <> nvl(b.VALID_FROM,'null')
          or nvl(a.VALID_TO,'null') <> nvl(b.VALID_TO,'null')
          or nvl(a.BLOCKED,'null') <> nvl(b.BLOCKED,'null')
          or nvl(a.DELE_FLAG,'null') <> nvl(b.DELE_FLAG,'null') )
  ) LOOP
     Update SAP_AMPL
        Set INT_PART_NO = REC1.INT_PART_NO,
            VALID_FROM = REC1.VALID_FROM,
            VALID_TO = REC1.VALID_TO,
            BLOCKED = REC1.BLOCKED,
            DELE_FLAG = REC1.DELE_FLAG
      Where COMPANY_CODE = REC1.COMPANY_CODE and PART_NO = REC1.PART_NO;

     Commit;
  END LOOP;

  iTracePoint := '350';
  insert into SAP_AMPL
    select * from SAP_AMPL_T
     where COMPANY_CODE = inCOMPANY_CODE
     and ( COMPANY_CODE, PART_NO, INT_PART_NO ) not in (
       select COMPANY_CODE, PART_NO, INT_PART_NO from SAP_AMPL
        where COMPANY_CODE = inCOMPANY_CODE );
  commit;


EXCEPTION
   When OTHERS Then
    --有錯誤產生則寄mail
    cErrorText := SQLERRM();
    MAIL_FILE_BIDBDBADMIN(in_to_name => 'minhorng@ms.usi.com.tw', subject => '[DCF] PL/SQL PLSQL_DCF_MATERIAL ERROR - ' || inCOMPANY_CODE, message => '[PLSQL_DCF_MATERIAL], The tracepoint is  ' || iTracePoint || ' and ErrorText= ' || cErrorText) ;
END PLSQL_DCF_MATERIAL;
/

