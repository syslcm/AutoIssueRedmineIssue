create PROCEDURE         "VQA_PLSQL_IRR_WK_MANFU_PN_WW" IS
      /*--------------------------------------------------------------*
         CREATE DATE:  2008/01/26
         PLSQL      :  VVQA_PLSQL_IRR_WK_MANFU_PN_WW
         Author     :  Susan Lin
         Purpase    :  IRR RATE-Manfu ww(By 每週執行一次)
                       TW/SZ/SH/MX
      *---------------------------------------------------------------*
      */


 vCompany_code VQA_050_IRR_WEEKLY_MANFU_PN_T.Company_code%TYPE;
 vPROCEE_YYYYMMDD varchar2(8);
 vPROCEE_YYYYMM   varchar2(6);
 iTracePoint      varchar2(100);
 cErrorText       varchar2(500);

BEGIN



  for REC1 in ( select COMPANY_CODE, YYYY, MM, WEEK, MANUF, PART_NO, PTYPE, MATGROUP, REJECT_LOT_CNT, LOT_CNT, PERCENTAGE, DATE_TIME
                 from VQA_050_IRR_WEEKLY_MANFU_PN
                 where WEEK in (Select substrb(yyyyww,5,2) from DIMENSION_DATE Where date_key = to_char( sysdate - 7, 'yyyymmdd'))
                       ) loop
    if REC1.COMPANY_CODE is not null then
      iTracePoint := '110';
      vCompany_code := REC1.Company_code;
    end if;
  end loop;

  if vCOMPANY_CODE is null then
   --若沒抓到資料則寄 error mail
    iTracePoint := '120';
    cErrorText := 'Manfu. WW No data!';
    MAIL_FILE_BIDBDBADMIN(in_to_name => 'shuchin@ms.usi.com.tw', subject => '[VQA] PL/SQL VQA_PLSQL_IRR_WK_MANFU_WW ERROR', message => '[VQA_010_IRR_WEEKLY_T], The tracepoint is  ' || iTracePoint || ' and ErrorText= ' || cErrorText) ;
  else


    --清除重覆資料ww
    DELETE FROM VQA_053_IRR_WK_MANFU_PN_WW
           WHERE WEEK in (Select substrb(yyyyww,5,2) from DIMENSION_DATE Where date_key = to_char( sysdate - 7, 'yyyymmdd'));

    iTracePoint := '400'; -- Manuf&part for WW Data
      for REC1 in ( select distinct a.YYYY, a.MM, a.WEEK, a.MANUF, a.PART_NO, a.PTYPE, b.YYYY || b.QUARTER as QUARTER, a.MATGROUP,
                   round(sum(a.REJECT_LOT_CNT)) as REJECT_LOT_CNT, sum(a.LOT_CNT) as LOT_CNT,
                   ( round(round(sum(a.REJECT_LOT_CNT)) / sum(a.LOT_CNT),2 ) * 100 ) as PERCENTAGE,
                   to_char(SYSDATE, 'yyyymmddhh24miss') as DATE_TIME, a.YYYY || a.WEEK as YYYYWW, '0000' AS CODE
                         from VQA_050_IRR_WEEKLY_MANFU_PN a, DIMENSION_DATE b
--                         where a.YYYY = SUBSTRB(vPROCEE_YYYYMM,1,4) and
--                               a.MM   = SUBSTRB(vPROCEE_YYYYMM,5,2) and
                         where b.date_key = to_char( sysdate - 7, 'yyyymmdd') and
                               a.WEEK in (Select substrb(yyyyww,5,2) from DIMENSION_DATE Where date_key = to_char( sysdate - 7, 'yyyymmdd'))
                          Group by a.YYYY, a.MM, a.WEEK, a.MANUF, a.PART_NO, a.PTYPE, b.YYYY || b.QUARTER,  a.MATGROUP
      ) loop

        iTracePoint := '500-' || REC1.YYYY || '-' || REC1.MM || '-' ||  REC1.MANUF || '-' || REC1.MATGROUP || '-' ||  SUBSTRB(vPROCEE_YYYYMM,1,6);
        insert into VQA_053_IRR_WK_MANFU_PN_WW (
                 COMPANY_CODE, YYYY, MM, WEEK, MANUF, PART_NO, PTYPE, QUARTER, MATGROUP, REJECT_LOT_CNT, LOT_CNT, PERCENTAGE, DATE_TIME, YYYYWW
             ) values (
               REC1.CODE,
               REC1.YYYY,
               REC1.MM,
               REC1.WEEK,
               REC1.MANUF,
               REC1.PART_NO,
               REC1.PTYPE,
               REC1.QUARTER,
               REC1.MATGROUP,
               REC1.REJECT_LOT_CNT,
               REC1.LOT_CNT,
               REC1.PERCENTAGE,
               REC1.DATE_TIME,
               REC1.YYYYWW
             );
           commit;




       end loop;


  end if;





EXCEPTION
   When OTHERS Then
    --有錯誤產生則寄mail
    cErrorText := SQLERRM();
    MAIL_FILE_BIDBDBADMIN(in_to_name => 'shuchin_lin@usiglobal.com', subject => '[VQA] PL/SQL VQA_PLSQL_IRR_WK_MANFU_WW ERROR', message => '[VQA_050_IRR_WEEKLY_MANFU_PN], The tracepoint is  ' || iTracePoint || ' and ErrorText= ' || cErrorText) ;

END VQA_PLSQL_IRR_WK_MANFU_PN_WW;
/

