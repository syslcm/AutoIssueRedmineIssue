create PROCEDURE         "Z_TEST_PLSQL" (
  inCompany  in VARCHAR2,
  f_YYYYMMDD in VARCHAR2,
  t_YYYYMMDD in VARCHAR2,
  RES out VARCHAR2
)
AUTHID DEFINER
is
   t_CURRENCY_LOCAL    Z_TEST_T.CURR%TYPE;
   a_EX_RATE_USD       KPI_SAP006_AP_TRX.EX_RATE_USD%TYPE;  
   f_PERIOD           VARCHAR2(6);

BEGIN
RES := 'A';
dbms_output.put_line('> start ' || to_char(SYSDATE,'YYYY/MM/DD HH24:MI:SS') || ' <');
dbms_output.put_line('f_YYYYMMDD=' || f_YYYYMMDD);
dbms_output.put_line('t_YYYYMMDD=' || t_YYYYMMDD);
f_PERIOD := SUBSTRB(f_YYYYMMDD,1,6);
 --抓CURRENCY_LOCAL
 t_CURRENCY_LOCAL := Null;
 Begin
   
 Select * into t_CURRENCY_LOCAL From (
     Select distinct CURR from Z_TEST_T
   ) Where ROWNUM <= 1;
     
 EXCEPTION
   When OTHERS Then
     t_CURRENCY_LOCAL := Null;
 End;

 If t_CURRENCY_LOCAL is Not Null Then
    --計算匯率
    a_EX_RATE_USD := Null;

   
   --開始處理資料
   --(1) EX_RATE_xxx, AMOUNT_xxxx
   
  End If;
  dbms_output.put_line('=== finish @ ' || to_char(sysdate,'YYYY/MM/DD HH24:MI:SS') || ' ===');
  RES := 'OK';
dbms_output.put_line('RES=' || RES);
  
END Z_TEST_PLSQL;
/

