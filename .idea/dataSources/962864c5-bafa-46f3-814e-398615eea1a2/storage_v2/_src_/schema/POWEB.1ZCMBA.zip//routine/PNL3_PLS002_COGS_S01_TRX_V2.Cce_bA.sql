create PROCEDURE       PNL3_PLS002_COGS_S01_TRX_V2 (
  --inCOMPANY       in VARCHAR2,
  inPeriod        in VARCHAR2,
  inPROFIT_CENTER in VARCHAR2,
  inAMT           in Number,
  inGLAccount     in VARCHAR
  --2008/9/17 Create to Process get Amount in Local/USD/TWD
  --Trigger by PNL2_BAD_DEPT_UPLOAD.JSP
)
AUTHID DEFINER
is
--2008/11/7 有發現  SUM(NET_REVENUE) <> 0 OR SUM(NET_COGS)  <> 0 條件成立但dm/dl/oh卻有值的戕況,因此不加入此條件
-- 在INSERT進資料庫時再排除金額=0的資料
     
     a_Rate          number(20,10);
     a_TRate         number(20,10);
     --a_COUNTER       integer;
     --i_COUNTER       integer;
     a_ENDCUSTOMER   PNL3_TRX001_COPA.END_CUSTOMER_ID%TYPE;
     a_NET_REVENUE   PNL3_TRX001_COPA.AMT_TWD%TYPE;
     a_REVENUE_LOCAL PNL3_TRX001_COPA.AMT_TWD%TYPE;
     a_REVENUE_TWD   PNL3_TRX001_COPA.AMT_TWD%TYPE;
     a_REVENUE_USD   PNL3_TRX001_COPA.AMT_TWD%TYPE;
     a_COGS_DM_LOCAL PNL3_TRX001_COPA.AMT_TWD%TYPE;
     a_COGS_DM_TWD   PNL3_TRX001_COPA.AMT_TWD%TYPE;
     a_COGS_DM_USD   PNL3_TRX001_COPA.AMT_TWD%TYPE;
     a_COGS_DL_LOCAL PNL3_TRX001_COPA.AMT_TWD%TYPE;
     a_COGS_DL_TWD   PNL3_TRX001_COPA.AMT_TWD%TYPE;
     a_COGS_DL_USD   PNL3_TRX001_COPA.AMT_TWD%TYPE;
     a_COGS_OH_LOCAL PNL3_TRX001_COPA.AMT_TWD%TYPE;
     a_COGS_OH_TWD   PNL3_TRX001_COPA.AMT_TWD%TYPE;
     a_COGS_OH_USD   PNL3_TRX001_COPA.AMT_TWD%TYPE;
     
 BEGIN
   

    a_RATE  := 0;
    IF inAMT <> 0 THEN --有營收,沒有營收早已處理

      a_TRate := 1;

      FOR REC1 in (SELECT END_CUSTOMER_ID,SUM(AMT_TWD) AMT_TWD FROM PNL3_TRX001_COPA 
                      WHERE PROFIT_CENTER = inPROFIT_CENTER
                        AND PERIOD = inPeriod
                        AND AREA1 = '1'
                        AND AREA2 = '1'
                        AND AREA3 = '0'
                        AND AMT_TWD <> 0
                        --AND SOURCE <> 'UPL001'
                        GROUP BY END_CUSTOMER_ID ORDER BY AMT_TWD DESC) Loop
        a_Rate := REC1.AMT_TWD / inAMT;
        a_TRate := a_TRate - a_Rate;
        a_REVENUE_LOCAL := 0;
        a_REVENUE_TWD   := 0;
        a_REVENUE_USD   := 0;
        a_COGS_DM_LOCAL := 0;
        a_COGS_DM_TWD   := 0;
        a_COGS_DM_USD   := 0;
        a_COGS_DL_LOCAL := 0;
        a_COGS_DL_TWD   := 0;
        a_COGS_DL_USD   := 0;
        a_COGS_OH_LOCAL := 0;
        a_COGS_OH_TWD   := 0;
        a_COGS_OH_USD   := 0;

        FOR REC2 in(
            SELECT *
              FROM PNL3_TRX002_GLACCOUNT_T
             WHERE  PERIOD = inPeriod 
               AND  PROFIT_CENTER = inPROFIT_CENTER
               AND  END_CUSTOMER_ID IS NULL
               AND COST_ELEMENT = inGLAccount) Loop
            --HAVING ( SUM(NET_REVENUE) <> 0 OR SUM(NET_COGS)  <> 0 )


             INSERT INTO PNL3_TRX002_GLACCOUNT (
                 COMPANY_CODE         ,PERIOD       ,PROFIT_CENTER   ,COST_ELEMENT , BILL_TO_PARTY, SHIP_TO_PARTY, MTL_GROUP , PART_NO,PLANT_CODE,
                 END_CUSTOMER_ID      ,R_KIND       ,AREA1           ,AREA2        ,MTL_TYPE,
                 AREA3                ,AMT_LOCAL    ,AMT_TWD         ,AMT_USD      ,
                 CUSTOMER_REVENUE     ,PC_REVENUE   ,RATE            ,
                 CREATE_DATE          
             ) VALUES(
                 REC2.COMPANY_CODE     ,inPeriod     ,inPROFIT_CENTER,inGLAccount   ,REC2.BILL_TO_PARTY, REC2.SHIP_TO_PARTY, REC2.MTL_GROUP, REC2.PART_NO,REC2.PLANT_CODE,
                 REC1.END_CUSTOMER_ID ,REC2.R_KIND        ,REC2.AREA1               ,REC2.AREA2            , REC2.MTL_TYPE,
                 REC2.AREA3                    ,round(REC2.AMT_LOCAL * a_RATE , 5)         ,
                 round(REC2.AMT_TWD * a_RATE , 5)  ,
                 round(REC2.AMT_USD * a_RATE , 5)  ,
                 REC1.AMT_TWD                , inAMT ,a_Rate  ,
                 SYSDATE
             );
             commit;
        

         END LOOP;              
      END LOOP;
      
        FOR REC2 in(
            SELECT *
              FROM PNL3_TRX002_GLACCOUNT_T
             WHERE  PERIOD = inPeriod 
               AND  PROFIT_CENTER = inPROFIT_CENTER
               AND  END_CUSTOMER_ID IS NOT NULL
               AND COST_ELEMENT = inGLAccount) Loop
            --HAVING ( SUM(NET_REVENUE) <> 0 OR SUM(NET_COGS)  <> 0 )


             INSERT INTO PNL3_TRX002_GLACCOUNT (
                 COMPANY_CODE         ,PERIOD       ,PROFIT_CENTER   ,COST_ELEMENT , BILL_TO_PARTY, SHIP_TO_PARTY, MTL_GROUP , PART_NO,PLANT_CODE,
                 END_CUSTOMER_ID      ,R_KIND       ,AREA1           ,AREA2        ,MTL_TYPE,
                 AREA3                ,AMT_LOCAL    ,AMT_TWD         ,AMT_USD      ,
                 CUSTOMER_REVENUE     ,PC_REVENUE   ,RATE            ,
                 CREATE_DATE          
             ) VALUES(
                 REC2.COMPANY_CODE     ,inPeriod     ,inPROFIT_CENTER,inGLAccount   ,REC2.BILL_TO_PARTY, REC2.SHIP_TO_PARTY, REC2.MTL_GROUP, REC2.PART_NO,REC2.PLANT_CODE,
                 REC2.END_CUSTOMER_ID ,REC2.R_KIND        ,REC2.AREA1               ,REC2.AREA2            , REC2.MTL_TYPE,
                 REC2.AREA3           ,REC2.AMT_LOCAL,REC2.AMT_TWD  , REC2.AMT_USD  ,
                 0               ,inAMT  ,1  ,
                 SYSDATE
             );
             commit;
     

         END LOOP; 
   END IF;
   
   
   
    
END PNL3_PLS002_COGS_S01_TRX_V2;
/

