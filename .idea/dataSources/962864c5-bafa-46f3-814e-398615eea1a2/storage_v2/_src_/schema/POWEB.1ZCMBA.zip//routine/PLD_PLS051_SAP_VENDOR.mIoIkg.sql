create PROCEDURE PLD_PLS051_SAP_VENDOR (
/*********************************************************************
  PROG-ID      : PLD_PLS051_SAP_VENDOR
  Author       : Asan Chang
  Date         : 2013/04/09
**********************************************************************/

   incompany    IN   VARCHAR2,
   f_yyyymmdd   IN   VARCHAR2,
   t_yyyymmdd   IN   VARCHAR2
)
AUTHID DEFINER
IS
   CURSOR pld_kpi_sap_vendor_t
   IS
      SELECT COMPANY_CODE,  VENDOR_CODE, VENDOR_NAME
      FROM pld_kpi_sap_vendor_t;

   a_SKIP        VARCHAR2 (1);
   itracepoint   INTEGER;
BEGIN


   --(1)清除舊的 pld_kpi_sap_vendor 資料

   DELETE FROM pld_kpi_sap_vendor
   where COMPANY_CODE = incompany;
   COMMIT;



   FOR REC1 IN pld_kpi_sap_vendor_t LOOP
   --(3)開始處理資料
       INSERT INTO pld_kpi_sap_vendor (
            COMPANY_CODE,         VENDOR_CODE,        VENDOR_NAME
            ) VALUES (
                 
            REC1.COMPANY_CODE,   REC1.VENDOR_CODE,    REC1.VENDOR_NAME               
             );    
       COMMIT;
   END LOOP;

   --(4) 刪除資料


   DELETE FROM pld_kpi_sap_vendor_t
   where COMPANY_CODE = incompany;
   COMMIT;

   --(4) Send Mail
END PLD_PLS051_SAP_VENDOR;
/

