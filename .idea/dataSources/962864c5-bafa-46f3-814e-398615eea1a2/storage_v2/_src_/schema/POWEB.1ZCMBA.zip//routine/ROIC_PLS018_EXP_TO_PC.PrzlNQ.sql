create PROCEDURE       ROIC_PLS018_EXP_TO_PC (
/* ********************************************************************
  PROG-ID      : ROIC_PLS018_EXP_TO_PC
  PROG-ACTION  : 
  Author       : Asan Chang
  Date         : 2019/12/10
  OA Number    : SAI110424
  Description  : Expense Alloc to PC
********************************************************************* 
* 2020/01/08 Asan Chang modify from_company_code����
********************************************************************* 
*/
   incompany    IN   VARCHAR2,
   YYYYMM       IN   VARCHAR2
)
AUTHID DEFINER
IS     
   CURSOR FROM_DATA
   IS  
   
   select a.*  , LPAD(b.ROA_PC, 10, '0') ROA_PC, b.PD ,b.ROA_PD,LPAD(b.PROFIT_CENTER, 10, '0') NEW_PROFIT_CENTER, b.EM_ACCOUNT ,c.GROUP1
   from ROIC_PST017_EXP_BEF_M a
   left join ROIC_MAP002_GROUP_ACCT_MAPPING c on a.GROUP_ACCT = c.GROUP_ACCT
   left join KPI_MAP018_ORGANIZATION b
   on a.COMPANY_CODE = b.COMPANY_CODE  AND a.PERIOD = b.PERIOD
   AND a.SENDER = b.SAP_COST_CENTER
   where a.COMPANY_CODE = incompany
   and a.PERIOD = YYYYMM 
   and c.GROUP1 in ( 'ADM-D'|| chr(38) ||'A-01', 'ADM-D'|| chr(38) ||'A-02',
                     'OH-D'|| chr(38) ||'A-01' , 'OH-D'|| chr(38) ||'A-02',
                     'R'|| chr(38) ||'D-D'|| chr(38) ||'A-01', 'R'|| chr(38) ||'D-D'|| chr(38) ||'A-02',
                     'SAL-D'|| chr(38) ||'A-01', 'SAL-D'|| chr(38) ||'A-02' ) ;
   
-- ADM-D&A-01
-- ADM-D&A-02
-- OH-D&A-01
-- OH-D&A-02
-- R&D-D&A-01
-- R&D-D&A-02
-- SAL-D&A-01
-- SAL-D&A-02   
   
      
   itracepoint         INTEGER;
   tmp_ALLOC_TYPE      VARCHAR(2);              --���u���� ex:01,02,03...
   tmp_PC              VARCHAR2(10 BYTE);
   tmp_WW_RATIO        NUMBER(15,2);
   tmp_LEGAL_RATIO     NUMBER(15,2);
   TMP_AMT1            NUMBER(15,5);
   TMP_AMT2            NUMBER(15,5); 
   TMP_AMT3            NUMBER(15,5);
   TMP_AMT4            NUMBER(15,5);   
   /*TMP_AMT5          NUMBER(15,5);
   TMP_AMT6            NUMBER(15,5);  
   TMP_AMT7            NUMBER(15,5);
   TMP_AMT8            NUMBER(15,5);  */  
   TMP_TTL_MHRATE      Number(15,5);
   TMP_TTL_LHRATE      Number(15,5);
   TMP_ROA_PD          VARCHAR(7);
   CORP2_NORMAL_CODE   VARCHAR(8);
   CORP2_NOFOUND_CODE  VARCHAR(8);  
   RATE_FLAG           VARCHAR(1);
   sPROC_NAME          ROIC_PST000_LOG.PROC_NAME%TYPE;
   sRUN_SEQ            ROIC_PST000_LOG.RUN_SEQ%TYPE;
   sRUN_DESC           ROIC_PST000_LOG.RUN_DESC%TYPE;
   sPARAMETER_DESC     ROIC_PST000_LOG.PARAMETER_DESC%TYPE;     
   ------------------------sub function ------------------------
  PROCEDURE INSERT_DATA (
    in_COMPANY_CODE         IN VARCHAR2,
    in_COST_ELEMENT         IN VARCHAR2,
    in_CATEGORY             IN VARCHAR2,
    in_FUN_AREA             IN VARCHAR2,
    in_SENDER               IN VARCHAR2,
    in_GROUP_ACCT           IN VARCHAR2,
    in_AMT_LOC              IN NUMBER,
    in_AMT_TWD              IN NUMBER,
    in_AMT_USD              IN NUMBER,
    in_AMT_CNY              IN NUMBER,	
    in_HOLDING_LEGAIL_CODE  IN VARCHAR2,
	in_CLASS_CODE           IN VARCHAR2,
    in_REASON_CODE          IN VARCHAR2,
    in_NAME_BUDGET_EN       IN VARCHAR2,	
    in_FROM_SITE            IN VARCHAR2,
	
    in_SORTKEY              IN VARCHAR2,
    in_REMARK               IN VARCHAR2,
    in_PROFIT_CENTER        IN VARCHAR2,	
    in_DATA_TYPE            IN VARCHAR2,	
		
    in_ROA_PD               IN VARCHAR2,
	in_RATIO                IN NUMBER,
	in_RATIO2               IN NUMBER,
	in_NEW_PROFIT_CENTER    IN VARCHAR2,
    in_ALLOC_TYPE           IN VARCHAR2,
	in_FROM_COMPANY_CODE    IN VARCHAR2,
    in_GROUP1               IN VARCHAR2
	
	
  ) IS
  BEGIN
   --(3)�}�l�B�z����
     INSERT INTO ROIC_PST018_EXP_TO_PC (
       COMPANY_CODE,	 
       PERIOD,
       COST_ELEMENT,
       CATEGORY,
       FUN_AREA,
       SENDER,
       GROUP_ACCT,
       AMT_LOC,
       AMT_TWD,
       AMT_USD,
       AMT_CNY,
       HOLDING_LEGAIL_CODE,
	   CLASS_CODE,
       REASON_CODE,
       NAME_BUDGET_EN,
       FROM_SITE,
       SORTKEY,
       REMARK,
       PROFIT_CENTER,
       DATA_TYPE,
       ROA_PD,
       RATIO,
       RATIO2,
       PROC_NAME,
       NEW_PROFIT_CENTER,
       ALLOC_TYPE,
	   FROM_COMPANY_CODE,
	   GROUP1
       ) VALUES (                                 
	   incompany ,       
       YYYYMM , 
       in_COST_ELEMENT,
       in_CATEGORY,
       in_FUN_AREA,
       in_SENDER,
       in_GROUP_ACCT,
       in_AMT_LOC,
       in_AMT_TWD,
       in_AMT_USD,
       in_AMT_CNY,
       in_HOLDING_LEGAIL_CODE,
	   in_CLASS_CODE,
       in_REASON_CODE,
       in_NAME_BUDGET_EN,
       in_FROM_SITE,
       in_SORTKEY,
       in_REMARK,
       in_PROFIT_CENTER,
       in_DATA_TYPE,
       in_ROA_PD,
       in_RATIO,
       in_RATIO2,
	   sPROC_NAME,
       in_NEW_PROFIT_CENTER,
       in_ALLOC_TYPE ,    
	   in_FROM_COMPANY_CODE,
	   in_GROUP1       
       );   
       COMMIT;
  END INSERT_DATA;
  ------------------------sub function ------------------------  
  
   ------------------------sub function2 ------------------------
  PROCEDURE INSERT_DATA2 (
    in_COMPANY_CODE         IN VARCHAR2,
    in_COST_ELEMENT         IN VARCHAR2,
    in_CATEGORY             IN VARCHAR2,
    in_FUN_AREA             IN VARCHAR2,
    in_SENDER               IN VARCHAR2,
    in_GROUP_ACCT           IN VARCHAR2,
    in_AMT_LOC              IN NUMBER,
    in_AMT_TWD              IN NUMBER,
    in_AMT_USD              IN NUMBER,
    in_AMT_CNY              IN NUMBER,	
    in_HOLDING_LEGAIL_CODE  IN VARCHAR2,
	in_CLASS_CODE           IN VARCHAR2,	
    in_REASON_CODE          IN VARCHAR2,
    in_NAME_BUDGET_EN       IN VARCHAR2,	
    in_FROM_SITE            IN VARCHAR2,
	
    in_SORTKEY              IN VARCHAR2,
    in_REMARK               IN VARCHAR2,
    in_PROFIT_CENTER        IN VARCHAR2,	
    in_DATA_TYPE            IN VARCHAR2,	
		
    in_ROA_PD               IN VARCHAR2,
	in_RATIO                IN NUMBER,
	in_RATIO2               IN NUMBER,
	in_NEW_PROFIT_CENTER    IN VARCHAR2,
    in_ALLOC_TYPE           IN VARCHAR2,
	in_FROM_COMPANY_CODE    IN VARCHAR2,
    in_GROUP1               IN VARCHAR2
	
  ) IS
  BEGIN
   --(3)�}�l�B�z����  
     INSERT INTO ROIC_PST018_EXP_TO_PC (
       COMPANY_CODE,	 
       PERIOD,
       COST_ELEMENT,
       CATEGORY,
       FUN_AREA,
       SENDER,
       GROUP_ACCT,
       AMT_LOC,
       AMT_TWD,
       AMT_USD,
       AMT_CNY,
       HOLDING_LEGAIL_CODE,
	   CLASS_CODE,	   
       REASON_CODE,
       NAME_BUDGET_EN,
       FROM_SITE,
       SORTKEY,
       REMARK,
       PROFIT_CENTER,
       DATA_TYPE,
       ROA_PD,
       RATIO,
       RATIO2,
       PROC_NAME,
       NEW_PROFIT_CENTER,
       ALLOC_TYPE,
	   FROM_COMPANY_CODE,
	   GROUP1	   
       ) VALUES (                                 
	   in_COMPANY_CODE ,       
       YYYYMM , 
       in_COST_ELEMENT,
       in_CATEGORY,
       in_FUN_AREA,
       in_SENDER,
       in_GROUP_ACCT,
       in_AMT_LOC,
       in_AMT_TWD,
       in_AMT_USD,
       in_AMT_CNY,
       in_HOLDING_LEGAIL_CODE,
	   in_CLASS_CODE,	   
       in_REASON_CODE,
       in_NAME_BUDGET_EN,
       in_FROM_SITE,
       in_SORTKEY,
       in_REMARK,
       in_PROFIT_CENTER,
       in_DATA_TYPE,
       in_ROA_PD,
       in_RATIO,
       in_RATIO2,
	   sPROC_NAME,
       in_NEW_PROFIT_CENTER,
       in_ALLOC_TYPE,     
	   in_FROM_COMPANY_CODE,
	   in_GROUP1
       );   
       COMMIT;
  END INSERT_DATA2;
  ------------------------sub function2 ------------------------   
 
  

   ------------------------sub function3 ------------------------
  PROCEDURE INSERT_DATA3 (
    in_PROFIT_CENTER             IN VARCHAR2,
    in_FUNCTION                  IN VARCHAR2,
    in_UNIT                      IN VARCHAR2,
    in_GROUP_ID                  IN VARCHAR2,
    in_DIVISION                  IN VARCHAR2,
    in_DEPARTMENT                IN VARCHAR2,
    in_SAP_COST_CENTER           IN VARCHAR2,
    in_BUDGET_COST               IN VARCHAR2,
    in_CATEGORY                  IN VARCHAR2,
    in_EM_ACCOUNT                IN VARCHAR2,
    in_LOCATION                  IN VARCHAR2,
    in_SECTIONS                  IN VARCHAR2,
    in_PD                        IN VARCHAR2,
    in_YEAR                      IN VARCHAR2, 
    in_ROA_PD                    IN VARCHAR2,
    in_ROA_PC                    IN VARCHAR2  
       
  ) IS
  BEGIN
   --(3)�}�l�B�z����
     INSERT INTO ROIC_MAP018_ORGANIZATION_EXP (
       COMPANY_CODE ,            
       PROFIT_CENTER,
       FUNCTION,
       UNIT,
       GROUP_ID,
       DIVISION,
       DEPARTMENT,
       SAP_COST_CENTER,
       BUDGET_COST,
       CATEGORY,
       EM_ACCOUNT,
       LOCATION,
       PERIOD,
       SECTIONS,
       CREATEDATE,
       PD,
       YEAR,
       ROA_PD,
       ROA_PC,
       CREATE_DATE
       ) VALUES (                                        
       incompany ,            
       in_PROFIT_CENTER,
       in_FUNCTION,
       in_UNIT,
       in_GROUP_ID,
       in_DIVISION,
       in_DEPARTMENT,
       in_SAP_COST_CENTER,
       in_BUDGET_COST,
       in_CATEGORY,
       in_EM_ACCOUNT,
       in_LOCATION,
       YYYYMM,
       in_SECTIONS,
       sysdate,
       in_PD,
       in_YEAR,
       in_ROA_PD,
       in_ROA_PC,
       sysdate
           );   
       COMMIT;
  END INSERT_DATA3;
  ------------------------sub function2 ------------------------ 
  
   PROCEDURE NO_RATE (
    /*
    in_COMPANY_CODE         IN VARCHAR2,
    in_FROM_COMPANY_CODE    IN VARCHAR2,
    in_PERIOD               IN VARCHAR2,
    in_ASSET_NO             IN VARCHAR2,
    in_ASSET_SUB_NO         IN VARCHAR2,
    in_SENDER_COST_CENTER   IN VARCHAR2,
    in_RECEIVER_COST_CENTER IN VARCHAR2,
    in_PC                   IN VARCHAR2,
    in_ALLOC_TYPE           IN VARCHAR2,
    in_OWN_TYPE             IN VARCHAR2,
    in_ACQ_VAL              IN NUMBER,
    in_BOOK_VAL             IN NUMBER,
    in_ACQ_VAL_TWD          IN NUMBER,
    in_BOOK_VAL_TWD         IN NUMBER,	
    in_ACQ_VAL_USD          IN NUMBER,
    in_BOOK_VAL_USD         IN NUMBER,	
    in_ACQ_VAL_CNY          IN NUMBER,
    in_BOOK_VAL_CNY         IN NUMBER,	
    in_REASON_CODE          IN VARCHAR2,
    in_USE_CODE             IN VARCHAR2,
    in_CLASS_CODE           IN VARCHAR2,		
    in_S_SEQ                IN VARCHAR2
	*/
    in_COMPANY_CODE         IN VARCHAR2,
	in_FROM_COMPANY_CODE    IN VARCHAR2,
    in_COST_ELEMENT         IN VARCHAR2,
    in_CATEGORY             IN VARCHAR2,
    in_FUN_AREA             IN VARCHAR2,
    in_SENDER               IN VARCHAR2,
    in_GROUP_ACCT           IN VARCHAR2,
    in_AMT_LOC              IN NUMBER,
    in_AMT_TWD              IN NUMBER,
    in_AMT_USD              IN NUMBER,
    in_AMT_CNY              IN NUMBER,	
    in_HOLDING_LEGAIL_CODE  IN VARCHAR2,
	in_CLASS_CODE           IN VARCHAR2,	
    in_REASON_CODE          IN VARCHAR2,
    in_NAME_BUDGET_EN       IN VARCHAR2,	
    in_FROM_SITE            IN VARCHAR2,
	
    in_SORTKEY              IN VARCHAR2,
    in_REMARK               IN VARCHAR2,
    in_PROFIT_CENTER        IN VARCHAR2,	
    in_DATA_TYPE            IN VARCHAR2,	
		
    in_ROA_PD               IN VARCHAR2,
	in_RATIO                IN NUMBER,
	in_RATIO2               IN NUMBER,
	in_NEW_PROFIT_CENTER    IN VARCHAR2,
    in_ALLOC_TYPE           IN VARCHAR2,	
    in_GROUP1               IN VARCHAR2	
	
  ) IS
  BEGIN
   --(3)�}�l�B�z����
   FOR REC3 IN (
   select LPAD(PC, 10, '0') PC, RATIO FROM ROA_UPL006_ALLC_CORP2 WHERE COMPANY_CODE = in_COMPANY_CODE AND PERIOD = YYYYMM AND RATIO > 0  AND AS2_CODE = CORP2_NOFOUND_CODE
   )
   LOOP                
     tmp_PC := REC3.PC;
     TMP_AMT1 := ROUND(in_AMT_LOC  / 100 * REC3.RATIO, 5);
     TMP_AMT2 := ROUND(in_AMT_TWD  / 100 * REC3.RATIO, 5);
     TMP_AMT3 := ROUND(in_AMT_USD  / 100 * REC3.RATIO, 5);
     TMP_AMT4 := ROUND(in_AMT_CNY  / 100 * REC3.RATIO, 5);
	 
     INSERT_DATA(in_FROM_COMPANY_CODE,in_COST_ELEMENT ,in_CATEGORY  ,in_FUN_AREA ,in_SENDER , in_GROUP_ACCT,
	 TMP_AMT1 ,TMP_AMT2,TMP_AMT3 ,TMP_AMT4, in_HOLDING_LEGAIL_CODE,	in_CLASS_CODE, in_REASON_CODE, in_NAME_BUDGET_EN, in_FROM_SITE,
     in_SORTKEY, in_REMARK, in_PROFIT_CENTER, in_DATA_TYPE, CORP2_NOFOUND_CODE, REC3.RATIO, 0,tmp_PC,in_ALLOC_TYPE,	in_FROM_COMPANY_CODE, in_GROUP1 );	           
   END LOOP; 
  END NO_RATE;
  ------------------------sub function2 ------------------------ 
       
BEGIN

--(0)Insert Log start
  sPROC_NAME := 'ROIC_PLS018_EXP_TO_PC';
  sRUN_SEQ   := '000010';
  sRUN_DESC  := 'Start';
  sPARAMETER_DESC := CONCAT(CONCAT(CONCAT('PERIOD=',YYYYMM),';Site='),incompany);
  
  
  INSERT INTO ROIC_PST000_LOG
      ( PROC_NAME, RUN_SEQ, RUN_DESC, PARAMETER_DESC )
    VALUES
      ( sPROC_NAME, sRUN_SEQ, sRUN_DESC, sPARAMETER_DESC );
  Commit;

     --(1)�M��������
     DELETE FROM ROIC_PST018_EXP_TO_PC
     where PERIOD       = YYYYMM
     AND   COMPANY_CODE = incompany
	 AND   PROC_NAME    = sPROC_NAME;
     COMMIT;       

     DELETE FROM ROIC_PST018_EXP_TO_PC
     where PERIOD       = YYYYMM
     AND   FROM_COMPANY_CODE = incompany
	 AND   PROC_NAME    = sPROC_NAME;
     COMMIT;              
           
     DELETE FROM ROIC_MAP018_ORGANIZATION_EXP   
     where PERIOD       = YYYYMM
     AND   COMPANY_CODE = incompany;
     COMMIT; 
     
     
     --(2)���o���u���v
     BEGIN
     select WW_RATIO ,LEGAL_RATIO  INTO tmp_WW_RATIO, tmp_LEGAL_RATIO  FROM ROA_UPL007_WW_LEGAL WHERE COMPANY_CODE = incompany
     AND PERIOD = YYYYMM; 
     EXCEPTION
       WHEN NO_DATA_FOUND THEN  -- catches all 'no data found' errors
       tmp_WW_RATIO := 0;   
       tmp_LEGAL_RATIO  := 0;     
     END;    
     
     CORP2_NORMAL_CODE := 'COP2001';
     CORP2_NOFOUND_CODE := 'NOT0001';    
    
  FOR REC1 IN FROM_DATA LOOP    
         
         if REC1.ROA_PC IS NOT NULL then    
           /*  ---------A---------  */
           tmp_ALLOC_TYPE := 'A1'; 
           tmp_PC := REC1.ROA_PC;
           INSERT_DATA(REC1.COMPANY_CODE,REC1.COST_ELEMENT ,REC1.CATEGORY  ,REC1.FUN_AREA ,REC1.SENDER , REC1.GROUP_ACCT,
	       REC1.AMT_LOC ,REC1.AMT_TWD,REC1.AMT_USD ,REC1.AMT_CNY, REC1.HOLDING_LEGAIL_CODE, REC1.CLASS_CODE, REC1.REASON_CODE, 
		   REC1.NAME_BUDGET_EN, REC1.FROM_SITE, REC1.SORTKEY, REC1.REMARK, REC1.PROFIT_CENTER, REC1.DATA_TYPE, '', 0, 0,tmp_PC,tmp_ALLOC_TYPE,REC1.COMPANY_CODE,REC1.GROUP1 );		   
		   
           /*
		   INSERT_DATA(REC1.FROM_SITE, REC1.ASSET_NO ,REC1.ASSET_SUB_NO ,REC1.SENDER_COST_CENTER ,REC1.RECEIVER_COST_CENTER ,
           tmp_PC , tmp_ALLOC_TYPE ,REC1.OWN_TYPE , 
		   REC1.ACQ_VAL ,    REC1.BOOK_VAL ,
		   REC1.ACQ_VAL_TWD ,REC1.BOOK_VAL_TWD ,
		   REC1.ACQ_VAL_USD ,REC1.BOOK_VAL_USD ,
		   REC1.ACQ_VAL_CNY ,REC1.BOOK_VAL_CNY ,REC1.REASON_CODE , REC1.USE_CODE , REC1.CLASS_CODE,REC1.S_SEQ,'',REC1.ACQ_VAL,REC1.BOOK_VAL,0,0);
		   */
         ELSIF REC1.EM_ACCOUNT = 'Attribution directly' THEN  
           /*  ---------B---------  */
           tmp_ALLOC_TYPE := 'B1';
           tmp_PC := REC1.NEW_PROFIT_CENTER;
           INSERT_DATA(REC1.COMPANY_CODE,REC1.COST_ELEMENT ,REC1.CATEGORY  ,REC1.FUN_AREA ,REC1.SENDER , REC1.GROUP_ACCT,
	       REC1.AMT_LOC ,REC1.AMT_TWD,REC1.AMT_USD ,REC1.AMT_CNY, REC1.HOLDING_LEGAIL_CODE, REC1.CLASS_CODE, REC1.REASON_CODE, 
		   REC1.NAME_BUDGET_EN, REC1.FROM_SITE, REC1.SORTKEY, REC1.REMARK, REC1.PROFIT_CENTER, REC1.DATA_TYPE, '', 0, 0,tmp_PC,tmp_ALLOC_TYPE,REC1.COMPANY_CODE,REC1.GROUP1 );			   
		   
		   /*
           INSERT_DATA(REC1.FROM_SITE,REC1.ASSET_NO ,REC1.ASSET_SUB_NO ,REC1.SENDER_COST_CENTER ,REC1.RECEIVER_COST_CENTER ,
           tmp_PC , tmp_ALLOC_TYPE ,REC1.OWN_TYPE , 		   
		   REC1.ACQ_VAL ,    REC1.BOOK_VAL ,
		   REC1.ACQ_VAL_TWD ,REC1.BOOK_VAL_TWD ,
		   REC1.ACQ_VAL_USD ,REC1.BOOK_VAL_USD ,
		   REC1.ACQ_VAL_CNY ,REC1.BOOK_VAL_CNY ,REC1.REASON_CODE , REC1.USE_CODE , REC1.CLASS_CODE,REC1.S_SEQ,'',REC1.ACQ_VAL,REC1.BOOK_VAL,0,0);    
           */		   
         ELSIF REC1.EM_ACCOUNT = 'Allocation-Corporate3' THEN  
           /*  ---------C---------  */
           tmp_ALLOC_TYPE := 'C1';
           tmp_PC := '0000000093';
           INSERT_DATA(REC1.COMPANY_CODE,REC1.COST_ELEMENT ,REC1.CATEGORY  ,REC1.FUN_AREA ,REC1.SENDER , REC1.GROUP_ACCT,
	       REC1.AMT_LOC ,REC1.AMT_TWD,REC1.AMT_USD ,REC1.AMT_CNY, REC1.HOLDING_LEGAIL_CODE,REC1.CLASS_CODE, REC1.REASON_CODE, 
		   REC1.NAME_BUDGET_EN, REC1.FROM_SITE, REC1.SORTKEY, REC1.REMARK, REC1.PROFIT_CENTER, REC1.DATA_TYPE, '', 0, 0,tmp_PC,tmp_ALLOC_TYPE,REC1.COMPANY_CODE,REC1.GROUP1 );	         
		   /*
		   INSERT_DATA(REC1.FROM_SITE,REC1.ASSET_NO ,REC1.ASSET_SUB_NO ,REC1.SENDER_COST_CENTER ,REC1.RECEIVER_COST_CENTER ,
           tmp_PC , tmp_ALLOC_TYPE ,REC1.OWN_TYPE , REC1.ACQ_VAL ,REC1.BOOK_VAL ,
           REC1.ACQ_VAL_TWD ,REC1.BOOK_VAL_TWD ,
		   REC1.ACQ_VAL_USD ,REC1.BOOK_VAL_USD ,
		   REC1.ACQ_VAL_CNY ,REC1.BOOK_VAL_CNY ,REC1.REASON_CODE , REC1.USE_CODE , REC1.CLASS_CODE, REC1.S_SEQ,'',REC1.ACQ_VAL,REC1.BOOK_VAL,0,0);       
           */		   
         ELSIF REC1.EM_ACCOUNT = 'Allocation-Corporate2' and ( tmp_WW_RATIO = 0 and tmp_LEGAL_RATIO = 0 ) THEN  
           /*  ---------D---------  */        
           tmp_ALLOC_TYPE := 'D1'; 
           RATE_FLAG := 'F';             
           FOR REC3 IN (
           select LPAD(PC, 10, '0') PC, RATIO FROM ROA_UPL006_ALLC_CORP2 WHERE COMPANY_CODE = REC1.COMPANY_CODE AND PERIOD = REC1.PERIOD AND RATIO > 0  AND AS2_CODE = CORP2_NORMAL_CODE
           )
           LOOP   
             RATE_FLAG := 'T'; 
             tmp_PC := REC3.PC;
             TMP_AMT1 := ROUND(REC1.AMT_LOC  / 100 * REC3.RATIO, 5);
             TMP_AMT2 := ROUND(REC1.AMT_TWD  / 100 * REC3.RATIO, 5);
             TMP_AMT3 := ROUND(REC1.AMT_USD  / 100 * REC3.RATIO, 5);
             TMP_AMT4 := ROUND(REC1.AMT_CNY  / 100 * REC3.RATIO, 5);			 
             INSERT_DATA(REC1.COMPANY_CODE,REC1.COST_ELEMENT ,REC1.CATEGORY  ,REC1.FUN_AREA ,REC1.SENDER , REC1.GROUP_ACCT,
	         TMP_AMT1 ,TMP_AMT2,TMP_AMT3 ,TMP_AMT4, REC1.HOLDING_LEGAIL_CODE, REC1.CLASS_CODE,REC1.REASON_CODE, 
		     REC1.NAME_BUDGET_EN, REC1.FROM_SITE, REC1.SORTKEY, REC1.REMARK, REC1.PROFIT_CENTER, REC1.DATA_TYPE, CORP2_NORMAL_CODE, REC3.RATIO, 0,tmp_PC,tmp_ALLOC_TYPE,REC1.COMPANY_CODE,REC1.GROUP1 );				 
             /*			 
             INSERT_DATA(REC1.FROM_SITE,REC1.ASSET_NO ,REC1.ASSET_SUB_NO ,REC1.SENDER_COST_CENTER ,REC1.RECEIVER_COST_CENTER ,
             tmp_PC , tmp_ALLOC_TYPE ,REC1.OWN_TYPE , TMP_AMT1 ,TMP_AMT2,TMP_AMT3 ,TMP_AMT4,TMP_AMT5 ,TMP_AMT6,TMP_AMT7 ,TMP_AMT8 ,
			 REC1.REASON_CODE , REC1.USE_CODE , REC1.CLASS_CODE,REC1.S_SEQ,CORP2_NORMAL_CODE,REC1.ACQ_VAL,REC1.BOOK_VAL,REC3.RATIO,0);    
             */			 
           END LOOP;  
           IF RATE_FLAG = 'F' THEN           
             NO_RATE(REC1.COMPANY_CODE,REC1.FROM_SITE,REC1.COST_ELEMENT ,REC1.CATEGORY  ,REC1.FUN_AREA ,REC1.SENDER , REC1.GROUP_ACCT,
	         REC1.AMT_LOC ,REC1.AMT_TWD,REC1.AMT_USD ,REC1.AMT_CNY, REC1.HOLDING_LEGAIL_CODE, REC1.CLASS_CODE, REC1.REASON_CODE, REC1.NAME_BUDGET_EN, REC1.FROM_SITE,
             REC1.SORTKEY, REC1.REMARK, REC1.PROFIT_CENTER, REC1.DATA_TYPE, '', 0, 0,tmp_PC,tmp_ALLOC_TYPE,REC1.GROUP1 );             
			 /*
			 NO_RATE (REC1.COMPANY_CODE,REC1.FROM_SITE,REC1.PERIOD,REC1.ASSET_NO ,REC1.ASSET_SUB_NO ,REC1.SENDER_COST_CENTER ,REC1.RECEIVER_COST_CENTER ,
             tmp_PC , tmp_ALLOC_TYPE ,REC1.OWN_TYPE , REC1.ACQ_VAL ,REC1.BOOK_VAL,
			 REC1.ACQ_VAL_TWD ,REC1.BOOK_VAL_TWD ,
		     REC1.ACQ_VAL_USD ,REC1.BOOK_VAL_USD ,
		     REC1.ACQ_VAL_CNY ,REC1.BOOK_VAL_CNY ,REC1.REASON_CODE , REC1.USE_CODE , REC1.CLASS_CODE ,REC1.S_SEQ);
			 */
           end IF;
           
                      
         ELSIF REC1.EM_ACCOUNT = 'Allocation-Corporate2' and ( tmp_WW_RATIO > 0 and tmp_LEGAL_RATIO > 0  ) THEN  
           /*  ---------E---------  */            
           --------  
           RATE_FLAG := 'F';
           FOR REC3 IN (
           select LPAD(PC, 10, '0') PC, RATIO FROM ROA_UPL006_ALLC_CORP2 WHERE COMPANY_CODE = REC1.COMPANY_CODE AND PERIOD = REC1.PERIOD AND RATIO > 0  AND AS2_CODE = CORP2_NORMAL_CODE
           )
           LOOP    
             --rate main: 10		   
             RATE_FLAG := 'T'; 
             tmp_ALLOC_TYPE := 'E1'; 
             tmp_PC := REC3.PC;
             TMP_AMT1 := ROUND(REC1.AMT_LOC  / 100 * REC3.RATIO / 100 * tmp_LEGAL_RATIO, 5);
             TMP_AMT2 := ROUND(REC1.AMT_TWD  / 100 * REC3.RATIO / 100 * tmp_LEGAL_RATIO, 5);
             TMP_AMT3 := ROUND(REC1.AMT_USD  / 100 * REC3.RATIO / 100 * tmp_LEGAL_RATIO, 5);
             TMP_AMT4 := ROUND(REC1.AMT_CNY  / 100 * REC3.RATIO / 100 * tmp_LEGAL_RATIO, 5);

             INSERT_DATA(REC1.COMPANY_CODE,REC1.COST_ELEMENT ,REC1.CATEGORY  ,REC1.FUN_AREA ,REC1.SENDER , REC1.GROUP_ACCT,
	         TMP_AMT1 ,TMP_AMT2,TMP_AMT3 ,TMP_AMT4, REC1.HOLDING_LEGAIL_CODE, REC1.CLASS_CODE, REC1.REASON_CODE, REC1.NAME_BUDGET_EN, REC1.FROM_SITE,
             REC1.SORTKEY, REC1.REMARK, REC1.PROFIT_CENTER, REC1.DATA_TYPE, CORP2_NORMAL_CODE, REC3.RATIO, tmp_LEGAL_RATIO,tmp_PC,tmp_ALLOC_TYPE,REC1.COMPANY_CODE,REC1.GROUP1 );				 
             /*
			 INSERT_DATA(REC1.FROM_SITE,REC1.ASSET_NO ,REC1.ASSET_SUB_NO ,REC1.SENDER_COST_CENTER ,REC1.RECEIVER_COST_CENTER ,
             tmp_PC , tmp_ALLOC_TYPE ,REC1.OWN_TYPE , TMP_AMT1 ,TMP_AMT2 ,TMP_AMT3 ,TMP_AMT4,TMP_AMT5 ,TMP_AMT6,TMP_AMT7 ,TMP_AMT8 ,
			 REC1.REASON_CODE , REC1.USE_CODE , REC1.CLASS_CODE,REC1.S_SEQ,CORP2_NORMAL_CODE,REC1.ACQ_VAL,REC1.BOOK_VAL,REC3.RATIO,tmp_LEGAL_RATIO);   
             */			 
           END LOOP;           
           IF RATE_FLAG = 'F' THEN           
             NO_RATE(REC1.COMPANY_CODE,REC1.FROM_SITE,REC1.COST_ELEMENT ,REC1.CATEGORY  ,REC1.FUN_AREA ,REC1.SENDER , REC1.GROUP_ACCT,
	         REC1.AMT_LOC ,REC1.AMT_TWD,REC1.AMT_USD ,REC1.AMT_CNY, REC1.HOLDING_LEGAIL_CODE,REC1.CLASS_CODE, REC1.REASON_CODE, REC1.NAME_BUDGET_EN, REC1.FROM_SITE,
             REC1.SORTKEY, REC1.REMARK, REC1.PROFIT_CENTER, REC1.DATA_TYPE, '', 0, 0,tmp_PC,tmp_ALLOC_TYPE ,REC1.GROUP1);               
			 /*
			 NO_RATE (REC1.COMPANY_CODE,REC1.FROM_SITE,REC1.PERIOD,REC1.ASSET_NO ,REC1.ASSET_SUB_NO ,REC1.SENDER_COST_CENTER ,REC1.RECEIVER_COST_CENTER ,
             tmp_PC , tmp_ALLOC_TYPE ,REC1.OWN_TYPE , REC1.ACQ_VAL ,REC1.BOOK_VAL,
			 REC1.ACQ_VAL_TWD ,REC1.BOOK_VAL_TWD ,
		     REC1.ACQ_VAL_USD ,REC1.BOOK_VAL_USD ,
		     REC1.ACQ_VAL_CNY ,REC1.BOOK_VAL_CNY ,REC1.REASON_CODE , REC1.USE_CODE , REC1.CLASS_CODE ,REC1.S_SEQ);
			 */
           end IF;          
           --------
             
           RATE_FLAG := 'F'; 
           FOR REC3 IN (
           select LPAD(PC, 10, '0') PC, RATIO  FROM ROA_UPL006_ALLC_CORP2 WHERE COMPANY_CODE = 'A999' AND PERIOD = REC1.PERIOD AND RATIO > 0  AND AS2_CODE = CORP2_NORMAL_CODE
           )
           LOOP  
		     --rate A999: 90
             RATE_FLAG := 'T'; 
             tmp_ALLOC_TYPE := 'E2'; 
             tmp_PC := REC3.PC;
             TMP_AMT1 := ROUND(REC1.AMT_LOC  / 100 * REC3.RATIO / 100 * tmp_WW_RATIO, 5);
             TMP_AMT2 := ROUND(REC1.AMT_TWD  / 100 * REC3.RATIO / 100 * tmp_WW_RATIO, 5);
             TMP_AMT3 := ROUND(REC1.AMT_USD  / 100 * REC3.RATIO / 100 * tmp_WW_RATIO, 5);
             TMP_AMT4 := ROUND(REC1.AMT_CNY  / 100 * REC3.RATIO / 100 * tmp_WW_RATIO, 5);

             INSERT_DATA2('A999',REC1.COST_ELEMENT ,REC1.CATEGORY  ,REC1.FUN_AREA ,REC1.SENDER , REC1.GROUP_ACCT,
	         TMP_AMT1 ,TMP_AMT2,TMP_AMT3 ,TMP_AMT4, REC1.HOLDING_LEGAIL_CODE, REC1.CLASS_CODE, REC1.REASON_CODE, REC1.NAME_BUDGET_EN, REC1.FROM_SITE,
             REC1.SORTKEY, REC1.REMARK, REC1.PROFIT_CENTER, REC1.DATA_TYPE, CORP2_NORMAL_CODE, REC3.RATIO, tmp_WW_RATIO,tmp_PC,tmp_ALLOC_TYPE,REC1.COMPANY_CODE,REC1.GROUP1 );				 

			 /*
             INSERT_DATA2('A999',REC1.ASSET_NO ,REC1.ASSET_SUB_NO ,REC1.SENDER_COST_CENTER ,REC1.RECEIVER_COST_CENTER ,
             tmp_PC , tmp_ALLOC_TYPE ,REC1.OWN_TYPE , TMP_AMT1 ,TMP_AMT2 ,TMP_AMT3 ,TMP_AMT4,TMP_AMT5 ,TMP_AMT6,TMP_AMT7 ,TMP_AMT8 ,
			 REC1.REASON_CODE , REC1.USE_CODE , REC1.CLASS_CODE,REC1.S_SEQ,CORP2_NORMAL_CODE,REC1.ACQ_VAL,REC1.BOOK_VAL,REC3.RATIO,tmp_WW_RATIO); 
             */
           END LOOP; 
           IF RATE_FLAG = 'F' THEN           
             NO_RATE(REC1.COMPANY_CODE,REC1.FROM_SITE,REC1.COST_ELEMENT ,REC1.CATEGORY  ,REC1.FUN_AREA ,REC1.SENDER , REC1.GROUP_ACCT,
	         REC1.AMT_LOC ,REC1.AMT_TWD,REC1.AMT_USD ,REC1.AMT_CNY, REC1.HOLDING_LEGAIL_CODE,REC1.CLASS_CODE, REC1.REASON_CODE, REC1.NAME_BUDGET_EN, REC1.FROM_SITE,
             REC1.SORTKEY, REC1.REMARK, REC1.PROFIT_CENTER, REC1.DATA_TYPE, '', 0, 0,tmp_PC,tmp_ALLOC_TYPE,REC1.GROUP1 );  

             /*
			 NO_RATE (REC1.COMPANY_CODE,REC1.FROM_SITE,REC1.PERIOD,REC1.ASSET_NO ,REC1.ASSET_SUB_NO ,REC1.SENDER_COST_CENTER ,REC1.RECEIVER_COST_CENTER ,
             tmp_PC , tmp_ALLOC_TYPE ,REC1.OWN_TYPE , REC1.ACQ_VAL ,REC1.BOOK_VAL,
			 REC1.ACQ_VAL_TWD ,REC1.BOOK_VAL_TWD ,
		     REC1.ACQ_VAL_USD ,REC1.BOOK_VAL_USD ,
		     REC1.ACQ_VAL_CNY ,REC1.BOOK_VAL_CNY ,REC1.REASON_CODE , REC1.USE_CODE , REC1.CLASS_CODE ,REC1.S_SEQ);
			 */
           end IF;                       
         ELSIF ( REC1.EM_ACCOUNT = 'Allocation-Corporate1' OR REC1.EM_ACCOUNT = 'Allocation-BG' ) AND REC1.CATEGORY = 'OH' THEN   --OH         
            /*  ---------F---------  */  
           If REC1.ROA_PD IS NOT NULL then
             select sum(MH_RATE) INTO TMP_TTL_MHRATE FROM ROA_SAP002_CO_MH_RATE WHERE COMPANY_CODE = REC1.COMPANY_CODE AND PERIOD = REC1.PERIOD AND ROA_PD = REC1.ROA_PD;
             If TMP_TTL_MHRATE IS NOT NULL and TMP_TTL_MHRATE > 0 then  
             
               RATE_FLAG := 'F'; 
               FOR REC3 IN (
               select LPAD(PC, 10, '0') PC, MH_RATE FROM ROA_SAP002_CO_MH_RATE WHERE COMPANY_CODE = REC1.COMPANY_CODE AND PERIOD = REC1.PERIOD AND ROA_PD = REC1.ROA_PD    
               )
               LOOP  
                 RATE_FLAG := 'T'; 
                 tmp_ALLOC_TYPE := 'F1'; 
                 tmp_PC := REC3.PC;
                 TMP_AMT1 := ROUND(REC1.AMT_LOC * REC3.MH_RATE , 5);
                 TMP_AMT2 := ROUND(REC1.AMT_TWD * REC3.MH_RATE , 5);
                 TMP_AMT3 := ROUND(REC1.AMT_USD * REC3.MH_RATE , 5);
                 TMP_AMT4 := ROUND(REC1.AMT_CNY * REC3.MH_RATE , 5);
             
			     INSERT_DATA(REC1.COMPANY_CODE,REC1.COST_ELEMENT ,REC1.CATEGORY  ,REC1.FUN_AREA ,REC1.SENDER , REC1.GROUP_ACCT,
	             TMP_AMT1 ,TMP_AMT2,TMP_AMT3 ,TMP_AMT4, REC1.HOLDING_LEGAIL_CODE,REC1.CLASS_CODE, REC1.REASON_CODE, REC1.NAME_BUDGET_EN, REC1.FROM_SITE,
                 REC1.SORTKEY, REC1.REMARK, REC1.PROFIT_CENTER, REC1.DATA_TYPE, REC1.ROA_PD, REC3.MH_RATE, 0,tmp_PC,tmp_ALLOC_TYPE,REC1.COMPANY_CODE,REC1.GROUP1 );				 
				 
				 /*	 
                 INSERT_DATA(REC1.FROM_SITE,REC1.ASSET_NO ,REC1.ASSET_SUB_NO ,REC1.SENDER_COST_CENTER ,REC1.RECEIVER_COST_CENTER ,
                 tmp_PC , tmp_ALLOC_TYPE ,REC1.OWN_TYPE , TMP_AMT1 ,TMP_AMT2 ,TMP_AMT3 ,TMP_AMT4,TMP_AMT5 ,TMP_AMT6,TMP_AMT7 ,TMP_AMT8 ,
				 REC1.REASON_CODE , REC1.USE_CODE , REC1.CLASS_CODE,REC1.S_SEQ,REC1.ROA_PD,REC1.ACQ_VAL,REC1.BOOK_VAL,REC3.MH_RATE,0);   
                 */				 
               END LOOP; 
               IF RATE_FLAG = 'F' THEN     
                 NO_RATE(REC1.COMPANY_CODE,REC1.FROM_SITE,REC1.COST_ELEMENT ,REC1.CATEGORY  ,REC1.FUN_AREA ,REC1.SENDER , REC1.GROUP_ACCT,
	             REC1.AMT_LOC ,REC1.AMT_TWD,REC1.AMT_USD ,REC1.AMT_CNY, REC1.HOLDING_LEGAIL_CODE,REC1.CLASS_CODE, REC1.REASON_CODE, REC1.NAME_BUDGET_EN, REC1.FROM_SITE,
                 REC1.SORTKEY, REC1.REMARK, REC1.PROFIT_CENTER, REC1.DATA_TYPE, '', 0, 0,tmp_PC,tmp_ALLOC_TYPE ,REC1.GROUP1 );  			   
                 /*			   
                 NO_RATE (REC1.COMPANY_CODE,REC1.FROM_SITE,REC1.PERIOD,REC1.ASSET_NO ,REC1.ASSET_SUB_NO ,REC1.SENDER_COST_CENTER ,REC1.RECEIVER_COST_CENTER ,
                 tmp_PC , tmp_ALLOC_TYPE ,REC1.OWN_TYPE , REC1.ACQ_VAL ,REC1.BOOK_VAL, 
				 REC1.ACQ_VAL_TWD ,REC1.BOOK_VAL_TWD ,
		         REC1.ACQ_VAL_USD ,REC1.BOOK_VAL_USD ,
		         REC1.ACQ_VAL_CNY ,REC1.BOOK_VAL_CNY ,REC1.REASON_CODE , REC1.USE_CODE , REC1.CLASS_CODE,REC1.S_SEQ);
				 */
               end IF;                            
                
             ELSIF TMP_TTL_MHRATE IS NULL OR TMP_TTL_MHRATE = 0 then    
               --RATE = 0 ���O���������v    
               --����LH RATE�A�YLH RATE�������A�A���W��������MH RATE��
               select sum(LH_RATE) INTO TMP_TTL_LHRATE FROM ROIC_SAP002_CO_LH_RATE WHERE COMPANY_CODE = REC1.COMPANY_CODE AND PERIOD = REC1.PERIOD AND ROA_PD = REC1.ROA_PD;
               If TMP_TTL_LHRATE IS NOT NULL and TMP_TTL_LHRATE > 0 then 
                 
                 RATE_FLAG := 'F'; 
                 FOR REC4 IN (
                   select LPAD(PC, 10, '0') PC, LH_RATE FROM ROIC_SAP002_CO_LH_RATE WHERE COMPANY_CODE = REC1.COMPANY_CODE AND PERIOD = REC1.PERIOD AND ROA_PD = REC1.ROA_PD    
                 )
                 LOOP  
                   RATE_FLAG := 'T'; 
                   tmp_ALLOC_TYPE := 'F4'; 
                   tmp_PC := REC4.PC;
                   TMP_AMT1 := ROUND(REC1.AMT_LOC  * REC4.LH_RATE , 5);
                   TMP_AMT2 := ROUND(REC1.AMT_TWD  * REC4.LH_RATE , 5);
                   TMP_AMT3 := ROUND(REC1.AMT_USD  * REC4.LH_RATE , 5);
                   TMP_AMT4 := ROUND(REC1.AMT_CNY  * REC4.LH_RATE , 5);
				   
			       INSERT_DATA(REC1.COMPANY_CODE,REC1.COST_ELEMENT ,REC1.CATEGORY  ,REC1.FUN_AREA ,REC1.SENDER , REC1.GROUP_ACCT,
	               TMP_AMT1 ,TMP_AMT2,TMP_AMT3 ,TMP_AMT4, REC1.HOLDING_LEGAIL_CODE,REC1.CLASS_CODE, REC1.REASON_CODE, REC1.NAME_BUDGET_EN, REC1.FROM_SITE,
                   REC1.SORTKEY, REC1.REMARK, REC1.PROFIT_CENTER, REC1.DATA_TYPE, REC1.ROA_PD, REC4.LH_RATE, 0,tmp_PC,tmp_ALLOC_TYPE,REC1.COMPANY_CODE,REC1.GROUP1 );					 
				   /*
                   INSERT_DATA(REC1.FROM_SITE,REC1.ASSET_NO ,REC1.ASSET_SUB_NO ,REC1.SENDER_COST_CENTER ,REC1.RECEIVER_COST_CENTER ,
                   tmp_PC , tmp_ALLOC_TYPE ,REC1.OWN_TYPE , TMP_AMT1 ,TMP_AMT2 ,TMP_AMT3 ,TMP_AMT4,TMP_AMT5 ,TMP_AMT6,TMP_AMT7 ,TMP_AMT8 ,
				   REC1.REASON_CODE , REC1.USE_CODE , REC1.CLASS_CODE,REC1.S_SEQ,REC1.ROA_PD,REC1.ACQ_VAL,REC1.BOOK_VAL,REC4.LH_RATE,0); 
                   */				   
                 END LOOP; 
                 IF RATE_FLAG = 'F' THEN           
                   NO_RATE(REC1.COMPANY_CODE,REC1.FROM_SITE,REC1.COST_ELEMENT ,REC1.CATEGORY  ,REC1.FUN_AREA ,REC1.SENDER , REC1.GROUP_ACCT,
	               REC1.AMT_LOC ,REC1.AMT_TWD,REC1.AMT_USD ,REC1.AMT_CNY, REC1.HOLDING_LEGAIL_CODE,REC1.CLASS_CODE, REC1.REASON_CODE, REC1.NAME_BUDGET_EN, REC1.FROM_SITE,
                   REC1.SORTKEY, REC1.REMARK, REC1.PROFIT_CENTER, REC1.DATA_TYPE, '', 0, 0,tmp_PC,tmp_ALLOC_TYPE ,REC1.GROUP1 );                     
				   /*
				   NO_RATE (REC1.COMPANY_CODE,REC1.FROM_SITE,REC1.PERIOD,REC1.ASSET_NO ,REC1.ASSET_SUB_NO ,REC1.SENDER_COST_CENTER ,REC1.RECEIVER_COST_CENTER ,
                   tmp_PC , tmp_ALLOC_TYPE ,REC1.OWN_TYPE , REC1.ACQ_VAL ,REC1.BOOK_VAL, 
				   REC1.ACQ_VAL_TWD ,REC1.BOOK_VAL_TWD ,
		           REC1.ACQ_VAL_USD ,REC1.BOOK_VAL_USD ,
		           REC1.ACQ_VAL_CNY ,REC1.BOOK_VAL_CNY ,REC1.REASON_CODE , REC1.USE_CODE , REC1.CLASS_CODE,REC1.S_SEQ);
				   */
                 end IF;                
                
               
                
               ELSIF TMP_TTL_LHRATE IS NULL OR TMP_TTL_LHRATE = 0 then     
                 --��W��������MH RATE��
                 --���o�i�H����ROAPD
                 TMP_ROA_PD := REC1.ROA_PD;    --
                 LOOP    
                   If SUBSTR(TMP_ROA_PD,4,4) = '0000' then 
                     TMP_ROA_PD :=  SUBSTR(TMP_ROA_PD,1,1) || '000000';
                   ELSIF SUBSTR(TMP_ROA_PD,6,2) = '00' then 
                     TMP_ROA_PD :=  SUBSTR(TMP_ROA_PD,1,3) || '0000';
                   ELSIF SUBSTR(TMP_ROA_PD,6,2) <> '00' then
                     TMP_ROA_PD :=  SUBSTR(TMP_ROA_PD,1,5) || '00';
                   end if;
                   select sum(MH_RATE) INTO TMP_TTL_MHRATE FROM ROA_SAP002_CO_MH_RATE WHERE COMPANY_CODE = REC1.COMPANY_CODE AND PERIOD = REC1.PERIOD AND ROA_PD = TMP_ROA_PD;                
                   EXIT WHEN TMP_TTL_MHRATE > 0 OR TMP_ROA_PD = 'P000000';
                 END LOOP;   
                 
               

                 FOR REC3 IN (  
                   select LPAD(PC, 10, '0') PC, MH_RATE FROM ROA_SAP002_CO_MH_RATE WHERE COMPANY_CODE = REC1.COMPANY_CODE AND PERIOD = REC1.PERIOD AND ROA_PD = TMP_ROA_PD
                 )
                 LOOP
                   tmp_PC := REC3.PC;  
                   tmp_ALLOC_TYPE := 'F2';  
                   TMP_AMT1 := ROUND(REC1.AMT_LOC  * REC3.MH_RATE , 5);
                   TMP_AMT2 := ROUND(REC1.AMT_TWD  * REC3.MH_RATE , 5);
                   TMP_AMT3 := ROUND(REC1.AMT_USD  * REC3.MH_RATE , 5);
                   TMP_AMT4 := ROUND(REC1.AMT_CNY  * REC3.MH_RATE , 5);
				   
				   
			       INSERT_DATA(REC1.FROM_SITE,REC1.COST_ELEMENT ,REC1.CATEGORY  ,REC1.FUN_AREA ,REC1.SENDER , REC1.GROUP_ACCT,
	               TMP_AMT1 ,TMP_AMT2,TMP_AMT3 ,TMP_AMT4, REC1.HOLDING_LEGAIL_CODE,REC1.CLASS_CODE, REC1.REASON_CODE, REC1.NAME_BUDGET_EN, REC1.FROM_SITE,
                   REC1.SORTKEY, REC1.REMARK, REC1.PROFIT_CENTER, REC1.DATA_TYPE, TMP_ROA_PD, REC3.MH_RATE, 0,tmp_PC,tmp_ALLOC_TYPE,REC1.COMPANY_CODE,REC1.GROUP1 );					 
			 
			       /*
                   INSERT_DATA(REC1.FROM_SITE,REC1.ASSET_NO ,REC1.ASSET_SUB_NO ,REC1.SENDER_COST_CENTER ,REC1.RECEIVER_COST_CENTER ,
                   tmp_PC , tmp_ALLOC_TYPE ,REC1.OWN_TYPE , TMP_AMT1 ,TMP_AMT2 ,TMP_AMT3 ,TMP_AMT4,TMP_AMT5 ,TMP_AMT6,TMP_AMT7 ,TMP_AMT8 ,
				   REC1.REASON_CODE , REC1.USE_CODE , REC1.CLASS_CODE,REC1.S_SEQ,TMP_ROA_PD,REC1.ACQ_VAL,REC1.BOOK_VAL,REC3.MH_RATE,0);              
                   */
				 END LOOP;               
                             
               end IF; 

             end if; 
              
             
           else
             tmp_ALLOC_TYPE := 'F3';                 
             FOR REC3 IN (  
             select LPAD(PC, 10, '0') PC, MH_RATE FROM ROA_SAP002_CO_MH_RATE WHERE COMPANY_CODE = REC1.COMPANY_CODE AND PERIOD = REC1.PERIOD AND ROA_PD = 'P000000'
             )
             LOOP
               tmp_PC := REC3.PC;
               TMP_AMT1 := ROUND(REC1.AMT_LOC * REC3.MH_RATE , 5);
               TMP_AMT2 := ROUND(REC1.AMT_TWD * REC3.MH_RATE , 5);
               TMP_AMT3 := ROUND(REC1.AMT_USD * REC3.MH_RATE , 5);
               TMP_AMT4 := ROUND(REC1.AMT_CNY * REC3.MH_RATE , 5);
			   
			   INSERT_DATA(REC1.FROM_SITE,REC1.COST_ELEMENT ,REC1.CATEGORY  ,REC1.FUN_AREA ,REC1.SENDER , REC1.GROUP_ACCT,
	           TMP_AMT1 ,TMP_AMT2,TMP_AMT3 ,TMP_AMT4, REC1.HOLDING_LEGAIL_CODE,REC1.CLASS_CODE, REC1.REASON_CODE, REC1.NAME_BUDGET_EN, REC1.FROM_SITE,
               REC1.SORTKEY, REC1.REMARK, REC1.PROFIT_CENTER, REC1.DATA_TYPE, 'P000000', REC3.MH_RATE, 0,tmp_PC,tmp_ALLOC_TYPE,REC1.COMPANY_CODE,REC1.GROUP1 );					 

		       /*
               INSERT_DATA(REC1.FROM_SITE,REC1.ASSET_NO ,REC1.ASSET_SUB_NO ,REC1.SENDER_COST_CENTER ,REC1.RECEIVER_COST_CENTER ,
               tmp_PC , tmp_ALLOC_TYPE ,REC1.OWN_TYPE , TMP_AMT1 ,TMP_AMT2 ,TMP_AMT3 ,TMP_AMT4,TMP_AMT5 ,TMP_AMT6,TMP_AMT7 ,TMP_AMT8 ,
			   REC1.REASON_CODE , REC1.USE_CODE , REC1.CLASS_CODE,REC1.S_SEQ,'P000000',REC1.ACQ_VAL,REC1.BOOK_VAL,REC3.MH_RATE,0); 
               */			   
             END LOOP;  
                      
           end if;
        
         
         ELSIF ( REC1.EM_ACCOUNT = 'Allocation-Corporate1' OR REC1.EM_ACCOUNT = 'Allocation-BG' ) AND REC1.CATEGORY <> 'OH'  THEN  --OP  
           /*  ---------G---------  */ 
           tmp_ALLOC_TYPE := 'G1';  
           RATE_FLAG := 'F';

           FOR REC3 IN ( 
             select * FROM HCA_UPL002_ALLOCATION_OP WHERE COMPANY_CODE = REC1.COMPANY_CODE AND PERIOD = REC1.PERIOD AND COST_CENTER = REC1.SENDER
             AND ALLOCATION_RATIO > 0 
           )
           LOOP
             tmp_PC := REC3.PC;
             TMP_AMT1 := ROUND(REC1.AMT_LOC  * REC3.ALLOCATION_RATIO , 5);
             TMP_AMT2 := ROUND(REC1.AMT_TWD  * REC3.ALLOCATION_RATIO , 5);
             TMP_AMT3 := ROUND(REC1.AMT_USD  * REC3.ALLOCATION_RATIO , 5);
             TMP_AMT4 := ROUND(REC1.AMT_CNY  * REC3.ALLOCATION_RATIO , 5);

			 INSERT_DATA(REC1.COMPANY_CODE,REC1.COST_ELEMENT ,REC1.CATEGORY  ,REC1.FUN_AREA ,REC1.SENDER , REC1.GROUP_ACCT,
	         TMP_AMT1 ,TMP_AMT2,TMP_AMT3 ,TMP_AMT4, REC1.HOLDING_LEGAIL_CODE,REC1.CLASS_CODE, REC1.REASON_CODE, REC1.NAME_BUDGET_EN, REC1.FROM_SITE,
             REC1.SORTKEY, REC1.REMARK, REC1.PROFIT_CENTER, REC1.DATA_TYPE, '', REC3.ALLOCATION_RATIO, 0,tmp_PC,tmp_ALLOC_TYPE, REC1.COMPANY_CODE,REC1.GROUP1 );			 
             /*
			 INSERT_DATA(REC1.FROM_SITE,REC1.ASSET_NO ,REC1.ASSET_SUB_NO ,REC1.SENDER_COST_CENTER ,REC1.RECEIVER_COST_CENTER ,
             tmp_PC , tmp_ALLOC_TYPE ,REC1.OWN_TYPE , TMP_AMT1 ,TMP_AMT2 ,TMP_AMT3 ,TMP_AMT4,TMP_AMT5 ,TMP_AMT6,TMP_AMT7 ,TMP_AMT8 ,
			 REC1.REASON_CODE , REC1.USE_CODE , REC1.CLASS_CODE,REC1.S_SEQ,'',REC1.ACQ_VAL,REC1.BOOK_VAL,REC3.ALLOCATION_RATIO,0);  
             */
			 RATE_FLAG := 'T';                      
           END LOOP; 
           IF RATE_FLAG = 'F' THEN        
		   
             NO_RATE(REC1.COMPANY_CODE,REC1.COMPANY_CODE,REC1.COST_ELEMENT ,REC1.CATEGORY  ,REC1.FUN_AREA ,REC1.SENDER , REC1.GROUP_ACCT,
	         REC1.AMT_LOC ,REC1.AMT_TWD,REC1.AMT_USD ,REC1.AMT_CNY, REC1.HOLDING_LEGAIL_CODE,REC1.CLASS_CODE, REC1.REASON_CODE, REC1.NAME_BUDGET_EN, REC1.FROM_SITE,
             REC1.SORTKEY, REC1.REMARK, REC1.PROFIT_CENTER, REC1.DATA_TYPE, '', 0, 0,tmp_PC,tmp_ALLOC_TYPE ,REC1.GROUP1 ); 		   
             /*		   
             NO_RATE (REC1.COMPANY_CODE,REC1.FROM_SITE,REC1.PERIOD,REC1.ASSET_NO ,REC1.ASSET_SUB_NO ,REC1.SENDER_COST_CENTER ,REC1.RECEIVER_COST_CENTER ,
             tmp_PC , tmp_ALLOC_TYPE ,REC1.OWN_TYPE , REC1.ACQ_VAL ,REC1.BOOK_VAL, 
		     REC1.ACQ_VAL_TWD ,REC1.BOOK_VAL_TWD ,
		     REC1.ACQ_VAL_USD ,REC1.BOOK_VAL_USD ,
		     REC1.ACQ_VAL_CNY ,REC1.BOOK_VAL_CNY ,REC1.REASON_CODE , REC1.USE_CODE , REC1.CLASS_CODE ,REC1.S_SEQ);
			 */
           end IF;
           
                              
         else   
           /*  ---------H---------  */    
           tmp_ALLOC_TYPE := 'H1';
           tmp_PC :='NO FOUND';
           TMP_AMT1 := ROUND(REC1.AMT_LOC  , 5);
           TMP_AMT2 := ROUND(REC1.AMT_TWD  , 5);
           TMP_AMT3 := ROUND(REC1.AMT_USD  , 5);
           TMP_AMT4 := ROUND(REC1.AMT_CNY  , 5);
		   
		   INSERT_DATA(REC1.COMPANY_CODE,REC1.COST_ELEMENT ,REC1.CATEGORY  ,REC1.FUN_AREA ,REC1.SENDER , REC1.GROUP_ACCT,
	       TMP_AMT1 ,TMP_AMT2,TMP_AMT3 ,TMP_AMT4, REC1.HOLDING_LEGAIL_CODE,REC1.CLASS_CODE, REC1.REASON_CODE, REC1.NAME_BUDGET_EN, REC1.FROM_SITE,
           REC1.SORTKEY, REC1.REMARK, REC1.PROFIT_CENTER, REC1.DATA_TYPE, '', 0, 0,tmp_PC,tmp_ALLOC_TYPE, REC1.COMPANY_CODE,REC1.GROUP1 );	   
	       /*
           INSERT_DATA(REC1.FROM_SITE,REC1.ASSET_NO ,REC1.ASSET_SUB_NO ,REC1.SENDER_COST_CENTER ,REC1.RECEIVER_COST_CENTER ,
           tmp_PC , tmp_ALLOC_TYPE ,REC1.OWN_TYPE , TMP_AMT1 ,TMP_AMT2 ,TMP_AMT3 ,TMP_AMT4,TMP_AMT5 ,TMP_AMT6,TMP_AMT7 ,TMP_AMT8 ,
		   REC1.REASON_CODE , REC1.USE_CODE , REC1.CLASS_CODE,REC1.S_SEQ,'',REC1.ACQ_VAL,REC1.BOOK_VAL,0,0); 
           */		   
         end if;                      
    COMMIT;
      
  END LOOP; 
  
  
  FOR REC5 IN (  
  select * FROM KPI_MAP018_ORGANIZATION  WHERE COMPANY_CODE = incompany AND PERIOD = YYYYMM
  )
  LOOP
    INSERT_DATA3( REC5.PROFIT_CENTER,REC5.FUNCTION,REC5.UNIT,REC5.GROUP_ID,REC5.DIVISION,REC5.DEPARTMENT,REC5.SAP_COST_CENTER,
    REC5.BUDGET_COST,REC5.CATEGORY, REC5.EM_ACCOUNT,REC5.LOCATION,REC5.SECTIONS,REC5.PD,REC5.YEAR,REC5.ROA_PD,REC5.ROA_PC);         
  END LOOP;   
  
  --
  -----------------------------------------
  --(0)Insert Log end
  sRUN_SEQ   := '000020';
  sRUN_DESC  := 'End';

  --Insert Log
  INSERT INTO ROIC_PST000_LOG
      ( PROC_NAME, RUN_SEQ, RUN_DESC, PARAMETER_DESC )
    VALUES
      ( sPROC_NAME, sRUN_SEQ, sRUN_DESC, sPARAMETER_DESC );
  Commit;  
   
END ROIC_PLS018_EXP_TO_PC;
/

