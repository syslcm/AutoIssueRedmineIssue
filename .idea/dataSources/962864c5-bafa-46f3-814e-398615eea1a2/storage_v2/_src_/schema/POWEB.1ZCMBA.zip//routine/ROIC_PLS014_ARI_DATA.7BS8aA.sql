create PROCEDURE       ROIC_PLS014_ARI_DATA (
  inCompany  in VARCHAR2,
  f_YYYYMMDD in VARCHAR2,
  t_YYYYMMDD in VARCHAR2
)
AUTHID DEFINER
is
/*********************************************************************
  PROG-ID      : ROIC_PLS014_ARI_DATA
  PROG-ACTION  : A.R.I.(Allowance to Reduce Inventory) 
  Author       : Patty
  Date         : 2019/12/12
  OA No.       : SAI108486
  Process      :
  1. Transfer ROIC_SAP004_ARI_DATA_T to ROIC_SAP004_ARI_DATA by company_code
  2. 採取 'E'-中國人民銀行匯率,月底收盤價
**********************************************************************/
/*---------------------------------------------------------------------

---------------------------------------------------------------------*/

 t_CURRENCY_LOC      ROIC_SAP004_ARI_DATA.WAERS_LOC%TYPE;
 a_EX_RATE_TWD       ROIC_SAP004_ARI_DATA.EXCH_RATE_TWD%TYPE;
 a_EX_RATE_USD       ROIC_SAP004_ARI_DATA.EXCH_RATE_USD%TYPE;
 a_EX_RATE_CNY       ROIC_SAP004_ARI_DATA.EXCH_RATE_CNY%TYPE; 
 w_YYYY              VARCHAR2(4);
 w_MM                VARCHAR2(2);

 CURSOR C_PERIOD is 
       Select DISTINCT COMPANY_CODE, PERIOD FROM ROIC_SAP004_ARI_DATA_T 
              WHERE COMPANY_CODE = inCompany
              GROUP BY COMPANY_CODE, PERIOD;

BEGIN

  for REC1 in C_PERIOD loop

    --?CURRENCY_LOCAL
    t_CURRENCY_LOC := Null;
    Select * into t_CURRENCY_LOC From (
             Select distinct WAERS_LOC from ROIC_SAP004_ARI_DATA_T
             where COMPANY_CODE = REC1.COMPANY_CODE
               and PERIOD = REC1.PERIOD
               and ROWNUM <= 1
        );    

    a_EX_RATE_TWD := GET_EXCHANGE_RATE_RWF(SUBSTRB(REC1.PERIOD,1,4),SUBSTRB(REC1.PERIOD,5,2),t_CURRENCY_LOC,'TWD','E');	
    a_EX_RATE_USD := GET_EXCHANGE_RATE_RWF(SUBSTRB(REC1.PERIOD,1,4),SUBSTRB(REC1.PERIOD,5,2),t_CURRENCY_LOC,'USD','E');	
    a_EX_RATE_CNY := GET_EXCHANGE_RATE_RWF(SUBSTRB(REC1.PERIOD,1,4),SUBSTRB(REC1.PERIOD,5,2),t_CURRENCY_LOC,'CNY','E');	
 
   --(1) Delete Old Data  
    DELETE FROM ROIC_SAP004_ARI_DATA
           WHERE COMPANY_CODE = REC1.COMPANY_CODE
             AND PERIOD = REC1.PERIOD
             AND SRC    = 'SAP';
    Commit;
   
   --(2) Process Data

    UPDATE ROIC_SAP004_ARI_DATA_T
      SET SRC = 'SAP', 
          CREATE_USER = 'SYSTEM',
	  EXCH_RATE_TWD = a_EX_RATE_TWD,
	  EXCH_RATE_USD = a_EX_RATE_USD,
	  EXCH_RATE_CNY = a_EX_RATE_CNY,		  
	  AMOUNT_TWD = Round(AMOUNT_LOC * a_EX_RATE_TWD, 5),
	  AMOUNT_USD = Round(AMOUNT_LOC * a_EX_RATE_USD, 5),
	  AMOUNT_CNY = Round(AMOUNT_LOC * a_EX_RATE_CNY, 5)		  
      WHERE COMPANY_CODE = REC1.COMPANY_CODE
             AND PERIOD = REC1.PERIOD;
    Commit;

   
   --(3) Insert Data     
         -- ROIC_SAP004_ARI_DATA_T -> ROIC_SAP004_ARI_DATA
    Insert into ROIC_SAP004_ARI_DATA
        Select * From ROIC_SAP004_ARI_DATA_T
         where COMPANY_CODE = REC1.COMPANY_CODE
           and PERIOD = REC1.PERIOD;
    Commit;

 end loop;


END ROIC_PLS014_ARI_DATA;
/

