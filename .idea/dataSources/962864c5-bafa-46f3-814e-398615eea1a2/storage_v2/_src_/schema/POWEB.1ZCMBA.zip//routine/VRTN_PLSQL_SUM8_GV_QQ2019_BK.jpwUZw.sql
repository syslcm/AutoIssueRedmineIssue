create PROCEDURE         "VRTN_PLSQL_SUM8_GV_QQ2019_BK" IS

    /*
     Susan Create:            
     1. 抓 VRTN_SUM09_AMT_GV_MATGP_Q and VRTN_SUM14_QQ_MATGP&VRTN_SUM04_AMT_MATGP_Q
           VRTN_SUM10_AMT_GV_VM_Q and VRTN_SUM05_AMT_VM_Q資料
     2. Insert to VRTN_SUM20_GV_QQ_MATGP table&
                  VRTN_SUM21_GV_QQ_VM table&
                  VRTN_SUM22_GV_QQ_COMBINE
         By Susan 2007/08/17
     *----------------------------------------------------------------------------*
       2008/03/26 Modify By matgroup and GV_Vendor for L1/L2
       2009/09/18 Modify by GVendor for matgroup amount max&8 大類
       2010/07/08 Susan add UGSZ/USI SZ -SAI015943
       2010/09/14 Susan Add GVC_TRACK SAI017501
       2012/12/04 Susan add      
     */


 vPROCEE_YYYYMMDD varchar2(8);
 vPROCEE_YYYYMM   varchar2(6);
 iTracePoint      varchar2(100);
 cErrorText       varchar2(500);
 vCOMPANY_CODE    varchar2(4);
 vYYYYMM          varchar2(6);
 vSTART_DATE      varchar2(8);
 vEND_DATE        varchar2(8);
 vQUARTER         varchar2(8);
 vCK_GV_VENDOR    varchar2(10);
 vIR_AMT_TWD      number(25,5);
 --PLD_KPI_IR_DETAIL.IR_AMT_TWD%TYPE;
 vQ_AMOUNT       number(25,5);

 vQ_RANKING                 number(5);
 vSITE                      VRTN_SUM14_QQ_MATGP.SITE%TYPE;
 vMATGROUP                  VRTN_SUM14_QQ_MATGP.MATGROUP%TYPE;

 vQA_10_GRADE     VRTN_SUM20_GV_QQ_MATGP.QA_10_GRADE%TYPE;
 vQA_11_GRADE     VRTN_SUM20_GV_QQ_MATGP.QA_11_GRADE%TYPE;
 vQA_12_GRADE     VRTN_SUM20_GV_QQ_MATGP.QA_12_GRADE%TYPE;
 vQ_QA_GRADE      VRTN_SUM20_GV_QQ_MATGP.Q_QA_GRADE%TYPE;
 vQB_10_GRADE     VRTN_SUM20_GV_QQ_MATGP.QB_10_GRADE%TYPE;
 vQB_11_GRADE     VRTN_SUM20_GV_QQ_MATGP.QB_11_GRADE%TYPE;
 vQB_12_GRADE     VRTN_SUM20_GV_QQ_MATGP.QB_12_GRADE%TYPE;
 vQ_QB_GRADE      VRTN_SUM20_GV_QQ_MATGP.Q_QB_GRADE%TYPE;
 vQC_10_GRADE     VRTN_SUM20_GV_QQ_MATGP.QC_10_GRADE%TYPE;
 vQC_11_GRADE     VRTN_SUM20_GV_QQ_MATGP.QC_11_GRADE%TYPE;
 vQC_12_GRADE     VRTN_SUM20_GV_QQ_MATGP.QC_12_GRADE%TYPE;
 vQ_QC_GRADE      VRTN_SUM20_GV_QQ_MATGP.Q_QC_GRADE%TYPE;
 vQD_10_GRADE     VRTN_SUM20_GV_QQ_MATGP.QD_10_GRADE%TYPE;
 vQD_11_GRADE     VRTN_SUM20_GV_QQ_MATGP.QD_11_GRADE%TYPE;
 vQD_12_GRADE     VRTN_SUM20_GV_QQ_MATGP.QD_12_GRADE%TYPE;
 vQ_QD_GRADE      VRTN_SUM20_GV_QQ_MATGP.Q_QD_GRADE%TYPE;
 vSUBTOT_10_Q     VRTN_SUM20_GV_QQ_MATGP.SUBTOT_10_Q%TYPE;
 vSUBTOT_11_Q     VRTN_SUM20_GV_QQ_MATGP.SUBTOT_11_Q%TYPE;
 vSUBTOT_12_Q     VRTN_SUM20_GV_QQ_MATGP.SUBTOT_12_Q%TYPE;
 vSUBTOT_Q        VRTN_SUM20_GV_QQ_MATGP.SUBTOT_Q%TYPE;
 vCA_10_GRADE     VRTN_SUM20_GV_QQ_MATGP.CA_10_GRADE%TYPE;
 vCA_11_GRADE     VRTN_SUM20_GV_QQ_MATGP.CA_11_GRADE%TYPE;
 vCA_12_GRADE     VRTN_SUM20_GV_QQ_MATGP.CA_12_GRADE%TYPE;
 vQ_CA_GRADE      VRTN_SUM20_GV_QQ_MATGP.Q_CA_GRADE%TYPE;
 vCB_10_GRADE     VRTN_SUM20_GV_QQ_MATGP.CB_10_GRADE%TYPE;
 vCB_11_GRADE     VRTN_SUM20_GV_QQ_MATGP.CB_11_GRADE%TYPE;
 vCB_12_GRADE     VRTN_SUM20_GV_QQ_MATGP.CB_12_GRADE%TYPE;
 vQ_CB_GRADE      VRTN_SUM20_GV_QQ_MATGP.Q_CB_GRADE%TYPE;
 vCC_10_GRADE     VRTN_SUM20_GV_QQ_MATGP.CC_10_GRADE%TYPE;
 vCC_11_GRADE     VRTN_SUM20_GV_QQ_MATGP.CC_11_GRADE%TYPE;
 vCC_12_GRADE     VRTN_SUM20_GV_QQ_MATGP.CC_12_GRADE%TYPE;
 vCC_GRADE        VRTN_SUM20_GV_QQ_MATGP.CC_GRADE%TYPE;
 vCD_10_GRADE     VRTN_SUM20_GV_QQ_MATGP.CD_10_GRADE%TYPE;
 vCD_11_GRADE     VRTN_SUM20_GV_QQ_MATGP.CD_11_GRADE%TYPE;
 vCD_12_GRADE     VRTN_SUM20_GV_QQ_MATGP.CD_12_GRADE%TYPE;
 vQ_CD_GRADE      VRTN_SUM20_GV_QQ_MATGP.Q_CD_GRADE%TYPE;
 vSUBTOT_10_C     VRTN_SUM20_GV_QQ_MATGP.SUBTOT_10_C%TYPE;
 vSUBTOT_11_C     VRTN_SUM20_GV_QQ_MATGP.SUBTOT_11_C%TYPE;
 vSUBTOT_12_C     VRTN_SUM20_GV_QQ_MATGP.SUBTOT_12_C%TYPE;
 vSUBTOT_C        VRTN_SUM20_GV_QQ_MATGP.SUBTOT_C%TYPE;
 vD1_10_GRADE     VRTN_SUM20_GV_QQ_MATGP.D1_10_GRADE%TYPE;
 vD1_11_GRADE     VRTN_SUM20_GV_QQ_MATGP.D1_11_GRADE%TYPE;
 vD1_12_GRADE     VRTN_SUM20_GV_QQ_MATGP.D1_12_GRADE%TYPE;
 vQ_D1_GRADE      VRTN_SUM20_GV_QQ_MATGP.Q_D1_GRADE%TYPE;
 vD2_10_GRADE     VRTN_SUM20_GV_QQ_MATGP.D2_10_GRADE%TYPE;
 vD2_11_GRADE     VRTN_SUM20_GV_QQ_MATGP.D2_11_GRADE%TYPE;
 vD2_12_GRADE     VRTN_SUM20_GV_QQ_MATGP.D2_12_GRADE%TYPE;
 vQ_D2_GRADE      VRTN_SUM20_GV_QQ_MATGP.Q_D2_GRADE%TYPE;
 vDE_10_GRADE     VRTN_SUM20_GV_QQ_MATGP.DE_10_GRADE%TYPE;
 vDE_11_GRADE     VRTN_SUM20_GV_QQ_MATGP.DE_11_GRADE%TYPE;
 vDE_12_GRADE     VRTN_SUM20_GV_QQ_MATGP.DE_12_GRADE%TYPE;
 vQ_DE_GRADE      VRTN_SUM20_GV_QQ_MATGP.Q_DE_GRADE%TYPE;
 vDF_10_GRADE     VRTN_SUM20_GV_QQ_MATGP.DF_10_GRADE%TYPE;
 vDF_11_GRADE     VRTN_SUM20_GV_QQ_MATGP.DF_11_GRADE%TYPE;
 vDF_12_GRADE     VRTN_SUM20_GV_QQ_MATGP.DF_12_GRADE%TYPE;
 vQ_DF_GRADE      VRTN_SUM20_GV_QQ_MATGP.Q_DF_GRADE%TYPE;
 vDG_10_GRADE     VRTN_SUM20_GV_QQ_MATGP.DG_10_GRADE%TYPE;
 vDG_11_GRADE     VRTN_SUM20_GV_QQ_MATGP.DG_11_GRADE%TYPE;
 vDG_12_GRADE     VRTN_SUM20_GV_QQ_MATGP.DG_12_GRADE%TYPE;
 vQ_DG_GRADE      VRTN_SUM20_GV_QQ_MATGP.Q_DG_GRADE%TYPE;
 vDH_10_GRADE     VRTN_SUM20_GV_QQ_MATGP.DH_10_GRADE%TYPE;
 vDH_11_GRADE     VRTN_SUM20_GV_QQ_MATGP.DH_11_GRADE%TYPE;
 vDH_12_GRADE     VRTN_SUM20_GV_QQ_MATGP.DH_12_GRADE%TYPE;
 vQ_DH_GRADE      VRTN_SUM20_GV_QQ_MATGP.Q_DH_GRADE%TYPE;
 vDI_10_GRADE     VRTN_SUM20_GV_QQ_MATGP.DI_10_GRADE%TYPE;
 vDI_11_GRADE     VRTN_SUM20_GV_QQ_MATGP.DI_11_GRADE%TYPE;
 vDI_12_GRADE     VRTN_SUM20_GV_QQ_MATGP.DI_12_GRADE%TYPE;
 vQ_DI_GRADE      VRTN_SUM20_GV_QQ_MATGP.Q_DI_GRADE%TYPE;
 vDJ_10_GRADE     VRTN_SUM20_GV_QQ_MATGP.DJ_10_GRADE%TYPE;
 vDJ_11_GRADE     VRTN_SUM20_GV_QQ_MATGP.DJ_11_GRADE%TYPE;
 vDJ_12_GRADE     VRTN_SUM20_GV_QQ_MATGP.DJ_12_GRADE%TYPE;
 vQ_DJ_GRADE      VRTN_SUM20_GV_QQ_MATGP.Q_DJ_GRADE %TYPE;
 vTOT_10_CQD      VRTN_SUM20_GV_QQ_MATGP.TOT_10_CQD%TYPE;
 vTOT_11_CQD      VRTN_SUM20_GV_QQ_MATGP.TOT_11_CQD%TYPE;
 vTOT_12_CQD      VRTN_SUM20_GV_QQ_MATGP.TOT_12_CQD%TYPE;
 vSUBTOT_10_D3    VRTN_SUM20_GV_QQ_MATGP.SUBTOT_10_D3%TYPE;
 vSUBTOT_11_D3    VRTN_SUM20_GV_QQ_MATGP.SUBTOT_11_D3%TYPE;
 vSUBTOT_12_D3    VRTN_SUM20_GV_QQ_MATGP.SUBTOT_12_D3%TYPE;
 vSUBTOT_D3       VRTN_SUM20_GV_QQ_MATGP.SUBTOT_D3%TYPE;
 vQ_SUBTOT_D3     VRTN_SUM20_GV_QQ_MATGP.Q_SUBTOT_D3%TYPE;
 vTOT_10_D        VRTN_SUM20_GV_QQ_MATGP.TOT_10_D%TYPE;
 vTOT_11_D        VRTN_SUM20_GV_QQ_MATGP.TOT_11_D%TYPE;
 vTOT_12_D        VRTN_SUM20_GV_QQ_MATGP.TOT_12_D%TYPE;
 vSUBTOT_10_D     VRTN_SUM20_GV_QQ_MATGP.SUBTOT_10_D%TYPE;
 vSUBTOT_11_D     VRTN_SUM20_GV_QQ_MATGP.SUBTOT_11_D%TYPE;
 vSUBTOT_12_D     VRTN_SUM20_GV_QQ_MATGP.SUBTOT_12_D%TYPE;
 vSUBTOT_D        VRTN_SUM20_GV_QQ_MATGP.SUBTOT_D%TYPE;
 vQ_SUBTOT_D      VRTN_SUM20_GV_QQ_MATGP.Q_SUBTOT_D%TYPE;
 vTOT_10_QCD      VRTN_SUM20_GV_QQ_MATGP.TOT_10_QCD %TYPE;
 vTOT_11_QCD      VRTN_SUM20_GV_QQ_MATGP.TOT_11_QCD %TYPE;
 vTOT_12_QCD      VRTN_SUM20_GV_QQ_MATGP.TOT_12_QCD %TYPE;
 vQ_10_SCORE      VRTN_SUM20_GV_QQ_MATGP.Q_10_SCORE%TYPE;
 vQ_11_SCORE      VRTN_SUM20_GV_QQ_MATGP.Q_11_SCORE%TYPE;
 vQ_12_SCORE      VRTN_SUM20_GV_QQ_MATGP.Q_12_SCORE%TYPE;
 vMM_SCORE        VRTN_SUM20_GV_QQ_MATGP.MM_SCORE%TYPE;
 vQ_MM_SCORE      VRTN_SUM20_GV_QQ_MATGP.Q_MM_SCORE%TYPE;
 vck01                 number(5);
 vck02                 number(5);

vTW_SITE  VRTN_SUM14_QQ_MATGP.SITE%TYPE;
vSZ_SITE  VRTN_SUM14_QQ_MATGP.SITE%TYPE;
vSH_SITE  VRTN_SUM14_QQ_MATGP.SITE%TYPE;
vTW_VENDOR  VRTN_SUM14_QQ_MATGP.VENDOR%TYPE;
vSZ_VENDOR  VRTN_SUM14_QQ_MATGP.VENDOR%TYPE;
vSH_VENDOR  VRTN_SUM14_QQ_MATGP.VENDOR%TYPE;
vMATGROUP_T VRTN_SUM14_QQ_MATGP.MATGROUP%TYPE;
vGV_VENDOR  VRTN_SUM14_QQ_MATGP.GV_VENDOR%TYPE;
--add 20100708
vUGSZ_SITE  VRTN_SUM14_QQ_MATGP.SITE%TYPE;
vUGTW_SITE  VRTN_SUM14_QQ_MATGP.SITE%TYPE;
vUGSZ_VENDOR VRTN_SUM14_QQ_MATGP.VENDOR%TYPE;
vUGTW_VENDOR VRTN_SUM14_QQ_MATGP.VENDOR%TYPE;
--
vL1_PROCEE_YYYYMM   varchar2(6);
vL1_QUARTER         varchar2(8);
vQ_GRADE_L1    VRTN_SUM20_GV_QQ_MATGP.MM_SCORE%TYPE;
vTW_Q_SCORE_L1 VRTN_SUM20_GV_QQ_MATGP.MM_SCORE%TYPE;
vSH_Q_SCORE_L1 VRTN_SUM20_GV_QQ_MATGP.MM_SCORE%TYPE;
vSZ_Q_SCORE_L1 VRTN_SUM20_GV_QQ_MATGP.MM_SCORE%TYPE;
vL2_PROCEE_YYYYMM   varchar2(6);
vL2_QUARTER         varchar2(8);
vQ_SCORE_L2    VRTN_SUM20_GV_QQ_MATGP.MM_SCORE%TYPE;
vTW_Q_SCORE_L2 VRTN_SUM20_GV_QQ_MATGP.MM_SCORE%TYPE;
vSH_Q_SCORE_L2 VRTN_SUM20_GV_QQ_MATGP.MM_SCORE%TYPE;
vSZ_Q_SCORE_L2 VRTN_SUM20_GV_QQ_MATGP.MM_SCORE%TYPE;
--add 20100708
vUGSZ_Q_SCORE_L1 VRTN_SUM20_GV_QQ_MATGP.MM_SCORE%TYPE;
vUGTW_Q_SCORE_L1 VRTN_SUM20_GV_QQ_MATGP.MM_SCORE%TYPE;
vUGSZ_Q_SCORE_L2 VRTN_SUM20_GV_QQ_MATGP.MM_SCORE%TYPE;
vUGTW_Q_SCORE_L2 VRTN_SUM20_GV_QQ_MATGP.MM_SCORE%TYPE;
--
--8TYPE
--vGV_VENDOR  VRTN_SUM14_QQ_MATGP.VENDOR%TYPE;
 vMATGROUPMAX VRTN_SUM14_QQ_MATGP.MATGROUP%TYPE;
-- vQ_AMOUNT VRTN_SUM14_QQ_MATGP.Q_AMOUNT%TYPE;
 vMATTYPE VRTN_SUM20_GV_QQ_MATGP.MATTYPE%TYPE;

--2012/12/04 add KS
vKS_Q_SCORE_L1 VRTN_SUM20_GV_QQ_MATGP.MM_SCORE%TYPE;
vKS_Q_SCORE_L2 VRTN_SUM20_GV_QQ_MATGP.MM_SCORE%TYPE;
vKS_SITE  VRTN_SUM14_QQ_MATGP.SITE%TYPE;
vKS_VENDOR VRTN_SUM14_QQ_MATGP.VENDOR%TYPE;
--OK
vMX_Q_SCORE_L1 VRTN_SUM20_GV_QQ_MATGP.MM_SCORE%TYPE;
vMX_Q_SCORE_L2 VRTN_SUM20_GV_QQ_MATGP.MM_SCORE%TYPE;
vMX_SITE  VRTN_SUM14_QQ_MATGP.SITE%TYPE;
vMX_VENDOR VRTN_SUM14_QQ_MATGP.VENDOR%TYPE;

BEGIN
--add 20100708
vUGSZ_Q_SCORE_L1 := null;
vUGTW_Q_SCORE_L1 := null;
vUGSZ_Q_SCORE_L2 := null;
vUGTW_Q_SCORE_L2 := null;
vUGSZ_SITE := null;
vUGTW_SITE := null;
vUGSZ_VENDOR := null;
vUGTW_VENDOR := null;


    vCOMPANY_CODE := null;
    vYYYYMM := null;
    vSTART_DATE := null;
    vEND_DATE := null;
    vQUARTER := null;
    vCK_GV_VENDOR := null;
--L1,L2
    vL1_PROCEE_YYYYMM := null;
    vQ_GRADE_L1 := null;
    vTW_Q_SCORE_L1 := null;
    vSH_Q_SCORE_L1 := null;
    vSZ_Q_SCORE_L1 := null;
    vL2_PROCEE_YYYYMM := null;
    vQ_SCORE_L2 := null;
    vTW_Q_SCORE_L2 := null;
    vSH_Q_SCORE_L2 := null;
    vSZ_Q_SCORE_L2 := null;
--8TYPE
    vGV_VENDOR := null;
    vMATGROUPMAX := null;
    vQ_AMOUNT := null;
    vMATTYPE := null;


--2012/12/04 Add KS
vKS_Q_SCORE_L1 := null;
vKS_Q_SCORE_L2 := null;
vKS_SITE := null;
vKS_VENDOR := null;


--Start L1,L2 月季
   --抓上一季月資料 (L1)
     iTracePoint := '100';
     vL1_PROCEE_YYYYMM := TO_CHAR(ADD_MONTHS(SYSDATE, -4), 'YYYYMM');

   --抓上季(L1)
      for REC1 in (Select distinct QUARTER
                           FROM DIMENSION_DATE
                           WHERE YYYY = SUBSTRB(vL1_PROCEE_YYYYMM,1,4)
                             AND MM = SUBSTRB(vL1_PROCEE_YYYYMM,5,2)
                             ) loop
          vL1_QUARTER := SUBSTRB(vL1_PROCEE_YYYYMM,1,4) || REC1.QUARTER;
      end loop;

   --抓上一季月資料(L2)
     iTracePoint := '100';
     vL2_PROCEE_YYYYMM := TO_CHAR(ADD_MONTHS(SYSDATE, -7), 'YYYYMM');

   --抓上季(L2)
      for REC1 in (Select distinct QUARTER
                           FROM DIMENSION_DATE
                           WHERE YYYY = SUBSTRB(vL2_PROCEE_YYYYMM,1,4)
                             AND MM = SUBSTRB(vL2_PROCEE_YYYYMM,5,2)
                             ) loop
          vL2_QUARTER := SUBSTRB(vL2_PROCEE_YYYYMM,1,4) || REC1.QUARTER;
      end loop;
--END


   --抓上個月資料
     iTracePoint := '100';
     vPROCEE_YYYYMM := TO_CHAR(ADD_MONTHS(SYSDATE, -1), 'YYYYMM');
   --抓季資料
      for REC1 in (Select QUARTER
                          FROM DIMENSION_DATE
                          WHERE YYYY = SUBSTRB(vPROCEE_YYYYMM,1,4)
                            AND MM = SUBSTRB(vPROCEE_YYYYMM,5,2)
                            ) loop
         vQUARTER := SUBSTRB(vPROCEE_YYYYMM,1,4) || REC1.QUARTER;
      end loop;
    --抓季起始區間資料
         for REC1 in (Select MIN(DATE_KEY) AS DATE_KEY
                             FROM DIMENSION_DATE
                             WHERE QUARTER = SUBSTRB(vQUARTER,5,2)
                               AND YYYY = SUBSTRB(vQUARTER,1,4)
                               ) loop
            vSTART_DATE := REC1.DATE_KEY;
         end loop;
    --抓季終上區間資料
        for REC1 in (Select MAX(DATE_KEY) AS DATE_KEY
                            FROM DIMENSION_DATE
                            WHERE QUARTER = SUBSTRB(vQUARTER,5,2)
                              AND YYYY = SUBSTRB(vQUARTER,1,4)
                             ) loop
            vEND_DATE := REC1.DATE_KEY;
        end loop;



  if vQUARTER is null then
     --若沒抓到資料則寄 error mail
     iTracePoint := '110';
     cErrorText := 'QUARTER error!';
     MAIL_FILE_BIDBDBADMIN(in_to_name => 'shuchin_lin@ugiglobal.com', subject => '[VRTN] PL/SQL VRTN_PLSQL_SUM8_GV_QQ ERROR', message => '[VRTN_PLSQL_SUM4_GV_AMT_QQ], The tracepoint is  ' || iTracePoint || ' and ErrorText= ' || cErrorText) ;
  else

     --清除舊的 VRTN_SUM20_GV_QQ_MATGP 資料
       iTracePoint := '200';
       DELETE FROM VRTN_SUM20_GV_QQ_MATGP WHERE QUARTER = SUBSTRB(vQUARTER,1,6);

     --放入季交易資料
       iTracePoint := '210';
        for REC1 in ( Select GV_VENDOR, MATGROUP, QUARTER, round(SUM(Q_AMOUNT), 2) as Q_AMOUNT
                             from VRTN_SUM09_AMT_GV_MATGP_Q
                             where GV_VENDOR is Not Null
                               and MATGROUP is Not Null
                               and QUARTER = SUBSTRB(vQUARTER,1,6)
                    Group by GV_VENDOR, MATGROUP, QUARTER
                    ) loop


    -- Check VRTN_SUM14_QQ_MATGP, VRTN_SUM04_AMT_MATGP_Q table exist
      vck01 := '0';
      vck02 := '0';
      Select count(*) into vck01
                 from VRTN_SUM14_QQ_MATGP a
                 where a.GV_VENDOR = REC1.GV_VENDOR
                   and a.MATGROUP = REC1.MATGROUP
                   and a.QUARTER =  vQUARTER;

      Select count(*) into vck02
                 from VRTN_SUM04_AMT_MATGP_Q  a
                       where a.GV_VENDOR = REC1.GV_VENDOR
                         and a.MATGROUP = REC1.MATGROUP
                         and a.QUARTER =  vQUARTER;

     if vck01 > 0 and vck02 > 0 then
      --放到 VRTN_SUM20_GV_QQ_MATGP
      iTracePoint := '220-' || REC1.GV_VENDOR || '-' || REC1.MATGROUP || '-' || vPROCEE_YYYYMM || REC1.QUARTER;
      insert into VRTN_SUM20_GV_QQ_MATGP (
                  GV_VENDOR, MATGROUP, QUARTER, Q_AMOUNT, FROM_DATE, TO_DATE, DATE_TIME
           ) values (
           REC1.GV_VENDOR,
           REC1.MATGROUP,
           REC1.QUARTER,
           REC1.Q_AMOUNT,
           vSTART_DATE,
           vEND_DATE,
           to_char(SYSDATE, 'yyyymmddhh24miss')
           );
      commit;
     end if;

    end loop;
  end if;


  iTracePoint := '300'; --MATGROUP, GV_VENDOR BY QUARTER
  for REC1 in (
     select distinct GV_VENDOR, MATGROUP from VRTN_SUM20_GV_QQ_MATGP c
      where QUARTER = vQUARTER
  ) loop
     select * into  vQA_10_GRADE, vQA_11_GRADE, vQA_12_GRADE, vQ_QA_GRADE, vQB_10_GRADE, vQB_11_GRADE, vQB_12_GRADE, vQ_QB_GRADE, vQC_10_GRADE, vQC_11_GRADE, vQC_12_GRADE, vQ_QC_GRADE, vQD_10_GRADE, vQD_11_GRADE, vQD_12_GRADE, vQ_QD_GRADE, vSUBTOT_10_Q, vSUBTOT_11_Q, vSUBTOT_12_Q, vSUBTOT_Q,
                    vCA_10_GRADE, vCA_11_GRADE, vCA_12_GRADE, vQ_CA_GRADE, vCB_10_GRADE, vCB_11_GRADE, vCB_12_GRADE, vQ_CB_GRADE, vCC_10_GRADE, vCC_11_GRADE, vCC_12_GRADE, vCC_GRADE,   vCD_10_GRADE, vCD_11_GRADE, vCD_12_GRADE, vQ_CD_GRADE, vSUBTOT_10_C, vSUBTOT_11_C, vSUBTOT_12_C, vSUBTOT_C,
                    vD1_10_GRADE, vD1_11_GRADE, vD1_12_GRADE, vQ_D1_GRADE, vD2_10_GRADE, vD2_11_GRADE, vD2_12_GRADE, vQ_D2_GRADE, vDE_10_GRADE, vDE_11_GRADE, vDE_12_GRADE, vQ_DE_GRADE, vDF_10_GRADE, vDF_11_GRADE, vDF_12_GRADE, vQ_DF_GRADE, vDG_10_GRADE, vDG_11_GRADE, vDG_12_GRADE, vQ_DG_GRADE, vDH_10_GRADE, vDH_11_GRADE, vDH_12_GRADE, vQ_DH_GRADE,
                    vDI_10_GRADE, vDI_11_GRADE, vDI_12_GRADE, vQ_DI_GRADE, vDJ_10_GRADE, vDJ_11_GRADE, vDJ_12_GRADE, vQ_DJ_GRADE, vTOT_10_CQD,  vTOT_11_CQD,  vTOT_12_CQD, vSUBTOT_10_D3, vSUBTOT_11_D3, vSUBTOT_12_D3, vSUBTOT_D3, vQ_SUBTOT_D3,
                    vTOT_10_D,    vTOT_11_D,    vTOT_12_D,    vSUBTOT_10_D,vSUBTOT_11_D, vSUBTOT_12_D, vSUBTOT_D,    vQ_SUBTOT_D, vTOT_10_QCD,  vTOT_11_QCD,  vTOT_12_QCD,  vQ_10_SCORE,  vQ_11_SCORE, vQ_12_SCORE, vMM_SCORE, vQ_MM_SCORE
                    from (
                 select round(sum(QA_10_GRADE * a.GV_PER),5) AS vQA_10_GRADE,
                        round(sum(QA_11_GRADE * a.GV_PER),5) AS vQA_11_GRADE,
                        round(sum(QA_12_GRADE * a.GV_PER),5) AS vQA_12_GRADE,
                        round(sum(Q_QA_GRADE  * a.GV_PER),5) AS vQ_QA_GRADE,
                        round(sum(QB_10_GRADE * a.GV_PER),5) AS vQB_10_GRADE,
                        round(sum(QB_11_GRADE * a.GV_PER),5) AS vQB_11_GRADE,
                        round(sum(QB_12_GRADE * a.GV_PER),5) AS vQB_12_GRADE,
                        round(sum(Q_QB_GRADE  * a.GV_PER),5) AS vQ_QB_GRADE,
                        round(sum(QC_10_GRADE * a.GV_PER),5) AS vQC_10_GRADE,
                        round(sum(QC_11_GRADE * a.GV_PER),5) AS vQC_11_GRADE,
                        round(sum(QC_12_GRADE * a.GV_PER),5) AS vQC_12_GRADE,
                        round(sum(Q_QC_GRADE  * a.GV_PER),5) AS vQ_QC_GRADE,
                        round(sum(QD_10_GRADE * a.GV_PER),5) AS vQD_10_GRADE,
                        round(sum(QD_11_GRADE * a.GV_PER),5) AS vQD_11_GRADE,
                        round(sum(QD_12_GRADE * a.GV_PER),5) AS vQD_12_GRADE,
                        round(sum(Q_QD_GRADE  * a.GV_PER),5) AS vQ_QD_GRADE,
                        round(sum(SUBTOT_10_Q * a.GV_PER),5) AS vSUBTOT_10_Q,
                        round(sum(SUBTOT_11_Q * a.GV_PER),5) AS vSUBTOT_11_Q,
                        round(sum(SUBTOT_12_Q * a.GV_PER),5) AS vSUBTOT_12_Q,
                        round(sum(SUBTOT_Q    * a.GV_PER),5) AS vSUBTOT_Q,
                        round(sum(CA_10_GRADE * a.GV_PER),5) AS vCA_10_GRADE,
                        round(sum(CA_11_GRADE * a.GV_PER),5) AS vCA_11_GRADE,
                        round(sum(CA_12_GRADE * a.GV_PER),5) AS vCA_12_GRADE,
                        round(sum(Q_CA_GRADE  * a.GV_PER),5) AS vQ_CA_GRADE,
                        round(sum(CB_10_GRADE * a.GV_PER),5) AS vCB_10_GRADE,
                        round(sum(CB_11_GRADE * a.GV_PER),5) AS vCB_11_GRADE,
                        round(sum(CB_12_GRADE * a.GV_PER),5) AS vCB_12_GRADE,
                        round(sum(Q_CB_GRADE  * a.GV_PER),5) AS vQ_CB_GRADE,
                        round(sum(CC_10_GRADE * a.GV_PER),5) AS vCC_10_GRADE,
                        round(sum(CC_11_GRADE * a.GV_PER),5) AS vCC_11_GRADE,
                        round(sum(CC_12_GRADE * a.GV_PER),5) AS vCC_12_GRADE,
                        round(sum(CC_GRADE    * a.GV_PER),5) AS vCC_GRADE,
                        round(sum(CD_10_GRADE * a.GV_PER),5) AS vCD_10_GRADE,
                        round(sum(CD_11_GRADE * a.GV_PER),5) AS vCD_11_GRADE,
                        round(sum(CD_12_GRADE * a.GV_PER),5) AS vCD_12_GRADE,
                        round(sum(Q_CD_GRADE  * a.GV_PER),5) AS vQ_CD_GRADE,
                        round(sum(SUBTOT_10_C * a.GV_PER),5) AS vSUBTOT_10_C,
                        round(sum(SUBTOT_11_C * a.GV_PER),5) AS vSUBTOT_11_C,
                        round(sum(SUBTOT_12_C * a.GV_PER),5) AS vSUBTOT_12_C,
                        round(sum(SUBTOT_C    * a.GV_PER),5) AS vSUBTOT_C,
                        round(sum(D1_10_GRADE * a.GV_PER),5) AS vD1_10_GRADE,
                        round(sum(D1_11_GRADE * a.GV_PER),5) AS vD1_11_GRADE,
                        round(sum(D1_12_GRADE * a.GV_PER),5) AS vD1_12_GRADE,
                        round(sum(Q_D1_GRADE  * a.GV_PER),5) AS vQ_D1_GRADE,
                        round(sum(D2_10_GRADE * a.GV_PER),5) AS vD2_10_GRADE,
                        round(sum(D2_11_GRADE * a.GV_PER),5) AS vD2_11_GRADE,
                        round(sum(D2_12_GRADE * a.GV_PER),5) AS vD2_12_GRADE,
                        round(sum(Q_D2_GRADE  * a.GV_PER),5) AS vQ_D2_GRADE,
                        round(sum(DE_10_GRADE * a.GV_PER),5) AS vDE_10_GRADE,
                        round(sum(DE_11_GRADE * a.GV_PER),5) AS vDE_11_GRADE,
                        round(sum(DE_12_GRADE * a.GV_PER),5) AS vDE_12_GRADE,
                        round(sum(Q_DE_GRADE  * a.GV_PER),5) AS vQ_DE_GRADE,
                        round(sum(DF_10_GRADE * a.GV_PER),5) AS vDF_10_GRADE,
                        round(sum(DF_11_GRADE * a.GV_PER),5) AS vDF_11_GRADE,
                        round(sum(DF_12_GRADE * a.GV_PER),5) AS vDF_12_GRADE,
                        round(sum(Q_DF_GRADE  * a.GV_PER),5) AS vQ_DF_GRADE,
                        round(sum(DG_10_GRADE * a.GV_PER),5) AS vDG_10_GRADE,
                        round(sum(DG_11_GRADE * a.GV_PER),5) AS vDG_11_GRADE,
                        round(sum(DG_12_GRADE * a.GV_PER),5) AS vDG_12_GRADE,
                        round(sum(Q_DG_GRADE  * a.GV_PER),5) AS vQ_DG_GRADE,
                        round(sum(DH_10_GRADE * a.GV_PER),5) AS vDH_10_GRADE,
                        round(sum(DH_11_GRADE * a.GV_PER),5) AS vDH_11_GRADE,
                        round(sum(DH_12_GRADE * a.GV_PER),5) AS vDH_12_GRADE,
                        round(sum(Q_DH_GRADE  * a.GV_PER),5) AS vQ_DH_GRADE,
                        round(sum(DI_10_GRADE * a.GV_PER),5) AS vDI_10_GRADE,
                        round(sum(DI_11_GRADE * a.GV_PER),5) AS vDI_11_GRADE,
                        round(sum(DI_12_GRADE * a.GV_PER),5) AS vDI_12_GRADE,
                        round(sum(Q_DI_GRADE  * a.GV_PER),5) AS vQ_DI_GRADE,
                        round(sum(DJ_10_GRADE * a.GV_PER),5) AS vDJ_10_GRADE,
                        round(sum(DJ_11_GRADE * a.GV_PER),5) AS vDJ_11_GRADE,
                        round(sum(DJ_12_GRADE * a.GV_PER),5) AS vDJ_12_GRADE,
                        round(sum(Q_DJ_GRADE  * a.GV_PER),5) AS vQ_DJ_GRADE,
                        round(sum(TOT_10_CQD  * a.GV_PER),5) AS vTOT_10_CQD,
                        round(sum(TOT_11_CQD  * a.GV_PER),5) AS vTOT_11_CQD,
                        round(sum(TOT_12_CQD  * a.GV_PER),5) AS vTOT_12_CQD,
                        round(sum(SUBTOT_10_D3* a.GV_PER),5) AS vSUBTOT_10_D3,
                        round(sum(SUBTOT_11_D3* a.GV_PER),5) AS vSUBTOT_11_D3,
                        round(sum(SUBTOT_12_D3* a.GV_PER),5) AS vSUBTOT_12_D3,
                        round(sum(SUBTOT_D3   * a.GV_PER),5) AS vSUBTOT_D3,
                        round(sum(Q_SUBTOT_D3 * a.GV_PER),5) AS vQ_SUBTOT_D3,
                        round(sum(TOT_10_D    * a.GV_PER),5) AS vTOT_10_D,
                        round(sum(TOT_11_D    * a.GV_PER),5) AS vTOT_11_D,
                        round(sum(TOT_12_D    * a.GV_PER),5) AS vTOT_12_D,
                        round(sum(SUBTOT_10_D * a.GV_PER),5) AS vSUBTOT_10_D,
                        round(sum(SUBTOT_11_D * a.GV_PER),5) AS vSUBTOT_11_D,
                        round(sum(SUBTOT_12_D * a.GV_PER),5) AS vSUBTOT_12_D,
                        round(sum(SUBTOT_D    * a.GV_PER),5) AS vSUBTOT_D,
                        round(sum(Q_SUBTOT_D  * a.GV_PER),5) AS vQ_SUBTOT_D,
                        round(sum(TOT_10_QCD  * a.GV_PER),5) AS vTOT_10_QCD,
                        round(sum(TOT_11_QCD  * a.GV_PER),5) AS vTOT_11_QCD,
                        round(sum(TOT_12_QCD  * a.GV_PER),5) AS vTOT_12_QCD,
                        round(sum(Q_10_SCORE  * a.GV_PER),5) AS vQ_10_SCORE,
                        round(sum(Q_11_SCORE  * a.GV_PER),5) AS vQ_11_SCORE,
                        round(sum(Q_12_SCORE  * a.GV_PER),5) AS vQ_12_SCORE,
                        round(sum(MM_SCORE    * a.GV_PER),5) AS vMM_SCORE,
                        round(sum(Q_MM_SCORE  * a.GV_PER),5) AS vQ_MM_SCORE
                        from VRTN_SUM04_AMT_MATGP_Q a, VRTN_SUM14_QQ_MATGP b
                             where a.GV_VENDOR = b.GV_VENDOR
                               and a.QUARTER = b.QUARTER
                               and a.SITE = b.SITE
                               and a.VENDOR = b.VENDOR
                               and a.MATGROUP = b.MATGROUP
                               and a.GV_VENDOR = REC1.GV_VENDOR
                               and a.MATGROUP = REC1.MATGROUP
                               and a.QUARTER = vQUARTER
                        Group by a.GV_VENDOR, a.MATGROUP


         );


        --PROCESS SCORE
          if vQA_10_GRADE > '100' then
             vQA_10_GRADE := '100';
          end if;
          if vQA_11_GRADE > '100' then
             vQA_11_GRADE := '100';
          end if;
          if vQA_12_GRADE > '100' then
             vQA_12_GRADE := '100';
          end if;
          if vQ_QA_GRADE > '100' then
             vQ_QA_GRADE := '100';
          end if;
          if vQB_10_GRADE > '100' then
             vQB_10_GRADE := '100';
          end if;
          if vQB_11_GRADE > '100' then
             vQB_11_GRADE := '100';
          end if;
          if vQB_12_GRADE > '100' then
             vQB_12_GRADE := '100';
          end if;
          if vQ_QB_GRADE > '100' then
             vQ_QB_GRADE := '100';
          end if;
          if vQC_10_GRADE > '100' then
             vQC_10_GRADE := '100';
          end if;
          if vQC_11_GRADE > '100' then
             vQC_11_GRADE := '100';
          end if;
          if vQC_12_GRADE > '100' then
             vQC_12_GRADE := '100';
          end if;
          if vQ_QC_GRADE > '100' then
             vQ_QC_GRADE := '100';
          end if;
          if vQD_10_GRADE > '100' then
             vQD_10_GRADE := '100';
          end if;
          if vQD_11_GRADE > '100' then
             vQD_11_GRADE := '100';
          end if;
          if vQD_12_GRADE > '100' then
             vQD_12_GRADE := '100';
          end if;
          if vQ_QD_GRADE > '100' then
             vQ_QD_GRADE := '100';
          end if;
          if vSUBTOT_10_Q > '100' then
             vSUBTOT_10_Q := '100';
          end if;
          if vSUBTOT_11_Q > '100' then
             vSUBTOT_11_Q := '100';
          end if;
          if vSUBTOT_12_Q > '100' then
             vSUBTOT_12_Q := '100';
          end if;
          if vSUBTOT_12_Q > '100' then
             vSUBTOT_12_Q := '100';
          end if;
          if vSUBTOT_Q > '100' then
             vSUBTOT_Q := '100';
          end if;
          if vCA_10_GRADE > '100' then
             vCA_10_GRADE := '100';
          end if;
          if vCA_11_GRADE > '100' then
             vCA_11_GRADE := '100';
          end if;
          if vCA_12_GRADE > '100' then
             vCA_12_GRADE := '100';
          end if;
          if vQ_CA_GRADE > '100' then
             vQ_CA_GRADE := '100';
          end if;
          if vCB_10_GRADE > '100' then
             vCB_10_GRADE := '100';
          end if;
          if vCB_11_GRADE > '100' then
             vCB_11_GRADE := '100';
          end if;
          if vCB_12_GRADE > '100' then
             vCB_12_GRADE := '100';
          end if;
          if vQ_CB_GRADE > '100' then
             vQ_CB_GRADE := '100';
          end if;
          if vCC_10_GRADE > '100' then
             vCC_10_GRADE := '100';
          end if;
          if vCC_11_GRADE > '100' then
             vCC_11_GRADE := '100';
          end if;
          if vCC_12_GRADE > '100' then
             vCC_12_GRADE := '100';
          end if;
                  if vCC_GRADE > '100' then
             vCC_GRADE := '100';
          end if;
          if vCD_10_GRADE > '100' then
             vCD_10_GRADE := '100';
          end if;
          if vCD_11_GRADE > '100' then
             vCD_11_GRADE := '100';
          end if;
          if vCD_12_GRADE > '100' then
             vCD_12_GRADE := '100';
          end if;
          if vQ_CD_GRADE > '100' then
             vQ_CD_GRADE := '100';
          end if;
          if vSUBTOT_10_C > '100' then
             vSUBTOT_10_C := '100';
          end if;
          if vSUBTOT_11_C > '100' then
             vSUBTOT_11_C := '100';
          end if;
          if vSUBTOT_12_C > '100' then
             vSUBTOT_12_C := '100';
          end if;
          if vSUBTOT_C > '100' then
             vSUBTOT_C := '100';
          end if;
          if vD1_10_GRADE > '100' then
             vD1_10_GRADE := '100';
          end if;
          if vD1_11_GRADE > '100' then
             vD1_11_GRADE := '100';
          end if;
          if vD1_12_GRADE > '100' then
             vD1_12_GRADE := '100';
          end if;
          if vQ_D1_GRADE > '100' then
             vQ_D1_GRADE := '100';
          end if;
          if vD2_10_GRADE > '100' then
             vD2_10_GRADE := '100';
          end if;
          if vD2_11_GRADE > '100' then
             vD2_11_GRADE := '100';
          end if;
          if vD2_12_GRADE > '100' then
             vD2_12_GRADE := '100';
          end if;
          if vQ_D2_GRADE > '100' then
             vQ_D2_GRADE := '100';
          end if;
          if vDE_10_GRADE > '100' then
             vDE_10_GRADE := '100';
          end if;
          if vDE_11_GRADE > '100' then
             vDE_11_GRADE := '100';
          end if;
          if vDE_12_GRADE > '100' then
             vDE_12_GRADE := '100';
          end if;
          if vQ_DE_GRADE > '100' then
             vQ_DE_GRADE := '100';
          end if;
          if vDF_10_GRADE > '100' then
             vDF_10_GRADE := '100';
          end if;
          if vDF_11_GRADE > '100' then
             vDF_11_GRADE := '100';
          end if;
          if vDF_12_GRADE > '100' then
             vDF_12_GRADE := '100';
          end if;
          if vQ_DF_GRADE > '100' then
             vQ_DF_GRADE := '100';
          end if;
          if vDG_10_GRADE > '100' then
             vDG_10_GRADE := '100';
          end if;
          if vDG_11_GRADE > '100' then
             vDG_11_GRADE := '100';
          end if;
          if vDG_12_GRADE > '100' then
             vDG_12_GRADE := '100';
          end if;
          if vQ_DG_GRADE > '100' then
             vQ_DG_GRADE := '100';
          end if;
          if vDH_10_GRADE > '100' then
             vDH_10_GRADE := '100';
          end if;
          if vDH_11_GRADE > '100' then
             vDH_11_GRADE := '100';
          end if;
          if vDH_12_GRADE > '100' then
             vDH_12_GRADE := '100';
          end if;
          if vQ_DH_GRADE > '100' then
             vQ_DH_GRADE := '100';
          end if;
          if vDI_10_GRADE > '100' then
             vDI_10_GRADE := '100';
          end if;
          if vDI_11_GRADE > '100' then
             vDI_11_GRADE := '100';
          end if;
          if vDI_12_GRADE > '100' then
             vDI_12_GRADE := '100';
          end if;
          if vQ_DI_GRADE > '100' then
             vQ_DI_GRADE := '100';
          end if;
          if vDJ_10_GRADE > '100' then
             vDJ_10_GRADE := '100';
          end if;
          if vDJ_11_GRADE > '100' then
             vDJ_11_GRADE := '100';
          end if;
          if vDJ_12_GRADE > '100' then
             vDJ_12_GRADE := '100';
          end if;
          if vQ_DJ_GRADE > '100' then
             vQ_DJ_GRADE := '100';
          end if;
          if vTOT_10_CQD > '100' then
             vTOT_10_CQD := '100';
          end if;
          if vTOT_11_CQD > '100' then
             vTOT_11_CQD := '100';
          end if;
          if vTOT_12_CQD > '100' then
             vTOT_12_CQD := '100';
          end if;
          if vSUBTOT_10_D3 > '100' then
             vSUBTOT_10_D3 := '100';
          end if;
          if vSUBTOT_11_D3 > '100' then
             vSUBTOT_11_D3 := '100';
          end if;
          if vSUBTOT_12_D3 > '100' then
             vSUBTOT_12_D3 := '100';
          end if;
          if vQ_SUBTOT_D3 > '100' then
             vQ_SUBTOT_D3 := '100';
          end if;
          if vTOT_10_D > '100' then
             vTOT_10_D := '100';
          end if;
          if vTOT_11_D > '100' then
             vTOT_11_D := '100';
          end if;
          if vTOT_12_D > '100' then
             vTOT_12_D := '100';
          end if;
          if vSUBTOT_10_D > '100' then
             vSUBTOT_10_D := '100';
          end if;
          if vSUBTOT_11_D > '100' then
             vSUBTOT_11_D := '100';
          end if;
          if vSUBTOT_12_D > '100' then
             vSUBTOT_12_D := '100';
          end if;
          if vSUBTOT_D > '100' then
             vSUBTOT_D := '100';
          end if;
          if vQ_SUBTOT_D > '100' then
             vQ_SUBTOT_D := '100';
          end if;
          if vTOT_10_QCD > '100' then
             vTOT_10_QCD := '100';
          end if;
          if vTOT_11_QCD > '100' then
             vTOT_11_QCD := '100';
          end if;
          if vTOT_12_QCD > '100' then
             vTOT_12_QCD := '100';
          end if;
          if vQ_10_SCORE > '100' then
             vQ_10_SCORE := '100';
          end if;
          if vQ_11_SCORE > '100' then
             vQ_11_SCORE := '100';
          end if;
          if vQ_12_SCORE > '100' then
             vQ_12_SCORE := '100';
          end if;
          if vMM_SCORE > '100' then
             vMM_SCORE := '100';
          end if;
          if vQ_MM_SCORE > '100' then
             vQ_MM_SCORE := '100';
          end if;


         UPDate VRTN_SUM20_GV_QQ_MATGP
                            set QA_10_GRADE = vQA_10_GRADE,
                                QA_11_GRADE = vQA_11_GRADE,
                                QA_12_GRADE = vQA_12_GRADE,
                                Q_QA_GRADE  = vQ_QA_GRADE,
                                QB_10_GRADE =  vQB_10_GRADE,
                                QB_11_GRADE =  vQB_11_GRADE,
                                QB_12_GRADE =  vQB_12_GRADE,
                                Q_QB_GRADE  =  vQ_QB_GRADE,
                                QC_10_GRADE =  vQC_10_GRADE,
                                QC_11_GRADE =  vQC_11_GRADE,
                                QC_12_GRADE =  vQC_12_GRADE,
                                Q_QC_GRADE  =  vQ_QC_GRADE,
                                QD_10_GRADE =  vQD_10_GRADE,
                                QD_11_GRADE =  vQD_11_GRADE,
                                QD_12_GRADE =  vQD_12_GRADE,
                                Q_QD_GRADE  =  vQ_QD_GRADE,
                                SUBTOT_10_Q =  vSUBTOT_10_Q,
                                SUBTOT_11_Q =  vSUBTOT_11_Q,
                                SUBTOT_12_Q =  vSUBTOT_12_Q,
                                SUBTOT_Q    =  vSUBTOT_Q,
                                CA_10_GRADE =  vCA_10_GRADE,
                                CA_11_GRADE =  vCA_11_GRADE,
                                CA_12_GRADE =  vCA_12_GRADE,
                                Q_CA_GRADE  =  vQ_CA_GRADE,
                                CB_10_GRADE =  vCB_10_GRADE,
                                CB_11_GRADE =  vCB_11_GRADE,
                                CB_12_GRADE =  vCB_12_GRADE,
                                Q_CB_GRADE  =  vQ_CB_GRADE,
                                CC_10_GRADE =  vCC_10_GRADE,
                                CC_11_GRADE =  vCC_11_GRADE,
                                CC_12_GRADE =  vCC_12_GRADE,
                                CC_GRADE    =  vCC_GRADE,
                                CD_10_GRADE =  vCD_10_GRADE,
                                CD_11_GRADE =  vCD_11_GRADE,
                                CD_12_GRADE =  vCD_12_GRADE,
                                Q_CD_GRADE  =  vQ_CD_GRADE,
                                SUBTOT_10_C =  vSUBTOT_10_C,
                                SUBTOT_11_C =  vSUBTOT_11_C,
                                SUBTOT_12_C =  vSUBTOT_12_C,
                                SUBTOT_C    =  vSUBTOT_C,
                                D1_10_GRADE =  vD1_10_GRADE,
                                D1_11_GRADE =  vD1_11_GRADE,
                                D1_12_GRADE =  vD1_12_GRADE,
                                Q_D1_GRADE  =  vQ_D1_GRADE,
                                D2_10_GRADE =  vD2_10_GRADE,
                                D2_11_GRADE =  vD2_11_GRADE,
                                D2_12_GRADE =  vD2_12_GRADE,
                                Q_D2_GRADE  =  vQ_D2_GRADE,
                                DE_10_GRADE =  vDE_10_GRADE,
                                DE_11_GRADE =  vDE_11_GRADE,
                                DE_12_GRADE =  vDE_12_GRADE,
                                Q_DE_GRADE  =  vQ_DE_GRADE,
                                DF_10_GRADE =  vDF_10_GRADE,
                                DF_11_GRADE =  vDF_11_GRADE,
                                DF_12_GRADE =  vDF_12_GRADE,
                                Q_DF_GRADE  =  vQ_DF_GRADE,
                                DG_10_GRADE =  vDG_10_GRADE,
                                DG_11_GRADE =  vDG_11_GRADE,
                                DG_12_GRADE =  vDG_12_GRADE,
                                Q_DG_GRADE  =  vQ_DG_GRADE,
                                DH_10_GRADE =  vDH_10_GRADE,
                                DH_11_GRADE =  vDH_11_GRADE,
                                DH_12_GRADE =  vDH_12_GRADE,
                                Q_DH_GRADE  =  vQ_DH_GRADE,
                                DI_10_GRADE =  vDI_10_GRADE,
                                DI_11_GRADE =  vDI_11_GRADE,
                                DI_12_GRADE =  vDI_12_GRADE,
                                Q_DI_GRADE  =  vQ_DI_GRADE,
                                DJ_10_GRADE =  vDJ_10_GRADE,
                                DJ_11_GRADE =  vDJ_11_GRADE,
                                DJ_12_GRADE =  vDJ_12_GRADE,
                                Q_DJ_GRADE  =  vQ_DJ_GRADE,
                                TOT_10_CQD  =  vTOT_10_CQD,
                                TOT_11_CQD  =  vTOT_11_CQD,
                                TOT_12_CQD  =  vTOT_12_CQD,
                                SUBTOT_10_D3=  vSUBTOT_10_D3,
                                SUBTOT_11_D3=  vSUBTOT_11_D3,
                                SUBTOT_12_D3=  vSUBTOT_12_D3,
                                SUBTOT_D3   =  vSUBTOT_D3,
                                Q_SUBTOT_D3 =  vQ_SUBTOT_D3,
                                TOT_10_D    =  vTOT_10_D,
                                TOT_11_D    =  vTOT_11_D,
                                TOT_12_D    =  vTOT_12_D,
                                SUBTOT_10_D =  vSUBTOT_10_D,
                                SUBTOT_11_D =  vSUBTOT_11_D,
                                SUBTOT_12_D =  vSUBTOT_12_D,
                                SUBTOT_D    =  vSUBTOT_D,
                                Q_SUBTOT_D  =  vQ_SUBTOT_D,
                                TOT_10_QCD  =  vTOT_10_QCD,
                                TOT_11_QCD  =  vTOT_11_QCD,
                                TOT_12_QCD  =  vTOT_12_QCD,
                                Q_10_SCORE  =  vQ_10_SCORE,
                                Q_11_SCORE  =  vQ_11_SCORE,
                                Q_12_SCORE  =  vQ_12_SCORE,
                                MM_SCORE    =  vMM_SCORE,
                                Q_MM_SCORE  =  vQ_MM_SCORE
        where QUARTER = vQUARTER
          and MATGROUP = REC1.MATGROUP
          and GV_VENDOR = REC1.GV_VENDOR;
       commit;

  end loop;

 -- Susan 2010/09/14
  iTracePoint := '305';
  for REC1 in (
     select a.GV_VENDOR, a.MATGROUP, a.QUARTER,
      ( select b.GVC_TRACK from GVM031_GLOBAL_VENDOR b where b.GLOBAL_VENDOR_CODE = a.GV_VENDOR) as GVC_TRACK
      from VRTN_SUM20_GV_QQ_MATGP a
      where a.QUARTER = vQUARTER
      group by a.GV_VENDOR, a.MATGROUP, a.QUARTER
  ) loop
     Update VRTN_SUM20_GV_QQ_MATGP
        set GVC_TRACK = REC1.GVC_TRACK
      where GV_VENDOR = REC1.GV_VENDOR
        and MATGROUP = REC1.MATGROUP
        and QUARTER = REC1.QUARTER;
     commit;
  end loop;
  --END

  iTracePoint := '310';
  vQ_RANKING := 0;
  vMATGROUP := '000';
  for REC1 in (
     select a.GV_VENDOR, a.MATGROUP, a.QUARTER, ( select b.GRADE from VRTN_SUM23_MAPPING_GRADE b where b.RANGE_TYPE = 'SC' and b.RANGE_FROM <= a.MM_SCORE and b.RANGE_TO >= a.MM_SCORE ) as Q_GRADE
       from VRTN_SUM20_GV_QQ_MATGP a
      where a.QUARTER = vQUARTER
      order by a.MM_SCORE desc, a.SUBTOT_Q desc, a.SUBTOT_C desc, a.Q_SUBTOT_D desc, a.Q_AMOUNT desc

  ) loop
  --   if vMATGROUP <> REC1.MATGROUP then
  --     vQ_RANKING := 0;
  --     vMATGROUP := REC1.MATGROUP;
  --   end if;
     vQ_RANKING := vQ_RANKING + 1;
     Update VRTN_SUM20_GV_QQ_MATGP
        set Q_GRADE = REC1.Q_GRADE,
            Q_RANKING = vQ_RANKING
      where GV_VENDOR = REC1.GV_VENDOR
        and MATGROUP = REC1.MATGROUP
        and QUARTER = REC1.QUARTER;
     commit;
  end loop;


 iTracePoint := '320';  --MATGROUP, GV_VENDOR, GV 001 / WW 001
  for REC1 in (
     select distinct MATGROUP, GV_VENDOR from VRTN_SUM20_GV_QQ_MATGP
            where QUARTER = vQUARTER
  ) loop
     BEGIN
       select * into vIR_AMT_TWD from (
         select round(sum(Q_AMOUNT),5) from VRTN_SUM20_GV_QQ_MATGP
          where QUARTER = vQUARTER
            and MATGROUP = REC1.MATGROUP
       );
     EXCEPTION
       When OTHERS Then
         vIR_AMT_TWD := 0;
     END;
     Update VRTN_SUM20_GV_QQ_MATGP
        set AMT_SHARE_GV = round(Q_AMOUNT / vIR_AMT_TWD, 5) * 100
      where GV_VENDOR = REC1.GV_VENDOR
        and MATGROUP = REC1.MATGROUP
        and QUARTER = vQUARTER;
     commit;
  end loop;

--2010/07/08 UGSZ/UGTW
  iTracePoint := '330';
     for REC1 in (
           select distinct MATGROUP, GV_VENDOR from VRTN_SUM20_GV_QQ_MATGP
                 where QUARTER = vQUARTER
       ) loop

        iTracePoint := '340';
           vTW_SITE := '1100';
           vSZ_SITE := '1200';
           vSH_SITE := '1500';
           vTW_VENDOR := '';
           vSZ_VENDOR := '';
           vSH_VENDOR := '';
           vUGSZ_SITE := '1400';
           vUGTW_SITE := '1700';
           vUGSZ_VENDOR := '';
           vUGTW_VENDOR := '';
           --2012/12/04 KS
            vKS_SITE := '4100';
            vKS_VENDOR := '';
        -- Clear vendor code
           Update VRTN_SUM20_GV_QQ_MATGP
              set TW_VENDOR = vTW_VENDOR,
                  SZ_VENDOR = vSZ_VENDOR,
                  SH_VENDOR = vSH_VENDOR,
                  UGSZ_VENDOR = vUGSZ_VENDOR,
                  UGTW_VENDOR = vUGTW_VENDOR,
                  KS_VENDOR = vKS_VENDOR
            where GV_VENDOR = REC1.GV_VENDOR
              and MATGROUP = REC1.MATGROUP
              and QUARTER = vQUARTER;
              commit;

           iTracePoint := '350';
           vMATGROUP_T := REC1.MATGROUP;
           vGV_VENDOR := REC1.GV_VENDOR;
            VRTN_PLSQL_SUM8_SUB01(vTW_SITE,vSZ_SITE,vSH_SITE,vUGSZ_SITE,vUGTW_SITE, vKS_SITE, vMX_SITE,vQUARTER,vMATGROUP_T,vGV_VENDOR);
--          VRTN_PLSQL_SUM8_SUB01(vTW_SITE,vSZ_SITE,vSH_SITE,vUGSZ_SITE,vUGTW_SITE, vQUARTER,vMATGROUP_T,vGV_VENDOR);
       end loop;

--2010/07/08 UGSZ/UGTW
--2010/12/04 KS
--By MATGROUP Update L1/L2
  iTracePoint := '360';  --BY MATGROUP, GV_VENDOR, Get L1/L2 SCORE
   for REC1 in (
      select distinct MATGROUP, GV_VENDOR from VRTN_SUM20_GV_QQ_MATGP
             where QUARTER = vQUARTER
   ) loop


      BEGIN
        select * into vQ_GRADE_L1, vTW_Q_SCORE_L1, vSH_Q_SCORE_L1, vSZ_Q_SCORE_L1, vUGSZ_Q_SCORE_L1, vUGTW_Q_SCORE_L1, vKS_Q_SCORE_L1 from (
             select Q_MM_SCORE, TW_Q_SCORE, SH_Q_SCORE, SZ_Q_SCORE, UGSZ_Q_SCORE, UGTW_Q_SCORE, KS_Q_SCORE from VRTN_SUM20_GV_QQ_MATGP
    --  select * into vQ_GRADE_L1, vTW_Q_SCORE_L1, vSH_Q_SCORE_L1, vSZ_Q_SCORE_L1, vUGSZ_Q_SCORE_L1, vUGTW_Q_SCORE_L1 from (
    --       select Q_MM_SCORE, TW_Q_SCORE, SH_Q_SCORE, SZ_Q_SCORE, UGSZ_Q_SCORE, UGTW_Q_SCORE from VRTN_SUM20_GV_QQ_MATGP
           where QUARTER = vL1_QUARTER
             and GV_VENDOR = REC1.GV_VENDOR
             and MATGROUP = REC1.MATGROUP
        );
      EXCEPTION
        When OTHERS Then
          vQ_GRADE_L1 := null;
          vTW_Q_SCORE_L1 := null;
          vSH_Q_SCORE_L1 := null;
          vSZ_Q_SCORE_L1 := null;
          vUGSZ_Q_SCORE_L1 := null;
          vUGTW_Q_SCORE_L1 := null;
          vKS_Q_SCORE_L1 := null;
      END;
      BEGIN
        select * into vQ_SCORE_L2, vTW_Q_SCORE_L2, vSH_Q_SCORE_L2, vSZ_Q_SCORE_L2, vUGSZ_Q_SCORE_L2, vUGTW_Q_SCORE_L2, vKS_Q_SCORE_L2 from (
           select Q_MM_SCORE, TW_Q_SCORE, SH_Q_SCORE, SZ_Q_SCORE, UGSZ_Q_SCORE, UGTW_Q_SCORE, KS_Q_SCORE from VRTN_SUM20_GV_QQ_MATGP
    --    select * into vQ_SCORE_L2, vTW_Q_SCORE_L2, vSH_Q_SCORE_L2, vSZ_Q_SCORE_L2, vUGSZ_Q_SCORE_L2, vUGTW_Q_SCORE_L2 from (
    --       select Q_MM_SCORE, TW_Q_SCORE, SH_Q_SCORE, SZ_Q_SCORE, UGSZ_Q_SCORE, UGTW_Q_SCORE from VRTN_SUM20_GV_QQ_MATGP
           where QUARTER = vL2_QUARTER
             and GV_VENDOR = REC1.GV_VENDOR
             and MATGROUP = REC1.MATGROUP
        );
      EXCEPTION
        When OTHERS Then
          vQ_SCORE_L2 := null;
          vTW_Q_SCORE_L2 := null;
          vSH_Q_SCORE_L2 := null;
          vSZ_Q_SCORE_L2 := null;
          vUGSZ_Q_SCORE_L2 := null;
          vUGTW_Q_SCORE_L2 := null;
          vKS_Q_SCORE_L2 := null;
      END;

      Update VRTN_SUM20_GV_QQ_MATGP
         set Q_GRADE_L1 = vQ_GRADE_L1,
             TW_Q_SCORE_L1 = vTW_Q_SCORE_L1,
             SH_Q_SCORE_L1 = vSH_Q_SCORE_L1,
             SZ_Q_SCORE_L1 = vSZ_Q_SCORE_L1,
             UGSZ_Q_SCORE_L1 = vUGSZ_Q_SCORE_L1,
             UGTW_Q_SCORE_L1 = vUGTW_Q_SCORE_L1,
             KS_Q_SCORE_L1   = vKS_Q_SCORE_L1,
             Q_SCORE_L2 = vQ_SCORE_L2,
             TW_Q_SCORE_L2 = vTW_Q_SCORE_L2,
             SH_Q_SCORE_L2 = vSH_Q_SCORE_L2,
             SZ_Q_SCORE_L2 = vSZ_Q_SCORE_L2,
             UGSZ_Q_SCORE_L2 = vUGSZ_Q_SCORE_L2,
             UGTW_Q_SCORE_L2 = vUGTW_Q_SCORE_L2,
             KS_Q_SCORE_L2   = vKS_Q_SCORE_L2
       where GV_VENDOR = REC1.GV_VENDOR
         and MATGROUP = REC1.MATGROUP
         and QUARTER = vQUARTER;
      commit;
   end loop;

--End By MATGROUP Update L1/L2

--2009/09/18 By GVendor get Amount Max MatGroup -for matgroup
    iTracePoint := '370';
     for REC1 in (
        select distinct GV_VENDOR, MATGROUP from VRTN_SUM20_GV_QQ_MATGP
               where QUARTER = vQUARTER
     ) loop

        BEGIN
         select * into vGV_VENDOR, vQ_AMOUNT from (
                   select GV_VENDOR, MAX(Q_AMOUNT)
                               from VRTN_SUM20_GV_QQ_MATGP a
                                 where a.GV_VENDOR = REC1.GV_VENDOR
                                   and a.QUARTER = vQUARTER
                                   GROUP BY GV_VENDOR
           );
        EXCEPTION
          When OTHERS Then
            vGV_VENDOR := null;
            vQ_AMOUNT := null;
        END;

        BEGIN
          select * into vGV_VENDOR, vMATGROUPMAX, vMATTYPE from (
              select a.GV_VENDOR, a.MATGROUP,
                     (select b.MATERIAL_TYPE From VRTN_8TYPE b where b.MATERIAL_GROUP = A.MATGROUP ) as MATTYPE
                  from VRTN_SUM20_GV_QQ_MATGP a
                  where a.QUARTER = vQUARTER
                  and a.GV_VENDOR = REC1.GV_VENDOR
                  and a.Q_AMOUNT = vQ_AMOUNT
          );

        EXCEPTION
          When OTHERS Then
            vGV_VENDOR := null;
            vMATGROUPMAX := null;
            vMATTYPE := null;
        END;

        Update VRTN_SUM20_GV_QQ_MATGP
           set MATGROUPMAX = vMATGROUPMAX,
               MATTYPE = vMATTYPE
         where GV_VENDOR = REC1.GV_VENDOR
           and QUARTER = vQUARTER;
        commit;
     end loop;
--2009/09/18 End By GVendor get Amount max MatGroup


  -- GV vendor Process
  if vQUARTER is null then
     --若沒抓到資料則寄 error mail
     iTracePoint := '400';
     cErrorText := 'QUARTER error!';
     MAIL_FILE_BIDBDBADMIN(in_to_name => 'shuchin_lin@usiglobal.com', subject => '[VRTN] PL/SQL VRTN_PLSQL_SUM8_GV_QQ ERROR', message => '[VRTN_PLSQL_SUM8_GV_QQ], The tracepoint is  ' || iTracePoint || ' and ErrorText= ' || cErrorText) ;
  else

     --清除舊的 VRTN_SUM21_GV_QQ_VM 資料
       iTracePoint := '500';
       DELETE FROM VRTN_SUM21_GV_QQ_VM WHERE QUARTER = SUBSTRB(vQUARTER,1,6);

     --放入季交易資料
       iTracePoint := '510';
        for REC1 in ( Select GV_VENDOR, QUARTER, round(SUM(Q_AMOUNT), 2) as Q_AMOUNT
                             from VRTN_SUM10_AMT_GV_VM_Q
                             where GV_VENDOR is Not Null
                               and QUARTER = SUBSTRB(vQUARTER,1,6)
                    Group by GV_VENDOR, QUARTER
                    ) loop

     -- Check VRTN_SUM05_AMT_VM_Q, VRTN_SUM15_QQ_VM table exist
           vck01 := '0';
           vck02 := '0';
           Select count(*) into vck01
                      from VRTN_SUM05_AMT_VM_Q a
                      where a.GV_VENDOR = REC1.GV_VENDOR
                        and a.QUARTER =  vQUARTER;

           Select count(*) into vck02
                      from VRTN_SUM15_QQ_VM a
                            where a.GV_VENDOR = REC1.GV_VENDOR
                              and a.QUARTER =  vQUARTER;

      if vck01 > 0 and vck02 > 0 then

      --放到 VRTN_SUM21_GV_QQ_VM
      iTracePoint := '520-' || REC1.GV_VENDOR || '-' || vPROCEE_YYYYMM || REC1.QUARTER;
      insert into VRTN_SUM21_GV_QQ_VM (
                  GV_VENDOR,  QUARTER, Q_AMOUNT, FROM_DATE, TO_DATE, DATE_TIME
           ) values (
           REC1.GV_VENDOR,
           REC1.QUARTER,
           REC1.Q_AMOUNT,
           vSTART_DATE,
           vEND_DATE,
           to_char(SYSDATE, 'yyyymmddhh24miss')
           );
      commit;
      end if;

    end loop;
  end if;



  iTracePoint := '600'; -- GV_VENDOR BY QUARTER
  for REC1 in (
     select distinct GV_VENDOR from VRTN_SUM21_GV_QQ_VM c
      where QUARTER = vQUARTER
  ) loop
     select * into  vQA_10_GRADE, vQA_11_GRADE, vQA_12_GRADE, vQ_QA_GRADE, vQB_10_GRADE, vQB_11_GRADE, vQB_12_GRADE, vQ_QB_GRADE, vQC_10_GRADE, vQC_11_GRADE, vQC_12_GRADE, vQ_QC_GRADE, vQD_10_GRADE, vQD_11_GRADE, vQD_12_GRADE, vQ_QD_GRADE, vSUBTOT_10_Q, vSUBTOT_11_Q, vSUBTOT_12_Q, vSUBTOT_Q,
                    vCA_10_GRADE, vCA_11_GRADE, vCA_12_GRADE, vQ_CA_GRADE, vCB_10_GRADE, vCB_11_GRADE, vCB_12_GRADE, vQ_CB_GRADE, vCC_10_GRADE, vCC_11_GRADE, vCC_12_GRADE, vCC_GRADE,   vCD_10_GRADE, vCD_11_GRADE, vCD_12_GRADE, vQ_CD_GRADE, vSUBTOT_10_C, vSUBTOT_11_C, vSUBTOT_12_C, vSUBTOT_C,
                    vD1_10_GRADE, vD1_11_GRADE, vD1_12_GRADE, vQ_D1_GRADE, vD2_10_GRADE, vD2_11_GRADE, vD2_12_GRADE, vQ_D2_GRADE, vDE_10_GRADE, vDE_11_GRADE, vDE_12_GRADE, vQ_DE_GRADE, vDF_10_GRADE, vDF_11_GRADE, vDF_12_GRADE, vQ_DF_GRADE, vDG_10_GRADE, vDG_11_GRADE, vDG_12_GRADE, vQ_DG_GRADE, vDH_10_GRADE, vDH_11_GRADE, vDH_12_GRADE, vQ_DH_GRADE,
                    vDI_10_GRADE, vDI_11_GRADE, vDI_12_GRADE, vQ_DI_GRADE, vDJ_10_GRADE, vDJ_11_GRADE, vDJ_12_GRADE, vQ_DJ_GRADE, vTOT_10_CQD,  vTOT_11_CQD,  vTOT_12_CQD,  vSUBTOT_10_D3, vSUBTOT_11_D3, vSUBTOT_12_D3, vSUBTOT_D3, vQ_SUBTOT_D3,
                    vTOT_10_D,    vTOT_11_D,    vTOT_12_D,    vSUBTOT_10_D,vSUBTOT_11_D, vSUBTOT_12_D, vSUBTOT_D,    vQ_SUBTOT_D, vTOT_10_QCD,  vTOT_11_QCD,  vTOT_12_QCD,  vQ_10_SCORE, vQ_11_SCORE, vQ_12_SCORE, vMM_SCORE, vQ_MM_SCORE
                    from (
                 select round(sum(QA_10_GRADE * a.GV_PER),5) AS vQA_10_GRADE,
                        round(sum(QA_11_GRADE * a.GV_PER),5) AS vQA_11_GRADE,
                        round(sum(QA_12_GRADE * a.GV_PER),5) AS vQA_12_GRADE,
                        round(sum(Q_QA_GRADE  * a.GV_PER),5) AS vQ_QA_GRADE,
                        round(sum(QB_10_GRADE * a.GV_PER),5) AS vQB_10_GRADE,
                        round(sum(QB_11_GRADE * a.GV_PER),5) AS vQB_11_GRADE,
                        round(sum(QB_12_GRADE * a.GV_PER),5) AS vQB_12_GRADE,
                        round(sum(Q_QB_GRADE  * a.GV_PER),5) AS vQ_QB_GRADE,
                        round(sum(QC_10_GRADE * a.GV_PER),5) AS vQC_10_GRADE,
                        round(sum(QC_11_GRADE * a.GV_PER),5) AS vQC_11_GRADE,
                        round(sum(QC_12_GRADE * a.GV_PER),5) AS vQC_12_GRADE,
                        round(sum(Q_QC_GRADE  * a.GV_PER),5) AS vQ_QC_GRADE,
                        round(sum(QD_10_GRADE * a.GV_PER),5) AS vQD_10_GRADE,
                        round(sum(QD_11_GRADE * a.GV_PER),5) AS vQD_11_GRADE,
                        round(sum(QD_12_GRADE * a.GV_PER),5) AS vQD_12_GRADE,
                        round(sum(Q_QD_GRADE  * a.GV_PER),5) AS vQ_QD_GRADE,
                        round(sum(SUBTOT_10_Q * a.GV_PER),5) AS vSUBTOT_10_Q,
                        round(sum(SUBTOT_11_Q * a.GV_PER),5) AS vSUBTOT_11_Q,
                        round(sum(SUBTOT_12_Q * a.GV_PER),5) AS vSUBTOT_12_Q,
                        round(sum(SUBTOT_Q    * a.GV_PER),5) AS vSUBTOT_Q,
                        round(sum(CA_10_GRADE * a.GV_PER),5) AS vCA_10_GRADE,
                        round(sum(CA_11_GRADE * a.GV_PER),5) AS vCA_11_GRADE,
                        round(sum(CA_12_GRADE * a.GV_PER),5) AS vCA_12_GRADE,
                        round(sum(Q_CA_GRADE  * a.GV_PER),5) AS vQ_CA_GRADE,
                        round(sum(CB_10_GRADE * a.GV_PER),5) AS vCB_10_GRADE,
                        round(sum(CB_11_GRADE * a.GV_PER),5) AS vCB_11_GRADE,
                        round(sum(CB_12_GRADE * a.GV_PER),5) AS vCB_12_GRADE,
                        round(sum(Q_CB_GRADE  * a.GV_PER),5) AS vQ_CB_GRADE,
                        round(sum(CC_10_GRADE * a.GV_PER),5) AS vCC_10_GRADE,
                        round(sum(CC_11_GRADE * a.GV_PER),5) AS vCC_11_GRADE,
                        round(sum(CC_12_GRADE * a.GV_PER),5) AS vCC_12_GRADE,
                        round(sum(CC_GRADE    * a.GV_PER),5) AS vCC_GRADE,
                        round(sum(CD_10_GRADE * a.GV_PER),5) AS vCD_10_GRADE,
                        round(sum(CD_11_GRADE * a.GV_PER),5) AS vCD_11_GRADE,
                        round(sum(CD_12_GRADE * a.GV_PER),5) AS vCD_12_GRADE,
                        round(sum(Q_CD_GRADE  * a.GV_PER),5) AS vQ_CD_GRADE,
                        round(sum(SUBTOT_10_C * a.GV_PER),5) AS vSUBTOT_10_C,
                        round(sum(SUBTOT_11_C * a.GV_PER),5) AS vSUBTOT_11_C,
                        round(sum(SUBTOT_12_C * a.GV_PER),5) AS vSUBTOT_12_C,
                        round(sum(SUBTOT_C    * a.GV_PER),5) AS vSUBTOT_C,
                        round(sum(D1_10_GRADE * a.GV_PER),5) AS vD1_10_GRADE,
                        round(sum(D1_11_GRADE * a.GV_PER),5) AS vD1_11_GRADE,
                        round(sum(D1_12_GRADE * a.GV_PER),5) AS vD1_12_GRADE,
                        round(sum(Q_D1_GRADE  * a.GV_PER),5) AS vQ_D1_GRADE,
                        round(sum(D2_10_GRADE * a.GV_PER),5) AS vD2_10_GRADE,
                        round(sum(D2_11_GRADE * a.GV_PER),5) AS vD2_11_GRADE,
                        round(sum(D2_12_GRADE * a.GV_PER),5) AS vD2_12_GRADE,
                        round(sum(Q_D2_GRADE  * a.GV_PER),5) AS vQ_D2_GRADE,
                        round(sum(DE_10_GRADE * a.GV_PER),5) AS vDE_10_GRADE,
                        round(sum(DE_11_GRADE * a.GV_PER),5) AS vDE_11_GRADE,
                        round(sum(DE_12_GRADE * a.GV_PER),5) AS vDE_12_GRADE,
                        round(sum(Q_DE_GRADE  * a.GV_PER),5) AS vQ_DE_GRADE,
                        round(sum(DF_10_GRADE * a.GV_PER),5) AS vDF_10_GRADE,
                        round(sum(DF_11_GRADE * a.GV_PER),5) AS vDF_11_GRADE,
                        round(sum(DF_12_GRADE * a.GV_PER),5) AS vDF_12_GRADE,
                        round(sum(Q_DF_GRADE  * a.GV_PER),5) AS vQ_DF_GRADE,
                        round(sum(DG_10_GRADE * a.GV_PER),5) AS vDG_10_GRADE,
                        round(sum(DG_11_GRADE * a.GV_PER),5) AS vDG_11_GRADE,
                        round(sum(DG_12_GRADE * a.GV_PER),5) AS vDG_12_GRADE,
                        round(sum(Q_DG_GRADE  * a.GV_PER),5) AS vQ_DG_GRADE,
                        round(sum(DH_10_GRADE * a.GV_PER),5) AS vDH_10_GRADE,
                        round(sum(DH_11_GRADE * a.GV_PER),5) AS vDH_11_GRADE,
                        round(sum(DH_12_GRADE * a.GV_PER),5) AS vDH_12_GRADE,
                        round(sum(Q_DH_GRADE  * a.GV_PER),5) AS vQ_DH_GRADE,
                        round(sum(DI_10_GRADE * a.GV_PER),5) AS vDI_10_GRADE,
                        round(sum(DI_11_GRADE * a.GV_PER),5) AS vDI_11_GRADE,
                        round(sum(DI_12_GRADE * a.GV_PER),5) AS vDI_12_GRADE,
                        round(sum(Q_DI_GRADE  * a.GV_PER),5) AS vQ_DI_GRADE,
                        round(sum(DJ_10_GRADE * a.GV_PER),5) AS vDJ_10_GRADE,
                        round(sum(DJ_11_GRADE * a.GV_PER),5) AS vDJ_11_GRADE,
                        round(sum(DJ_12_GRADE * a.GV_PER),5) AS vDJ_12_GRADE,
                        round(sum(Q_DJ_GRADE  * a.GV_PER),5) AS vQ_DJ_GRADE,
                        round(sum(TOT_10_CQD  * a.GV_PER),5) AS vTOT_10_CQD,
                        round(sum(TOT_11_CQD  * a.GV_PER),5) AS vTOT_11_CQD,
                        round(sum(TOT_12_CQD  * a.GV_PER),5) AS vTOT_12_CQD,
                        round(sum(SUBTOT_10_D3* a.GV_PER),5) AS vSUBTOT_10_D3,
                        round(sum(SUBTOT_11_D3* a.GV_PER),5) AS vSUBTOT_11_D3,
                        round(sum(SUBTOT_12_D3* a.GV_PER),5) AS vSUBTOT_12_D3,
                        round(sum(SUBTOT_D3   * a.GV_PER),5) AS vSUBTOT_D3,
                        round(sum(Q_SUBTOT_D3 * a.GV_PER),5) AS vQ_SUBTOT_D3,
                        round(sum(TOT_10_D    * a.GV_PER),5) AS vTOT_10_D,
                        round(sum(TOT_11_D    * a.GV_PER),5) AS vTOT_11_D,
                        round(sum(TOT_12_D    * a.GV_PER),5) AS vTOT_12_D,
                        round(sum(SUBTOT_10_D * a.GV_PER),5) AS vSUBTOT_10_D,
                        round(sum(SUBTOT_11_D * a.GV_PER),5) AS vSUBTOT_11_D,
                        round(sum(SUBTOT_12_D * a.GV_PER),5) AS vSUBTOT_12_D,
                        round(sum(SUBTOT_D    * a.GV_PER),5) AS vSUBTOT_D,
                        round(sum(Q_SUBTOT_D  * a.GV_PER),5) AS vQ_SUBTOT_D,
                        round(sum(TOT_10_QCD  * a.GV_PER),5) AS vTOT_10_QCD,
                        round(sum(TOT_11_QCD  * a.GV_PER),5) AS vTOT_11_QCD,
                        round(sum(TOT_12_QCD  * a.GV_PER),5) AS vTOT_12_QCD,
                        round(sum(Q_10_SCORE  * a.GV_PER),5) AS vQ_10_SCORE,
                        round(sum(Q_11_SCORE  * a.GV_PER),5) AS vQ_11_SCORE,
                        round(sum(Q_12_SCORE  * a.GV_PER),5) AS vQ_12_SCORE,
                        round(sum(MM_SCORE    * a.GV_PER),5) AS vMM_SCORE,
                        round(sum(Q_MM_SCORE  * a.GV_PER),5) AS vQ_MM_SCORE
                        from VRTN_SUM05_AMT_VM_Q a, VRTN_SUM15_QQ_VM b
                             where a.GV_VENDOR = b.GV_VENDOR
                               and a.QUARTER = b.QUARTER
                               and a.SITE = b.SITE
                               and a.VENDOR = b.VENDOR
                               and a.GV_VENDOR = REC1.GV_VENDOR
                               and a.QUARTER = vQUARTER
                         Group by a.GV_VENDOR


         );


        --PROCESS SCORE
          if vQA_10_GRADE > '100' then
             vQA_10_GRADE := '100';
          end if;
          if vQA_11_GRADE > '100' then
             vQA_11_GRADE := '100';
          end if;
          if vQA_12_GRADE > '100' then
             vQA_12_GRADE := '100';
          end if;
          if vQ_QA_GRADE > '100' then
             vQ_QA_GRADE := '100';
          end if;
          if vQB_10_GRADE > '100' then
             vQB_10_GRADE := '100';
          end if;
          if vQB_11_GRADE > '100' then
             vQB_11_GRADE := '100';
          end if;
          if vQB_12_GRADE > '100' then
             vQB_12_GRADE := '100';
          end if;
          if vQ_QB_GRADE > '100' then
             vQ_QB_GRADE := '100';
          end if;
          if vQC_10_GRADE > '100' then
             vQC_10_GRADE := '100';
          end if;
          if vQC_11_GRADE > '100' then
             vQC_11_GRADE := '100';
          end if;
          if vQC_12_GRADE > '100' then
             vQC_12_GRADE := '100';
          end if;
          if vQ_QC_GRADE > '100' then
             vQ_QC_GRADE := '100';
          end if;
          if vQD_10_GRADE > '100' then
             vQD_10_GRADE := '100';
          end if;
          if vQD_11_GRADE > '100' then
             vQD_11_GRADE := '100';
          end if;
          if vQD_12_GRADE > '100' then
             vQD_12_GRADE := '100';
          end if;
          if vQ_QD_GRADE > '100' then
             vQ_QD_GRADE := '100';
          end if;
          if vSUBTOT_10_Q > '100' then
             vSUBTOT_10_Q := '100';
          end if;
          if vSUBTOT_11_Q > '100' then
             vSUBTOT_11_Q := '100';
          end if;
          if vSUBTOT_12_Q > '100' then
             vSUBTOT_12_Q := '100';
          end if;
          if vSUBTOT_12_Q > '100' then
             vSUBTOT_12_Q := '100';
          end if;
          if vSUBTOT_Q > '100' then
             vSUBTOT_Q := '100';
          end if;
          if vCA_10_GRADE > '100' then
             vCA_10_GRADE := '100';
          end if;
          if vCA_11_GRADE > '100' then
             vCA_11_GRADE := '100';
          end if;
          if vCA_12_GRADE > '100' then
             vCA_12_GRADE := '100';
          end if;
          if vQ_CA_GRADE > '100' then
             vQ_CA_GRADE := '100';
          end if;
          if vCB_10_GRADE > '100' then
             vCB_10_GRADE := '100';
          end if;
          if vCB_11_GRADE > '100' then
             vCB_11_GRADE := '100';
          end if;
          if vCB_12_GRADE > '100' then
             vCB_12_GRADE := '100';
          end if;
          if vQ_CB_GRADE > '100' then
             vQ_CB_GRADE := '100';
          end if;
          if vCC_10_GRADE > '100' then
             vCC_10_GRADE := '100';
          end if;
          if vCC_11_GRADE > '100' then
             vCC_11_GRADE := '100';
          end if;
          if vCC_12_GRADE > '100' then
             vCC_12_GRADE := '100';
          end if;
          if vCC_GRADE > '100' then
             vCC_GRADE := '100';
          end if;
          if vCD_10_GRADE > '100' then
             vCD_10_GRADE := '100';
          end if;
          if vCD_11_GRADE > '100' then
             vCD_11_GRADE := '100';
          end if;
          if vCD_12_GRADE > '100' then
             vCD_12_GRADE := '100';
          end if;
          if vQ_CD_GRADE > '100' then
             vQ_CD_GRADE := '100';
          end if;
          if vSUBTOT_10_C > '100' then
             vSUBTOT_10_C := '100';
          end if;
          if vSUBTOT_11_C > '100' then
             vSUBTOT_11_C := '100';
          end if;
          if vSUBTOT_12_C > '100' then
             vSUBTOT_12_C := '100';
          end if;
          if vSUBTOT_C > '100' then
             vSUBTOT_C := '100';
          end if;
          if vD1_10_GRADE > '100' then
             vD1_10_GRADE := '100';
          end if;
          if vD1_11_GRADE > '100' then
             vD1_11_GRADE := '100';
          end if;
          if vD1_12_GRADE > '100' then
             vD1_12_GRADE := '100';
          end if;
          if vQ_D1_GRADE > '100' then
             vQ_D1_GRADE := '100';
          end if;
          if vD2_10_GRADE > '100' then
             vD2_10_GRADE := '100';
          end if;
          if vD2_11_GRADE > '100' then
             vD2_11_GRADE := '100';
          end if;
          if vD2_12_GRADE > '100' then
             vD2_12_GRADE := '100';
          end if;
          if vQ_D2_GRADE > '100' then
             vQ_D2_GRADE := '100';
          end if;
          if vDE_10_GRADE > '100' then
             vDE_10_GRADE := '100';
          end if;
          if vDE_11_GRADE > '100' then
             vDE_11_GRADE := '100';
          end if;
          if vDE_12_GRADE > '100' then
             vDE_12_GRADE := '100';
          end if;
          if vQ_DE_GRADE > '100' then
             vQ_DE_GRADE := '100';
          end if;
          if vDF_10_GRADE > '100' then
             vDF_10_GRADE := '100';
          end if;
          if vDF_11_GRADE > '100' then
             vDF_11_GRADE := '100';
          end if;
          if vDF_12_GRADE > '100' then
             vDF_12_GRADE := '100';
          end if;
          if vQ_DF_GRADE > '100' then
             vQ_DF_GRADE := '100';
          end if;
          if vDG_10_GRADE > '100' then
             vDG_10_GRADE := '100';
          end if;
          if vDG_11_GRADE > '100' then
             vDG_11_GRADE := '100';
          end if;
          if vDG_12_GRADE > '100' then
             vDG_12_GRADE := '100';
          end if;
          if vQ_DG_GRADE > '100' then
             vQ_DG_GRADE := '100';
          end if;
          if vDH_10_GRADE > '100' then
             vDH_10_GRADE := '100';
          end if;
          if vDH_11_GRADE > '100' then
             vDH_11_GRADE := '100';
          end if;
          if vDH_12_GRADE > '100' then
             vDH_12_GRADE := '100';
          end if;
          if vQ_DH_GRADE > '100' then
             vQ_DH_GRADE := '100';
          end if;
          if vDI_10_GRADE > '100' then
             vDI_10_GRADE := '100';
          end if;
          if vDI_11_GRADE > '100' then
             vDI_11_GRADE := '100';
          end if;
          if vDI_12_GRADE > '100' then
             vDI_12_GRADE := '100';
          end if;
          if vQ_DI_GRADE > '100' then
             vQ_DI_GRADE := '100';
          end if;
          if vDJ_10_GRADE > '100' then
             vDJ_10_GRADE := '100';
          end if;
          if vDJ_11_GRADE > '100' then
             vDJ_11_GRADE := '100';
          end if;
          if vDJ_12_GRADE > '100' then
             vDJ_12_GRADE := '100';
          end if;
          if vQ_DJ_GRADE > '100' then
             vQ_DJ_GRADE := '100';
          end if;
          if vTOT_10_CQD > '100' then
             vTOT_10_CQD := '100';
          end if;
          if vTOT_11_CQD > '100' then
             vTOT_11_CQD := '100';
          end if;
          if vTOT_12_CQD > '100' then
             vTOT_12_CQD := '100';
          end if;
          if vSUBTOT_10_D3 > '100' then
             vSUBTOT_10_D3 := '100';
          end if;
          if vSUBTOT_11_D3 > '100' then
             vSUBTOT_11_D3 := '100';
          end if;
          if vSUBTOT_12_D3 > '100' then
             vSUBTOT_12_D3 := '100';
          end if;
          if vQ_SUBTOT_D3 > '100' then
             vQ_SUBTOT_D3 := '100';
          end if;
          if vTOT_10_D > '100' then
             vTOT_10_D := '100';
          end if;
          if vTOT_11_D > '100' then
             vTOT_11_D := '100';
          end if;
          if vTOT_12_D > '100' then
             vTOT_12_D := '100';
          end if;
          if vSUBTOT_10_D > '100' then
             vSUBTOT_10_D := '100';
          end if;
          if vSUBTOT_11_D > '100' then
             vSUBTOT_11_D := '100';
          end if;
          if vSUBTOT_12_D > '100' then
             vSUBTOT_12_D := '100';
          end if;
          if vSUBTOT_D > '100' then
             vSUBTOT_D := '100';
          end if;
          if vQ_SUBTOT_D > '100' then
             vQ_SUBTOT_D := '100';
          end if;
          if vTOT_10_QCD > '100' then
             vTOT_10_QCD := '100';
          end if;
          if vTOT_11_QCD > '100' then
             vTOT_11_QCD := '100';
          end if;
          if vTOT_12_QCD > '100' then
             vTOT_12_QCD := '100';
          end if;
          if vQ_10_SCORE > '100' then
             vQ_10_SCORE := '100';
          end if;
          if vQ_11_SCORE > '100' then
             vQ_11_SCORE := '100';
          end if;
          if vQ_12_SCORE > '100' then
             vQ_12_SCORE := '100';
          end if;
          if vMM_SCORE > '100' then
             vMM_SCORE := '100';
          end if;
                  if vQ_MM_SCORE > '100' then
             vQ_MM_SCORE := '100';
          end if;



         UPDate VRTN_SUM21_GV_QQ_VM
                            set QA_10_GRADE = vQA_10_GRADE,
                                QA_11_GRADE = vQA_11_GRADE,
                                QA_12_GRADE = vQA_12_GRADE,
                                Q_QA_GRADE  = vQ_QA_GRADE,
                                QB_10_GRADE =  vQB_10_GRADE,
                                QB_11_GRADE =  vQB_11_GRADE,
                                QB_12_GRADE =  vQB_12_GRADE,
                                Q_QB_GRADE  =  vQ_QB_GRADE,
                                QC_10_GRADE =  vQC_10_GRADE,
                                QC_11_GRADE =  vQC_11_GRADE,
                                QC_12_GRADE =  vQC_12_GRADE,
                                Q_QC_GRADE  =  vQ_QC_GRADE,
                                QD_10_GRADE =  vQD_10_GRADE,
                                QD_11_GRADE =  vQD_11_GRADE,
                                QD_12_GRADE =  vQD_12_GRADE,
                                Q_QD_GRADE  =  vQ_QD_GRADE,
                                SUBTOT_10_Q =  vSUBTOT_10_Q,
                                SUBTOT_11_Q =  vSUBTOT_11_Q,
                                SUBTOT_12_Q =  vSUBTOT_12_Q,
                                SUBTOT_Q    =  vSUBTOT_Q,
                                CA_10_GRADE =  vCA_10_GRADE,
                                CA_11_GRADE =  vCA_11_GRADE,
                                CA_12_GRADE =  vCA_12_GRADE,
                                Q_CA_GRADE  =  vQ_CA_GRADE,
                                CB_10_GRADE =  vCB_10_GRADE,
                                CB_11_GRADE =  vCB_11_GRADE,
                                CB_12_GRADE =  vCB_12_GRADE,
                                Q_CB_GRADE  =  vQ_CB_GRADE,
                                CC_10_GRADE =  vCC_10_GRADE,
                                CC_11_GRADE =  vCC_11_GRADE,
                                CC_12_GRADE =  vCC_12_GRADE,
                                CC_GRADE    =  vCC_GRADE,
                                CD_10_GRADE =  vCD_10_GRADE,
                                CD_11_GRADE =  vCD_11_GRADE,
                                CD_12_GRADE =  vCD_12_GRADE,
                                Q_CD_GRADE  =  vQ_CD_GRADE,
                                SUBTOT_10_C =  vSUBTOT_10_C,
                                SUBTOT_11_C =  vSUBTOT_11_C,
                                SUBTOT_12_C =  vSUBTOT_12_C,
                                SUBTOT_C    =  vSUBTOT_C,
                                D1_10_GRADE =  vD1_10_GRADE,
                                D1_11_GRADE =  vD1_11_GRADE,
                                D1_12_GRADE =  vD1_12_GRADE,
                                Q_D1_GRADE  =  vQ_D1_GRADE,
                                D2_10_GRADE =  vD2_10_GRADE,
                                D2_11_GRADE =  vD2_11_GRADE,
                                D2_12_GRADE =  vD2_12_GRADE,
                                Q_D2_GRADE  =  vQ_D2_GRADE,
                                DE_10_GRADE =  vDE_10_GRADE,
                                DE_11_GRADE =  vDE_11_GRADE,
                                DE_12_GRADE =  vDE_12_GRADE,
                                Q_DE_GRADE  =  vQ_DE_GRADE,
                                DF_10_GRADE =  vDF_10_GRADE,
                                DF_11_GRADE =  vDF_11_GRADE,
                                DF_12_GRADE =  vDF_12_GRADE,
                                Q_DF_GRADE  =  vQ_DF_GRADE,
                                DG_10_GRADE =  vDG_10_GRADE,
                                DG_11_GRADE =  vDG_11_GRADE,
                                DG_12_GRADE =  vDG_12_GRADE,
                                Q_DG_GRADE  =  vQ_DG_GRADE,
                                DH_10_GRADE =  vDH_10_GRADE,
                                DH_11_GRADE =  vDH_11_GRADE,
                                DH_12_GRADE =  vDH_12_GRADE,
                                Q_DH_GRADE  =  vQ_DH_GRADE,
                                DI_10_GRADE =  vDI_10_GRADE,
                                DI_11_GRADE =  vDI_11_GRADE,
                                DI_12_GRADE =  vDI_12_GRADE,
                                Q_DI_GRADE  =  vQ_DI_GRADE,
                                DJ_10_GRADE =  vDJ_10_GRADE,
                                DJ_11_GRADE =  vDJ_11_GRADE,
                                DJ_12_GRADE =  vDJ_12_GRADE,
                                Q_DJ_GRADE  =  vQ_DJ_GRADE,
                                TOT_10_CQD  =  vTOT_10_CQD,
                                TOT_11_CQD  =  vTOT_11_CQD,
                                TOT_12_CQD  =  vTOT_12_CQD,
                                SUBTOT_10_D3=  vSUBTOT_10_D3,
                                SUBTOT_11_D3=  vSUBTOT_11_D3,
                                SUBTOT_12_D3=  vSUBTOT_12_D3,
                                SUBTOT_D3   =  vSUBTOT_D3,
                                Q_SUBTOT_D3 =  vQ_SUBTOT_D3,
                                TOT_10_D    =  vTOT_10_D,
                                TOT_11_D    =  vTOT_11_D,
                                TOT_12_D    =  vTOT_12_D,
                                SUBTOT_10_D =  vSUBTOT_10_D,
                                SUBTOT_11_D =  vSUBTOT_11_D,
                                SUBTOT_12_D =  vSUBTOT_12_D,
                                SUBTOT_D    =  vSUBTOT_D,
                                Q_SUBTOT_D  =  vQ_SUBTOT_D,
                                TOT_10_QCD  =  vTOT_10_QCD,
                                TOT_11_QCD  =  vTOT_11_QCD,
                                TOT_12_QCD  =  vTOT_12_QCD,
                                Q_10_SCORE  =  vQ_10_SCORE,
                                Q_11_SCORE  =  vQ_11_SCORE,
                                Q_12_SCORE  =  vQ_12_SCORE,
                                MM_SCORE    =  vMM_SCORE,
                                Q_MM_SCORE  =  vQ_MM_SCORE
        where QUARTER = vQUARTER
          and GV_VENDOR = REC1.GV_VENDOR;
       commit;

  end loop;

  -- Susan 2010/09/14
  iTracePoint := '605';
  for REC1 in (
     select a.GV_VENDOR, a.QUARTER,
      ( select b.GVC_TRACK from GVM031_GLOBAL_VENDOR b where b.GLOBAL_VENDOR_CODE = a.GV_VENDOR) as GVC_TRACK
      from VRTN_SUM21_GV_QQ_VM a
      where a.QUARTER = vQUARTER
      group by a.GV_VENDOR, a.QUARTER
  ) loop
     Update VRTN_SUM21_GV_QQ_VM
        set GVC_TRACK = REC1.GVC_TRACK
      where GV_VENDOR = REC1.GV_VENDOR
        and QUARTER = REC1.QUARTER;
     commit;
  end loop;
  --END

  iTracePoint := '610';
  vQ_RANKING := 0;
  for REC1 in (
     select a.GV_VENDOR, a.QUARTER, ( select b.GRADE from VRTN_SUM23_MAPPING_GRADE b where b.RANGE_TYPE = 'SC' and b.RANGE_FROM <= a.MM_SCORE and b.RANGE_TO >= a.MM_SCORE ) as Q_GRADE
       from VRTN_SUM21_GV_QQ_VM a
      where a.QUARTER = vQUARTER
      order by a.MM_SCORE desc, a.SUBTOT_Q desc, a.SUBTOT_C desc, a.Q_SUBTOT_D desc, a.Q_AMOUNT desc

  ) loop
     vQ_RANKING := vQ_RANKING + 1;
     Update VRTN_SUM21_GV_QQ_VM
        set Q_GRADE = REC1.Q_GRADE,
            Q_RANKING = vQ_RANKING
      where GV_VENDOR = REC1.GV_VENDOR
        and QUARTER = REC1.QUARTER;
     commit;
  end loop;



  iTracePoint := '620';  --GV_VENDOR, GV / WW
  for REC1 in (
      select distinct GV_VENDOR from VRTN_SUM21_GV_QQ_VM
             where QUARTER = vQUARTER
   ) loop
      BEGIN
        select * into vQ_AMOUNT from (
          select round(sum(Q_AMOUNT),5) AS Q_AMOUNT from VRTN_SUM21_GV_QQ_VM
           where QUARTER = vQUARTER
        );
      EXCEPTION
        When OTHERS Then
          vQ_AMOUNT := 0;
      END;
          if vQ_AMOUNT > 0 then
         Update VRTN_SUM21_GV_QQ_VM
            set AMT_SHARE_GV = round(Q_AMOUNT / vQ_AMOUNT, 5) * 100
         where GV_VENDOR = REC1.GV_VENDOR
           and QUARTER = vQUARTER;
         commit;
          else
         MAIL_FILE_BIDBDBADMIN(in_to_name => 'shuchin_lin@usiglobal.com', subject => '[VRTN] PL/SQL VRTN_PLSQL_SUM8_GV_QQ ERROR', message => '[VRTN_PLSQL_SUM8_GV_QQ], The tracepoint is  ' || iTracePoint || ' and ErrorText= ' || cErrorText || REC1.GV_VENDOR || 'Amt=' || vQ_AMOUNT);

          end if;
  end loop;

--2010/07/08 UGSZ/UGTW
  iTracePoint := '630';
     for REC1 in (
           select distinct GV_VENDOR from VRTN_SUM21_GV_QQ_VM
                 where QUARTER = vQUARTER
       ) loop
        iTracePoint := '640';
           vTW_SITE := '1100';
           vSZ_SITE := '1200';
           vSH_SITE := '1500';
           vTW_VENDOR := '';
           vSZ_VENDOR := '';
           vSH_VENDOR := '';
           vUGSZ_SITE := '1400';
           vUGTW_SITE := '1700';
           vKS_SITE   := '4100';
           vUGSZ_VENDOR := '';
           vUGTW_VENDOR := '';
           vKS_VENDOR   := '';
        -- Clear vendor code
           Update VRTN_SUM21_GV_QQ_VM
              set TW_VENDOR = vTW_VENDOR,
                  SZ_VENDOR = vSZ_VENDOR,
                  SH_VENDOR = vSH_VENDOR,
                  UGSZ_VENDOR = vUGSZ_VENDOR,
                  UGTW_VENDOR = vUGTW_VENDOR,
                  KS_VENDOR   = vKS_VENDOR
            where GV_VENDOR = REC1.GV_VENDOR
              and QUARTER = vQUARTER;
              commit;

        iTracePoint := '650';
          vGV_VENDOR := REC1.GV_VENDOR;
          VRTN_PLSQL_SUM8_SUB02(vTW_SITE,vSZ_SITE,vSH_SITE,vUGSZ_SITE,vUGTW_SITE, vKS_SITE, vMX_SITE,vQUARTER,vGV_VENDOR);

       end loop;

--2010/07/08 UGSZ/UGTW
--By GV_VENDOR Update L1/L2
  vQ_GRADE_L1 := null;
  vTW_Q_SCORE_L1 := null;
  vSH_Q_SCORE_L1 := null;
  vSZ_Q_SCORE_L1 := null;
  vQ_SCORE_L2 := null;
  vTW_Q_SCORE_L2 := null;
  vSH_Q_SCORE_L2 := null;
  vSZ_Q_SCORE_L2 := null;
--
  vUGSZ_Q_SCORE_L1 := null;
  vUGTW_Q_SCORE_L1 := null;
  vUGSZ_Q_SCORE_L2 := null;
  vUGTW_Q_SCORE_L2 := null;
  vKS_Q_SCORE_L1 := null;
  vKS_Q_SCORE_L2 := null;

--2010/07/08 UGSZ/UGTW
  iTracePoint := '660';   --BY GV_VENDOR, Get L1/L2 SCORE
  for REC1 in (
      select distinct GV_VENDOR from VRTN_SUM21_GV_QQ_VM
             where QUARTER = vQUARTER
   ) loop
      BEGIN
         select * into vQ_GRADE_L1, vTW_Q_SCORE_L1, vSH_Q_SCORE_L1, vSZ_Q_SCORE_L1, vUGSZ_Q_SCORE_L1, vUGTW_Q_SCORE_L1, vKS_Q_SCORE_L1 from (
           select Q_MM_SCORE, TW_Q_SCORE, SH_Q_SCORE, SZ_Q_SCORE, UGSZ_Q_SCORE, UGTW_Q_SCORE, KS_Q_SCORE from VRTN_SUM21_GV_QQ_VM
--        select * into vQ_GRADE_L1, vTW_Q_SCORE_L1, vSH_Q_SCORE_L1, vSZ_Q_SCORE_L1, vUGSZ_Q_SCORE_L1, vUGTW_Q_SCORE_L1 from (
--           select Q_MM_SCORE, TW_Q_SCORE, SH_Q_SCORE, SZ_Q_SCORE, UGSZ_Q_SCORE, UGTW_Q_SCORE from VRTN_SUM21_GV_QQ_VM
           where QUARTER = vL1_QUARTER
             and GV_VENDOR = REC1.GV_VENDOR
        );
      EXCEPTION
        When OTHERS Then
          vQ_GRADE_L1 := null;
          vTW_Q_SCORE_L1 := null;
          vSH_Q_SCORE_L1 := null;
          vSZ_Q_SCORE_L1 := null;
          vUGSZ_Q_SCORE_L1 := null;
          vUGTW_Q_SCORE_L1 := null;
          vKS_Q_SCORE_L1 := null;
      END;

      BEGIN
         select * into vQ_SCORE_L2, vTW_Q_SCORE_L2, vSH_Q_SCORE_L2, vSZ_Q_SCORE_L2, vUGSZ_Q_SCORE_L2, vUGTW_Q_SCORE_L2, vKS_Q_SCORE_L2 from (
            select Q_MM_SCORE, TW_Q_SCORE, SH_Q_SCORE, SZ_Q_SCORE, UGSZ_Q_SCORE, UGTW_Q_SCORE, KS_Q_SCORE from VRTN_SUM21_GV_QQ_VM
--         select * into vQ_SCORE_L2, vTW_Q_SCORE_L2, vSH_Q_SCORE_L2, vSZ_Q_SCORE_L2, vUGSZ_Q_SCORE_L2, vUGTW_Q_SCORE_L2 from (
--            select Q_MM_SCORE, TW_Q_SCORE, SH_Q_SCORE, SZ_Q_SCORE, UGSZ_Q_SCORE, UGTW_Q_SCORE from VRTN_SUM21_GV_QQ_VM
            where QUARTER = vL2_QUARTER
              and GV_VENDOR = REC1.GV_VENDOR
         );
      EXCEPTION
        When OTHERS Then
               vQ_SCORE_L2 := null;
               vTW_Q_SCORE_L2 := null;
               vSH_Q_SCORE_L2 := null;
               vSZ_Q_SCORE_L2 := null;
               vUGSZ_Q_SCORE_L2 := null;
               vUGTW_Q_SCORE_L2 := null;
               vKS_Q_SCORE_L2 := null;
      END;

      Update VRTN_SUM21_GV_QQ_VM
         set Q_GRADE_L1 = vQ_GRADE_L1,
             TW_Q_SCORE_L1 = vTW_Q_SCORE_L1,
             SH_Q_SCORE_L1 = vSH_Q_SCORE_L1,
             SZ_Q_SCORE_L1 = vSZ_Q_SCORE_L1,
             UGSZ_Q_SCORE_L1 = vUGSZ_Q_SCORE_L1,
             UGTW_Q_SCORE_L1 = vUGTW_Q_SCORE_L1,
             Q_SCORE_L2 = vQ_SCORE_L2,
             TW_Q_SCORE_L2 = vTW_Q_SCORE_L2,
             SH_Q_SCORE_L2 = vSH_Q_SCORE_L2,
             SZ_Q_SCORE_L2 = vSZ_Q_SCORE_L2,
             UGSZ_Q_SCORE_L2 = vUGSZ_Q_SCORE_L2,
             UGTW_Q_SCORE_L2 = vUGTW_Q_SCORE_L2,
             KS_Q_SCORE_L2 = vKS_Q_SCORE_L2
       where GV_VENDOR = REC1.GV_VENDOR
         and QUARTER = vQUARTER;
      commit;

  end loop;
--End By GV_VENDOR Update L1/L2

--2009/09/18 By GVendor get Amount Max MatGroup - 000
    vGV_VENDOR := null;
    vMATGROUPMAX := null;
    vQ_AMOUNT := null;
    vMATTYPE := null;
    iTracePoint := '380';
     for REC1 in (
        select distinct GV_VENDOR from VRTN_SUM21_GV_QQ_VM
               where QUARTER = vQUARTER
     ) loop

        BEGIN
          select * into vGV_VENDOR, vMATGROUPMAX, vMATTYPE from (
             select GV_VENDOR, MATGROUPMAX, MATTYPE from VRTN_SUM20_GV_QQ_MATGP
                                           where QUARTER = vQUARTER
                                             and GV_VENDOR = REC1.GV_VENDOR
                  GROUP BY GV_VENDOR,MATGROUPMAX,MATTYPE
          );
        EXCEPTION
          When OTHERS Then
            vGV_VENDOR := null;
            vMATGROUPMAX := null;
            vMATTYPE := null;
        END;

        Update VRTN_SUM21_GV_QQ_VM
           set MATGROUPMAX = vMATGROUPMAX,
               MATTYPE = vMATTYPE
         where GV_VENDOR = REC1.GV_VENDOR
           and QUARTER = vQUARTER;
        commit;
     end loop;
--2009/09/18 End By GVendor get Amount max MatGroup- 000


  --COMBINE
  iTracePoint := '700';  --刪除 VVRTN_SUM22_GV_QQ_COMBINE
  delete from VRTN_SUM22_GV_QQ_COMBINE
   where QUARTER = vQUARTER;
  commit;

--Add 2010/07/08 UGSZ/UGTW
  iTracePoint := '800';
  insert into VRTN_SUM22_GV_QQ_COMBINE (GV_VENDOR, MATGROUP, QUARTER, Q_GRADE, Q_RANKING, Q_AMOUNT, FROM_DATE, TO_DATE, DATE_TIME, AMT_SHARE_GV,
                    QA_10_GRADE, QA_11_GRADE, QA_12_GRADE, Q_QA_GRADE, QB_10_GRADE, QB_11_GRADE, QB_12_GRADE, Q_QB_GRADE, QC_10_GRADE, QC_11_GRADE, QC_12_GRADE, Q_QC_GRADE, QD_10_GRADE, QD_11_GRADE, QD_12_GRADE, Q_QD_GRADE, SUBTOT_10_Q, SUBTOT_11_Q, SUBTOT_12_Q, SUBTOT_Q,
                    CA_10_GRADE, CA_11_GRADE, CA_12_GRADE, Q_CA_GRADE, CB_10_GRADE, CB_11_GRADE, CB_12_GRADE, Q_CB_GRADE, CC_10_GRADE, CC_11_GRADE, CC_12_GRADE, CC_GRADE,   CD_10_GRADE, CD_11_GRADE, CD_12_GRADE, Q_CD_GRADE, SUBTOT_10_C, SUBTOT_11_C, SUBTOT_12_C, SUBTOT_C,
                    D1_10_GRADE, D1_11_GRADE, D1_12_GRADE, Q_D1_GRADE, D2_10_GRADE, D2_11_GRADE, D2_12_GRADE, Q_D2_GRADE, DE_10_GRADE, DE_11_GRADE, DE_12_GRADE, Q_DE_GRADE, DF_10_GRADE, DF_11_GRADE, DF_12_GRADE, Q_DF_GRADE, DG_10_GRADE, DG_11_GRADE, DG_12_GRADE, Q_DG_GRADE, DH_10_GRADE, DH_11_GRADE, DH_12_GRADE, Q_DH_GRADE,
                    DI_10_GRADE, DI_11_GRADE, DI_12_GRADE, Q_DI_GRADE, DJ_10_GRADE, DJ_11_GRADE, DJ_12_GRADE, Q_DJ_GRADE, TOT_10_CQD,  TOT_11_CQD,  TOT_12_CQD,  SUBTOT_10_D3, SUBTOT_11_D3, SUBTOT_12_D3, SUBTOT_D3, Q_SUBTOT_D3,
                    TOT_10_D,    TOT_11_D,    TOT_12_D,    SUBTOT_10_D,SUBTOT_11_D, SUBTOT_12_D, SUBTOT_D,    Q_SUBTOT_D, TOT_10_QCD,  TOT_11_QCD,  TOT_12_QCD,  Q_10_SCORE, Q_11_SCORE,  Q_12_SCORE,  MM_SCORE, Q_MM_SCORE,
                    Q_SCORE_L2, Q_GRADE_L1, TW_VENDOR, TW_AMOUNT, TW_AMT_SHARE_SITE, TW_Q_SCORE, TW_SUBTOT_Q, TW_SUBTOT_C, TW_SUBTOT_D, TW_Q_SCORE_L2, TW_Q_SCORE_L1, TW_COMMENT, SH_VENDOR, SH_AMOUNT, SH_AMT_SHARE_SITE, SH_Q_SCORE, SH_SUBTOT_Q, SH_SUBTOT_C, SH_SUBTOT_D, SH_Q_SCORE_L2, SH_Q_SCORE_L1, SH_COMMENT,
                    SZ_VENDOR, SZ_AMOUNT, SZ_AMT_SHARE_SITE, SZ_Q_SCORE, SZ_SUBTOT_Q, SZ_SUBTOT_C, SZ_SUBTOT_D, SZ_Q_SCORE_L2, SZ_Q_SCORE_L1, SZ_COMMENT, MATGROUPMAX, MATTYPE,
                    UGSZ_VENDOR, UGSZ_AMOUNT, UGSZ_AMT_SHARE_SITE, UGSZ_Q_SCORE, UGSZ_SUBTOT_Q, UGSZ_SUBTOT_C, UGSZ_SUBTOT_D, UGSZ_Q_SCORE_L2, UGSZ_Q_SCORE_L1, UGSZ_COMMENT,
                    UGTW_VENDOR, UGTW_AMOUNT, UGTW_AMT_SHARE_SITE, UGTW_Q_SCORE, UGTW_SUBTOT_Q, UGTW_SUBTOT_C, UGTW_SUBTOT_D, UGTW_Q_SCORE_L2, UGTW_Q_SCORE_L1, UGTW_COMMENT, GVC_TRACK,KS_VENDOR,
                    KS_AMOUNT, KS_AMT_SHARE_SITE, KS_Q_SCORE, KS_SUBTOT_Q, KS_SUBTOT_C, KS_SUBTOT_D, KS_Q_SCORE_L2, KS_Q_SCORE_L1, KS_COMMENT
                     )
         select     GV_VENDOR, MATGROUP, QUARTER, Q_GRADE, Q_RANKING, Q_AMOUNT, FROM_DATE, TO_DATE, DATE_TIME, AMT_SHARE_GV,
                    QA_10_GRADE, QA_11_GRADE, QA_12_GRADE, Q_QA_GRADE, QB_10_GRADE, QB_11_GRADE, QB_12_GRADE, Q_QB_GRADE, QC_10_GRADE, QC_11_GRADE, QC_12_GRADE, Q_QC_GRADE, QD_10_GRADE, QD_11_GRADE, QD_12_GRADE, Q_QD_GRADE, SUBTOT_10_Q, SUBTOT_11_Q, SUBTOT_12_Q, SUBTOT_Q,
                    CA_10_GRADE, CA_11_GRADE, CA_12_GRADE, Q_CA_GRADE, CB_10_GRADE, CB_11_GRADE, CB_12_GRADE, Q_CB_GRADE, CC_10_GRADE, CC_11_GRADE, CC_12_GRADE, CC_GRADE,   CD_10_GRADE, CD_11_GRADE, CD_12_GRADE, Q_CD_GRADE, SUBTOT_10_C, SUBTOT_11_C, SUBTOT_12_C, SUBTOT_C,
                    D1_10_GRADE, D1_11_GRADE, D1_12_GRADE, Q_D1_GRADE, D2_10_GRADE, D2_11_GRADE, D2_12_GRADE, Q_D2_GRADE, DE_10_GRADE, DE_11_GRADE, DE_12_GRADE, Q_DE_GRADE, DF_10_GRADE, DF_11_GRADE, DF_12_GRADE, Q_DF_GRADE, DG_10_GRADE, DG_11_GRADE, DG_12_GRADE, Q_DG_GRADE, DH_10_GRADE, DH_11_GRADE, DH_12_GRADE, Q_DH_GRADE,
                    DI_10_GRADE, DI_11_GRADE, DI_12_GRADE, Q_DI_GRADE, DJ_10_GRADE, DJ_11_GRADE, DJ_12_GRADE, Q_DJ_GRADE, TOT_10_CQD,  TOT_11_CQD,  TOT_12_CQD,  SUBTOT_10_D3, SUBTOT_11_D3, SUBTOT_12_D3, SUBTOT_D3, Q_SUBTOT_D3,
                    TOT_10_D,    TOT_11_D,    TOT_12_D,    SUBTOT_10_D,SUBTOT_11_D, SUBTOT_12_D, SUBTOT_D,    Q_SUBTOT_D, TOT_10_QCD,  TOT_11_QCD,  TOT_12_QCD,  Q_10_SCORE, Q_11_SCORE,  Q_12_SCORE,  MM_SCORE, Q_MM_SCORE,
                    Q_SCORE_L2, Q_GRADE_L1, TW_VENDOR, TW_AMOUNT, TW_AMT_SHARE_SITE, TW_Q_SCORE, TW_SUBTOT_Q, TW_SUBTOT_C, TW_SUBTOT_D, TW_Q_SCORE_L2, TW_Q_SCORE_L1, TW_COMMENT, SH_VENDOR, SH_AMOUNT, SH_AMT_SHARE_SITE, SH_Q_SCORE, SH_SUBTOT_Q, SH_SUBTOT_C, SH_SUBTOT_D, SH_Q_SCORE_L2, SH_Q_SCORE_L1, SH_COMMENT,
                    SZ_VENDOR, SZ_AMOUNT, SZ_AMT_SHARE_SITE, SZ_Q_SCORE, SZ_SUBTOT_Q, SZ_SUBTOT_C, SZ_SUBTOT_D, SZ_Q_SCORE_L2, SZ_Q_SCORE_L1, SZ_COMMENT, MATGROUPMAX, MATTYPE,
                    UGSZ_VENDOR, UGSZ_AMOUNT, UGSZ_AMT_SHARE_SITE, UGSZ_Q_SCORE, UGSZ_SUBTOT_Q, UGSZ_SUBTOT_C, UGSZ_SUBTOT_D, UGSZ_Q_SCORE_L2, UGSZ_Q_SCORE_L1, UGSZ_COMMENT,
                    UGTW_VENDOR, UGTW_AMOUNT, UGTW_AMT_SHARE_SITE, UGTW_Q_SCORE, UGTW_SUBTOT_Q, UGTW_SUBTOT_C, UGTW_SUBTOT_D, UGTW_Q_SCORE_L2, UGTW_Q_SCORE_L1, UGTW_COMMENT, GVC_TRACK, KS_VENDOR,
                    KS_AMOUNT, KS_AMT_SHARE_SITE, KS_Q_SCORE, KS_SUBTOT_Q, KS_SUBTOT_C, KS_SUBTOT_D, KS_Q_SCORE_L2, KS_Q_SCORE_L1, KS_COMMENT
         from  VRTN_SUM20_GV_QQ_MATGP
                 where QUARTER = vQUARTER
              union all
                 select     GV_VENDOR, '000', QUARTER, Q_GRADE, Q_RANKING, Q_AMOUNT, FROM_DATE, TO_DATE, DATE_TIME, AMT_SHARE_GV,
                    QA_10_GRADE, QA_11_GRADE, QA_12_GRADE, Q_QA_GRADE, QB_10_GRADE, QB_11_GRADE, QB_12_GRADE, Q_QB_GRADE, QC_10_GRADE, QC_11_GRADE, QC_12_GRADE, Q_QC_GRADE, QD_10_GRADE, QD_11_GRADE, QD_12_GRADE, Q_QD_GRADE, SUBTOT_10_Q, SUBTOT_11_Q, SUBTOT_12_Q, SUBTOT_Q,
                    CA_10_GRADE, CA_11_GRADE, CA_12_GRADE, Q_CA_GRADE, CB_10_GRADE, CB_11_GRADE, CB_12_GRADE, Q_CB_GRADE, CC_10_GRADE, CC_11_GRADE, CC_12_GRADE, CC_GRADE,   CD_10_GRADE, CD_11_GRADE, CD_12_GRADE, Q_CD_GRADE, SUBTOT_10_C, SUBTOT_11_C, SUBTOT_12_C, SUBTOT_C,
                    D1_10_GRADE, D1_11_GRADE, D1_12_GRADE, Q_D1_GRADE, D2_10_GRADE, D2_11_GRADE, D2_12_GRADE, Q_D2_GRADE, DE_10_GRADE, DE_11_GRADE, DE_12_GRADE, Q_DE_GRADE, DF_10_GRADE, DF_11_GRADE, DF_12_GRADE, Q_DF_GRADE, DG_10_GRADE, DG_11_GRADE, DG_12_GRADE, Q_DG_GRADE, DH_10_GRADE, DH_11_GRADE, DH_12_GRADE, Q_DH_GRADE,
                    DI_10_GRADE, DI_11_GRADE, DI_12_GRADE, Q_DI_GRADE, DJ_10_GRADE, DJ_11_GRADE, DJ_12_GRADE, Q_DJ_GRADE, TOT_10_CQD,  TOT_11_CQD,  TOT_12_CQD,  SUBTOT_10_D3, SUBTOT_11_D3, SUBTOT_12_D3, SUBTOT_D3, Q_SUBTOT_D3,
                    TOT_10_D,    TOT_11_D,    TOT_12_D,    SUBTOT_10_D,SUBTOT_11_D, SUBTOT_12_D, SUBTOT_D,    Q_SUBTOT_D, TOT_10_QCD,  TOT_11_QCD,  TOT_12_QCD,  Q_10_SCORE, Q_11_SCORE,  Q_12_SCORE,  MM_SCORE, Q_MM_SCORE,
                    Q_SCORE_L2, Q_GRADE_L1, TW_VENDOR, TW_AMOUNT, TW_AMT_SHARE_SITE, TW_Q_SCORE, TW_SUBTOT_Q, TW_SUBTOT_C, TW_SUBTOT_D, TW_Q_SCORE_L2, TW_Q_SCORE_L1, TW_COMMENT, SH_VENDOR, SH_AMOUNT, SH_AMT_SHARE_SITE, SH_Q_SCORE, SH_SUBTOT_Q, SH_SUBTOT_C, SH_SUBTOT_D, SH_Q_SCORE_L2, SH_Q_SCORE_L1, SH_COMMENT,
                    SZ_VENDOR, SZ_AMOUNT, SZ_AMT_SHARE_SITE, SZ_Q_SCORE, SZ_SUBTOT_Q, SZ_SUBTOT_C, SZ_SUBTOT_D, SZ_Q_SCORE_L2, SZ_Q_SCORE_L1, SZ_COMMENT, MATGROUPMAX, MATTYPE,
                    UGSZ_VENDOR, UGSZ_AMOUNT, UGSZ_AMT_SHARE_SITE, UGSZ_Q_SCORE, UGSZ_SUBTOT_Q, UGSZ_SUBTOT_C, UGSZ_SUBTOT_D, UGSZ_Q_SCORE_L2, UGSZ_Q_SCORE_L1, UGSZ_COMMENT,
                    UGTW_VENDOR, UGTW_AMOUNT, UGTW_AMT_SHARE_SITE, UGTW_Q_SCORE, UGTW_SUBTOT_Q, UGTW_SUBTOT_C, UGTW_SUBTOT_D, UGTW_Q_SCORE_L2, UGTW_Q_SCORE_L1, UGTW_COMMENT, GVC_TRACK, KS_VENDOR,
                    KS_AMOUNT, KS_AMT_SHARE_SITE, KS_Q_SCORE, KS_SUBTOT_Q, KS_SUBTOT_C, KS_SUBTOT_D, KS_Q_SCORE_L2, KS_Q_SCORE_L1, KS_COMMENT
         from VRTN_SUM21_GV_QQ_VM
                 where QUARTER = vQUARTER;

   commit;




EXCEPTION
   When OTHERS Then
    --有錯誤產生則寄mail
      cErrorText := SQLERRM();
      MAIL_FILE_BIDBDBADMIN(in_to_name => 'shuchin_lin@usiglobal.com', subject => '[VRTN] PL/SQL VRTN_PLSQL_SUM8_GV_QQ ERROR', message => '[VRTN_PLSQL_SUM8_GV_QQ], The tracepoint is  ' || iTracePoint || ' and ErrorText= ' || cErrorText);


END VRTN_PLSQL_SUM8_GV_QQ2019_BK;
/

