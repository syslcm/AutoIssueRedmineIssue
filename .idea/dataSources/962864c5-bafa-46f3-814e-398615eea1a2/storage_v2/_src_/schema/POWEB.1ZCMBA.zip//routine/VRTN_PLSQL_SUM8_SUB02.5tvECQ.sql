create PROCEDURE         "VRTN_PLSQL_SUM8_SUB02" (
  vTW_SITE in VARCHAR2,
  vSZ_SITE in VARCHAR2,
  vSH_SITE in VARCHAR2,
  vUGSZ_SITE in VARCHAR2,
  vUGTW_SITE in VARCHAR2,
  vKS_SITE in VARCHAR2,
  vMX_SITE in VARCHAR2, 
  vQUARTER in VARCHAR2,
  vGV_VENDOR in VARCHAR2
)
IS
    /*
         Susan Lin Create:
         VRTN_PLSQL_SUM8_SUB02 VENDOR
         By Susan 2007/09/28
         By Susan 2015/04/16 Ks  
     */

      --TW VENDOR SELECT
       CURSOR TW_VENDOR is
       select VENDOR, Q_AMOUNT, Q_MM_SCORE, SUBTOT_Q, SUBTOT_C, Q_SUBTOT_D from VRTN_SUM15_QQ_VM
                           where QUARTER = vQUARTER
                             and GV_VENDOR = vGV_VENDOR
                             and SITE = vTW_SITE
       GROUP BY QUARTER,GV_VENDOR,SITE,VENDOR, Q_AMOUNT, Q_MM_SCORE, SUBTOT_Q, SUBTOT_C, Q_SUBTOT_D;
      -- SZ VENDOR SELECT
         CURSOR SZ_VENDOR is
         select VENDOR, Q_AMOUNT, Q_MM_SCORE, SUBTOT_Q, SUBTOT_C, Q_SUBTOT_D from VRTN_SUM15_QQ_VM
                             where QUARTER = vQUARTER
                               and GV_VENDOR = vGV_VENDOR
                               and SITE = vSZ_SITE
         GROUP BY QUARTER,GV_VENDOR,SITE,VENDOR, Q_AMOUNT, Q_MM_SCORE, SUBTOT_Q, SUBTOT_C, Q_SUBTOT_D;

       --SH VENDOR SELECT
        CURSOR SH_VENDOR is
        select VENDOR, Q_AMOUNT, Q_MM_SCORE, SUBTOT_Q, SUBTOT_C, Q_SUBTOT_D from VRTN_SUM15_QQ_VM
                            where QUARTER = vQUARTER
                              and GV_VENDOR = vGV_VENDOR
                              and SITE = vSH_SITE
        GROUP BY QUARTER,GV_VENDOR,SITE,VENDOR, Q_AMOUNT, Q_MM_SCORE, SUBTOT_Q, SUBTOT_C, Q_SUBTOT_D;

       --UGSZ VENDOR SELECT
        CURSOR UGSZ_VENDOR is
        select VENDOR, Q_AMOUNT, Q_MM_SCORE, SUBTOT_Q, SUBTOT_C, Q_SUBTOT_D from VRTN_SUM15_QQ_VM
                            where QUARTER = vQUARTER
                              and GV_VENDOR = vGV_VENDOR
                              and SITE = vUGSZ_SITE
        GROUP BY QUARTER,GV_VENDOR,SITE,VENDOR, Q_AMOUNT, Q_MM_SCORE, SUBTOT_Q, SUBTOT_C, Q_SUBTOT_D;

       --UGTW VENDOR SELECT
        CURSOR UGTW_VENDOR is
        select VENDOR, Q_AMOUNT, Q_MM_SCORE, SUBTOT_Q, SUBTOT_C, Q_SUBTOT_D from VRTN_SUM15_QQ_VM
                            where QUARTER = vQUARTER
                              and GV_VENDOR = vGV_VENDOR
                              and SITE = vUGTW_SITE
        GROUP BY QUARTER,GV_VENDOR,SITE,VENDOR, Q_AMOUNT, Q_MM_SCORE, SUBTOT_Q, SUBTOT_C, Q_SUBTOT_D;
        
        --
        CURSOR KS_VENDOR is
        select VENDOR, Q_AMOUNT, Q_MM_SCORE, SUBTOT_Q, SUBTOT_C, Q_SUBTOT_D from VRTN_SUM15_QQ_VM
                            where QUARTER = vQUARTER
                              and GV_VENDOR = vGV_VENDOR
                              and SITE = vKS_SITE
        GROUP BY QUARTER,GV_VENDOR,SITE,VENDOR, Q_AMOUNT, Q_MM_SCORE, SUBTOT_Q, SUBTOT_C, Q_SUBTOT_D;
        
        --
        CURSOR MX_VENDOR is
        select VENDOR, Q_AMOUNT, Q_MM_SCORE, SUBTOT_Q, SUBTOT_C, Q_SUBTOT_D from VRTN_SUM15_QQ_VM
                            where QUARTER = vQUARTER
                              and GV_VENDOR = vGV_VENDOR
                              and SITE = vMX_SITE
        GROUP BY QUARTER,GV_VENDOR,SITE,VENDOR, Q_AMOUNT, Q_MM_SCORE, SUBTOT_Q, SUBTOT_C, Q_SUBTOT_D;
       
                       
iTracePoint      varchar2(100);
cErrorText       varchar2(500);

vTW_VENDOR varchar2(100);
vSZ_VENDOR varchar2(100);
vSH_VENDOR varchar2(100);

vTW_AMOUNT NUMBER(20,5);
vSZ_AMOUNT NUMBER(20,5);
vSH_AMOUNT NUMBER(20,5);
vTOT_AMOUNT NUMBER(25,5);
vTW_AMT_SHARE_SITE VRTN_SUM20_GV_QQ_MATGP.TW_AMT_SHARE_SITE%TYPE;
vSZ_AMT_SHARE_SITE VRTN_SUM20_GV_QQ_MATGP.SZ_AMT_SHARE_SITE%TYPE;
vSH_AMT_SHARE_SITE VRTN_SUM20_GV_QQ_MATGP.SH_AMT_SHARE_SITE%TYPE;
vTW_Q_SCORE VRTN_SUM20_GV_QQ_MATGP.TW_Q_SCORE%TYPE;
vSZ_Q_SCORE VRTN_SUM20_GV_QQ_MATGP.SZ_Q_SCORE%TYPE;
vSH_Q_SCORE VRTN_SUM20_GV_QQ_MATGP.SH_Q_SCORE%TYPE;
vTW_SITE_PER VRTN_SUM20_GV_QQ_MATGP.SH_AMT_SHARE_SITE%TYPE;
vSZ_SITE_PER VRTN_SUM20_GV_QQ_MATGP.SH_AMT_SHARE_SITE%TYPE;
vSH_SITE_PER VRTN_SUM20_GV_QQ_MATGP.SH_AMT_SHARE_SITE%TYPE;

vTW_SUBTOT_Q   VRTN_SUM20_GV_QQ_MATGP.SUBTOT_Q%TYPE;
vTW_SUBTOT_C   VRTN_SUM20_GV_QQ_MATGP.SUBTOT_Q%TYPE;
vTW_Q_SUBTOT_D VRTN_SUM20_GV_QQ_MATGP.SUBTOT_Q%TYPE;
vSZ_SUBTOT_Q   VRTN_SUM20_GV_QQ_MATGP.SUBTOT_Q%TYPE;
vSZ_SUBTOT_C   VRTN_SUM20_GV_QQ_MATGP.SUBTOT_Q%TYPE;
vSZ_Q_SUBTOT_D VRTN_SUM20_GV_QQ_MATGP.SUBTOT_Q%TYPE;
vSH_SUBTOT_Q   VRTN_SUM20_GV_QQ_MATGP.SUBTOT_Q%TYPE;
vSH_SUBTOT_C   VRTN_SUM20_GV_QQ_MATGP.SUBTOT_Q%TYPE;
vSH_Q_SUBTOT_D VRTN_SUM20_GV_QQ_MATGP.SUBTOT_Q%TYPE;

--
vUGSZ_VENDOR varchar2(100);
vUGSZ_AMOUNT NUMBER(20,5);
vUGSZ_AMT_SHARE_SITE VRTN_SUM20_GV_QQ_MATGP.SH_AMT_SHARE_SITE%TYPE;
vUGSZ_Q_SCORE VRTN_SUM20_GV_QQ_MATGP.SH_Q_SCORE%TYPE;
vUGSZ_SITE_PER VRTN_SUM20_GV_QQ_MATGP.SH_AMT_SHARE_SITE%TYPE;
vUGSZ_SUBTOT_Q   VRTN_SUM20_GV_QQ_MATGP.SUBTOT_Q%TYPE;
vUGSZ_SUBTOT_C   VRTN_SUM20_GV_QQ_MATGP.SUBTOT_Q%TYPE;
vUGSZ_Q_SUBTOT_D VRTN_SUM20_GV_QQ_MATGP.SUBTOT_Q%TYPE;
vUGTW_VENDOR varchar2(100);
vUGTW_AMOUNT NUMBER(20,5);
vUGTW_AMT_SHARE_SITE VRTN_SUM20_GV_QQ_MATGP.SH_AMT_SHARE_SITE%TYPE;
vUGTW_Q_SCORE VRTN_SUM20_GV_QQ_MATGP.SH_Q_SCORE%TYPE;
vUGTW_SITE_PER VRTN_SUM20_GV_QQ_MATGP.SH_AMT_SHARE_SITE%TYPE;
vUGTW_SUBTOT_Q   VRTN_SUM20_GV_QQ_MATGP.SUBTOT_Q%TYPE;
vUGTW_SUBTOT_C   VRTN_SUM20_GV_QQ_MATGP.SUBTOT_Q%TYPE;
vUGTW_Q_SUBTOT_D VRTN_SUM20_GV_QQ_MATGP.SUBTOT_Q%TYPE;

vKS_VENDOR varchar2(100);
vKS_AMOUNT NUMBER(20,5);
vKS_AMT_SHARE_SITE VRTN_SUM20_GV_QQ_MATGP.SH_AMT_SHARE_SITE%TYPE;
vKS_Q_SCORE VRTN_SUM20_GV_QQ_MATGP.SH_Q_SCORE%TYPE;
vKS_SITE_PER VRTN_SUM20_GV_QQ_MATGP.SH_AMT_SHARE_SITE%TYPE;
vKS_SUBTOT_Q   VRTN_SUM20_GV_QQ_MATGP.SUBTOT_Q%TYPE;
vKS_SUBTOT_C   VRTN_SUM20_GV_QQ_MATGP.SUBTOT_Q%TYPE;
vKS_Q_SUBTOT_D VRTN_SUM20_GV_QQ_MATGP.SUBTOT_Q%TYPE;
--
vMX_VENDOR varchar2(100);
vMX_AMOUNT NUMBER(20,5);
vMX_AMT_SHARE_SITE VRTN_SUM20_GV_QQ_MATGP.SH_AMT_SHARE_SITE%TYPE;
vMX_Q_SCORE VRTN_SUM20_GV_QQ_MATGP.SH_Q_SCORE%TYPE;
vMX_SITE_PER VRTN_SUM20_GV_QQ_MATGP.SH_AMT_SHARE_SITE%TYPE;
vMX_SUBTOT_Q   VRTN_SUM20_GV_QQ_MATGP.SUBTOT_Q%TYPE;
vMX_SUBTOT_C   VRTN_SUM20_GV_QQ_MATGP.SUBTOT_Q%TYPE;
vMX_Q_SUBTOT_D VRTN_SUM20_GV_QQ_MATGP.SUBTOT_Q%TYPE;
BEGIN

     vTW_VENDOR := '';
     vSZ_VENDOR := '';
     vSH_VENDOR := '';
     vTW_AMOUNT := 0;
     vSZ_AMOUNT := 0;
     vSH_AMOUNT := 0;
     vTW_AMT_SHARE_SITE := 0;
     vSH_AMT_SHARE_SITE := 0;
     vSZ_AMT_SHARE_SITE := 0;
     vTW_Q_SCORE := 0;
     vSZ_Q_SCORE := 0;
     vSH_Q_SCORE := 0;
     vTW_SUBTOT_Q := 0;
     vTW_SUBTOT_C := 0;
     vTW_Q_SUBTOT_D := 0;
     vSZ_SUBTOT_Q := 0;
     vSZ_SUBTOT_C := 0;
     vSZ_Q_SUBTOT_D := 0;
     vSH_SUBTOT_Q := 0;
     vSH_SUBTOT_C := 0;
     vSH_Q_SUBTOT_D := 0;
     
     vUGSZ_VENDOR := '';
     vUGSZ_AMOUNT := 0;
     vUGSZ_AMT_SHARE_SITE := 0;
     vUGSZ_Q_SCORE := 0;
     vUGSZ_SUBTOT_Q := 0;
     vUGSZ_SUBTOT_C := 0;
     vUGSZ_Q_SUBTOT_D := 0;
     vUGTW_VENDOR := '';
     vUGTW_AMOUNT := 0;
     vUGTW_AMT_SHARE_SITE := 0;
     vUGTW_Q_SCORE := 0;
     vUGTW_SUBTOT_Q := 0;
     vUGTW_SUBTOT_C := 0;
     vUGTW_Q_SUBTOT_D := 0;
     --
     vKS_VENDOR := ''; 
     vKS_AMOUNT := 0;
     vKS_AMT_SHARE_SITE := 0; 
     vKS_Q_SCORE    := 0;
     vKS_SITE_PER   := 0;
     vKS_SUBTOT_Q   := 0;
     vKS_SUBTOT_C   := 0;
     vKS_Q_SUBTOT_D := 0;
     vMX_VENDOR := ''; 
     vMX_AMOUNT := 0;
     vMX_AMT_SHARE_SITE := 0; 
     vMX_Q_SCORE    := 0;
     vMX_SITE_PER   := 0;
     vMX_SUBTOT_Q   := 0;
     vMX_SUBTOT_C   := 0;
     vMX_Q_SUBTOT_D := 0;                   
     BEGIN
        select * into vTOT_AMOUNT from (
           select round(sum(Q_AMOUNT),5) from VRTN_SUM15_QQ_VM
              where QUARTER = vQUARTER
                and GV_VENDOR = vGV_VENDOR
           GROUP BY QUARTER,GV_VENDOR
                 );
      EXCEPTION
      When OTHERS Then
           vTOT_AMOUNT := 0;
      END;

      iTracePoint := '651'; -- TW VENDOR
      for TW_VENDOR_LIST_REC in TW_VENDOR LOOP
          vTW_VENDOR := trim(TW_VENDOR_LIST_REC.VENDOR || trim(NVL(vTW_VENDOR,' ')));
          vTW_AMOUNT := NVL(to_number(vTW_AMOUNT), 0) + TW_VENDOR_LIST_REC.Q_AMOUNT;

      end loop;

      iTracePoint := '652'; -- SZ VENDOR
      for SZ_VENDOR_LIST_REC in SZ_VENDOR LOOP
         vSZ_VENDOR := trim(SZ_VENDOR_LIST_REC.VENDOR || trim(NVL(vSZ_VENDOR,' ')));
         vSZ_AMOUNT := NVL(to_number(vSZ_AMOUNT), 0) + SZ_VENDOR_LIST_REC.Q_AMOUNT;

      end loop;

      iTracePoint := '653'; -- SH VENDOR
      for SH_VENDOR_LIST_REC in SH_VENDOR LOOP
         vSH_VENDOR := trim(SH_VENDOR_LIST_REC.VENDOR || trim(NVL(vSH_VENDOR,' ')));
         vSH_AMOUNT := NVL(to_number(vSH_AMOUNT), 0) + SH_VENDOR_LIST_REC.Q_AMOUNT;

      end loop;
       
       
      iTracePoint := '654'; -- UGSZ VENDOR
      for UGSZ_VENDOR_LIST_REC in UGSZ_VENDOR LOOP
         vUGSZ_VENDOR := trim(UGSZ_VENDOR_LIST_REC.VENDOR || trim(NVL(vUGSZ_VENDOR,' ')));
         vUGSZ_AMOUNT := NVL(to_number(vUGSZ_AMOUNT), 0) + UGSZ_VENDOR_LIST_REC.Q_AMOUNT;
      end loop;
     
      iTracePoint := '655'; -- UGTW VENDOR
      for UGTW_VENDOR_LIST_REC in UGTW_VENDOR LOOP
         vUGTW_VENDOR := trim(UGTW_VENDOR_LIST_REC.VENDOR || trim(NVL(vUGTW_VENDOR,' ')));
         vUGTW_AMOUNT := NVL(to_number(vUGTW_AMOUNT), 0) + UGTW_VENDOR_LIST_REC.Q_AMOUNT;
      end loop; 
      
      iTracePoint := '655'; -- KS VENDOR
      for KS_VENDOR_LIST_REC in KS_VENDOR LOOP
         vKS_VENDOR := trim(KS_VENDOR_LIST_REC.VENDOR || trim(NVL(vKS_VENDOR,' ')));
         vKS_AMOUNT := NVL(to_number(vKS_AMOUNT), 0) + KS_VENDOR_LIST_REC.Q_AMOUNT;
      end loop; 
                              
      iTracePoint := '655'; -- MX VENDOR
      for MX_VENDOR_LIST_REC in MX_VENDOR LOOP
         vMX_VENDOR := trim(MX_VENDOR_LIST_REC.VENDOR || trim(NVL(vMX_VENDOR,' ')));
         vMX_AMOUNT := NVL(to_number(vMX_AMOUNT), 0) + MX_VENDOR_LIST_REC.Q_AMOUNT;
      end loop; 
      
      iTracePoint := '656'; -- AMOUNT SHARE SITE
      if vTOT_AMOUNT > 0 then
         vTW_AMT_SHARE_SITE := NVL(to_number(vTW_AMOUNT),0 ) / NVL(to_number(vTOT_AMOUNT), 0);
         vSZ_AMT_SHARE_SITE := NVL(to_number(vSZ_AMOUNT),0 ) / NVL(to_number(vTOT_AMOUNT), 0);
         vSH_AMT_SHARE_SITE := NVL(to_number(vSH_AMOUNT),0 ) / NVL(to_number(vTOT_AMOUNT), 0);
         vUGSZ_AMT_SHARE_SITE := NVL(to_number(vUGSZ_AMOUNT),0 ) / NVL(to_number(vTOT_AMOUNT), 0);
         vUGTW_AMT_SHARE_SITE := NVL(to_number(vUGTW_AMOUNT),0 ) / NVL(to_number(vTOT_AMOUNT), 0);
         vKS_AMT_SHARE_SITE := NVL(to_number(vKS_AMOUNT),0 ) / NVL(to_number(vTOT_AMOUNT), 0);
         vMX_AMT_SHARE_SITE := NVL(to_number(vMX_AMOUNT),0 ) / NVL(to_number(vTOT_AMOUNT), 0); --//
      end if;


     iTracePoint := '657'; -- TW VENDOR SITE PER
     for TW_VENDOR_LIST_REC in TW_VENDOR LOOP
        -- UPDATE SITE PER
        --     Update VRTN_SUM15_QQ_VM
        --        set SITE_PER = round(Q_AMOUNT / vTW_AMOUNT, 5)
        --      where QUARTER =  vQUARTER
        --        and SITE = vTW_SITE
        --        and GV_VENDOR = vGV_VENDOR
        --        and VENDOR = TW_VENDOR_LIST_REC.VENDOR;

         if vTW_AMOUNT > 0 then
            vTW_SITE_PER := TW_VENDOR_LIST_REC.Q_AMOUNT / vTW_AMOUNT;
            vTW_Q_SCORE := NVL(to_number(vTW_Q_SCORE), 0) + TW_VENDOR_LIST_REC.Q_MM_SCORE * vTW_SITE_PER;

            vTW_SUBTOT_Q := NVL(to_number(vTW_SUBTOT_Q), 0) + TW_VENDOR_LIST_REC.SUBTOT_Q * vTW_SITE_PER;
            vTW_SUBTOT_C := NVL(to_number(vTW_SUBTOT_C), 0) + TW_VENDOR_LIST_REC.SUBTOT_C * vTW_SITE_PER;
            vTW_Q_SUBTOT_D := NVL(to_number(vTW_Q_SUBTOT_D), 0) + TW_VENDOR_LIST_REC.Q_SUBTOT_D * vTW_SITE_PER;

         end if;
     end loop;
         commit;

     iTracePoint := '658'; -- SZ VENDOR SITE PER
     for SZ_VENDOR_LIST_REC in SZ_VENDOR LOOP

--             Update VRTN_SUM15_QQ_VM
--                set SITE_PER = round(Q_AMOUNT / vTW_AMOUNT, 5)
--              where QUARTER =  vQUARTER
--                and SITE = vTW_SITE
--                and GV_VENDOR = vGV_VENDOR
--                and VENDOR = TW_VENDOR_LIST_REC.VENDOR
--             commit;
         if vSZ_AMOUNT > 0 then
            vSZ_SITE_PER := SZ_VENDOR_LIST_REC.Q_AMOUNT / vSZ_AMOUNT;
            vSZ_Q_SCORE := NVL(to_number(vSZ_Q_SCORE), 0) + SZ_VENDOR_LIST_REC.Q_MM_SCORE * vSZ_SITE_PER;

            vSZ_SUBTOT_Q := NVL(to_number(vSZ_SUBTOT_Q), 0) + SZ_VENDOR_LIST_REC.SUBTOT_Q * vSZ_SITE_PER;
            vSZ_SUBTOT_C := NVL(to_number(vSZ_SUBTOT_C), 0) + SZ_VENDOR_LIST_REC.SUBTOT_C * vSZ_SITE_PER;
            vSZ_Q_SUBTOT_D := NVL(to_number(vSZ_Q_SUBTOT_D), 0) + SZ_VENDOR_LIST_REC.Q_SUBTOT_D * vSZ_SITE_PER;
--          MAIL_FILE_BIDBDBADMIN(in_to_name => 'shuchin@ms.usi.com.tw', subject => '[VRT] SZ PL/SQL VRTN_PLSQL_SUM8_SUB02 ERROR', message => '[VRTN_PLSQL_SUM8_SUB02], The tracepoint is  ' || iTracePoint || ' TEST= ' ||  vSZ_VENDOR || SZ_VENDOR_LIST_REC.Q_AMOUNT || 'AMT=' || vSZ_AMOUNT || 'PER='|| vSZ_SITE_PER || 'S=' || vSZ_Q_SCORE );

         end if;
     end loop;

     iTracePoint := '659'; -- SH VENDOR SITE PER
     for SH_VENDOR_LIST_REC in SH_VENDOR LOOP

--             Update VRTN_SUM15_QQ_VM
--                set SITE_PER = round(Q_AMOUNT / vTW_AMOUNT, 5)
--              where QUARTER =  vQUARTER
--                and SITE = vTW_SITE
--                and GV_VENDOR = vGV_VENDOR
--                and VENDOR = TW_VENDOR_LIST_REC.VENDOR
         if vSH_AMOUNT > 0 then
            vSH_SITE_PER := SH_VENDOR_LIST_REC.Q_AMOUNT / vSH_AMOUNT;
            vSH_Q_SCORE := NVL(to_number(vSH_Q_SCORE), 0) + SH_VENDOR_LIST_REC.Q_MM_SCORE * vSH_SITE_PER;

            vSH_SUBTOT_Q := NVL(to_number(vSH_SUBTOT_Q), 0) + SH_VENDOR_LIST_REC.SUBTOT_Q * vSH_SITE_PER;
            vSH_SUBTOT_C := NVL(to_number(vSH_SUBTOT_C), 0) + SH_VENDOR_LIST_REC.SUBTOT_C * vSH_SITE_PER;
            vSH_Q_SUBTOT_D := NVL(to_number(vSH_Q_SUBTOT_D), 0) + SH_VENDOR_LIST_REC.Q_SUBTOT_D * vSH_SITE_PER;

         end if;
     end loop;


    iTracePoint := '660'; -- UGSZ VENDOR SITE PER
     for UGSZ_VENDOR_LIST_REC in UGSZ_VENDOR LOOP
         if vUGSZ_AMOUNT > 0 then
            vUGSZ_SITE_PER := UGSZ_VENDOR_LIST_REC.Q_AMOUNT / vUGSZ_AMOUNT;
            vUGSZ_Q_SCORE := NVL(to_number(vUGSZ_Q_SCORE), 0) + UGSZ_VENDOR_LIST_REC.Q_MM_SCORE * vUGSZ_SITE_PER;
            vUGSZ_SUBTOT_Q := NVL(to_number(vUGSZ_SUBTOT_Q), 0) + UGSZ_VENDOR_LIST_REC.SUBTOT_Q * vUGSZ_SITE_PER;
            vUGSZ_SUBTOT_C := NVL(to_number(vUGSZ_SUBTOT_C), 0) + UGSZ_VENDOR_LIST_REC.SUBTOT_C * vUGSZ_SITE_PER;
            vUGSZ_Q_SUBTOT_D := NVL(to_number(vUGSZ_Q_SUBTOT_D), 0) + UGSZ_VENDOR_LIST_REC.Q_SUBTOT_D * vUGSZ_SITE_PER;
         end if;
     end loop;

      iTracePoint := '661'; -- UGTW VENDOR SITE PER
     for UGTW_VENDOR_LIST_REC in UGTW_VENDOR LOOP
         if vUGTW_AMOUNT > 0 then
            vUGTW_SITE_PER := UGTW_VENDOR_LIST_REC.Q_AMOUNT / vUGTW_AMOUNT;
            vUGTW_Q_SCORE := NVL(to_number(vUGTW_Q_SCORE), 0) + UGTW_VENDOR_LIST_REC.Q_MM_SCORE * vUGTW_SITE_PER;
            vUGTW_SUBTOT_Q := NVL(to_number(vUGTW_SUBTOT_Q), 0) + UGTW_VENDOR_LIST_REC.SUBTOT_Q * vUGTW_SITE_PER;
            vUGTW_SUBTOT_C := NVL(to_number(vUGTW_SUBTOT_C), 0) + UGTW_VENDOR_LIST_REC.SUBTOT_C * vUGTW_SITE_PER;
            vUGTW_Q_SUBTOT_D := NVL(to_number(vUGTW_Q_SUBTOT_D), 0) + UGTW_VENDOR_LIST_REC.Q_SUBTOT_D * vUGTW_SITE_PER;
         end if;
     end loop;


     iTracePoint := '661'; -- KS VENDOR SITE PER
     for KS_VENDOR_LIST_REC in KS_VENDOR LOOP
         if vKS_AMOUNT > 0 then
            vKS_SITE_PER := KS_VENDOR_LIST_REC.Q_AMOUNT / vKS_AMOUNT;
            vKS_Q_SCORE := NVL(to_number(vKS_Q_SCORE), 0) + KS_VENDOR_LIST_REC.Q_MM_SCORE * vKS_SITE_PER;
            vKS_SUBTOT_Q := NVL(to_number(vKS_SUBTOT_Q), 0) + KS_VENDOR_LIST_REC.SUBTOT_Q * vKS_SITE_PER;
            vKS_SUBTOT_C := NVL(to_number(vKS_SUBTOT_C), 0) + KS_VENDOR_LIST_REC.SUBTOT_C * vKS_SITE_PER;
            vKS_Q_SUBTOT_D := NVL(to_number(vKS_Q_SUBTOT_D), 0) + KS_VENDOR_LIST_REC.Q_SUBTOT_D * vKS_SITE_PER;
               
         end if;
     end loop;
     
     iTracePoint := '661'; --
     for MX_VENDOR_LIST_REC in MX_VENDOR LOOP
         if vMX_AMOUNT > 0 then
            vMX_SITE_PER := MX_VENDOR_LIST_REC.Q_AMOUNT / vMX_AMOUNT;
            vMX_Q_SCORE := NVL(to_number(vMX_Q_SCORE), 0) + MX_VENDOR_LIST_REC.Q_MM_SCORE * vMX_SITE_PER;
            vMX_SUBTOT_Q := NVL(to_number(vMX_SUBTOT_Q), 0) + MX_VENDOR_LIST_REC.SUBTOT_Q * vMX_SITE_PER;
            vMX_SUBTOT_C := NVL(to_number(vMX_SUBTOT_C), 0) + MX_VENDOR_LIST_REC.SUBTOT_C * vMX_SITE_PER;
            vMX_Q_SUBTOT_D := NVL(to_number(vMX_Q_SUBTOT_D), 0) + MX_VENDOR_LIST_REC.Q_SUBTOT_D * vMX_SITE_PER;
               
         end if;
     end loop;     

     
     iTracePoint := '662'; -- UPDATE SCORE
     Update VRTN_SUM21_GV_QQ_VM
              set TW_VENDOR = vTW_VENDOR,
                  SZ_VENDOR = vSZ_VENDOR,
                  SH_VENDOR = vSH_VENDOR,
                  UGSZ_VENDOR = vUGSZ_VENDOR,
                  UGTW_VENDOR = vUGTW_VENDOR,                  
                  TW_AMOUNT = vTW_AMOUNT,
                  SZ_AMOUNT = vSZ_AMOUNT,
                  SH_AMOUNT = vSH_AMOUNT,
                  UGSZ_AMOUNT = vUGSZ_AMOUNT,
                  UGTW_AMOUNT = vUGTW_AMOUNT,
                  TW_AMT_SHARE_SITE = vTW_AMT_SHARE_SITE,
                  SZ_AMT_SHARE_SITE = vSZ_AMT_SHARE_SITE,
                  SH_AMT_SHARE_SITE = vSH_AMT_SHARE_SITE,
                  UGSZ_AMT_SHARE_SITE = vUGSZ_AMT_SHARE_SITE,
                  UGTW_AMT_SHARE_SITE = vUGTW_AMT_SHARE_SITE,
                  TW_Q_SCORE = vTW_Q_SCORE,
                  SZ_Q_SCORE = vSZ_Q_SCORE,
                  SH_Q_SCORE = vSH_Q_SCORE,
                  UGSZ_Q_SCORE = vUGSZ_Q_SCORE,
                  UGTW_Q_SCORE = vUGTW_Q_SCORE,
                  TW_SUBTOT_Q = vTW_SUBTOT_Q,
                  TW_SUBTOT_C = vTW_SUBTOT_C,
                  TW_SUBTOT_D = vTW_Q_SUBTOT_D,
                  SZ_SUBTOT_Q = vSZ_SUBTOT_Q,
                  SZ_SUBTOT_C = vSZ_SUBTOT_C,
                  SZ_SUBTOT_D = vSZ_Q_SUBTOT_D,
                  SH_SUBTOT_Q = vSH_SUBTOT_Q,
                  SH_SUBTOT_C = vSH_SUBTOT_C,
                  SH_SUBTOT_D = vSH_Q_SUBTOT_D,
                  UGSZ_SUBTOT_Q = vUGSZ_SUBTOT_Q,
                  UGSZ_SUBTOT_C = vUGSZ_SUBTOT_C,
                  UGSZ_SUBTOT_D = vUGSZ_Q_SUBTOT_D,
                  UGTW_SUBTOT_Q = vUGTW_SUBTOT_Q,
                  UGTW_SUBTOT_C = vUGTW_SUBTOT_C,
                  UGTW_SUBTOT_D = vUGTW_Q_SUBTOT_D,
                  KS_VENDOR = vKS_VENDOR,
                  KS_AMOUNT = vKS_AMOUNT,
                  KS_AMT_SHARE_SITE = vKS_AMT_SHARE_SITE, 
                  KS_Q_SCORE = vKS_Q_SCORE,    
                  KS_SUBTOT_Q = vKS_SUBTOT_Q,
                  KS_SUBTOT_C = vKS_SUBTOT_C,
                  KS_SUBTOT_D = vKS_Q_SUBTOT_D,
                  MX_VENDOR = vMX_VENDOR, --
                  MX_AMOUNT = vMX_AMOUNT,
                  MX_AMT_SHARE_SITE = vMX_AMT_SHARE_SITE, 
                  MX_Q_SCORE = vMX_Q_SCORE,    
                  MX_SUBTOT_Q = vMX_SUBTOT_Q,
                  MX_SUBTOT_C = vMX_SUBTOT_C,
                  MX_SUBTOT_D = vMX_Q_SUBTOT_D                                                                                                 
            where GV_VENDOR = vGV_VENDOR
              and QUARTER = vQUARTER;
            commit;


EXCEPTION
   When OTHERS Then
    --有錯誤產生則寄mail
      cErrorText := SQLERRM();
      MAIL_FILE_BIDBDBADMIN(in_to_name => 'shuchin_lin@usiglobal.com', subject => '[VRT] PL/SQL VRTN_PLSQL_SUM8_SUB02 ERROR', message => '[VRTN_PLSQL_SUM8_SUB02], The tracepoint is  ' || iTracePoint || ' and ErrorText= ' || cErrorText);


END VRTN_PLSQL_SUM8_SUB02;
/

