create PROCEDURE       ROIC_PLS004_AM_LIST_TYPE (
/* ********************************************************************
  PROG-ID      : ROIC_PLS004_AM_LIST_TYPE
  PROG-ACTION  : 
  Author       : Asan Chang
  Date         : 2019/02/12
  OA Number    : SAI094675
  Description  : 1.�w���T�w������������class mapping
               : 2.�w��others�����b��ORG���O�_���n�k����PD
               : 3.��ROA_SAP005_CLASS_RULE.ASSET_CLASS=G�}�Y�������A����TB���T(���|����)
               : �o�X���B�^�gROIC_MAP004_AM_LIST_TYPE/ROIC_SAP001_AM_LIST
               : TB��������:roic_vew002_tb_dtl ������type�H��function area
********************************************************************* 
* 2019/02/19 SAI094675 Asan Chang adj for TB
* 2019/05/07 SAI099185 Asan Chang �w��COMPANY_CODE = '2300'�A���eG00�����B�O���@����TB��AMOUNT_LOC2����(���O��WAERS_LOC2)�A
* ���N�^�������������� AMOUNT_LOC
* 2019/12/13 SAI111549 Asan Chang ���H���������������v�����H�������������v
--            �Y���O = 'IS' => ���� 'C'-�����H���������v,������
--            ���L          => ���� 'E'-�����H���������v,�������L��
*********************************************************************  
*/
   incompany    IN   VARCHAR2,
   in_yyyymm    IN   VARCHAR2,
   in_type      IN   VARCHAR2
)
AUTHID DEFINER
IS 
   a_EX_RATE_CNY       EMPS_SAP001_DAILY_DN_ZF430.EX_RATE_CNY%TYPE;
   a_EX_RATE_USD       EMPS_SAP001_DAILY_DN_ZF430.EX_RATE_USD%TYPE;
   a_EX_RATE_TWD       EMPS_SAP001_DAILY_DN_ZF430.EX_RATE_TWD%TYPE;  
   t_CURRENCY_LOCAL    pld_kpi_non_bom_ir.IR_CURRENCY%TYPE;
   sPROC_NAME          ROIC_PST000_LOG.PROC_NAME%TYPE;
   sRUN_SEQ            ROIC_PST000_LOG.RUN_SEQ%TYPE;
   sRUN_DESC           ROIC_PST000_LOG.RUN_DESC%TYPE;
   sPARAMETER_DESC     ROIC_PST000_LOG.PARAMETER_DESC%TYPE;   
            
   

  
   --(1)Loop 1
   CURSOR ROIC_SAP001_AM_LIST
   IS
      SELECT COMPANY_CODE, PERIOD, ASSET_CLASS, ASSET_NO , ASSET_SUB_NO,    
      COST_CENTER, EV_GRP5 ,EV_GRP5_TEXT, CAP_DATE , ASSET_NAME, FYE_ACQ_VAL,     
      CUM_ACQ_VAL, ASSET_VAL_TRANS, VAL_ADJTRANS_FYE, CUM_ORD_DEPREC, 
      ORD_DEP_PSTD, PSTD_UNPL_DEP, CUM_UNPLND_DEP, CUR_NET_BOOK_VAL, 
      INVENTORY_NOTE, SOURCE_FROM               
      FROM ROIC_SAP001_AM_LIST
      where COMPANY_CODE = incompany and PERIOD = in_yyyymm 
      and ASSET_NO <> 'TB';


   itracepoint         INTEGER;
   t_S_SEQ             ROIC_MAP004_AM_LIST_TYPE.S_SEQ%TYPE; 
   t_SOURCE_FROM       VARCHAR(30); 
   t_PD                VARCHAR(10);
   t_AMT               NUMBER(15,5);
   t_WAERS             VARCHAR2(5);
BEGIN

    sPROC_NAME := 'ROIC_PLS004_AM_LIST_TYPE';
    sRUN_SEQ   := '000010';
    sRUN_DESC  := 'Start';
    sPARAMETER_DESC := CONCAT(CONCAT(CONCAT('incompany=',incompany),';t_PERIOD='),in_yyyymm);   

    --Insert Log
    INSERT INTO ROIC_PST000_LOG
      ( PROC_NAME, RUN_SEQ, RUN_DESC, PARAMETER_DESC )
    VALUES
      ( sPROC_NAME, sRUN_SEQ, sRUN_DESC, sPARAMETER_DESC );
    Commit;
   

     --(1)�M��������
     DELETE FROM ROIC_MAP004_AM_LIST_TYPE
     where PERIOD =  in_yyyymm
     AND   COMPANY_CODE = incompany;
     COMMIT;  


     --(2)�p�����v
     select COMPANY_CURR INTO t_CURRENCY_LOCAL FROM PNL_MAP006_SITE_MAPPING WHERE COMPANY_CODE = incompany;
     --a_EX_RATE_USD := Get_Exchange_Rate(SUBSTRB(f_yyyymmdd,1,4),SUBSTRB(f_yyyymmdd,5,2),t_CURRENCY_LOCAL,'USD','R') ;
     --a_EX_RATE_TWD := Get_Exchange_Rate(SUBSTRB(f_yyyymmdd,1,4),SUBSTRB(f_yyyymmdd,5,2),t_CURRENCY_LOCAL,'TWD','R') ;
     --a_EX_RATE_CNY := Get_Exchange_Rate(SUBSTRB(f_yyyymmdd,1,4),SUBSTRB(f_yyyymmdd,5,2),t_CURRENCY_LOCAL,'CNY','R') ;
     --a_EX_RATE_TWD := GET_EXCHANGE_RATE_RWF(SUBSTRB(in_yyyymm,1,4),SUBSTRB(in_yyyymm,5,2),t_CURRENCY_LOCAL,'TWD','C');    
     --a_EX_RATE_USD := GET_EXCHANGE_RATE_RWF(SUBSTRB(in_yyyymm,1,4),SUBSTRB(in_yyyymm,5,2),t_CURRENCY_LOCAL,'USD','C');    
     --a_EX_RATE_CNY := GET_EXCHANGE_RATE_RWF(SUBSTRB(in_yyyymm,1,4),SUBSTRB(in_yyyymm,5,2),t_CURRENCY_LOCAL,'CNY','C');    
     a_EX_RATE_TWD := GET_EXCHANGE_RATE_RWF(SUBSTRB(in_yyyymm,1,4),SUBSTRB(in_yyyymm,5,2),t_CURRENCY_LOCAL,'TWD','E');    
     a_EX_RATE_USD := GET_EXCHANGE_RATE_RWF(SUBSTRB(in_yyyymm,1,4),SUBSTRB(in_yyyymm,5,2),t_CURRENCY_LOCAL,'USD','E');    
     a_EX_RATE_CNY := GET_EXCHANGE_RATE_RWF(SUBSTRB(in_yyyymm,1,4),SUBSTRB(in_yyyymm,5,2),t_CURRENCY_LOCAL,'CNY','E');    
     
     

   FOR REC1 IN ROIC_SAP001_AM_LIST LOOP
   
   
   
   
     --(3)���o�������T�Amapping�������Y������
     t_S_SEQ := '';  
     BEGIN
       select S_SEQ INTO t_S_SEQ FROM ROA_SAP005_CLASS_RULE WHERE COMPANY_CODE = incompany and  ASSET_CLASS = REC1.ASSET_CLASS 
       and rownum <=1 and type = in_type ;                     
     EXCEPTION
       WHEN NO_DATA_FOUND THEN
         t_S_SEQ := '';  
     END;      
       
     t_PD := '';   
     if t_S_SEQ = '40' Then   --others  
       BEGIN  
         select PD INTO t_PD FROM KPI_MAP018_ORGANIZATION WHERE COMPANY_CODE = REC1.COMPANY_CODE
         AND PERIOD = REC1.PERIOD AND SAP_COST_CENTER = REC1.COST_CENTER and rownum <=1; 
         IF t_PD IS NOT NULL then
           t_S_SEQ := '30';   --FA-PD          
         end if ;  
       EXCEPTION
         WHEN NO_DATA_FOUND THEN
           t_S_SEQ := 'N/A';              
       END;    
     end if;       
    
     --�������N�����������A�����j���w�q-CANCEL 2019/02/12
     --���������w����-N/A 2019/02/14
     if LENGTH( t_S_SEQ ) = 0  OR t_S_SEQ IS null Then
       t_S_SEQ := 'N/A';   --
     end if;

     if LENGTH( REC1.SOURCE_FROM ) = 0  OR REC1.SOURCE_FROM IS null Then
       t_SOURCE_FROM  := 'SAP'; 
     else
       t_SOURCE_FROM  := REC1.SOURCE_FROM; 
     end if;
     
     if LENGTH( t_S_SEQ ) = 0  OR t_S_SEQ IS null Then
     --do nothing   
       t_PD := ''; 
     else
       --(4-1)�s�W��������
       INSERT INTO ROIC_MAP004_AM_LIST_TYPE (
          COMPANY_CODE,        PERIOD,                 ASSET_CLASS,          ASSET_NO , 
          ASSET_SUB_NO,        TYPE,                   S_SEQ
          ) VALUES (                 
          REC1.COMPANY_CODE,   REC1.PERIOD,            REC1.ASSET_CLASS,     REC1.ASSET_NO , 
          REC1.ASSET_SUB_NO,   in_type,
          t_S_SEQ               
           );   
       COMMIT;
              
       --(4-2)���s���O���T
       UPDATE ROIC_SAP001_AM_LIST 
       SET SOURCE_FROM  = t_SOURCE_FROM ,
           CURRENCY = t_CURRENCY_LOCAL,
           EX_RATE_TWD = a_EX_RATE_TWD,
           EX_RATE_USD = a_EX_RATE_USD,
           EX_RATE_CNY = a_EX_RATE_CNY          
       WHERE COMPANY_CODE = REC1.COMPANY_CODE
       AND   PERIOD = REC1.PERIOD
       AND   ASSET_CLASS = REC1.ASSET_CLASS
       AND   ASSET_NO = REC1.ASSET_NO
       AND   ASSET_SUB_NO = REC1.ASSET_SUB_NO;
       COMMIT;      
     end if; 
   END LOOP;

   --(2)Loop 2      
   
     DELETE FROM ROIC_SAP001_AM_LIST
     where PERIOD =  in_yyyymm AND COMPANY_CODE = incompany and ASSET_NO = 'TB'; 
     
     COMMIT;
   for REC2 IN (
     select a.company_code,a.asset_class,a.s_seq  ,b.period,
	 b.WAERS_LOC2, b.WAERS_LOC, sum( b.AMOUNT_LOC) AMT, sum( b.AMOUNT_LOC2) AMT2
     FROM ROA_SAP005_CLASS_RULE a left join roic_vew002_tb_dtl b
     on a.company_code = b.company_code and a.account = b.SAP_ACCT
     WHERE a.ASSET_CLASS Like 'G%' and a.type = in_type and b.period = in_yyyymm
     and a.COMPANY_CODE = incompany
     group by a.company_code,a.asset_class,a.s_seq  ,b.period,b.WAERS_LOC2, b.WAERS_LOC   
      )
   LOOP    
     if incompany = '2300'  Then
       t_AMT  := REC2.AMT; 
	   t_WAERS  := REC2.WAERS_LOC; 
     else
       t_AMT  := REC2.AMT2; 
	   t_WAERS  := REC2.WAERS_LOC2;  
     end if;  
  
        INSERT INTO ROIC_SAP001_AM_LIST (
          COMPANY_CODE,        PERIOD,       ASSET_CLASS,       ASSET_NO, ASSET_SUB_NO,    FYE_ACQ_VAL,            
          CUR_NET_BOOK_VAL,
          CURRENCY,            
          EX_RATE_TWD,
          EX_RATE_USD,
          EX_RATE_CNY,
          SOURCE_FROM
          ) VALUES (
                 
          REC2.COMPANY_CODE,   REC2.PERIOD,  REC2.ASSET_CLASS,  'TB',     '0',     REC2.AMT,             
          t_AMT, 
          t_WAERS,
          a_EX_RATE_TWD,     
          a_EX_RATE_USD,   
          a_EX_RATE_CNY,
          'BI-TB'                
           );   
       COMMIT;   
   
       INSERT INTO ROIC_MAP004_AM_LIST_TYPE (
          COMPANY_CODE,        PERIOD,                 ASSET_CLASS,       ASSET_NO,  ASSET_SUB_NO,    TYPE, 
          S_SEQ
          ) VALUES (                 
          REC2.COMPANY_CODE,   REC2.PERIOD,            REC2.ASSET_CLASS,  'TB',      '0',         in_type,
          REC2.S_SEQ                
           );   
       COMMIT;               
   END LOOP;  

     -----------------------------------------
  sRUN_SEQ   := '000020';
  sRUN_DESC  := 'End';

  --Insert Log
  INSERT INTO ROIC_PST000_LOG
      ( PROC_NAME, RUN_SEQ, RUN_DESC, PARAMETER_DESC )
    VALUES
      ( sPROC_NAME, sRUN_SEQ, sRUN_DESC, sPARAMETER_DESC );
  Commit;
   
   
END ROIC_PLS004_AM_LIST_TYPE;
/

