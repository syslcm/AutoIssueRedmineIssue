create PROCEDURE       PNL2_PLS005_UTILIZATION_TRX (
  --inCompany  in VARCHAR2,
  
  --inPC in VARCHAR2,
  --inGL in VARCHAR2,
  inPeriod in VARCHAR2
  --2008/9/17 Create to Process get Amount in Local/USD/TWD
  --Trigger by PNL2_BAD_DEPT_UPLOAD.JSP
)
AUTHID DEFINER
is
    
    CURSOR C_PNL2_UTIL is
        SELECT COMPANY_CODE,PROFIT_CENTER,COST_ELEMENT,PERIOD,SUM(NET_REVENUE) NET_REVENUE, SUM(NET_REVENUE_USD) NET_REVENUE_USD, SUM(NET_REVENUE_TWD) NET_REVENUE_TWD ,
               SUM(NET_COGS) NET_COGS  , SUM(NET_COGS_USD) NET_COGS_USD  , SUM(NET_COGS_TWD) NET_COGS_TWD   ,
               SUM(COGS_MB) COGS_MB ,SUM(COGS_MB_USD) COGS_MB_USD,SUM(COGS_MB_TWD) COGS_MB_TWD,
               SUM(COGS_LB) COGS_LB,SUM(COGS_LB_USD) COGS_LB_USD,SUM(COGS_LB_TWD) COGS_LB_TWD,
               SUM(COGS_OB) COGS_OB,SUM(COGS_OB_USD) COGS_OB_USD,SUM(COGS_OB_TWD) COGS_OB_TWD,
               SUM(NET_REVENUE),SUM(NET_COGS)
          FROM KPI_SAP001_COPA_TRX
         WHERE PERIOD = inPeriod 
           AND ( NET_REVENUE <> 0 OR NET_COGS <>  0)
           AND RELATED_PARTY <> 'Y'
          -- AND COMPANY_CODE = inCOMPANY
           --AND PROFIT_CENTER = inPC
           --AND COST_ELEMENT = inGL
           AND COST_ELEMENT IN ('0000510201','0000510301','0000510401','0000510501')
      GROUP BY COMPANY_CODE,PROFIT_CENTER,COST_ELEMENT,PERIOD
        HAVING ( SUM(NET_REVENUE) <> 0 OR SUM(NET_COGS)  <> 0 );
            

     a_TAMOUNT       KPI_SAP001_COPA_TRX.NET_REVENUE%TYPE;
     a_Rate          PNL2_UPL003_REALIZED_GM.EX_RATE_USD%TYPE;
     a_ENDCUSTOMER   KPI_SAP001_COPA_TRX.END_CUSTOMER_ID%TYPE;
     a_TOTAL_HRS     PNL2_TRX003_UN_UTILIZATION.TOTAL_HRS%TYPE;
 BEGIN
   DELETE FROM PNL2_TRX003_UN_UTILIZATION
   WHERE Period = inPeriod ;
   Commit;
   
   FOR REC1 in C_PNL2_UTIL Loop
      -- Get Total HRS
      a_TOTAL_HRS := 0;
      BEGIN 
         SELECT NVL(SUM(TOTAL_HRS),0) INTO a_TOTAL_HRS
           FROM KPI_SAP012_EXPENSE_HISTORY
          WHERE PERIOD = REC1.PERIOD
            AND COMPANY_CODE = REC1.COMPANY_CODE
            AND PROFIT_CENTER = REC1.PROFIT_CENTER
            AND TRANSACTION = 'RKL';  
         IF SQL%NOTFOUND THEN
           a_TOTAL_HRS := 0;
         END IF;
         EXCEPTION
           WHEN OTHERS THEN
             a_TOTAL_HRS := 0;
      END;
            
      a_TAMOUNT := 0;
      BEGIN 
         SELECT NVL(SUM(NET_REVENUE_TWD),0) into a_TAMOUNT
           FROM  KPI_SAP001_COPA_TRX
          WHERE PERIOD = REC1.PERIOD 
            AND PROFIT_CENTER = REC1.PROFIT_CENTER
            AND RELATED_PARTY <> 'Y';
         IF SQL%NOTFOUND THEN
             a_TAMOUNT := 0;
         END IF;
         EXCEPTION
              WHEN OTHERS THEN
                a_TAMOUNT := 0;
      END;
      
      
      IF a_TOTAL_HRS = 0 THEN  --抓不到工時分攤,PROFICE CENTER 9X的有這種狀況,全部用Revenue去分
 
        IF a_TAMOUNT = 0 THEN  --沒有營收,全部歸OTHERS ,Profit center 34即沒有營收也沒有工時
               INSERT INTO PNL2_TRX003_UN_UTILIZATION (
                  COMPANY_CODE         ,PERIOD                 ,PROFIT_CENTER       ,
                  PART_NO              ,TOTAL_HRS              ,PN_HRS              ,         
                  NET_REVENUE          ,NET_REVENUE_TWD        ,NET_REVENUE_USD     ,
                  NET_COGS             ,NET_COGS_TWD           ,NET_COGS_USD        ,
                  COGS_MB              ,COGS_MB_TWD            ,COGS_MB_USD         ,
                  COGS_LB              ,COGS_LB_TWD            ,COGS_LB_USD         ,
                  COGS_OB              ,COGS_OB_TWD            ,COGS_OB_USD         ,
                  O_NET_REVENUE        ,O_NET_COGS             ,
                  RATE                 ,COST_ELEMENT           ,END_CUSTOMER_ID ,
                  SQL_METHOD           ,CUSTOMER_RATE          ,
                  CREATE_DATE     
               ) VALUES(
                  REC1.COMPANY_CODE    ,REC1.PERIOD           ,REC1.PROFIT_CENTER    ,
                  NULL                 ,0                     ,0                     ,
                  REC1.NET_REVENUE     ,REC1.NET_REVENUE_TWD  ,REC1.NET_REVENUE_USD  ,
                  REC1.NET_COGS        ,REC1.NET_COGS_TWD     ,REC1.NET_COGS_USD     ,
                  REC1.COGS_MB         ,REC1.COGS_MB_TWD      ,REC1.COGS_MB_USD      ,
                  REC1.COGS_LB         ,REC1.COGS_LB_TWD      ,REC1.COGS_LB_USD      ,
                  REC1.COGS_OB         ,REC1.COGS_OB_TWD      ,REC1.COGS_OB_USD      ,
                  REC1.NET_REVENUE_TWD ,REC1.NET_COGS_TWD     ,
                  0                    ,REC1.COST_ELEMENT     ,'OTHERS'              ,
                  'WH=0/T_AMT=0'       ,0                     ,
                  SYSDATE
               );
               commit;
        ELSE --有營收,用END_CUSTOMER 的REVENUE去分
            PNL2_PLS005_UTILIZATION_S02_TX(REC1.COMPANY_CODE,REC1.PERIOD,REC1.PROFIT_CENTER,REC1.COST_ELEMENT,a_TAMOUNT,
                                           REC1.NET_REVENUE,REC1.NET_REVENUE_USD,REC1.NET_REVENUE_TWD,
                                           REC1.NET_COGS,REC1.NET_COGS_USD,REC1.NET_COGS_TWD,
                                           REC1.COGS_MB,REC1.COGS_MB_USD,REC1.COGS_MB_TWD,
                                           REC1.COGS_LB,REC1.COGS_LB_USD,REC1.COGS_LB_TWD,
                                           REC1.COGS_OB,REC1.COGS_OB_USD,REC1.COGS_OB_TWD);
        END IF;
        
      ELSE  --有工時,以料號來分別
      PNL2_PLS005_UTILIZATION_S01_TX(REC1.COMPANY_CODE,REC1.PERIOD,REC1.PROFIT_CENTER,REC1.COST_ELEMENT,a_TAMOUNT,a_TOTAL_HRS,
                                     REC1.NET_REVENUE,REC1.NET_REVENUE_USD,REC1.NET_REVENUE_TWD,
                                     REC1.NET_COGS,REC1.NET_COGS_USD,REC1.NET_COGS_TWD,
                                     REC1.COGS_MB,REC1.COGS_MB_USD,REC1.COGS_MB_TWD,
                                     REC1.COGS_LB,REC1.COGS_LB_USD,REC1.COGS_LB_TWD,
                                     REC1.COGS_OB,REC1.COGS_OB_USD,REC1.COGS_OB_TWD);
      END IF;
   END LOOP;
   

    
END PNL2_PLS005_UTILIZATION_TRX;
/

