create PROCEDURE PLSQL_VSF_SAP003_TRX (
  inCompany  in VARCHAR2,
  f_YYYYMMDD in VARCHAR2,
  t_YYYYMMDD in VARCHAR2
)
AUTHID DEFINER
is
	iTracePoint           integer;
	cErrorText            varchar2(500);
	cCHK_POINT1           varchar2(100);
	t_CREATE_DATE         VSF_SAP001_PBIM.CREATE_DATE%TYPE;
BEGIN
	--同site有兩筆不同 CREATE_DATE, 留最大者
	-- VSF_SAP001_PBIM & VSF_SAP003_PBED 是每次都清空重上 (直接透過 KPI_SYS005)
	-- VSF_SAP002_PBHI 需認 change date
	iTracePoint := 100;
	cCHK_POINT1 := ' ';
	select * into t_CREATE_DATE from (
		select max(CREATE_DATE) from VSF_SAP001_PBIM
		where COMPANY_CODE = inCompany and CREATE_DATE = t_YYYYMMDD
	) where rownum <= 1;

	iTracePoint := 120;
	select * into t_CREATE_DATE from (
		select max(CREATE_DATE) from VSF_SAP002_PBHI_T
		where COMPANY_CODE = inCompany and CREATE_DATE = t_YYYYMMDD
	) where rownum <= 1;

	iTracePoint := 130;
	select * into t_CREATE_DATE from (
		select max(CREATE_DATE) from VSF_SAP003_PBED
		where COMPANY_CODE = inCompany and CREATE_DATE = t_YYYYMMDD
	) where rownum <= 1;

	iTracePoint := 150;  -- VSF_SAP002_PBHI_T  move to VSF_SAP002_PBHI
	delete from VSF_SAP002_PBHI where COMPANY_CODE = inCompany
		and CHANGE_DATE >= f_YYYYMMDD;
	commit;
	iTracePoint := 155;
	insert into VSF_SAP002_PBHI
		select * from VSF_SAP002_PBHI_T
		where COMPANY_CODE = inCompany and CREATE_DATE = t_YYYYMMDD;
	commit;

	-- 清理重複資料 (ex.: 1100/000000133230)
	iTracePoint := 200;  --VSF_SAP002_PBHI
	for REC1 in (
		select COMPANY_CODE, REQMTS_POINTER, FINISH_DATE, CHANGE_DATE, CHANGE_TIME, CHANGE_USER
		from VSF_SAP002_PBHI where COMPANY_CODE = inCompany
		group by COMPANY_CODE, REQMTS_POINTER, FINISH_DATE, CHANGE_DATE, CHANGE_TIME, CHANGE_USER
		having count(*) > 1
	) loop
		cCHK_POINT1 := REC1.COMPANY_CODE || '-' || REC1.REQMTS_POINTER;
		delete from VSF_SAP002_PBHI
		where COMPANY_CODE = REC1.COMPANY_CODE and REQMTS_POINTER = REC1.REQMTS_POINTER
		and FINISH_DATE = REC1.FINISH_DATE and CHANGE_DATE = REC1.CHANGE_DATE
		and CHANGE_TIME = REC1.CHANGE_TIME and CHANGE_USER = REC1.CHANGE_USER
		and ROWID != (
			select max(ROWID) from VSF_SAP002_PBHI
			where COMPANY_CODE = REC1.COMPANY_CODE and REQMTS_POINTER = REC1.REQMTS_POINTER
			and FINISH_DATE = REC1.FINISH_DATE and CHANGE_DATE = REC1.CHANGE_DATE
			and CHANGE_TIME = REC1.CHANGE_TIME and CHANGE_USER = REC1.CHANGE_USER
		);
		commit;
	end loop;

	iTracePoint := 210;  --VSF_SAP003_PBED
	for REC1 in (
		select COMPANY_CODE, REQMTS_POINTER, FINISH_DATE
		from VSF_SAP003_PBED where COMPANY_CODE = inCompany
		group by COMPANY_CODE, REQMTS_POINTER, FINISH_DATE
		having count(*) > 1
	) loop
		cCHK_POINT1 := REC1.COMPANY_CODE || '-' || REC1.REQMTS_POINTER;
		delete from VSF_SAP003_PBED
		where COMPANY_CODE = REC1.COMPANY_CODE and REQMTS_POINTER = REC1.REQMTS_POINTER
		and FINISH_DATE = REC1.FINISH_DATE
		and ROWID != (
			select max(ROWID) from VSF_SAP003_PBED
			where COMPANY_CODE = REC1.COMPANY_CODE and REQMTS_POINTER = REC1.REQMTS_POINTER
			and FINISH_DATE = REC1.FINISH_DATE
		);
		commit;
	end loop;

	/*
	iTracePoint := 200;  --處理 VSF_TMP001_CHANGE_DATE
	insert into VSF_TMP001_CHANGE_DATE (
		COMPANY_CODE, REQMTS_POINTER, CHANGE_DATE, CHANGE_TIME
	)
	select COMPANY_CODE, REQMTS_POINTER, CHANGE_DATE, CHANGE_TIME
	from VSF_SAP002_PBHI
	where COMPANY_CODE = inCompany
	group by COMPANY_CODE, REQMTS_POINTER, CHANGE_DATE, CHANGE_TIME;

	iTracePoint := 220;  --處理 VSF_TMP002_FINISH_DATE
	insert into VSF_TMP002_FINISH_DATE (
		COMPANY_CODE, REQMTS_POINTER, FINISH_DATE
	)
	select COMPANY_CODE, REQMTS_POINTER, FINISH_DATE
	from VSF_SAP003_PBED
	where COMPANY_CODE = inCompany
	group by COMPANY_CODE, REQMTS_POINTER, FINISH_DATE;
	*/




EXCEPTION
	WHEN OTHERS THEN
		cErrorText := cCHK_POINT1 || '->' || SQLERRM();
		rollback;
		MAIL_FILE_BIDBDBADMIN(in_to_name=>'minhorng@ms.usi.com.tw',subject   => '[BI-VSF]PL/SQL PLSQL_VSF_SAP003_TRX ERROR - Company: ' || inCompany, message => '[PLSQL_VSF_SAP003_TRX], The tracepoint is  ' || to_char(iTracePoint) || ' and ErrorText=' || cErrorText);
END PLSQL_VSF_SAP003_TRX;
/

