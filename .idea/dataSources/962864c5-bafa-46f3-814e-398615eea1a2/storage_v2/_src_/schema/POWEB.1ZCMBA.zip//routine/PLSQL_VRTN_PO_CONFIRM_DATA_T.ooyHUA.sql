create PROCEDURE         "PLSQL_VRTN_PO_CONFIRM_DATA_T" (
  inCompany  in VRTN_SAP011_PO_CONFIRM_DATA.COMPANY_CODE%TYPE,
  f_YYYYMMDD in VARCHAR2,
  t_YYYYMMDD in VARCHAR2
)
is
 iTracePoint  integer ;
 cErrorText varchar2(500);

BEGIN
  iTracePoint := '000';
/*
  DELETE FROM VRTN_SAP011_PO_CONFIRM_DATA WHERE COMPANY_CODE =inCompany
     and YYYYMM >= SUBSTRB(f_YYYYMMDD,1,6)
     and YYYYMM  <= SUBSTRB(f_YYYYMMDD,1,6);

  iTracePoint := '100';
  Insert into VRTN_SAP011_PO_CONFIRM_DATA (
        COMPANY_CODE , YYYYMM , WERKS  , SITE  , EBELN ,  EBELP ,  AEDAT ,  EINDT  ,  CYCLE_TIME ,  YYYY  ,  MM,VENDOR_NO , MATGROUP,SCORE    )
   Select  COMPANY_CODE ,  YYYYMM ,  WERKS  ,  SITE  ,  EBELN ,  EBELP ,  AEDAT ,  EINDT  ,  CYCLE_TIME ,  YYYY  ,  MM ,VENDOR_NO,MATGROUP,SCORE
     from VRTN_SAP011_PO_CONFIRM_DATA_T
    where COMPANY_CODE= inCompany
      and YYYYMM  >= SUBSTRB(f_YYYYMMDD,1,6)
      and YYYYMM  <= SUBSTRB(f_YYYYMMDD,1,6);

   iTracePoint := '200';
   DELETE  from VRTN_SAP011_PO_CONFIRM_DATA_T
    where COMPANY_CODE = inCompany
      and YYYYMM  >= SUBSTRB(f_YYYYMMDD,1,6)
      and YYYYMM  <= SUBSTRB(f_YYYYMMDD,1,6)
      ;

   iTracePoint := '300';
   DELETE   FROM VRTN_MAP030_SUMMARY_GRAD WHERE  BUKRS = inCompany and  TYPE ='DE'
            AND  YYYY = SUBSTRB(f_YYYYMMDD,1,4) AND MM = SUBSTRB(f_YYYYMMDD,5,2);
*/
   iTracePoint := '400';
   EXECUTE IMMEDIATE 'INSERT INTO  VRTN_MAP030_SUMMARY_GRAD (SITE,LIFNR,MATGROUP,TYPE,YYYY,MM ,QUARTER, BUKRS , L1 , GRADE_L1 , L2 , GRADE_L2, L3 , GRADE_L3 ,L4 , GRADE_L4 )
   SELECT   SITE, vendor_no AS LIFNR ,MATGROUP, ''DE'' AS TYPE  ,yyyy, mm,''Q''||to_char(TO_DATE(YYYYMM||''01'',''YYYYMMDD''),''Q'') QUARTER, company_code as burks , ''S0'' AS L1,
     ROUND(SCORE*(SELECT percentage from VRTN_MAP020_RATE_INDEX where INDEX_KEY =''DELIVERY'' AND TYPE =''DE'' AND LEVEL_S = ''L1''),5) GRADE_L1,''D0'' AS L2,
     ROUND(SCORE*(SELECT percentage from VRTN_MAP020_RATE_INDEX where INDEX_KEY =''DELIVERY'' AND TYPE =''DE'' AND LEVEL_S = ''L2''),5) GRADE_L2,''D3'' AS L3,
  ROUND(SCORE*(SELECT percentage from VRTN_MAP020_RATE_INDEX where INDEX_KEY =''DELIVERY'' AND TYPE =''DE'' AND LEVEL_S = ''L3''),5) GRADE_L3,''DE'' AS L4,
    SCORE AS GRADE_L4  FROM (SELECT   SITE, yyyy, yyyymm, mm, vendor_no,MATGROUP,
            ROUND(avg(SCORE),5) SCORE ,COMPANY_CODE fROM VRTN_SAP011_PO_CONFIRM_DATA
        WHERE  COMPANY_CODE ='|| inCompany ||' and YYYYMM  >='|| SUBSTRB(f_YYYYMMDD,1,6) ||'
           and YYYYMM  <='|| SUBSTRB(f_YYYYMMDD,1,6) ||' GROUP BY SITE, yyyy, yyyymm, mm, vendor_no,MATGROUP,COMPANY_CODE)';


   Commit;
EXCEPTION
   When OTHERS Then
    --有錯誤產生則寄mail
    cErrorText := SQLERRM();
    MAIL_FILE_BIDBDBADMIN(in_to_name => 'shuchin_lin@usiglobal.com', subject => '[VRTN] PL/SQL VRTN_SAP011_PO_CONFIRM_DATA ERROR', message => '[VRTN_SAP011_PO_CONFIRM_DATA], The tracepoint is  ' || iTracePoint || ' and ErrorText= ' || cErrorText) ;


END PLSQL_VRTN_PO_CONFIRM_DATA_T;
/

