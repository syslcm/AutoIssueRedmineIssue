create PROCEDURE         "VQA_PLSQL_IRR_MONTHLY" AUTHID DEFINER
IS

      /*--------------------------------------------------------------*
         CREATE DATE:  2007/12/27
         PLSQL      :  VQA_PLSQL_IRR_MONTHLY
         Author     :  Susan Lin
         Purpase    :  IRR RATE(By 每月執行一次)
                       TW/SZ/SH/MX
      *---------------------------------------------------------------*
      */


 vVENDOR_CODE  VQA_010_IRR_WEEKLY.VENDOR_CODE%TYPE;
 vCompany_code VQA_010_IRR_WEEKLY.Company_code%TYPE;
 vPROCEE_YYYYMMDD varchar2(8);
 vPROCEE_YYYYMM   varchar2(6);
 iTracePoint      varchar2(100);
 cErrorText       varchar2(500);

BEGIN

 --抓上月份By系統日期
  iTracePoint := '000';
   select * into vPROCEE_YYYYMM, vPROCEE_YYYYMMDD  from (
          select trim(to_char(add_months(SYSDATE,-1), 'YYYYMM')), trim(to_char(add_months(SYSDATE,-1), 'YYYYMM')) || '01'
                 from dual
   );

 -- GET INPUT DATE
 -- vPROCEE_YYYYMM := substr(f_YYYYMMDD,1,6);
 -- vPROCEE_YYYYMMDD := f_YYYYMMDD;
 --vPROCEE_YYYYMM := '200712';
 --vPROCEE_YYYYMMDD := '20071201';

  for REC1 in ( select COMPANY_CODE, YYYY, MM, WEEK, VENDOR_CODE, PART_NO, PTYPE, REJECT_LOT_CNT, LOT_CNT, PERCENTAGE, DATE_TIME
                 from VQA_010_IRR_WEEKLY
--                 where COMPANY_CODE = inCompany
                   where YYYY =  substr(vPROCEE_YYYYMM,1,4)
                     and MM =   substr(vPROCEE_YYYYMM,5,2)
                       ) loop
    if REC1.COMPANY_CODE is not null then
      iTracePoint := '100';
      vCompany_code := REC1.Company_code;
    end if;
  end loop;

  if vCOMPANY_CODE is null then
    --若沒抓到資料則寄 error mail
    iTracePoint := '200';
    cErrorText := 'No data!';
    MAIL_FILE_BIDBDBADMIN(in_to_name => 'shuchin@ms.usi.com.tw', subject => '[VQA] PL/SQL VQA_PLSQL_IRR_MONTHLY ERROR', message => '[VQA_010_IRR_WEEKLY], The tracepoint is  ' || iTracePoint || ' and ErrorText= ' || cErrorText) ;
  else

  --清除重覆資料 VQA_020_IRR_MONTHLY
  --    DELETE FROM VQA_020_IRR_MONTHLY where COMPANY_CODE = inCompany
      DELETE FROM VQA_020_IRR_MONTHLY where YYYY =  substr(vPROCEE_YYYYMM,1,4)
                                        and MM =   substr(vPROCEE_YYYYMM,5,2);
    Commit;

    --抓 Weekly 資料放到 VQA_020_IRR_MONTHLY BY PART -Monthly
  iTracePoint := '300';
  insert into VQA_020_IRR_MONTHLY ( COMPANY_CODE, YYYY, MM, QUARTER, VENDOR_CODE, PART_NO, PTYPE, REJECT_LOT_CNT, LOT_CNT, PERCENTAGE, DATE_TIME )
    Select COMPANY_CODE, YYYY, MM, QUARTER, VENDOR_CODE, PART_NO, PTYPE, sum(REJECT_LOT_CNT), sum(LOT_CNT), (sum(REJECT_LOT_CNT) / sum(LOT_CNT) * 100 ) as PERCENTAGE, to_char(SYSDATE, 'yyyymmddhh24miss') as DATE_TIME
                 from (
     Select a.COMPANY_CODE, a.YYYY, a.MM, b.QUARTER, a.VENDOR_CODE, a.PART_NO, a.PTYPE, a.REJECT_LOT_CNT, a.LOT_CNT, a.PERCENTAGE, a.DATE_TIME
       from VQA_010_IRR_WEEKLY a, DIMENSION_DATE b
--        where a.YYYY = '2007'
--          and a.MM = '12'
--          and a.COMPANY_CODE = '1100'
--          and b.DATE_KEY = '20071201'
         where a.YYYY = substr(vPROCEE_YYYYMM,1,4)
           and a.MM = substr(vPROCEE_YYYYMM,5,2)
--         and a.COMPANY_CODE = inCompany
           and b.DATE_KEY = substr(vPROCEE_YYYYMMDD,1,8)
       ) group by COMPANY_CODE, YYYY, MM, QUARTER, VENDOR_CODE, PART_NO, PTYPE;
       commit;

  --清除重覆資料 VQA_030_IRR_MM_VENDOR
   iTracePoint := '400';
   DELETE FROM VQA_030_IRR_MM_VENDOR where YYYY =  substr(vPROCEE_YYYYMM,1,4)
                                       and MM =   substr(vPROCEE_YYYYMM,5,2);
   Commit;


  --抓 Parts 資料放到 VQA_030_IRR_MM_VENDOR  - By VENDOR -monthly
  iTracePoint := '500';
  insert into VQA_030_IRR_MM_VENDOR ( COMPANY_CODE, YYYY, MM, QUARTER, VENDOR_CODE, GV_VENDOR, PTYPE, REJECT_LOT_CNT, LOT_CNT, PERCENTAGE, DATE_TIME )
    Select COMPANY_CODE, YYYY, MM, QUARTER, VENDOR_CODE, GLOBAL_VENDOR_CODE as GV_VENDOR, PTYPE, sum(REJECT_LOT_CNT) as REJECT_LOT_CNT, sum(LOT_CNT) as LOT_CNT, round((sum(REJECT_LOT_CNT) / sum(LOT_CNT) * 100),2 ) as PERCENTAGE, to_char(SYSDATE, 'yyyymmddhh24miss') as DATE_TIME
       from (
     Select a.COMPANY_CODE, a.YYYY, a.MM, b.QUARTER, a.VENDOR_CODE, c.GLOBAL_VENDOR_CODE, a.PART_NO, a.PTYPE, a.REJECT_LOT_CNT, a.LOT_CNT, a.PERCENTAGE, a.DATE_TIME
       from VQA_020_IRR_MONTHLY a, DIMENSION_DATE b, GVM032_GLOBAL_VENDOR_ITEM c
         where a.YYYY = substr(vPROCEE_YYYYMM,1,4)
           and a.MM = substr(vPROCEE_YYYYMM,5,2)
           and a.COMPANY_CODE = c.COMPANY_CODE
           and a.VENDOR_CODE = c.SAP_VENDOR_CODE
           and b.DATE_KEY = substr(vPROCEE_YYYYMMDD,1,8)
   ) group by COMPANY_CODE, YYYY, MM, QUARTER, VENDOR_CODE, GLOBAL_VENDOR_CODE, PTYPE;
   commit;


  --清除重覆資料 VQA_040_IRR_MM_GLOBAL
   iTracePoint := '600';
   DELETE FROM VQA_040_IRR_MM_GLOBAL where YYYY =  substr(vPROCEE_YYYYMM,1,4)
                                       and MM =   substr(vPROCEE_YYYYMM,5,2);
   Commit;


  --抓 Vendor 資料放到 VQA_040_IRR_MM_GLOBAL - By GV_VENDOR -monthly
  iTracePoint := '700';
  insert into VQA_040_IRR_MM_GLOBAL ( YYYY, MM, QUARTER, GV_VENDOR, PTYPE, REJECT_LOT_CNT, LOT_CNT, PERCENTAGE, DATE_TIME )
    Select YYYY, MM, QUARTER, GV_VENDOR, PTYPE, sum(REJECT_LOT_CNT) as REJECT_LOT_CNT, sum(LOT_CNT) as LOT_CNT, round((sum(REJECT_LOT_CNT) / sum(LOT_CNT) * 100),2 ) as PERCENTAGE, to_char(SYSDATE, 'yyyymmddhh24miss') as DATE_TIME
       from (
     Select a.COMPANY_CODE, a.YYYY, a.MM, a.QUARTER, a.VENDOR_CODE, a.GV_VENDOR, a.PTYPE, a.REJECT_LOT_CNT, a.LOT_CNT, a.PERCENTAGE, a.DATE_TIME
       from VQA_030_IRR_MM_VENDOR a
         where a.YYYY = substr(vPROCEE_YYYYMM,1,4)
           and a.MM = substr(vPROCEE_YYYYMM,5,2)
   ) group by YYYY, MM, QUARTER, GV_VENDOR, PTYPE;
   commit;



  end if;






EXCEPTION
   When OTHERS Then
    --有錯誤產生則寄mail
    cErrorText := SQLERRM();
    MAIL_FILE_BIDBDBADMIN(in_to_name => 'shuchin_lin@usiglobal.com', subject => '[VQA] PL/SQL VQA_PLSQL_IRR_MONTHLY ERROR', message => '[VQA_020_IRR_MONTHLY ], The tracepoint is  ' || iTracePoint || ' and ErrorText= ' || cErrorText) ;

END VQA_PLSQL_IRR_MONTHLY;
/

