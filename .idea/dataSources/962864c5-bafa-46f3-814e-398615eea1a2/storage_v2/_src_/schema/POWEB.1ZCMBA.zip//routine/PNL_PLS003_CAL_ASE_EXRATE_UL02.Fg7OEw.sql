create PROCEDURE PNL_PLS003_CAL_ASE_EXRATE_UL02 (
  sKEYIN_YYMM in PNL_UPL002_BG_FORECAST.KEYIN_YYMM%TYPE,
  sPROFIT_CENTER in PNL_UPL002_BG_FORECAST.PROFIT_CENTER%TYPE,
  sCOMPANY_CODE in PNL_UPL002_BG_FORECAST.COMPANY_CODE%TYPE
)
AUTHID DEFINER
/*********************************************************************
  ACTION       : Revenue Forecast 使用 ASE (RWF_MAP003_ASE_EX_RATE) 匯率 FOR TABLE PNL_UPL002_BG_FORECAST
  Author       : KANGI
  Date         : 2014/07/10
  OA           :  SAI045958
**********************************************************************/
/*********************************************************************
  ACTION       : 上傳格式改為 USD
  Author       : KANGI
  Date         : 20141229
  OA           :  SAI049288
**********************************************************************/
is
   --處理 (周別) PNL_UPL002_BG_FORECAST
   CURSOR PNL_UPL002_CUR is
   SELECT YYYY,MONTH FROM PNL_UPL002_BG_FORECAST
    WHERE KEYIN_YYMM = sKEYIN_YYMM
      AND PROFIT_CENTER = sPROFIT_CENTER
      AND COMPANY_CODE = sCOMPANY_CODE
   GROUP BY YYYY,MONTH  ;

   sORG_CURRENCY   RWF_MAP003_ASE_EX_RATE.FROM_CURRENCY%TYPE ;
   nTO_USD_RATE    RWF_MAP003_ASE_EX_RATE.TO_USD_RATE%TYPE ;
   nTO_CNY_RATE    RWF_MAP003_ASE_EX_RATE.TO_CNY_RATE%TYPE ;
   nTO_TWD_RATE    RWF_MAP003_ASE_EX_RATE.TO_TWD_RATE%TYPE ;
   sBDATE          RWF_MAP003_ASE_EX_RATE.BDATE%TYPE ;
   iTracePoint  integer ;
   cErrorText varchar2(500) ;
 BEGIN
  iTracePoint := 100 ;
  --Modify kangi 20141229
  --sORG_CURRENCY := 'CNY' ; Remark kangi 20141229
   sORG_CURRENCY := 'USD' ;
  --End Modify kangi 20141229

  iTracePoint := 200 ;


  iTracePoint := 300 ;
  --GET 最大的 sBDATE FROM RWF_MAP003_ASE_EX_RATE
  sBDATE := NULL ;
  BEGIN
      iTracePoint := 400 ;
      SELECT MAX(BDATE) INTO sBDATE FROM RWF_MAP003_ASE_EX_RATE ;
      iTracePoint := 500 ;
      EXCEPTION
          WHEN OTHERS THEN
          NULL  ;
  END ;
  iTracePoint := 600 ;
  IF sBDATE IS NOT NULL THEN
     iTracePoint := 700 ;
     FOR PNL_UPL002_REC in PNL_UPL002_CUR LOOP
         iTracePoint := 800 ;
         nTO_USD_RATE := 0 ;
         nTO_TWD_RATE := 0 ;
         nTO_CNY_RATE := 0 ;
         iTracePoint := 900 ;
         BEGIN
            iTracePoint := 400 ;
            SELECT TO_USD_RATE,TO_CNY_RATE,TO_TWD_RATE
              INTO nTO_USD_RATE,nTO_CNY_RATE,nTO_TWD_RATE
              FROM RWF_MAP003_ASE_EX_RATE
             WHERE FROM_CURRENCY = sORG_CURRENCY
               AND PERIOD = ( SELECT MAX(PERIOD) FROM RWF_MAP003_ASE_EX_RATE WHERE PERIOD <= PNL_UPL002_REC.YYYY||PNL_UPL002_REC.MONTH AND BDATE = sBDATE )
               AND BDATE = sBDATE  ;
            iTracePoint := 1000 ;
                  EXCEPTION
                  WHEN OTHERS THEN
                     iTracePoint := 1100 ;
                     NULL  ;
         END ;
         iTracePoint := 1200 ;

         IF nTO_TWD_RATE <> 0 THEN
            iTracePoint := 1300 ;
            --更新PNL_UPL002_BG_FORECAST BY sKEYIN_YYMM,sPROFIT_CENTER,sCOMPANY_CODE
            BEGIN
              UPDATE PNL_UPL002_BG_FORECAST
              SET AMOUNT_USD = AMOUNT * nTO_USD_RATE ,
                  AMOUNT_TWD = AMOUNT * nTO_TWD_RATE ,
                  AMOUNT_CNY = AMOUNT * nTO_CNY_RATE ,
                  EX_RATE_USD = nTO_USD_RATE,
                  EX_RATE_TWD = nTO_TWD_RATE,
                  EX_RATE_CNY = nTO_CNY_RATE
              WHERE KEYIN_YYMM = sKEYIN_YYMM
                AND PROFIT_CENTER = sPROFIT_CENTER
                AND COMPANY_CODE = sCOMPANY_CODE
                AND YYYY = PNL_UPL002_REC.YYYY
                AND MONTH = PNL_UPL002_REC.MONTH ;
              iTracePoint := 1400 ;
              EXCEPTION
              WHEN OTHERS THEN
              iTracePoint := 1500 ;
              NULL  ;
            END ;
         END IF;
         iTracePoint := 1600 ;
     END LOOP ;
     iTracePoint := 1700 ;
  END IF;
  --COMMIT ;
  iTracePoint := 1800 ;
 EXCEPTION
     WHEN OTHERS THEN
            --rollback ;
            cErrorText := SQLERRM() ;
            MAIL_FILE_BIDBDBADMIN(in_to_name=>'kangi@ms.usi.com.tw',subject   => 'PL/SQL PNL_PLS003_CAL_ASE_EXRATE_UL02 ERROR', message => '[PNL_PLS003_CAL_ASE_EXRATE_UL02], The tracepoint is  ' || to_char(iTracePoint) || 'and ErrorText=' || cErrorText) ;
            DBMS_OUTPUT.PUT_LINE(SUBSTR(cErrorText,1,255));
            DBMS_OUTPUT.PUT_LINE(TO_CHAR(iTracePoint));
END PNL_PLS003_CAL_ASE_EXRATE_UL02;
/

