create PROCEDURE       ROA_PLS001_CO_MONTHLY_RPT (
/* ********************************************************************
  PROG-ID      : ROA_SAP001_CO_MONTHLY_RPT
  PROG-ACTION  : 
  Author       : Asan Chang
  Date         : 2017/03/21
  OA Number    : SAI069417
*********************************************************************

********************************************************************* */
   incompany    IN   VARCHAR2,
   f_yyyymmdd   IN   VARCHAR2,
   t_yyyymmdd   IN   VARCHAR2
)
AUTHID DEFINER
IS
   CURSOR ROA_SAP001_CO_MONTHLY_RPT_t
   IS
      SELECT COMPANY_CODE, PERIOD, COST_CENTER, WO, PERIO, ACCT_549901H, 
      ACCT_559901H, ACCT_559906H, ACCT_559907H, ACCT_549901, ACCT_559901,
      ACCT_559906, ACCT_559907, LH, MH, OHLH, OHMH, LH_AMT, MH_AMT, OHLH_AMT,
      OHMH_AMT, V11, V12, V13, V14, LHA, MHA, OHLHA, OHMHA, R11, R12 ,R13, R14,
      V21, V22, V23, V24, TEXT, PN, PC , ROA_PD, ROA_PC, PD
                  

      FROM ROA_SAP001_CO_MONTHLY_RPT_t
      where COMPANY_CODE = incompany;


   itracepoint   INTEGER;
BEGIN
     --(1)清除舊資料
     DELETE FROM ROA_SAP001_CO_MONTHLY_RPT
     where PERIOD IN  (SELECT PERIOD FROM ROA_SAP001_CO_MONTHLY_RPT_t )
     AND   COMPANY_CODE = incompany;
     COMMIT;  


   FOR REC1 IN ROA_SAP001_CO_MONTHLY_RPT_t LOOP
    
   
   
   --(2)開始處理資料
       INSERT INTO ROA_SAP001_CO_MONTHLY_RPT (
            COMPANY_CODE,        PERIOD,              COST_CENTER,                  WO,            
            PERIO,               ACCT_549901H,        ACCT_559901H,                 ACCT_559906H, 
            ACCT_559907H,        ACCT_549901,         ACCT_559901,                  ACCT_559906, 
            ACCT_559907,         LH,                  MH,                           OHLH, 
            OHMH,                LH_AMT,              MH_AMT,                       OHLH_AMT,
            OHMH_AMT,            V11,                 V12,                          V13, 
            V14,                 LHA,                 MHA,                          OHLHA, 
            OHMHA,               R11,                 R12 ,                         R13, 
            R14,                 V21,                 V22,                          V23, 
            V24,                 TEXT,                PN,                           PC,
            ROA_PD,              ROA_PC,              PD
            ) VALUES (
                 
            REC1.COMPANY_CODE,   REC1.PERIOD,         REC1.COST_CENTER,             REC1.WO,            
            REC1.PERIO,          REC1.ACCT_549901H,   REC1.ACCT_559901H,            REC1.ACCT_559906H, 
            REC1.ACCT_559907H,   REC1.ACCT_549901,    REC1.ACCT_559901,             REC1.ACCT_559906, 
            REC1.ACCT_559907,    REC1.LH,             REC1.MH,                      REC1.OHLH, 
            REC1.OHMH,           REC1.LH_AMT,         REC1.MH_AMT,                  REC1.OHLH_AMT,
            REC1.OHMH_AMT,       REC1.V11,            REC1.V12,                     REC1.V13, 
            REC1.V14,            REC1.LHA,            REC1.MHA,                     REC1.OHLHA, 
            REC1.OHMHA,          REC1.R11,            REC1.R12 ,                    REC1.R13, 
            REC1.R14,            REC1.V21,            REC1.V22,                     REC1.V23, 
            REC1.V24,            REC1.TEXT,           REC1.PN,                      REC1.PC,
            REC1.ROA_PD,         REC1.ROA_PC,         REC1.PD         
             );    
       COMMIT;

   END LOOP;

   --(3) 刪除資料
   DELETE FROM ROA_SAP001_CO_MONTHLY_RPT_t
   where COMPANY_CODE = incompany;
   COMMIT;


END ROA_PLS001_CO_MONTHLY_RPT;
/

