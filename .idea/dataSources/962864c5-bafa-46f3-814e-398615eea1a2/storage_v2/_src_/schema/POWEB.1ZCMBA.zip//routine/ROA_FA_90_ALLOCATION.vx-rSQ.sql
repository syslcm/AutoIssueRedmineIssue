create PROCEDURE       "ROA_FA_90_ALLOCATION" (
  f_YYYYMM  in VARCHAR2
  --,inCompany in VARCHAR2
)
AUTHID DEFINER
/* ****************************************************************************************
  PROG-ID      : ROA_FA_90_ALLOCATION
  PROG-ACTION  :   
  Author       : Asan Chang
  Date         : 2016/07/15
  OA No.       : SAI062303
 ========================================================================================== 
 2016/07/18 SAI062303 Asan Chang (1)所有site一起執行 (2)先換成台幣再算ratio
 ========================================================================================== 
 2016/07/21 SAI062303 Asan Chang 1700,1100 計算分攤時，不可以用兩個加總的去計算allocation,要用各自的 
 ========================================================================================== 
 2016/07/22 SAI062303 Asan Chang company_code = 2200 , 若只有90 且 沒有其 PC, 
 則直接分攤給 30, 否則用原來的分攤原則.
 *************************************************************************************/
is
   iReccnt              integer;
   YY_1                 DIMENSION_DATE.YYYY%TYPE;
   MM_1                 DIMENSION_DATE.MM%TYPE; 
   L_PERIOD             DIMENSION_DATE.YYYYMM%TYPE;
   L_ALLOCATION_PC      ROA_UPL001_FIXED_ASSETS.PC%TYPE;
   L_CNT                NUMBER(6);
   iTracePoint          integer ; 
   inCompany            ROA_UPL001_FIXED_ASSETS.COMPANY_CODE%TYPE;
   /*
   L_COMPANY_CODE      ROA_UPL001_FIXED_ASSETS.PC%TYPE;
   L_TYPE              ROA_UPL001_FIXED_ASSETS.TYPE%TYPE;
   L_S_SEQ             ROA_UPL001_FIXED_ASSETS.S_SEQ%TYPE;
   L_PC                ROA_UPL001_FIXED_ASSETS.PC%TYPE;
   L_UPL_AMT_LOC       NUMBER(15,5);
   L_UPL_AMT_TWD       NUMBER(15,5);
   L_UPL_AMT_USD       NUMBER(15,5);
   L_UPL_AMT_CNY       NUMBER(15,5);       
   L_ALOC_AMT_LOC      NUMBER(15,5); 
   L_ALOC_AMT_TWD      NUMBER(15,5); 
   L_ALOC_AMT_USD      NUMBER(15,5); 
   L_ALOC_AMT_CNY      NUMBER(15,5);    
   L_AFTER_AMT_LOC     NUMBER(15,5); 
   L_AFTER_AMT_TWD     NUMBER(15,5); 
   L_AFTER_AMT_USD     NUMBER(15,5); 
   L_AFTER_AMT_CNY     NUMBER(15,5);     
   L_ALOC_RATIO        NUMBER(13,10);
   L_EX_RATE_TWD       NUMBER(15,5); 
   L_EX_RATE_USD       NUMBER(15,5); 
   L_EX_RATE_CNY       NUMBER(15,5);  */
   
  
BEGIN
--
  YY_1 := SUBSTR( f_YYYYMM, 1, 4);
  MM_1 := SUBSTR( f_YYYYMM, 5, 2);
  L_PERIOD := YY_1 || MM_1;
  L_ALLOCATION_PC := '0000000090';  
  for REC2 IN (
  SELECT COMPANY_CODE FROM ROA_UPL001_FIXED_ASSETS
  GROUP BY COMPANY_CODE
  ORDER BY COMPANY_CODE  
  )
  LOOP
     inCompany :=  REC2.COMPANY_CODE;

--
/* ****************************************************************************************
  1100,1700 一起分攤
************************************************************************************ */
    IF inCompany IN ('1700','1100') THEN 
      iTracePoint := 100 ;  
      for REC1 IN (
      SELECT A.COMPANY_CODE, A.PERIOD,A.TYPE, A.S_SEQ, A.PC, A.UPL_AMT_LOC,
      A.EX_RATE_TWD, A.EX_RATE_USD,A.EX_RATE_CNY , B.TOTAL, C.ALLOCATION_PC
      --,DECODE(B.TOTAL,0,0, (A.UPL_AMT_LOC / B.TOTAL ))
      ,DECODE(PC,L_ALLOCATION_PC,-1,DECODE(B.TOTAL,0,0, (A.UPL_AMT_LOC / B.TOTAL )) )  AS ALOC_RATIO
      ,DECODE(PC,L_ALLOCATION_PC,-1,DECODE(B.TOTAL,0,0, (A.UPL_AMT_LOC / B.TOTAL )) ) * C.ALLOCATION_PC AS ALOC_AMT_LOC
      FROM ROA_UPL001_FIXED_ASSETS A ,
      ( SELECT S_SEQ, TYPE, sum(UPL_AMT_LOC) AS TOTAL
      FROM ROA_UPL001_FIXED_ASSETS
      where PC <> L_ALLOCATION_PC and company_code IN ('1700','1100') and period = f_YYYYMM
      GROUP BY S_SEQ, TYPE
      ORDER BY S_SEQ, TYPE ) B ,
      ( SELECT S_SEQ, TYPE, sum(UPL_AMT_LOC) AS ALLOCATION_PC
      FROM ROA_UPL001_FIXED_ASSETS
      where PC = L_ALLOCATION_PC and company_code IN ('1700','1100') and period = f_YYYYMM
      GROUP BY S_SEQ, TYPE
      ORDER BY S_SEQ, TYPE ) C
      where A.COMPANY_CODE IN ('1700','1100')
      AND A.PERIOD = f_YYYYMM
      AND A.S_SEQ = B.S_SEQ AND B.S_SEQ = C.S_SEQ
      AND A.TYPE = B.TYPE AND B.TYPE = C.TYPE
      )   
--     
      LOOP
        iTracePoint := 200 ;
        if REC1.PC <> L_ALLOCATION_PC THEN
          UPDATE ROA_UPL001_FIXED_ASSETS A
          SET A.UPL_AMT_TWD = ( REC1.UPL_AMT_LOC * REC1.EX_RATE_TWD ) , 
              A.UPL_AMT_USD = ( REC1.UPL_AMT_LOC * REC1.EX_RATE_USD ) , 
              A.UPL_AMT_CNY = ( REC1.UPL_AMT_LOC * REC1.EX_RATE_CNY ) , 
              A.ALOC_AMT_LOC = REC1.ALOC_AMT_LOC,
              A.ALOC_AMT_TWD = ( REC1.ALOC_AMT_LOC * REC1.EX_RATE_TWD ) ,
              A.ALOC_AMT_USD = ( REC1.ALOC_AMT_LOC * REC1.EX_RATE_USD ) ,
              A.ALOC_AMT_CNY = ( REC1.ALOC_AMT_LOC * REC1.EX_RATE_CNY ) ,
              A.ALOC_RATIO = REC1.ALOC_RATIO,             
              A.AFTER_AMT_LOC = ( REC1.UPL_AMT_LOC + REC1.ALOC_AMT_LOC ) ,
              A.AFTER_AMT_TWD = ( REC1.UPL_AMT_LOC + REC1.ALOC_AMT_LOC ) * REC1.EX_RATE_TWD ,
              A.AFTER_AMT_USD = ( REC1.UPL_AMT_LOC + REC1.ALOC_AMT_LOC ) * REC1.EX_RATE_USD ,
              A.AFTER_AMT_CNY = ( REC1.UPL_AMT_LOC + REC1.ALOC_AMT_LOC ) * REC1.EX_RATE_CNY ,
              A.MODIFY_DATE  = SYSDATE            
          WHERE A.COMPANY_CODE = REC1.COMPANY_CODE
          AND A.PERIOD   = REC1.PERIOD
          AND A.S_SEQ    = REC1.S_SEQ
          AND A.TYPE     = REC1.TYPE
          AND A.PC       = REC1.PC ;
        else
          UPDATE ROA_UPL001_FIXED_ASSETS A
          SET A.UPL_AMT_TWD = ( REC1.UPL_AMT_LOC * REC1.EX_RATE_TWD ) , 
              A.UPL_AMT_USD = ( REC1.UPL_AMT_LOC * REC1.EX_RATE_USD ) , 
              A.UPL_AMT_CNY = ( REC1.UPL_AMT_LOC * REC1.EX_RATE_CNY ) , 
              A.ALOC_AMT_LOC = ( REC1.UPL_AMT_LOC * -1 ),
              A.ALOC_AMT_TWD = ( ( REC1.UPL_AMT_LOC * -1 ) * REC1.EX_RATE_TWD ) ,
              A.ALOC_AMT_USD = ( ( REC1.UPL_AMT_LOC * -1 ) * REC1.EX_RATE_USD ) ,
              A.ALOC_AMT_CNY = ( ( REC1.UPL_AMT_LOC * -1 ) * REC1.EX_RATE_CNY ) ,
              A.ALOC_RATIO = REC1.ALOC_RATIO,             
              A.AFTER_AMT_LOC = 0 ,
              A.AFTER_AMT_TWD = 0 ,
              A.AFTER_AMT_USD = 0 ,
              A.AFTER_AMT_CNY = 0 ,
              A.MODIFY_DATE  = SYSDATE            
          WHERE A.COMPANY_CODE = REC1.COMPANY_CODE
          AND A.PERIOD   = REC1.PERIOD
          AND A.S_SEQ    = REC1.S_SEQ
          AND A.TYPE     = REC1.TYPE
          AND A.PC       = REC1.PC ;       
        END IF;
        
        iTracePoint := 300 ;
        COMMIT ;         
         
      END LOOP; 




    ELSE
-- -------------------------------------------------------------------------------
    /* 判斷 PC=90 有無金額 */
-- -------------------------------------------------------------------------------
      SELECT COUNT(*) INTO L_CNT 
      FROM  ROA_UPL001_FIXED_ASSETS
      WHERE PERIOD = f_YYYYMM AND COMPANY_CODE = inCompany 
      AND PC = L_ALLOCATION_PC AND UPL_AMT_LOC > 0;
       
      IF L_CNT > 0 THEN
-- -------------------------------------------------------------------------------
     /* (1)PC=90 有金額 */
-- -------------------------------------------------------------------------------      
--     
        iTracePoint := 400 ;
        /*****************************************************************************************
           ROAROE 分攤時, 若為CA 2200, 若只有90 且 沒有其 PC, 則直接分攤給 30, 否則用原分攤原則.
        *************************************************************************************/
      
        SELECT COUNT(*) INTO L_CNT  -- 判斷非90的PC有無金額
        FROM  ROA_UPL001_FIXED_ASSETS
        WHERE PERIOD = f_YYYYMM AND COMPANY_CODE = inCompany 
        AND PC <> L_ALLOCATION_PC AND UPL_AMT_LOC > 0;        
        
                         
        --先換成台幣再換算
        for REC1 IN (
        SELECT A.COMPANY_CODE, A.PERIOD,A.TYPE, A.S_SEQ, A.PC, A.UPL_AMT_LOC,
        A.EX_RATE_TWD, A.EX_RATE_USD,A.EX_RATE_CNY,   
        --DECODE(B.TOTAL,0,0, (A.UPL_AMT_LOC / B.TOTAL )) 
        --DECODE(B.TOTAL,0,0, ((A.UPL_AMT_LOC*A.EX_RATE_TWD) / (B.TOTAL*A.EX_RATE_TWD) )) 
        DECODE(PC,L_ALLOCATION_PC,-1,(DECODE(B.TOTAL,0,0, ((A.UPL_AMT_LOC*A.EX_RATE_TWD) / (B.TOTAL*A.EX_RATE_TWD) ))  ) )  AS ALOC_RATIO ,    
        --DECODE(PC,L_ALLOCATION_PC,-1,((A.UPL_AMT_LOC*A.EX_RATE_TWD) / (B.TOTAL*A.EX_RATE_TWD) ) )  AS ALOC_RATIO ,
        DECODE(PC,L_ALLOCATION_PC,-1,(DECODE(B.TOTAL,0,0, (A.UPL_AMT_LOC / B.TOTAL )) ) ) * (C.ALLOCATION_PC) AS ALOC_AMT_LOC
        ,C.ALLOCATION_PC
     
        FROM ROA_UPL001_FIXED_ASSETS A ,
        ( SELECT S_SEQ, TYPE, sum(UPL_AMT_LOC) AS TOTAL
        FROM ROA_UPL001_FIXED_ASSETS
        where PC <> L_ALLOCATION_PC and company_code = inCompany and period = f_YYYYMM
        GROUP BY S_SEQ, TYPE
        ORDER BY S_SEQ, TYPE ) B ,
        ( SELECT S_SEQ, TYPE, sum(UPL_AMT_LOC) AS ALLOCATION_PC
        FROM ROA_UPL001_FIXED_ASSETS
        where PC = L_ALLOCATION_PC and company_code = inCompany and period = f_YYYYMM
        GROUP BY S_SEQ, TYPE
        ORDER BY S_SEQ, TYPE ) C
        where A.COMPANY_CODE = inCompany 
        AND A.PERIOD = f_YYYYMM  
        AND A.S_SEQ = B.S_SEQ AND B.S_SEQ = C.S_SEQ
        AND A.TYPE = B.TYPE AND B.TYPE = C.TYPE    
        )   
--     
        LOOP
          iTracePoint := 500 ;
          
        if inCompany IN ('2200') AND L_CNT = 0 AND REC1.PC= '0000000030' AND REC1.ALLOCATION_PC > 0 THEN 
        --90直接攤給30 
          UPDATE ROA_UPL001_FIXED_ASSETS A
          SET A.UPL_AMT_TWD = 0 , 
              A.UPL_AMT_USD = 0 , 
              A.UPL_AMT_CNY = 0 , 
              A.ALOC_AMT_LOC = REC1.ALLOCATION_PC,
              A.ALOC_AMT_TWD = ( REC1.ALLOCATION_PC * REC1.EX_RATE_TWD ) ,
              A.ALOC_AMT_USD = ( REC1.ALLOCATION_PC * REC1.EX_RATE_USD ) ,
              A.ALOC_AMT_CNY = ( REC1.ALLOCATION_PC * REC1.EX_RATE_CNY ) ,
              A.ALOC_RATIO = 1,             
              A.AFTER_AMT_LOC = ( REC1.ALLOCATION_PC ) ,
              A.AFTER_AMT_TWD = ( REC1.ALLOCATION_PC ) * REC1.EX_RATE_TWD ,
              A.AFTER_AMT_USD = ( REC1.ALLOCATION_PC ) * REC1.EX_RATE_USD ,
              A.AFTER_AMT_CNY = ( REC1.ALLOCATION_PC ) * REC1.EX_RATE_CNY ,
              A.MODIFY_DATE  = SYSDATE            
          WHERE A.COMPANY_CODE = REC1.COMPANY_CODE
          AND A.PERIOD   = REC1.PERIOD
          AND A.S_SEQ    = REC1.S_SEQ
          AND A.TYPE     = REC1.TYPE
          AND A.PC       = REC1.PC ;

          iTracePoint := 600 ;
          COMMIT ;         
        else
          UPDATE ROA_UPL001_FIXED_ASSETS A
          SET A.UPL_AMT_TWD = ( REC1.UPL_AMT_LOC * REC1.EX_RATE_TWD ) , 
              A.UPL_AMT_USD = ( REC1.UPL_AMT_LOC * REC1.EX_RATE_USD ) , 
              A.UPL_AMT_CNY = ( REC1.UPL_AMT_LOC * REC1.EX_RATE_CNY ) , 
              A.ALOC_AMT_LOC = REC1.ALOC_AMT_LOC,
              A.ALOC_AMT_TWD = ( REC1.ALOC_AMT_LOC * REC1.EX_RATE_TWD ) ,
              A.ALOC_AMT_USD = ( REC1.ALOC_AMT_LOC * REC1.EX_RATE_USD ) ,
              A.ALOC_AMT_CNY = ( REC1.ALOC_AMT_LOC * REC1.EX_RATE_CNY ) ,
              A.ALOC_RATIO = REC1.ALOC_RATIO,             
              A.AFTER_AMT_LOC = ( REC1.UPL_AMT_LOC + REC1.ALOC_AMT_LOC ) ,
              A.AFTER_AMT_TWD = ( REC1.UPL_AMT_LOC + REC1.ALOC_AMT_LOC ) * REC1.EX_RATE_TWD ,
              A.AFTER_AMT_USD = ( REC1.UPL_AMT_LOC + REC1.ALOC_AMT_LOC ) * REC1.EX_RATE_USD ,
              A.AFTER_AMT_CNY = ( REC1.UPL_AMT_LOC + REC1.ALOC_AMT_LOC ) * REC1.EX_RATE_CNY ,
              A.MODIFY_DATE  = SYSDATE            
          WHERE A.COMPANY_CODE = REC1.COMPANY_CODE
          AND A.PERIOD   = REC1.PERIOD
          AND A.S_SEQ    = REC1.S_SEQ
          AND A.TYPE     = REC1.TYPE
          AND A.PC       = REC1.PC ;

          iTracePoint := 600 ;
          COMMIT ;        
        END IF;
  
        END LOOP; 
      ELSE
 -- -------------------------------------------------------------------------------
     /* (2)PC=90 no 金額 */
-- -------------------------------------------------------------------------------     
        iTracePoint := 700 ;
       
        for REC1 IN ( 
        SELECT A.COMPANY_CODE,  A.PERIOD ,A.TYPE, A.S_SEQ, A.PC, A.UPL_AMT_LOC, A.EX_RATE_TWD, A.EX_RATE_USD, A.EX_RATE_CNY 
        --INTO   L_COMPANY_CODE, L_TYPE, L_S_SEQ, L_PC, L_UPL_AMT_LOC, L_EX_RATE_TWD, L_EX_RATE_USD, L_EX_RATE_CNY
        FROM ROA_UPL001_FIXED_ASSETS A
        where A.COMPANY_CODE = inCompany 
        AND A.PERIOD = f_YYYYMM 
        )
        LOOP
       
          iTracePoint := 800 ;
          UPDATE ROA_UPL001_FIXED_ASSETS A
          SET A.UPL_AMT_TWD = ( REC1.UPL_AMT_LOC * REC1.EX_RATE_TWD ) , 
              A.UPL_AMT_USD = ( REC1.UPL_AMT_LOC * REC1.EX_RATE_USD ) , 
              A.UPL_AMT_CNY = ( REC1.UPL_AMT_LOC * REC1.EX_RATE_CNY ) , 
              A.ALOC_AMT_LOC = 0,
              A.ALOC_AMT_TWD = 0 ,
              A.ALOC_AMT_USD = 0 ,
              A.ALOC_AMT_CNY = 0 ,
              A.ALOC_RATIO = 0,             
              A.AFTER_AMT_LOC = ( REC1.UPL_AMT_LOC + 0) ,
              A.AFTER_AMT_TWD = ( REC1.UPL_AMT_LOC + 0 ) * REC1.EX_RATE_TWD ,
              A.AFTER_AMT_USD = ( REC1.UPL_AMT_LOC + 0 ) * REC1.EX_RATE_USD ,
              A.AFTER_AMT_CNY = ( REC1.UPL_AMT_LOC + 0 ) * REC1.EX_RATE_CNY ,
              A.MODIFY_DATE  = SYSDATE            
          WHERE A.COMPANY_CODE = REC1.COMPANY_CODE
          AND A.PERIOD   = REC1.PERIOD
          AND A.S_SEQ    = REC1.S_SEQ
          AND A.TYPE     = REC1.TYPE
          AND A.PC       = REC1.PC ; 

          iTracePoint := 900 ;
          COMMIT ; 
        END LOOP;      
      END IF;
    END IF;
  END LOOP;

END ROA_FA_90_ALLOCATION;
/

