create PROCEDURE "VRT_PLSQL_COMPLIANCE_WEEK" (
 inCompany  in VRT_SAP006_COMPLIANCE_WEEK_T.COMPANY_CODE%TYPE,
 f_YYYYMMDD in VARCHAR2,
 t_YYYYMMDD in VARCHAR2
)
IS

    /*
     每週執行一次
     1. 抓 VRT_SAP006_COMPLIANCE_WEEK_T 資料
     2. Insert to VRT_ZOT004_COMPLIANCE_WEEK table
         By Susan 2006/10/03
    */

 vVENDOR_CODE   VRT_SAP006_COMPLIANCE_WEEK_T.VENDOR_CODE%TYPE;
 vCompany_code  VRT_SAP006_COMPLIANCE_WEEK_T.Company_code%TYPE;
 vSITE          VRT_SAP006_COMPLIANCE_WEEK_T.SITE%TYPE;
 vPROCEE_YYYYMMDD varchar2(8);
 vPROCEE_YYYYMM   varchar2(6);
 iTracePoint      varchar2(100);
 cErrorText       varchar2(500);

BEGIN

  --抓當月份系統日期
  iTracePoint := '100';
  --vPROCEE_YYYYMM := TO_CHAR(ADD_MONTHS(SYSDATE, -1), 'YYYYMM');
  vPROCEE_YYYYMMDD  :=  to_char(sysdate,'YYYYMMDD');
  vPROCEE_YYYYMM :=  SUBSTRB(vPROCEE_YYYYMMDD,1,6);


  for REC1 in ( select P_YEAR, P_MONTH, P_WEEK, P_QUARTER, COMPANY_CODE, SITE, VENDOR_CODE, PTYPE, SCORES, COMPLIANCE_CNT, TOTAL_4A4_CNT, DATE_TIME
                 from VRT_SAP006_COMPLIANCE_WEEK_T
                 where COMPANY_CODE = inCompany and
                       p_week in (Select substrb(yyyyww,5,2) from DIMENSION_DATE Where date_key = to_char( sysdate - 7, 'yyyymmdd'))
                       ) loop
    if REC1.COMPANY_CODE is not null then
      iTracePoint := '110';
      vCompany_code := REC1.Company_code;
          vSITE := REC1.SITE;
    end if;
  end loop;

  if vCOMPANY_CODE is null then
    --若沒抓到資料則寄 error mail
    iTracePoint := '450';
    cErrorText := 'No data!';
    MAIL_FILE_BIDBDBADMIN(in_to_name => 'shuchin@ms.usi.com.tw', subject => '[VRT] PL/SQL VRT_PLSQL_COMPLIANCE_WEEK ERROR', message => '[VRT_SAP006_COMPLIANCE_WEEK_T], The tracepoint is  ' || iTracePoint || ' and ErrorText= ' || cErrorText) ;
  else

  --清除重覆資料
   DELETE FROM VRT_ZOT004_COMPLIANCE_WEEK WHERE COMPANY_CODE =inCompany
           and p_week in (Select substrb(yyyyww,5,2) from DIMENSION_DATE Where date_key = to_char( sysdate - 7, 'yyyymmdd'));

  iTracePoint := '200';
  Insert into VRT_ZOT004_COMPLIANCE_WEEK (
                   P_YEAR, P_MONTH, P_WEEK, P_QUARTER, COMPANY_CODE, SITE, VENDOR_CODE, PTYPE, SCORES, COMPLIANCE_CNT, TOTAL_4A4_CNT, DATE_TIME)
      Select P_YEAR, P_MONTH, P_WEEK, P_QUARTER, COMPANY_CODE, SITE, VENDOR_CODE, PTYPE, SCORES, COMPLIANCE_CNT, TOTAL_4A4_CNT, DATE_TIME
             from VRT_SAP006_COMPLIANCE_WEEK_T
             where COMPANY_CODE = inCompany
               and p_week in (Select substrb(yyyyww,5,2) from DIMENSION_DATE Where date_key = to_char( sysdate - 7, 'yyyymmdd'));


  iTracePoint := '300';
  DELETE from VRT_SAP006_COMPLIANCE_WEEK_T
         where COMPANY_CODE = inCompany
           and p_week in (Select substrb(yyyyww,5,2) from DIMENSION_DATE Where date_key = to_char( sysdate - 7, 'yyyymmdd'));
  Commit;

  end if;

  --Add by susan 2006/11/22
  if inCompany = '1100' then
     VRT_PLSQL_ON_TIME_WEEK;
  end if;

EXCEPTION
   When OTHERS Then
    --有錯誤產生則寄mail
    cErrorText := SQLERRM();
    MAIL_FILE_BIDBDBADMIN(in_to_name => 'shuchin@ms.usi.com.tw', subject => '[VRT] PL/SQL VRT_PLSQL_COMPLIANCE_WEEK ERROR', message => '[VRT_ZOT004_COMPLIANCE_WEEK], The tracepoint is  ' || iTracePoint || ' and ErrorText= ' || cErrorText) ;

END VRT_PLSQL_COMPLIANCE_WEEK;
/

