create PROCEDURE         "VQA_PLSQL_SUM8_GV_QQ" IS

    /*
     CREATE DATE :  2008/03/02
      PLSQL      :  VQA_PLSQL_SUM8_GV_QQ
      Author     :  Susan Lin
      Purpase    :  Summary - Quality - WW(By 每月執行一次 For 季 )
                    TW/SZ/SH
     */


 vPROCEE_YYYYMMDD varchar2(8);
 vPROCEE_YYYYMM   varchar2(6);
 iTracePoint      varchar2(100);
 cErrorText       varchar2(500);
 vCOMPANY_CODE    varchar2(4);
 vYYYYMM          varchar2(6);
 vSTART_DATE      varchar2(8);
 vEND_DATE        varchar2(8);
 vQUARTER         varchar2(8);
 vCK_MANUF        varchar2(10);
 vIR_AMT_TWD                PLD_KPI_IR_DETAIL.IR_AMT_TWD%TYPE;
 vQ_AMOUNT       number(25,5);

 vQ_RANKING                 number(5);
 vSITE                      VQA_SUM14_QQ_MATGP.SITE%TYPE;
 vMATGROUP                  VQA_SUM14_QQ_MATGP.MATGROUP%TYPE;


 vQA_10_GRADE     VRTN_SUM20_GV_QQ_MATGP.QA_10_GRADE%TYPE;
 vQA_11_GRADE     VRTN_SUM20_GV_QQ_MATGP.QA_11_GRADE%TYPE;
 vQA_12_GRADE     VRTN_SUM20_GV_QQ_MATGP.QA_12_GRADE%TYPE;
 vQ_QA_GRADE      VRTN_SUM20_GV_QQ_MATGP.Q_QA_GRADE%TYPE;
 vQB_10_GRADE     VRTN_SUM20_GV_QQ_MATGP.QB_10_GRADE%TYPE;
 vQB_11_GRADE     VRTN_SUM20_GV_QQ_MATGP.QB_11_GRADE%TYPE;
 vQB_12_GRADE     VRTN_SUM20_GV_QQ_MATGP.QB_12_GRADE%TYPE;
 vQ_QB_GRADE      VRTN_SUM20_GV_QQ_MATGP.Q_QB_GRADE%TYPE;
 vQC_10_GRADE     VRTN_SUM20_GV_QQ_MATGP.QC_10_GRADE%TYPE;
 vQC_11_GRADE     VRTN_SUM20_GV_QQ_MATGP.QC_11_GRADE%TYPE;
 vQC_12_GRADE     VRTN_SUM20_GV_QQ_MATGP.QC_12_GRADE%TYPE;
 vQ_QC_GRADE      VRTN_SUM20_GV_QQ_MATGP.Q_QC_GRADE%TYPE;
 vQD_10_GRADE     VRTN_SUM20_GV_QQ_MATGP.QD_10_GRADE%TYPE;
 vQD_11_GRADE     VRTN_SUM20_GV_QQ_MATGP.QD_11_GRADE%TYPE;
 vQD_12_GRADE     VRTN_SUM20_GV_QQ_MATGP.QD_12_GRADE%TYPE;
 vQ_QD_GRADE      VRTN_SUM20_GV_QQ_MATGP.Q_QD_GRADE%TYPE;
 vSUBTOT_10_Q     VRTN_SUM20_GV_QQ_MATGP.SUBTOT_10_Q%TYPE;
 vSUBTOT_11_Q     VRTN_SUM20_GV_QQ_MATGP.SUBTOT_11_Q%TYPE;
 vSUBTOT_12_Q     VRTN_SUM20_GV_QQ_MATGP.SUBTOT_12_Q%TYPE;
 vSUBTOT_Q        VRTN_SUM20_GV_QQ_MATGP.SUBTOT_Q%TYPE;

 vck01                 number(5);
 vck02                 number(5);

vTW_SITE   VQA_SUM14_QQ_MATGP.SITE%TYPE;
vSZ_SITE   VQA_SUM14_QQ_MATGP.SITE%TYPE;
vSH_SITE   VQA_SUM14_QQ_MATGP.SITE%TYPE;
vTW_MANUF  VQA_SUM14_QQ_MATGP.MANUF%TYPE;
vSZ_MANUF  VQA_SUM14_QQ_MATGP.MANUF%TYPE;
vSH_MANUF  VQA_SUM14_QQ_MATGP.MANUF%TYPE;
vMATGROUP_T VQA_SUM14_QQ_MATGP.MATGROUP%TYPE;
vMANUF      VQA_SUM14_QQ_MATGP.MANUF%TYPE;

BEGIN
    vCOMPANY_CODE := null;
    vYYYYMM := null;
    vSTART_DATE := null;
    vEND_DATE := null;
    vQUARTER := null;
    vCK_MANUF := null;

   --抓上個月資料
     iTracePoint := '100';
     vPROCEE_YYYYMM := TO_CHAR(ADD_MONTHS(SYSDATE, -1), 'YYYYMM');
   --抓季資料
      for REC1 in (Select QUARTER
                          FROM DIMENSION_DATE
                          WHERE YYYY = SUBSTRB(vPROCEE_YYYYMM,1,4)
                            AND MM = SUBSTRB(vPROCEE_YYYYMM,5,2)
                            ) loop
         vQUARTER := SUBSTRB(vPROCEE_YYYYMM,1,4) || REC1.QUARTER;
      end loop;
    --抓季起始區間資料
         for REC1 in (Select MIN(DATE_KEY) AS DATE_KEY
                             FROM DIMENSION_DATE
                             WHERE QUARTER = SUBSTRB(vQUARTER,5,2)
                               AND YYYY = SUBSTRB(vQUARTER,1,4)
                               ) loop
            vSTART_DATE := REC1.DATE_KEY;
         end loop;
    --抓季終上區間資料
        for REC1 in (Select MAX(DATE_KEY) AS DATE_KEY
                            FROM DIMENSION_DATE
                            WHERE QUARTER = SUBSTRB(vQUARTER,5,2)
                              AND YYYY = SUBSTRB(vQUARTER,1,4)
                             ) loop
            vEND_DATE := REC1.DATE_KEY;
        end loop;



  if vQUARTER is null then
     --若沒抓到資料則寄 error mail
     iTracePoint := '110';
     cErrorText := 'QUARTER error!';
     MAIL_FILE_BIDBDBADMIN(in_to_name => 'shuchin@ms.usi.com.tw', subject => '[VQA] PL/SQL VQA_PLSQL_SUM8_GV_QQ ERROR', message => '[VRTN_PLSQL_SUM4_GV_AMT_QQ], The tracepoint is  ' || iTracePoint || ' and ErrorText= ' || cErrorText) ;
  else

     --清除舊的 VQA_SUM20_GV_QQ_MATGP 資料
       iTracePoint := '200';
       DELETE FROM VQA_SUM20_GV_QQ_MATGP WHERE QUARTER = SUBSTRB(vQUARTER,1,6);

     --放入季交易資料
       iTracePoint := '210';
        for REC1 in ( Select MANUF, MATGROUP, QUARTER, round(SUM(Q_AMOUNT), 2) as Q_AMOUNT
                             from VQA_SUM09_AMT_GV_MATGP_Q
                             where MANUF is Not Null
                               and MATGROUP is Not Null
                               and QUARTER = SUBSTRB(vQUARTER,1,6)
                    Group by MANUF, MATGROUP, QUARTER
                    ) loop


    -- Check VQA_SUM14_QQ_MATGP, VQA_SUM04_AMT_MATGP_Q table exist
      vck01 := '0';
      vck02 := '0';
      Select count(*) into vck01
                 from VQA_SUM14_QQ_MATGP a
                 where a.MANUF = REC1.MANUF
                   and a.MATGROUP = REC1.MATGROUP
                   and a.QUARTER =  vQUARTER;

      Select count(*) into vck02
                 from VQA_SUM04_AMT_MATGP_Q  a
                       where a.MANUF = REC1.MANUF
                         and a.MATGROUP = REC1.MATGROUP
                         and a.QUARTER =  vQUARTER;

     if vck01 > 0 and vck02 > 0 then
      --放到 VQA_SUM20_GV_QQ_MATGP
      iTracePoint := '220-' || REC1.MANUF || '-' || REC1.MATGROUP || '-' || vPROCEE_YYYYMM || REC1.QUARTER;
      insert into VQA_SUM20_GV_QQ_MATGP (
                  MANUF, MATGROUP, QUARTER, Q_AMOUNT, FROM_DATE, TO_DATE, DATE_TIME
           ) values (
           REC1.MANUF,
           REC1.MATGROUP,
           REC1.QUARTER,
           REC1.Q_AMOUNT,
           vSTART_DATE,
           vEND_DATE,
           to_char(SYSDATE, 'yyyymmddhh24miss')
           );
      commit;
     end if;

    end loop;
  end if;


  iTracePoint := '300'; --MATGROUP, MANUF BY QUARTER
  for REC1 in (
     select distinct MANUF, MATGROUP from VQA_SUM20_GV_QQ_MATGP c
      where QUARTER = vQUARTER
  ) loop
     select * into  vQA_10_GRADE, vQA_11_GRADE, vQA_12_GRADE, vQ_QA_GRADE, vQB_10_GRADE, vQB_11_GRADE, vQB_12_GRADE, vQ_QB_GRADE, vQC_10_GRADE, vQC_11_GRADE, vQC_12_GRADE, vQ_QC_GRADE, vQD_10_GRADE, vQD_11_GRADE, vQD_12_GRADE, vQ_QD_GRADE, vSUBTOT_10_Q, vSUBTOT_11_Q, vSUBTOT_12_Q, vSUBTOT_Q
                    from (
                 select round(sum(QA_10_GRADE * a.GV_PER),5) AS vQA_10_GRADE,
                        round(sum(QA_11_GRADE * a.GV_PER),5) AS vQA_11_GRADE,
                        round(sum(QA_12_GRADE * a.GV_PER),5) AS vQA_12_GRADE,
                        round(sum(Q_QA_GRADE  * a.GV_PER),5) AS vQ_QA_GRADE,
                        round(sum(QB_10_GRADE * a.GV_PER),5) AS vQB_10_GRADE,
                        round(sum(QB_11_GRADE * a.GV_PER),5) AS vQB_11_GRADE,
                        round(sum(QB_12_GRADE * a.GV_PER),5) AS vQB_12_GRADE,
                        round(sum(Q_QB_GRADE  * a.GV_PER),5) AS vQ_QB_GRADE,
                        round(sum(QC_10_GRADE * a.GV_PER),5) AS vQC_10_GRADE,
                        round(sum(QC_11_GRADE * a.GV_PER),5) AS vQC_11_GRADE,
                        round(sum(QC_12_GRADE * a.GV_PER),5) AS vQC_12_GRADE,
                        round(sum(Q_QC_GRADE  * a.GV_PER),5) AS vQ_QC_GRADE,
                        round(sum(QD_10_GRADE * a.GV_PER),5) AS vQD_10_GRADE,
                        round(sum(QD_11_GRADE * a.GV_PER),5) AS vQD_11_GRADE,
                        round(sum(QD_12_GRADE * a.GV_PER),5) AS vQD_12_GRADE,
                        round(sum(Q_QD_GRADE  * a.GV_PER),5) AS vQ_QD_GRADE,
                        round(sum(SUBTOT_10_Q * a.GV_PER),5) AS vSUBTOT_10_Q,
                        round(sum(SUBTOT_11_Q * a.GV_PER),5) AS vSUBTOT_11_Q,
                        round(sum(SUBTOT_12_Q * a.GV_PER),5) AS vSUBTOT_12_Q,
                        round(sum(SUBTOT_Q    * a.GV_PER),5) AS vSUBTOT_Q
                        from VQA_SUM04_AMT_MATGP_Q a, VQA_SUM14_QQ_MATGP b
                             where a.MANUF = b.MANUF
                               and a.QUARTER = b.QUARTER
                               and a.SITE = b.SITE
                               and a.MATGROUP = b.MATGROUP
                               and a.MANUF = REC1.MANUF
                               and a.MATGROUP = REC1.MATGROUP
                               and a.QUARTER = vQUARTER
                        Group by a.MANUF, a.MATGROUP


         );


        --PROCESS SCORE
          if vQA_10_GRADE > '100' then
             vQA_10_GRADE := '100';
          end if;
          if vQA_11_GRADE > '100' then
             vQA_11_GRADE := '100';
          end if;
          if vQA_12_GRADE > '100' then
             vQA_12_GRADE := '100';
          end if;
          if vQ_QA_GRADE > '100' then
             vQ_QA_GRADE := '100';
          end if;
          if vQB_10_GRADE > '100' then
             vQB_10_GRADE := '100';
          end if;
          if vQB_11_GRADE > '100' then
             vQB_11_GRADE := '100';
          end if;
          if vQB_12_GRADE > '100' then
             vQB_12_GRADE := '100';
          end if;
          if vQ_QB_GRADE > '100' then
             vQ_QB_GRADE := '100';
          end if;
          if vQC_10_GRADE > '100' then
             vQC_10_GRADE := '100';
          end if;
          if vQC_11_GRADE > '100' then
             vQC_11_GRADE := '100';
          end if;
          if vQC_12_GRADE > '100' then
             vQC_12_GRADE := '100';
          end if;
          if vQ_QC_GRADE > '100' then
             vQ_QC_GRADE := '100';
          end if;
          if vQD_10_GRADE > '100' then
             vQD_10_GRADE := '100';
          end if;
          if vQD_11_GRADE > '100' then
             vQD_11_GRADE := '100';
          end if;
          if vQD_12_GRADE > '100' then
             vQD_12_GRADE := '100';
          end if;
          if vQ_QD_GRADE > '100' then
             vQ_QD_GRADE := '100';
          end if;
          if vSUBTOT_10_Q > '100' then
             vSUBTOT_10_Q := '100';
          end if;
          if vSUBTOT_11_Q > '100' then
             vSUBTOT_11_Q := '100';
          end if;
          if vSUBTOT_12_Q > '100' then
             vSUBTOT_12_Q := '100';
          end if;
          if vSUBTOT_12_Q > '100' then
             vSUBTOT_12_Q := '100';
          end if;
          if vSUBTOT_Q > '100' then
             vSUBTOT_Q := '100';
          end if;


         UPDate VQA_SUM20_GV_QQ_MATGP
                            set QA_10_GRADE = vQA_10_GRADE,
                                QA_11_GRADE = vQA_11_GRADE,
                                QA_12_GRADE = vQA_12_GRADE,
                                Q_QA_GRADE  = vQ_QA_GRADE,
                                QB_10_GRADE =  vQB_10_GRADE,
                                QB_11_GRADE =  vQB_11_GRADE,
                                QB_12_GRADE =  vQB_12_GRADE,
                                Q_QB_GRADE  =  vQ_QB_GRADE,
                                QC_10_GRADE =  vQC_10_GRADE,
                                QC_11_GRADE =  vQC_11_GRADE,
                                QC_12_GRADE =  vQC_12_GRADE,
                                Q_QC_GRADE  =  vQ_QC_GRADE,
                                QD_10_GRADE =  vQD_10_GRADE,
                                QD_11_GRADE =  vQD_11_GRADE,
                                QD_12_GRADE =  vQD_12_GRADE,
                                Q_QD_GRADE  =  vQ_QD_GRADE,
                                SUBTOT_10_Q =  vSUBTOT_10_Q,
                                SUBTOT_11_Q =  vSUBTOT_11_Q,
                                SUBTOT_12_Q =  vSUBTOT_12_Q,
                                SUBTOT_Q    =  vSUBTOT_Q
        where QUARTER = vQUARTER
          and MATGROUP = REC1.MATGROUP
          and MANUF = REC1.MANUF;
       commit;

  end loop;




  -- GV Manufacture Process
  if vQUARTER is null then
     --若沒抓到資料則寄 error mail
     iTracePoint := '400';
     cErrorText := 'VQA QUARTER error!';
     MAIL_FILE_BIDBDBADMIN(in_to_name => 'shuchin@ms.usi.com.tw', subject => '[VQA] PL/SQL VQA_PLSQL_SUM8_GV_QQ ERROR', message => '[VRTN_PLSQL_SUM8_GV_QQ], The tracepoint is  ' || iTracePoint || ' and ErrorText= ' || cErrorText) ;
  else

     --清除舊的 VQA_SUM21_GV_QQ_MF 資料
       iTracePoint := '500';
       DELETE FROM VQA_SUM21_GV_QQ_MF WHERE QUARTER = SUBSTRB(vQUARTER,1,6);

     --放入季交易資料
       iTracePoint := '510';
        for REC1 in ( Select MANUF, QUARTER, round(SUM(Q_AMOUNT), 2) as Q_AMOUNT
                             from VQA_SUM10_AMT_GV_MF_Q
                             where MANUF is Not Null
                               and QUARTER = SUBSTRB(vQUARTER,1,6)
                    Group by MANUF, QUARTER
                    ) loop

     -- Check VQA_SUM05_AMT_MF_Q , VQA_SUM15_QQ_MF table exist
           vck01 := '0';
           vck02 := '0';
           Select count(*) into vck01
                      from VQA_SUM05_AMT_MF_Q a
                      where a.MANUF = REC1.MANUF
                        and a.QUARTER =  vQUARTER;

           Select count(*) into vck02
                      from VQA_SUM15_QQ_MF a
                            where a.MANUF = REC1.MANUF
                              and a.QUARTER =  vQUARTER;

      if vck01 > 0 and vck02 > 0 then

      --放到 VQA_SUM21_GV_QQ_MF
      iTracePoint := '520-' || REC1.MANUF || '-' || vPROCEE_YYYYMM || REC1.QUARTER;
      insert into VQA_SUM21_GV_QQ_MF (
                  MANUF,  QUARTER, Q_AMOUNT, FROM_DATE, TO_DATE, DATE_TIME
           ) values (
           REC1.MANUF,
           REC1.QUARTER,
           REC1.Q_AMOUNT,
           vSTART_DATE,
           vEND_DATE,
           to_char(SYSDATE, 'yyyymmddhh24miss')
           );
      commit;
      end if;

    end loop;
  end if;



  iTracePoint := '600'; -- MANUF BY QUARTER
  for REC1 in (
     select distinct MANUF from VQA_SUM21_GV_QQ_MF c
      where QUARTER = vQUARTER
  ) loop
     select * into  vQA_10_GRADE, vQA_11_GRADE, vQA_12_GRADE, vQ_QA_GRADE, vQB_10_GRADE, vQB_11_GRADE, vQB_12_GRADE, vQ_QB_GRADE, vQC_10_GRADE, vQC_11_GRADE, vQC_12_GRADE, vQ_QC_GRADE, vQD_10_GRADE, vQD_11_GRADE, vQD_12_GRADE, vQ_QD_GRADE, vSUBTOT_10_Q, vSUBTOT_11_Q, vSUBTOT_12_Q, vSUBTOT_Q
                    from (
                 select round(sum(QA_10_GRADE * a.GV_PER),5) AS vQA_10_GRADE,
                        round(sum(QA_11_GRADE * a.GV_PER),5) AS vQA_11_GRADE,
                        round(sum(QA_12_GRADE * a.GV_PER),5) AS vQA_12_GRADE,
                        round(sum(Q_QA_GRADE  * a.GV_PER),5) AS vQ_QA_GRADE,
                        round(sum(QB_10_GRADE * a.GV_PER),5) AS vQB_10_GRADE,
                        round(sum(QB_11_GRADE * a.GV_PER),5) AS vQB_11_GRADE,
                        round(sum(QB_12_GRADE * a.GV_PER),5) AS vQB_12_GRADE,
                        round(sum(Q_QB_GRADE  * a.GV_PER),5) AS vQ_QB_GRADE,
                        round(sum(QC_10_GRADE * a.GV_PER),5) AS vQC_10_GRADE,
                        round(sum(QC_11_GRADE * a.GV_PER),5) AS vQC_11_GRADE,
                        round(sum(QC_12_GRADE * a.GV_PER),5) AS vQC_12_GRADE,
                        round(sum(Q_QC_GRADE  * a.GV_PER),5) AS vQ_QC_GRADE,
                        round(sum(QD_10_GRADE * a.GV_PER),5) AS vQD_10_GRADE,
                        round(sum(QD_11_GRADE * a.GV_PER),5) AS vQD_11_GRADE,
                        round(sum(QD_12_GRADE * a.GV_PER),5) AS vQD_12_GRADE,
                        round(sum(Q_QD_GRADE  * a.GV_PER),5) AS vQ_QD_GRADE,
                        round(sum(SUBTOT_10_Q * a.GV_PER),5) AS vSUBTOT_10_Q,
                        round(sum(SUBTOT_11_Q * a.GV_PER),5) AS vSUBTOT_11_Q,
                        round(sum(SUBTOT_12_Q * a.GV_PER),5) AS vSUBTOT_12_Q,
                        round(sum(SUBTOT_Q    * a.GV_PER),5) AS vSUBTOT_Q
                        from VQA_SUM05_AMT_MF_Q a, VQA_SUM15_QQ_MF b
                             where a.MANUF = b.MANUF
                               and a.QUARTER = b.QUARTER
                               and a.SITE = b.SITE
                               and a.MANUF = REC1.MANUF
                               and a.QUARTER = vQUARTER
                         Group by a.MANUF

         );


        --PROCESS SCORE
          if vQA_10_GRADE > '100' then
             vQA_10_GRADE := '100';
          end if;
          if vQA_11_GRADE > '100' then
             vQA_11_GRADE := '100';
          end if;
          if vQA_12_GRADE > '100' then
             vQA_12_GRADE := '100';
          end if;
          if vQ_QA_GRADE > '100' then
             vQ_QA_GRADE := '100';
          end if;
          if vQB_10_GRADE > '100' then
             vQB_10_GRADE := '100';
          end if;
          if vQB_11_GRADE > '100' then
             vQB_11_GRADE := '100';
          end if;
          if vQB_12_GRADE > '100' then
             vQB_12_GRADE := '100';
          end if;
          if vQ_QB_GRADE > '100' then
             vQ_QB_GRADE := '100';
          end if;
          if vQC_10_GRADE > '100' then
             vQC_10_GRADE := '100';
          end if;
          if vQC_11_GRADE > '100' then
             vQC_11_GRADE := '100';
          end if;
          if vQC_12_GRADE > '100' then
             vQC_12_GRADE := '100';
          end if;
          if vQ_QC_GRADE > '100' then
             vQ_QC_GRADE := '100';
          end if;
          if vQD_10_GRADE > '100' then
             vQD_10_GRADE := '100';
          end if;
          if vQD_11_GRADE > '100' then
             vQD_11_GRADE := '100';
          end if;
          if vQD_12_GRADE > '100' then
             vQD_12_GRADE := '100';
          end if;
          if vQ_QD_GRADE > '100' then
             vQ_QD_GRADE := '100';
          end if;
          if vSUBTOT_10_Q > '100' then
             vSUBTOT_10_Q := '100';
          end if;
          if vSUBTOT_11_Q > '100' then
             vSUBTOT_11_Q := '100';
          end if;
          if vSUBTOT_12_Q > '100' then
             vSUBTOT_12_Q := '100';
          end if;
          if vSUBTOT_12_Q > '100' then
             vSUBTOT_12_Q := '100';
          end if;
          if vSUBTOT_Q > '100' then
             vSUBTOT_Q := '100';
          end if;



         UPDate VQA_SUM21_GV_QQ_MF
                            set QA_10_GRADE = vQA_10_GRADE,
                                QA_11_GRADE = vQA_11_GRADE,
                                QA_12_GRADE = vQA_12_GRADE,
                                Q_QA_GRADE  = vQ_QA_GRADE,
                                QB_10_GRADE =  vQB_10_GRADE,
                                QB_11_GRADE =  vQB_11_GRADE,
                                QB_12_GRADE =  vQB_12_GRADE,
                                Q_QB_GRADE  =  vQ_QB_GRADE,
                                QC_10_GRADE =  vQC_10_GRADE,
                                QC_11_GRADE =  vQC_11_GRADE,
                                QC_12_GRADE =  vQC_12_GRADE,
                                Q_QC_GRADE  =  vQ_QC_GRADE,
                                QD_10_GRADE =  vQD_10_GRADE,
                                QD_11_GRADE =  vQD_11_GRADE,
                                QD_12_GRADE =  vQD_12_GRADE,
                                Q_QD_GRADE  =  vQ_QD_GRADE,
                                SUBTOT_10_Q =  vSUBTOT_10_Q,
                                SUBTOT_11_Q =  vSUBTOT_11_Q,
                                SUBTOT_12_Q =  vSUBTOT_12_Q,
                                SUBTOT_Q    =  vSUBTOT_Q
        where QUARTER = vQUARTER
          and MANUF = REC1.MANUF;
       commit;

  end loop;




  --COMBINE
  iTracePoint := '700';  --刪除 VQA_SUM22_GV_QQ_COMBINE
  delete from VQA_SUM22_GV_QQ_COMBINE
   where QUARTER = vQUARTER;
  commit;


  iTracePoint := '800';
  insert into VQA_SUM22_GV_QQ_COMBINE (MANUF, MATGROUP, QUARTER, Q_GRADE, Q_RANKING, Q_AMOUNT, FROM_DATE, TO_DATE, DATE_TIME, AMT_SHARE_GV,
                    QA_10_GRADE, QA_11_GRADE, QA_12_GRADE, Q_QA_GRADE, QB_10_GRADE, QB_11_GRADE, QB_12_GRADE, Q_QB_GRADE, QC_10_GRADE, QC_11_GRADE, QC_12_GRADE, Q_QC_GRADE, QD_10_GRADE, QD_11_GRADE, QD_12_GRADE, Q_QD_GRADE, SUBTOT_10_Q, SUBTOT_11_Q, SUBTOT_12_Q, SUBTOT_Q,
                    TW_AMOUNT, TW_AMT_SHARE_SITE, TW_Q_SCORE, TW_SUBTOT_Q, TW_COMMENT, SH_AMOUNT, SH_AMT_SHARE_SITE, SH_Q_SCORE, SH_SUBTOT_Q, SH_COMMENT, SZ_AMOUNT, SZ_AMT_SHARE_SITE, SZ_Q_SCORE, SZ_SUBTOT_Q, SZ_COMMENT
                     )
         select   MANUF, MATGROUP, QUARTER, Q_GRADE, Q_RANKING, Q_AMOUNT, FROM_DATE, TO_DATE, DATE_TIME, AMT_SHARE_GV,
                    QA_10_GRADE, QA_11_GRADE, QA_12_GRADE, Q_QA_GRADE, QB_10_GRADE, QB_11_GRADE, QB_12_GRADE, Q_QB_GRADE, QC_10_GRADE, QC_11_GRADE, QC_12_GRADE, Q_QC_GRADE, QD_10_GRADE, QD_11_GRADE, QD_12_GRADE, Q_QD_GRADE, SUBTOT_10_Q, SUBTOT_11_Q, SUBTOT_12_Q, SUBTOT_Q,
                    TW_AMOUNT, TW_AMT_SHARE_SITE, TW_Q_SCORE, TW_SUBTOT_Q, TW_COMMENT, SH_AMOUNT, SH_AMT_SHARE_SITE, SH_Q_SCORE, SH_SUBTOT_Q, SH_COMMENT, SZ_AMOUNT, SZ_AMT_SHARE_SITE, SZ_Q_SCORE, SZ_SUBTOT_Q, SZ_COMMENT
         from  VQA_SUM20_GV_QQ_MATGP
                 where QUARTER = vQUARTER
              union all
                 select  MANUF, '000', QUARTER, Q_GRADE, Q_RANKING, Q_AMOUNT, FROM_DATE, TO_DATE, DATE_TIME, AMT_SHARE_GV,
                    QA_10_GRADE, QA_11_GRADE, QA_12_GRADE, Q_QA_GRADE, QB_10_GRADE, QB_11_GRADE, QB_12_GRADE, Q_QB_GRADE, QC_10_GRADE, QC_11_GRADE, QC_12_GRADE, Q_QC_GRADE, QD_10_GRADE, QD_11_GRADE, QD_12_GRADE, Q_QD_GRADE, SUBTOT_10_Q, SUBTOT_11_Q, SUBTOT_12_Q, SUBTOT_Q,
                    TW_AMOUNT, TW_AMT_SHARE_SITE, TW_Q_SCORE, TW_SUBTOT_Q, TW_COMMENT, SH_AMOUNT, SH_AMT_SHARE_SITE, SH_Q_SCORE, SH_SUBTOT_Q, SH_COMMENT, SZ_AMOUNT, SZ_AMT_SHARE_SITE, SZ_Q_SCORE, SZ_SUBTOT_Q, SZ_COMMENT
         from VQA_SUM21_GV_QQ_MF
                 where QUARTER = vQUARTER;

   commit;




EXCEPTION
   When OTHERS Then
    --有錯誤產生則寄mail
      cErrorText := SQLERRM();
      MAIL_FILE_BIDBDBADMIN(in_to_name => 'shuchin_lin@usiglobal.com', subject => '[VQA] PL/SQL VQA_PLSQL_SUM8_GV_QQ ERROR', message => '[VQA_PLSQL_SUM8_GV_QQ], The tracepoint is  ' || iTracePoint || ' and ErrorText= ' || cErrorText);


END VQA_PLSQL_SUM8_GV_QQ;
/

