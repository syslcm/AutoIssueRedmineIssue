create PROCEDURE         "PLSQL_ANALYZE_DB" (
  outRES OUT VARCHAR2
)
AUTHID DEFINER
is
BEGIN
  --analyze
  outRES := 'START';
  /*
  DBMS_STATS.GATHER_SCHEMA_STATS
  (
    ownname => 'POWEB',
    estimate_percent => NULL,
    method_opt => NULL,
    cascade => TRUE
  );
  Commit;
  */
  outRES := 'SUCCESS PLSQL_ANALYZE_DB';

EXCEPTION
  WHEN OTHERS THEN
    Rollback;
    outRES := 'FAILED PLSQL_ANALYZE_DB';
END PLSQL_ANALYZE_DB;
/

