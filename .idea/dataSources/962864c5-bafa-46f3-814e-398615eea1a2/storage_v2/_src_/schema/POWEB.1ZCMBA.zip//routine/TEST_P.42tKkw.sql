create PROCEDURE TEST_P (
  sTEST in VARCHAR2,
  RES OUT VARCHAR2         --回傳:執行的訊息
)
AUTHID DEFINER
is
BEGIN
  --RES := 'OK' ;
  --IF sTEST = 'OUT' THEN
  --   sTEST_OUT := 'TESTOUTP';
  --
  --END IF;
  --IF sTEST_OUT = 'TEST' Then
  --   sTEST_OUT := 'TESTOUTP';
  --End If;
  RES := sTEST ;

END TEST_P;
/

