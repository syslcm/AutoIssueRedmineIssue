create PROCEDURE       pnl3_pls005_cat_gen_pn_trx (
   --inCompany  in VARCHAR2,
   inperiod   IN   VARCHAR2
--2008/10/15 Crate by wenrong
--2008/11/6  要搬到collect_data時,不要再加上mtl_group,ship_to,bill_to,pn等資料,畢竟只是要計算出summary資料而已,不然在200810除了未分配有3萬筆,其他copa/pca/glaccount
--加起來也2萬筆,卻跑出23萬筆的資料
--2009/5/19 因為pnl 要by project,此程式原本用不到,從2009/5/19開始就會用來產生明細到pn以及PROJECT NAME的資料
--          金額在PNL3_PLS005_CAT_GEN_ALL_TRX已由正轉負,所以這裡不能再減一次了,要*-1回來
)
AUTHID DEFINER
IS
   --呆帳金額(待寫)
   a_amount_l    pnl3_trx001_copa.amt_twd%TYPE;
   a_amount_t    pnl3_trx001_copa.amt_twd%TYPE;
   a_amount_u    pnl3_trx001_copa.amt_twd%TYPE;
   ex_amount_l   pnl3_trx001_copa.amt_twd%TYPE;
   ex_amount_t   pnl3_trx001_copa.amt_twd%TYPE;
   ex_amount_u   pnl3_trx001_copa.amt_twd%TYPE;
   a_counter     INTEGER;
   a_rate        NUMBER (10, 2);
   a_year        pnl_msa001_em_data.yyyy%TYPE;
   a_month       pnl_msa001_em_data.MONTH%TYPE;
BEGIN
   a_year := SUBSTRB (inperiod, 1, 4);
   a_month := SUBSTRB (inperiod, 5, 6);

   DELETE FROM pnl3_trx005_collect_pn
         WHERE period = inperiod;

   COMMIT;

   FOR rec1 IN (SELECT   company_code, period, profit_center,
                         end_customer_id, r_kind, area1, area2, area3,
                         SOURCE, part_no, project_type, project_name, pjm,
                         project_l1, project_l2, project_l3, project_l4,
                         project_l5, project_l6, SUM (amt_local) amt_local,
                         SUM (amt_usd) amt_usd, SUM (amt_twd) amt_twd
                    FROM pnl3_trx005_collect_detail_pn
                   WHERE period = inperiod
                GROUP BY company_code,
                         period,
                         profit_center,
                         end_customer_id,
                         r_kind,
                         area1,
                         area2,
                         area3,
                         SOURCE,
                         part_no,
                         project_type,
                         project_name,
                         pjm,
                         project_l1,
                         project_l2,
                         project_l3,
                         project_l4,
                         project_l5,
                         project_l6)
   LOOP
      INSERT INTO pnl3_trx005_collect_pn
                  (company_code, period, profit_center,
                   end_customer_id, amt_local, amt_usd,
                   amt_twd, SOURCE, r_kind, area1,
                   area2, area3, create_date, part_no,
                   project_type, project_name, pjm,
                   project_l1, project_l2, project_l3,
                   project_l4, project_l5, project_l6
                  )
           VALUES (rec1.company_code, rec1.period, rec1.profit_center,
                   rec1.end_customer_id, rec1.amt_local, rec1.amt_usd,
                   rec1.amt_twd, rec1.SOURCE, rec1.r_kind, rec1.area1,
                   rec1.area2, rec1.area3, SYSDATE, rec1.part_no,
                   rec1.project_type, rec1.project_name, rec1.pjm,
                   rec1.project_l1, rec1.project_l2, rec1.project_l3,
                   rec1.project_l4, rec1.project_l5, rec1.project_l6
                  ); 

      COMMIT;
   END LOOP;
   
   --因費用邏輯不同,所以要使用pl02
   UPDATE pnl3_trx005_collect_pn SET R_KIND = 'PL02' WHERE PERIOD = inPeriod;
   COMMIT;
   --以下在計算加總

   --從Revenue角度來看,但也得考慮到end customer可能沒有Revenue只有成本??雖然不大可能發生,仍要加入這條邏輯(寫在此LOOP後)
   FOR rec1 IN (SELECT   profit_center, end_customer_id, company_code, SOURCE,
                         part_no, project_type, project_name, pjm, project_l1,
                         project_l2, project_l3, project_l4, project_l5,
                         project_l6, SUM (amt_local) amt_local,
                         SUM (amt_usd) amt_usd, SUM (amt_twd) amt_twd
                    FROM pnl3_trx005_collect_detail_pn
                   WHERE r_kind = 'PL01'
                     AND period = inperiod
                     AND area1 = '1'
                     AND area2 = '1'
                     AND area3 = '0'
                GROUP BY profit_center,
                         end_customer_id,
                         company_code,
                         SOURCE,
                         part_no,
                         project_type,
                         project_name,
                         pjm,
                         project_l1,
                         project_l2,
                         project_l3,
                         project_l4,
                         project_l5,
                         project_l6)
   LOOP
      INSERT INTO pnl3_trx005_collect_pn
                  (company_code, period, profit_center,
                   end_customer_id, amt_local, amt_usd,
                   amt_twd, SOURCE, r_kind, area1, area2, area3,
                   create_date, TYPE, part_no, project_type,
                   project_name, pjm, project_l1,
                   project_l2, project_l3, project_l4,
                   project_l5, project_l6
                  )
           VALUES (rec1.company_code, inperiod, rec1.profit_center,
                   rec1.end_customer_id, rec1.amt_local, rec1.amt_usd,
                   rec1.amt_twd, rec1.SOURCE, 'PL02', '1', '4', '0',
                   SYSDATE, 'SUM', rec1.part_no, rec1.project_type,
                   rec1.project_name, rec1.pjm, rec1.project_l1,
                   rec1.project_l2, rec1.project_l3, rec1.project_l4,
                   rec1.project_l5, rec1.project_l6
                  );

      COMMIT;
      --Gross margin & COGS Subtotal
      a_amount_l := rec1.amt_local;
      a_amount_t := rec1.amt_twd;
      a_amount_u := rec1.amt_usd;

      FOR rec2 IN (SELECT   profit_center, end_customer_id, company_code,
                            SOURCE, part_no, project_type, project_name, pjm,
                            project_l1, project_l2, project_l3, project_l4,
                            project_l5, project_l6,
                            NVL (SUM (amt_local), 0) amt_local,
                            NVL (SUM (amt_usd), 0) amt_usd,
                            NVL (SUM (amt_twd), 0) amt_twd
                       FROM pnl3_trx005_collect_detail_pn
                      WHERE r_kind = 'PL01'
                        AND period = inperiod
                        AND profit_center = rec1.profit_center
                        AND company_code = rec1.company_code
                        AND end_customer_id = rec1.end_customer_id
                        AND part_no = rec1.part_no
                        AND SOURCE = rec1.SOURCE
                        AND project_type = rec1.project_type
                        AND project_name = rec1.project_name
                        AND pjm = rec1.pjm
                        AND project_l1 = rec1.project_l1
                        AND project_l2 = rec1.project_l2
                        AND project_l3 = rec1.project_l3
                        AND project_l4 = rec1.project_l4
                        AND project_l5 = rec1.project_l5
                        AND project_l6 = rec1.project_l6
                        AND area1 = '2'
                        AND area2 IN ('2', '3', '4', '5')
                   --AND AREA3  = '0'
                   GROUP BY profit_center,
                            end_customer_id,
                            company_code,
                            SOURCE,
                            part_no,
                            project_type,
                            project_name,
                            pjm,
                            project_l1,
                            project_l2,
                            project_l3,
                            project_l4,
                            project_l5,
                            project_l6)
      LOOP
         a_amount_l := a_amount_l - (rec2.amt_local * -1);
         a_amount_t := a_amount_t - (rec2.amt_twd * -1);
         a_amount_u := a_amount_u - (rec2.amt_usd * -1);

         --COGS SubTotal
         INSERT INTO pnl3_trx005_collect_pn
                     (company_code, period, profit_center,
                      end_customer_id, amt_local, amt_usd,
                      amt_twd, SOURCE, r_kind, area1, area2, area3,
                      create_date, TYPE, part_no, project_type,
                      project_name, pjm, project_l1,
                      project_l2, project_l3, project_l4,
                      project_l5, project_l6
                     )
              VALUES (rec2.company_code, inperiod, rec2.profit_center,
                      rec2.end_customer_id, rec2.amt_local, rec2.amt_usd,
                      rec2.amt_twd, rec1.SOURCE, 'PL02', '2', '6', '0',
                      SYSDATE, 'SUM', rec2.part_no, rec2.project_type,
                      rec2.project_name, rec2.pjm, rec2.project_l1,
                      rec2.project_l2, rec2.project_l3, rec2.project_l4,
                      rec2.project_l5, rec2.project_l6
                     );

         COMMIT;
      END LOOP;

      --Gross margin
      INSERT INTO pnl3_trx005_collect_pn
                  (company_code, period, profit_center,
                   end_customer_id, amt_local, amt_usd, amt_twd,
                   SOURCE, r_kind, area1, area2, area3, create_date, TYPE,
                   part_no, project_type, project_name,
                   pjm, project_l1, project_l2,
                   project_l3, project_l4, project_l5,
                   project_l6
                  )
           VALUES (rec1.company_code, inperiod, rec1.profit_center,
                   rec1.end_customer_id, a_amount_l, a_amount_u, a_amount_t,
                   rec1.SOURCE, 'PL02', '3', '0', '0', SYSDATE, 'SUM',
                   rec1.part_no, rec1.project_type, rec1.project_name,
                   rec1.pjm, rec1.project_l1, rec1.project_l2,
                   rec1.project_l3, rec1.project_l4, rec1.project_l5,
                   rec1.project_l6
                  );

      COMMIT;
   END LOOP;

   FOR rec1 IN (SELECT   profit_center, end_customer_id, company_code, period,
                         SOURCE, part_no, project_type, project_name, pjm,
                         project_l1, project_l2, project_l3, project_l4,
                         project_l5, project_l6,
                         NVL (SUM (amt_local), 0) amt_local,
                         NVL (SUM (amt_usd), 0) amt_usd,
                         NVL (SUM (amt_twd), 0) amt_twd
                    FROM pnl3_trx005_collect_detail_pn
                   WHERE r_kind = 'PL01'
                     AND period = inperiod
                     --AND PROFIT_CENTER = REC1.PROFIT_CENTER
                     --AND COMPANY_CODE = REC1.COMPANY_CODE
                     --AND END_CUSTOMER_ID = REC1.END_CUSTOMER_ID
                     AND area1 = '2'
                     AND area2 IN ('2', '3', '4', '5')
                --AND AREA3  = '0'
                GROUP BY profit_center,
                         end_customer_id,
                         company_code,
                         period,
                         SOURCE,
                         part_no,
                         project_type,
                         project_name,
                         pjm,
                         project_l1,
                         project_l2,
                         project_l3,
                         project_l4,
                         project_l5,
                         project_l6)
   LOOP
      a_counter := 0;
      a_amount_l := 0;
      a_amount_t := 0;
      a_amount_u := 0;

      BEGIN
         SELECT   COUNT (*)
             INTO a_counter
             FROM pnl3_trx005_collect_detail_pn
            WHERE r_kind = 'PL01'
              AND period = inperiod
              AND area1 = '1'
              AND area2 = '1'
              AND area3 = '0'
              AND profit_center = rec1.profit_center
              AND end_customer_id = rec1.end_customer_id
              AND company_code = rec1.company_code
              AND SOURCE = rec1.SOURCE
              AND part_no = rec1.part_no
              AND project_type = rec1.project_type
              AND project_name = rec1.project_name
              AND pjm = rec1.pjm
              AND project_l1 = rec1.project_l1
              AND project_l2 = rec1.project_l2
              AND project_l3 = rec1.project_l3
              AND project_l4 = rec1.project_l4
              AND project_l5 = rec1.project_l5
              AND project_l6 = rec1.project_l6
         GROUP BY profit_center,
                  end_customer_id,
                  company_code,
                  SOURCE,
                  part_no,
                  project_type,
                  project_name,
                  pjm,
                  project_l1,
                  project_l2,
                  project_l3,
                  project_l4,
                  project_l5,
                  project_l6;

         IF SQL%NOTFOUND
         THEN
            a_counter := 0;
         END IF;
      EXCEPTION
         WHEN OTHERS
         THEN
            a_counter := 0;
      END;

      --表示此PC+SITE+END_CUSTOMER 沒有營收,只有成本
      IF a_counter = 0
      THEN
         INSERT INTO pnl3_trx005_collect_pn
                     (company_code, period, profit_center,
                      end_customer_id, amt_local, amt_usd,
                      amt_twd, SOURCE, r_kind, area1, area2, area3,
                      create_date, TYPE, part_no, project_type,
                      project_name, pjm, project_l1,
                      project_l2, project_l3, project_l4,
                      project_l5, project_l6
                     )
              VALUES (rec1.company_code, rec1.period, rec1.profit_center,
                      rec1.end_customer_id, rec1.amt_local, rec1.amt_usd,
                      rec1.amt_twd, rec1.SOURCE, 'PL02', '2', '6', '0',
                      SYSDATE, 'SUM', rec1.part_no, rec1.project_type,
                      rec1.project_name, rec1.pjm, rec1.project_l1,
                      rec1.project_l2, rec1.project_l3, rec1.project_l4,
                      rec1.project_l5, rec1.project_l6
                     );

         COMMIT;
         --Gross margin
         a_amount_l := a_amount_l - (rec1.amt_local * -1);
         a_amount_t := a_amount_t - (rec1.amt_twd * -1);
         a_amount_u := a_amount_u - (rec1.amt_usd * -1);

         INSERT INTO pnl3_trx005_collect_pn
                     (company_code, period, profit_center,
                      end_customer_id, amt_local, amt_usd,
                      amt_twd, SOURCE, r_kind, area1, area2, area3,
                      create_date, TYPE, part_no, project_type,
                      project_name, pjm, project_l1,
                      project_l2, project_l3, project_l4,
                      project_l5, project_l6
                     )
              VALUES (rec1.company_code, rec1.period, rec1.profit_center,
                      rec1.end_customer_id, a_amount_l, a_amount_u,
                      a_amount_t, rec1.SOURCE, 'PL02', '3', '0', '0',
                      SYSDATE, 'SUM', rec1.part_no, rec1.project_type,
                      rec1.project_name, rec1.pjm, rec1.project_l1,
                      rec1.project_l2, rec1.project_l3, rec1.project_l4,
                      rec1.project_l5, rec1.project_l6
                     );

         COMMIT;
      END IF;
   END LOOP;
   
   pnl3_pls013_RDexp_ratio_trx(inperiod);  --計算比例
   pnl3_pls014_PROJECT_EXP_trx(inperiod);  --計算費用

   --exp.的total 或 subtotal要計算完再加
   FOR rec1 IN (SELECT   profit_center, end_customer_id, company_code, period,
                         SOURCE, part_no, project_type, project_name, pjm,
                         project_l1, project_l2, project_l3, project_l4,
                         project_l5, project_l6,
                         NVL (SUM (amt_local), 0) amt_local,
                         NVL (SUM (amt_usd), 0) amt_usd,
                         NVL (SUM (amt_twd), 0) amt_twd
                    FROM pnl3_trx005_collect_pn
                   WHERE r_kind = 'PL02'
                     AND period = inperiod
                     AND area1 = '4'
                     AND area2 = '1'
                     AND area3 BETWEEN '1' AND '89'
                GROUP BY profit_center,
                         end_customer_id,
                         company_code,
                         period,
                         SOURCE,
                         part_no,
                         project_type,
                         project_name,
                         pjm,
                         project_l1,
                         project_l2,
                         project_l3,
                         project_l4,
                         project_l5,
                         project_l6)
   LOOP
      INSERT INTO pnl3_trx005_collect_pn
                  (company_code, period, profit_center,
                   end_customer_id, amt_local, amt_usd,
                   amt_twd, SOURCE, r_kind, area1, area2, area3,
                   create_date, TYPE, part_no, project_type,
                   project_name, pjm, project_l1,
                   project_l2, project_l3, project_l4,
                   project_l5, project_l6
                  )
           VALUES (rec1.company_code, rec1.period, rec1.profit_center,
                   rec1.end_customer_id, rec1.amt_local, rec1.amt_usd,
                   rec1.amt_twd, rec1.SOURCE, 'PL02', '4', '1', '90',
                   SYSDATE, 'SUM', rec1.part_no, rec1.project_type,
                   rec1.project_name, rec1.pjm, rec1.project_l1,
                   rec1.project_l2, rec1.project_l3, rec1.project_l4,
                   rec1.project_l5, rec1.project_l6
                  );

      COMMIT;

      INSERT INTO pnl3_trx005_collect_pn
                  (company_code, period, profit_center,
                   end_customer_id, amt_local, amt_usd, amt_twd, SOURCE,
                   r_kind, area1, area2, area3, create_date, TYPE, part_no,
                   project_type, project_name, pjm,
                   project_l1, project_l2, project_l3,
                   project_l4, project_l5, project_l6
                  )
           VALUES (rec1.company_code, rec1.period, rec1.profit_center,
                   rec1.end_customer_id, 0, 0, 0, rec1.SOURCE,
                   'PL02', '4', '1', '0', SYSDATE, 'SUM', rec1.part_no,
                   rec1.project_type, rec1.project_name, rec1.pjm,
                   rec1.project_l1, rec1.project_l2, rec1.project_l3,
                   rec1.project_l4, rec1.project_l5, rec1.project_l6
                  );

      COMMIT;
   END LOOP;

   FOR rec1 IN (SELECT   profit_center, end_customer_id, company_code, period,
                         SOURCE, part_no, project_type, project_name, pjm,
                         project_l1, project_l2, project_l3, project_l4,
                         project_l5, project_l6
                    FROM pnl3_trx005_collect_pn
                   WHERE r_kind = 'PL02' AND period = inperiod AND area1 = '4'
                GROUP BY profit_center,
                         end_customer_id,
                         company_code,
                         period,
                         SOURCE,
                         part_no,
                         project_type,
                         project_name,
                         pjm,
                         project_l1,
                         project_l2,
                         project_l3,
                         project_l4,
                         project_l5,
                         project_l6)
   LOOP
      INSERT INTO pnl3_trx005_collect_pn
                  (company_code, period, profit_center,
                   end_customer_id, amt_local, amt_usd, amt_twd, SOURCE,
                   r_kind, area1, area2, area3, create_date, TYPE, part_no,
                   project_type, project_name, pjm,
                   project_l1, project_l2, project_l3,
                   project_l4, project_l5, project_l6
                  )
           VALUES (rec1.company_code, rec1.period, rec1.profit_center,
                   rec1.end_customer_id, 0, 0, 0, rec1.SOURCE,
                   'PL02', '4', '0', '0', SYSDATE, 'SUM', rec1.part_no,
                   rec1.project_type, rec1.project_name, rec1.pjm,
                   rec1.project_l1, rec1.project_l2, rec1.project_l3,
                   rec1.project_l4, rec1.project_l5, rec1.project_l6
                  );

      COMMIT;
   END LOOP;

   FOR rec1 IN (SELECT   profit_center, end_customer_id, company_code, period,
                         SOURCE, part_no, project_type, project_name, pjm,
                         project_l1, project_l2, project_l3, project_l4,
                         project_l5, project_l6,
                         NVL (SUM (amt_local), 0) amt_local,
                         NVL (SUM (amt_usd), 0) amt_usd,
                         NVL (SUM (amt_twd), 0) amt_twd
                    FROM pnl3_trx005_collect_pn
                   WHERE r_kind = 'PL02'
                     AND period = inperiod
                     AND area1 = '4'
                     AND area2 = '2'
                     AND area3 BETWEEN '1' AND '89'
                GROUP BY profit_center,
                         end_customer_id,
                         company_code,
                         period,
                         SOURCE,
                         part_no,
                         project_type,
                         project_name,
                         pjm,
                         project_l1,
                         project_l2,
                         project_l3,
                         project_l4,
                         project_l5,
                         project_l6)
   LOOP
      INSERT INTO pnl3_trx005_collect_pn
                  (company_code, period, profit_center,
                   end_customer_id, amt_local, amt_usd,
                   amt_twd, SOURCE, r_kind, area1, area2, area3,
                   create_date, TYPE, part_no, project_type,
                   project_name, pjm, project_l1,
                   project_l2, project_l3, project_l4,
                   project_l5, project_l6
                  )
           VALUES (rec1.company_code, rec1.period, rec1.profit_center,
                   rec1.end_customer_id, rec1.amt_local, rec1.amt_usd,
                   rec1.amt_twd, rec1.SOURCE, 'PL02', '4', '2', '90',
                   SYSDATE, 'SUM', rec1.part_no, rec1.project_type,
                   rec1.project_name, rec1.pjm, rec1.project_l1,
                   rec1.project_l2, rec1.project_l3, rec1.project_l4,
                   rec1.project_l5, rec1.project_l6
                  );

      COMMIT;

      INSERT INTO pnl3_trx005_COLLECT_pn
                  (company_code, period, profit_center,
                   end_customer_id, amt_local, amt_usd, amt_twd, SOURCE,
                   r_kind, area1, area2, area3, create_date, TYPE, part_no,
                   project_type, project_name, pjm,
                   project_l1, project_l2, project_l3,
                   project_l4, project_l5, project_l6
                  )
           VALUES (rec1.company_code, rec1.period, rec1.profit_center,
                   rec1.end_customer_id, 0, 0, 0, rec1.SOURCE,
                   'PL02', '4', '2', '0', SYSDATE, 'SUM', rec1.part_no,
                   rec1.project_type, rec1.project_name, rec1.pjm,
                   rec1.project_l1, rec1.project_l2, rec1.project_l3,
                   rec1.project_l4, rec1.project_l5, rec1.project_l6
                  );

      COMMIT;
   END LOOP;

   FOR rec1 IN (SELECT   profit_center, end_customer_id, company_code, period,
                         SOURCE, part_no, project_type, project_name, pjm,
                         project_l1, project_l2, project_l3, project_l4,
                         project_l5, project_l6,
                         NVL (SUM (amt_local), 0) amt_local,
                         NVL (SUM (amt_usd), 0) amt_usd,
                         NVL (SUM (amt_twd), 0) amt_twd
                    FROM pnl3_trx005_collect_pn
                   WHERE r_kind = 'PL02'
                     AND period = inperiod
                     AND area1 = '4'
                     AND area2 = '3'
                     AND area3 BETWEEN '1' AND '89'
                GROUP BY profit_center,
                         end_customer_id,
                         company_code,
                         period,
                         SOURCE,
                         part_no,
                         project_type,
                         project_name,
                         pjm,
                         project_l1,
                         project_l2,
                         project_l3,
                         project_l4,
                         project_l5,
                         project_l6)
   LOOP
      INSERT INTO pnl3_trx005_collect_pn
                  (company_code, period, profit_center,
                   end_customer_id, amt_local, amt_usd,
                   amt_twd, SOURCE, r_kind, area1, area2, area3,
                   create_date, TYPE, part_no, project_type,
                   project_name, pjm, project_l1,
                   project_l2, project_l3, project_l4,
                   project_l5, project_l6
                  )
           VALUES (rec1.company_code, rec1.period, rec1.profit_center,
                   rec1.end_customer_id, rec1.amt_local, rec1.amt_usd,
                   rec1.amt_twd, rec1.SOURCE, 'PL02', '4', '3', '90',
                   SYSDATE, 'SUM', rec1.part_no, rec1.project_type,
                   rec1.project_name, rec1.pjm, rec1.project_l1,
                   rec1.project_l2, rec1.project_l3, rec1.project_l4,
                   rec1.project_l5, rec1.project_l6
                  );

      COMMIT;

      INSERT INTO pnl3_trx005_collect_pn
                  (company_code, period, profit_center,
                   end_customer_id, amt_local, amt_usd, amt_twd, SOURCE,
                   r_kind, area1, area2, area3, create_date, TYPE, part_no,
                   project_type, project_name, pjm,
                   project_l1, project_l2, project_l3,
                   project_l4, project_l5, project_l6
                  )
           VALUES (rec1.company_code, rec1.period, rec1.profit_center,
                   rec1.end_customer_id, 0, 0, 0, rec1.SOURCE,
                   'PL02', '4', '3', '0', SYSDATE, 'SUM', rec1.part_no,
                   rec1.project_type, rec1.project_name, rec1.pjm,
                   rec1.project_l1, rec1.project_l2, rec1.project_l3,
                   rec1.project_l4, rec1.project_l5, rec1.project_l6
                  );

      COMMIT;
   END LOOP;

   FOR rec1 IN (SELECT   profit_center, end_customer_id, company_code, period,
                         SOURCE, part_no, project_type, project_name, pjm,
                         project_l1, project_l2, project_l3, project_l4,
                         project_l5, project_l6,
                         NVL (SUM (amt_local), 0) amt_local,
                         NVL (SUM (amt_usd), 0) amt_usd,
                         NVL (SUM (amt_twd), 0) amt_twd
                    FROM pnl3_trx005_collect_pn
                   WHERE r_kind = 'PL02'
                     AND period = inperiod
                     AND area1 = '4'
                     AND area3 = '90'
                GROUP BY profit_center,
                         end_customer_id,
                         company_code,
                         period,
                         SOURCE,
                         part_no,
                         project_type,
                         project_name,
                         pjm,
                         project_l1,
                         project_l2,
                         project_l3,
                         project_l4,
                         project_l5,
                         project_l6)
   LOOP
      INSERT INTO pnl3_trx005_collect_pn
                  (company_code, period, profit_center,
                   end_customer_id, amt_local, amt_usd,
                   amt_twd, SOURCE, r_kind, area1, area2, area3,
                   create_date, TYPE, part_no, project_type,
                   project_name, pjm, project_l1,
                   project_l2, project_l3, project_l4,
                   project_l5, project_l6
                  )
           VALUES (rec1.company_code, rec1.period, rec1.profit_center,
                   rec1.end_customer_id, rec1.amt_local, rec1.amt_usd,
                   rec1.amt_twd, rec1.SOURCE, 'PL02', '4', '4', '0',
                   SYSDATE, 'SUM', rec1.part_no, rec1.project_type,
                   rec1.project_name, rec1.pjm, rec1.project_l1,
                   rec1.project_l2, rec1.project_l3, rec1.project_l4,
                   rec1.project_l5, rec1.project_l6
                  );

      COMMIT;
   END LOOP;

   FOR rec1 IN (SELECT   company_code, profit_center, end_customer_id,
                         part_no, project_type, project_name, pjm, project_l1,
                         project_l2, project_l3, project_l4, project_l5,
                         project_l6, SUM (amt_local) amt_local,
                         SUM (amt_usd) amt_usd, SUM (amt_twd) amt_twd
                    FROM pnl3_trx005_collect_pn
                   WHERE period = inperiod
                     AND r_kind = 'PL02'
                     AND area1 = '3'
                     AND area2 = '0'
                     AND area3 = '0'
                GROUP BY company_code,
                         profit_center,
                         end_customer_id,
                         part_no,
                         project_type,
                         project_name,
                         pjm,
                         project_l1,
                         project_l2,
                         project_l3,
                         project_l4,
                         project_l5,
                         project_l6)
   LOOP
      a_counter := 0;
      a_amount_l := rec1.amt_local;
      a_amount_t := rec1.amt_twd;
      a_amount_u := rec1.amt_usd;

      FOR rec2 IN (SELECT   profit_center, end_customer_id, company_code,
                            part_no, project_type, project_name, pjm,
                            project_l1, project_l2, project_l3, project_l4,
                            project_l5, project_l6,
                            NVL (SUM (amt_local), 0) amt_local,
                            NVL (SUM (amt_usd), 0) amt_usd,
                            NVL (SUM (amt_twd), 0) amt_twd
                       FROM pnl3_trx005_collect_pn
                      WHERE r_kind = 'PL02'
                        AND period = inperiod
                        AND profit_center = rec1.profit_center
                        AND company_code = rec1.company_code
                        AND end_customer_id = rec1.end_customer_id
                        AND part_no = rec1.part_no
                        AND project_type = rec1.project_type
                        AND project_name = rec1.project_name
                        AND pjm = rec1.pjm
                        AND project_l1 = rec1.project_l1
                        AND project_l2 = rec1.project_l2
                        AND project_l3 = rec1.project_l3
                        AND project_l4 = rec1.project_l4
                        AND project_l5 = rec1.project_l5
                        AND project_l6 = rec1.project_l6
                        AND area1 = '4'
                        AND area2 = '4'
                        AND area3 = '0'
                   GROUP BY profit_center,
                            end_customer_id,
                            company_code,
                            part_no,
                            project_type,
                            project_name,
                            pjm,
                            project_l1,
                            project_l2,
                            project_l3,
                            project_l4,
                            project_l5,
                            project_l6)
      LOOP
         a_amount_l := a_amount_l + rec2.amt_local;
         a_amount_t := a_amount_t + rec2.amt_twd;
         a_amount_u := a_amount_u + rec2.amt_usd;
         a_counter := a_counter + 1;

         --COGS SubTotal
         INSERT INTO pnl3_trx005_collect_pn
                     (company_code, period, profit_center,
                      end_customer_id, amt_local, amt_usd,
                      amt_twd, SOURCE, r_kind, area1, area2, area3,
                      create_date, TYPE, part_no, project_type,
                      project_name, pjm, project_l1,
                      project_l2, project_l3, project_l4,
                      project_l5, project_l6
                     )
              VALUES (rec2.company_code, inperiod, rec2.profit_center,
                      rec2.end_customer_id, a_amount_l, a_amount_u,
                      a_amount_t, 'TOTAL', 'PL02', '4', '5', '0',
                      SYSDATE, 'SUM', rec2.part_no, rec2.project_type,
                      rec2.project_name, rec2.pjm, rec2.project_l1,
                      rec2.project_l2, rec2.project_l3, rec2.project_l4,
                      rec2.project_l5, rec2.project_l6
                     );

         COMMIT;
      END LOOP;

      IF a_counter = 0
      THEN
         INSERT INTO pnl3_trx005_collect_pn
                     (company_code, period, profit_center,
                      end_customer_id, amt_local, amt_usd,
                      amt_twd, SOURCE, r_kind, area1, area2, area3,
                      create_date, TYPE, part_no, project_type,
                      project_name, pjm, project_l1,
                      project_l2, project_l3, project_l4,
                      project_l5, project_l6
                     )
              VALUES (rec1.company_code, inperiod, rec1.profit_center,
                      rec1.end_customer_id, a_amount_l, a_amount_u,
                      a_amount_t, 'TOTAL', 'PL02', '4', '5', '0',
                      SYSDATE, 'SUM', rec1.part_no, rec1.project_type,
                      rec1.project_name, rec1.pjm, rec1.project_l1,
                      rec1.project_l2, rec1.project_l3, rec1.project_l4,
                      rec1.project_l5, rec1.project_l6
                     );

         COMMIT;
      END IF;
   END LOOP;

   FOR rec2 IN (SELECT   profit_center, end_customer_id, company_code,
                         part_no, project_type, project_name, pjm, project_l1,
                         project_l2, project_l3, project_l4, project_l5,
                         project_l6, NVL (SUM (amt_local), 0) amt_local,
                         NVL (SUM (amt_usd), 0) amt_usd,
                         NVL (SUM (amt_twd), 0) amt_twd
                    FROM pnl3_trx005_collect_pn
                   WHERE r_kind = 'PL02'
                     AND period = inperiod
                     AND area1 = '4'
                     AND area2 = '4'
                     AND area3 = '0'
                GROUP BY profit_center,
                         end_customer_id,
                         company_code,
                         part_no,
                         project_type,
                         project_name,
                         pjm,
                         project_l1,
                         project_l2,
                         project_l3,
                         project_l4,
                         project_l5,
                         project_l6)
   LOOP
      a_amount_l := rec2.amt_local;
      a_amount_t := rec2.amt_twd;
      a_amount_u := rec2.amt_usd;
      a_counter := 0;

      BEGIN
         SELECT COUNT (*)
           INTO a_counter
           FROM pnl3_trx005_collect_pn
          WHERE r_kind = 'PL02'
            AND period = inperiod
            AND profit_center = rec2.profit_center
            AND company_code = rec2.company_code
            AND end_customer_id = rec2.end_customer_id
            AND part_no = rec2.part_no
            AND project_type = rec2.project_type
            AND project_name = rec2.project_name
            AND pjm = rec2.pjm
            AND project_l1 = rec2.project_l1
            AND project_l2 = rec2.project_l2
            AND project_l3 = rec2.project_l3
            AND project_l4 = rec2.project_l4
            AND project_l5 = rec2.project_l5
            AND project_l6 = rec2.project_l6
            AND area1 = '3'
            AND area2 = '0'
            AND area3 = '0';
      EXCEPTION
         WHEN OTHERS
         THEN
            a_counter := 0;
      END;

      IF a_counter = 0
      THEN
         INSERT INTO pnl3_trx005_collect_pn
                     (company_code, period, profit_center,
                      end_customer_id, amt_local, amt_usd,
                      amt_twd, SOURCE, r_kind, area1, area2, area3,
                      create_date, TYPE, part_no, project_type,
                      project_name, pjm, project_l1,
                      project_l2, project_l3, project_l4,
                      project_l5, project_l6
                     )
              VALUES (rec2.company_code, inperiod, rec2.profit_center,
                      rec2.end_customer_id, a_amount_l, a_amount_u,
                      a_amount_t, 'TOTAL', 'PL02', '4', '5', '0',
                      SYSDATE, 'SUM', rec2.part_no, rec2.project_type,
                      rec2.project_name, rec2.pjm, rec2.project_l1,
                      rec2.project_l2, rec2.project_l3, rec2.project_l4,
                      rec2.project_l5, rec2.project_l6
                     );

         COMMIT;
      END IF;
   END LOOP;
--呆帳金額,待user上傳
END pnl3_pls005_cat_gen_pn_trx;
/

