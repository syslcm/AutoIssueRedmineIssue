create PROCEDURE PNL_PLS002_CALU_DATA_SUB03 (
  inCompany  in VARCHAR2,
  f_YYYYMMDD in VARCHAR2,
  t_YYYYMMDD in VARCHAR2
)
AUTHID DEFINER
/*********************************************************************
  PROG-ID      : PNL_PLS002_CALU_DATA_SUB03
  PROG-ACTION  : (03-03M,04-06M,05-09M,06-12M)
               : AMOUNT
  Author       : KANGI
  Date         : 2007/03/27
**********************************************************************/
is
   iTracePoint  integer ;
   cErrorText varchar2(500) ;
   cPNL_YYYY PNL_TRX001_DATA.YEAR%TYPE;
   cRWF_YW  PNL_TRX001_DATA.RWF_YW%TYPE;
   cTOP_KIND PNL_TRX001_DATA.TOP_KIND%TYPE;
   cTOP_PERIOD PNL_TRX001_DATA.TOP_PERIOD%TYPE;
   iReduceMonth integer ;
   fUSD_TO_TWD_RATE float ;
   dRUNDATE DATE ;

 BEGIN
   iTracePoint := 100 ;
   cPNL_YYYY := TO_CHAR(SYSDATE,'YYYY');
   dRUNDATE := SYSDATE ;
   ----DELETE PNL_MSS001_BGT_DATA
   DELETE PNL_TRX001_DATA WHERE YEAR = cPNL_YYYY AND TOP_KIND IN ('03-PLN');
   iTracePoint := 300 ;
   COMMIT ;
   ---PROCESS PNL_PLS002_CALU_DATA_SUB03_01 (REVENUE)
   PNL_PLS002_CALU_DATA_SUB03_01(inCompany,f_YYYYMMDD,t_YYYYMMDD) ;
    COMMIT ;


   ---PROCESS PNL_PLS002_CALU_DATA_SUB03_02 (REVENUE)
   PNL_PLS002_CALU_DATA_SUB03_02(inCompany,f_YYYYMMDD,t_YYYYMMDD) ;


   COMMIT ;
 EXCEPTION
     WHEN OTHERS THEN
            --rollback ;
            cErrorText := SQLERRM() ;
            MAIL_FILE_BIDBDBADMIN(in_to_name=>'kangi@ms.usi.com.tw',subject   => 'PL/SQL PNL_PLS002_CALU_DATA_SUB03_01 ERROR', message => '[PNL_PLS002_CALU_DATA_SUB03_01], The tracepoint is  ' || to_char(iTracePoint) || 'and ErrorText=' || cErrorText) ;
            DBMS_OUTPUT.PUT_LINE(SUBSTR(cErrorText,1,255));
            DBMS_OUTPUT.PUT_LINE(TO_CHAR(iTracePoint));
END PNL_PLS002_CALU_DATA_SUB03;
/

