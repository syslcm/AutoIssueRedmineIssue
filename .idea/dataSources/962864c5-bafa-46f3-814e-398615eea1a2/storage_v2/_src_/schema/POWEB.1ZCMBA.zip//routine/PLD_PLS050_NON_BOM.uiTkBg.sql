create PROCEDURE       PLD_PLS050_NON_BOM (
/*********************************************************************
  PROG-ID      : PLD_PLS050_NON_BOM
  PROG-ACTION  : PLD_KPI_RTV_MONTH_PL_BY_MON Get Slow Moving by purchase department
  Author       : Asan Chang
  Date         : 2013/02/20
**********************************************************************
  Author       : Angeline Chen
  Date         : 2015/03/12
  Description  : add Col. MFRPN
**********************************************************************
  Author       : Asan Chang
  Global OA    : SAI085371
  Date         : 2018/07/03
  Description  : add Col. MFRNR
**********************************************************************/
   incompany    IN   VARCHAR2,
   f_yyyymmdd   IN   VARCHAR2,
   t_yyyymmdd   IN   VARCHAR2
)
AUTHID DEFINER
IS
   CURSOR pld_kpi_non_bom_ir_t
   IS
      SELECT COMPANY_CODE, PR_NO, PR_ITEM, REQUISTIONER, PO_NO, PO_ITEM, MATERIAL,
      DESCRIPTION, SHORT_TEXT, BUYER_CODE, BUYER_NAME, MATERIAL_GROUP, IR_QTY, 
      IR_PRICE, IR_CURRENCY, IR_EXCHANGE_RATE, PO_VENDER_CODE, ACCOUNT_ASSIGN,
      PROFIT_CENTER, COST_CENTER, ASSETS, SO_NO, SO_ITEM, GL_ACCOUNT, PO_CREATE_DT,
      PLANT, SLOC, IR_NO, IR_ITEM, IR_YEAR, IR_DATE, TEXT1, TEXT2, TEXT3, 
      TEXT4, TEXT5, TEXT6, PO_TEXT1, PO_TEXT2, PO_TEXT3, PO_TEXT4, PO_TEXT5, PO_TEXT6, 
      MFRPN, MFRNR
      FROM pld_kpi_non_bom_ir_t
      where IR_DATE >= f_yyyymmdd
      AND IR_DATE <= t_yyyymmdd
      AND COMPANY_CODE = incompany;

   t_CURRENCY_LOCAL    pld_kpi_non_bom_ir.IR_CURRENCY%TYPE;
   p_CURRENCY_LOCAL    pld_kpi_non_bom_ir.IR_CURRENCY%TYPE;
   a_EX_RATE_USD       pld_kpi_non_bom_ir.EX_RATE_USD%TYPE;
   a_EX_RATE_TWD       pld_kpi_non_bom_ir.EX_RATE_TWD%TYPE;
   a_SKIP        VARCHAR2 (1);
   itracepoint   INTEGER;
BEGIN


   --(1)清除舊的 pld_kpi_non_bom_ir 資料

   DELETE FROM pld_kpi_non_bom_ir
   where IR_DATE >= to_date(f_yyyymmdd, 'yyyy/mm/dd') 
   AND IR_DATE <= to_date(t_yyyymmdd, 'yyyy/mm/dd') 
   AND COMPANY_CODE = incompany;
   COMMIT;


   --(2)處理匯率
   FOR REC1 IN pld_kpi_non_bom_ir_t LOOP
   --抓CURRENCY_LOCAL
     t_CURRENCY_LOCAL := REC1.IR_CURRENCY;

     --計算匯率
     if t_CURRENCY_LOCAL = p_CURRENCY_LOCAL THEN
       a_SKIP := 'X';

     ELSE
       a_EX_RATE_TWD := NULL;
       a_EX_RATE_USD := NULL;

       a_EX_RATE_USD := Get_Exchange_Rate(SUBSTRB(REC1.IR_DATE,1,4),SUBSTRB(REC1.IR_DATE,5,2),t_CURRENCY_LOCAL,'USD','T') ;
       a_EX_RATE_TWD := Get_Exchange_Rate(SUBSTRB(REC1.IR_DATE,1,4),SUBSTRB(REC1.IR_DATE,5,2),t_CURRENCY_LOCAL,'TWD','T') ;
     END IF;


   --(3)開始處理資料
       INSERT INTO pld_kpi_non_bom_ir (
            COMPANY_CODE,        PR_NO,               PR_ITEM,             REQUISTIONER, 
            PO_NO,               PO_ITEM,             MATERIAL,            DESCRIPTION, 
            SHORT_TEXT,          BUYER_CODE,          BUYER_NAME,          MATERIAL_GROUP, 
            IR_QTY,              IR_PRICE,            IR_CURRENCY,         IR_EXCHANGE_RATE, 
            IR_LOCAL_AMT,        
            IR_TWD_AMT,          IR_USD_AMT,          
            EX_RATE_TWD,
            EX_RATE_USD,         PO_VENDER_CODE,      ACCOUNT_ASSIGN,      PROFIT_CENTER,  
            COST_CENTER,         ASSETS,              SO_NO,               SO_ITEM,         
            GL_ACCOUNT,          PO_CREATE_DT,                    
            PLANT,               SLOC, 
            IR_NO,               IR_ITEM,             IR_YEAR,             
            IR_DATE, 
            TEXT1,               TEXT2,               TEXT3,               TEXT4, 
            TEXT5,               TEXT6,               PO_TEXT1,            PO_TEXT2,               
            PO_TEXT3,            PO_TEXT4,            PO_TEXT5,            PO_TEXT6, 
            MFRPN,               MFRNR
            ) VALUES (
                 
            REC1.COMPANY_CODE,   REC1.PR_NO,          REC1.PR_ITEM,        REC1.REQUISTIONER, 
            REC1.PO_NO,          REC1.PO_ITEM,        REC1.MATERIAL,       REC1.DESCRIPTION, 
            REC1.SHORT_TEXT,     REC1.BUYER_CODE,     REC1.BUYER_NAME,     REC1.MATERIAL_GROUP, 
            REC1.IR_QTY,         REC1.IR_PRICE,       REC1.IR_CURRENCY,    REC1.IR_EXCHANGE_RATE, 
            REC1.IR_PRICE,       
            ROUND(REC1.IR_PRICE * a_EX_RATE_TWD, 5),  ROUND(REC1.IR_PRICE * a_EX_RATE_USD, 5),     
            a_EX_RATE_TWD,
            a_EX_RATE_USD,       REC1.PO_VENDER_CODE, REC1.ACCOUNT_ASSIGN, REC1.PROFIT_CENTER,  
            REC1.COST_CENTER,    REC1.ASSETS,         REC1.SO_NO,          REC1.SO_ITEM,         
            REC1.GL_ACCOUNT,     to_date(REC1.PO_CREATE_DT, 'yyyy/mm/dd'),   
            REC1.PLANT,          REC1.SLOC, 
            REC1.IR_NO,          REC1.IR_ITEM,        REC1.IR_YEAR,        
            to_date(REC1.IR_DATE, 'yyyy/mm/dd'), 
            REC1.TEXT1,          REC1.TEXT2,          REC1.TEXT3,          REC1.TEXT4, 
            REC1.TEXT5,          REC1.TEXT6,          REC1.PO_TEXT1,       REC1.PO_TEXT2,          
            REC1.PO_TEXT3,       REC1.PO_TEXT4,       REC1.PO_TEXT5,       REC1.PO_TEXT6,
            REC1.MFRPN ,         REC1.MFRNR           
             );    
       COMMIT;

     p_CURRENCY_LOCAL := t_CURRENCY_LOCAL;
   END LOOP;

   --(4) 刪除資料


   DELETE FROM pld_kpi_non_bom_ir_t
   where IR_DATE >= f_yyyymmdd
   AND IR_DATE <= t_yyyymmdd
   AND COMPANY_CODE = incompany;
   COMMIT;

   --(4) Send Mail
END PLD_PLS050_NON_BOM;
/

