create PROCEDURE       "PLS_PLS002_GET_AF_DATA" (
  f_YYYYMM in VARCHAR2
)
AUTHID DEFINER
/*********************************************************************
  PROG-ID      : PLS_PLS002_GET_AF_DATA
                 ( called by ??? - 每次重新計算 by Site分攤EM資料時)
  PROG-ACTION  : 由 AFR_UPL001_AF_REPORT_DATA ＆ PNL_MSA001_EM_DATA &
                 PLS_PST004_ADJ
                 產生 (1)AF Data, (2)EM-AF Data, (3)EM after Adj. by Site
                 => PLS_PST005_AF_DATA
  Author       : KATHY
  Date         : 2014/06/20
  OA No.       : SAI043515
 ======================================================================                 
--Modify       : 2019/08/29 - SAI104649 - Kathy
--                      1.PNL_MSA001_EM_DATA Mapping to PNL_MAP007_ACCMAPPING
--                      2.Use PNL_MAP007_ACCMAPPING.ACCT_ID_AF to replace
--                           PNL_MSA001_EM_DATA.ACCT_ID 
-- 2020/01/30 SAI110406 Pattty Modify:
--                      1.Delete Old Process Source
--                      2.Call Procedure PLS_PLS002_GET_AF_DATA_ALL ＆ PLS_PLS002_GET_AF_DATA_UG
-- 2020/02/19 SAI114678 Pattty ADD Call Procedure PLS_PLS002_GET_AF_DATA_NUG
**********************************************************************/
is

  w_PERIOD           VARCHAR2(6);
BEGIN

-- << SAI110406 Begin --
  w_PERIOD := SUBSTRB(f_YYYYMM,1,6);

  --Exec Store Procedure
  PLS_PLS002_GET_AF_DATA_ALL(w_PERIOD);
  PLS_PLS002_GET_AF_DATA_UG(w_PERIOD);
  PLS_PLS002_GET_AF_DATA_NUG(w_PERIOD);               --SAI114678
-- -- SAI110406 End -->>

--
-- -------------------------------------------------------------------------------

END PLS_PLS002_GET_AF_DATA;
/

