create PROCEDURE test_pls_update
IS
   CURSOR PPQ_CUR
   is
    SELECT ROWID AS RID
	FROM PPQ_PRODUCT_PRICE_QUOTATION_H ;
 begin
    FOR PPQ_REC in PPQ_CUR  LOOP
	    BEGIN
          UPDATE PPQ_PRODUCT_PRICE_QUOTATION_H SET QUOTE_DATE = to_char(to_date(QUOTE_DATE,'Month.dd, YYYY','NLS_DATE_LANGUAGE = American'),'YYYYMMDD') || 'A0'
		  WHERE ROWID = PPQ_REC.RID ;
		  COMMIT;
		EXCEPTION
                 WHEN OTHERS THEN
                 NULL  ;
        END ;
    END LOOP ;
END test_pls_update ;
/

