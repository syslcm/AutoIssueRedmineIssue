create PROCEDURE PLSQL_PMI_WIP001_AMT(
  inCompany  in PMI_WIP001_AMT.COMPANY_CODE%TYPE,
  f_YYYYMMDD in VARCHAR2,
  t_YYYYMMDD in VARCHAR2
)
is
 iTracePoint  integer ;
 cErrorText varchar2(500);
 vPROCEE_YYYYMMDD varchar2(8);

BEGIN
  iTracePoint := '000';


  vPROCEE_YYYYMMDD  :=  to_char(sysdate-1,'YYYYMMDD');

  DELETE FROM PMI_WIP001_AMT WHERE COMPANY_CODE =inCompany
     and WIP_DATE = vPROCEE_YYYYMMDD;

  iTracePoint := '100';
  Insert into PMI_WIP001_AMT (
        COMPANY_CODE , PLANT , WIP_DATE , DEPARTMENT , ORDER_NUMBER , PART_NO , PN_DESC , WIP_QTY , PRICE    )
   Select  COMPANY_CODE , PLANT , WIP_DATE , DEPARTMENT , ORDER_NUMBER , PART_NO , PN_DESC , WIP_QTY , PRICE
     from PMI_WIP001_AMT_T
    where COMPANY_CODE= inCompany
      and WIP_DATE = vPROCEE_YYYYMMDD;

   iTracePoint := '200';
   DELETE  from PMI_WIP001_AMT_T
    where COMPANY_CODE = inCompany
      and WIP_DATE = vPROCEE_YYYYMMDD;



   Commit;
EXCEPTION
   When OTHERS Then
    --有錯誤產生則寄mail
    cErrorText := SQLERRM();
    MAIL_FILE_BIDBDBADMIN(in_to_name => 'sam_chen@ms.usi.com.tw', subject => '[VRT] PL/SQL PMI_WIP001_AMT ERROR', message => '[PMI_WIP001_AMT], The tracepoint is  ' || iTracePoint || ' and ErrorText= ' || cErrorText) ;


END PLSQL_PMI_WIP001_AMT;
/

