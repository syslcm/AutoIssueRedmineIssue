create PROCEDURE       "ROIC_PLS019_FINAL_RPT_PC_V2" (
  in_YYYYMM1       IN   VARCHAR2,
  in_GRP_CODE      IN   VARCHAR2
)
AUTHID DEFINER
/* 
 ****************************************************************************************
  PROG-ID      :  ROIC_PLS019_FINAL_RPT_PC_V2
  PROG-ACTION  :   
  Author       : Asan Chang
  Date         : 2020/03/03
  OA No.       : SAI115487
 ************************************************************************************
 2020/03/05 SAI115487 Asan Chang
 1. PC is null -> PC replace by '0000000099'
 2. INC = N & UG = N which don't insert ROIC_PST019_FINAL_RPT_PC
 3. AP/AR add limit Group1 = AP/AR
 4. Amount of 00060(COGS)~00120(SG&A) need to * (-1)
 ************************************************************************************
  2020/03/05 SAI115487 Asan Chang cancel 00120(SG&A) * (-1)
  2020/03/09 SAI115487 Asan Chang AM PC = NOT FOUND -> replace by '0000000099'
  2020/03/10 SAI115487 Asan Chang add in_GRP_CODE & change table schema ROIC_PST019_FINAL_RPT_PC
  2020/03/11 SAI115487 Asan Chang
  1.S_DECS 80~110 �O�^��New Profit Center & Group1
  2.S_DECS 280 : Subtotal=Min. Cash+Working Capital+PP&E
  2020/03/13 SAI115487 Asan Chang  
  ���� S_DESC 240? NI �]after tax�^=Current NI �]after tax�^ rolling 12 months(�Y���e�[12����)
   2020/04/10 SAI118200 Asan Chang �w������������0
 ************************************************************************************ 
 */
is
   iReccnt              integer;
   In_YYYY              DIMENSION_DATE.YYYY%TYPE;
   In_MM                DIMENSION_DATE.MM%TYPE; 
   In_PERIOD            DIMENSION_DATE.YYYYMM%TYPE;
   From_PERIOD          DIMENSION_DATE.YYYYMM%TYPE; 
   DATE_TRANS           varchar2(10);
   sPROC_NAME           ROIC_PST000_LOG.PROC_NAME%TYPE;
   sRUN_SEQ             ROIC_PST000_LOG.RUN_SEQ%TYPE;
   sRUN_DESC            ROIC_PST000_LOG.RUN_DESC%TYPE;
   sPARAMETER_DESC      ROIC_PST000_LOG.PARAMETER_DESC%TYPE;   
   L_CNT                NUMBER(6);
   L_waers_loc2         varchar2(30);
   iTracePoint          integer ; 
   In_MM2               integer ;
   inCompany            ROA_PST004_FIXED_ASSETS.COMPANY_CODE%TYPE;
   STR01                varchar2(30);
   STR02                varchar2(30);
   STR03                varchar2(30);
   STR04                varchar2(30);
   STR06                varchar2(30); 
   STR07                varchar2(30); 
   REPLACE_PC           varchar2(10); 
   NOT_FOUND_STR        varchar2(10); 
   --GRP_CODE_STR         varchar2(30);   
   TMP_OPTION1          NUMBER(15,5); 
   TMP_OPTION2          NUMBER(15,5);   
   TMP_AMT1             NUMBER(15,5);
   TMP_AMT2             NUMBER(15,5); 
   TMP_AMT3             NUMBER(15,5);
   TMP_AMT4             NUMBER(15,5);   
BEGIN
--
  In_YYYY := SUBSTR( in_YYYYMM1, 1, 4);
  In_MM := SUBSTR( in_YYYYMM1, 5, 2); 
  In_MM2 := In_MM;
  In_PERIOD := In_YYYY || In_MM;
  --In_KIND := in_Kind1;
  DATE_TRANS := In_YYYY ||'-'|| In_MM || '-01';

  sPROC_NAME := 'ROIC_PLS019_FINAL_RPT_PC_V2';
  sRUN_SEQ   := '000010';
  sRUN_DESC  := 'Start';
  sPARAMETER_DESC := CONCAT(CONCAT(CONCAT('s_PERIOD=',In_PERIOD),';t_PERIOD='),In_PERIOD);
  REPLACE_PC := '0000000099';
  NOT_FOUND_STR := 'NO FOUND';

  if in_GRP_CODE = 'UG' Then
      TMP_OPTION1  := 1;  
      TMP_OPTION2  := 2;
  else
      TMP_OPTION1  := 2;  
      TMP_OPTION2  := 1;
  end if; 
  
  
  --Insert Log
  INSERT INTO ROIC_PST000_LOG
      ( PROC_NAME, RUN_SEQ, RUN_DESC, PARAMETER_DESC )
    VALUES
      ( sPROC_NAME, sRUN_SEQ, sRUN_DESC, sPARAMETER_DESC );
  Commit;

  --Delete old data
  delete ROIC_PST019_FINAL_RPT_PC WHERE PERIOD = In_PERIOD and GRP_CODE = in_GRP_CODE;
  COMMIT ;   
  
  --get from period
  for REC_PERIOD IN (
    (select TO_CHAR(add_months(TO_DATE(DATE_TRANS, 'YYYY-MM-DD'),-11),'YYYYMM') FROM_PERIOD from dual )
  )
  LOOP
    From_PERIOD := REC_PERIOD.FROM_PERIOD;                 
  END LOOP;
  
  /* ****************************************************************************************
      (0-1)00010	AR
  ************************************************************************************ */
      STR01 :=  '00010';
      for REC1 IN (
	    --SQL
        /*
		select COMPANY_CODE, PERIOD, PROFIT_CENTER ,INC, UG ,
        sum(EVALUATION_AMT_TWD) AMOUNT_TWD, sum(EVALUATION_AMT_USD) AMOUNT_USD, sum(EVALUATION_AMT_CNY) AMOUNT_CNY
        from roic_vew011_ar_trx_ga
        where PERIOD = In_PERIOD
        group by COMPANY_CODE, PERIOD, PROFIT_CENTER ,INC, UG
        order by COMPANY_CODE, PERIOD, PROFIT_CENTER ,INC, UG	
		*/
	    select PERIOD, PROFIT_CENTER ,
	    sum(AMOUNT_TWD) AMOUNT_TWD, sum(AMOUNT_USD) AMOUNT_USD, sum(AMOUNT_CNY) AMOUNT_CNY
	    from
	    (
	        select PERIOD, NVL( TRIM(PROFIT_CENTER) , REPLACE_PC) PROFIT_CENTER ,INC , UG,
	        sum(EVALUATION_AMT_TWD) AMOUNT_TWD, sum(EVALUATION_AMT_USD) AMOUNT_USD, sum(EVALUATION_AMT_CNY) AMOUNT_CNY
	        from roic_vew011_ar_trx_ga
	        where 
		
			PERIOD = In_PERIOD
			and GROUP1 = 'AR'
			--and ( INC = 'Y' OR UG = 'Y' )
			and (( INC = 'Y' AND 1 = TMP_OPTION2 ) OR ( UG = 'Y' AND 1 = TMP_OPTION1 ))
	        group by PERIOD, PROFIT_CENTER ,INC, UG
	        order by PERIOD, PROFIT_CENTER ,INC, UG
        )
	    group by PERIOD, PROFIT_CENTER 
	    order by PERIOD, PROFIT_CENTER		
      )
      LOOP
        INSERT INTO ROIC_PST019_FINAL_RPT_PC
         ( PERIOD, PC, GRP_CODE,S_DESC, AMOUNT_TWD, AMOUNT_USD, AMOUNT_CNY) 
        VALUES
         ( In_PERIOD , REC1.PROFIT_CENTER,in_GRP_CODE,STR01, REC1.AMOUNT_TWD, REC1.AMOUNT_USD, REC1.AMOUNT_CNY);    
	  END LOOP;  

  /* ****************************************************************************************
      (0-2)00020	INV
  ************************************************************************************ */
      STR01 :=  '00020';
      for REC1 IN (
	    --SQL
		/*
	    select COMPANY_CODE, PERIOD, PROFIT_CENTER ,INC, UG ,
	    sum(AMOUNT_TWD) AMOUNT_TWD, sum(AMOUNT_USD) AMOUNT_USD, sum(AMOUNT_CNY) AMOUNT_CNY
	    from roic_vew015_inv_ga
	    where PERIOD = In_PERIOD
	    group by COMPANY_CODE, PERIOD, PROFIT_CENTER ,INC, UG
	    order by COMPANY_CODE, PERIOD, PROFIT_CENTER ,INC, UG
		*/
	    select PERIOD, PROFIT_CENTER ,
	    sum(AMOUNT_TWD) AMOUNT_TWD, sum(AMOUNT_USD) AMOUNT_USD, sum(AMOUNT_CNY) AMOUNT_CNY
	    from
	    (
	        select PERIOD, NVL( TRIM(PROFIT_CENTER) , REPLACE_PC) PROFIT_CENTER ,INC, UG ,
	        sum(AMOUNT_TWD) AMOUNT_TWD, sum(AMOUNT_USD) AMOUNT_USD, sum(AMOUNT_CNY) AMOUNT_CNY
	        from roic_vew015_inv_ga
	        where PERIOD = In_PERIOD
			--and ( INC = 'Y' OR UG = 'Y' )
			and (( INC = 'Y' AND 1 = TMP_OPTION2 ) OR ( UG = 'Y' AND 1 = TMP_OPTION1 ))
	        group by PERIOD, PROFIT_CENTER ,INC, UG
	        order by PERIOD, PROFIT_CENTER ,INC, UG
        )
	    group by PERIOD, PROFIT_CENTER 
	    order by PERIOD, PROFIT_CENTER 	
      )
      LOOP
        INSERT INTO ROIC_PST019_FINAL_RPT_PC
         ( PERIOD, PC, GRP_CODE,S_DESC, AMOUNT_TWD, AMOUNT_USD, AMOUNT_CNY) 
        VALUES
         ( In_PERIOD , REC1.PROFIT_CENTER,in_GRP_CODE,STR01, REC1.AMOUNT_TWD, REC1.AMOUNT_USD, REC1.AMOUNT_CNY);    
	  END LOOP;

  /* ****************************************************************************************
      (0-3)00030	AP
  ************************************************************************************ */
      STR01 :=  '00030';
      for REC1 IN (
	    --SQL
		/*
        select COMPANY_CODE, PERIOD, PROFIT_CENTER ,INC, UG ,
        sum(EVALUATION_AMT_TWD) AMOUNT_TWD, sum(EVALUATION_AMT_USD) AMOUNT_USD, sum(EVALUATION_AMT_CNY) AMOUNT_CNY
        from roic_vew010_ap_trx_ga
	    where PERIOD = In_PERIOD
        group by COMPANY_CODE, PERIOD, PROFIT_CENTER ,INC, UG
        order by COMPANY_CODE, PERIOD, PROFIT_CENTER ,INC, UG
		*/
	    select PERIOD, PROFIT_CENTER ,
	    sum(AMOUNT_TWD) AMOUNT_TWD, sum(AMOUNT_USD) AMOUNT_USD, sum(AMOUNT_CNY) AMOUNT_CNY
	    from
	    (
	        select PERIOD, NVL( TRIM(PROFIT_CENTER) , REPLACE_PC) PROFIT_CENTER ,INC, UG ,
	        sum(EVALUATION_AMT_TWD) AMOUNT_TWD, sum(EVALUATION_AMT_USD) AMOUNT_USD, sum(EVALUATION_AMT_CNY) AMOUNT_CNY
	        from roic_vew010_ap_trx_ga
	        where PERIOD = In_PERIOD
			and GROUP1 = 'AP'
			--and ( INC = 'Y' OR UG = 'Y' )
			and (( INC = 'Y' AND 1 = TMP_OPTION2 ) OR ( UG = 'Y' AND 1 = TMP_OPTION1 ))
	        group by PERIOD, PROFIT_CENTER ,INC, UG
	        order by PERIOD, PROFIT_CENTER ,INC, UG
        )
	    group by PERIOD, PROFIT_CENTER
	    order by PERIOD, PROFIT_CENTER		
		
      )
      LOOP
        INSERT INTO ROIC_PST019_FINAL_RPT_PC
         ( PERIOD, PC, GRP_CODE,S_DESC, AMOUNT_TWD, AMOUNT_USD, AMOUNT_CNY) 
        VALUES
         ( In_PERIOD , REC1.PROFIT_CENTER,in_GRP_CODE,STR01, REC1.AMOUNT_TWD, REC1.AMOUNT_USD, REC1.AMOUNT_CNY);    
	  END LOOP;  
	   
  /* ****************************************************************************************
      (0-4)00040 	FA-Land
  ************************************************************************************ */
      STR01 :=  '00040';
      for REC1 IN (
	    --SQL
		/*
        select COMPANY_CODE, PERIOD, PC PROFIT_CENTER ,INC, UG ,
        sum(BOOK_VAL_TWD) AMOUNT_TWD, sum(BOOK_VAL_USD) AMOUNT_USD, sum(BOOK_VAL_CNY) AMOUNT_CNY
        from roic_vew016_am_ga
        where PERIOD = In_PERIOD
        and  ( S_SEQ >= '10'  AND S_SEQ <= '19' )
        group by COMPANY_CODE, PERIOD, PC ,INC, UG
        order by COMPANY_CODE, PERIOD, PC ,INC, UG
		*/
	    select PERIOD, PROFIT_CENTER ,
	    sum(AMOUNT_TWD) AMOUNT_TWD, sum(AMOUNT_USD) AMOUNT_USD, sum(AMOUNT_CNY) AMOUNT_CNY
	    from
	    (
	        select PERIOD, DECODE(NVL( TRIM(PC) , REPLACE_PC),NOT_FOUND_STR,REPLACE_PC,PC) PROFIT_CENTER ,INC, UG ,
	        sum(BOOK_VAL_TWD) AMOUNT_TWD, sum(BOOK_VAL_USD) AMOUNT_USD, sum(BOOK_VAL_CNY) AMOUNT_CNY
	        from roic_vew016_am_ga
	        where PERIOD = In_PERIOD
			and (( INC = 'Y' AND 1 = TMP_OPTION2 ) OR ( UG = 'Y' AND 1 = TMP_OPTION1 ))
			and  ( S_SEQ >= '10'  AND S_SEQ <= '19' )
	        group by PERIOD, PC ,INC, UG
	        order by PERIOD, PC,INC, UG
        )
	    group by PERIOD, PROFIT_CENTER
	    order by PERIOD, PROFIT_CENTER		
		
      )
      LOOP
        INSERT INTO ROIC_PST019_FINAL_RPT_PC
         ( PERIOD, PC, GRP_CODE,S_DESC, AMOUNT_TWD, AMOUNT_USD, AMOUNT_CNY) 
        VALUES
         ( In_PERIOD , REC1.PROFIT_CENTER,in_GRP_CODE,STR01, REC1.AMOUNT_TWD, REC1.AMOUNT_USD, REC1.AMOUNT_CNY);    
	  END LOOP;  

  /* ****************************************************************************************
      (0-5)00041 	FA-Building
  ************************************************************************************ */
      STR01 :=  '00041';
      for REC1 IN (
	    --SQL
        /*
		select COMPANY_CODE, PERIOD, PC PROFIT_CENTER ,INC, UG ,
        sum(BOOK_VAL_TWD) AMOUNT_TWD, sum(BOOK_VAL_USD) AMOUNT_USD, sum(BOOK_VAL_CNY) AMOUNT_CNY

        from roic_vew016_am_ga
        where PERIOD = In_PERIOD
        and  ( S_SEQ >= '20'  AND S_SEQ <= '29' )
        group by COMPANY_CODE, PERIOD, PC ,INC, UG
        order by COMPANY_CODE, PERIOD, PC ,INC, UG
		*/
	    select PERIOD, PROFIT_CENTER ,
	    sum(AMOUNT_TWD) AMOUNT_TWD, sum(AMOUNT_USD) AMOUNT_USD, sum(AMOUNT_CNY) AMOUNT_CNY
	    from
	    (
	        select PERIOD, DECODE(NVL( TRIM(PC) , REPLACE_PC),NOT_FOUND_STR,REPLACE_PC,PC) PROFIT_CENTER ,INC, UG ,
	        sum(BOOK_VAL_TWD) AMOUNT_TWD, sum(BOOK_VAL_USD) AMOUNT_USD, sum(BOOK_VAL_CNY) AMOUNT_CNY
	        from roic_vew016_am_ga
	        where PERIOD = In_PERIOD
			and (( INC = 'Y' AND 1 = TMP_OPTION2 ) OR ( UG = 'Y' AND 1 = TMP_OPTION1 ))
			and  ( S_SEQ >= '20'  AND S_SEQ <= '29' )
	        group by PERIOD, PC ,INC, UG
	        order by PERIOD, PC,INC, UG
        )
	    group by PERIOD, PROFIT_CENTER 
	    order by PERIOD, PROFIT_CENTER		
      )
      LOOP
        INSERT INTO ROIC_PST019_FINAL_RPT_PC
         ( PERIOD, PC, GRP_CODE,S_DESC, AMOUNT_TWD, AMOUNT_USD, AMOUNT_CNY) 
        VALUES
         ( In_PERIOD , REC1.PROFIT_CENTER,in_GRP_CODE,STR01, REC1.AMOUNT_TWD, REC1.AMOUNT_USD, REC1.AMOUNT_CNY);    
	  END LOOP; 

  /* ****************************************************************************************
      (0-6)00042 	FA-Equipment
  ************************************************************************************ */
      STR01 :=  '00042';
      for REC1 IN (
	    --SQL
        /*
		select COMPANY_CODE, PERIOD, PC PROFIT_CENTER ,INC, UG ,
        sum(BOOK_VAL_TWD) AMOUNT_TWD, sum(BOOK_VAL_USD) AMOUNT_USD, sum(BOOK_VAL_CNY) AMOUNT_CNY

        from roic_vew016_am_ga
        where PERIOD = In_PERIOD
        and  ( S_SEQ >= '30'  AND S_SEQ <= '39' )
        group by COMPANY_CODE, PERIOD, PC ,INC, UG
        order by COMPANY_CODE, PERIOD, PC ,INC, UG
		*/
	    select PERIOD, PROFIT_CENTER ,
	    sum(AMOUNT_TWD) AMOUNT_TWD, sum(AMOUNT_USD) AMOUNT_USD, sum(AMOUNT_CNY) AMOUNT_CNY
	    from
	    (
	        select PERIOD, DECODE(NVL( TRIM(PC) , REPLACE_PC),NOT_FOUND_STR,REPLACE_PC,PC) PROFIT_CENTER ,INC, UG ,
	        sum(BOOK_VAL_TWD) AMOUNT_TWD, sum(BOOK_VAL_USD) AMOUNT_USD, sum(BOOK_VAL_CNY) AMOUNT_CNY
	        from roic_vew016_am_ga
	        where PERIOD = In_PERIOD
			and (( INC = 'Y' AND 1 = TMP_OPTION2 ) OR ( UG = 'Y' AND 1 = TMP_OPTION1 ))
			and  ( S_SEQ >= '30'  AND S_SEQ <= '39' )
	        group by PERIOD, PC ,INC, UG
	        order by PERIOD, PC,INC, UG
        )
	    group by PERIOD, PROFIT_CENTER 
	    order by PERIOD, PROFIT_CENTER			
      )
      LOOP
        INSERT INTO ROIC_PST019_FINAL_RPT_PC
         ( PERIOD, PC, GRP_CODE,S_DESC, AMOUNT_TWD, AMOUNT_USD, AMOUNT_CNY) 
        VALUES
         ( In_PERIOD , REC1.PROFIT_CENTER,in_GRP_CODE,STR01, REC1.AMOUNT_TWD, REC1.AMOUNT_USD, REC1.AMOUNT_CNY);    
	  END LOOP; 

  /* ****************************************************************************************
      (0-7)00043 	FA-Others
  ************************************************************************************ */
      STR01 :=  '00043';
      for REC1 IN (
	    --SQL
		/*
        select COMPANY_CODE, PERIOD, PC PROFIT_CENTER ,INC, UG ,
        sum(BOOK_VAL_TWD) AMOUNT_TWD, sum(BOOK_VAL_USD) AMOUNT_USD, sum(BOOK_VAL_CNY) AMOUNT_CNY

        from roic_vew016_am_ga
        where PERIOD = In_PERIOD
        and  ( ( S_SEQ >= '40'  AND S_SEQ <= '49' ) OR ( S_SEQ >= '60'  AND S_SEQ <= '69' ) )
        group by COMPANY_CODE, PERIOD, PC ,INC, UG
        order by COMPANY_CODE, PERIOD, PC ,INC, UG
		*/
	    select PERIOD, PROFIT_CENTER ,
	    sum(AMOUNT_TWD) AMOUNT_TWD, sum(AMOUNT_USD) AMOUNT_USD, sum(AMOUNT_CNY) AMOUNT_CNY
	    from
	    (
	        select PERIOD,DECODE(NVL( TRIM(PC) , REPLACE_PC),NOT_FOUND_STR,REPLACE_PC,PC) PROFIT_CENTER ,INC, UG ,
	        sum(BOOK_VAL_TWD) AMOUNT_TWD, sum(BOOK_VAL_USD) AMOUNT_USD, sum(BOOK_VAL_CNY) AMOUNT_CNY
	        from roic_vew016_am_ga
	        where PERIOD = In_PERIOD
			and (( INC = 'Y' AND 1 = TMP_OPTION2 ) OR ( UG = 'Y' AND 1 = TMP_OPTION1 ))
            and  ( ( S_SEQ >= '40'  AND S_SEQ <= '49' ) OR ( S_SEQ >= '60'  AND S_SEQ <= '69' ) )
	        group by PERIOD, PC ,INC, UG
	        order by PERIOD, PC,INC, UG
        )
	    group by PERIOD, PROFIT_CENTER 
	    order by PERIOD, PROFIT_CENTER			
      )
      LOOP
        INSERT INTO ROIC_PST019_FINAL_RPT_PC
         ( PERIOD, PC, GRP_CODE,S_DESC, AMOUNT_TWD, AMOUNT_USD, AMOUNT_CNY) 
        VALUES
         ( In_PERIOD , REC1.PROFIT_CENTER,in_GRP_CODE,STR01, REC1.AMOUNT_TWD, REC1.AMOUNT_USD, REC1.AMOUNT_CNY);    
	   END LOOP;   

  /* ****************************************************************************************
      (0-8)00044	FA-Land Occupy	
  ************************************************************************************ */
      STR01 :=  '00044';
      for REC1 IN (
	    --SQL
		/*
        select COMPANY_CODE, PERIOD, PC PROFIT_CENTER ,INC, UG ,
        sum(BOOK_VAL_TWD) AMOUNT_TWD, sum(BOOK_VAL_USD) AMOUNT_USD, sum(BOOK_VAL_CNY) AMOUNT_CNY

        from roic_vew016_am_ga
        where PERIOD = In_PERIOD
        and  ( S_SEQ >= '50'  AND S_SEQ <= '59' ) 
        group by COMPANY_CODE, PERIOD, PC ,INC, UG
        order by COMPANY_CODE, PERIOD, PC ,INC, UG
		*/
	    select PERIOD, PROFIT_CENTER ,
	    sum(AMOUNT_TWD) AMOUNT_TWD, sum(AMOUNT_USD) AMOUNT_USD, sum(AMOUNT_CNY) AMOUNT_CNY
	    from
	    (
	        select PERIOD, DECODE(NVL( TRIM(PC) , REPLACE_PC),NOT_FOUND_STR,REPLACE_PC,PC) PROFIT_CENTER ,INC, UG ,
	        sum(BOOK_VAL_TWD) AMOUNT_TWD, sum(BOOK_VAL_USD) AMOUNT_USD, sum(BOOK_VAL_CNY) AMOUNT_CNY
	        from roic_vew016_am_ga
	        where PERIOD = In_PERIOD
			and (( INC = 'Y' AND 1 = TMP_OPTION2 ) OR ( UG = 'Y' AND 1 = TMP_OPTION1 ))
            and  ( S_SEQ >= '50'  AND S_SEQ <= '59' )
	        group by PERIOD, PC ,INC, UG
	        order by PERIOD, PC,INC, UG
        )
	    group by PERIOD, PROFIT_CENTER 
	    order by PERIOD, PROFIT_CENTER		
		
      )
      LOOP
        INSERT INTO ROIC_PST019_FINAL_RPT_PC
         ( PERIOD, PC, GRP_CODE,S_DESC, AMOUNT_TWD, AMOUNT_USD, AMOUNT_CNY) 
        VALUES
         ( In_PERIOD , REC1.PROFIT_CENTER,in_GRP_CODE,STR01, REC1.AMOUNT_TWD, REC1.AMOUNT_USD, REC1.AMOUNT_CNY);    
	  END LOOP;  

  /* ****************************************************************************************
      (0-9)00050	REV
  ************************************************************************************ */
      STR01 :=  '00050';
      for REC1 IN (
	    --SQL
	    /*
		select COMPANY_CODE, PERIOD, PROFIT_CENTER ,INC, UG ,
	    sum(NET_REVENUE_TWD) AMOUNT_TWD, sum(NET_REVENUE_USD) AMOUNT_USD, sum(NET_REVENUE_CNY) AMOUNT_CNY

	    from roic_vew014_copa_pca_ga
	    where PERIOD = In_PERIOD
	    group by COMPANY_CODE, PERIOD, PROFIT_CENTER ,INC, UG
	    order by COMPANY_CODE, PERIOD, PROFIT_CENTER ,INC, UG
		*/
	    select PERIOD, PROFIT_CENTER ,
	    sum(AMOUNT_TWD) AMOUNT_TWD, sum(AMOUNT_USD) AMOUNT_USD, sum(AMOUNT_CNY) AMOUNT_CNY
	    from
	    (
	        select PERIOD, NVL( TRIM(PROFIT_CENTER) , REPLACE_PC) PROFIT_CENTER ,INC, UG ,
	        sum(NET_REVENUE_TWD) AMOUNT_TWD, sum(NET_REVENUE_USD) AMOUNT_USD, sum(NET_REVENUE_CNY) AMOUNT_CNY
	        from roic_vew014_copa_pca_ga
	        where PERIOD = In_PERIOD
			--and ( INC = 'Y' OR UG = 'Y' )
			and (( INC = 'Y' AND 1 = TMP_OPTION2 ) OR ( UG = 'Y' AND 1 = TMP_OPTION1 ))
	        group by PERIOD, PROFIT_CENTER ,INC, UG
	        order by PERIOD, PROFIT_CENTER ,INC, UG
        )
	    group by PERIOD, PROFIT_CENTER 
	    order by PERIOD, PROFIT_CENTER		
		
      )
      LOOP
        INSERT INTO ROIC_PST019_FINAL_RPT_PC
         ( PERIOD, PC, GRP_CODE,S_DESC, AMOUNT_TWD, AMOUNT_USD, AMOUNT_CNY) 
        VALUES
         ( In_PERIOD , REC1.PROFIT_CENTER,in_GRP_CODE,STR01, REC1.AMOUNT_TWD, REC1.AMOUNT_USD, REC1.AMOUNT_CNY);    
	  END LOOP; 

  /* ****************************************************************************************
      (0-10)00060	COGS
  ************************************************************************************ */
      -- *(-1)
	  STR01 :=  '00060';
      for REC1 IN (
	    --SQL
	    /*
		select COMPANY_CODE, PERIOD, PROFIT_CENTER ,INC, UG ,
	    sum(NET_COGS_TWD) AMOUNT_TWD, sum(NET_COGS_USD) AMOUNT_USD, sum(NET_COGS_CNY) AMOUNT_CNY

	    from roic_vew014_copa_pca_ga
	    where PERIOD = In_PERIOD
	    group by COMPANY_CODE, PERIOD, PROFIT_CENTER ,INC, UG
	    order by COMPANY_CODE, PERIOD, PROFIT_CENTER ,INC, UG
		*/
	    select PERIOD, PROFIT_CENTER ,
	    sum(AMOUNT_TWD) AMOUNT_TWD, sum(AMOUNT_USD) AMOUNT_USD, sum(AMOUNT_CNY) AMOUNT_CNY
	    from
	    (
	        select PERIOD, NVL( TRIM(PROFIT_CENTER) , REPLACE_PC) PROFIT_CENTER ,INC, UG ,
	        sum(NET_COGS_TWD) AMOUNT_TWD, sum(NET_COGS_USD) AMOUNT_USD, sum(NET_COGS_CNY) AMOUNT_CNY
	        from roic_vew014_copa_pca_ga
	        where PERIOD = In_PERIOD
			--and ( INC = 'Y' OR UG = 'Y' )
			and (( INC = 'Y' AND 1 = TMP_OPTION2 ) OR ( UG = 'Y' AND 1 = TMP_OPTION1 ))
	        group by PERIOD, PROFIT_CENTER ,INC, UG
	        order by PERIOD, PROFIT_CENTER ,INC, UG
        )
	    group by PERIOD, PROFIT_CENTER 
	    order by PERIOD, PROFIT_CENTER				
      )
      LOOP
        INSERT INTO ROIC_PST019_FINAL_RPT_PC
         ( PERIOD, PC,GRP_CODE, S_DESC, AMOUNT_TWD, AMOUNT_USD, AMOUNT_CNY) 
        VALUES
         ( In_PERIOD , REC1.PROFIT_CENTER,in_GRP_CODE,STR01, (REC1.AMOUNT_TWD * -1), (REC1.AMOUNT_USD* -1), (REC1.AMOUNT_CNY* -1)); 
	  END LOOP;

  /* ****************************************************************************************
      (0-11)00070 	D&A
  ************************************************************************************ */
      -- *(-1)
      STR01 :=  '00070';
	  STR02 :=  'D'|| chr(38) ||'A';
      for REC1 IN (
	    --SQL
	    /*
		select COMPANY_CODE, PERIOD, PROFIT_CENTER ,INC, UG ,
	    sum(AMT_TWD) AMOUNT_TWD, sum(AMT_USD) AMOUNT_USD, sum(AMT_CNY) AMOUNT_CNY

	    from roic_vew017_exp_ga
	    where PERIOD = In_PERIOD 
	    and GROUP3 = STR02
	    group by COMPANY_CODE, PERIOD, PROFIT_CENTER ,INC, UG
	    order by COMPANY_CODE, PERIOD, PROFIT_CENTER ,INC, UG
		*/
	    select PERIOD, PROFIT_CENTER ,
	    sum(AMOUNT_TWD) AMOUNT_TWD, sum(AMOUNT_USD) AMOUNT_USD, sum(AMOUNT_CNY) AMOUNT_CNY
	    from
	    (
	        select PERIOD, DECODE(NVL( TRIM(NEW_PROFIT_CENTER) , REPLACE_PC),NOT_FOUND_STR,REPLACE_PC,NEW_PROFIT_CENTER) PROFIT_CENTER ,INC, UG ,
	        sum(AMT_TWD) AMOUNT_TWD, sum(AMT_USD) AMOUNT_USD, sum(AMT_CNY) AMOUNT_CNY
	        from roic_vew017_exp_ga
	        where PERIOD = In_PERIOD
			and (( INC = 'Y' AND 1 = TMP_OPTION2 ) OR ( UG = 'Y' AND 1 = TMP_OPTION1 ))
			and GROUP3 = STR02
	        group by PERIOD, NEW_PROFIT_CENTER ,INC, UG
	        order by PERIOD, NEW_PROFIT_CENTER ,INC, UG
        )
	    group by PERIOD, PROFIT_CENTER 
	    order by PERIOD, PROFIT_CENTER 		
      )
      LOOP
        INSERT INTO ROIC_PST019_FINAL_RPT_PC
         ( PERIOD, PC,GRP_CODE, S_DESC, AMOUNT_TWD, AMOUNT_USD, AMOUNT_CNY) 
        VALUES
         ( In_PERIOD , REC1.PROFIT_CENTER,in_GRP_CODE,STR01, (REC1.AMOUNT_TWD * -1), (REC1.AMOUNT_USD* -1), (REC1.AMOUNT_CNY* -1)); 
	  END LOOP;

  /* ****************************************************************************************
      (0-12)00080 	OH-D&A-01
  ************************************************************************************ */
      -- *(-1)
      STR01 :=  '00080';
	  STR02 :=  'OH-D'|| chr(38) ||'A-01';
      for REC1 IN (
	    --SQL
	    /*
		select COMPANY_CODE, PERIOD, PROFIT_CENTER ,INC, UG ,
	    sum(AMT_TWD) AMOUNT_TWD, sum(AMT_USD) AMOUNT_USD, sum(AMT_CNY) AMOUNT_CNY

	    from roic_vew017_exp_ga
	    where PERIOD = In_PERIOD 
	    and GROUP1 = STR02
	    group by COMPANY_CODE, PERIOD, PROFIT_CENTER ,INC, UG
	    order by COMPANY_CODE, PERIOD, PROFIT_CENTER ,INC, UG
		*/
	    select PERIOD, PROFIT_CENTER ,
	    sum(AMOUNT_TWD) AMOUNT_TWD, sum(AMOUNT_USD) AMOUNT_USD, sum(AMOUNT_CNY) AMOUNT_CNY
	    from
	    (
	        select PERIOD, NVL( TRIM(NEW_PROFIT_CENTER) , REPLACE_PC) PROFIT_CENTER ,
	        sum(AMT_TWD) AMOUNT_TWD, sum(AMT_USD) AMOUNT_USD, sum(AMT_CNY) AMOUNT_CNY
	        from roic_vew017_exp_ga
	        where PERIOD = In_PERIOD
			and (( INC = 'Y' AND 1 = TMP_OPTION2 ) OR ( UG = 'Y' AND 1 = TMP_OPTION1 ))
			and GROUP1 = STR02
	        group by PERIOD, NEW_PROFIT_CENTER 
	        order by PERIOD, NEW_PROFIT_CENTER 
        )
	    group by PERIOD, PROFIT_CENTER 
	    order by PERIOD, PROFIT_CENTER	
      )
      LOOP
        INSERT INTO ROIC_PST019_FINAL_RPT_PC
         ( PERIOD, PC,GRP_CODE, S_DESC, AMOUNT_TWD, AMOUNT_USD, AMOUNT_CNY) 
        VALUES
         ( In_PERIOD , REC1.PROFIT_CENTER,in_GRP_CODE,STR01, (REC1.AMOUNT_TWD * -1), (REC1.AMOUNT_USD* -1), (REC1.AMOUNT_CNY* -1)); 
      END LOOP;
  /* ****************************************************************************************
      (0-13)00090 	R&D-D&A-01
  ************************************************************************************ */
      -- *(-1)
      STR01 :=  '00090';
	  STR02 :=  'R'|| chr(38) ||'D-D'|| chr(38) || 'A-01';
      for REC1 IN (
	    --SQL
	    /*
		select COMPANY_CODE, PERIOD, PROFIT_CENTER ,INC, UG ,
	    sum(AMT_TWD) AMOUNT_TWD, sum(AMT_USD) AMOUNT_USD, sum(AMT_CNY) AMOUNT_CNY

	    from roic_vew017_exp_ga
	    where PERIOD = In_PERIOD 
	    and GROUP1 = STR02
	    group by COMPANY_CODE, PERIOD, PROFIT_CENTER ,INC, UG
	    order by COMPANY_CODE, PERIOD, PROFIT_CENTER ,INC, UG
		*/
	    select PERIOD, PROFIT_CENTER ,
	    sum(AMOUNT_TWD) AMOUNT_TWD, sum(AMOUNT_USD) AMOUNT_USD, sum(AMOUNT_CNY) AMOUNT_CNY
	    from
	    (
	        select PERIOD, NVL( TRIM(NEW_PROFIT_CENTER) , REPLACE_PC) PROFIT_CENTER ,
	        sum(AMT_TWD) AMOUNT_TWD, sum(AMT_USD) AMOUNT_USD, sum(AMT_CNY) AMOUNT_CNY
	        from roic_vew017_exp_ga
	        where PERIOD = In_PERIOD
			and (( INC = 'Y' AND 1 = TMP_OPTION2 ) OR ( UG = 'Y' AND 1 = TMP_OPTION1 ))
			and GROUP1 = STR02
	        group by PERIOD, NEW_PROFIT_CENTER 
	        order by PERIOD, NEW_PROFIT_CENTER
        )
	    group by PERIOD, PROFIT_CENTER 
	    order by PERIOD, PROFIT_CENTER 		
      )
      LOOP
        INSERT INTO ROIC_PST019_FINAL_RPT_PC
         ( PERIOD, PC,GRP_CODE, S_DESC, AMOUNT_TWD, AMOUNT_USD, AMOUNT_CNY) 
        VALUES
         ( In_PERIOD , REC1.PROFIT_CENTER,in_GRP_CODE,STR01, (REC1.AMOUNT_TWD * -1), (REC1.AMOUNT_USD* -1), (REC1.AMOUNT_CNY* -1)); 
	  END LOOP;

  /* ****************************************************************************************
      (0-14)00100 	SAL-D&A-01
  ************************************************************************************ */
      -- *(-1)
      STR01 :=  '00100';
	  STR02 :=  'SAL-D'|| chr(38) ||'A-01';
      for REC1 IN (
	    --SQL
	    /*
		select COMPANY_CODE, PERIOD, PROFIT_CENTER ,INC, UG ,
	    sum(AMT_TWD) AMOUNT_TWD, sum(AMT_USD) AMOUNT_USD, sum(AMT_CNY) AMOUNT_CNY

	    from roic_vew017_exp_ga
	    where PERIOD = In_PERIOD 
	    and GROUP1 = STR02
	    group by COMPANY_CODE, PERIOD, PROFIT_CENTER ,INC, UG
	    order by COMPANY_CODE, PERIOD, PROFIT_CENTER ,INC, UG
		*/
	    select PERIOD, PROFIT_CENTER ,
	    sum(AMOUNT_TWD) AMOUNT_TWD, sum(AMOUNT_USD) AMOUNT_USD, sum(AMOUNT_CNY) AMOUNT_CNY
	    from
	    (
	        select PERIOD, NVL( TRIM(NEW_PROFIT_CENTER) , REPLACE_PC) PROFIT_CENTER ,
	        sum(AMT_TWD) AMOUNT_TWD, sum(AMT_USD) AMOUNT_USD, sum(AMT_CNY) AMOUNT_CNY
	        from roic_vew017_exp_ga
	        where PERIOD = In_PERIOD
			and (( INC = 'Y' AND 1 = TMP_OPTION2 ) OR ( UG = 'Y' AND 1 = TMP_OPTION1 ))
			and GROUP1 = STR02
	        group by PERIOD, NEW_PROFIT_CENTER 
	        order by PERIOD, NEW_PROFIT_CENTER
        )
	    group by PERIOD, PROFIT_CENTER 
	    order by PERIOD, PROFIT_CENTER	
      )
      LOOP
        INSERT INTO ROIC_PST019_FINAL_RPT_PC
         ( PERIOD, PC,GRP_CODE, S_DESC, AMOUNT_TWD, AMOUNT_USD, AMOUNT_CNY) 
        VALUES
         ( In_PERIOD , REC1.PROFIT_CENTER,in_GRP_CODE,STR01, (REC1.AMOUNT_TWD * -1), (REC1.AMOUNT_USD* -1), (REC1.AMOUNT_CNY* -1)); 
	  END LOOP;

  /* ****************************************************************************************
      (0-15)00110 	ADM-D&A-01
  ************************************************************************************ */
      -- *(-1)
      STR01 :=  '00110';
	  STR02 :=  'ADM-D'|| chr(38) ||'A-01';
      for REC1 IN (
	    --SQL
	    /*
		select COMPANY_CODE, PERIOD, PROFIT_CENTER ,INC, UG ,
	    sum(AMT_TWD) AMOUNT_TWD, sum(AMT_USD) AMOUNT_USD, sum(AMT_CNY) AMOUNT_CNY

	    from roic_vew017_exp_ga
	    where PERIOD = In_PERIOD 
	    and GROUP1 = STR02
	    group by COMPANY_CODE, PERIOD, PROFIT_CENTER ,INC, UG
	    order by COMPANY_CODE, PERIOD, PROFIT_CENTER ,INC, UG
		*/
	    select PERIOD, PROFIT_CENTER ,
	    sum(AMOUNT_TWD) AMOUNT_TWD, sum(AMOUNT_USD) AMOUNT_USD, sum(AMOUNT_CNY) AMOUNT_CNY
	    from
	    (
	        select PERIOD, NVL( TRIM(NEW_PROFIT_CENTER) , REPLACE_PC) PROFIT_CENTER ,
	        sum(AMT_TWD) AMOUNT_TWD, sum(AMT_USD) AMOUNT_USD, sum(AMT_CNY) AMOUNT_CNY
	        from roic_vew017_exp_ga
	        where PERIOD = In_PERIOD
			and (( INC = 'Y' AND 1 = TMP_OPTION2 ) OR ( UG = 'Y' AND 1 = TMP_OPTION1 ))
			and GROUP1 = STR02
	        group by PERIOD, NEW_PROFIT_CENTER 
	        order by PERIOD, NEW_PROFIT_CENTER 
        )
	    group by PERIOD, PROFIT_CENTER 
	    order by PERIOD, PROFIT_CENTER 		
      )
      LOOP
        INSERT INTO ROIC_PST019_FINAL_RPT_PC
         ( PERIOD, PC,GRP_CODE, S_DESC, AMOUNT_TWD, AMOUNT_USD, AMOUNT_CNY) 
        VALUES
         ( In_PERIOD , REC1.PROFIT_CENTER,in_GRP_CODE,STR01, (REC1.AMOUNT_TWD * -1), (REC1.AMOUNT_USD* -1), (REC1.AMOUNT_CNY* -1)); 
	  END LOOP;	

  /* ****************************************************************************************
      (0-16)00120 	SG&A
  ************************************************************************************ */
      -- 
      STR01 :=  '00120';
      for REC1 IN (
	    --SQL
		/*
	    select COMPANY_CODE, PERIOD, PROFIT_CENTER ,INC, UG ,
	    sum(AMOUNT) AMOUNT_TWD, sum(AMOUNT_USD) AMOUNT_USD, sum(AMOUNT_CNY) AMOUNT_CNY
	    from roic_vew018_sga_ga
	    where PERIOD = In_PERIOD
	    group by COMPANY_CODE, PERIOD, PROFIT_CENTER ,INC, UG
	    order by COMPANY_CODE, PERIOD, PROFIT_CENTER ,INC, UG
		*/
	    select PERIOD, PROFIT_CENTER ,
	    sum(AMOUNT_TWD) AMOUNT_TWD, sum(AMOUNT_USD) AMOUNT_USD, sum(AMOUNT_CNY) AMOUNT_CNY
	    from
	    (
	        select PERIOD, NVL( TRIM(PROFIT_CENTER) , REPLACE_PC) PROFIT_CENTER ,INC, UG ,
	        sum(AMOUNT) AMOUNT_TWD, sum(AMOUNT_USD) AMOUNT_USD, sum(AMOUNT_CNY) AMOUNT_CNY
	        from roic_vew018_sga_ga
	        where PERIOD = In_PERIOD
			and (( INC = 'Y' AND 1 = TMP_OPTION2 ) OR ( UG = 'Y' AND 1 = TMP_OPTION1 ))
	        group by PERIOD, PROFIT_CENTER ,INC, UG
	        order by PERIOD, PROFIT_CENTER ,INC, UG
        )
	    group by PERIOD, PROFIT_CENTER 
	    order by PERIOD, PROFIT_CENTER	
      )
      LOOP
        INSERT INTO ROIC_PST019_FINAL_RPT_PC
         ( PERIOD, PC, GRP_CODE,S_DESC, AMOUNT_TWD, AMOUNT_USD, AMOUNT_CNY) 
        VALUES
         ( In_PERIOD , REC1.PROFIT_CENTER,in_GRP_CODE,STR01, REC1.AMOUNT_TWD, REC1.AMOUNT_USD, REC1.AMOUNT_CNY); 	  
	  END LOOP;		   


  /*****************************************************************************************
      ��0����
  ************************************************************************************ */  
      for REC2 IN (
	    select PC from ROIC_PST019_FINAL_RPT_PC where PERIOD = In_PERIOD and GRP_CODE = in_GRP_CODE group by pc
      )
      LOOP
	    for REC3 IN (
          select * from ROIC_MAP005_FINAL_FORMAT  where by_pc = 'Y' and caculate = 'N' and s_order not in
         ( select  s_DESC from ROIC_PST019_FINAL_RPT_PC where PERIOD = In_PERIOD and PC = REC2.PC  and GRP_CODE = in_GRP_CODE )
		)
		LOOP
          INSERT INTO ROIC_PST019_FINAL_RPT_PC
           ( PERIOD, PC, GRP_CODE,S_DESC, AMOUNT_TWD, AMOUNT_USD, AMOUNT_CNY) 
          VALUES
           ( In_PERIOD , REC2.PC,in_GRP_CODE,REC3.S_ORDER, 0, 0, 0); 			
		END LOOP; 
      END LOOP;    
  
  /*****************************************************************************************
      (1)OPM
  ************************************************************************************ */
  --OPM=REV+COGS+SG&A
       
      STR01 :=  '00220';                 --OPM
	  STR02 :=  '00050';                 --REV
	  STR03 :=  '00060';                 --COGS
	  STR04 :=  '00120';                 --SG&A

	  
      for REC1 IN (
	    --SQL
        select  AA1.period,AA1.PC PROFIT_CENTER,
        AA1.amount_twd+AA2.amount_twd+AA3.amount_twd amount_twd,
        AA1.amount_usd+AA2.amount_usd+AA3.amount_usd amount_usd,
        AA1.amount_cny+AA2.amount_cny+AA3.amount_cny amount_cny        
        
        from
        (
          SELECT a.period, a.PC,
            SUM (a.amount_twd)  amount_twd,
            SUM (a.amount_usd)  amount_usd,
            SUM (a.amount_cny)  amount_cny
          FROM ROIC_PST019_FINAL_RPT_PC a
          WHERE a.S_DESC = STR02 and a.period = In_PERIOD
		  and GRP_CODE = in_GRP_CODE
          GROUP BY period	,PC    

		  
        ) AA1,

        (
		
          SELECT a.period, a.PC,
            SUM (a.amount_twd)  amount_twd,
            SUM (a.amount_usd)  amount_usd,
            SUM (a.amount_cny)  amount_cny
          FROM ROIC_PST019_FINAL_RPT_PC a
          WHERE a.S_DESC = STR03 and a.period = In_PERIOD
		  and GRP_CODE = in_GRP_CODE
          GROUP BY period	,PC

		  
        ) AA2,

        (		
          SELECT a.period, a.PC,
            SUM (a.amount_twd)  amount_twd,
            SUM (a.amount_usd)  amount_usd,
            SUM (a.amount_cny)  amount_cny
          FROM ROIC_PST019_FINAL_RPT_PC a
          WHERE a.S_DESC = STR04 and a.period = In_PERIOD
          and GRP_CODE = in_GRP_CODE
          GROUP BY period	,PC
		  
		
        ) AA3   
        
        where
        AA1.period = AA2.period and AA2.period = AA3.period     
        and ( AA1.PC = AA2.PC and AA2.PC = AA3.PC  )         
      )
      LOOP
        INSERT INTO ROIC_PST019_FINAL_RPT_PC
         ( PERIOD, PC, GRP_CODE,S_DESC, AMOUNT_TWD, AMOUNT_USD, AMOUNT_CNY) 
        VALUES
         ( In_PERIOD , REC1.PROFIT_CENTER,in_GRP_CODE,STR01, REC1.AMOUNT_TWD, REC1.AMOUNT_USD, REC1.AMOUNT_CNY);  
      END LOOP;   
      
  /*****************************************************************************************
      (2)Min. Cash
  ************************************************************************************ */
  --1. Sep'18 Min. Cash={SUM(COGS rolling 12 months)+'SUM(D&A rolling 12 months)-'SUM(SG&A rolling 12 months)}*30/365
  
 
      STR01 :=  '00250';                 --Min. Cash
	  STR02 :=  '00060';                 --COGS
	  STR03 :=  '00120';                 --SG&A
	  STR04 :=  '00070';                 --D&A
  
      for REC1 IN (
	    --SQL
        select  AA1.period,AA1.PC PROFIT_CENTER, 
        ( AA1.amount_twd + AA2.amount_twd - AA3.amount_twd ) * 30 / 365 * -1 amount_twd,
        ( AA1.amount_usd + AA2.amount_usd - AA3.amount_usd ) * 30 / 365 * -1 amount_usd,
        ( AA1.amount_cny + AA2.amount_cny - AA3.amount_cny ) * 30 / 365 * -1 amount_cny        
        
        from
        (
		  		  
          SELECT a.period, a.PC, 
            SUM (a.amount_twd)  amount_twd,
            SUM (a.amount_usd)  amount_usd,
            SUM (a.amount_cny)  amount_cny
          FROM ROIC_PST019_FINAL_RPT_PC a
          WHERE a.S_DESC = STR02 and (a.period <= In_PERIOD and a.period >= From_PERIOD )
		  and GRP_CODE = in_GRP_CODE
          GROUP BY period	,PC		  

		  
        ) AA1,

        (

		
          SELECT a.period, a.PC,
            SUM (a.amount_twd)  amount_twd,
            SUM (a.amount_usd)  amount_usd,
            SUM (a.amount_cny)  amount_cny
          FROM ROIC_PST019_FINAL_RPT_PC a
          WHERE a.S_DESC = STR03 and ( a.period <= In_PERIOD and a.period >= From_PERIOD )
		  and GRP_CODE = in_GRP_CODE
          GROUP BY period	,PC

		  
        ) AA2,

        (
		
          SELECT a.period, a.PC,
            SUM (a.amount_twd)  amount_twd,
            SUM (a.amount_usd)  amount_usd,
            SUM (a.amount_cny)  amount_cny
          FROM ROIC_PST019_FINAL_RPT_PC a
          WHERE a.S_DESC = STR04 and ( a.period <= In_PERIOD and a.period >= From_PERIOD )
		  and GRP_CODE = in_GRP_CODE
          GROUP BY period	,PC
		  
		
        ) AA3   
        
        where
        AA1.period = AA2.period and AA2.period = AA3.period      
        and ( AA1.PC = AA2.PC and AA2.PC = AA3.PC  )            
      )
      LOOP
        INSERT INTO ROIC_PST019_FINAL_RPT_PC
         ( PERIOD, PC, GRP_CODE,S_DESC, AMOUNT_TWD, AMOUNT_USD, AMOUNT_CNY) 
        VALUES
         ( In_PERIOD , REC1.PROFIT_CENTER,in_GRP_CODE,STR01, REC1.AMOUNT_TWD, REC1.AMOUNT_USD, REC1.AMOUNT_CNY);             
      END LOOP;   
 
  /*****************************************************************************************
      (3)Working Capital
  ************************************************************************************ */
  --2. Working Capital: �C������ AR+Inventory-AP�A ���e rolling �A��12����������
  -- Sep'18 Working Capital={SUM(AR rolling 12 months)+'SUM(INV rolling 12 months)-'SUM(AP rolling 12 months)}/12 

 
      STR01 :=  '00260';                 --Working Capital
	  STR02 :=  '00010';                 --AR
	  STR03 :=  '00020';                 --INV
	  STR04 :=  '00030';                 --AP

  
      for REC1 IN (
	    --SQL
        select  AA1.period,AA1.PC PROFIT_CENTER,
        ( AA1.amount_twd + AA2.amount_twd - AA3.amount_twd ) / 12 amount_twd,
        ( AA1.amount_usd + AA2.amount_usd - AA3.amount_usd ) / 12 amount_usd,
        ( AA1.amount_cny + AA2.amount_cny - AA3.amount_cny ) / 12 amount_cny        
        
        from
        (
          SELECT a.period, a.PC,
            SUM (a.amount_twd)  amount_twd,
            SUM (a.amount_usd)  amount_usd,
            SUM (a.amount_cny)  amount_cny
          FROM ROIC_PST019_FINAL_RPT_PC a
          WHERE a.S_DESC = STR02 and ( a.period <= In_PERIOD and a.period >= From_PERIOD )
		  and GRP_CODE = in_GRP_CODE
          GROUP BY period	,PC
        ) AA1,

        (
          SELECT a.period, a.PC,
            SUM (a.amount_twd)  amount_twd,
            SUM (a.amount_usd)  amount_usd,
            SUM (a.amount_cny)  amount_cny
          FROM ROIC_PST019_FINAL_RPT_PC a
          WHERE a.S_DESC = STR03 and ( a.period <= In_PERIOD and a.period >= From_PERIOD )
		  and GRP_CODE = in_GRP_CODE
          GROUP BY period	,PC
        ) AA2,

        (
          SELECT a.period, a.PC,
            SUM (a.amount_twd)  amount_twd,
            SUM (a.amount_usd)  amount_usd,
            SUM (a.amount_cny)  amount_cny
          FROM ROIC_PST019_FINAL_RPT_PC a
          WHERE a.S_DESC = STR04 and ( a.period <= In_PERIOD and a.period >= From_PERIOD )
		  and GRP_CODE = in_GRP_CODE
          GROUP BY period	,PC
        ) AA3   
        
        where
        AA1.period = AA2.period and AA2.period = AA3.period         
        and ( AA1.PC = AA2.PC and AA2.PC = AA3.PC  )          
      )
      LOOP
        INSERT INTO ROIC_PST019_FINAL_RPT_PC
         ( PERIOD, PC, GRP_CODE,S_DESC, AMOUNT_TWD, AMOUNT_USD, AMOUNT_CNY) 
        VALUES
         ( In_PERIOD , REC1.PROFIT_CENTER,in_GRP_CODE,STR01, REC1.AMOUNT_TWD, REC1.AMOUNT_USD, REC1.AMOUNT_CNY);            
      END LOOP;  

  /*****************************************************************************************
      (4)PP&E
  ************************************************************************************ */
  --3. PP&E �G �C������ PP&E (���e rolling�A��12��������)
  --PP&E �]�t :FA-Building,Electricity,Land+FA-Equitment+FA-Others+FA-Land Occupy
  -- Sep'18 PP&E={rolling 12 months(FA-Land+FA-Building,Electricity+FA-Equitment +FA-Others+FA-Land Occupy)}/12 

     
 
      STR01 :=  '00270';	 --'PP&E' 
      for REC1 IN (
	    --SQL

          SELECT a.period, a.PC PROFIT_CENTER, 
            ( SUM (a.amount_twd)) / 12  amount_twd,
            ( SUM (a.amount_usd)) / 12  amount_usd,
            ( SUM (a.amount_cny)) / 12  amount_cny
          FROM ROIC_PST019_FINAL_RPT_PC a
          WHERE a.S_DESC in ('00040','00041','00042','00043','00044') 
		  and ( a.period <= In_PERIOD and a.period >= From_PERIOD )
		  and GRP_CODE = in_GRP_CODE
          GROUP BY period	,PC
		
      )
      LOOP
        INSERT INTO ROIC_PST019_FINAL_RPT_PC
         ( PERIOD, PC, GRP_CODE,S_DESC, AMOUNT_TWD, AMOUNT_USD, AMOUNT_CNY) 
        VALUES
         ( In_PERIOD , REC1.PROFIT_CENTER,in_GRP_CODE,STR01, REC1.AMOUNT_TWD, REC1.AMOUNT_USD, REC1.AMOUNT_CNY); 
	   END LOOP;  	  	  

    /*****************************************************************************************
      (5)Current NI ( after tax )
    ************************************************************************************ */
    --Current NI ( after tax )
	
      STR01 :=  '00230';                 --Current NI ( after tax )
	  STR02 :=  '00050';                 --REV
	  STR03 :=  '00060';                 --COGS
	  STR04 :=  '00120';                 --SG&A
	  --STR04 :=  'SG&A';
	  
      for REC1 IN (
	    --SQL
        select  AA4.TAX_RATE ,AA1.PC PROFIT_CENTER, 
        ((AA1.amount_twd+AA2.amount_twd+AA3.amount_twd) * ( 1 - AA4.TAX_RATE ) )   amount_twd,
        ((AA1.amount_usd+AA2.amount_usd+AA3.amount_usd) * ( 1 - AA4.TAX_RATE ) )   amount_usd,
        ((AA1.amount_cny+AA2.amount_cny+AA3.amount_cny) * ( 1 - AA4.TAX_RATE ) )   amount_cny        
        
        from
        (

		  
          SELECT a.period,  a.PC,
            SUM (a.amount_twd)  amount_twd,
            SUM (a.amount_usd)  amount_usd,
            SUM (a.amount_cny)  amount_cny
          FROM ROIC_PST019_FINAL_RPT_PC a
          WHERE a.S_DESC = STR02 and ( a.period = In_PERIOD )
		  and GRP_CODE = in_GRP_CODE
          GROUP BY period ,PC   
		  
        ) AA1,

        (

		
          SELECT a.period,  a.PC,
            SUM (a.amount_twd)  amount_twd,
            SUM (a.amount_usd)  amount_usd,
            SUM (a.amount_cny)  amount_cny
          FROM ROIC_PST019_FINAL_RPT_PC a
          WHERE a.S_DESC = STR03 and ( a.period = In_PERIOD )
		  and GRP_CODE = in_GRP_CODE
          GROUP BY period ,PC	 
		  
        ) AA2,

        (

		
          SELECT a.period,   a.PC,
            SUM (a.amount_twd)  amount_twd,
            SUM (a.amount_usd)  amount_usd,
            SUM (a.amount_cny)  amount_cny
          FROM ROIC_PST019_FINAL_RPT_PC a
          WHERE a.S_DESC = STR04 and ( a.period = In_PERIOD )
		  and GRP_CODE = in_GRP_CODE
          GROUP BY period ,PC 		
		
        ) AA3 ,
		
		(
        select * from ROIC_UPL001_TAX_RATE where  ( START_DATE <= In_PERIOD and END_DATE >= In_PERIOD ) and company_code = in_GRP_CODE
		)
		AA4
		
        where
		/*(
        AA1.company_code = AA2.company_code and AA2.company_code = AA3.company_code and
		AA1.company_code = AA4.company_code
		)
		and */
        ( AA1.PC = AA2.PC and AA2.PC = AA3.PC  )  		
         
      )
      LOOP
        INSERT INTO ROIC_PST019_FINAL_RPT_PC
         ( PERIOD, PC, GRP_CODE,S_DESC, AMOUNT_TWD, AMOUNT_USD, AMOUNT_CNY) 
        VALUES
         ( In_PERIOD , REC1.PROFIT_CENTER,in_GRP_CODE,STR01, REC1.AMOUNT_TWD, REC1.AMOUNT_USD, REC1.AMOUNT_CNY);           
      END LOOP;

	  
    /*****************************************************************************************
      (6)NI �]after tax�^
    ************************************************************************************ */
    --4. NI  ( after tax )�G �p�� OPM * �]1-���q�����|�v�^�A ���e rolling �[�`12����
    --PS.���e���������|�v 18%,���O�d������������
	-- Sep'18 NI �]after tax�^=OPM*(1- �����|�v) rolling 12 months 

	
      STR01 :=  '00240';    --NI  ( after tax )
	  STR02 :=  '00230';    --REV

	  
      for REC1 IN (
	  
          SELECT a.period, a.PC PROFIT_CENTER, 
            SUM (a.amount_twd)  amount_twd,
            SUM (a.amount_usd)  amount_usd,
            SUM (a.amount_cny)  amount_cny
          FROM ROIC_PST019_FINAL_RPT_PC a
          WHERE a.S_DESC = STR02 and ( a.period <= In_PERIOD and a.period >= From_PERIOD )
		  and GRP_CODE = in_GRP_CODE
          GROUP BY period,PC
		  
	    --SQL
		/*
        select  AA1.period , AA4.TAX_RATE ,AA1.PC PROFIT_CENTER,
        ((AA1.amount_twd+AA2.amount_twd+AA3.amount_twd) * ( 1 - AA4.TAX_RATE ) )   amount_twd,
        ((AA1.amount_usd+AA2.amount_usd+AA3.amount_usd) * ( 1 - AA4.TAX_RATE ) )   amount_usd,
        ((AA1.amount_cny+AA2.amount_cny+AA3.amount_cny) * ( 1 - AA4.TAX_RATE ) )   amount_cny        
        
        from
        (
		  
          SELECT a.period, a.PC, 
            SUM (a.amount_twd)  amount_twd,
            SUM (a.amount_usd)  amount_usd,
            SUM (a.amount_cny)  amount_cny
          FROM ROIC_PST019_FINAL_RPT_PC a
          WHERE a.S_DESC = STR02 and ( a.period <= In_PERIOD and a.period >= From_PERIOD )
		  and GRP_CODE = in_GRP_CODE
          GROUP BY period,PC	  
		  
        ) AA1,

        (

		
          SELECT a.period,a.PC,
            SUM (a.amount_twd)  amount_twd,
            SUM (a.amount_usd)  amount_usd,
            SUM (a.amount_cny)  amount_cny
          FROM ROIC_PST019_FINAL_RPT_PC a
          WHERE a.S_DESC = STR03 and ( a.period <= In_PERIOD and a.period >= From_PERIOD )
		  and GRP_CODE = in_GRP_CODE
          GROUP BY period	,PC	  
        ) AA2,

        (

          SELECT a.period, a.PC, 
            SUM (a.amount_twd)  amount_twd,
            SUM (a.amount_usd)  amount_usd,
            SUM (a.amount_cny)  amount_cny
          FROM ROIC_PST019_FINAL_RPT_PC a
          WHERE a.S_DESC = STR04 and ( a.period <= In_PERIOD and a.period >= From_PERIOD )
		  and GRP_CODE = in_GRP_CODE
          GROUP BY period,PC  	
		
        ) AA3 ,
		
		(
        select * from ROIC_UPL001_TAX_RATE where  ( START_DATE <= In_PERIOD and END_DATE >= In_PERIOD )  and company_code = in_GRP_CODE
		)
		AA4
		
        where		
        ( AA1.PC = AA2.PC and AA2.PC = AA3.PC  )  
        */ 
      )
      LOOP
        INSERT INTO ROIC_PST019_FINAL_RPT_PC
         ( PERIOD, PC, GRP_CODE,S_DESC, AMOUNT_TWD, AMOUNT_USD, AMOUNT_CNY) 
        VALUES
         ( In_PERIOD , REC1.PROFIT_CENTER,in_GRP_CODE,STR01, REC1.AMOUNT_TWD, REC1.AMOUNT_USD, REC1.AMOUNT_CNY);           
      END LOOP;


    /*****************************************************************************************
      (7)Subtotal
    ************************************************************************************ */
    --Subtotal = Min. Cash + Working Capital + PP&E

	
      STR01 :=  '00280';            --Subtotal
	  STR02 :=  '00250';            --Min. Cash             
	  STR03 :=  '00260';            -- Working Capital               
	  STR04 :=  '00270';            --PP&E

	  
      for REC1 IN (

        select  AA1.period, AA1.PC PROFIT_CENTER, 
        SUM ( AA1.amount_twd ) amount_twd,
        SUM ( AA1.amount_usd ) amount_usd,
        SUM ( AA1.amount_cny ) amount_cny
        FROM  ROIC_PST019_FINAL_RPT_PC  AA1
        WHERE ( S_DESC = STR02	OR S_DESC = STR03 OR S_DESC = STR04 ) AND AA1.period = In_PERIOD
		and GRP_CODE = in_GRP_CODE
        GROUP BY AA1.period, AA1.PC
         
      )
      LOOP
        INSERT INTO ROIC_PST019_FINAL_RPT_PC
         ( PERIOD, PC, GRP_CODE,S_DESC, AMOUNT_TWD, AMOUNT_USD, AMOUNT_CNY) 
        VALUES
         ( In_PERIOD , REC1.PROFIT_CENTER,in_GRP_CODE,STR01, REC1.AMOUNT_TWD, REC1.AMOUNT_USD, REC1.AMOUNT_CNY);               
      END LOOP;	
        
    /*****************************************************************************************
      (8)ROIC
    ************************************************************************************ */
    --5. �C�������i�� ROIC �G ���l NI =�]after tax�^�A���� = Subtotal = Min. Cash + Working Capital + PP&E
    -- Sep'18 ROIC=NI �]after tax�^/Subtotal 

	
      STR01 :=  '00290';             --ROIC
      STR02 :=  '00240';             --NI  ( after tax )
	  STR03 :=  '00280';             --Subtotal        
	                   

	  
      for REC1 IN (
        select  AA1.period,AA1.PC PROFIT_CENTER,
        ( AA1.amount_twd / decode(AA2.amount_twd,0,1,AA2.amount_twd)) amount_twd,
        ( AA1.amount_usd / decode(AA2.amount_usd,0,1,AA2.amount_usd)) amount_usd,
        ( AA1.amount_cny / decode(AA2.amount_cny,0,1,AA2.amount_cny)) amount_cny
      
        
        from
        
        (
        select  AA.period,AA.PC,
        SUM ( AA.amount_twd ) amount_twd,
        SUM ( AA.amount_usd ) amount_usd,
        SUM ( AA.amount_cny ) amount_cny
        FROM  ROIC_PST019_FINAL_RPT_PC  AA
        WHERE ( S_DESC = STR02 ) AND AA.period = In_PERIOD
		and GRP_CODE = in_GRP_CODE
        GROUP BY AA.period,AA.PC
        ) AA1,  
        
        (
        select  AA.period,AA.PC,
        SUM ( AA.amount_twd ) amount_twd,
        SUM ( AA.amount_usd ) amount_usd,
        SUM ( AA.amount_cny ) amount_cny
        FROM  ROIC_PST019_FINAL_RPT_PC  AA
        WHERE ( S_DESC = STR03 ) AND AA.period = In_PERIOD
		and GRP_CODE = in_GRP_CODE
        GROUP BY AA.period,AA.PC	
        ) AA2        
        
		where
        AA1.period = AA2.period   
        and ( AA1.PC = AA2.PC  )  		
      )
      LOOP
        INSERT INTO ROIC_PST019_FINAL_RPT_PC
         ( PERIOD, PC, GRP_CODE,S_DESC, AMOUNT_TWD, AMOUNT_USD, AMOUNT_CNY) 
        VALUES
         ( In_PERIOD , REC1.PROFIT_CENTER,in_GRP_CODE,STR01, REC1.AMOUNT_TWD, REC1.AMOUNT_USD, REC1.AMOUNT_CNY);       
      END LOOP;	 	   

  
  -----------------------------------------
  sRUN_SEQ   := '000020';
  sRUN_DESC  := 'End';

  --Insert Log
  INSERT INTO ROIC_PST000_LOG
      ( PROC_NAME, RUN_SEQ, RUN_DESC, PARAMETER_DESC )
    VALUES
      ( sPROC_NAME, sRUN_SEQ, sRUN_DESC, sPARAMETER_DESC );
  Commit;
  
END ROIC_PLS019_FINAL_RPT_PC_V2;
/

