create PROCEDURE RWF_PLS001_ACTUAL_REVENUE (
  inCompany  in VARCHAR2,
  f_YYYYMMDD in VARCHAR2,
  t_YYYYMMDD in VARCHAR2
)
AUTHID DEFINER
/*********************************************************************
  PROG-ID      : RWF_PLS001_ACTUAL_REVENUE
  PROG-ACTION  : GET ACTUAL's SUMMARY REVENUE FROM TABLE(KPI_VEW001_REVENUE_DETAIL)
  Author       : KANGI
  Date         : 2006/12/30
**********************************************************************/
/*********************************************************************
  PROG-ID      : RWF_PLS001_ACTUAL_REVENUE
  PROG-ACTION  : New two columns =>MTL_GROUP,PROJECT_TYPE
  Author       : KANGI
  Date         : 2007/10/15
**********************************************************************/
/*********************************************************************
  PROG-ID      : RWF_PLS001_ACTUAL_REVENUE
  PROG-ACTION  : UPDATE to get data by year
  Author       : KANGI
  Date         : 2008/01/08
**********************************************************************/
/*********************************************************************
  Modify-ACTION  : 人民幣(CNY) 為基準
                   Add CNY Amount
  Modify Author       : KANGI
  Modify Date         : 2011/12/29
  OA                  : SAI028442
**********************************************************************/
/*********************************************************************
  Modify-ACTION  : APPLE TRANSFER TO JORDAN
  Modify Author       : KANGI
  Modify Date         : 2013/03/15
  OA                  :
**********************************************************************/
is
   --處理 (月份) KPI_VEW001_REVENUE_DETAIL
   CURSOR KPI_VEW001_CUR is
   SELECT PERIOD FROM KPI_VEW001_REVENUE_DETAIL
   --Modify by kangi on 20080108
   --  WHERE PERIOD >= SUBSTR(f_YYYYMMDD,1,6)  Remark by kangi on 20080108
       WHERE PERIOD >= SUBSTR(f_YYYYMMDD,1,4) || '01'
   --End Modify by kangi on 20080108
       AND PERIOD <= SUBSTR(t_YYYYMMDD,1,6)
	   GROUP BY PERIOD ORDER BY PERIOD ;

   cCURRENT_PERIOD KPI_SAP001_COPA_TRX.PERIOD%TYPE ;
   dBILLING_END_DATE_BY_MON RWF_SAP002_REVENUE_ACTUAL.BILLING_END_DATE_BY_MON%TYPE;
   iTracePoint  integer ;
   cErrorText varchar2(500) ;
 BEGIN
  iTracePoint := 100 ;
  cCURRENT_PERIOD := TO_CHAR(SYSDATE,'YYYYMM') ;
  iTracePoint := 200 ;
  EXECUTE IMMEDIATE 'TRUNCATE TABLE RWF_ZOT002_REVENUE_TEMP';

  iTracePoint := 300 ;
  FOR KPI_VEW001_REC in KPI_VEW001_CUR  LOOP
       iTracePoint := 400 ;
       ----
       ----GEG DETAIL DATA
       INSERT INTO RWF_ZOT002_REVENUE_TEMP
       (  COMPANY_CODE,PLANT_CODE,PERIOD,
          POSTING_DATE,SAP_CREATE_DATE,COPA_DOC_NO,
          COPA_DOC_ITEM,SO_NO,SO_ITEM,
          PART_NO,PROFIT_CENTER,PARTNER_PROFIT_CENTER,DOMESTIC_OR_FOREIGN,
          DIVISION,SALES_DISTRICT,SALES_DISTRICT_NAME,
          ACCOUNT_ASSIGNMENT,ACCOUNT_ASG_DESC,CUST_GROUP,
          SEARCH_TERM,CUSTOMER_ID,SHIP_TO_PARTY,
          MTL_GROUP,SHIP_TO_PARTY_GROUP,MTL_GROUP_1,
          MTL_GROUP_1_DESC,SOLD_TO_PARTY,CURRENCY_DOC,
          GROSS_REVENUE_DOC,GROSS_QTY,NET_QTY,
          GROSS_REVENUE,NET_REVENUE,GROSS_COGS,
          NET_COGS,CURRENCY_LOCAL,
          EX_RATE_USD,NET_REVENUE_USD,NET_COGS_USD,
          EX_RATE_TWD,NET_REVENUE_TWD,NET_COGS_TWD,
        --Add kangi 20111229
          EX_RATE_CNY,NET_REVENUE_CNY,NET_COGS_CNY,
        --End Add kangi 20111229
          END_CUSTOMER_ID,NEW_CUSTOMER,NEW_PRODUCT_LINE,
          CREATE_DATE,COST_ELEMENT,RELATED_PARTY,
          MTL_TYPE,MTL_TYPE_AF,PROJECT_NAME,
          PROJECT_TYPE,END_CUSTOMER_NAME
       ) SELECT A.COMPANY_CODE,A.PLANT_CODE,A.PERIOD,
       A.POSTING_DATE,A.SAP_CREATE_DATE,A.COPA_DOC_NO,
       A.COPA_DOC_ITEM,A.SO_NO,A.SO_ITEM,
       A.PART_NO,A.PROFIT_CENTER,A.PARTNER_PROFIT_CENTER,A.DOMESTIC_OR_FOREIGN,
       A.DIVISION,A.SALES_DISTRICT,A.SALES_DISTRICT_NAME,
       A.ACCOUNT_ASSIGNMENT,A.ACCOUNT_ASG_DESC,A.CUST_GROUP,
       A.SEARCH_TERM,A.CUSTOMER_ID,A.SHIP_TO_PARTY,
       A.MTL_GROUP,A.SHIP_TO_PARTY_GROUP,A.MTL_GROUP_1,
       A.MTL_GROUP_1_DESC,A.SOLD_TO_PARTY,A.CURRENCY_DOC,
       A.GROSS_REVENUE_DOC,A.GROSS_QTY,A.NET_QTY,
       A.GROSS_REVENUE,A.NET_REVENUE,A.GROSS_COGS,
       A.NET_COGS,A.CURRENCY_LOCAL,
       A.EX_RATE_USD,A.NET_REVENUE_USD,A.NET_COGS_USD,
       A.EX_RATE_TWD,A.NET_REVENUE_TWD,A.NET_COGS_TWD,
      --Add kangi 20111229
       A.EX_RATE_CNY,A.NET_REVENUE_CNY,A.NET_COGS_CNY,
      --End Add kangi 20111229
       A.END_CUSTOMER_ID,A.NEW_CUSTOMER,A.NEW_PRODUCT_LINE,
       A.CREATE_DATE,COST_ELEMENT,A.RELATED_PARTY,
       A.MTL_TYPE,MTL_TYPE_AF,D.PROJECT_NAME,
       D.PROJECT_TYPE,null END_CUSTOMER_NAME FROM KPI_VEW012_REVENUE_ALL_DTL A,KPI_ZOT001_PDM_PROJECT D
          WHERE A.PART_NO = D.FG_NO(+)
            AND A.RELATED_PARTY = 'N'
            AND A.PERIOD = KPI_VEW001_REC.PERIOD
            AND A.NET_REVENUE <> 0  ;
       iTracePoint := 500 ;
   END LOOP ;
   iTracePoint := 600 ;
   UPDATE RWF_ZOT002_REVENUE_TEMP
      SET END_CUSTOMER_NAME =
             (SELECT DISTINCT TRIM (END_CUSTOMER_NAME)
                         FROM CEP_MAP009_PARTNO_CUSTOMER
                        WHERE FG_MATERIAL_NO =
                                      RPAD (RWF_ZOT002_REVENUE_TEMP.PART_NO, 18, ' ')
                          AND LAST_MODIFY_DATE <= SYSDATE) ;
   COMMIT;
   iTracePoint := 700 ;
   /*
    *  Profit center 20/21 且mtl group 001-059歸Lenovo
    *  其他不屬於20/21 但仍是001-059則歸  其他-材料轉售
    *  不屬於001-059的材料則用search term(但要考慮到如果是cogs-屬於特定cost element則不走這裡)
    *  空白料號-用SEarch term update
    * 2008/11/26 邏輯變動 只要是20/21的材料都叫LENOVO
    * 而其他的如果SEARCH TERM是LENOVO就叫LENOVO,分完後再來做其他-材料轉售
   */
   UPDATE RWF_ZOT002_REVENUE_TEMP
      SET END_CUSTOMER_NAME = 'LENOVO'
    WHERE PROFIT_CENTER IN ('0000000020', '0000000021')
      AND MTL_GROUP BETWEEN '001' AND '059'
      AND MTL_TYPE = 'RAW'
      AND END_CUSTOMER_NAME IS NULL;

   COMMIT;
   iTracePoint := 800 ;
   UPDATE RWF_ZOT002_REVENUE_TEMP
      SET END_CUSTOMER_NAME = 'LENOVO'
    WHERE (PROFIT_CENTER NOT IN ('0000000020', '0000000021')
           OR PROFIT_CENTER IS NULL)
      AND MTL_GROUP BETWEEN '001' AND '059'
      AND SEARCH_TERM = 'LENOVO'
      AND MTL_TYPE = 'RAW'
      AND END_CUSTOMER_NAME IS NULL;

   COMMIT;
   iTracePoint := 900 ;
   UPDATE RWF_ZOT002_REVENUE_TEMP
      SET END_CUSTOMER_NAME = '其他-材料轉售'
    WHERE (PROFIT_CENTER NOT IN ('0000000020', '0000000021')
           OR PROFIT_CENTER IS NULL)
      AND MTL_GROUP BETWEEN '001' AND '059'
      AND MTL_TYPE = 'RAW'
      AND END_CUSTOMER_NAME IS NULL;

   COMMIT;

   iTracePoint := 1000 ;
   UPDATE RWF_ZOT002_REVENUE_TEMP
      SET END_CUSTOMER_NAME = TRIM (SEARCH_TERM)
    WHERE SEARCH_TERM IS NOT NULL
      AND END_CUSTOMER_NAME IS NULL
      AND MTL_TYPE = 'RAW';

   COMMIT;
   iTracePoint := 1100 ;
   --2008/11/12 剩下的直接用SEARCH TERM UPDATE
   UPDATE RWF_ZOT002_REVENUE_TEMP
      SET END_CUSTOMER_NAME = TRIM (SEARCH_TERM)
    WHERE SEARCH_TERM IS NOT NULL
      AND END_CUSTOMER_NAME IS NULL
      AND (MTL_TYPE <> 'RAW' OR MTL_TYPE IS NULL);

   COMMIT;

   --Add kangi 20130315
   BEGIN
         iTracePoint := 1110 ;
         UPDATE RWF_ZOT002_REVENUE_TEMP
          SET END_CUSTOMER_NAME = 'JORDAN'
         WHERE UPPER(END_CUSTOMER_NAME) = 'APPLE' ;
         iTracePoint := 1120 ;
		 UPDATE RWF_ZOT002_REVENUE_TEMP
          SET END_CUSTOMER_ID = 'JORDAN'
         WHERE UPPER(END_CUSTOMER_ID) = 'APPLE' ;
		 iTracePoint := 1130 ;
      EXCEPTION
      WHEN OTHERS THEN
           NULL;
   END ;
   --End Add kangi 20130315


   iTracePoint := 1200 ;
   cCURRENT_PERIOD := TO_CHAR(SYSDATE,'YYYYMM') ;
   iTracePoint := 1300 ;
   FOR KPI_VEW001_REC in KPI_VEW001_CUR  LOOP
       iTracePoint := 1400 ;
       --DELETE RWF_SAP002_REVENUE_ACTUAL
       DELETE RWF_SAP002_REVENUE_ACTUAL
          WHERE RWF_YYYY = SUBSTR(KPI_VEW001_REC.PERIOD,1,4)
            AND RWF_MM = SUBSTR(KPI_VEW001_REC.PERIOD,5,2) ;
       iTracePoint := 1500 ;

       --GET BILL END DATE BY MONTH
       IF to_number(cCURRENT_PERIOD) > to_number(KPI_VEW001_REC.PERIOD) THEN
          iTracePoint := 1600 ;
          dBILLING_END_DATE_BY_MON := LAST_DAY(TO_DATE(KPI_VEW001_REC.PERIOD||'01','YYYYMMDD')) ;
       ELSE
          iTracePoint := 1700 ;
          dBILLING_END_DATE_BY_MON := TRUNC(SYSDATE-1) ;
          --SELECT TO_DATE(MAX(POSTING_DATE),'YYYYMMDD') INTO dBILLING_END_DATE_BY_MON FROM RWF_ZOT002_REVENUE_TEMP WHERE PERIOD = KPI_VEW001_REC.PERIOD ;
       END IF;

       iTracePoint := 1800 ;
       --INSERT RWF_SAP002_REVENUE_ACTUAL
       INSERT INTO RWF_SAP002_REVENUE_ACTUAL
       (RWF_YYYY,RWF_MM,RWF_TYPE,
          COMPANY_CODE,PROFIT_CENTER,RECEIVE_PROFIT_CENTER,
          CUSTOMER_ID,END_CUSTOMER_ID,BILLING_END_DATE_BY_MON,
          NET_REVENUE,NET_REVENUE_USD,NET_REVENUE_TWD,
        --Add kangi 20111229
          NET_REVENUE_CNY,
        --End Add kangi 20111229
          CREATE_DATE,MTL_GROUP,PROJECT_TYPE,
          END_CUSTOMER_NAME)
       SELECT SUBSTR(PERIOD,1,4) RFS_YYYY,SUBSTR(PERIOD,5,2) RFS_MM,'ACTUAL' RFS_TYPE,
              COMPANY_CODE,PROFIT_CENTER,PARTNER_PROFIT_CENTER RECEIVE_PROFIT_CENTER,
	            CUSTOMER_ID,END_CUSTOMER_ID END_CUSTOMER_NAME,
	            dBILLING_END_DATE_BY_MON,
	            SUM(NET_REVENUE) NET_REVENUE,
	            SUM(NET_REVENUE_USD) NET_REVENUE_USD,
	            SUM(NET_REVENUE_TWD) NET_REVENUE_TWD,
	          --Add kangi 20111229
	            SUM(NET_REVENUE_CNY) NET_REVENUE_CNY,
	          --End Add kangi 20111229
	            TO_CHAR(SYSDATE,'YYYYMMDD')
        --Add by kangi on 20071015
                    ,MTL_GROUP,PROJECT_TYPE
        --End Add by kangi on 20071015
        --Add by kangi on 20090218
                    ,END_CUSTOMER_NAME
        --End Add by kangi on 20090218
       FROM RWF_ZOT002_REVENUE_TEMP
       WHERE RELATED_PARTY = 'N'
         AND PERIOD = KPI_VEW001_REC.PERIOD
         AND NET_REVENUE <> 0
         --Modify by kangi on 20071015
         -- GROUP BY PERIOD,COMPANY_CODE,PROFIT_CENTER,PARTNER_PROFIT_CENTER,CUSTOMER_ID,END_CUSTOMER_ID  ; Remark by kangi on 20071015
         --Modify by kangi on 20090218
         --GROUP BY PERIOD,COMPANY_CODE,PROFIT_CENTER,PARTNER_PROFIT_CENTER,CUSTOMER_ID,END_CUSTOMER_ID,MTL_GROUP,PROJECT_TYPE ;  Remark by kangi on 20090218
         GROUP BY PERIOD,COMPANY_CODE,PROFIT_CENTER,PARTNER_PROFIT_CENTER,CUSTOMER_ID,END_CUSTOMER_ID,MTL_GROUP,PROJECT_TYPE,END_CUSTOMER_NAME ;
         --End Modify by kangi on 20090218
         --End Modify by kangi on 20071015
       iTracePoint := 1900 ;

   END LOOP ;
   iTracePoint := 2000 ;
   COMMIT ;
   iTracePoint := 2100 ;
 EXCEPTION
     WHEN OTHERS THEN
            --rollback ;
            cErrorText := SQLERRM() ;
            MAIL_FILE_BIDBDBADMIN(in_to_name=>'kangi@ms.usi.com.tw',subject   => 'PL/SQL RWF_PLS001_ACTUAL_REVENUE ERROR', message => '[RWF_PLS001_ACTUAL_REVENUE], The tracepoint is  ' || to_char(iTracePoint) || 'and ErrorText=' || cErrorText) ;
            DBMS_OUTPUT.PUT_LINE(SUBSTR(cErrorText,1,255));
            DBMS_OUTPUT.PUT_LINE(TO_CHAR(iTracePoint));
END RWF_PLS001_ACTUAL_REVENUE;
/

