create PROCEDURE       pnl3_pls003_unut_trx_s02 (
   incompany         IN   VARCHAR2,
   inperiod          IN   VARCHAR2,
   inprofit_center   IN   VARCHAR2,
   inglaccount       IN   VARCHAR,
   inamt             IN   NUMBER,
   inrevenue         IN   NUMBER,
   inrevenue_usd     IN   NUMBER,
   inrevenue_twd     IN   NUMBER,
   incogs            IN   NUMBER,
   incogs_usd        IN   NUMBER,
   incogs_twd        IN   NUMBER,
   indm              IN   NUMBER,
   indm_usd          IN   NUMBER,
   indm_twd          IN   NUMBER,
   indl              IN   NUMBER,
   indl_usd          IN   NUMBER,
   indl_twd          IN   NUMBER,
   inoh              IN   NUMBER,
   inoh_usd          IN   NUMBER,
   inoh_twd          IN   NUMBER
--2008/9/17 Create to Process get Amount in Local/USD/TWD
--Trigger by PNL2_BAD_DEPT_UPLOAD.JSP
)
AUTHID DEFINER
IS
  --2008/11/7 有發現  SUM(NET_REVENUE) <> 0 OR SUM(NET_COGS)  <> 0 條件成立但dm/dl/oh卻有值的戕況,因此不加入此條件
-- 在INSERT進資料庫時再排除金額=0的資料
   a_rate            NUMBER (20, 10);
   a_trate           NUMBER (20, 10);
   a_endcustomer     kpi_sap001_copa_trx.end_customer_id%TYPE;
   a_net_revenue     kpi_sap001_copa_trx.net_revenue%TYPE;
   a_revenue_local   kpi_sap001_copa_trx.net_revenue%TYPE;
   a_revenue_twd     kpi_sap001_copa_trx.net_revenue%TYPE;
   a_revenue_usd     kpi_sap001_copa_trx.net_revenue%TYPE;
   a_cogs_dm_local   kpi_sap001_copa_trx.net_revenue%TYPE;
   a_cogs_dm_twd     kpi_sap001_copa_trx.net_revenue%TYPE;
   a_cogs_dm_usd     kpi_sap001_copa_trx.net_revenue%TYPE;
   a_cogs_dl_local   kpi_sap001_copa_trx.net_revenue%TYPE;
   a_cogs_dl_twd     kpi_sap001_copa_trx.net_revenue%TYPE;
   a_cogs_dl_usd     kpi_sap001_copa_trx.net_revenue%TYPE;
   a_cogs_oh_local   kpi_sap001_copa_trx.net_revenue%TYPE;
   a_cogs_oh_twd     kpi_sap001_copa_trx.net_revenue%TYPE;
   a_cogs_oh_usd     kpi_sap001_copa_trx.net_revenue%TYPE;
BEGIN
   a_trate := 0;

   /*
   FOR REC1 in (SELECT END_CUSTOMER_ID,NVL(SUM(AMT_TWD),0) AMT_TWD FROM PNL3_TRX001_COPA
                   WHERE PROFIT_CENTER = inPROFIT_CENTER
                     AND PERIOD = inPeriod
                     --AND SOURCE <> 'UPL001'
                     AND AREA1 = '1'
                     AND AREA2 = '1'
                     AND AREA3 = '0'
                     GROUP BY END_CUSTOMER_ID ORDER BY AMT_TWD DESC) Loop*/
   FOR rec1 IN (SELECT end_customer_id, rate
                  FROM pnl3_map001_customer_rate
                 WHERE r_kind = 'PL01'        --隨便抓一筆來用,反正匯率都一樣
                   AND area1 = '4'
                   AND area2 = '1'
                   AND area3 = '1'
                   --AND COMPANY_CODE = REC1.COMPANY_CODE
                   AND profit_center = inprofit_center
                   AND period = inperiod)
   LOOP
      a_rate := rec1.rate;

      IF a_rate <> 0
      THEN
         INSERT INTO pnl3_trx003_unutilization
                     (company_code, period, profit_center, part_no,
                      total_hrs, pn_hrs, net_revenue,
                      net_revenue_twd,
                      net_revenue_usd,
                      net_cogs,
                      net_cogs_twd,
                      net_cogs_usd,
                      cogs_mb,
                      cogs_mb_twd,
                      cogs_mb_usd,
                      cogs_lb,
                      cogs_lb_twd,
                      cogs_lb_usd,
                      cogs_ob,
                      cogs_ob_twd,
                      cogs_ob_usd, o_net_revenue,
                      o_net_cogs, rate, cost_element, end_customer_id,
                      sql_method, customer_rate, create_date
                     )
              VALUES (incompany, inperiod, inprofit_center, NULL,
                      0, 0, ROUND (inrevenue * a_rate, 5),
                      ROUND (inrevenue_twd * a_rate, 5),
                      ROUND (inrevenue_usd * a_rate, 5),
                      ROUND (incogs * a_rate, 5),
                      ROUND (incogs_twd * a_rate, 5),
                      ROUND (incogs_usd * a_rate, 5),
                      ROUND (indm * a_rate, 5),
                      ROUND (indm_twd * a_rate, 5),
                      ROUND (indm_usd * a_rate, 5),
                      ROUND (indl * a_rate, 5),
                      ROUND (indl_twd * a_rate, 5),
                      ROUND (indl_usd * a_rate, 5),
                      ROUND (inoh * a_rate, 5),
                      ROUND (inoh_twd * a_rate, 5),
                      ROUND (inoh_usd * a_rate, 5), inrevenue_twd,
                      incogs_twd, 0, inglaccount, rec1.end_customer_id,
                      'WH=0/T_AMT<>0', a_rate, SYSDATE
                     );

         COMMIT;
      END IF;
   END LOOP;
END pnl3_pls003_unut_trx_s02;
/

