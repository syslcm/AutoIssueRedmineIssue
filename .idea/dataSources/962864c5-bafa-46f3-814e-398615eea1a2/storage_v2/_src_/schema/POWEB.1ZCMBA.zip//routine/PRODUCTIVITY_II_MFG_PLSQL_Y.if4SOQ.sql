create PROCEDURE Productivity_Ii_Mfg_Plsql_Y
IS
/*-----------------------------------------------------------------------------------------------------------------------------*
        CREATE DATE:  2009/11/19
         PLSQL      :
         Author     :  Shuya
         Purpose    :  PRODUCTIVITY MFG Report by yearly
                           26 for TW SH SZ , 01 for MX
*------------------------------------------------------------------------------------------------------------------------------*/

 vPROCESS_YYYY  VARCHAR2(6);
 vProductivity   NUMBER(13,4);
 iTracePoint    VARCHAR2(100);
 cErrorText     VARCHAR2(500);

BEGIN

  --抓上月份系統日期
  iTracePoint := '000';
  vPROCESS_YYYY := TO_CHAR(SYSDATE-7, 'YYYY');

  --清除重覆資料
  iTracePoint := '200';
  DELETE FROM PRODUCTIVITY_II_MFG_YY WHERE YY = vPROCESS_YYYY;

  --取約當數量& WO Actual LH hrs (by local currency)
  iTracePoint := '300';
  INSERT INTO PRODUCTIVITY_II_MFG_YY
   SELECT   company_code, vPROCESS_YYYY, usipn, profit_center, division, SUM(sum_qty),
            SUM (lh), '', '', '', '0', '0', SYSDATE
       FROM PRODUCTIVITY_II_MFG_MM
      WHERE period LIKE vPROCESS_YYYY || '%'
   GROUP BY   company_code, usipn, division;

  --計算當期生產力
  iTracePoint := '400';
  UPDATE PRODUCTIVITY_II_MFG_YY
   SET PRODUCTIVITY = sum_qty/lh
    WHERE  lh IS NOT NULL AND lh <> 0 AND YY = vPROCESS_YYYY;

   --計算總人工工時
   iTracePoint := '700';
   FOR rec1 IN (SELECT COMPANY_CODE, DIVISION, SUM(LH) AS SUM_LH FROM PRODUCTIVITY_II_MFG_YY WHERE YY = vPROCESS_YYYY GROUP BY COMPANY_CODE, DIVISION)
   LOOP
     UPDATE PRODUCTIVITY_II_MFG_YY
        SET LH_SUM = rec1.SUM_LH
	  WHERE company_code = rec1.company_code
		AND YY = vPROCESS_YYYY
		AND division = rec1.division;
   END LOOP;

   --計算人工工時百分比
   iTracePoint := '800';
   UPDATE PRODUCTIVITY_II_MFG_YY
      SET LH_PERCENT = LH / LH_SUM  WHERE YY=vPROCESS_YYYY;

   --取前期生產力 (去年)
   iTracePoint := '900';
   FOR rec1 IN (SELECT * FROM PRODUCTIVITY_II_MFG_YY WHERE YY = vPROCESS_YYYY)
   LOOP
      FOR rec2 IN(
        SELECT Productivity
            FROM PRODUCTIVITY_II_MFG_YY
            WHERE  (Productivity IS NOT NULL OR Productivity <> 0)
			  AND ROWNUM = 1
			  AND company_code = rec1.company_code
			  AND YY < vPROCESS_YYYY
			  AND division = rec1.division
			  AND usipn = rec1.usipn
			ORDER BY YY DESC)
		LOOP
	      UPDATE PRODUCTIVITY_II_MFG_YY
              SET last_productivity = rec2.Productivity
			  WHERE company_code = rec1.company_code
			    AND YY = rec1.YY
			    AND usipn = rec1.usipn
			    AND division = rec1.division;
		END LOOP;
   END LOOP;

   --計算基期生產力(前期生產力*嫁動百分比)
   iTracePoint := '1100';
   UPDATE PRODUCTIVITY_II_MFG_YY
      SET BASE_PRODUCTIVITY = LH_PERCENT * LAST_PRODUCTIVITY WHERE yy=vPROCESS_YYYY;

   --計算基期生產力(若無前期生產力，則以當月生產力*嫁動百分比)
   UPDATE PRODUCTIVITY_II_MFG_YY
      SET BASE_PRODUCTIVITY = LH_PERCENT * PRODUCTIVITY WHERE YY=vPROCESS_YYYY AND (BASE_PRODUCTIVITY =0 OR BASE_PRODUCTIVITY IS NULL);

   COMMIT;
EXCEPTION
   WHEN OTHERS THEN
    --有錯誤產生則寄mail
    cErrorText := SQLERRM();
    Mail_File_Bidbdbadmin(in_to_name => 'shuya@ms.usi.com.tw', subject => '[PRODUCTIVITY-Error] PL/SQL PRODUCTIVITY_II_MFG_PLSQL_Y ERROR', message => '[Table:PRODUCTIVITY_II_MFG_YY], The tracepoint is  ' || iTracePoint || ' and ErrorText= ' || cErrorText||' and vPROCESS_YYYY ='||vPROCESS_YYYY  ) ;

END Productivity_Ii_Mfg_Plsql_Y;
/

