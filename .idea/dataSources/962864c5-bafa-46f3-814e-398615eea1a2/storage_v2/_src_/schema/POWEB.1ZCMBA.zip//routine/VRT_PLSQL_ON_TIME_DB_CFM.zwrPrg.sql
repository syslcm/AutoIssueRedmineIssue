create PROCEDURE "VRT_PLSQL_ON_TIME_DB_CFM" (
  inCompany  in VARCHAR2
)
AUTHID DEFINER
IS

   /*
    每月執行一次 (透過 PLD_KPI_PO_OVERDUE.java )
    1. 抓 PLD_KPI_PO_OVERDUE (DA) / VRT_ZOT003_ONTIME_DELV_WEEK (DB) 資料
    2. Insert to VRT_ZOT001_ONTIME_DELIVERY table
    3. 計算寫到 VRT_MAP030_SUMMARY_GRAD
   */


  iTracePoint                varchar2(100);
  cErrorText                 varchar2(500);
  vPROCEE_YYYYMM             varchar2(6);
  vPERCENTAGE_L1             VRT_MAP020_RATE_INDEX.PERCENTAGE%TYPE;
  vPERCENTAGE_L2             VRT_MAP020_RATE_INDEX.PERCENTAGE%TYPE;
  vPERCENTAGE_L3             VRT_MAP020_RATE_INDEX.PERCENTAGE%TYPE;

BEGIN
    --抓上個月份
    iTracePoint := '100';
    vPROCEE_YYYYMM := TO_CHAR(ADD_MONTHS(SYSDATE, -1), 'YYYYMM');

    --先清舊的資料以避免重覆
    iTracePoint := '200-' || vPROCEE_YYYYMM || '-' || inCompany;
    DELETE FROM VRT_ZOT001_ONTIME_DELIVERY WHERE COMPANY_CODE = inCompany
       and P_YEAR = substr(vPROCEE_YYYYMM,1,4) and P_MONTH = substr(vPROCEE_YYYYMM,5,2);
    commit;

    --處理 PLD_KPI_PO_OVERDUE (DA)
    iTracePoint := '300-' || vPROCEE_YYYYMM || '-' || inCompany;
    for REC1 in (
          select COMPANY_CODE, VERSION, VENDOR_ID, SITE, sum(CFM_QTY) as CFM, sum(GR_QTY) as GR, round(sum(SCORES) / sum(CNT),0) as SCORE
            from (
               select COMPANY_CODE, VERSION, VENDOR_ID, CFM_QTY, GR_QTY, SITE,
                      decode(sign(T_SCORE),-1,0,decode(floor(T_SCORE / 100),0,T_SCORE,100)) as SCORES, 1 as CNT
                 from (
                    select COMPANY_CODE, VERSION, VENDOR_ID, CFM_QTY, GR_QTY, decode(PLANT_CODE,'1110','1110',COMPANY_CODE) as SITE,
                           ( 100 - ( ( to_date(GR_DATE,'YYYYMMDD') - to_date(CFM_DATE,'YYYYMMDD') - 3 ) * 25 ) ) as T_SCORE
                      from PLD_KPI_PO_OVERDUE
                     where COMPANY_CODE = inCompany
                       and VERSION = vPROCEE_YYYYMM
                       and GR_DATE >= CFM_DATE
                       and GR_DATE is not null
                       and CFM_DATE is not null )
               union all
               select COMPANY_CODE, VERSION, VENDOR_ID, CFM_QTY, GR_QTY, decode(PLANT_CODE,'1110','1110',COMPANY_CODE) as SITE,
                      100 as SCORES, 1 as CNT
                 from PLD_KPI_PO_OVERDUE
                where COMPANY_CODE = inCompany
                  and VERSION = vPROCEE_YYYYMM
                  and GR_DATE < CFM_DATE
                  and GR_DATE is not null
                  and CFM_DATE is not null
                  and NVL(EARLY_DAY,0) = 0
               union all
               select COMPANY_CODE, VERSION, VENDOR_ID, CFM_QTY, GR_QTY, SITE,
                      decode(sign(T_SCORE),-1,0,decode(floor(T_SCORE / 100),0,T_SCORE,100)) as SCORES, 1 as CNT
                 from (
                    select COMPANY_CODE, VERSION, VENDOR_ID, CFM_QTY, GR_QTY, decode(PLANT_CODE,'1110','1110',COMPANY_CODE) as SITE,
                           ( 100 - ( ( ( to_date(CFM_DATE,'YYYYMMDD') - to_date(GR_DATE,'YYYYMMDD') - EARLY_DAY ) * 100 ) / EARLY_DAY ) ) as T_SCORE
                      from PLD_KPI_PO_OVERDUE
                     where COMPANY_CODE = inCompany
                       and VERSION = vPROCEE_YYYYMM
                       and GR_DATE < CFM_DATE
                       and GR_DATE is not null
                       and CFM_DATE is not null
                       and NVL(EARLY_DAY,0) > 0 )
          ) group by COMPANY_CODE, VERSION, VENDOR_ID, SITE
    ) loop
       --放到 VRT_ZOT001_ONTIME_DELIVERY (DA)
       iTracePoint := '330-' || REC1.COMPANY_CODE || '-' || REC1.VENDOR_ID || '-' || vPROCEE_YYYYMM;
       insert into VRT_ZOT001_ONTIME_DELIVERY (
              P_YEAR, P_MONTH, P_QUARTER, COMPANY_CODE, SITE, VENDOR_CODE, PTYPE, SCORES, GR_QTY, CFM_QTY
            ) values (
              substr(REC1.VERSION, 1, 4),
              substr(REC1.VERSION, 5, 2),
              trim('Q' || to_char(to_date(REC1.VERSION || '01','YYYYMMDD'), 'Q')),
              REC1.COMPANY_CODE,
              REC1.SITE,
              REC1.VENDOR_ID,
              'DA',
              REC1.SCORE,
              REC1.GR,
              REC1.CFM
            );
       commit;
    end loop;


    --處理 VRT_ZOT003_ONTIME_DELV_WEEK (DB)
    iTracePoint := '400-' || vPROCEE_YYYYMM || '-' || inCompany;
    for REC1 in (
          select P_YEAR, P_MONTH, P_QUARTER, COMPANY_CODE, SITE, VENDOR_CODE, PTYPE,
                 sum(CFM_4A5_QTY) as CFM, sum(GR_QTY) as GR, round(sum(SCORE) / sum(CNT),0) as SCORE
            from (
              select P_YEAR, P_MONTH, P_QUARTER, COMPANY_CODE, SITE, VENDOR_CODE, PTYPE, CFM_4A5_QTY, GR_QTY, SCORE, 1 as CNT
                from VRT_ZOT003_ONTIME_DELV_WEEK
               where COMPANY_CODE = inCompany
                 and P_YEAR = substr(vPROCEE_YYYYMM,1,4)
                 and P_MONTH = substr(vPROCEE_YYYYMM,5,2)
                 and GR_QTY > 0
          ) group by P_YEAR, P_MONTH, P_QUARTER, COMPANY_CODE, SITE, VENDOR_CODE, PTYPE
    ) loop
       --放到 VRT_ZOT001_ONTIME_DELIVERY (DB)
       iTracePoint := '430-' || REC1.COMPANY_CODE || '-' || REC1.VENDOR_CODE || '-' || vPROCEE_YYYYMM;
       insert into VRT_ZOT001_ONTIME_DELIVERY (
              P_YEAR, P_MONTH, P_QUARTER, COMPANY_CODE, SITE, VENDOR_CODE, PTYPE, SCORES, GR_QTY, CFM_QTY
            ) values (
              REC1.P_YEAR,
              REC1.P_MONTH,
              REC1.P_QUARTER,
              REC1.COMPANY_CODE,
              REC1.SITE,
              REC1.VENDOR_CODE,
              REC1.PTYPE,
              REC1.SCORE,
              REC1.GR,
              REC1.CFM
            );
       commit;
    end loop;

  --抓各階分數
  iTracePoint := '500';
  vPERCENTAGE_L1 := null;
  vPERCENTAGE_L2 := null;
  vPERCENTAGE_L3 := null;

  for REC1 in ( select LEVEL_S, PERCENTAGE from VRT_MAP020_RATE_INDEX
                 where INDEX_KEY = 'DELIVERY' and TYPE = 'D1' ) loop
    if REC1.LEVEL_S = 'L1' then
      iTracePoint := '510';
      vPERCENTAGE_L1 := REC1.PERCENTAGE;
    elsif REC1.LEVEL_S = 'L2' then
      iTracePoint := '520';
      vPERCENTAGE_L2 := REC1.PERCENTAGE;
    elsif REC1.LEVEL_S = 'L3' then
      iTracePoint := '530';
      vPERCENTAGE_L3 := REC1.PERCENTAGE;
    end if;
  end loop;

  if vPERCENTAGE_L1 is null or vPERCENTAGE_L2 is null or vPERCENTAGE_L3 is null then
    --若沒抓到資料則寄 error mail
    iTracePoint := '550';
    cErrorText := 'vPERCENTAGE_L1 is ' || nvl(to_char(vPERCENTAGE_L1),'null') || ',vPERCENTAGE_L2 is ' || nvl(to_char(vPERCENTAGE_L2),'null') || ',vPERCENTAGE_L3 is ' || nvl(to_char(vPERCENTAGE_L3),'null');
    MAIL_FILE_BIDBDBADMIN(in_to_name => 'minhorng@ms.usi.com.tw', subject => '[VRT] PL/SQL VRT_PLSQL_ON_TIME_DB_CFM ERROR', message => '[VRT_PLSQL_ON_TIME_DB_CFM], The tracepoint is  ' || iTracePoint || ' and ErrorText= ' || cErrorText) ;
  else
    --先清舊的資料以避免重覆
    iTracePoint := '600-' || vPROCEE_YYYYMM;
    delete from VRT_MAP030_SUMMARY_GRAD where TYPE = 'D1' and BUKRS = inCompany
       and YYYY = substr(vPROCEE_YYYYMM,1,4) and MM = substr(vPROCEE_YYYYMM,5,2);
    commit;

    --放入上月分數
    iTracePoint := '620';
    for REC1 in (
            select SITE, VENDOR_CODE, P_YEAR, P_MONTH, P_QUARTER, COMPANY_CODE,
                   round(sum(SCORES * GR_QTY) / sum(GR_QTY),5) as SCORE
              from VRT_ZOT001_ONTIME_DELIVERY
             where P_YEAR = substr(vPROCEE_YYYYMM,1,4)
               and P_MONTH = substr(vPROCEE_YYYYMM,5,2)
               and COMPANY_CODE = inCompany
             group by SITE, VENDOR_CODE, P_YEAR, P_MONTH, P_QUARTER, COMPANY_CODE
    ) loop
      --放到 VRT_MAP030_SUMMARY_GRAD
      iTracePoint := '640-' || REC1.SITE || '-' || REC1.VENDOR_CODE || '-' || vPROCEE_YYYYMM;
      insert into VRT_MAP030_SUMMARY_GRAD (
             SITE, LIFNR, TYPE, YYYY, MM, QUARTER, BUKRS, L1, GRADE_L1, L2, GRADE_L2, L3, GRADE_L3, L4, GRADE_L4
           ) values (
             REC1.SITE,
             REC1.VENDOR_CODE,
             'D1',
             REC1.P_YEAR,
             REC1.P_MONTH,
             REC1.P_QUARTER,
             REC1.COMPANY_CODE,
             'S0',
             round(REC1.SCORE * vPERCENTAGE_L1, 5),
             'D0',
             round(REC1.SCORE * vPERCENTAGE_L2, 5),
             'D1',
             round(REC1.SCORE * vPERCENTAGE_L3, 5),
             null,
             null
           );
      commit;
    end loop;
  end if;

  --2007/5/22 add by Minhorng
  VRTN_PLSQL_ON_TIME_DB_CFM(inCompany);

EXCEPTION
  When OTHERS Then
    --有錯誤產生則寄mail
    cErrorText := SQLERRM();
    MAIL_FILE_BIDBDBADMIN(in_to_name => 'minhorng@ms.usi.com.tw', subject => '[VRT] PL/SQL VRT_PLSQL_ON_TIME_DB_CFM ERROR', message => '[VRT_PLSQL_ON_TIME_DB_CFM], The tracepoint is  ' || iTracePoint || ' and ErrorText= ' || cErrorText) ;
END;
/

