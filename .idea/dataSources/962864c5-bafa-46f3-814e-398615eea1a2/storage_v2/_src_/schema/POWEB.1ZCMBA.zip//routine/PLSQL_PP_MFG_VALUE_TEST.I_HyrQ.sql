create PROCEDURE PLSQL_PP_MFG_VALUE_TEST(
  inCompany  in PP_MFG_VALUE_001.COMPANY_CODE%TYPE,
  f_YYYYMMDD in VARCHAR2,
  t_YYYYMMDD in VARCHAR2
)
is
 iTracePoint  integer ;
 cErrorText varchar2(500);
 vPROCEE_YYYYMMDD varchar2(8);
 vYYYYMMDD varchar2(8);
 vYYYYMM varchar2(6);
 vYYYY varchar2(4);
 rYYYY varchar2(4);
 vMM varchar2(2);
 rMM varchar2(2);
 vDD varchar2(2);
 vDAYS_A varchar2(2);
 iDAYS_T integer;
 iDAYS_A integer;
 iRATE number(3,2);

 --NEW
 iiDAYS_T varchar2(2);
 rrDAYS_A varchar2(2);
 rDAYS_A integer;
 rRATE number(3,2);
 --new
 rYYYYMM varchar2(6);
 fYYYYMM varchar2(6);
BEGIN
  iTracePoint := '000';


  vPROCEE_YYYYMMDD  :=  to_char(sysdate-1,'YYYYMMDD');


   iTracePoint := '300';
   vPROCEE_YYYYMMDD  :=  to_char(sysdate,'YYYYMMDD');
   vYYYYMM := substr(vPROCEE_YYYYMMDD,1,6);

   --new
   rYYYYMM := substr(f_YYYYMMDD,1,6);
   rYYYY := substr(f_YYYYMMDD,1,4);
   rMM := substr(f_YYYYMMDD,5,2);
   --new

   vYYYY := substr(vPROCEE_YYYYMMDD,1,4);
   vMM := substr(vPROCEE_YYYYMMDD,5,2);
   vDD := substr(vPROCEE_YYYYMMDD,7,2);
   --vYYYY := substr(f_YYYYMMDD,1,4);
   --vMM := substr(f_YYYYMMDD,5,2);
   --vDD := substr(f_YYYYMMDD,7,2);
   iDAYS_T := to_number(vDD);

   --delete from PP_MFG_VALUE_DAYS where yyyymmdd =  vPROCEE_YYYYMMDD;
   delete from PP_MFG_VALUE_DAYS where yyyymm =  vYYYYMM;

   Commit;

   delete from PP_MFG_VALUE_DAYS where yyyymm =  rYYYYMM;

   Commit;

   iTracePoint := '400';

   select to_number(max(DD)) into iDAYS_A from dimension_date where yyyy = vYYYY and mm = vMM;

   iDAYS_T := iDAYS_T - 1;
   iRATE := iDAYS_T / iDAYS_A;
   vDAYS_A := to_char(iDAYS_A);
   iiDAYS_T := to_char(iDAYS_T);

   select to_number(max(DD)) into rDAYS_A from dimension_date where yyyy = rYYYY and mm = rMM;

   rRATE := rDAYS_A / rDAYS_A;
   rrDAYS_A := to_char(rDAYS_A);

   iTracePoint := '500';

   INSERT INTO PP_MFG_VALUE_DAYS (YYYYMM,YYYY,MM,DD,DAYS,RATE) VALUES (vYYYYMM,vYYYY,vMM,iiDAYS_T,vDAYS_A,iRATE);


   Commit;

   INSERT INTO PP_MFG_VALUE_DAYS (YYYYMM,YYYY,MM,DD,DAYS,RATE) VALUES (rYYYYMM,rYYYY,rMM,rrDAYS_A,rrDAYS_A,rRATE);


   Commit;

EXCEPTION
   When OTHERS Then
    --有錯誤產生則寄mail
    cErrorText := SQLERRM();
    MAIL_FILE_BIDBDBADMIN(in_to_name => 'sam_chen@ms.usi.com.tw', subject => '[VRT] PL/SQL PP_MFG_VALUE_001', message => '[PP_MFG_VALUE_001], The tracepoint is  ' || iTracePoint || ' and ErrorText= ' || cErrorText) ;


END PLSQL_PP_MFG_VALUE_TEST;
/

