create Function       USI11731(
cYYYY in KPI_MAP006_EXCHANGE_RATE.YYYY%TYPE,
cMM in KPI_MAP006_EXCHANGE_RATE.MM%TYPE,
cLocal_Currency in KPI_MAP006_EXCHANGE_RATE.FROM_CURRENCY%TYPE,
cChangeCurrency in KPI_MAP006_EXCHANGE_RATE.TO_CURRENCY%TYPE,
sGL_TYPE in KPI_SAP005_GL_SUM_BY_PF.GL_TYPE%TYPE)
return number
is
nExchange   number;
nEXCHANGE_RATEUSD  number ;
nUSDEXCHANGE_RATETWD  number ;
Begin
 ------------------------------------
 --餘額R(資產)End , 異動T(損益)Avg
 ------------------------------------
 IF sGL_TYPE = 'R' Then
    If trim(cLocal_Currency) = trim(cChangeCurrency) Then
       nExchange := 1 ;
    Else
        If not (cLocal_Currency = 'USD' AND cChangeCurrency = 'TWD') THEN
           ---Process USD
           If cLocal_Currency = 'GBP' Then
              SELECT   a.EXCH_RATE INTO nEXCHANGE_RATEUSD
                   FROM kpi_map013_exchange_rate_end a,
                      (SELECT   from_currency, to_currency,
                         MAX (YYYY || MM) valid_from_date
                   FROM kpi_map013_exchange_rate_end
                  WHERE (YYYY || MM) <= cYYYY||cMM
                      GROUP BY from_currency, to_currency) b
                WHERE a.from_currency = b.from_currency
                  AND a.to_currency = b.to_currency
                  AND (a.YYYY || a.MM) = b.valid_from_date
                  AND a.to_currency = 'USD'
                  AND a.from_currency = cLocal_Currency
                      ORDER BY a.from_currency;
           Else
             SELECT   1/a.EXCH_RATE INTO nEXCHANGE_RATEUSD
                  FROM kpi_map013_exchange_rate_end a,
                     (SELECT   from_currency, to_currency,
                        MAX (YYYY || MM) valid_from_date
                   FROM kpi_map013_exchange_rate_end
                  WHERE (YYYY || MM) <= cYYYY||cMM
                      GROUP BY from_currency, to_currency) b
                WHERE a.from_currency = b.from_currency
                  AND a.to_currency = b.to_currency
                  AND (a.YYYY || a.MM) = b.valid_from_date
                  AND a.to_currency = cLocal_Currency
                  AND a.from_currency = 'USD'
                      ORDER BY a.from_currency;
          End If;
       End If;
          If cChangeCurrency = 'USD' Then
             nExchange := ROUND(nEXCHANGE_RATEUSD,5) ;
          Else
          ---Process USD to TWD
               SELECT   a.EXCH_RATE INTO nUSDEXCHANGE_RATETWD
                  FROM kpi_map013_exchange_rate_end a,
                     (SELECT   from_currency, to_currency,
                        MAX (YYYY || MM) valid_from_date
                   FROM kpi_map013_exchange_rate_end
                  WHERE (YYYY || MM) <= cYYYY||cMM
                      GROUP BY from_currency, to_currency) b
                WHERE a.from_currency = b.from_currency
                  AND a.to_currency = b.to_currency
                  AND (a.YYYY || a.MM) = b.valid_from_date
                  AND a.to_currency = 'TWD'
                  AND a.from_currency = 'USD'
                      ORDER BY a.from_currency;
               If cLocal_Currency = 'USD' AND cChangeCurrency = 'TWD' THEN
                  nExchange := ROUND(nUSDEXCHANGE_RATETWD,5) ;
               Else
                  nExchange := ROUND(nEXCHANGE_RATEUSD*nUSDEXCHANGE_RATETWD,5) ;
               End If;

          End If ;
   End If;
 Else
      If trim(cLocal_Currency) = trim(cChangeCurrency) Then
         nExchange := 1 ;
      Else
        If not (cLocal_Currency = 'USD' AND cChangeCurrency = 'TWD') THEN
          ---Process USD
          If cLocal_Currency = 'GBP' Then
             SELECT   a.EXCH_RATE INTO nEXCHANGE_RATEUSD
                  FROM KPI_MAP006_EXCHANGE_RATE a,
                     (SELECT   from_currency, to_currency,
                        MAX (YYYY || MM) valid_from_date
                   FROM KPI_MAP006_EXCHANGE_RATE
                  WHERE (YYYY || MM) <= cYYYY||cMM
                      GROUP BY from_currency, to_currency) b
                WHERE a.from_currency = b.from_currency
                  AND a.to_currency = b.to_currency
                  AND (a.YYYY || a.MM) = b.valid_from_date
                  AND a.to_currency = 'USD'
                  AND a.from_currency = cLocal_Currency
                      ORDER BY a.from_currency;
          Else
             SELECT   1/a.EXCH_RATE INTO nEXCHANGE_RATEUSD
                  FROM KPI_MAP006_EXCHANGE_RATE a,
                     (SELECT   from_currency, to_currency,
                        MAX (YYYY || MM) valid_from_date
                   FROM KPI_MAP006_EXCHANGE_RATE
                  WHERE (YYYY || MM) <= cYYYY||cMM
                      GROUP BY from_currency, to_currency) b
                WHERE a.from_currency = b.from_currency
                  AND a.to_currency = b.to_currency
                  AND (a.YYYY || a.MM) = b.valid_from_date
                  AND a.to_currency = cLocal_Currency
                  AND a.from_currency = 'USD'
                      ORDER BY a.from_currency;
          End If;
       End If;
          If cChangeCurrency = 'USD' Then
             nExchange := ROUND(nEXCHANGE_RATEUSD,5) ;
          Else
          ---Process USD to TWD
               SELECT   a.EXCH_RATE INTO nUSDEXCHANGE_RATETWD
                  FROM KPI_MAP006_EXCHANGE_RATE a,
                     (SELECT   from_currency, to_currency,
                        MAX (YYYY || MM) valid_from_date
                   FROM KPI_MAP006_EXCHANGE_RATE
                  WHERE (YYYY || MM) <= cYYYY||cMM
                      GROUP BY from_currency, to_currency) b
                WHERE a.from_currency = b.from_currency
                  AND a.to_currency = b.to_currency
                  AND (a.YYYY || a.MM) = b.valid_from_date
                  AND a.to_currency = 'TWD'
                  AND a.from_currency = 'USD'
                      ORDER BY a.from_currency;
               If cLocal_Currency = 'USD' AND cChangeCurrency = 'TWD' THEN
                  nExchange := ROUND(nUSDEXCHANGE_RATETWD,5) ;
               Else
                  nExchange := ROUND(nEXCHANGE_RATEUSD*nUSDEXCHANGE_RATETWD,5) ;
               End If;
          End If ;
     End If ;
 End If ;
       return nExchange ;
    Exception
      WHEN NO_DATA_FOUND THEN
         return 0 ;
End USI11731;
/

