create PROCEDURE PLSQL_R1MAIL (
inCompany  in VARCHAR2)
AUTHID DEFINER
is
   --f_PERIOD            VARCHAR2(6);
   --t_PERIOD            VARCHAR2(6);
   --r_PERIOD            VARCHAR2(6);

BEGIN

  
 --抓CURRENCY_LOCAL
 
  
    for REC1 in (
  select * from R1MAIL_KS
--  and SYS_DAT >= f_YYYYMMDD
--  and SYS_DAT <= t_YYYYMMDD
 ) loop  
 --計算匯率
  --DEL TABLE KPI_CO01_SCRAP_DET
  
  UPDATE R1MAIL SET EMAIL = REC1.NEW_MAIL WHERE EMAIL = REC1.OLD_MAIL AND COMPANY_CODE = '4100'; 
  
  Commit;
  
end loop;  
  
  
      
END PLSQL_R1MAIL;
/

