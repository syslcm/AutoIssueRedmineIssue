create PROCEDURE       ROA_PLS002_CO_MH_RATE (
/* ********************************************************************
  PROG-ID      : ROA_PLS002_CO_MH_RATE
  PROG-ACTION  : 
  Author       : Asan Chang
  Date         : 2017/03/23
  OA Number    : SAI069417
********************************************************************* */
   incompany    IN   VARCHAR2,
   f_yyyymmdd   IN   VARCHAR2,
   t_yyyymmdd   IN   VARCHAR2
)
AUTHID DEFINER
IS
   CURSOR ROA_SAP002_CO_MH_RATE_T
   IS
      SELECT COMPANY_CODE, PERIOD, COST_CENTER, PC, ROA_PD, MH, MH_RATE
               
      FROM ROA_SAP002_CO_MH_RATE_T
      where COMPANY_CODE = incompany;


   itracepoint   INTEGER;
BEGIN

     --(1)清除舊資料
     DELETE FROM ROA_SAP002_CO_MH_RATE
     where PERIOD IN  (SELECT PERIOD FROM ROA_SAP002_CO_MH_RATE_T )
     AND   COMPANY_CODE = incompany;
     COMMIT;  

   FOR REC1 IN ROA_SAP002_CO_MH_RATE_T LOOP
   
   --(3)開始處理資料
       INSERT INTO ROA_SAP002_CO_MH_RATE (
          COMPANY_CODE,          PERIOD,              COST_CENTER,                  PC, 
          ROA_PD,                MH,                  MH_RATE
          ) VALUES (
                 
          REC1.COMPANY_CODE,     REC1.PERIOD,         REC1.COST_CENTER,             REC1.PC, 
          REC1.ROA_PD,           REC1.MH,             REC1.MH_RATE
           );   
       COMMIT;

   END LOOP;

   --(3) 刪除資料
   DELETE FROM ROA_SAP002_CO_MH_RATE_T
   where COMPANY_CODE = incompany;
   COMMIT;
   
   
END ROA_PLS002_CO_MH_RATE;
/

