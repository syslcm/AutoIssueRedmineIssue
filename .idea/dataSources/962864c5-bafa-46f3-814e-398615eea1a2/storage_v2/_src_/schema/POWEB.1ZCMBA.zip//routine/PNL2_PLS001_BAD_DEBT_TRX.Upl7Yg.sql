create PROCEDURE pnl2_pls001_bad_debt_trx (
   incompany   IN   VARCHAR2,
   t_period    IN   VARCHAR2
--2008/9/17 Create to Process get Amount in Local/USD/TWD
--Trigger by PNL2_BAD_DEPT_UPLOAD.JSP
--2009/1/19 用customer id去對到PNL3_TRX001_COPA 的CUSTOMER ID來抓END CUSTOMER,(KYE:PC+SITE+CUSTOMER_ID)
--但會發生台灣BILLING後來在大陸發生呆帳的狀況
--註:材料轉售排除
--2009/3/10 COMPANY CODE:1101歸給ABIT M/B
--2009/11/18 BILL_TO_PARTY = 480006歸到OTHERS去,因為是一次性客戶
--2010/09/23 wenrong BILL_TO_PARTY 0000012504   = Zarlink , 0000455661  = X-Rite, 0000456467 = Sagem,因為抓不到營收
--2011/1/28 wenrong BILL_TO_PARTY 0000456396 = CPT  因為2009為cmo,2010為cpt,但正確為cpt
--2012/09/12 kangi 更改程式錯誤抓pnl3_trx001_copa　的end_customer_id　需要先排序完再用ROWNUM = 1
--2015/01/29 針對 Profit Center (00000000S7 , 00000000S8) 更新為 (S7 , S8) 所有英文字適用
)
AUTHID DEFINER
IS
   CURSOR c_pnl2_pls001_t
   IS
      SELECT   period, company_code, profit_center, customer_id,
               end_customer_id, biuser, currency, uploadsite,
               NVL (SUM (amount), 0) AS amt_local
          FROM pnl2_upl002_bad_debt_t
         WHERE uploadsite = incompany
      GROUP BY period,
               company_code,
               profit_center,
               customer_id,
               end_customer_id,
               biuser,
               currency,
               uploadsite;

   t_currency_local   pnl2_upl002_bad_debt.currency_local%TYPE;
   a_ex_rate_usd      pnl2_upl002_bad_debt.ex_rate_usd%TYPE;
   a_ex_rate_twd      pnl2_upl002_bad_debt.ex_rate_twd%TYPE;
   a_customer         pnl2_upl002_bad_debt.end_customer_id%TYPE;
   a_period           pnl2_upl002_bad_debt.period%TYPE;
   p_period string(4);
BEGIN
   DELETE FROM pnl2_upl002_bad_debt
         WHERE period IN (SELECT   period
                              FROM pnl2_upl002_bad_debt_t
                             WHERE uploadsite = incompany
                          GROUP BY period);

   COMMIT;

   p_period := SUBSTRB (t_period, 1, 4) - 1;

   FOR rec1 IN c_pnl2_pls001_t
   LOOP
      --抓CURRENCY_LOCAL
      t_currency_local := rec1.currency;
      --計算匯率
      a_ex_rate_twd := NULL;
      a_ex_rate_usd := NULL;
      a_ex_rate_usd :=
         get_exchange_rate (SUBSTRB (rec1.period, 1, 4),
                            SUBSTRB (rec1.period, 5, 2),
                            t_currency_local,
                            'USD',
                            'T'
                           );
      a_ex_rate_twd :=
         get_exchange_rate (SUBSTRB (rec1.period, 1, 4),
                            SUBSTRB (rec1.period, 5, 2),
                            t_currency_local,
                            'TWD',
                            'T'
                           );
      a_customer := 'OTHERS';
      IF REC1.COMPANY_CODE = '1101' THEN
        a_customer := 'ABIT M/B';
      ELSIF rec1.customer_id = '0000480006'
      THEN
         a_customer := 'OTHERS';
      ELSIF rec1.customer_id = '0000012504'
      THEN
         a_customer := 'ZARLINK';
      ELSIF rec1.customer_id = '0000455661'
      THEN
         a_customer := 'X-RITE';
      ELSIF rec1.customer_id = '0000456467'
      THEN
         a_customer := 'SAGEM';
      ELSIF rec1.customer_id = '0000456396'
      THEN
         a_customer := 'CPT';
      ELSE
       BEGIN
         --Modify kangi 20120912
         --SELECT DISTINCT end_customer_id, period
         --           INTO a_customer, a_period
         --           FROM pnl3_trx001_copa
         --          WHERE bill_to_party = rec1.customer_id
         --            AND profit_center = rec1.profit_center
         --            AND company_code = rec1.company_code
         --            AND ( period LIKE SUBSTRB (rec1.period, 1, 4) || '%' or period like p_period || '%' )
         --            AND ROWNUM = 1
         --            AND end_customer_id <> '其他-材料轉售'
         --            order by period desc;
         SELECT end_customer_id, period INTO a_customer, a_period FROM
          (SELECT DISTINCT end_customer_id, period
                    FROM pnl3_trx001_copa
                   WHERE bill_to_party = rec1.customer_id
                     AND profit_center = rec1.profit_center
                     AND company_code = rec1.company_code
                     AND ( period LIKE SUBSTRB (rec1.period, 1, 4) || '%' or period like p_period || '%' )
                     AND end_customer_id <> '其他-材料轉售'
                     order by period desc )
         WHERE ROWNUM = 1;
         --End Modify kangi 20120912
       EXCEPTION
         WHEN OTHERS
         THEN
            a_customer := 'OTHERS';
       END;

       IF a_customer = 'OTHERS'
        THEN
         BEGIN
            --Modify kangi 20120912
            --SELECT DISTINCT end_customer_id, period
            --           INTO a_customer, a_period
            --           FROM pnl3_trx001_copa
            --          WHERE bill_to_party = rec1.customer_id
            --            --AND PROFIT_CENTER = REC1.PROFIT_CENTER
            --            AND company_code = rec1.company_code
            --            AND ( period LIKE SUBSTRB (rec1.period, 1, 4) || '%' or period like p_period || '%' )
            --            --AND period LIKE SUBSTRB (rec1.period, 1, 4) || '%'
            --            AND ROWNUM = 1
            --            AND end_customer_id <> '其他-材料轉售'
            --            order by period desc;
            SELECT end_customer_id, period INTO a_customer, a_period FROM
             (SELECT DISTINCT end_customer_id, period
                    FROM pnl3_trx001_copa
                   WHERE bill_to_party = rec1.customer_id
                     --AND PROFIT_CENTER = REC1.PROFIT_CENTER
                     AND company_code = rec1.company_code
                     AND ( period LIKE SUBSTRB (rec1.period, 1, 4) || '%' or period like p_period || '%' )
                     --AND period LIKE SUBSTRB (rec1.period, 1, 4) || '%'
                     AND end_customer_id <> '其他-材料轉售'
                     order by period desc )
            WHERE ROWNUM = 1;
            --End Modify kangi 20120912
         EXCEPTION
            WHEN OTHERS
            THEN
               a_customer := 'OTHERS';
         END;
       END IF;

       IF a_customer = 'OTHERS'
        THEN
         BEGIN
            --Modify kangi 20120912
            --SELECT DISTINCT end_customer_id, period
            --           INTO a_customer, a_period
            --           FROM pnl3_trx001_copa
            --          WHERE bill_to_party = rec1.customer_id
            --            --AND PROFIT_CENTER = REC1.PROFIT_CENTER
            --            --AND COMPANY_CODE = REC1.COMPANY_CODE
            --            AND ( period LIKE SUBSTRB (rec1.period, 1, 4) || '%' or period like p_period || '%' )
            --            --AND period LIKE SUBSTRB (rec1.period, 1, 4) || '%'
            --            AND ROWNUM = 1
            --            AND end_customer_id <> '其他-材料轉售'
            --            order by period desc;
            SELECT end_customer_id, period INTO a_customer, a_period FROM
             (SELECT DISTINCT end_customer_id, period
                    FROM pnl3_trx001_copa
                   WHERE bill_to_party = rec1.customer_id
                     --AND PROFIT_CENTER = REC1.PROFIT_CENTER
                     --AND COMPANY_CODE = REC1.COMPANY_CODE
                     AND ( period LIKE SUBSTRB (rec1.period, 1, 4) || '%' or period like p_period || '%' )
                     --AND period LIKE SUBSTRB (rec1.period, 1, 4) || '%'
                     AND end_customer_id <> '其他-材料轉售'
                     order by period desc )
            WHERE ROWNUM = 1;
            --End Modify kangi 20120912
         EXCEPTION
            WHEN OTHERS
            THEN
               a_customer := 'OTHERS';
         END;
       END IF;
      END IF;
      INSERT INTO pnl2_upl002_bad_debt
                  (period, company_code, profit_center,
                   amount_local, currency_local,
                   amount_twd, ex_rate_twd,
                   amount_usd, ex_rate_usd,
                   customer_id, upload_end_customer_id, create_date,
                   biuser, uploadsite, end_customer_id
                  )
           VALUES (rec1.period, rec1.company_code, rec1.profit_center,
                   rec1.amt_local, rec1.currency,
                   ROUND (rec1.amt_local * a_ex_rate_twd, 5), a_ex_rate_twd,
                   ROUND (rec1.amt_local * a_ex_rate_usd, 5), a_ex_rate_usd,
                   rec1.customer_id, rec1.end_customer_id, SYSDATE,
                   rec1.biuser, rec1.uploadsite, a_customer
                  );

      COMMIT;
   END LOOP;
   --Add kangi 20150129
   BEGIN
   UPDATE PNL2_UPL002_BAD_DEBT
      SET PROFIT_CENTER = lZEROCANCEL(PROFIT_CENTER)
    WHERE PERIOD IN (SELECT  PERIOD FROM PNL2_UPL002_BAD_DEBT_T
                      WHERE UPLOADSITE = INCOMPANY
                      GROUP BY PERIOD)
      AND TRANSLATE(PROFIT_CENTER,'\0123456789','\') IS NOT NULL ;
   EXCEPTION
          WHEN OTHERS Then
		  NULL ;
   END;
   --End Add kangi 20150129

   DELETE FROM pnl2_upl002_bad_debt_t
         WHERE uploadsite = incompany;

   COMMIT;
END pnl2_pls001_bad_debt_trx;
/

