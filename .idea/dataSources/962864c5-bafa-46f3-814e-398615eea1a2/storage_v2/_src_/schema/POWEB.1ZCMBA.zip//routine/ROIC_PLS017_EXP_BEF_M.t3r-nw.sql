create PROCEDURE       ROIC_PLS017_EXP_BEF_M (
/* ********************************************************************
  PROG-ID      : ROIC_PLS017_EXP_BEF_M
  PROG-ACTION  : 
  Author       : Asan Chang
  Date         : 2019/12/10
  OA Number    : SAI110424
  Description  : Save Expense data for alloc 
********************************************************************* 
*/
   incompany    IN   VARCHAR2,
   YYYYMM       IN   VARCHAR2
)
AUTHID DEFINER
IS
   CURSOR ROIC_ALL_EXP
   IS
   /*----------------------------------*/       

   SELECT a.company_code, a.period, a.cost_element, a.CATEGORY, b.fun_area,
          a.sender, b.group_acct, a.amt_loc, a.amt_twd, a.amt_usd, a.amt_cny,
          ' ' AS holding_legail_code, 'A' AS use_code, ' ' AS class_code,
          ' ' AS reason_code, d.name_budget_en, ' ' AS from_site, a.sortkey,
          CAST (' ' AS NVARCHAR2 (1)) AS remark,
          DECODE (a.ns_pc, NULL, c.profit_center, a.ns_pc) AS profit_center,
          'ORIGINAL' AS data_type
     FROM roic_vew012_exp_bef a,
          roic_vew001_sap_acct_mapping b,
          kpi_map018_organization c,
          kpi_map019_account d
    WHERE a.company_code = b.company_code(+)
      AND a.cost_element = b.sap_acct(+)
      AND NVL (a.CATEGORY, ' ') = b.fun_area_alias(+)
      AND a.company_code = c.company_code(+)
      AND a.period = c.period(+)
      AND a.sender = c.sap_cost_center(+)
      AND a.company_code = d.company_code(+)
      AND a.cost_element = d.sap_cost_element(+)
      AND a.period BETWEEN d.from_period(+) AND d.to_period(+)
      AND a.sortkey = 'A'          -- 20191018 Ray_Lin required (For ORIGINAL)    
      AND a.company_code = incompany
      AND a.period = YYYYMM
   UNION ALL
-- ADJUST
   SELECT a.company_code, a.period, a.cost_element, a.CATEGORY, a.fun_area,
          a.sender, a.group_acct, a.amt_loc, a.amt_twd, a.amt_usd, a.amt_cny,
          a.holding_legail_code, 'A' AS use_code,
          NVL ((SELECT h.class_code
                  FROM roic_upl012_adj_reason_mapping h
                 WHERE h.use_code = 'A' AND h.reason_code = a.reason_code),
               ' '
              ) AS class_code,
          a.reason_code, a.name_budget_en, a.from_site, a.sortkey, a.remark,
          c.profit_center, 'ADJ' AS data_type
     FROM roic_upl013_exp_adj a, kpi_map018_organization c
    WHERE a.company_code = c.company_code(+) AND a.period = c.period(+)
     AND a.sender = c.sap_cost_center(+)
     AND a.company_code = incompany
     AND a.period = YYYYMM;
    

      
   itracepoint         INTEGER;
   tmp_OWN_TYPE        VARCHAR(1);  --'A':���u���B, 'B':���v���B
   TMP_AMT1            NUMBER(15,5);
   TMP_AMT2            NUMBER(15,5);
   TMP_AMT3            NUMBER(15,5);
   TMP_AMT4            NUMBER(15,5);   
   TMP_AMT5            NUMBER(15,5);
   TMP_AMT6            NUMBER(15,5);  
   TMP_AMT7            NUMBER(15,5);
   TMP_AMT8            NUMBER(15,5);    
   TMP_CCTR            VARCHAR(10);
   EX_RATE_TWD1        NUMBER(15,5);
   EX_RATE_USD1        NUMBER(15,5);
   EX_RATE_CNY1        NUMBER(15,5);
   NEW_COMPANY_CODE    VARCHAR(4);
   sPROC_NAME          ROIC_PST000_LOG.PROC_NAME%TYPE;
   sRUN_SEQ            ROIC_PST000_LOG.RUN_SEQ%TYPE;
   sRUN_DESC           ROIC_PST000_LOG.RUN_DESC%TYPE;
   sPARAMETER_DESC     ROIC_PST000_LOG.PARAMETER_DESC%TYPE;    
BEGIN

  --(0)Insert Log start
  sPROC_NAME := 'ROIC_PLS017_EXP_BEF_M';
  sRUN_SEQ   := '000010';
  sRUN_DESC  := 'Start';
  sPARAMETER_DESC := CONCAT(CONCAT(CONCAT('PERIOD=',YYYYMM),';Site='),incompany);
  
  
  INSERT INTO ROIC_PST000_LOG
      ( PROC_NAME, RUN_SEQ, RUN_DESC, PARAMETER_DESC )
    VALUES
      ( sPROC_NAME, sRUN_SEQ, sRUN_DESC, sPARAMETER_DESC );
  Commit;

     --(1)�M��������
     DELETE FROM ROIC_PST017_EXP_BEF_M
     where PERIOD       = YYYYMM
     AND   COMPANY_CODE = incompany;
     COMMIT;  
    

   FOR REC1 IN ROIC_ALL_EXP LOOP
   BEGIN
       INSERT INTO ROIC_PST017_EXP_BEF_M (
       PERIOD,
       COMPANY_CODE,
       COST_ELEMENT,
       CATEGORY,
       FUN_AREA,
       SENDER,
       GROUP_ACCT,
       AMT_LOC,
       AMT_TWD,
       AMT_USD,
       AMT_CNY,
       HOLDING_LEGAIL_CODE,
	   CLASS_CODE,
       REASON_CODE,
       NAME_BUDGET_EN,
       FROM_SITE,
       SORTKEY,
       REMARK,
       PROFIT_CENTER,
       DATA_TYPE
                  
       ) VALUES (  
       REC1.PERIOD,
       REC1.COMPANY_CODE,
       REC1.COST_ELEMENT,
       REC1.CATEGORY,
       REC1.FUN_AREA,
       REC1.SENDER,
       REC1.GROUP_ACCT,
       REC1.AMT_LOC,
       REC1.AMT_TWD,
       REC1.AMT_USD,
       REC1.AMT_CNY,
       REC1.HOLDING_LEGAIL_CODE,
	   REC1.CLASS_CODE,
       REC1.REASON_CODE,
       REC1.NAME_BUDGET_EN,
       REC1.FROM_SITE,
       REC1.SORTKEY,
       REC1.REMARK,
       REC1.PROFIT_CENTER,
       REC1.DATA_TYPE
	   );       
      
       COMMIT;  

     END;
     
     
   END LOOP;

  -----------------------------------------
  --(0)Insert Log end
  sRUN_SEQ   := '000020';
  sRUN_DESC  := 'End';

  --Insert Log
  INSERT INTO ROIC_PST000_LOG
      ( PROC_NAME, RUN_SEQ, RUN_DESC, PARAMETER_DESC )
    VALUES
      ( sPROC_NAME, sRUN_SEQ, sRUN_DESC, sPARAMETER_DESC );
  Commit;   
   
END ROIC_PLS017_EXP_BEF_M;
/

