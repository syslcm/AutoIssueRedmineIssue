create PROCEDURE       pnl3_pls003_unut_trx_s01 (
   --2008/12/29 從PNL3_PLS003_UNUT_TRX_S01_V3 回復,改回原本邏輯profit_center+ 工時,
   --2008/12/29 新增邏輯,只要cost center有維護在PNL3_MAP005_UNT_COST_CETNER的就到KPI_SAP012_EXPENSE_HISTORY
   --抓取金額後直接歸客戶,剩下的再用工時分
   --備份2008/12/22 PNL3_PLS003_UNUT_TRX_S01
   incompany         IN   VARCHAR2,
   inperiod          IN   VARCHAR2,
   inprofit_center   IN   VARCHAR2,
   inglaccount       IN   VARCHAR,
   inamount          IN   NUMBER,
   intotal_hrs       IN   NUMBER,
   inrevenue         IN   NUMBER,
   inrevenue_usd     IN   NUMBER,
   inrevenue_twd     IN   NUMBER,
   incogs            IN   NUMBER,
   incogs_usd        IN   NUMBER,
   incogs_twd        IN   NUMBER,
   indm              IN   NUMBER,
   indm_usd          IN   NUMBER,
   indm_twd          IN   NUMBER,
   indl              IN   NUMBER,
   indl_usd          IN   NUMBER,
   indl_twd          IN   NUMBER,
   inoh              IN   NUMBER,
   inoh_usd          IN   NUMBER,
   inoh_twd          IN   NUMBER
)
AUTHID DEFINER
IS
   a_rate             NUMBER (20, 10);
   a_miss_rate        NUMBER (20, 10);    --找不到end customer時用revenue來分
   a_total_hrs        pnl2_trx003_un_utilization.total_hrs%TYPE;
   a_counter          INTEGER;                                 --record count
   a_amount           kpi_sap001_copa_trx.net_revenue%TYPE;
   a_endcustomer      pnl3_trx001_copa.end_customer_id%TYPE;
   a_net_revenue      kpi_sap001_copa_trx.net_revenue%TYPE;
   a_revenue_local    kpi_sap001_copa_trx.net_revenue%TYPE;
   a_revenue_twd      kpi_sap001_copa_trx.net_revenue%TYPE;
   a_revenue_usd      kpi_sap001_copa_trx.net_revenue%TYPE;
   a_cogs_dm_local    kpi_sap001_copa_trx.net_revenue%TYPE;
   a_cogs_dm_twd      kpi_sap001_copa_trx.net_revenue%TYPE;
   a_cogs_dm_usd      kpi_sap001_copa_trx.net_revenue%TYPE;
   a_cogs_dl_local    kpi_sap001_copa_trx.net_revenue%TYPE;
   a_cogs_dl_twd      kpi_sap001_copa_trx.net_revenue%TYPE;
   a_cogs_dl_usd      kpi_sap001_copa_trx.net_revenue%TYPE;
   a_cogs_oh_local    kpi_sap001_copa_trx.net_revenue%TYPE;
   a_cogs_oh_twd      kpi_sap001_copa_trx.net_revenue%TYPE;
   a_cogs_oh_usd      kpi_sap001_copa_trx.net_revenue%TYPE;
   a_cogs_local       kpi_sap001_copa_trx.net_revenue%TYPE;
   a_cogs_twd         kpi_sap001_copa_trx.net_revenue%TYPE;
   a_cogs_usd         kpi_sap001_copa_trx.net_revenue%TYPE;
   o_revenue          kpi_sap001_copa_trx.net_revenue%TYPE;
   o_cogs             kpi_sap001_copa_trx.net_revenue%TYPE;
   a_cost_element     kpi_sap012_expense_history.cost_element%TYPE;
   t_currency_local   pnl2_upl002_bad_debt.currency_local%TYPE;
   a_ex_rate_usd      pnl2_upl002_bad_debt.ex_rate_usd%TYPE;
   a_ex_rate_twd      pnl2_upl002_bad_debt.ex_rate_twd%TYPE;
   l_cogs_dm_local    kpi_sap001_copa_trx.net_revenue%TYPE;
   l_cogs_dm_twd      kpi_sap001_copa_trx.net_revenue%TYPE;
   l_cogs_dm_usd      kpi_sap001_copa_trx.net_revenue%TYPE;
   l_cogs_dl_local    kpi_sap001_copa_trx.net_revenue%TYPE;
   l_cogs_dl_twd      kpi_sap001_copa_trx.net_revenue%TYPE;
   l_cogs_dl_usd      kpi_sap001_copa_trx.net_revenue%TYPE;
   l_cogs_oh_local    kpi_sap001_copa_trx.net_revenue%TYPE;
   l_cogs_oh_twd      kpi_sap001_copa_trx.net_revenue%TYPE;
   l_cogs_oh_usd      kpi_sap001_copa_trx.net_revenue%TYPE;
   l_cogs_local       kpi_sap001_copa_trx.net_revenue%TYPE;
   l_cogs_twd         kpi_sap001_copa_trx.net_revenue%TYPE;
   l_cogs_usd         kpi_sap001_copa_trx.net_revenue%TYPE;
   a_cost_center      pnl3_map005_unut_cost_center.cost_center%TYPE;
BEGIN
   a_revenue_local := inrevenue;
   a_revenue_twd := inrevenue_twd;
   a_revenue_usd := inrevenue_usd;
   a_cogs_dm_local := indm;
   a_cogs_dm_twd := indm_twd;
   a_cogs_dm_usd := indm_usd;
   a_cogs_dl_local := indl;
   a_cogs_dl_twd := indl_twd;
   a_cogs_dl_usd := indl_usd;
   a_cogs_oh_local := inoh;
   a_cogs_oh_twd := inoh_twd;
   a_cogs_oh_usd := inoh_usd;
   a_cogs_local := incogs;
   a_cogs_twd := incogs_twd;
   a_cogs_usd := incogs_usd;
   o_revenue := 0;
   o_cogs := 0;

   IF inglaccount = '0000510201'
   THEN
      a_cost_element := '0000529905';
   ELSIF inglaccount = '0000510301'
   THEN
      a_cost_element := '0000529907';
   ELSIF inglaccount = '0000510401'
   THEN
      a_cost_element := '0000529906';
   ELSE                                                           --0000529908
      a_cost_element := '0000529908';
   END IF;

   FOR rec1 IN (SELECT   a.cost_center, currency_local, cost_element,
                         NVL (SUM (amt_local), 0) amt_local
                    FROM kpi_sap012_expense_history a,
                         pnl3_map005_unut_cost_center b
                   WHERE cost_element = a_cost_element
                     AND a.period = inperiod
                     AND a.company_code = incompany
                     AND a.company_code = b.company_code
                     AND b.profit_center = inprofit_center
                     AND a.cost_center = b.cost_center
                GROUP BY a.cost_center, currency_local, cost_element)
   /*
   SELECT cost_center,sum(amt_local)
                  FROM kpi_sap012_expense_history
                 WHERE cost_element = a_cost_element
                   AND period = inperiod
                   AND company_code = incompany
                   group by cost_center)
                   */
   --AND profit_center = inprofit_center)
   LOOP
      a_cost_center := NULL;
      a_endcustomer := NULL;

      BEGIN
         SELECT cost_center, end_customer_id
           INTO a_cost_center, a_endcustomer
           FROM pnl3_map005_unut_cost_center
          WHERE company_code = incompany
            AND cost_center = rec1.cost_center
            AND profit_center = inprofit_center
            AND start_date <= SYSDATE
            AND end_date >= SYSDATE;
      EXCEPTION
         WHEN OTHERS
         THEN
            a_cost_center := NULL;
            a_endcustomer := NULL;
      END;

      IF a_cost_center IS NOT NULL
      THEN
         --抓CURRENCY_LOCAL
         t_currency_local := rec1.currency_local;
         --計算匯率
         a_ex_rate_twd := NULL;
         a_ex_rate_usd := NULL;
         a_ex_rate_usd :=
            get_exchange_rate (SUBSTRB (inperiod, 1, 4),
                               SUBSTRB (inperiod, 5, 2),
                               t_currency_local,
                               'USD',
                               'T'
                              );
         a_ex_rate_twd :=
            get_exchange_rate (SUBSTRB (inperiod, 1, 4),
                               SUBSTRB (inperiod, 5, 2),
                               t_currency_local,
                               'TWD',
                               'T'
                              );
         l_cogs_dm_local := 0;
         l_cogs_dm_twd := 0;
         l_cogs_dm_usd := 0;
         l_cogs_dl_local := 0;
         l_cogs_dl_twd := 0;
         l_cogs_dl_usd := 0;
         l_cogs_oh_local := 0;
         l_cogs_oh_twd := 0;
         l_cogs_oh_usd := 0;
         l_cogs_local := 0;
         l_cogs_twd := 0;
         l_cogs_usd := 0;

         --金額一律正轉負,負轉正,因為借貸方關係,
         IF rec1.cost_element = '0000529905'
         THEN
            l_cogs_dl_local := rec1.amt_local * -1;
            l_cogs_dl_twd := rec1.amt_local * a_ex_rate_twd * -1;
            l_cogs_dl_usd := rec1.amt_local * a_ex_rate_usd * -1;
         ELSIF rec1.cost_element = '0000529907'
         THEN
            l_cogs_oh_local := rec1.amt_local * -1;
            l_cogs_oh_twd := rec1.amt_local * a_ex_rate_twd * -1;
            l_cogs_oh_usd := rec1.amt_local * a_ex_rate_usd * -1;
         ELSIF rec1.cost_element = '0000529906'
         THEN
            l_cogs_oh_local := rec1.amt_local * -1;
            l_cogs_oh_twd := rec1.amt_local * a_ex_rate_twd * -1;
            l_cogs_oh_usd := rec1.amt_local * a_ex_rate_usd * -1;
         ELSE                                                     --0000529908
            l_cogs_oh_local := rec1.amt_local * -1;
            l_cogs_oh_twd := rec1.amt_local * a_ex_rate_twd * -1;
            l_cogs_oh_usd := rec1.amt_local * a_ex_rate_usd * -1;
         END IF;

         l_cogs_local := rec1.amt_local * -1;
         l_cogs_twd := rec1.amt_local * a_ex_rate_twd * -1;
         l_cogs_usd := rec1.amt_local * a_ex_rate_usd * -1;
         a_cogs_local := a_cogs_local - l_cogs_local;
         a_cogs_usd := a_cogs_usd - l_cogs_usd;
         a_cogs_twd := a_cogs_twd - l_cogs_twd;
         a_cogs_dm_local := a_cogs_dm_local - l_cogs_dm_local;
         a_cogs_dm_usd := a_cogs_dm_usd - l_cogs_dm_usd;
         a_cogs_dm_twd := a_cogs_dm_twd - l_cogs_dm_twd;
         a_cogs_dl_local := a_cogs_dl_local - l_cogs_dl_local;
         a_cogs_dl_usd := a_cogs_dl_usd - l_cogs_dl_usd;
         a_cogs_dl_twd := a_cogs_dl_twd - l_cogs_dl_twd;
         a_cogs_oh_local := a_cogs_oh_local - l_cogs_oh_local;
         a_cogs_oh_usd := a_cogs_oh_usd - l_cogs_oh_usd;
         a_cogs_oh_twd := a_cogs_oh_twd - l_cogs_oh_twd;

         INSERT INTO pnl3_trx003_unutilization
                     (company_code, period, profit_center, part_no,
                      total_hrs, pn_hrs, net_revenue, net_revenue_twd,
                      net_revenue_usd, net_cogs, net_cogs_twd,
                      net_cogs_usd, cogs_mb,
                      cogs_mb_twd, cogs_mb_usd,
                      cogs_lb, cogs_lb_twd,
                      cogs_lb_usd, cogs_ob,
                      cogs_ob_twd, cogs_ob_usd, o_net_revenue,
                      o_net_cogs, rate, cost_element, end_customer_id,
                      sql_method, customer_rate, create_date, cost_center
                     )
              VALUES (incompany, inperiod, inprofit_center, NULL,
                      0, 0, 0, 0,
                      0, ROUND (l_cogs_local, 5), ROUND (l_cogs_twd, 5),
                      ROUND (l_cogs_usd, 5), ROUND (l_cogs_dm_local, 5),
                      ROUND (l_cogs_dm_twd, 5), ROUND (l_cogs_dm_usd, 5),
                      ROUND (l_cogs_dl_local, 5), ROUND (l_cogs_dl_twd, 5),
                      ROUND (l_cogs_dl_usd, 5), ROUND (l_cogs_oh_local, 5),
                      ROUND (l_cogs_oh_twd, 5), ROUND (l_cogs_oh_usd, 5), 0,
                      l_cogs_local, 1, inglaccount, a_endcustomer,
                      'WH<>0/Directly', 1, SYSDATE, a_cost_center
                     );

         COMMIT;
      END IF;
   END LOOP;

   a_rate := 0;

   FOR rec1 IN (SELECT   part_no, NVL (SUM (total_hrs), 0) total_hrs
                    FROM kpi_sap012_expense_history
                   WHERE company_code = incompany
                     AND profit_center = inprofit_center
                     AND period = inperiod
                     AND TRANSACTION = 'RKL'
                GROUP BY part_no
                ORDER BY total_hrs DESC)
   LOOP
      --有出現TOTAL_HRS = 0 的料號,則此料號不入
      IF rec1.total_hrs <> 0
      THEN
         a_rate := rec1.total_hrs / intotal_hrs;

         IF a_rate <> 0
         THEN
            a_counter := 0;
            a_endcustomer := NULL;

            BEGIN
               SELECT DISTINCT TRIM (end_customer_name)
                          INTO a_endcustomer
                          FROM cep_map009_partno_customer
                         WHERE fg_material_no = Rpad(rec1.part_no,18,' ')
                           AND last_modify_date <= SYSDATE;
            EXCEPTION
               WHEN OTHERS
               THEN
                  a_endcustomer := NULL;
            END;

            IF a_endcustomer IS NULL THEN
            
              BEGIN 
                 SELECT TRIM(b.end_customer_name) INTO a_endcustomer
                          FROM cep_zot001_fg_bom_list_f a,
                               cep_map009_partno_customer b
                         WHERE a.fg_material_no= b.fg_material_no
                           AND a.raw_material_no= rpad(rec1.PART_NO,18,' ')
                           --AND a.PLANT = PNL3_TRX002_GLACCOUNT_T.PLANT_CODE
                           AND a.MFG_SITE = incompany
                           AND b.last_modify_date <= SYSDATE
                           AND ROWNUM = 1;
               EXCEPTION
               WHEN OTHERS
               THEN
                  a_endcustomer := NULL;
              END;
            END IF;
            
            IF a_endcustomer IS NOT NULL
            THEN
               INSERT INTO pnl3_trx003_unutilization
                           (company_code, period, profit_center,
                            part_no, total_hrs, pn_hrs,
                            net_revenue,
                            net_revenue_twd,
                            net_revenue_usd,
                            net_cogs,
                            net_cogs_twd,
                            net_cogs_usd,
                            cogs_mb,
                            cogs_mb_twd,
                            cogs_mb_usd,
                            cogs_lb,
                            cogs_lb_twd,
                            cogs_lb_usd,
                            cogs_ob,
                            cogs_ob_twd,
                            cogs_ob_usd, o_net_revenue,
                            o_net_cogs, rate, cost_element, end_customer_id,
                            sql_method, customer_rate, create_date
                           )
                    VALUES (incompany, inperiod, inprofit_center,
                            rec1.part_no, intotal_hrs, rec1.total_hrs,
                            ROUND (a_revenue_local * a_rate, 5),
                            ROUND (a_revenue_twd * a_rate, 5),
                            ROUND (a_revenue_usd * a_rate, 5),
                            ROUND (a_cogs_local * a_rate, 5),
                            ROUND (a_cogs_twd * a_rate, 5),
                            ROUND (a_cogs_usd * a_rate, 5),
                            ROUND (a_cogs_dm_local * a_rate, 5),
                            ROUND (a_cogs_dm_twd * a_rate, 5),
                            ROUND (a_cogs_dm_usd * a_rate, 5),
                            ROUND (a_cogs_dl_local * a_rate, 5),
                            ROUND (a_cogs_dl_twd * a_rate, 5),
                            ROUND (a_cogs_dl_usd * a_rate, 5),
                            ROUND (a_cogs_oh_local * a_rate, 5),
                            ROUND (a_cogs_oh_twd * a_rate, 5),
                            ROUND (a_cogs_oh_usd * a_rate, 5), a_revenue_twd,
                            a_cogs_twd, a_rate, inglaccount, a_endcustomer,
                            'WH<>0/T_AMT<>0', 1, SYSDATE
                           );

               COMMIT;
            ELSE
               --找不到end_customer或有多個end_customer時,依end customer 營收比率來分
               a_endcustomer := NULL;
               a_net_revenue := 0;

               IF inamount = 0
               THEN
                  -- NET_REVENUE =0的狀況,多發生在Profit center 9X ,全部歸到Others,
                        --2008/11/20 9x的抓upload的營收
                  IF inprofit_center = '0000000034'
                  THEN
                     INSERT INTO pnl3_trx003_unutilization
                                 (company_code, period, profit_center,
                                  part_no, total_hrs, pn_hrs,
                                  net_revenue,
                                  net_revenue_twd,
                                  net_revenue_usd,
                                  net_cogs,
                                  net_cogs_twd,
                                  net_cogs_usd,
                                  cogs_mb,
                                  cogs_mb_twd,
                                  cogs_mb_usd,
                                  cogs_lb,
                                  cogs_lb_twd,
                                  cogs_lb_usd,
                                  cogs_ob,
                                  cogs_ob_twd,
                                  cogs_ob_usd,
                                  o_net_revenue, o_net_cogs, rate,
                                  cost_element, end_customer_id,
                                  sql_method, customer_rate, create_date
                                 )
                          VALUES (incompany, inperiod, inprofit_center,
                                  rec1.part_no, intotal_hrs, rec1.total_hrs,
                                  ROUND (a_revenue_local * a_rate, 5),
                                  ROUND (a_revenue_twd * a_rate, 5),
                                  ROUND (a_revenue_usd * a_rate, 5),
                                  ROUND (a_cogs_local * a_rate, 5),
                                  ROUND (a_cogs_twd * a_rate, 5),
                                  ROUND (a_cogs_usd * a_rate, 5),
                                  ROUND (a_cogs_dm_local * a_rate, 5),
                                  ROUND (a_cogs_dm_twd * a_rate, 5),
                                  ROUND (a_cogs_dm_usd * a_rate, 5),
                                  ROUND (a_cogs_dl_local * a_rate, 5),
                                  ROUND (a_cogs_dl_twd * a_rate, 5),
                                  ROUND (a_cogs_dl_usd * a_rate, 5),
                                  ROUND (a_cogs_oh_local * a_rate, 5),
                                  ROUND (a_cogs_oh_twd * a_rate, 5),
                                  ROUND (a_cogs_oh_usd * a_rate, 5),
                                  a_revenue_twd, a_cogs_twd, a_rate,
                                  inglaccount, 'UABIT''S CUST',
                                  'WH<>0/T_AMT=0', 1, SYSDATE
                                 );

                     COMMIT;
                  ELSIF SUBSTR (inprofit_center, 1, 9) = '000000009'
                  THEN
                     IF SUBSTR (incompany, 1, 1) = '9'
                     THEN
                        INSERT INTO pnl3_trx003_unutilization
                                    (company_code, period, profit_center,
                                     part_no, total_hrs,
                                     pn_hrs,
                                     net_revenue,
                                     net_revenue_twd,
                                     net_revenue_usd,
                                     net_cogs,
                                     net_cogs_twd,
                                     net_cogs_usd,
                                     cogs_mb,
                                     cogs_mb_twd,
                                     cogs_mb_usd,
                                     cogs_lb,
                                     cogs_lb_twd,
                                     cogs_lb_usd,
                                     cogs_ob,
                                     cogs_ob_twd,
                                     cogs_ob_usd,
                                     o_net_revenue, o_net_cogs, rate,
                                     cost_element, end_customer_id,
                                     sql_method, customer_rate, create_date
                                    )
                             VALUES (incompany, inperiod, inprofit_center,
                                     rec1.part_no, intotal_hrs,
                                     rec1.total_hrs,
                                     ROUND (a_revenue_local * a_rate, 5),
                                     ROUND (a_revenue_twd * a_rate, 5),
                                     ROUND (a_revenue_usd * a_rate, 5),
                                     ROUND (a_cogs_local * a_rate, 5),
                                     ROUND (a_cogs_twd * a_rate, 5),
                                     ROUND (a_cogs_usd * a_rate, 5),
                                     ROUND (a_cogs_dm_local * a_rate, 5),
                                     ROUND (a_cogs_dm_twd * a_rate, 5),
                                     ROUND (a_cogs_dm_usd * a_rate, 5),
                                     ROUND (a_cogs_dl_local * a_rate, 5),
                                     ROUND (a_cogs_dl_twd * a_rate, 5),
                                     ROUND (a_cogs_dl_usd * a_rate, 5),
                                     ROUND (a_cogs_oh_local * a_rate, 5),
                                     ROUND (a_cogs_oh_twd * a_rate, 5),
                                     ROUND (a_cogs_oh_usd * a_rate, 5),
                                     a_revenue_twd, a_cogs_twd, a_rate,
                                     inglaccount, '投資公司',
                                     'WH<>0/T_AMT=0', 1, SYSDATE
                                    );

                        COMMIT;
                     ELSE
                        a_counter := 0;

                        FOR rec2 IN (SELECT end_customer_id, rate
                                       FROM pnl3_map001_customer_rate
                                      WHERE r_kind = 'PL01'
                                        --隨便抓一筆來用,反正匯率都一樣
                                        AND area1 = '4'
                                        AND area2 = '1'
                                        AND area3 = '1'
                                        --AND COMPANY_CODE = REC1.COMPANY_CODE
                                        AND profit_center = inprofit_center
                                        AND period = inperiod)
                        LOOP
                           a_counter := 1;

                           INSERT INTO pnl3_trx003_unutilization
                                       (company_code, period,
                                        profit_center, part_no,
                                        total_hrs, pn_hrs,
                                        net_revenue,
                                        net_revenue_twd,
                                        net_revenue_usd,
                                        net_cogs,
                                        net_cogs_twd,
                                        net_cogs_usd,
                                        cogs_mb,
                                        cogs_mb_twd,
                                        cogs_mb_usd,
                                        cogs_lb,
                                        cogs_lb_twd,
                                        cogs_lb_usd,
                                        cogs_ob,
                                        cogs_ob_twd,
                                        cogs_ob_usd,
                                        o_net_revenue, o_net_cogs, rate,
                                        cost_element, end_customer_id,
                                        sql_method, customer_rate,
                                        create_date
                                       )
                                VALUES (incompany, inperiod,
                                        inprofit_center, rec1.part_no,
                                        intotal_hrs, rec1.total_hrs,
                                        ROUND (  a_revenue_local
                                               * rec2.rate
                                               * a_rate,
                                               5
                                              ),
                                        ROUND (  a_revenue_twd
                                               * rec2.rate
                                               * a_rate,
                                               5
                                              ),
                                        ROUND (  a_revenue_usd
                                               * rec2.rate
                                               * a_rate,
                                               5
                                              ),
                                        ROUND (a_cogs_local * rec2.rate
                                               * a_rate,
                                               5
                                              ),
                                        ROUND (a_cogs_twd * rec2.rate * a_rate,
                                               5
                                              ),
                                        ROUND (a_cogs_usd * rec2.rate * a_rate,
                                               5
                                              ),
                                        ROUND (  a_cogs_dm_local
                                               * rec2.rate
                                               * a_rate,
                                               5
                                              ),
                                        ROUND (  a_cogs_dm_twd
                                               * rec2.rate
                                               * a_rate,
                                               5
                                              ),
                                        ROUND (  a_cogs_dm_usd
                                               * rec2.rate
                                               * a_rate,
                                               5
                                              ),
                                        ROUND (  a_cogs_dl_local
                                               * rec2.rate
                                               * a_rate,
                                               5
                                              ),
                                        ROUND (  a_cogs_dl_twd
                                               * rec2.rate
                                               * a_rate,
                                               5
                                              ),
                                        ROUND (  a_cogs_dl_usd
                                               * rec2.rate
                                               * a_rate,
                                               5
                                              ),
                                        ROUND (  a_cogs_oh_local
                                               * rec2.rate
                                               * a_rate,
                                               5
                                              ),
                                        ROUND (  a_cogs_oh_twd
                                               * rec2.rate
                                               * a_rate,
                                               5
                                              ),
                                        ROUND (  a_cogs_oh_usd
                                               * rec2.rate
                                               * a_rate,
                                               5
                                              ),
                                        a_revenue_twd, a_cogs_twd, rec2.rate,
                                        inglaccount, rec2.end_customer_id,
                                        'WH<>0/T_AMT=0', a_rate,
                                        SYSDATE
                                       );

                           COMMIT;
                        END LOOP;

                        IF a_counter = 0
                        THEN
                           FOR rec2 IN (SELECT end_customer_id, rate
                                          FROM pnl3_map001_global_cust_rate
                                         WHERE r_kind = 'PL01'
                                           --隨便抓一筆來用,反正匯率都一樣
                                           AND area1 = '4'
                                           AND area2 = '1'
                                           AND area3 = '1'
                                           --AND COMPANY_CODE = REC1.COMPANY_CODE
                                           --AND PROFIT_CENTER = REC1.PROFIT_CENTER
                                           AND period = inperiod)
                           LOOP
                              INSERT INTO pnl3_trx003_unutilization
                                          (company_code, period,
                                           profit_center, part_no,
                                           total_hrs, pn_hrs,
                                           net_revenue,
                                           net_revenue_twd,
                                           net_revenue_usd,
                                           net_cogs,
                                           net_cogs_twd,
                                           net_cogs_usd,
                                           cogs_mb,
                                           cogs_mb_twd,
                                           cogs_mb_usd,
                                           cogs_lb,
                                           cogs_lb_twd,
                                           cogs_lb_usd,
                                           cogs_ob,
                                           cogs_ob_twd,
                                           cogs_ob_usd,
                                           o_net_revenue, o_net_cogs, rate,
                                           cost_element,
                                           end_customer_id,
                                           sql_method, customer_rate,
                                           create_date
                                          )
                                   VALUES (incompany, inperiod,
                                           inprofit_center, rec1.part_no,
                                           intotal_hrs, rec1.total_hrs,
                                           ROUND (  a_revenue_local
                                                  * rec2.rate
                                                  * a_rate,
                                                  5
                                                 ),
                                           ROUND (  a_revenue_twd
                                                  * rec2.rate
                                                  * a_rate,
                                                  5
                                                 ),
                                           ROUND (  a_revenue_usd
                                                  * rec2.rate
                                                  * a_rate,
                                                  5
                                                 ),
                                           ROUND (  a_cogs_local
                                                  * rec2.rate
                                                  * a_rate,
                                                  5
                                                 ),
                                           ROUND (  a_cogs_twd
                                                  * rec2.rate
                                                  * a_rate,
                                                  5
                                                 ),
                                           ROUND (  a_cogs_usd
                                                  * rec2.rate
                                                  * a_rate,
                                                  5
                                                 ),
                                           ROUND (  a_cogs_dm_local
                                                  * rec2.rate
                                                  * a_rate,
                                                  5
                                                 ),
                                           ROUND (  a_cogs_dm_twd
                                                  * rec2.rate
                                                  * a_rate,
                                                  5
                                                 ),
                                           ROUND (  a_cogs_dm_usd
                                                  * rec2.rate
                                                  * a_rate,
                                                  5
                                                 ),
                                           ROUND (  a_cogs_dl_local
                                                  * rec2.rate
                                                  * a_rate,
                                                  5
                                                 ),
                                           ROUND (  a_cogs_dl_twd
                                                  * rec2.rate
                                                  * a_rate,
                                                  5
                                                 ),
                                           ROUND (  a_cogs_dl_usd
                                                  * rec2.rate
                                                  * a_rate,
                                                  5
                                                 ),
                                           ROUND (  a_cogs_oh_local
                                                  * rec2.rate
                                                  * a_rate,
                                                  5
                                                 ),
                                           ROUND (  a_cogs_oh_twd
                                                  * rec2.rate
                                                  * a_rate,
                                                  5
                                                 ),
                                           ROUND (  a_cogs_oh_usd
                                                  * rec2.rate
                                                  * a_rate,
                                                  5
                                                 ),
                                           a_revenue_twd, a_cogs_twd, rec2.rate,
                                           inglaccount,
                                           rec2.end_customer_id,
                                           'WH<>0/T_AMT=0', a_rate,
                                           SYSDATE
                                          );

                              COMMIT;
                           END LOOP;
                        END IF;
                     END IF;
                  ELSE
                     a_counter := 0;

                     FOR rec2 IN (SELECT end_customer_id, rate
                                    FROM pnl3_map001_customer_rate
                                   WHERE r_kind = 'PL01'
                                     --隨便抓一筆來用,反正匯率都一樣
                                     AND area1 = '4'
                                     AND area2 = '1'
                                     AND area3 = '1'
                                     --AND COMPANY_CODE = REC1.COMPANY_CODE
                                     AND profit_center = inprofit_center
                                     AND period = inperiod)
                     LOOP
                        a_counter := 1;

                        INSERT INTO pnl3_trx003_unutilization
                                    (company_code, period, profit_center,
                                     part_no, total_hrs,
                                     pn_hrs,
                                     net_revenue,
                                     net_revenue_twd,
                                     net_revenue_usd,
                                     net_cogs,
                                     net_cogs_twd,
                                     net_cogs_usd,
                                     cogs_mb,
                                     cogs_mb_twd,
                                     cogs_mb_usd,
                                     cogs_lb,
                                     cogs_lb_twd,
                                     cogs_lb_usd,
                                     cogs_ob,
                                     cogs_ob_twd,
                                     cogs_ob_usd,
                                     o_net_revenue, o_net_cogs, rate,
                                     cost_element, end_customer_id,
                                     sql_method, customer_rate, create_date
                                    )
                             VALUES (incompany, inperiod, inprofit_center,
                                     rec1.part_no, intotal_hrs,
                                     rec1.total_hrs,
                                     ROUND (a_revenue_local * rec2.rate
                                            * a_rate,
                                            5
                                           ),
                                     ROUND (a_revenue_twd * rec2.rate * a_rate,
                                            5
                                           ),
                                     ROUND (a_revenue_usd * rec2.rate * a_rate,
                                            5
                                           ),
                                     ROUND (a_cogs_local * rec2.rate * a_rate,
                                            5
                                           ),
                                     ROUND (a_cogs_twd * rec2.rate * a_rate,
                                            5),
                                     ROUND (a_cogs_usd * rec2.rate * a_rate,
                                            5),
                                     ROUND (a_cogs_dm_local * rec2.rate
                                            * a_rate,
                                            5
                                           ),
                                     ROUND (a_cogs_dm_twd * rec2.rate * a_rate,
                                            5
                                           ),
                                     ROUND (a_cogs_dm_usd * rec2.rate * a_rate,
                                            5
                                           ),
                                     ROUND (a_cogs_dl_local * rec2.rate
                                            * a_rate,
                                            5
                                           ),
                                     ROUND (a_cogs_dl_twd * rec2.rate * a_rate,
                                            5
                                           ),
                                     ROUND (a_cogs_dl_usd * rec2.rate * a_rate,
                                            5
                                           ),
                                     ROUND (a_cogs_oh_local * rec2.rate
                                            * a_rate,
                                            5
                                           ),
                                     ROUND (a_cogs_oh_twd * rec2.rate * a_rate,
                                            5
                                           ),
                                     ROUND (a_cogs_oh_usd * rec2.rate * a_rate,
                                            5
                                           ),
                                     a_revenue_twd, a_cogs_twd, rec2.rate,
                                     inglaccount, rec2.end_customer_id,
                                     'WH<>0/T_AMT=0', a_rate, SYSDATE
                                    );

                        COMMIT;
                     END LOOP;

                     IF a_counter = 0
                     THEN
                        FOR rec2 IN (SELECT end_customer_id, rate
                                       FROM pnl3_map001_global_cust_rate
                                      WHERE r_kind = 'PL01'
                                        --隨便抓一筆來用,反正匯率都一樣
                                        AND area1 = '4'
                                        AND area2 = '1'
                                        AND area3 = '1'
                                        --AND COMPANY_CODE = REC1.COMPANY_CODE
                                        --AND PROFIT_CENTER = REC1.PROFIT_CENTER
                                        AND period = inperiod)
                        LOOP
                           INSERT INTO pnl3_trx003_unutilization
                                       (company_code, period,
                                        profit_center, part_no,
                                        total_hrs, pn_hrs,
                                        net_revenue,
                                        net_revenue_twd,
                                        net_revenue_usd,
                                        net_cogs,
                                        net_cogs_twd,
                                        net_cogs_usd,
                                        cogs_mb,
                                        cogs_mb_twd,
                                        cogs_mb_usd,
                                        cogs_lb,
                                        cogs_lb_twd,
                                        cogs_lb_usd,
                                        cogs_ob,
                                        cogs_ob_twd,
                                        cogs_ob_usd,
                                        o_net_revenue, o_net_cogs, rate,
                                        cost_element, end_customer_id,
                                        sql_method, customer_rate,
                                        create_date
                                       )
                                VALUES (incompany, inperiod,
                                        inprofit_center, rec1.part_no,
                                        intotal_hrs, rec1.total_hrs,
                                        ROUND (  a_revenue_local
                                               * rec2.rate
                                               * a_rate,
                                               5
                                              ),
                                        ROUND (  a_revenue_twd
                                               * rec2.rate
                                               * a_rate,
                                               5
                                              ),
                                        ROUND (  a_revenue_usd
                                               * rec2.rate
                                               * a_rate,
                                               5
                                              ),
                                        ROUND (a_cogs_local * rec2.rate
                                               * a_rate,
                                               5
                                              ),
                                        ROUND (a_cogs_twd * rec2.rate * a_rate,
                                               5
                                              ),
                                        ROUND (a_cogs_usd * rec2.rate * a_rate,
                                               5
                                              ),
                                        ROUND (  a_cogs_dm_local
                                               * rec2.rate
                                               * a_rate,
                                               5
                                              ),
                                        ROUND (  a_cogs_dm_twd
                                               * rec2.rate
                                               * a_rate,
                                               5
                                              ),
                                        ROUND (a_cogs_dm_usd * rec2.rate, 5),
                                        ROUND (  a_cogs_dl_local
                                               * rec2.rate
                                               * a_rate,
                                               5
                                              ),
                                        ROUND (  a_cogs_dl_twd
                                               * rec2.rate
                                               * a_rate,
                                               5
                                              ),
                                        ROUND (  a_cogs_dl_usd
                                               * rec2.rate
                                               * a_rate,
                                               5
                                              ),
                                        ROUND (  a_cogs_oh_local
                                               * rec2.rate
                                               * a_rate,
                                               5
                                              ),
                                        ROUND (  a_cogs_oh_twd
                                               * rec2.rate
                                               * a_rate,
                                               5
                                              ),
                                        ROUND (  a_cogs_oh_usd
                                               * rec2.rate
                                               * a_rate,
                                               5
                                              ),
                                        a_revenue_twd, a_cogs_twd, rec2.rate,
                                        inglaccount, rec2.end_customer_id,
                                        'WH<>0/T_AMT=0', a_rate,
                                        SYSDATE
                                       );

                           COMMIT;
                        END LOOP;
                     END IF;
                  END IF;
               ELSE              --依照營收來分,32要用SITE,其他用PROFIT CENTER
                  a_miss_rate := 0;

                  IF inprofit_center = '0000000032'
                  THEN
                     a_counter := 0;

                     FOR rec2 IN (SELECT end_customer_id, rate
                                    FROM pnl3_map001_site_rate
                                   WHERE r_kind = 'PL01'
                                     --隨便抓一筆來用,反正匯率都一樣
                                     AND area1 = '4'
                                     AND area2 = '1'
                                     AND area3 = '1'
                                     AND company_code = incompany
                                     AND profit_center = inprofit_center
                                     AND period = inperiod)
                     LOOP
                        a_counter := 1;

                        INSERT INTO pnl3_trx003_unutilization
                                    (company_code, period, profit_center,
                                     part_no, total_hrs,
                                     pn_hrs,
                                     net_revenue,
                                     net_revenue_twd,
                                     net_revenue_usd,
                                     net_cogs,
                                     net_cogs_twd,
                                     net_cogs_usd,
                                     cogs_mb,
                                     cogs_mb_twd,
                                     cogs_mb_usd,
                                     cogs_lb,
                                     cogs_lb_twd,
                                     cogs_lb_usd,
                                     cogs_ob,
                                     cogs_ob_twd,
                                     cogs_ob_usd,
                                     o_net_revenue, o_net_cogs, rate,
                                     cost_element, end_customer_id,
                                     sql_method, customer_rate, create_date
                                    )
                             VALUES (incompany, inperiod, inprofit_center,
                                     rec1.part_no, intotal_hrs,
                                     rec1.total_hrs,
                                     ROUND (a_revenue_local * rec2.rate
                                            * a_rate,
                                            5
                                           ),
                                     ROUND (a_revenue_twd * rec2.rate * a_rate,
                                            5
                                           ),
                                     ROUND (a_revenue_usd * rec2.rate * a_rate,
                                            5
                                           ),
                                     ROUND (a_cogs_local * rec2.rate * a_rate,
                                            5
                                           ),
                                     ROUND (a_cogs_twd * rec2.rate * a_rate,
                                            5),
                                     ROUND (a_cogs_usd * rec2.rate * a_rate,
                                            5),
                                     ROUND (a_cogs_dm_local * rec2.rate
                                            * a_rate,
                                            5
                                           ),
                                     ROUND (a_cogs_dm_twd * rec2.rate * a_rate,
                                            5
                                           ),
                                     ROUND (a_cogs_dm_usd * rec2.rate * a_rate,
                                            5
                                           ),
                                     ROUND (a_cogs_dl_local * rec2.rate
                                            * a_rate,
                                            5
                                           ),
                                     ROUND (a_cogs_dl_twd * rec2.rate * a_rate,
                                            5
                                           ),
                                     ROUND (a_cogs_dl_usd * rec2.rate * a_rate,
                                            5
                                           ),
                                     ROUND (a_cogs_oh_local * rec2.rate
                                            * a_rate,
                                            5
                                           ),
                                     ROUND (a_cogs_oh_twd * rec2.rate * a_rate,
                                            5
                                           ),
                                     ROUND (a_cogs_oh_usd * rec2.rate * a_rate,
                                            5
                                           ),
                                     a_revenue_twd, a_cogs_twd, rec2.rate,
                                     inglaccount, rec2.end_customer_id,
                                     'WH<>0/T_AMT<>0', a_rate, SYSDATE
                                    );

                        COMMIT;
                     END LOOP;

                     IF a_counter = 0
                     THEN
                        FOR rec2 IN (SELECT end_customer_id, rate
                                       FROM pnl3_map001_customer_rate
                                      WHERE r_kind = 'PL01'
                                        --隨便抓一筆來用,反正匯率都一樣
                                        AND area1 = '4'
                                        AND area2 = '1'
                                        AND area3 = '1'
                                        --AND COMPANY_CODE = incompany
                                        AND profit_center = inprofit_center
                                        AND period = inperiod)
                        LOOP
                           a_counter := 1;

                           INSERT INTO pnl3_trx003_unutilization
                                       (company_code, period,
                                        profit_center, part_no,
                                        total_hrs, pn_hrs,
                                        net_revenue,
                                        net_revenue_twd,
                                        net_revenue_usd,
                                        net_cogs,
                                        net_cogs_twd,
                                        net_cogs_usd,
                                        cogs_mb,
                                        cogs_mb_twd,
                                        cogs_mb_usd,
                                        cogs_lb,
                                        cogs_lb_twd,
                                        cogs_lb_usd,
                                        cogs_ob,
                                        cogs_ob_twd,
                                        cogs_ob_usd,
                                        o_net_revenue, o_net_cogs, rate,
                                        cost_element, end_customer_id,
                                        sql_method, customer_rate,
                                        create_date
                                       )
                                VALUES (incompany, inperiod,
                                        inprofit_center, rec1.part_no,
                                        intotal_hrs, rec1.total_hrs,
                                        ROUND (  a_revenue_local
                                               * rec2.rate
                                               * a_rate,
                                               5
                                              ),
                                        ROUND (  a_revenue_twd
                                               * rec2.rate
                                               * a_rate,
                                               5
                                              ),
                                        ROUND (  a_revenue_usd
                                               * rec2.rate
                                               * a_rate,
                                               5
                                              ),
                                        ROUND (a_cogs_local * rec2.rate
                                               * a_rate,
                                               5
                                              ),
                                        ROUND (a_cogs_twd * rec2.rate * a_rate,
                                               5
                                              ),
                                        ROUND (a_cogs_usd * rec2.rate * a_rate,
                                               5
                                              ),
                                        ROUND (  a_cogs_dm_local
                                               * rec2.rate
                                               * a_rate,
                                               5
                                              ),
                                        ROUND (  a_cogs_dm_twd
                                               * rec2.rate
                                               * a_rate,
                                               5
                                              ),
                                        ROUND (  a_cogs_dm_usd
                                               * rec2.rate
                                               * a_rate,
                                               5
                                              ),
                                        ROUND (  a_cogs_dl_local
                                               * rec2.rate
                                               * a_rate,
                                               5
                                              ),
                                        ROUND (  a_cogs_dl_twd
                                               * rec2.rate
                                               * a_rate,
                                               5
                                              ),
                                        ROUND (  a_cogs_dl_usd
                                               * rec2.rate
                                               * a_rate,
                                               5
                                              ),
                                        ROUND (  a_cogs_oh_local
                                               * rec2.rate
                                               * a_rate,
                                               5
                                              ),
                                        ROUND (  a_cogs_oh_twd
                                               * rec2.rate
                                               * a_rate,
                                               5
                                              ),
                                        ROUND (  a_cogs_oh_usd
                                               * rec2.rate
                                               * a_rate,
                                               5
                                              ),
                                        a_revenue_twd, a_cogs_twd, rec2.rate,
                                        inglaccount, rec2.end_customer_id,
                                        'WH<>0/T_AMT<>0', a_rate,
                                        SYSDATE
                                       );

                           COMMIT;
                        END LOOP;
                     END IF;
                  ELSE
                     FOR rec2 IN (SELECT end_customer_id, rate
                                    FROM pnl3_map001_customer_rate
                                   WHERE r_kind = 'PL01'
                                     --隨便抓一筆來用,反正匯率都一樣
                                     AND area1 = '4'
                                     AND area2 = '1'
                                     AND area3 = '1'
                                     --AND COMPANY_CODE = incompany
                                     AND profit_center = inprofit_center
                                     AND period = inperiod)
                     LOOP
                        a_counter := 1;

                        INSERT INTO pnl3_trx003_unutilization
                                    (company_code, period, profit_center,
                                     part_no, total_hrs,
                                     pn_hrs,
                                     net_revenue,
                                     net_revenue_twd,
                                     net_revenue_usd,
                                     net_cogs,
                                     net_cogs_twd,
                                     net_cogs_usd,
                                     cogs_mb,
                                     cogs_mb_twd,
                                     cogs_mb_usd,
                                     cogs_lb,
                                     cogs_lb_twd,
                                     cogs_lb_usd,
                                     cogs_ob,
                                     cogs_ob_twd,
                                     cogs_ob_usd,
                                     o_net_revenue, o_net_cogs, rate,
                                     cost_element, end_customer_id,
                                     sql_method, customer_rate, create_date
                                    )
                             VALUES (incompany, inperiod, inprofit_center,
                                     rec1.part_no, intotal_hrs,
                                     rec1.total_hrs,
                                     ROUND (a_revenue_local * rec2.rate
                                            * a_rate,
                                            5
                                           ),
                                     ROUND (a_revenue_twd * rec2.rate * a_rate,
                                            5
                                           ),
                                     ROUND (a_revenue_usd * rec2.rate * a_rate,
                                            5
                                           ),
                                     ROUND (a_cogs_local * rec2.rate * a_rate,
                                            5
                                           ),
                                     ROUND (a_cogs_twd * rec2.rate * a_rate,
                                            5),
                                     ROUND (a_cogs_usd * rec2.rate * a_rate,
                                            5),
                                     ROUND (a_cogs_dm_local * rec2.rate
                                            * a_rate,
                                            5
                                           ),
                                     ROUND (a_cogs_dm_twd * rec2.rate * a_rate,
                                            5
                                           ),
                                     ROUND (a_cogs_dm_usd * rec2.rate * a_rate,
                                            5
                                           ),
                                     ROUND (a_cogs_dl_local * rec2.rate
                                            * a_rate,
                                            5
                                           ),
                                     ROUND (a_cogs_dl_twd * rec2.rate * a_rate,
                                            5
                                           ),
                                     ROUND (a_cogs_dl_usd * rec2.rate * a_rate,
                                            5
                                           ),
                                     ROUND (a_cogs_oh_local * rec2.rate
                                            * a_rate,
                                            5
                                           ),
                                     ROUND (a_cogs_oh_twd * rec2.rate * a_rate,
                                            5
                                           ),
                                     ROUND (a_cogs_oh_usd * rec2.rate * a_rate,
                                            5
                                           ),
                                     a_revenue_twd, a_cogs_twd, rec2.rate,
                                     inglaccount, rec2.end_customer_id,
                                     'WH<>0/T_AMT<>0', a_rate, SYSDATE
                                    );

                        COMMIT;
                     END LOOP;
                  END IF;
               END IF;
            END IF;
         END IF;
      END IF;
   END LOOP;
END pnl3_pls003_unut_trx_s01;
/

