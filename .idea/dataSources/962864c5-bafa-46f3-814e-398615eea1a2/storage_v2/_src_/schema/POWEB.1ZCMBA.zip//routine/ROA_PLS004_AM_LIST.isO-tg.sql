create PROCEDURE       ROA_PLS004_AM_LIST (
/* ********************************************************************
  PROG-ID      : ROA_PLS004_AM_LIST
  PROG-ACTION  : 
  Author       : Asan Chang
  Date         : 2017/04/13
  OA Number    : SAI070818
********************************************************************* 
* 2017/04/21 SAI070818 Asan Chang add TWD/CNY/USD
* 2017/04/24 SAI070818 Asan Chang add 分類(S_SEQ) 10/20/30/40 定義 -> ROA_MAP001_DESC
* 2017/04/29 SAI070818 Asan Chang add source
* 2017/05/10 SAI071713 Asan Chang 四大類分類邏輯變更，改為讀table:ROA_SAP005_CLASS_RULE
* 2017/06/15 SAI071713 Asan Chang 四大類分類邏輯變更
* (1)先去四大類分類table(ROA_SAP005_CLASS_RULE)，會得到對應的S_SEQ = 10/20/30/40
* (2)若再第一階段沒找到分類,或是歸類為30(others)，再去組織裡面找是否為PD
*    若是PD，則S_SEQ = 20 (PD)
* (3)若S_SEQ =仍為空(沒找到分類)，則設為30(others)
********************************************************************* 
* 2018/11/06 OA Asan Chang get ROA_SAP005_CLASS_RULE by type = ROA
********************************************************************* 
*/
   incompany    IN   VARCHAR2,
   f_yyyymmdd   IN   VARCHAR2,
   t_yyyymmdd   IN   VARCHAR2
)
AUTHID DEFINER
IS
   CURSOR ROA_SAP004_AM_LIST_T
   IS
      SELECT COMPANY_CODE, PERIOD, ASSET_CLASS, ASSET_NO , ASSET_SUB_NO,    
      COST_CENTER, EV_GRP5 ,EV_GRP5_TEXT, CAP_DATE , ASSET_NAME, FYE_ACQ_VAL,     
      CUM_ACQ_VAL, ASSET_VAL_TRANS, VAL_ADJTRANS_FYE, CUM_ORD_DEPREC, 
      ORD_DEP_PSTD, PSTD_UNPL_DEP, CUM_UNPLND_DEP, CUR_NET_BOOK_VAL, 
      INVENTORY_NOTE, SOURCE_FROM               
      FROM ROA_SAP004_AM_LIST_T
      where COMPANY_CODE = incompany;


   itracepoint   INTEGER;
   t_CURRENCY_LOCAL    pld_kpi_non_bom_ir.IR_CURRENCY%TYPE;
   p_CURRENCY_LOCAL    pld_kpi_non_bom_ir.IR_CURRENCY%TYPE;
     a_EX_RATE_CNY       EMPS_SAP001_DAILY_DN_ZF430.EX_RATE_CNY%TYPE;
     a_EX_RATE_USD       EMPS_SAP001_DAILY_DN_ZF430.EX_RATE_USD%TYPE;
     a_EX_RATE_TWD       EMPS_SAP001_DAILY_DN_ZF430.EX_RATE_TWD%TYPE;  
     t_S_SEQ             ROA_SAP004_AM_LIST.S_SEQ%TYPE; 
     t_PD                VARCHAR(10);
     t_TYPE              VARCHAR(4);
BEGIN
   

     --(1)清除舊資料
     DELETE FROM ROA_SAP004_AM_LIST
     where PERIOD IN  (SELECT PERIOD FROM ROA_SAP004_AM_LIST_T )
     AND   COMPANY_CODE = incompany;
     COMMIT;  


     --計算匯率
     --R:用路透社匯率 table:KPI_MAP013_EXCHANGE_RATE_END
     select COMPANY_CURR INTO t_CURRENCY_LOCAL FROM PNL_MAP006_SITE_MAPPING WHERE COMPANY_CODE = incompany;
     a_EX_RATE_USD := Get_Exchange_Rate(SUBSTRB(f_yyyymmdd,1,4),SUBSTRB(f_yyyymmdd,5,2),t_CURRENCY_LOCAL,'USD','R') ;
     a_EX_RATE_TWD := Get_Exchange_Rate(SUBSTRB(f_yyyymmdd,1,4),SUBSTRB(f_yyyymmdd,5,2),t_CURRENCY_LOCAL,'TWD','R') ;
     a_EX_RATE_CNY := Get_Exchange_Rate(SUBSTRB(f_yyyymmdd,1,4),SUBSTRB(f_yyyymmdd,5,2),t_CURRENCY_LOCAL,'CNY','R') ;
     t_TYPE := 'ROA';

   FOR REC1 IN ROA_SAP004_AM_LIST_T LOOP
     t_S_SEQ := '';  
     BEGIN
       select S_SEQ INTO t_S_SEQ FROM ROA_SAP005_CLASS_RULE WHERE ASSET_CLASS = REC1.ASSET_CLASS and rownum <=1 and type = t_TYPE;                     
     EXCEPTION
       WHEN NO_DATA_FOUND THEN
         t_S_SEQ := '';  
     END;      
       
     t_PD := '';   
     if ( LENGTH( t_S_SEQ ) = 0  OR t_S_SEQ IS null ) OR t_S_SEQ = '30' Then     
       BEGIN  
         select PD INTO t_PD FROM KPI_MAP018_ORGANIZATION WHERE COMPANY_CODE = REC1.COMPANY_CODE
         AND PERIOD = REC1.PERIOD AND SAP_COST_CENTER = REC1.COST_CENTER and rownum <=1; 
         IF t_PD IS NOT NULL then
           t_S_SEQ := '20';   --FA-PD          
         end if ;  
       EXCEPTION
         WHEN NO_DATA_FOUND THEN
           t_S_SEQ := '30';              
       END;    
     end if;       
    
     if LENGTH( t_S_SEQ ) = 0  OR t_S_SEQ IS null Then
       t_S_SEQ := '30';   --FA-Others
     end if;
     
     
   --(3)開始處理資料
       INSERT INTO ROA_SAP004_AM_LIST (
          COMPANY_CODE,        PERIOD,                 ASSET_CLASS,          ASSET_NO , 
          ASSET_SUB_NO,        COST_CENTER,            EV_GRP5 ,             EV_GRP5_TEXT, 
          CAP_DATE ,           ASSET_NAME,             FYE_ACQ_VAL,          CUM_ACQ_VAL, 
          ASSET_VAL_TRANS,     VAL_ADJTRANS_FYE,       CUM_ORD_DEPREC,       ORD_DEP_PSTD, 
          PSTD_UNPL_DEP,       CUM_UNPLND_DEP,         CUR_NET_BOOK_VAL,     INVENTORY_NOTE,
          CURRENCY,            
          EX_RATE_TWD,
          EX_RATE_USD,
          EX_RATE_CNY,
          S_SEQ, SOURCE_FROM
          ) VALUES (
                 
          REC1.COMPANY_CODE,   REC1.PERIOD,            REC1.ASSET_CLASS,     REC1.ASSET_NO , 
          REC1.ASSET_SUB_NO,   REC1.COST_CENTER,       REC1.EV_GRP5 ,        REC1.EV_GRP5_TEXT, 
          REC1.CAP_DATE ,      REC1.ASSET_NAME,        REC1.FYE_ACQ_VAL,     REC1.CUM_ACQ_VAL, 
          REC1.ASSET_VAL_TRANS,REC1.VAL_ADJTRANS_FYE,  REC1.CUM_ORD_DEPREC,  REC1.ORD_DEP_PSTD, 
          REC1.PSTD_UNPL_DEP,  REC1.CUM_UNPLND_DEP,    REC1.CUR_NET_BOOK_VAL,REC1.INVENTORY_NOTE,
          t_CURRENCY_LOCAL,
          a_EX_RATE_TWD,     
          a_EX_RATE_USD,   
          a_EX_RATE_CNY,
          t_S_SEQ ,  'SAP'                
           );   
       COMMIT;

   END LOOP;

   --(3) 刪除資料
   DELETE FROM ROA_SAP004_AM_LIST_T
   where COMPANY_CODE = incompany;
   COMMIT;
   
   
END ROA_PLS004_AM_LIST;
/

