create PROCEDURE Z_PLSQL_ZD468C_TEST
AUTHID DEFINER
is
	iTracePoint         varchar2(3);
	cErrorText          varchar2(500);
	nDIFF_DAY           PLD_KPI_AUDIT_ZD468_PR_CLOSE.DIFF_DAY%TYPE;

BEGIN

	iTracePoint := '630';
	for rec3 in (
		select distinct a.COMPANY_CODE, a.DOC_NO, a.DOC_ITEM, a.DOC_CREATE, a.CLOSED_DATE, a.DIFF_DAY,
			(to_date(a.CLOSED_DATE,'yyyymmdd') - to_date(a.DOC_CREATE,'yyyymmdd')) as DIFF_DAY2
		from PLD_KPI_AUDIT_ZD468_PR_CLOSE a
	) loop
		-- 計算處理天數 (找出星期六日有幾天並扣除之)
		nDIFF_DAY := 0;
		select count(*) into nDIFF_DAY from DIMENSION_DATE
		where DATE_KEY >= rec3.DOC_CREATE and DATE_KEY <= rec3.CLOSED_DATE and DAY_OF_WK in ('6','0');
		if nDIFF_DAY >= rec3.DIFF_DAY2 then
			nDIFF_DAY := 0;
		else
			nDIFF_DAY := rec3.DIFF_DAY2 - nDIFF_DAY;
		end if;
		--
		if nDIFF_DAY <> rec3.DIFF_DAY then
			iTracePoint := '633';
			update PLD_KPI_AUDIT_ZD468_PR_CLOSE set DIFF_DAY = nDIFF_DAY
			where COMPANY_CODE = rec3.COMPANY_CODE and DOC_NO = rec3.DOC_NO and DOC_ITEM = rec3.DOC_ITEM;
			--
			iTracePoint := '639';
			commit;
		end if;
	end loop;


	-- end
	iTracePoint := '999';
EXCEPTION
	WHEN OTHERS THEN
		cErrorText := SQLERRM();
		MAIL_FILE_BIDBDBADMIN(in_to_name=>'minhorng@ms.usi.com.tw',subject   => '[PLD KPI]PL/SQL Z_PLSQL_ZD468C_TEST ERROR', message => '[Z_PLSQL_ZD468C_TEST], The tracepoint is  ' || iTracePoint || ' and ErrorText=' || cErrorText) ;
END Z_PLSQL_ZD468C_TEST;
/

