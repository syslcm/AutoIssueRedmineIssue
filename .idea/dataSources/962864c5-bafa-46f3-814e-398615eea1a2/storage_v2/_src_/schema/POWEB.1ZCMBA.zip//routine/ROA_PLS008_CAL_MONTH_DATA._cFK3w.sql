create PROCEDURE       "ROA_PLS008_CAL_MONTH_DATA" (
  in_YYYYMM1  in VARCHAR2
  ,in_Kind1 in VARCHAR2
)
AUTHID DEFINER
/* ****************************************************************************************
  PROG-ID      : ROA_PLS008_CAL_MONTH_DATA
  PROG-ACTION  :   
  Author       : Asan Chang
  Date         : 2017/06/06
  OA No.       : SAI065848
 ========================================================================================== 

 *************************************************************************************/
is
   iReccnt              integer;
   In_YYYY              DIMENSION_DATE.YYYY%TYPE;
   In_MM                DIMENSION_DATE.MM%TYPE; 
   In_PERIOD            DIMENSION_DATE.YYYYMM%TYPE;
   In_KIND              varchar2(2); 
   USI_KIND             varchar2(2);
   PC_KIND              varchar2(2);
   This_ACC             varchar2(6);
   L_CNT                NUMBER(6);
   iTracePoint          integer ; 
   In_MM2               integer ;
   inCompany            ROA_PST004_FIXED_ASSETS.COMPANY_CODE%TYPE;
   STR01                varchar2(30);
   STR02                varchar2(30);
   STR03                varchar2(10);
   STR04                varchar2(2);
   STR06                varchar2(20); 
   STR07                varchar2(20); 
  
BEGIN
--
  In_YYYY := SUBSTR( in_YYYYMM1, 1, 4);
  In_MM := SUBSTR( in_YYYYMM1, 5, 2); 
  In_MM2 := In_MM;
  In_PERIOD := In_YYYY || In_MM;
  In_KIND := in_Kind1;

  delete ROA_PST001_MONTH_DATA WHERE PERIOD = In_PERIOD AND D_KIND = In_KIND ;
  COMMIT ;   
  

                   
  /*****************************************************************************************
      (1)Kind = 01-PC
  ************************************************************************************ */
  if In_KIND IN ('01') THEN 
      iTracePoint := 100 ;  
      
  --(1-01) --------      
      STR01 :=  'A00800';
      for REC1 IN (
          SELECT STR01 D_ACC, pc, sum( upl_amt ) AMOUNT FROM ROA_UPL004_AR_AP_INV_DATA WHERE
          PERIOD = In_PERIOD AND TYPE IN ( 'AR' )
          GROUP BY PC ORDER BY PC    
      )
      LOOP
        INSERT INTO ROA_PST001_MONTH_DATA
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,REC1.PC ,REC1.D_ACC, REC1.AMOUNT);                 
      END LOOP;    
      
--(1-02) --------  
      STR01 :=  'A00900';
      for REC1 IN (
          SELECT STR01 D_ACC, pc, sum( upl_amt ) AMOUNT FROM ROA_UPL004_AR_AP_INV_DATA WHERE
          PERIOD = In_PERIOD AND TYPE IN  ( 'INV', 'ADJ_INV' ) 
          GROUP BY PC ORDER BY PC    
      )
      LOOP
        INSERT INTO ROA_PST001_MONTH_DATA
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,REC1.PC ,REC1.D_ACC, REC1.AMOUNT);                 
      END LOOP; 
           
  --(1-03) --------  
      STR01 :=  'A01500';
      for REC1 IN (
          SELECT STR01 D_ACC, pc, sum( upl_amt ) AMOUNT FROM ROA_UPL004_AR_AP_INV_DATA WHERE
          PERIOD = In_PERIOD AND TYPE IN  ( 'AP' ) 
          GROUP BY PC ORDER BY PC    
      )
      LOOP
        INSERT INTO ROA_PST001_MONTH_DATA
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,REC1.PC ,REC1.D_ACC, REC1.AMOUNT);                 
      END LOOP;       

  --(1-04) --------  
      STR01 :=  'A01000';
      for REC1 IN (
          SELECT STR01 D_ACC, pc, sum( AFTER_AMT_TWD ) AMOUNT FROM ROA_PST004_FIXED_ASSETS WHERE
          PERIOD = In_PERIOD AND S_SEQ IN ( '10' ) AND TYPE ='2'
          GROUP BY PC ORDER BY PC    
      )
      LOOP
        INSERT INTO ROA_PST001_MONTH_DATA
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,REC1.PC ,REC1.D_ACC, REC1.AMOUNT);                 
      END LOOP; 

  --(1-05) --------  
      STR01 :=  'A01100';
      for REC1 IN (
          SELECT STR01 D_ACC, pc, sum( AFTER_AMT_TWD ) AMOUNT FROM ROA_PST004_FIXED_ASSETS WHERE
          PERIOD = In_PERIOD AND S_SEQ IN ( '20' ) AND TYPE ='2'
          GROUP BY PC ORDER BY PC    
      )
      LOOP
        INSERT INTO ROA_PST001_MONTH_DATA
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,REC1.PC ,REC1.D_ACC, REC1.AMOUNT);                 
      END LOOP;    

  --(1-06) --------  
      STR01 :=  'A03000';
      for REC1 IN (
          SELECT STR01 D_ACC, pc, sum( AFTER_AMT_TWD ) AMOUNT FROM ROA_PST004_FIXED_ASSETS WHERE
          PERIOD = In_PERIOD AND S_SEQ IN ( '20' ) AND TYPE ='2'
          GROUP BY PC ORDER BY PC    
      )
      LOOP
        INSERT INTO ROA_PST001_MONTH_DATA
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,REC1.PC ,REC1.D_ACC, REC1.AMOUNT);                 
      END LOOP;   

  --(1-07) --------  
      STR01 :=  'A01200';
      for REC1 IN (
          SELECT STR01 D_ACC, pc, sum( AFTER_AMT_TWD ) AMOUNT FROM ROA_PST004_FIXED_ASSETS WHERE
          PERIOD = In_PERIOD AND S_SEQ IN ( '30','40' ) AND TYPE ='2'
          GROUP BY PC ORDER BY PC    
      )
      LOOP
        INSERT INTO ROA_PST001_MONTH_DATA
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,REC1.PC ,REC1.D_ACC, REC1.AMOUNT);                 
      END LOOP;  
           
  --(1-08) --------  
      STR01 :=  'A03200';
      for REC1 IN (
          SELECT STR01 D_ACC, pc, sum( AFTER_AMT_TWD ) AMOUNT FROM ROA_PST004_FIXED_ASSETS WHERE
          PERIOD = In_PERIOD AND S_SEQ IN ( '20','30','40' ) AND TYPE ='2'
          GROUP BY PC ORDER BY PC    
      )
      LOOP
        INSERT INTO ROA_PST001_MONTH_DATA
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,REC1.PC ,REC1.D_ACC, REC1.AMOUNT);                 
      END LOOP;      

  --(1-09) --------  
      STR01 :=  'A02900';
      for REC1 IN (
          SELECT STR01 D_ACC, pc, sum( AFTER_AMT_TWD ) AMOUNT FROM ROA_PST004_FIXED_ASSETS WHERE
          PERIOD = In_PERIOD AND S_SEQ IN ( '10','20','30','40' ) AND TYPE ='2'
          GROUP BY PC ORDER BY PC    
      )
      LOOP
        INSERT INTO ROA_PST001_MONTH_DATA
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,REC1.PC ,REC1.D_ACC, REC1.AMOUNT);                 
      END LOOP;
      
  --(1-10) --------  
      STR01 :=  'A02100';
      STR02 :=  'Net Mfg Revenues';
      for REC1 IN (
          SELECT STR01 D_ACC, LPAD(pc, 10, '0') PC, sum( amount ) AMOUNT FROM PNL_MSA001_EM_DATA WHERE
          YYYY = In_YYYY AND MONTH = In_MM AND acct_id<> ' ' AND ACCT_NAME = STR02
          GROUP BY PC ORDER BY PC    
      )
      LOOP
        INSERT INTO ROA_PST001_MONTH_DATA
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,REC1.PC ,REC1.D_ACC, (REC1.AMOUNT * 1000 ));                 
      END LOOP; 
      
  --(1-11) --------  
      STR01 :=  'A02200';
      STR02 :=  '07.050';
      for REC1 IN (
          SELECT STR01 D_ACC, LPAD(pc, 10, '0') PC, sum( amount ) AMOUNT FROM PNL_MSA001_EM_DATA WHERE
          YYYY = In_YYYY AND MONTH = In_MM AND acct_id <> ' ' AND acct_id <= STR02
          GROUP BY PC ORDER BY PC    
      )
      LOOP
        INSERT INTO ROA_PST001_MONTH_DATA
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,REC1.PC ,REC1.D_ACC, (REC1.AMOUNT * 1000 ));                 
      END LOOP;       

  --(1-12) --------  
      STR01 :=  'A04000';
      for REC1 IN (
          SELECT STR01 D_ACC, pc, sum( AFTER_AMT_TWD ) AMOUNT FROM ROA_PST004_FIXED_ASSETS WHERE
          PERIOD = In_PERIOD AND S_SEQ IN ( '10' ) AND TYPE ='1'
          GROUP BY PC ORDER BY PC    
      )
      LOOP
        INSERT INTO ROA_PST001_MONTH_DATA
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,REC1.PC ,REC1.D_ACC, REC1.AMOUNT);                 
      END LOOP;

  --(1-13) --------  
      STR01 :=  'A03600';
      for REC1 IN (
          SELECT STR01 D_ACC, pc, sum( AFTER_AMT_TWD ) AMOUNT FROM ROA_PST004_FIXED_ASSETS WHERE
          PERIOD = In_PERIOD AND S_SEQ IN ( '20' ) AND TYPE ='1'
          GROUP BY PC ORDER BY PC    
      )
      LOOP
        INSERT INTO ROA_PST001_MONTH_DATA
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,REC1.PC ,REC1.D_ACC, REC1.AMOUNT);                 
      END LOOP;

  --(1-13) --------  
      STR01 :=  'A04100';
      for REC1 IN (
          SELECT STR01 D_ACC, pc, sum( AFTER_AMT_TWD ) AMOUNT FROM ROA_PST004_FIXED_ASSETS WHERE
          PERIOD = In_PERIOD AND S_SEQ IN ( '20' ) AND TYPE ='1'
          GROUP BY PC ORDER BY PC    
      )
      LOOP
        INSERT INTO ROA_PST001_MONTH_DATA
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,REC1.PC ,REC1.D_ACC, REC1.AMOUNT);                 
      END LOOP;
                
  --(1-14) --------  
      STR01 :=  'A04200';
      for REC1 IN (
          SELECT STR01 D_ACC, pc, sum( AFTER_AMT_TWD ) AMOUNT FROM ROA_PST004_FIXED_ASSETS WHERE
          PERIOD = In_PERIOD AND S_SEQ IN ( '30','40' ) AND TYPE ='1'
          GROUP BY PC ORDER BY PC    
      )
      LOOP
        INSERT INTO ROA_PST001_MONTH_DATA
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,REC1.PC ,REC1.D_ACC, REC1.AMOUNT);                 
      END LOOP;             

  --(1-15) --------  
      STR01 :=  'A03800';
      for REC1 IN (
          SELECT STR01 D_ACC, pc, sum( AFTER_AMT_TWD ) AMOUNT FROM ROA_PST004_FIXED_ASSETS WHERE
          PERIOD = In_PERIOD AND S_SEQ IN ( '20','30','40' ) AND TYPE ='1'
          GROUP BY PC ORDER BY PC    
      )
      LOOP
        INSERT INTO ROA_PST001_MONTH_DATA
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,REC1.PC ,REC1.D_ACC, REC1.AMOUNT);                 
      END LOOP; 

  --(1-16) --------  
      STR01 :=  'C_NIB_Y_22';
      STR02 :=  In_YYYY || '01';
      for REC1 IN (
        SELECT D_KEY,  (( SUM( D_AMOUNT ) / In_MM2 ) * 12)  AMOUNT
        FROM ROA_PST001_MONTH_DATA
        WHERE PERIOD >= STR02 and  PERIOD <= In_PERIOD
        AND D_KIND = In_KIND AND D_ACC = 'A02200'
      GROUP BY D_KEY
      order by D_KEY
  
      )
      LOOP
        INSERT INTO ROA_PST001_MONTH_DATA
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND, REC1.D_KEY ,STR01, REC1.AMOUNT);                 
      END LOOP; 

  --(1-17) --------  
      STR01 :=  'C_SUB_A_14';
      STR02 :=  In_YYYY || '01';
      for REC1 IN (
        SELECT D_KEY,  ( SUM( D_AMOUNT ) / In_MM2 )  AMOUNT
        FROM ROA_PST001_MONTH_DATA
        WHERE PERIOD >= STR02 and  PERIOD <= In_PERIOD
        AND D_KIND = In_KIND AND D_ACC = 'A01400'
      GROUP BY D_KEY
      order by D_KEY
  
      )
      LOOP
        INSERT INTO ROA_PST001_MONTH_DATA
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND, REC1.D_KEY ,STR01, REC1.AMOUNT);                 
      END LOOP; 

  --(1-18) --------  
      STR01 :=  'C_EQU_A_17';
      STR02 :=  In_YYYY || '01';
      for REC1 IN (
        SELECT D_KEY,  ( SUM( D_AMOUNT ) / In_MM2 )  AMOUNT
        FROM ROA_PST001_MONTH_DATA
        WHERE PERIOD >= STR02 and  PERIOD <= In_PERIOD
        AND D_KIND = In_KIND AND D_ACC = 'A01700'
      GROUP BY D_KEY
      order by D_KEY
  
      )
      LOOP
        INSERT INTO ROA_PST001_MONTH_DATA
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND, REC1.D_KEY ,STR01, REC1.AMOUNT);                 
      END LOOP;

  --(1-19) --------  
      STR01 :=  'C_REV_Y_21';
      STR02 :=  In_YYYY || '01';
      for REC1 IN (
        SELECT D_KEY,  (( SUM( D_AMOUNT ) / In_MM2 )* 12)  AMOUNT
        FROM ROA_PST001_MONTH_DATA
        WHERE PERIOD >= STR02 and  PERIOD <= In_PERIOD
        AND D_KIND = In_KIND AND D_ACC = 'A02100'
      GROUP BY D_KEY
      order by D_KEY
  
      )
      LOOP
        INSERT INTO ROA_PST001_MONTH_DATA
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND, REC1.D_KEY ,STR01, REC1.AMOUNT);                 
      END LOOP;

  --(1-20) --------  
      STR01 :=  'C_SFA_A_10N12';
      STR02 :=  In_YYYY || '01';
      for REC1 IN (
        SELECT D_KEY,  ( SUM( D_AMOUNT ) / In_MM2 )  AMOUNT
        FROM ROA_PST001_MONTH_DATA
        WHERE PERIOD >= STR02 and  PERIOD <= In_PERIOD
        AND D_KIND = In_KIND AND D_ACC in ( 'A01000', 'A01100', 'A01200')
      GROUP BY D_KEY
      order by D_KEY
  
      )
      LOOP
        INSERT INTO ROA_PST001_MONTH_DATA
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND, REC1.D_KEY ,STR01, REC1.AMOUNT);                 
      END LOOP;

  --(1-21) --------  
      STR01 :=  'C_BV1_A_30';
      STR02 :=  In_YYYY || '01';
      for REC1 IN (
        SELECT D_KEY,  ( SUM( D_AMOUNT ) / In_MM2 )  AMOUNT
        FROM ROA_PST001_MONTH_DATA
        WHERE PERIOD >= STR02 and  PERIOD <= In_PERIOD
        AND D_KIND = In_KIND AND D_ACC in ( 'A03000' )
      GROUP BY D_KEY
      order by D_KEY
  
      )
      LOOP
        INSERT INTO ROA_PST001_MONTH_DATA
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND, REC1.D_KEY ,STR01, REC1.AMOUNT);                 
      END LOOP;

  --(1-22) --------  
      STR01 :=  'C_BV2_A_32';
      STR02 :=  In_YYYY || '01';
      for REC1 IN (
        SELECT D_KEY,  ( SUM( D_AMOUNT ) / In_MM2 )  AMOUNT
        FROM ROA_PST001_MONTH_DATA
        WHERE PERIOD >= STR02 and  PERIOD <= In_PERIOD
        AND D_KIND = In_KIND AND D_ACC in ( 'A03200' )
      GROUP BY D_KEY
      order by D_KEY
  
      )
      LOOP
        INSERT INTO ROA_PST001_MONTH_DATA
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND, REC1.D_KEY ,STR01, REC1.AMOUNT);                 
      END LOOP;

  --(1-23) --------  
      STR01 :=  'C_BV2_A_34';
      STR02 :=  In_YYYY || '01';
      for REC1 IN (
        SELECT D_KEY,  ( SUM( D_AMOUNT ) / In_MM2 )  AMOUNT
        FROM ROA_PST001_MONTH_DATA
        WHERE PERIOD >= STR02 and  PERIOD <= In_PERIOD
        AND D_KIND = In_KIND AND D_ACC in ( 'A03400' )
      GROUP BY D_KEY
      order by D_KEY
  
      )
      LOOP
        INSERT INTO ROA_PST001_MONTH_DATA
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND, REC1.D_KEY ,STR01, REC1.AMOUNT);                 
      END LOOP;


  --(1-24) --------  
      STR01 :=  'C_BV2_A_36';
      STR02 :=  In_YYYY || '01';
      for REC1 IN (
        SELECT D_KEY,  ( SUM( D_AMOUNT ) / In_MM2 )  AMOUNT
        FROM ROA_PST001_MONTH_DATA
        WHERE PERIOD >= STR02 and  PERIOD <= In_PERIOD
        AND D_KIND = In_KIND AND D_ACC in ( 'A03600' )
      GROUP BY D_KEY
      order by D_KEY
  
      )
      LOOP
        INSERT INTO ROA_PST001_MONTH_DATA
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND, REC1.D_KEY ,STR01, REC1.AMOUNT);                 
      END LOOP;

  --(1-25) --------  
      STR01 :=  'C_BV2_A_38';
      STR02 :=  In_YYYY || '01';
      for REC1 IN (
        SELECT D_KEY,  ( SUM( D_AMOUNT ) / In_MM2 )  AMOUNT
        FROM ROA_PST001_MONTH_DATA
        WHERE PERIOD >= STR02 and  PERIOD <= In_PERIOD
        AND D_KIND = In_KIND AND D_ACC in ( 'A03800' )
      GROUP BY D_KEY
      order by D_KEY
  
      )
      LOOP
        INSERT INTO ROA_PST001_MONTH_DATA
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND, REC1.D_KEY ,STR01, REC1.AMOUNT);                 
      END LOOP;

    
      
  /*****************************************************************************************
      (2)Kind = 08-USI(no Bravo)
  ************************************************************************************ */
  ELSIF In_KIND IN ('08') THEN    
    In_KIND := '08'; 
    USI_KIND := '09';
    PC_KIND := '01';
    STR06 :=  'USI'; 
    STR07 :=  'USI(No Bravo)';
    STR03 :=  '0000000080';     
    STR04 :=  '80';
    
  --(2-01) --------      
      STR01 :=  'A00800';
      for REC1 IN ( 
          select b.D_AMOUNT-a.AMOUNT AMOUNT from
          ( SELECT sum( upl_amt ) AMOUNT FROM ROA_UPL004_AR_AP_INV_DATA WHERE
          PERIOD = In_PERIOD AND TYPE IN ( 'AR' )  AND  ( PC = STR03 ) ) a ,
          ( select D_AMOUNT from ROA_PST001_MONTH_DATA where period = In_PERIOD
          and D_KIND = USI_KIND and D_KEY = STR06 and D_ACC = STR01) b              
      )
      LOOP
        INSERT INTO ROA_PST001_MONTH_DATA
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR07 ,STR01, REC1.AMOUNT);                 
      END LOOP;    
      
--(2-02) --------  
      STR01 :=  'A00900';
      for REC1 IN (  
          select b.D_AMOUNT-a.AMOUNT AMOUNT from
          ( SELECT sum( upl_amt ) AMOUNT FROM ROA_UPL004_AR_AP_INV_DATA WHERE
          PERIOD = In_PERIOD AND TYPE IN  ( 'INV', 'ADJ_INV' ) AND ( PC = STR03 )  ) a ,
          ( select D_AMOUNT from ROA_PST001_MONTH_DATA where period = In_PERIOD
          and D_KIND = USI_KIND and D_KEY = STR06 and D_ACC = STR01) b             
      )
      LOOP
        INSERT INTO ROA_PST001_MONTH_DATA
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR07 ,STR01, REC1.AMOUNT);                  
      END LOOP; 
           
  --(2-03) --------  
      STR01 :=  'A01500';
      for REC1 IN (       
          select b.D_AMOUNT-a.AMOUNT AMOUNT from
          ( SELECT sum( upl_amt ) AMOUNT FROM ROA_UPL004_AR_AP_INV_DATA WHERE
          PERIOD = In_PERIOD AND TYPE IN  ( 'AP' ) AND ( PC = STR03 )  ) a ,
          ( select D_AMOUNT from ROA_PST001_MONTH_DATA where period = In_PERIOD
          and D_KIND = USI_KIND and D_KEY = STR06 and D_ACC = STR01 ) b       
      )
      LOOP
        INSERT INTO ROA_PST001_MONTH_DATA
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR07 ,STR01, REC1.AMOUNT);                   
      END LOOP;       

  --(2-04) --------  
      STR01 :=  'A01000';
      for REC1 IN (    
          select b.D_AMOUNT-a.AMOUNT AMOUNT from
          ( SELECT sum( AFTER_AMT_TWD ) AMOUNT FROM ROA_PST004_FIXED_ASSETS WHERE
          PERIOD = In_PERIOD AND S_SEQ IN ( '10' ) AND TYPE ='2' AND ( PC = STR03 ) ) a, 
          ( select D_AMOUNT from ROA_PST001_MONTH_DATA where period = In_PERIOD
          and D_KIND = USI_KIND and D_KEY = STR06 and D_ACC = STR01 ) b          
            
      )
      LOOP
        INSERT INTO ROA_PST001_MONTH_DATA
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR07 ,STR01, REC1.AMOUNT);                  
      END LOOP; 

  --(2-05) --------  
      STR01 :=  'A01100';
      for REC1 IN (  
          select b.D_AMOUNT-a.AMOUNT AMOUNT from
          ( SELECT sum( AFTER_AMT_TWD ) AMOUNT FROM ROA_PST004_FIXED_ASSETS WHERE
          PERIOD = In_PERIOD AND S_SEQ IN ( '20' ) AND TYPE ='2' AND ( PC = STR03 ) ) a, 
          ( select D_AMOUNT from ROA_PST001_MONTH_DATA where period = In_PERIOD
          and D_KIND = USI_KIND and D_KEY = STR06 and D_ACC = STR01 ) b    
      )
      LOOP
        INSERT INTO ROA_PST001_MONTH_DATA
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR07 ,STR01, REC1.AMOUNT);               
      END LOOP;    

  --(2-06) --------  
      STR01 :=  'A03000';
      for REC1 IN (  
          select b.D_AMOUNT-a.AMOUNT AMOUNT from 
          ( SELECT STR01 D_ACC,  sum( AFTER_AMT_TWD ) AMOUNT FROM ROA_PST004_FIXED_ASSETS WHERE
          PERIOD = In_PERIOD AND S_SEQ IN ( '20' ) AND TYPE ='2' AND ( PC = STR03 ) ) a, 
          ( select D_AMOUNT from ROA_PST001_MONTH_DATA where period = In_PERIOD
          and D_KIND = USI_KIND and D_KEY = STR06 and D_ACC = STR01 ) b   
      )
      LOOP
        INSERT INTO ROA_PST001_MONTH_DATA
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR07 ,STR01, REC1.AMOUNT);                
      END LOOP;   

  --(2-07) --------  
      STR01 :=  'A01200';
      for REC1 IN (
          select b.D_AMOUNT-a.AMOUNT AMOUNT from
          ( SELECT sum( AFTER_AMT_TWD ) AMOUNT FROM ROA_PST004_FIXED_ASSETS WHERE
          PERIOD = In_PERIOD AND S_SEQ IN ( '30','40' ) AND TYPE ='2' AND ( PC = STR03 )  ) a, 
          ( select D_AMOUNT from ROA_PST001_MONTH_DATA where period = In_PERIOD
          and D_KIND = USI_KIND and D_KEY = STR06 and D_ACC = STR01 ) b  
      )
      LOOP
        INSERT INTO ROA_PST001_MONTH_DATA
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR07 ,STR01, REC1.AMOUNT);                
      END LOOP;  
           
  --(2-08) --------  
      STR01 :=  'A03200';
      for REC1 IN (  
          select b.D_AMOUNT-a.AMOUNT AMOUNT from
          ( SELECT sum( AFTER_AMT_TWD ) AMOUNT FROM ROA_PST004_FIXED_ASSETS WHERE
          PERIOD = In_PERIOD AND S_SEQ IN ( '20','30','40' ) AND TYPE ='2'  AND ( PC = STR03 ) ) a, 
          ( select D_AMOUNT from ROA_PST001_MONTH_DATA where period = In_PERIOD
          and D_KIND = USI_KIND and D_KEY = STR06 and D_ACC = STR01 ) b     
      )
      LOOP
        INSERT INTO ROA_PST001_MONTH_DATA
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR07 ,STR01, REC1.AMOUNT);                
      END LOOP;      

  --(2-09) --------  
      STR01 :=  'A02900';
      for REC1 IN ( 
          select b.D_AMOUNT-a.AMOUNT AMOUNT from
          ( SELECT sum( AFTER_AMT_TWD ) AMOUNT FROM ROA_PST004_FIXED_ASSETS WHERE
          PERIOD = In_PERIOD AND S_SEQ IN ( '10','20','30','40' ) AND TYPE ='2' AND ( PC = STR03 )) a, 
          ( select D_AMOUNT from ROA_PST001_MONTH_DATA where period = In_PERIOD
          and D_KIND = USI_KIND and D_KEY = STR06 and D_ACC = STR01 ) b    
      )
      LOOP
        INSERT INTO ROA_PST001_MONTH_DATA
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR07 ,STR01, REC1.AMOUNT);                
      END LOOP;
      
  --(2-10) --------  
      STR01 :=  'A02100';
      STR02 :=  'Net Mfg Revenues';
      for REC1 IN (  
          select a.amount1 - b.amount2 amount from
          ( SELECT sum( amount ) AMOUNT1  FROM PNL_MSA001_EM_DATA WHERE
          YYYY = In_YYYY AND MONTH = In_MM AND acct_id <> ' ' AND ACCT_NAME = STR02 ) a,
          ( SELECT sum( amount ) AMOUNT2  FROM PNL_MSA001_EM_DATA WHERE
          YYYY = In_YYYY AND MONTH = In_MM AND acct_id <> ' ' AND ACCT_NAME = STR02 AND ( PC = STR04 ) ) b
      )
      LOOP
        INSERT INTO ROA_PST001_MONTH_DATA
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR07 ,STR01, REC1.AMOUNT);                
      END LOOP; 
      
  --(2-11) --------  
      STR01 :=  'A02200';
      STR02 :=  '07.050';
      for REC1 IN (        
          select a.amount1 - b.amount2 amount from
          ( SELECT sum( amount ) AMOUNT1  FROM PNL_MSA001_EM_DATA WHERE
          YYYY = In_YYYY AND MONTH = In_MM AND acct_id <> ' ' AND acct_id <= STR02 ) a,
          ( SELECT sum( amount ) AMOUNT2  FROM PNL_MSA001_EM_DATA WHERE
          YYYY = In_YYYY AND MONTH = In_MM AND acct_id <> ' ' AND acct_id <= STR02 AND ( PC = STR04 ) ) b             
      )
      LOOP
        INSERT INTO ROA_PST001_MONTH_DATA
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR07 ,STR01, REC1.AMOUNT);                 
      END LOOP;       

  --(2-12) --------  
      STR01 :=  'A04000';
      for REC1 IN (
          select b.D_AMOUNT-a.AMOUNT AMOUNT from
          ( SELECT sum( AFTER_AMT_TWD ) AMOUNT FROM ROA_PST004_FIXED_ASSETS WHERE
          PERIOD = In_PERIOD AND S_SEQ IN ( '10' ) AND TYPE ='1' AND ( PC = STR03 ) ) a, 
          ( select D_AMOUNT from ROA_PST001_MONTH_DATA where period = In_PERIOD
          and D_KIND = USI_KIND and D_KEY = STR06 and D_ACC = STR01 ) b     
      )
      LOOP
        INSERT INTO ROA_PST001_MONTH_DATA
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR07 ,STR01, REC1.AMOUNT);                 
      END LOOP;

  --(2-13) --------  
      STR01 :=  'A03600';
      for REC1 IN ( 
          select b.D_AMOUNT-a.AMOUNT AMOUNT from
          ( SELECT sum( AFTER_AMT_TWD ) AMOUNT FROM ROA_PST004_FIXED_ASSETS WHERE
          PERIOD = In_PERIOD AND S_SEQ IN ( '20' ) AND TYPE ='1' AND ( PC = STR03 ) ) a, 
          ( select D_AMOUNT from ROA_PST001_MONTH_DATA where period = In_PERIOD
          and D_KIND = USI_KIND and D_KEY = STR06 and D_ACC = STR01 ) b     
      )
      LOOP
        INSERT INTO ROA_PST001_MONTH_DATA
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR07 ,STR01, REC1.AMOUNT);                 
      END LOOP;

  --(2-13) --------  
      STR01 :=  'A04100';
      for REC1 IN (
          select b.D_AMOUNT-a.AMOUNT AMOUNT from
          ( SELECT sum( AFTER_AMT_TWD ) AMOUNT FROM ROA_PST004_FIXED_ASSETS WHERE
          PERIOD = In_PERIOD AND S_SEQ IN ( '20' ) AND TYPE ='1' AND ( PC = STR03 ) ) a, 
          ( select D_AMOUNT from ROA_PST001_MONTH_DATA where period = In_PERIOD
          and D_KIND = USI_KIND and D_KEY = STR06 and D_ACC = STR01 ) b               
      )
      LOOP
        INSERT INTO ROA_PST001_MONTH_DATA
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR07 ,STR01, REC1.AMOUNT);               
      END LOOP;
                
  --(2-14) --------  
      STR01 :=  'A04200';
      for REC1 IN (   
          select b.D_AMOUNT-a.AMOUNT AMOUNT from
          ( SELECT sum( AFTER_AMT_TWD ) AMOUNT FROM ROA_PST004_FIXED_ASSETS WHERE
          PERIOD = In_PERIOD AND S_SEQ IN ( '30','40' ) AND TYPE ='1'  AND ( PC = STR03 )) a, 
          ( select D_AMOUNT from ROA_PST001_MONTH_DATA where period = In_PERIOD
          and D_KIND = USI_KIND and D_KEY = STR06 and D_ACC = STR01 ) b   
      )
      LOOP
        INSERT INTO ROA_PST001_MONTH_DATA
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR07 ,STR01, REC1.AMOUNT);               
      END LOOP;             

  --(2-15) --------  
      STR01 :=  'A03800';
      for REC1 IN ( 
          select b.D_AMOUNT-a.AMOUNT AMOUNT from
          ( SELECT sum( AFTER_AMT_TWD ) AMOUNT FROM ROA_PST004_FIXED_ASSETS WHERE
          PERIOD = In_PERIOD AND S_SEQ IN ( '20','30','40' ) AND TYPE ='1'  AND ( PC = STR03 )) a,
          ( select D_AMOUNT from ROA_PST001_MONTH_DATA where period = In_PERIOD
          and D_KIND = USI_KIND and D_KEY = STR06 and D_ACC = STR01 ) b             
      )
      LOOP
        INSERT INTO ROA_PST001_MONTH_DATA
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR07 ,STR01, REC1.AMOUNT);                
      END LOOP; 

  --(2-16) --------  
      STR01 :=  'C_NIB_Y_22';
      STR02 :=  In_YYYY || '01';
      for REC1 IN (  
         select b.D_AMOUNT-a.D_AMOUNT AMOUNT from       
         ( select D_AMOUNT from ROA_PST001_MONTH_DATA where period = In_PERIOD
         and D_KIND = PC_KIND and D_KEY = STR03 and D_ACC = STR01 ) a,      
         ( select D_AMOUNT from ROA_PST001_MONTH_DATA where period = In_PERIOD
         and D_KIND = USI_KIND and D_KEY = STR06 and D_ACC = STR01 ) b
  
      )
      LOOP
        INSERT INTO ROA_PST001_MONTH_DATA
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR07 ,STR01, REC1.AMOUNT);                 
      END LOOP; 

  --(2-17) --------  
      STR01 :=  'C_SUB_A_14';
      STR02 :=  In_YYYY || '01';
      for REC1 IN (  
         select b.D_AMOUNT-a.D_AMOUNT AMOUNT from       
         ( select D_AMOUNT from ROA_PST001_MONTH_DATA where period = In_PERIOD
         and D_KIND = PC_KIND and D_KEY = STR03 and D_ACC = STR01 ) a,      
         ( select D_AMOUNT from ROA_PST001_MONTH_DATA where period = In_PERIOD
         and D_KIND = USI_KIND and D_KEY = STR06 and D_ACC = STR01 ) b
  
      )
      LOOP
        INSERT INTO ROA_PST001_MONTH_DATA
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR07 ,STR01, REC1.AMOUNT);                 
      END LOOP; 

  --(2-18) --------  
      STR01 :=  'C_EQU_A_17';
      STR02 :=  In_YYYY || '01';
      for REC1 IN (  
         select b.D_AMOUNT-a.D_AMOUNT AMOUNT from       
         ( select D_AMOUNT from ROA_PST001_MONTH_DATA where period = In_PERIOD
         and D_KIND = PC_KIND and D_KEY = STR03 and D_ACC = STR01 ) a,      
         ( select D_AMOUNT from ROA_PST001_MONTH_DATA where period = In_PERIOD
         and D_KIND = USI_KIND and D_KEY = STR06 and D_ACC = STR01 ) b
  
      )
      LOOP
        INSERT INTO ROA_PST001_MONTH_DATA
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR07 ,STR01, REC1.AMOUNT);                 
      END LOOP;

  --(2-19) --------  
      STR01 :=  'C_REV_Y_21';
      STR02 :=  In_YYYY || '01';
      for REC1 IN (  
         select b.D_AMOUNT-a.D_AMOUNT AMOUNT from       
         ( select D_AMOUNT from ROA_PST001_MONTH_DATA where period = In_PERIOD
         and D_KIND = PC_KIND and D_KEY = STR03 and D_ACC = STR01 ) a,      
         ( select D_AMOUNT from ROA_PST001_MONTH_DATA where period = In_PERIOD
         and D_KIND = USI_KIND and D_KEY = STR06 and D_ACC = STR01 ) b
  
      )
      LOOP
        INSERT INTO ROA_PST001_MONTH_DATA
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR07 ,STR01, REC1.AMOUNT);                 
      END LOOP;

  --(2-20) --------  
      STR01 :=  'C_SFA_A_10N12';
      STR02 :=  In_YYYY || '01';
      for REC1 IN (  
         select b.D_AMOUNT-a.D_AMOUNT AMOUNT from       
         ( select D_AMOUNT from ROA_PST001_MONTH_DATA where period = In_PERIOD
         and D_KIND = PC_KIND and D_KEY = STR03 and D_ACC = STR01 ) a,      
         ( select D_AMOUNT from ROA_PST001_MONTH_DATA where period = In_PERIOD
         and D_KIND = USI_KIND and D_KEY = STR06 and D_ACC = STR01 ) b
  
      )
      LOOP
        INSERT INTO ROA_PST001_MONTH_DATA
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR07 ,STR01, REC1.AMOUNT);                 
      END LOOP;

  --(2-21) --------  
      STR01 :=  'C_BV1_A_30';
      STR02 :=  In_YYYY || '01';
      for REC1 IN (  
         select b.D_AMOUNT-a.D_AMOUNT AMOUNT from       
         ( select D_AMOUNT from ROA_PST001_MONTH_DATA where period = In_PERIOD
         and D_KIND = PC_KIND and D_KEY = STR03 and D_ACC = STR01 ) a,      
         ( select D_AMOUNT from ROA_PST001_MONTH_DATA where period = In_PERIOD
         and D_KIND = USI_KIND and D_KEY = STR06 and D_ACC = STR01 ) b
  
      )
      LOOP
        INSERT INTO ROA_PST001_MONTH_DATA
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR07 ,STR01, REC1.AMOUNT);                 
      END LOOP;

  --(2-22) --------  
      STR01 :=  'C_BV2_A_32';
      STR02 :=  In_YYYY || '01';
      for REC1 IN (  
         select b.D_AMOUNT-a.D_AMOUNT AMOUNT from       
         ( select D_AMOUNT from ROA_PST001_MONTH_DATA where period = In_PERIOD
         and D_KIND = PC_KIND and D_KEY = STR03 and D_ACC = STR01 ) a,      
         ( select D_AMOUNT from ROA_PST001_MONTH_DATA where period = In_PERIOD
         and D_KIND = USI_KIND and D_KEY = STR06 and D_ACC = STR01 ) b
  
      )
      LOOP
        INSERT INTO ROA_PST001_MONTH_DATA
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR07 ,STR01, REC1.AMOUNT);                 
      END LOOP;

  --(2-23) --------  
      STR01 :=  'C_BV2_A_34';
      STR02 :=  In_YYYY || '01';
      for REC1 IN (  
         select b.D_AMOUNT-a.D_AMOUNT AMOUNT from       
         ( select D_AMOUNT from ROA_PST001_MONTH_DATA where period = In_PERIOD
         and D_KIND = PC_KIND and D_KEY = STR03 and D_ACC = STR01 ) a,      
         ( select D_AMOUNT from ROA_PST001_MONTH_DATA where period = In_PERIOD
         and D_KIND = USI_KIND and D_KEY = STR06 and D_ACC = STR01 ) b
  
      )
      LOOP
        INSERT INTO ROA_PST001_MONTH_DATA
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR07 ,STR01, REC1.AMOUNT);                 
      END LOOP;


  --(2-24) --------  
      STR01 :=  'C_BV2_A_36';
      STR02 :=  In_YYYY || '01';
      for REC1 IN (  
         select b.D_AMOUNT-a.D_AMOUNT AMOUNT from       
         ( select D_AMOUNT from ROA_PST001_MONTH_DATA where period = In_PERIOD
         and D_KIND = PC_KIND and D_KEY = STR03 and D_ACC = STR01 ) a,      
         ( select D_AMOUNT from ROA_PST001_MONTH_DATA where period = In_PERIOD
         and D_KIND = USI_KIND and D_KEY = STR06 and D_ACC = STR01 ) b
  
      )
      LOOP
        INSERT INTO ROA_PST001_MONTH_DATA
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR07 ,STR01, REC1.AMOUNT);                 
      END LOOP;

  --(2-25) --------  
      STR01 :=  'C_BV2_A_38';
      STR02 :=  In_YYYY || '01';
      for REC1 IN (  
         select b.D_AMOUNT-a.D_AMOUNT AMOUNT from       
         ( select D_AMOUNT from ROA_PST001_MONTH_DATA where period = In_PERIOD
         and D_KIND = PC_KIND and D_KEY = STR03 and D_ACC = STR01 ) a,      
         ( select D_AMOUNT from ROA_PST001_MONTH_DATA where period = In_PERIOD
         and D_KIND = USI_KIND and D_KEY = STR06 and D_ACC = STR01 ) b
  
      )
      LOOP
        INSERT INTO ROA_PST001_MONTH_DATA
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR07 ,STR01, REC1.AMOUNT);                 
      END LOOP;   
    
  /*****************************************************************************************
      (3)Kind = 09-USI
  ************************************************************************************ */    
  ELSIF In_KIND IN ('09') THEN
    In_KIND := '09'; 
    STR06 :=  'USI';


  --(3-26) --------      
      STR01 :=  'A00200';
      for REC1 IN (
          select SUM(a.upl_amt) Amount from ROA_UPL003_BS_DATA a join ROA_MAP002_BS_ACCOUNT b
          on b.S_DESC = a.S_DESC where b.account = 'Cash' and PERIOD = In_PERIOD 
          and company_code = STR06               
      )
      LOOP
        INSERT INTO ROA_PST001_MONTH_DATA
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR06 ,STR01, REC1.AMOUNT);                 
      END LOOP;  
      
  --(3-27) --------      
      STR01 :=  'A00400';
      for REC1 IN (
          select SUM(a.upl_amt) Amount from ROA_UPL003_BS_DATA a join ROA_MAP002_BS_ACCOUNT b
          on b.S_DESC = a.S_DESC where b.account = 'Financial Asset' and PERIOD = In_PERIOD
          and company_code = STR06                 
      )
      LOOP
        INSERT INTO ROA_PST001_MONTH_DATA
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR06 ,STR01, REC1.AMOUNT);                 
      END LOOP;

  --(3-28) --------      
      STR01 :=  'A00500';
      for REC1 IN (
          select SUM(a.upl_amt) Amount from ROA_UPL003_BS_DATA a join ROA_MAP002_BS_ACCOUNT b
          on b.S_DESC = a.S_DESC where b.account = 'Others Receivable' and PERIOD = In_PERIOD  
          and company_code = STR06               
      )
      LOOP
        INSERT INTO ROA_PST001_MONTH_DATA
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR06 ,STR01, REC1.AMOUNT);                 
      END LOOP;
      
  --(3-29) --------      
      STR01 :=  'A00600';
      for REC1 IN (
          select SUM(a.upl_amt) Amount from ROA_UPL003_BS_DATA a join ROA_MAP002_BS_ACCOUNT b
          on b.S_DESC = a.S_DESC where b.account = 'Deferred Tax' and PERIOD = In_PERIOD  
          and company_code = STR06               
      )
      LOOP
        INSERT INTO ROA_PST001_MONTH_DATA
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR06 ,STR01, REC1.AMOUNT);                 
      END LOOP;      
      
  --(3-30) --------      
      STR01 :=  'A00700';
      for REC1 IN (
          select SUM(a.upl_amt) Amount from ROA_UPL003_BS_DATA a join ROA_MAP002_BS_ACCOUNT b
          on b.S_DESC = a.S_DESC where b.account = 'Deferred charges' and PERIOD = In_PERIOD 
          and company_code = STR06                
      )
      LOOP
        INSERT INTO ROA_PST001_MONTH_DATA
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR06 ,STR01, REC1.AMOUNT);                 
      END LOOP;

  --(3-31) --------      
      STR01 :=  'A01400';
      for REC1 IN (
          select SUM(a.upl_amt) Amount from ROA_UPL003_BS_DATA a join ROA_MAP002_BS_ACCOUNT b
          on b.S_DESC = a.S_DESC where b.account = 'Total assets' and PERIOD = In_PERIOD 
          and company_code = STR06                
      )
      LOOP
        INSERT INTO ROA_PST001_MONTH_DATA
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR06 ,STR01, REC1.AMOUNT);                 
      END LOOP;

  --(3-32) --------      
      STR01 :=  'A01700';
      for REC1 IN (
          select SUM(a.upl_amt) Amount from ROA_UPL003_BS_DATA a join ROA_MAP002_BS_ACCOUNT b
          on b.S_DESC = a.S_DESC where b.account = 'Equity' and PERIOD = In_PERIOD 
          and company_code = STR06                
      )
      LOOP
        INSERT INTO ROA_PST001_MONTH_DATA
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR06 ,STR01, REC1.AMOUNT);                 
      END LOOP;
      
                
  --(3-01) --------      
      STR01 :=  'A00800';
      for REC1 IN (
          select SUM(a.upl_amt) Amount from ROA_UPL003_BS_DATA a join ROA_MAP002_BS_ACCOUNT b
          on b.S_DESC = a.S_DESC where b.account = 'AR-3rd' and PERIOD = In_PERIOD  
          and company_code = STR06               
      )
      LOOP
        INSERT INTO ROA_PST001_MONTH_DATA
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR06 ,STR01, REC1.AMOUNT);                 
      END LOOP;   
      
--(3-02) --------  
      STR01 :=  'A00900';
      for REC1 IN (
          select SUM(a.upl_amt) Amount from ROA_UPL003_BS_DATA a join ROA_MAP002_BS_ACCOUNT b
          on b.S_DESC = a.S_DESC where b.account = 'INV' and PERIOD = In_PERIOD     
          and company_code = STR06            
      )
      LOOP
        INSERT INTO ROA_PST001_MONTH_DATA
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR06 ,STR01, REC1.AMOUNT);                 
      END LOOP; 
           
  --(3-03) --------  
      STR01 :=  'A01500';
      for REC1 IN (
          select SUM(a.upl_amt) Amount from ROA_UPL003_BS_DATA a join ROA_MAP002_BS_ACCOUNT b
          on b.S_DESC = a.S_DESC where b.account = 'AP-3rd' and PERIOD = In_PERIOD   
          and company_code = STR06              
      )
      LOOP
        INSERT INTO ROA_PST001_MONTH_DATA
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR06 ,STR01, REC1.AMOUNT);                 
      END LOOP;      

  --(3-04) --------  
      STR01 :=  'A01000';
      for REC1 IN (
          SELECT STR01 D_ACC,  sum( AFTER_AMT_TWD ) AMOUNT FROM ROA_PST004_FIXED_ASSETS WHERE
          PERIOD = In_PERIOD AND S_SEQ IN ( '10' ) AND TYPE ='2'    
              
      )
      LOOP
        INSERT INTO ROA_PST001_MONTH_DATA
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR06 ,REC1.D_ACC, REC1.AMOUNT);                 
      END LOOP; 

  --(3-05) --------  
      STR01 :=  'A01100';
      for REC1 IN (
          SELECT STR01 D_ACC,  sum( AFTER_AMT_TWD ) AMOUNT FROM ROA_PST004_FIXED_ASSETS WHERE
          PERIOD = In_PERIOD AND S_SEQ IN ( '20' ) AND TYPE ='2'
              
      )
      LOOP
        INSERT INTO ROA_PST001_MONTH_DATA
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR06 ,REC1.D_ACC, REC1.AMOUNT);                 
      END LOOP;    

  --(3-06) --------  
      STR01 :=  'A03000';
      for REC1 IN (
          SELECT STR01 D_ACC,  sum( AFTER_AMT_TWD ) AMOUNT FROM ROA_PST004_FIXED_ASSETS WHERE
          PERIOD = In_PERIOD AND S_SEQ IN ( '20' ) AND TYPE ='2'
              
      )
      LOOP
        INSERT INTO ROA_PST001_MONTH_DATA
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR06 ,REC1.D_ACC, REC1.AMOUNT);                 
      END LOOP;   

  --(3-07) --------  
      STR01 :=  'A01200';
      for REC1 IN (
          SELECT STR01 D_ACC,  sum( AFTER_AMT_TWD ) AMOUNT FROM ROA_PST004_FIXED_ASSETS WHERE
          PERIOD = In_PERIOD AND S_SEQ IN ( '30','40' ) AND TYPE ='2'
              
      )
      LOOP
        INSERT INTO ROA_PST001_MONTH_DATA
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR06 ,REC1.D_ACC, REC1.AMOUNT);                 
      END LOOP;  
           
  --(3-08) --------  
      STR01 :=  'A03200';
      for REC1 IN (
          SELECT STR01 D_ACC,  sum( AFTER_AMT_TWD ) AMOUNT FROM ROA_PST004_FIXED_ASSETS WHERE
          PERIOD = In_PERIOD AND S_SEQ IN ( '20','30','40' ) AND TYPE ='2'
              
      )
      LOOP
        INSERT INTO ROA_PST001_MONTH_DATA
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR06 ,REC1.D_ACC, REC1.AMOUNT);                 
      END LOOP;      

  --(3-09) --------  
      STR01 :=  'A02900';
      for REC1 IN (
          SELECT STR01 D_ACC,  sum( AFTER_AMT_TWD ) AMOUNT FROM ROA_PST004_FIXED_ASSETS WHERE
          PERIOD = In_PERIOD AND S_SEQ IN ( '10','20','30','40' ) AND TYPE ='2'
              
      )
      LOOP
        INSERT INTO ROA_PST001_MONTH_DATA
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR06 ,REC1.D_ACC, REC1.AMOUNT);                 
      END LOOP;
      
  --(3-10) --------  
      STR01 :=  'A02100';
      STR02 :=  'Net Mfg Revenues';
      for REC1 IN (
          SELECT STR01 D_ACC,   sum( amount ) AMOUNT FROM PNL_MSA001_EM_DATA WHERE
          YYYY = In_YYYY AND MONTH = In_MM AND acct_id<> ' ' AND ACCT_NAME = STR02
              
      )
      LOOP
        INSERT INTO ROA_PST001_MONTH_DATA
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR06 ,REC1.D_ACC, REC1.AMOUNT);                 
      END LOOP; 
      
  --(3-11) --------  
      STR01 :=  'A02200';
      STR02 :=  '07.050';
      for REC1 IN (
          SELECT STR01 D_ACC,   sum( amount ) AMOUNT FROM PNL_MSA001_EM_DATA WHERE
          YYYY = In_YYYY AND MONTH = In_MM AND acct_id <> ' ' AND acct_id <= STR02
              
      )
      LOOP
        INSERT INTO ROA_PST001_MONTH_DATA
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR06 ,REC1.D_ACC, REC1.AMOUNT);                 
      END LOOP;       

  --(3-12) --------  
      STR01 :=  'A04000';
      for REC1 IN (
          SELECT STR01 D_ACC,  sum( AFTER_AMT_TWD ) AMOUNT FROM ROA_PST004_FIXED_ASSETS WHERE
          PERIOD = In_PERIOD AND S_SEQ IN ( '10' ) AND TYPE ='1'
              
      )
      LOOP
        INSERT INTO ROA_PST001_MONTH_DATA
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR06 ,REC1.D_ACC, REC1.AMOUNT);                 
      END LOOP;

  --(3-13) --------  
      STR01 :=  'A03600';
      for REC1 IN (
          SELECT STR01 D_ACC,  sum( AFTER_AMT_TWD ) AMOUNT FROM ROA_PST004_FIXED_ASSETS WHERE
          PERIOD = In_PERIOD AND S_SEQ IN ( '20' ) AND TYPE ='1'
              
      )
      LOOP
        INSERT INTO ROA_PST001_MONTH_DATA
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR06 ,REC1.D_ACC, REC1.AMOUNT);                 
      END LOOP;

  --(3-13) --------  
      STR01 :=  'A04100';
      for REC1 IN (
          SELECT STR01 D_ACC,  sum( AFTER_AMT_TWD ) AMOUNT FROM ROA_PST004_FIXED_ASSETS WHERE
          PERIOD = In_PERIOD AND S_SEQ IN ( '20' ) AND TYPE ='1'
              
      )
      LOOP
        INSERT INTO ROA_PST001_MONTH_DATA
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR06 ,REC1.D_ACC, REC1.AMOUNT);                 
      END LOOP;
                
  --(3-14) --------  
      STR01 :=  'A04200';
      for REC1 IN (
          SELECT STR01 D_ACC,  sum( AFTER_AMT_TWD ) AMOUNT FROM ROA_PST004_FIXED_ASSETS WHERE
          PERIOD = In_PERIOD AND S_SEQ IN ( '30','40' ) AND TYPE ='1'
              
      )
      LOOP
        INSERT INTO ROA_PST001_MONTH_DATA
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR06 ,REC1.D_ACC, REC1.AMOUNT);                 
      END LOOP;             

  --(3-15) --------  
      STR01 :=  'A03800';
      for REC1 IN (
          SELECT STR01 D_ACC,  sum( AFTER_AMT_TWD ) AMOUNT FROM ROA_PST004_FIXED_ASSETS WHERE
          PERIOD = In_PERIOD AND S_SEQ IN ( '20','30','40' ) AND TYPE ='1'
              
      )
      LOOP
        INSERT INTO ROA_PST001_MONTH_DATA
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR06 ,REC1.D_ACC, REC1.AMOUNT);                 
      END LOOP; 

  --(3-16) --------  
      STR01 :=  'C_NIB_Y_22';
      STR02 :=  In_YYYY || '01';
      for REC1 IN (
        SELECT (( SUM( D_AMOUNT ) / In_MM2 ) * 12)  AMOUNT
        FROM ROA_PST001_MONTH_DATA
        WHERE PERIOD >= STR02 and  PERIOD <= In_PERIOD
        AND D_KIND = In_KIND AND D_ACC = 'A02200' 
      )
      LOOP
        INSERT INTO ROA_PST001_MONTH_DATA
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND, STR06 ,STR01, REC1.AMOUNT);                 
      END LOOP; 

  --(3-17) --------  
      STR01 :=  'C_SUB_A_14';
      STR02 :=  In_YYYY || '01';
      for REC1 IN (
        SELECT ( SUM( D_AMOUNT ) / In_MM2 )  AMOUNT
        FROM ROA_PST001_MONTH_DATA
        WHERE PERIOD >= STR02 and  PERIOD <= In_PERIOD
        AND D_KIND = In_KIND AND D_ACC = 'A01400'  
      )
      LOOP
        INSERT INTO ROA_PST001_MONTH_DATA
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND, STR06 ,STR01, REC1.AMOUNT);                 
      END LOOP; 

  --(3-18) --------  
      STR01 :=  'C_EQU_A_17';
      STR02 :=  In_YYYY || '01';
      for REC1 IN (
        SELECT ( SUM( D_AMOUNT ) / In_MM2 )  AMOUNT
        FROM ROA_PST001_MONTH_DATA
        WHERE PERIOD >= STR02 and  PERIOD <= In_PERIOD
        AND D_KIND = In_KIND AND D_ACC = 'A01700'  
      )
      LOOP
        INSERT INTO ROA_PST001_MONTH_DATA
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND, STR06 ,STR01, REC1.AMOUNT);                 
      END LOOP;

  --(3-19) --------  
      STR01 :=  'C_REV_Y_21';
      STR02 :=  In_YYYY || '01';
      for REC1 IN (
        SELECT   (( SUM( D_AMOUNT ) / In_MM2 )* 12)  AMOUNT
        FROM ROA_PST001_MONTH_DATA
        WHERE PERIOD >= STR02 and  PERIOD <= In_PERIOD
        AND D_KIND = In_KIND AND D_ACC = 'A02100'  
      )
      LOOP
        INSERT INTO ROA_PST001_MONTH_DATA
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND, STR06 ,STR01, REC1.AMOUNT);                 
      END LOOP;

  --(3-20) --------  
      STR01 :=  'C_SFA_A_10N12';
      STR02 :=  In_YYYY || '01';
      for REC1 IN (
        SELECT   ( SUM( D_AMOUNT ) / In_MM2 )  AMOUNT
        FROM ROA_PST001_MONTH_DATA
        WHERE PERIOD >= STR02 and  PERIOD <= In_PERIOD
        AND D_KIND = In_KIND AND D_ACC in ( 'A01000', 'A01100', 'A01200')  
      )
      LOOP
        INSERT INTO ROA_PST001_MONTH_DATA
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND, STR06 ,STR01, REC1.AMOUNT);                 
      END LOOP;

  --(3-21) --------  
      STR01 :=  'C_BV1_A_30';
      STR02 :=  In_YYYY || '01';
      for REC1 IN (
        SELECT ( SUM( D_AMOUNT ) / In_MM2 )  AMOUNT
        FROM ROA_PST001_MONTH_DATA
        WHERE PERIOD >= STR02 and  PERIOD <= In_PERIOD
        AND D_KIND = In_KIND AND D_ACC in ( 'A03000' )  
      )
      LOOP
        INSERT INTO ROA_PST001_MONTH_DATA
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND, STR06 ,STR01, REC1.AMOUNT);                 
      END LOOP;

  --(3-22) --------  
      STR01 :=  'C_BV2_A_32';
      STR02 :=  In_YYYY || '01';
      for REC1 IN (
        SELECT ( SUM( D_AMOUNT ) / In_MM2 )  AMOUNT
        FROM ROA_PST001_MONTH_DATA
        WHERE PERIOD >= STR02 and  PERIOD <= In_PERIOD
        AND D_KIND = In_KIND AND D_ACC in ( 'A03200' )
      )
      LOOP
        INSERT INTO ROA_PST001_MONTH_DATA
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND, STR06 ,STR01, REC1.AMOUNT);                 
      END LOOP;

  --(3-23) --------  
      STR01 :=  'C_BV2_A_34';
      STR02 :=  In_YYYY || '01';
      for REC1 IN (
        SELECT ( SUM( D_AMOUNT ) / In_MM2 )  AMOUNT
        FROM ROA_PST001_MONTH_DATA
        WHERE PERIOD >= STR02 and  PERIOD <= In_PERIOD
        AND D_KIND = In_KIND AND D_ACC in ( 'A03400' )  
      )
      LOOP
        INSERT INTO ROA_PST001_MONTH_DATA
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND, STR06 ,STR01, REC1.AMOUNT);                 
      END LOOP;


  --(3-24) --------  
      STR01 :=  'C_BV2_A_36';
      STR02 :=  In_YYYY || '01';
      for REC1 IN (
        SELECT ( SUM( D_AMOUNT ) / In_MM2 )  AMOUNT
        FROM ROA_PST001_MONTH_DATA
        WHERE PERIOD >= STR02 and  PERIOD <= In_PERIOD
        AND D_KIND = In_KIND AND D_ACC in ( 'A03600' )  
      )
      LOOP
        INSERT INTO ROA_PST001_MONTH_DATA
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND, STR06 ,STR01, REC1.AMOUNT);                 
      END LOOP;

  --(3-25) --------  
      STR01 :=  'C_BV2_A_38';
      STR02 :=  In_YYYY || '01';
      for REC1 IN (
        SELECT  ( SUM( D_AMOUNT ) / In_MM2 )  AMOUNT
        FROM ROA_PST001_MONTH_DATA
        WHERE PERIOD >= STR02 and  PERIOD <= In_PERIOD
        AND D_KIND = In_KIND AND D_ACC in ( 'A03800' )  
      )
      LOOP
        INSERT INTO ROA_PST001_MONTH_DATA
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND, STR06 ,STR01, REC1.AMOUNT);                 
      END LOOP;
  
  
  
  END IF;

  

END ROA_PLS008_CAL_MONTH_DATA;
/

