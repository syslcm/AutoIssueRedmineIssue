create PROCEDURE "VRT_PLSQL_DDR_TEMP_Q2"
IS

   /*
    每月執行一次
    1. 抓 VRT_PDM_DDR_DATA 資料
    2. Insert to VRT_MAP030_SUMMARY_GRAD
    create by susan
   */

  vPERCENTAGE_L1             VRT_MAP020_RATE_INDEX.PERCENTAGE%TYPE;
  vPERCENTAGE_L2             VRT_MAP020_RATE_INDEX.PERCENTAGE%TYPE;
  vPERCENTAGE_L3             VRT_MAP020_RATE_INDEX.PERCENTAGE%TYPE;
  vPERCENTAGE_L4             VRT_MAP020_RATE_INDEX.PERCENTAGE%TYPE;
  iTracePoint                varchar2(100);
  cErrorText                 varchar2(500);
  vPROCEE_YYYYMMDD           varchar2(8);
  vPROCEE_YYYYMM             varchar2(6);
  vSCORE                     VRT_MAP040_RANGE_SCORE.SCORES%TYPE;

BEGIN
    --抓上個月份
    iTracePoint := '100';
--        vPROCEE_YYYYMM := TO_CHAR(ADD_MONTHS(SYSDATE, -3), 'YYYYMM');
--        vPROCEE_YYYYMMDD  :=  to_char(sysdate,'YYYYMMDD');



 --抓各階分數
  iTracePoint := '500';
  vPERCENTAGE_L1 := null;
  vPERCENTAGE_L2 := null;
  vPERCENTAGE_L3 := null;
  vPERCENTAGE_L4 := null;

  for REC1 in ( select LEVEL_S, PERCENTAGE from VRT_MAP020_RATE_INDEX
                 where INDEX_KEY = 'QUALITY' and TYPE = 'QB' ) loop
    if REC1.LEVEL_S = 'L1' then
      iTracePoint := '510';
      vPERCENTAGE_L1 := REC1.PERCENTAGE;
    elsif REC1.LEVEL_S = 'L2' then
      iTracePoint := '520';
      vPERCENTAGE_L2 := REC1.PERCENTAGE;
    elsif REC1.LEVEL_S = 'L3' then
      iTracePoint := '530';
      vPERCENTAGE_L3 := REC1.PERCENTAGE;
    elsif REC1.LEVEL_S = 'L4' then
      iTracePoint := '540';
      vPERCENTAGE_L4 := REC1.PERCENTAGE;
    end if;
  end loop;

  if vPERCENTAGE_L1 is null or vPERCENTAGE_L2 is null or vPERCENTAGE_L3 is null or vPERCENTAGE_L4 is null then
    --若沒抓到資料則寄 error mail
    iTracePoint := '550';
    cErrorText := 'vPERCENTAGE_L1 is ' || nvl(to_char(vPERCENTAGE_L1),'null') || ',vPERCENTAGE_L2 is ' || nvl(to_char(vPERCENTAGE_L2),'null') || ',vPERCENTAGE_L3 is ' || nvl(to_char(vPERCENTAGE_L3),'null') || ',vPERCENTAGE_L4 is ' || nvl(to_char(vPERCENTAGE_L4),'null');
    MAIL_FILE_BIDBDBADMIN(in_to_name => 'shuchin@ms.usi.com.tw', subject => '[VRT] PL/SQL VRT_PLSQL_DDR_TEMP ERROR', message => '[VRT_MAP020_RATE_INDEX ], The tracepoint is  ' || iTracePoint || ' and ErrorText= ' || cErrorText) ;
  else
    --先清舊的資料以避免重覆(All Site)
    iTracePoint := '560-' || vPROCEE_YYYYMM;
--    delete from VRT_MAP030_SUMMARY_GRAD
--     where TYPE = 'QB' and YYYY = substr(vPROCEE_YYYYMM,1,4) and MM = substr(vPROCEE_YYYYMM,5,2);
--    commit;


    --放入上月分數
    iTracePoint := '600';
    for REC1 in ( select a.SITE,  a.VENDOR_CODE, (Substr(a.YYYYMM,1,4)) as P_YEAR, (Substr(a.YYYYMM,5,2)) as P_MONTH,  b.QUARTER,  a.COMPANY_CODE, a.SCORE
                         from VRT_PDM_DDR_DATA a, DIMENSION_DATE b
						 where ( a.YYYYMM = '200704' OR
						         a.YYYYMM = '200705' OR
							     a.YYYYMM = '200706' )
							    AND
                               ( a.YYYYMM || '01' ) = b.DATE_KEY
                    group by a.SITE,  a.VENDOR_CODE, (Substr(a.YYYYMM,1,4)), (Substr(a.YYYYMM,5,2)),  b.QUARTER,  a.COMPANY_CODE, a.SCORE
                         ) loop


    --放到 VRT_MAP030_SUMMARY_GRAD
      iTracePoint := '700-' || REC1.SITE || '-' || REC1.VENDOR_CODE || '-' ||  SUBSTRB(vPROCEE_YYYYMM,1,6);
      insert into VRT_MAP030_SUMMARY_GRAD (
             SITE, LIFNR, TYPE, YYYY, MM, QUARTER, BUKRS, L1, GRADE_L1, L2, GRADE_L2, L3, GRADE_L3, L4, GRADE_L4
           ) values (
             REC1.SITE,
             REC1.VENDOR_CODE,
          --   REC1.PTYPE,
		     'QB',
             REC1.P_YEAR,
             REC1.P_MONTH,
             REC1.QUARTER,
             REC1.COMPANY_CODE,
             'S0',
             round(REC1.SCORE * vPERCENTAGE_L1, 5),
             'Q0',
             round(REC1.SCORE * vPERCENTAGE_L2, 5),
             'QB',
             round(REC1.SCORE * vPERCENTAGE_L3, 5),
             'QB',
             round(REC1.SCORE * vPERCENTAGE_L4, 5)
           );
      commit;
    end loop;
  end if;


EXCEPTION
  When OTHERS Then
    --有錯誤產生則寄mail
    cErrorText := SQLERRM();
    MAIL_FILE_BIDBDBADMIN(in_to_name => 'shuchin@ms.usi.com.tw', subject => '[VRT] VRT_PLSQL_DDR_TEMP ERROR', message => '[VRT_MAP030_SUMMARY_GRAD], The tracepoint is  ' || iTracePoint || ' and ErrorText= ' || cErrorText) ;

END VRT_PLSQL_DDR_TEMP_Q2;
/

