create PROCEDURE PLSQL_DCF_RPT_WEEKLY_LOA_1 (
  outRES OUT VARCHAR2
)
AUTHID DEFINER
is
  --SAP inforecord and RFQ not exist
  CURSOR C_SAP_INFOREC1 is
    Select distinct
          A.PART_NO, A.VENDOR_CODE, A.INCOTERM, A.LOCATION, A.UNIT_PRICE, A.CURRENCY,
          B.IBM_PN, B.IBM_VENDOR_NO, B.COUNCIL_NAME, B.COMMODITY, B.IBM_PART_DESC,
          B.IBM_VENDOR, B.IBM_LAST_QUOTA, B.IBM_QUOTA, B.IBM_CONTRACT, B.CONTRACT_START,
          B.CONTRACT_END, B.IBM_LAST_PRICE, B.LAST_PRICE_DATE, B.IBM_PRICE, B.IBM_CURRENCY,
          B.PRICE_START, B.PRICE_END, B.IBM_LAST_LT, B.IBM_LT, B.IBM_MOQ, B.VENDOR_MULT, B.CUSTOMER,
          SUBSTRB(C.VENDOR_NAME,1,20) as VENDOR_NAME1
     From SAP_INFOREC A, DCF_IBM_LOA_CURRENT B, PLD_KPI_VENDOR_MASTER C
    --where A.PART_NO like B.USI_PN_LIKE || '%'
    where TRIM(SUBSTRB(A.PART_NO,1,7)) = TRIM(B.USI_PN_LIKE)
      and NOT EXISTS (
	    Select D.USI_PN from DCF_USI_RFQ D
		 where D.USI_PN = A.PART_NO
		   and D.USI_VENDOR_NO = A.VENDOR_CODE
      )
      and A.COMPANY_CODE = '1100'
      and A.INFO_CATEGORY = '0'
      and A.VENDOR_CODE = C.VENDOR_ID
      and C.COMPANY_CODE = '1100'
      and ( A.DELE_FLAG is NULL or A.DELE_FLAG = '' );

  --SAP inforecord and RFQ exist
  CURSOR C_SAP_INFOREC2 is
    Select distinct
          A.PART_NO, A.VENDOR_CODE, A.INCOTERM, A.LOCATION, A.UNIT_PRICE, A.CURRENCY,
          B.IBM_PN, B.IBM_VENDOR_NO, B.IBM_PRICE, B.IBM_CURRENCY, B.CUSTOMER
     From SAP_INFOREC A, DCF_IBM_LOA_CURRENT B
    --where A.PART_NO like B.USI_PN_LIKE || '%'
    where TRIM(SUBSTRB(A.PART_NO,1,7)) = TRIM(B.USI_PN_LIKE)
      and EXISTS (
	    Select C.USI_PN from DCF_USI_RFQ C
		 where C.USI_PN = A.PART_NO
		   and C.USI_VENDOR_NO = A.VENDOR_CODE
      )
      and A.COMPANY_CODE = '1100'
      and A.INFO_CATEGORY = '0'
      and ( A.DELE_FLAG is NULL or A.DELE_FLAG = '' );

   nCOUNT              NUMBER(5);
   nQTA_DIFF           DCF_RPT_WEEKLY_LOA.QTA_DIFF%TYPE;
   nPRICE_DISCREPANCY  DCF_RPT_WEEKLY_LOA.PRICE_DISCREPANCY%TYPE;
   nLT_DIFF            DCF_RPT_WEEKLY_LOA.LT_DIFF%TYPE;
   nUSI_CURRENCY       DCF_USI_RFQ.USI_CURRENCY%TYPE;

 BEGIN
   outRES := 'START';
   --SAP inforecord and RFQ not exist
   nCOUNT := 0;
   FOR REC1 in C_SAP_INFOREC1 LOOP
     outRES := 'C_SAP_INFOREC1:' || REC1.CUSTOMER || '<>' || REC1.IBM_PN || '<>' || REC1.PART_NO || '<>' || REC1.IBM_VENDOR_NO || '<>' || REC1.VENDOR_CODE;
     If ( REC1.IBM_LAST_QUOTA is NULL ) or ( REC1.IBM_LAST_QUOTA = REC1.IBM_QUOTA ) Then
       nQTA_DIFF := 'NO';
     Else
       nQTA_DIFF := 'YES';
     End If;
     If REC1.IBM_LAST_PRICE is NULL Then
       nPRICE_DISCREPANCY := 0;
     Else
       nPRICE_DISCREPANCY := NVL(REC1.IBM_PRICE,0) - NVL(REC1.IBM_LAST_PRICE,0);
     End If;
     If REC1.IBM_LAST_LT is NULL Then
       nLT_DIFF := 0;
     Else
       nLT_DIFF := NVL(REC1.IBM_LT,0) - NVL(REC1.IBM_LAST_LT,0);
     End If;
     Insert into DCF_RPT_WEEKLY_LOA ( IBM_PN, USI_PN, COUNCIL_NAME, COMMODITY, IBM_PART_DESC,
                                      IBM_VENDOR, IBM_LAST_QUOTA, IBM_QUOTA, QTA_DIFF, IBM_VENDOR_NO,
                                      IBM_CONTRACT, CONTRACT_START, CONTRACT_END, USI_CURRENCY, USI_PRICE,
                                      USI_VENDOR_NO, USI_VENDOR_NAME, IBM_LAST_PRICE, LAST_PRICE_DATE, IBM_PRICE,
                                      IBM_CURRENCY, PRICE_START, PRICE_END, PRICE_DISCREPANCY,
                                      IBM_LAST_LT, IBM_LT, LT_DIFF, IBM_MOQ, VENDOR_MULT,
                                      INCOTERM, LOCATION, CUSTOMER )
          values ( REC1.IBM_PN, REC1.PART_NO, REC1.COUNCIL_NAME, REC1.COMMODITY, REC1.IBM_PART_DESC,
                   REC1.IBM_VENDOR, REC1.IBM_LAST_QUOTA, REC1.IBM_QUOTA, nQTA_DIFF, REC1.IBM_VENDOR_NO,
                   REC1.IBM_CONTRACT, REC1.CONTRACT_START, REC1.CONTRACT_END, REC1.CURRENCY, REC1.UNIT_PRICE,
                   REC1.VENDOR_CODE, REC1.VENDOR_NAME1, REC1.IBM_LAST_PRICE, REC1.LAST_PRICE_DATE, REC1.IBM_PRICE,
                   REC1.IBM_CURRENCY, REC1.PRICE_START, REC1.PRICE_END, nPRICE_DISCREPANCY,
                   REC1.IBM_LAST_LT, REC1.IBM_LT, nLT_DIFF, REC1.IBM_MOQ, REC1.VENDOR_MULT,
                   REC1.INCOTERM, REC1.LOCATION, REC1.CUSTOMER );
     Commit;
   END LOOP;
   outRES := 'INSERT C_SAP_INFOREC1 OK';

   --SAP inforecord and RFQ exist
   nCOUNT := 0;
   FOR REC1 in C_SAP_INFOREC2 LOOP
     outRES := 'C_SAP_INFOREC2:' || REC1.CUSTOMER || '<>' || REC1.IBM_PN || '<>' || REC1.PART_NO || '<>' || REC1.IBM_VENDOR_NO || '<>' || REC1.VENDOR_CODE;
     --Check RFQ Price exist or not
     nUSI_CURRENCY := Null;
     BEGIN
       Select * into nUSI_CURRENCY From (
         Select USI_CURRENCY from DCF_RPT_WEEKLY_LOA
          where IBM_PN = REC1.IBM_PN
            and USI_PN = REC1.PART_NO
            and IBM_VENDOR_NO = REC1.IBM_VENDOR_NO
            and USI_VENDOR_NO = REC1.VENDOR_CODE
            and CUSTOMER = REC1.CUSTOMER
       ) Where ROWNUM <= 1;
     EXCEPTION
       WHEN OTHERS THEN
         nUSI_CURRENCY := Null;
     END;
     If nUSI_CURRENCY is Null Then
       Update DCF_RPT_WEEKLY_LOA set USI_CURRENCY = REC1.CURRENCY,
                                     USI_PRICE = REC1.UNIT_PRICE,
                                     INCOTERM = REC1.INCOTERM,
                                     LOCATION = REC1.LOCATION
                               where IBM_PN = REC1.IBM_PN
                                 and USI_PN = REC1.PART_NO
                                 and IBM_VENDOR_NO = REC1.IBM_VENDOR_NO
                                 and USI_VENDOR_NO = REC1.VENDOR_CODE
                                 and CUSTOMER = REC1.CUSTOMER;
     Else
       Update DCF_RPT_WEEKLY_LOA set INCOTERM = REC1.INCOTERM,
                                     LOCATION = REC1.LOCATION
                               where IBM_PN = REC1.IBM_PN
                                 and USI_PN = REC1.PART_NO
                                 and IBM_VENDOR_NO = REC1.IBM_VENDOR_NO
                                 and USI_VENDOR_NO = REC1.VENDOR_CODE
                                 and CUSTOMER = REC1.CUSTOMER;
     End If;
     Commit;
   END LOOP;

   outRES := 'SUCCESS';
 EXCEPTION
   WHEN OTHERS THEN
     outRES := TRIM(outRES) || ' - ' || TRIM(SUBSTR(SQLERRM,1,100));
     Rollback;
 END PLSQL_DCF_RPT_WEEKLY_LOA_1;
/

