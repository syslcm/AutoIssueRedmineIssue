create PROCEDURE test_pls1_insert (p_array_size IN PLS_INTEGER DEFAULT 100)
IS
   type row_type is table of KPI_SAP001_COPA_TRX%rowtype index by binary_integer;
   rows row_type;
   CURSOR cur1 IS SELECT * from KPI_SAP001_COPA_TRX where period like '201201' ;
 begin
    OPEN cur1;
    LOOP
         FETCH cur1 BULK COLLECT INTO rows limit p_array_size;
         FORALL i IN 1..rows.COUNT
              INSERT INTO T1 VALUES rows(i);
    EXIT WHEN cur1%NOTFOUND;
    END LOOP;
    CLOSE cur1;
END test_pls1_insert;
/

