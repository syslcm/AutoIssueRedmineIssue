create PROCEDURE         "PLSQL_PLD_KPI_CR_CURR_SUM_UPD" (
  inCompany  in VARCHAR2,
  f_YYYYMMDD in VARCHAR2,
  t_YYYYMMDD in VARCHAR2
)
/***********************************************************************
  PROG-ID      : PLSQL_PLD_KPI_CR_CURR_SUM_UPD
  PROG-ACTION  : CREATE Quarter u-price in PLD_KPI_CR_LAST_YEAR_Q4
                 ALSO UPDATE BASE_PRICE IN PLD_KPI_CR_CURR_IR_SUM 
  Author       : KATHY
  Date         : 2008/01/02
  UPDATE Date  : 2010/02/08
-------------------------------------------------------------------------------------------
--Run PLSQL WITH table:KPI_SAP017_ZB027_DATA_T (SEQ-06)
---- 2010/02/08 add BASE_PRICE_Q
-------------------------------------------------------------------------------------------
*/
--***********************************************************************
AUTHID DEFINER
is

  iFind_Flag   integer ;          ----1=>find , 0=>dosen't find
  iBP_found    char(1) ;
  iS_Period    char(2) ;
  iE_Period    char(2) ;
  iLAST_Y_Q4   char(6) ;          ---- 2010/02/08 add
  iCURR_Y_Q1   char(6) ;          ---- 2010/02/08 add
  iCURR_Y_Q2   char(6) ;          ---- 2010/02/08 add
  iCURR_Y_Q3   char(6) ;          ---- 2010/02/08 add
  iCURR_Q      char(6) ;          ---- 2010/02/08 add
  iM_AMT PLD_KPI_CR_CURR_IR_SUM.MONTH_AMT%TYPE ;
  iM_QTY PLD_KPI_CR_CURR_IR_SUM.MONTH_QTY%TYPE ;
  iLAST_Y_Q4_AMT PLD_KPI_CR_LAST_YEAR_Q4.LAST_Y_Q4_AMT%TYPE ;
  iLAST_Y_Q4_QTY PLD_KPI_CR_LAST_YEAR_Q4.LAST_Y_Q4_QTY%TYPE ;
  iCURR_Y_Q1_AMT PLD_KPI_CR_LAST_YEAR_Q4.CURR_Y_Q1_AMT%TYPE ;
  iCURR_Y_Q1_QTY PLD_KPI_CR_LAST_YEAR_Q4.CURR_Y_Q1_QTY%TYPE ; 
  iCURR_Y_Q2_AMT PLD_KPI_CR_LAST_YEAR_Q4.CURR_Y_Q2_AMT%TYPE ;
  iCURR_Y_Q2_QTY PLD_KPI_CR_LAST_YEAR_Q4.CURR_Y_Q2_QTY%TYPE ;
  iCURR_Y_Q3_AMT PLD_KPI_CR_LAST_YEAR_Q4.CURR_Y_Q3_AMT%TYPE ;
  iCURR_Y_Q3_QTY PLD_KPI_CR_LAST_YEAR_Q4.CURR_Y_Q3_QTY%TYPE ;
--
  iM_AMT_USD PLD_KPI_CR_CURR_IR_SUM.MONTH_AMT_USD%TYPE ;
  iLAST_Y_Q4_AMT_USD PLD_KPI_CR_LAST_YEAR_Q4.LAST_Y_Q4_AMT_USD%TYPE ;
  iCURR_Y_Q1_AMT_USD PLD_KPI_CR_LAST_YEAR_Q4.CURR_Y_Q1_AMT_USD%TYPE ;
  iCURR_Y_Q2_AMT_USD PLD_KPI_CR_LAST_YEAR_Q4.CURR_Y_Q2_AMT_USD%TYPE ;
  iCURR_Y_Q3_AMT_USD PLD_KPI_CR_LAST_YEAR_Q4.CURR_Y_Q3_AMT_USD%TYPE ;



  CURSOR C_PLD_KPI_CR_LAST_YEAR_Q4_COM1 is
     SELECT YYYY, PART_NO, SUM(MONTH_AMT) AS TT_AMT, SUM(MONTH_QTY) AS TT_QTY,
                           SUM(MONTH_AMT_USD) AS TT_AMT_USD
       FROM PLD_KPI_CR_CURR_IR_SUM
      WHERE YYYY||MM >= to_char(Add_months(to_date(t_YYYYMMDD,'YYYYMMDD'),-12),'YYYY')||'10'
        AND YYYY||MM <= to_char(Add_months(to_date(t_YYYYMMDD,'YYYYMMDD'),-12),'YYYY')||'12'
      GROUP BY YYYY, PART_NO  ;

  CURSOR C_PLD_KPI_CR_CURR_YEAR_Q1_COM1 is
     SELECT YYYY, PART_NO, SUM(MONTH_AMT) AS TT_AMT, SUM(MONTH_QTY) AS TT_QTY,
                           SUM(MONTH_AMT_USD) AS TT_AMT_USD
       FROM PLD_KPI_CR_CURR_IR_SUM
      WHERE YYYY||MM >= to_char(to_date(t_YYYYMMDD,'YYYYMMDD'),'YYYY')||'01'
        AND YYYY||MM <= to_char(to_date(t_YYYYMMDD,'YYYYMMDD'),'YYYY')||'03'
      GROUP BY YYYY, PART_NO  ;

  CURSOR C_PLD_KPI_CR_CURR_YEAR_Q2_COM1 is
     SELECT YYYY, PART_NO, SUM(MONTH_AMT) AS TT_AMT, SUM(MONTH_QTY) AS TT_QTY,
                           SUM(MONTH_AMT_USD) AS TT_AMT_USD
       FROM PLD_KPI_CR_CURR_IR_SUM
      WHERE YYYY||MM >= to_char(to_date(t_YYYYMMDD,'YYYYMMDD'),'YYYY')||'04'
        AND YYYY||MM <= to_char(to_date(t_YYYYMMDD,'YYYYMMDD'),'YYYY')||'06'
      GROUP BY YYYY, PART_NO  ;

  CURSOR C_PLD_KPI_CR_CURR_YEAR_Q3_COM1 is
     SELECT YYYY, PART_NO, SUM(MONTH_AMT) AS TT_AMT, SUM(MONTH_QTY) AS TT_QTY,
                           SUM(MONTH_AMT_USD) AS TT_AMT_USD
       FROM PLD_KPI_CR_CURR_IR_SUM
      WHERE YYYY||MM >= to_char(to_date(t_YYYYMMDD,'YYYYMMDD'),'YYYY')||'07'
        AND YYYY||MM <= to_char(to_date(t_YYYYMMDD,'YYYYMMDD'),'YYYY')||'09'
      GROUP BY YYYY, PART_NO  ;

  CURSOR C_PLD_KPI_MONTH_BASE_COM1 is
      SELECT YYYY, MM, PART_NO
      FROM PLD_KPI_CR_CURR_IR_SUM
      WHERE YYYY||MM = SUBSTRB(f_YYYYMMDD,1,6);

  CURSOR C_PLD_KPI_MONTH_BASE_COM2 is
      SELECT YYYY, MM, PART_NO
      FROM PLD_KPI_CR_CURR_IR_SUM
      WHERE YYYY||MM = SUBSTRB(t_YYYYMMDD,1,6);

---=========================================================================================
begin

-- 產生 BASE_PRICE_Q - 2010/02/08
   iLAST_Y_Q4 := to_char(Add_months(to_date(t_YYYYMMDD,'YYYYMMDD'),-12),'YYYY') || 'Q4';
   iCURR_Y_Q1 := to_char(to_date(t_YYYYMMDD,'YYYYMMDD'),'YYYY')||'Q1';
   iCURR_Y_Q2 := to_char(to_date(t_YYYYMMDD,'YYYYMMDD'),'YYYY')||'Q2';
   iCURR_Y_Q3 := to_char(to_date(t_YYYYMMDD,'YYYYMMDD'),'YYYY')||'Q3';
   IF SUBSTRB(t_YYYYMMDD,5,2) >= '01' OR SUBSTRB(t_YYYYMMDD,5,2) <= '03' THEN
      iCURR_Q := to_char(to_date(t_YYYYMMDD,'YYYYMMDD'),'YYYY')||'Q1';
   ELSE
      IF SUBSTRB(t_YYYYMMDD,5,2) >= '04' OR SUBSTRB(t_YYYYMMDD,5,2) <= '06' THEN
         iCURR_Q := to_char(to_date(t_YYYYMMDD,'YYYYMMDD'),'YYYY')||'Q2';
      ELSE
         IF SUBSTRB(t_YYYYMMDD,5,2) >= '07' OR SUBSTRB(t_YYYYMMDD,5,2) <= '09' THEN
            iCURR_Q := to_char(to_date(t_YYYYMMDD,'YYYYMMDD'),'YYYY')||'Q3';
         ELSE
            iCURR_Q := to_char(to_date(t_YYYYMMDD,'YYYYMMDD'),'YYYY')||'Q4';
         END IF;
      END IF;
   END IF;

---*********************************************************************************
-- 若截止月為1月, 則計算去年Q4單價, 更新 PLD_KPI_CR_LAST_YEAR_Q4 LastYear-Q4的單價.
---*********************************************************************************
   iBP_found := 'N';
-- (1)先將舊的資料清為0:
   IF SUBSTRB(t_YYYYMMDD,1,4) >= '2007' AND SUBSTRB(t_YYYYMMDD,5,2) = '01' THEN
      Update PLD_KPI_CR_LAST_YEAR_Q4
         Set LAST_Y_Q4_AMT = 0,
             LAST_Y_Q4_QTY = 0,
             LAST_Y_Q4_AMT_USD = 0
        Where YYYY = SUBSTRB(t_YYYYMMDD,1,4);
      Commit;

-- (2)再更新新的去年Q4單價資料:
      FOR REC1 in C_PLD_KPI_CR_LAST_YEAR_Q4_COM1 Loop
         iFind_Flag :=0 ;
         BEGIN
           SELECT COUNT(*) INTO iFind_Flag FROM PLD_KPI_CR_LAST_YEAR_Q4
           WHERE YYYY = SUBSTRB(t_YYYYMMDD,1,4)
             AND PART_NO = REC1.PART_NO;
           EXCEPTION
                 WHEN OTHERS THEN
                 NULL  ;
         END ;
------若該 P/N 已存在, 作更新:
         IF iFind_Flag > 0 THEN
            Update PLD_KPI_CR_LAST_YEAR_Q4
               Set LAST_Y_Q4_AMT = REC1.TT_AMT,
                   LAST_Y_Q4_QTY = REC1.TT_QTY,
                   LAST_Y_Q4_AMT_USD = REC1.TT_AMT_USD
             Where YYYY = SUBSTRB(t_YYYYMMDD,1,4)
               AND PART_NO = REC1.PART_NO;
            Commit;
         ELSE
------不存在, 作新增:
            Insert into PLD_KPI_CR_LAST_YEAR_Q4 (
                   YYYY, PART_NO, LAST_Y_Q4_AMT, LAST_Y_Q4_QTY, CREATE_DATE,
                   CURR_Y_Q1_AMT, CURR_Y_Q1_QTY, CURR_Y_Q2_AMT, CURR_Y_Q2_QTY,
                   CURR_Y_Q3_AMT, CURR_Y_Q3_QTY, LAST_Y_Q4_AMT_USD,
                   CURR_Y_Q1_AMT_USD, CURR_Y_Q2_AMT_USD, CURR_Y_Q3_AMT_USD
            )
            SELECT SUBSTRB(t_YYYYMMDD,1,4), REC1.PART_NO, REC1.TT_AMT, REC1.TT_QTY,
                   to_char(SYSDATE,'YYYYMMDD'), 0, 0, 0, 0, 0, 0,
                   REC1.TT_AMT_USD, 0, 0, 0
            FROM DUAL;
            Commit;
         END IF;
      END LOOP;
   END IF;
---*********************************************************************************
-- 若截止月為4月, 則計算今年Q1單價, 更新 PLD_KPI_CR_LAST_YEAR_Q4 CURR_Y_Q1的單價.
---*********************************************************************************
-- (1)先將舊的資料清為0:
   IF SUBSTRB(t_YYYYMMDD,1,4) >= '2007' AND SUBSTRB(t_YYYYMMDD,5,2) = '04' THEN
      Update PLD_KPI_CR_LAST_YEAR_Q4
         Set CURR_Y_Q1_AMT = 0,
             CURR_Y_Q1_QTY = 0,
             CURR_Y_Q1_AMT_USD = 0
        Where YYYY = SUBSTRB(t_YYYYMMDD,1,4);
      Commit;

-- (2)再更新新的今年Q1單價資料:
      FOR REC1 in C_PLD_KPI_CR_CURR_YEAR_Q1_COM1 Loop
         iFind_Flag :=0 ;
         BEGIN
           SELECT COUNT(*) INTO iFind_Flag FROM PLD_KPI_CR_LAST_YEAR_Q4
           WHERE YYYY = SUBSTRB(t_YYYYMMDD,1,4)
             AND PART_NO = REC1.PART_NO;
           EXCEPTION
                 WHEN OTHERS THEN
                 NULL  ;
         END ;
------若該 P/N 已存在, 作更新:
         IF iFind_Flag > 0 THEN
            Update PLD_KPI_CR_LAST_YEAR_Q4
               Set CURR_Y_Q1_AMT = REC1.TT_AMT,
                   CURR_Y_Q1_QTY = REC1.TT_QTY,
                   CURR_Y_Q1_AMT_USD = REC1.TT_AMT_USD
             Where YYYY = SUBSTRB(t_YYYYMMDD,1,4)
               AND PART_NO = REC1.PART_NO;
            Commit;
         ELSE
------不存在, 作新增:
            Insert into PLD_KPI_CR_LAST_YEAR_Q4 (
                   YYYY, PART_NO, LAST_Y_Q4_AMT, LAST_Y_Q4_QTY, CREATE_DATE,
                   CURR_Y_Q1_AMT, CURR_Y_Q1_QTY, CURR_Y_Q2_AMT, CURR_Y_Q2_QTY,
                   CURR_Y_Q3_AMT, CURR_Y_Q3_QTY, LAST_Y_Q4_AMT_USD,
                   CURR_Y_Q1_AMT_USD, CURR_Y_Q2_AMT_USD, CURR_Y_Q3_AMT_USD
            )
            SELECT SUBSTRB(t_YYYYMMDD,1,4), REC1.PART_NO, 0, 0,
                   to_char(SYSDATE,'YYYYMMDD'), REC1.TT_AMT, REC1.TT_QTY, 0, 0, 0, 0,
                   0, REC1.TT_AMT_USD, 0, 0
            FROM DUAL;
            Commit;
         END IF;
      END LOOP;
   END IF;
---*********************************************************************************
-- 若截止月為7月, 則計算今年Q2單價, 更新 PLD_KPI_CR_LAST_YEAR_Q4 CURR_Y_Q2的單價.
---*********************************************************************************
-- (1)先將舊的資料清為0:
   IF SUBSTRB(t_YYYYMMDD,1,4) >= '2007' AND SUBSTRB(t_YYYYMMDD,5,2) = '07' THEN
      Update PLD_KPI_CR_LAST_YEAR_Q4
         Set CURR_Y_Q2_AMT = 0,
             CURR_Y_Q2_QTY = 0,
             CURR_Y_Q2_AMT_USD = 0
        Where YYYY = SUBSTRB(t_YYYYMMDD,1,4);
      Commit;

-- (2)再更新新的今年Q2單價資料:
      FOR REC1 in C_PLD_KPI_CR_CURR_YEAR_Q2_COM1 Loop
         iFind_Flag :=0 ;
         BEGIN
           SELECT COUNT(*) INTO iFind_Flag FROM PLD_KPI_CR_LAST_YEAR_Q4
           WHERE YYYY = SUBSTRB(t_YYYYMMDD,1,4)
             AND PART_NO = REC1.PART_NO;
           EXCEPTION
                 WHEN OTHERS THEN
                 NULL  ;
         END ;
------若該 P/N 已存在, 作更新:
         IF iFind_Flag > 0 THEN
            Update PLD_KPI_CR_LAST_YEAR_Q4
               Set CURR_Y_Q2_AMT = REC1.TT_AMT,
                   CURR_Y_Q2_QTY = REC1.TT_QTY,
                   CURR_Y_Q2_AMT_USD = REC1.TT_AMT_USD
             Where YYYY = SUBSTRB(t_YYYYMMDD,1,4)
               AND PART_NO = REC1.PART_NO;
            Commit;
         ELSE
------不存在, 作新增:
            Insert into PLD_KPI_CR_LAST_YEAR_Q4 (
                   YYYY, PART_NO, LAST_Y_Q4_AMT, LAST_Y_Q4_QTY, CREATE_DATE,
                   CURR_Y_Q1_AMT, CURR_Y_Q1_QTY, CURR_Y_Q2_AMT, CURR_Y_Q2_QTY,
                   CURR_Y_Q3_AMT, CURR_Y_Q3_QTY, LAST_Y_Q4_AMT_USD,
                   CURR_Y_Q1_AMT_USD, CURR_Y_Q2_AMT_USD, CURR_Y_Q3_AMT_USD
            )
            SELECT SUBSTRB(t_YYYYMMDD,1,4), REC1.PART_NO, 0, 0,
                   to_char(SYSDATE,'YYYYMMDD'), 0, 0, REC1.TT_AMT, REC1.TT_QTY, 0, 0,
                   0, 0, REC1.TT_AMT_USD, 0
            FROM DUAL;
            Commit;
         END IF;
      END LOOP;
   END IF;
---*********************************************************************************
-- 若截止月為10月, 則計算今年Q3單價, 更新 PLD_KPI_CR_LAST_YEAR_Q4 CURR_Y_Q3的單價.
---*********************************************************************************
-- (1)先將舊的資料清為0:
   IF SUBSTRB(t_YYYYMMDD,1,4) >= '2007' AND SUBSTRB(t_YYYYMMDD,5,2) = '10' THEN
      Update PLD_KPI_CR_LAST_YEAR_Q4
         Set CURR_Y_Q3_AMT = 0,
             CURR_Y_Q3_QTY = 0,
             CURR_Y_Q3_AMT_USD = 0
        Where YYYY = SUBSTRB(t_YYYYMMDD,1,4);
      Commit;

-- (2)再更新新的今年Q3單價資料:
      FOR REC1 in C_PLD_KPI_CR_CURR_YEAR_Q3_COM1 Loop
         iFind_Flag :=0 ;
         BEGIN
           SELECT COUNT(*) INTO iFind_Flag FROM PLD_KPI_CR_LAST_YEAR_Q4
           WHERE YYYY = SUBSTRB(t_YYYYMMDD,1,4)
             AND PART_NO = REC1.PART_NO;
           EXCEPTION
                 WHEN OTHERS THEN
                 NULL  ;
         END ;
------若該 P/N 已存在, 作更新:
         IF iFind_Flag > 0 THEN
            Update PLD_KPI_CR_LAST_YEAR_Q4
               Set CURR_Y_Q3_AMT = REC1.TT_AMT,
                   CURR_Y_Q3_QTY = REC1.TT_QTY,
                   CURR_Y_Q3_AMT_USD = REC1.TT_AMT_USD
             Where YYYY = SUBSTRB(t_YYYYMMDD,1,4)
               AND PART_NO = REC1.PART_NO;
            Commit;
         ELSE
------不存在, 作新增:
            Insert into PLD_KPI_CR_LAST_YEAR_Q4 (
                   YYYY, PART_NO, LAST_Y_Q4_AMT, LAST_Y_Q4_QTY, CREATE_DATE,
                   CURR_Y_Q1_AMT, CURR_Y_Q1_QTY, CURR_Y_Q2_AMT, CURR_Y_Q2_QTY,
                   CURR_Y_Q3_AMT, CURR_Y_Q3_QTY, LAST_Y_Q4_AMT_USD,
                   CURR_Y_Q1_AMT_USD, CURR_Y_Q2_AMT_USD, CURR_Y_Q3_AMT_USD
            )
            SELECT SUBSTRB(t_YYYYMMDD,1,4), REC1.PART_NO, 0, 0,
                   to_char(SYSDATE,'YYYYMMDD'), 0, 0, 0, 0, REC1.TT_AMT, REC1.TT_QTY,
                   0, 0, 0, REC1.TT_AMT_USD
            FROM DUAL;
            Commit;
         END IF;
      END LOOP;
   END IF;

---***********************************************************************************
-- 計算 f_YYYYMM 當月 BASE-PRICE IN PLD_KPI_CR_CURR_IR_SUM :
---***********************************************************************************
-- (1)先讀去年Q4單價 FROM PLD_KPI_CR_LAST_YEAR_Q4,
--    若資料存在:
--      (A)若 LAST_Y_Q4_AMT<>0 且 LAST_Y_Q4_QTY<>0, 則 BASE_PRICE=LAST_Y_Q4_AMT / LAST_Y_Q4_QTY
--      (B)若 REC1.MM > '03', CURR_Y_Q1_AMT<>0 且 CURR_Y_Q1_QTY<>0, 則 BASE_PRICE=CURR_Y_Q1_AMT / CURR_Y_Q1_QTY
--      (C)若 REC1.MM > '06', CURR_Y_Q2_AMT<>0 且 CURR_Y_Q2_QTY<>0, 則 BASE_PRICE=CURR_Y_Q2_AMT / CURR_Y_Q2_QTY
--      (D)若 REC1.MM > '09', CURR_Y_Q3_AMT<>0 且 CURR_Y_Q3_QTY<>0, 則 BASE_PRICE=CURR_Y_Q3_AMT / CURR_Y_Q3_QTY
----
      FOR REC1 in C_PLD_KPI_MONTH_BASE_COM1 Loop
         iBP_found := 'N';
-----     先以當月作一次update
--          Update PLD_KPI_CR_CURR_IR_SUM
--             Set BASE_PRICE = MONTH_AMT / MONTH_QTY,
--                 BASE_PRICE_USD = MONTH_AMT_USD / MONTH_QTY,
--                 BASE_PRICE_Q = iLAST_Y_Q4                     --- 2010/02/08 add
--           Where YYYY = REC1.YYYY
--             AND MM = REC1.MM
--             AND PART_NO = REC1.PART_NO
--             AND MONTH_QTY <> 0 ;
--          Commit;
-----
         iFind_Flag :=0 ;
         BEGIN
           SELECT COUNT(*) INTO iFind_Flag FROM PLD_KPI_CR_LAST_YEAR_Q4
           WHERE YYYY = REC1.YYYY
             AND PART_NO = REC1.PART_NO;
           EXCEPTION
                 WHEN OTHERS THEN
                 NULL  ;
         END ;
------若去年Q4資料存在, 作單價更新:
         IF iFind_Flag > 0 THEN
            BEGIN
              SELECT LAST_Y_Q4_AMT,  LAST_Y_Q4_QTY,  CURR_Y_Q1_AMT,  CURR_Y_Q1_QTY,
                     CURR_Y_Q2_AMT,  CURR_Y_Q2_QTY,  CURR_Y_Q3_AMT,  CURR_Y_Q3_QTY,
                     LAST_Y_Q4_AMT_USD, CURR_Y_Q1_AMT_USD, CURR_Y_Q2_AMT_USD, CURR_Y_Q3_AMT_USD 
                INTO iLAST_Y_Q4_AMT, iLAST_Y_Q4_QTY, iCURR_Y_Q1_AMT, iCURR_Y_Q1_QTY,
                     iCURR_Y_Q2_AMT, iCURR_Y_Q2_QTY, iCURR_Y_Q3_AMT, iCURR_Y_Q3_QTY,
                     iLAST_Y_Q4_AMT_USD, iCURR_Y_Q1_AMT_USD, iCURR_Y_Q2_AMT_USD, iCURR_Y_Q3_AMT_USD 
                FROM PLD_KPI_CR_LAST_YEAR_Q4
               WHERE YYYY = REC1.YYYY
                 AND PART_NO = REC1.PART_NO;
            END ;
            IF iLAST_Y_Q4_AMT<>0 AND iLAST_Y_Q4_QTY<>0 THEN
               Update PLD_KPI_CR_CURR_IR_SUM
                  Set BASE_PRICE = iLAST_Y_Q4_AMT / iLAST_Y_Q4_QTY,
                      BASE_PRICE_USD = iLAST_Y_Q4_AMT_USD / iLAST_Y_Q4_QTY,
                      BASE_PRICE_Q = iLAST_Y_Q4                              --- 2010/02/08 add
                Where YYYY = REC1.YYYY
                  AND MM = REC1.MM
                  AND PART_NO = REC1.PART_NO;
               Commit;
               iBP_found := 'Y';
            ELSE
               IF REC1.MM > '03' AND iCURR_Y_Q1_AMT<>0 AND iCURR_Y_Q1_QTY<>0 THEN
                  Update PLD_KPI_CR_CURR_IR_SUM
                     Set BASE_PRICE = iCURR_Y_Q1_AMT / iCURR_Y_Q1_QTY,
                         BASE_PRICE_USD = iCURR_Y_Q1_AMT_USD / iCURR_Y_Q1_QTY,
                         BASE_PRICE_Q = iCURR_Y_Q1                              --- 2010/02/08 add
                   Where YYYY = REC1.YYYY
                     AND MM = REC1.MM
                     AND PART_NO = REC1.PART_NO;
                  Commit;
                  iBP_found := 'Y';
               ELSE
                  IF REC1.MM > '06' AND iCURR_Y_Q2_AMT<>0 AND iCURR_Y_Q2_QTY<>0 THEN
                     Update PLD_KPI_CR_CURR_IR_SUM
                        Set BASE_PRICE = iCURR_Y_Q2_AMT / iCURR_Y_Q2_QTY,
                            BASE_PRICE_USD = iCURR_Y_Q2_AMT_USD / iCURR_Y_Q2_QTY,
                            BASE_PRICE_Q = iCURR_Y_Q2                              --- 2010/02/08 add
                      Where YYYY = REC1.YYYY
                        AND MM = REC1.MM
                        AND PART_NO = REC1.PART_NO;
                     Commit;
                     iBP_found := 'Y';
                  ELSE
                     IF REC1.MM > '09' AND iCURR_Y_Q3_AMT<>0 AND iCURR_Y_Q3_QTY<>0 THEN
                        Update PLD_KPI_CR_CURR_IR_SUM
                           Set BASE_PRICE = iCURR_Y_Q3_AMT / iCURR_Y_Q3_QTY,
                               BASE_PRICE_USD = iCURR_Y_Q3_AMT_USD / iCURR_Y_Q3_QTY,
                               BASE_PRICE_Q = iCURR_Y_Q3                              --- 2010/02/08 add
                         Where YYYY = REC1.YYYY
                           AND MM = REC1.MM
                           AND PART_NO = REC1.PART_NO;
                        Commit;
                        iBP_found := 'Y';
                     END IF;
                  END IF;
               END IF;
            END IF;
         END IF;

------不存在:
 -- (2)若無去年Q4單價, 則判斷目前各月資料:
--    IR_DATE(5,2)='01', iS_Period = '01', iE_Period = '01'.
--    IR_DATE(5,2)='02', iS_Period = '01', iE_Period = '01'.
--    IR_DATE(5,2)='03', iS_Period = '01', iE_Period = '02'.
--    IR_DATE(5,2)='04', iS_Period = '04', iE_Period = '04'.
--    IR_DATE(5,2)='05', iS_Period = '04', iE_Period = '04'.
--    IR_DATE(5,2)='06', iS_Period = '04', iE_Period = '05'.
--    IR_DATE(5,2)='07', iS_Period = '07', iE_Period = '07'.
--    IR_DATE(5,2)='08', iS_Period = '07', iE_Period = '07'.
--    IR_DATE(5,2)='09', iS_Period = '07', iE_Period = '08'.
--    IR_DATE(5,2)='10', iS_Period = '10', iE_Period = '10'.
--    IR_DATE(5,2)='11', iS_Period = '10', iE_Period = '10'.
--    IR_DATE(5,2)='12', iS_Period = '10', iE_Period = '11'.
--    讀PLD_KPI_CR_CURR_IR_SUM起迄期間之金額及數量合計,
--    (A)若存在 BASE_PRICE=合計的金額/數量.
--    (B)否則   BASE_PRICE=本月的金額/數量.
----
         IF iBP_found = 'N'  THEN
           IF REC1.MM = '01' THEN
               iS_Period :='01' ;
               iE_Period :='01' ;
            END IF;

            IF REC1.MM = '02' THEN
               iS_Period :='01' ;
               iE_Period :='01' ;
            END IF;

            IF REC1.MM = '03' THEN
               iS_Period :='01' ;
               iE_Period :='02' ;
            END IF;

            IF REC1.MM = '04' THEN
               iS_Period :='04' ;
               iE_Period :='04' ;
            END IF;

            IF REC1.MM = '05' THEN
               iS_Period :='04' ;
               iE_Period :='04' ;
            END IF;

            IF REC1.MM = '06' THEN
               iS_Period :='04' ;
               iE_Period :='05' ;
            END IF;

            IF REC1.MM = '07' THEN
               iS_Period :='07' ;
               iE_Period :='07' ;
            END IF;

            IF REC1.MM = '08' THEN
               iS_Period :='07' ;
               iE_Period :='07' ;
            END IF;

            IF REC1.MM = '09' THEN
               iS_Period :='07' ;
               iE_Period :='08' ;
            END IF;

            IF REC1.MM = '10' THEN
               iS_Period :='10' ;
               iE_Period :='10' ;
            END IF;

            IF REC1.MM = '11' THEN
               iS_Period :='10' ;
               iE_Period :='10' ;
            END IF;

            IF REC1.MM = '12' THEN
               iS_Period :='10' ;
               iE_Period :='11' ;
            END IF;

            iFind_Flag :=0 ;
            BEGIN
              SELECT COUNT(*) INTO iFind_Flag FROM PLD_KPI_CR_CURR_IR_SUM
              WHERE YYYY = REC1.YYYY
                AND MM  >= iS_Period
                AND MM  <= iE_Period
                AND PART_NO = REC1.PART_NO
                AND MONTH_AMT <> 0
                AND MONTH_QTY <> 0 ;
              EXCEPTION
                    WHEN OTHERS THEN
                    NULL  ;
            END ;
            IF iFind_Flag > 0 THEN
               BEGIN
                  SELECT SUM( MONTH_AMT ), SUM( MONTH_QTY ), SUM( MONTH_AMT_USD )
                    INTO iM_AMT, iM_QTY, iM_AMT_USD
                    FROM PLD_KPI_CR_CURR_IR_SUM
                   WHERE YYYY = REC1.YYYY
                     AND MM  >= iS_Period
                     AND MM  <= iE_Period
                     AND PART_NO = REC1.PART_NO
                     AND MONTH_AMT <> 0
                     AND MONTH_QTY <> 0 ;
               END ;
               IF iM_QTY <> 0 THEN
                  Update PLD_KPI_CR_CURR_IR_SUM
                     Set BASE_PRICE = iM_AMT / iM_QTY,
                         BASE_PRICE_USD = iM_AMT_USD / iM_QTY,
                         BASE_PRICE_Q = iCURR_Q                           --- 2010/02/08 add @@@@
                   Where YYYY = REC1.YYYY
                     AND MM = REC1.MM
                     AND PART_NO = REC1.PART_NO;
                  Commit;
               END IF;
            ELSE
               Update PLD_KPI_CR_CURR_IR_SUM
                  Set BASE_PRICE = MONTH_AMT / MONTH_QTY,
                      BASE_PRICE_USD = MONTH_AMT_USD / MONTH_QTY,
                      BASE_PRICE_Q = iCURR_Q                              --- 2010/02/08 add @@@@
                Where YYYY = REC1.YYYY
                  AND MM = REC1.MM
                  AND PART_NO = REC1.PART_NO
                  AND MONTH_QTY <> 0 ;
               Commit;
            END IF;
         END IF;
      END LOOP;
---***********************************************************************************
-- 計算 t_YYYYMM 當月 BASE-PRICE IN PLD_KPI_CR_CURR_IR_SUM :
---***********************************************************************************
-- (1)先讀去年Q4單價 FROM PLD_KPI_CR_LAST_YEAR_Q4,
--    若資料存在:
--      (A)若 LAST_Y_Q4_AMT<>0 且 LAST_Y_Q4_QTY<>0, 則 BASE_PRICE=LAST_Y_Q4_AMT / LAST_Y_Q4_QTY
--      (B)若 REC1.MM > '03', CURR_Y_Q1_AMT<>0 且 CURR_Y_Q1_QTY<>0, 則 BASE_PRICE=CURR_Y_Q1_AMT / CURR_Y_Q1_QTY
--      (C)若 REC1.MM > '06', CURR_Y_Q2_AMT<>0 且 CURR_Y_Q2_QTY<>0, 則 BASE_PRICE=CURR_Y_Q2_AMT / CURR_Y_Q2_QTY
--      (D)若 REC1.MM > '09', CURR_Y_Q3_AMT<>0 且 CURR_Y_Q3_QTY<>0, 則 BASE_PRICE=CURR_Y_Q3_AMT / CURR_Y_Q3_QTY
----
----
---
      FOR REC1 in C_PLD_KPI_MONTH_BASE_COM2 Loop
         iBP_found := 'N';
-----    先以當月作一次update
--          Update PLD_KPI_CR_CURR_IR_SUM,
--             Set BASE_PRICE = MONTH_AMT / MONTH_QTY,
--                 BASE_PRICE_USD = MONTH_AMT_USD / MONTH_QTY,
--                 BASE_PRICE_Q = iCURR_Q
--           Where YYYY = REC1.YYYY
--             AND MM = REC1.MM
--             AND PART_NO = REC1.PART_NO
--             AND MONTH_QTY <> 0 ;
--          Commit;
-----
         iFind_Flag :=0 ;
         BEGIN
           SELECT COUNT(*) INTO iFind_Flag FROM PLD_KPI_CR_LAST_YEAR_Q4
           WHERE YYYY = REC1.YYYY
             AND PART_NO = REC1.PART_NO;
           EXCEPTION
                 WHEN OTHERS THEN
                 NULL  ;
         END ;
------若去年Q4資料存在, 作單價更新:
         IF iFind_Flag > 0 THEN
            BEGIN

              SELECT LAST_Y_Q4_AMT,  LAST_Y_Q4_QTY,  CURR_Y_Q1_AMT,  CURR_Y_Q1_QTY,
                     CURR_Y_Q2_AMT,  CURR_Y_Q2_QTY,  CURR_Y_Q3_AMT,  CURR_Y_Q3_QTY,
                     LAST_Y_Q4_AMT_USD, CURR_Y_Q1_AMT_USD, CURR_Y_Q2_AMT_USD, CURR_Y_Q3_AMT_USD 
                INTO iLAST_Y_Q4_AMT, iLAST_Y_Q4_QTY, iCURR_Y_Q1_AMT, iCURR_Y_Q1_QTY,
                     iCURR_Y_Q2_AMT, iCURR_Y_Q2_QTY, iCURR_Y_Q3_AMT, iCURR_Y_Q3_QTY,
                     iLAST_Y_Q4_AMT_USD, iCURR_Y_Q1_AMT_USD, iCURR_Y_Q2_AMT_USD, iCURR_Y_Q3_AMT_USD 
                FROM PLD_KPI_CR_LAST_YEAR_Q4
               WHERE YYYY = REC1.YYYY
                 AND PART_NO = REC1.PART_NO;
            END ;
            IF iLAST_Y_Q4_AMT<>0 AND iLAST_Y_Q4_QTY<>0 THEN
               iBP_found := 'Y';
               Update PLD_KPI_CR_CURR_IR_SUM
                  Set BASE_PRICE = iLAST_Y_Q4_AMT / iLAST_Y_Q4_QTY,
                      BASE_PRICE_USD = iLAST_Y_Q4_AMT_USD / iLAST_Y_Q4_QTY,
                      BASE_PRICE_Q = iLAST_Y_Q4                              --- 2010/02/08 add
                Where YYYY = REC1.YYYY
                  AND MM = REC1.MM
                  AND PART_NO = REC1.PART_NO;
               Commit;
            ELSE
               IF REC1.MM > '03' AND iCURR_Y_Q1_AMT<>0 AND iCURR_Y_Q1_QTY<>0 THEN
                  iBP_found := 'Y';
                  Update PLD_KPI_CR_CURR_IR_SUM
                     Set BASE_PRICE = iCURR_Y_Q1_AMT / iCURR_Y_Q1_QTY,
                         BASE_PRICE_USD = iCURR_Y_Q1_AMT_USD / iCURR_Y_Q1_QTY,
                         BASE_PRICE_Q = iCURR_Y_Q1                              --- 2010/02/08 add
                   Where YYYY = REC1.YYYY
                     AND MM = REC1.MM
                     AND PART_NO = REC1.PART_NO;
                  Commit;
               ELSE
                  IF REC1.MM > '06' AND iCURR_Y_Q2_AMT<>0 AND iCURR_Y_Q2_QTY<>0 THEN
                     iBP_found := 'Y';
                     Update PLD_KPI_CR_CURR_IR_SUM
                        Set BASE_PRICE = iCURR_Y_Q2_AMT / iCURR_Y_Q2_QTY,
                            BASE_PRICE_USD = iCURR_Y_Q2_AMT_USD / iCURR_Y_Q2_QTY,
                            BASE_PRICE_Q = iCURR_Y_Q2                           --- 2010/02/08 add
                      Where YYYY = REC1.YYYY
                        AND MM = REC1.MM
                        AND PART_NO = REC1.PART_NO;
                     Commit;
                  ELSE
                     IF REC1.MM > '09' AND iCURR_Y_Q3_AMT<>0 AND iCURR_Y_Q3_QTY<>0 THEN
                        iBP_found := 'Y';
                        Update PLD_KPI_CR_CURR_IR_SUM
                           Set BASE_PRICE = iCURR_Y_Q3_AMT / iCURR_Y_Q3_QTY,
                               BASE_PRICE_USD = iCURR_Y_Q3_AMT_USD / iCURR_Y_Q3_QTY,
                               BASE_PRICE_Q = iCURR_Y_Q3                        --- 2010/02/08 add
                         Where YYYY = REC1.YYYY
                           AND MM = REC1.MM
                           AND PART_NO = REC1.PART_NO;
                        Commit;
                      END IF;
                  END IF;
               END IF;
            END IF;
         ELSE
            iBP_found := 'N';
         END IF;
------不存在:
 -- (2)若無去年Q4單價, 則判斷目前各月資料:
--    IR_DATE(5,2)='01', iS_Period = '01', iE_Period = '01'.
--    IR_DATE(5,2)='02', iS_Period = '01', iE_Period = '01'.
--    IR_DATE(5,2)='03', iS_Period = '01', iE_Period = '02'.
--    IR_DATE(5,2)='04', iS_Period = '04', iE_Period = '04'.
--    IR_DATE(5,2)='05', iS_Period = '04', iE_Period = '04'.
--    IR_DATE(5,2)='06', iS_Period = '04', iE_Period = '05'.
--    IR_DATE(5,2)='07', iS_Period = '07', iE_Period = '07'.
--    IR_DATE(5,2)='08', iS_Period = '07', iE_Period = '07'.
--    IR_DATE(5,2)='09', iS_Period = '07', iE_Period = '08'.
--    IR_DATE(5,2)='10', iS_Period = '10', iE_Period = '10'.
--    IR_DATE(5,2)='11', iS_Period = '10', iE_Period = '10'.
--    IR_DATE(5,2)='12', iS_Period = '10', iE_Period = '11'.
--    讀PLD_KPI_CR_CURR_IR_SUM起迄期間之金額及數量合計,
--    (A)若存在 BASE_PRICE=合計的金額/數量.
--    (B)否則   BASE_PRICE=本月的金額/數量.
----
         IF iBP_found = 'N'  THEN
            IF REC1.MM = '01' THEN
               iS_Period :='01' ;
               iE_Period :='01' ;
            END IF;

            IF REC1.MM = '02' THEN
               iS_Period :='01' ;
               iE_Period :='01' ;
            END IF;

            IF REC1.MM = '03' THEN
               iS_Period :='01' ;
               iE_Period :='02' ;
            END IF;

            IF REC1.MM = '04' THEN
               iS_Period :='04' ;
               iE_Period :='04' ;
            END IF;

            IF REC1.MM = '05' THEN
               iS_Period :='04' ;
               iE_Period :='04' ;
            END IF;

            IF REC1.MM = '06' THEN
               iS_Period :='04' ;
               iE_Period :='05' ;
            END IF;

            IF REC1.MM = '07' THEN
               iS_Period :='07' ;
               iE_Period :='07' ;
            END IF;

            IF REC1.MM = '08' THEN
               iS_Period :='07' ;
               iE_Period :='07' ;
            END IF;

            IF REC1.MM = '09' THEN
               iS_Period :='07' ;
               iE_Period :='08' ;
            END IF;

            IF REC1.MM = '10' THEN
               iS_Period :='10' ;
               iE_Period :='10' ;
            END IF;

            IF REC1.MM = '11' THEN
               iS_Period :='10' ;
               iE_Period :='10' ;
            END IF;

            IF REC1.MM = '12' THEN
               iS_Period :='10' ;
               iE_Period :='11' ;
            END IF;

            iFind_Flag :=0 ;
            BEGIN
              SELECT COUNT(*) INTO iFind_Flag FROM PLD_KPI_CR_CURR_IR_SUM
              WHERE YYYY = REC1.YYYY
                AND MM  >= iS_Period
                AND MM  <= iE_Period
                AND PART_NO = REC1.PART_NO
                AND MONTH_AMT <> 0
                AND MONTH_QTY <> 0 ;
              EXCEPTION
                    WHEN OTHERS THEN
                    NULL  ;
            END ;
            IF iFind_Flag > 0 THEN
               BEGIN
                  SELECT SUM( MONTH_AMT ), SUM( MONTH_QTY ), SUM( MONTH_AMT_USD )
                    INTO iM_AMT, iM_QTY, iM_AMT_USD
                    FROM PLD_KPI_CR_CURR_IR_SUM
                   WHERE YYYY = REC1.YYYY
                     AND MM  >= iS_Period
                     AND MM  <= iE_Period
                     AND PART_NO = REC1.PART_NO
                     AND MONTH_AMT <> 0
                     AND MONTH_QTY <> 0 ;
               END ;
               IF iM_QTY <> 0 THEN
                  Update PLD_KPI_CR_CURR_IR_SUM
                     Set BASE_PRICE = iM_AMT / iM_QTY,
                         BASE_PRICE_USD = iM_AMT_USD / iM_QTY,
                         BASE_PRICE_Q = iCURR_Q                              --- 2010/02/08 add @@@@
                   Where YYYY = REC1.YYYY
                     AND MM = REC1.MM
                     AND PART_NO = REC1.PART_NO;
                  Commit;
                  iBP_found := 'Y';
               ELSE
                  Update PLD_KPI_CR_CURR_IR_SUM
                     Set BASE_PRICE = MONTH_AMT / MONTH_QTY,
                         BASE_PRICE_USD = MONTH_AMT_USD / MONTH_QTY,
                         BASE_PRICE_Q = iCURR_Q                              --- 2010/02/08 add @@@@
                   Where YYYY = REC1.YYYY
                     AND MM = REC1.MM
                     AND PART_NO = REC1.PART_NO
                     AND MONTH_QTY <> 0 ;
                  Commit;
                  iBP_found := 'Y';
               END IF;
            ELSE
               Update PLD_KPI_CR_CURR_IR_SUM
                  Set BASE_PRICE = MONTH_AMT / MONTH_QTY,
                      BASE_PRICE_USD = MONTH_AMT_USD / MONTH_QTY,
                         BASE_PRICE_Q = iCURR_Q                              --- 2010/02/08 add @@@@
                Where YYYY = REC1.YYYY
                  AND MM = REC1.MM
                  AND PART_NO = REC1.PART_NO
                  AND MONTH_QTY <> 0 ;
               Commit;
               iBP_found := 'Y';
            END IF;
         END IF;
         IF iBP_found = 'N'  THEN
            Update PLD_KPI_CR_CURR_IR_SUM
               Set BASE_PRICE = MONTH_AMT / MONTH_QTY,
                   BASE_PRICE_USD = MONTH_AMT_USD / MONTH_QTY,
                         BASE_PRICE_Q = iCURR_Q                              --- 2010/02/08 add @@@@
             Where YYYY = REC1.YYYY
               AND MM = REC1.MM
               AND PART_NO = REC1.PART_NO
               AND MONTH_QTY <> 0 ;
            Commit;
            iBP_found := 'Y';
         END IF;
      END LOOP;

end PLSQL_PLD_KPI_CR_CURR_SUM_UPD;
/

