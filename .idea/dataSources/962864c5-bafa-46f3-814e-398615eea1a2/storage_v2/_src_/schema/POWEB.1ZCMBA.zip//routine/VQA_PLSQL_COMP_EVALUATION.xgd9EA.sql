create PROCEDURE "VQA_PLSQL_COMP_EVALUATION"
IS
   /*--------------------------------------------------------------*
      CREATE DATE:  2008/02/25
      PLSQL      :  VQA_PLSQL_COMP_EVALUATION
      Author     :  Shuya
      Purpase    :  Calculate component evaluation By Daily ？   *---------------------------------------------------------------*/
   vvendor_code       vqa_010_irr_weekly_t.vendor_code%TYPE;
   vcompany_code      vqa_010_irr_weekly_t.company_code%TYPE;
   vprocee_yyyymmdd   VARCHAR2 (8);
   vprocee_yyyymm     VARCHAR2 (6);
   itracepoint        VARCHAR2 (100);
   cerrortext         VARCHAR2 (500);
   record_count       NUMBER (6, 0);
BEGIN
   --抓當月份系統日期
   itracepoint := '100';
   vprocee_yyyymmdd := TO_CHAR (SYSDATE, 'YYYYMMDD');
   vprocee_yyyymm := SUBSTRB (vprocee_yyyymmdd, 1, 6);

   SELECT COUNT (*)
     INTO record_count
     FROM vqa_avl_comp_evaluation
    WHERE yyyy = TO_CHAR (SYSDATE, 'YYYY') AND mm = TO_CHAR (SYSDATE, 'MM');

   IF record_count = '0'
   THEN
      INSERT INTO vqa_avl_comp_evaluation
         SELECT   mfr_name, mat_grp, TO_CHAR (SYSDATE, 'yyyy') AS yyyy,
                  TO_CHAR (SYSDATE, 'mm') AS mm, 'Q'||TO_CHAR (SYSDATE, 'Q') AS Quarter,
                  (SELECT COUNT (DISTINCT mfr_pn)
                     FROM vqa_pdm_pn_data
                    WHERE (   phase = 'Project Approved'
					       OR phase = 'AMPL'
                           OR phase = 'AMPL1'
                           OR phase = 'AMPL2'
                           OR phase = 'AMPL3'
                           OR phase = 'Supplier Phase Out'
						   OR phase = 'Obsolete'
                          )
                      AND mat_grp = a.mat_grp
                      AND mfr_name = a.mfr_name) AS approve_s,
                  (SELECT COUNT (DISTINCT mfr_pn)
                     FROM vqa_pdm_pn_data
                    WHERE (   phase = 'Project Approved'
					       OR phase = 'AMPL'
                           OR phase = 'AMPL1'
                           OR phase = 'AMPL2'
                           OR phase = 'AMPL3'
                           OR phase = 'Supplier Phase Out'
						   OR phase = 'Obsolete'
                          )
                      AND mat_grp = a.mat_grp
                      AND mfr_name = a.mfr_name) AS approve_e,
                  '0',
                  (SELECT COUNT (DISTINCT mfr_pn)
                     FROM vqa_pdm_pn_data
                    WHERE ( phase = 'Disqualify'
                          )
                      AND mat_grp = a.mat_grp
                      AND mfr_name = a.mfr_name) AS disquality_s,
                  (SELECT COUNT (DISTINCT mfr_pn)
                     FROM vqa_pdm_pn_data
                    WHERE (   phase = 'Disqualify'
                          )
                      AND mat_grp = a.mat_grp
                      AND mfr_name = a.mfr_name) AS disquality_e,
                  '0',
                  (SELECT COUNT (DISTINCT mfr_pn)
                     FROM vqa_pdm_pn_data
                    WHERE phase = 'EMS'
                      AND mat_grp = a.mat_grp
                      AND mfr_name = a.mfr_name) AS customer_assign_s,
                  (SELECT COUNT (DISTINCT mfr_pn)
                     FROM vqa_pdm_pn_data
                    WHERE phase = 'EMS'
                      AND mat_grp = a.mat_grp
                      AND mfr_name = a.mfr_name) AS customer_assign_e,
                  '0', SYSDATE
             FROM vqa_pdm_pn_data a
         GROUP BY mfr_name, mat_grp;
      COMMIT;

   ELSE
      itracepoint := 0;

      FOR rec1 IN (SELECT DISTINCT mfr_name, mat_grp
                              FROM vqa_pdm_pn_data)
      LOOP
         itracepoint := itracepoint + 1;

         UPDATE vqa_avl_comp_evaluation
            SET approve_e =
                   (SELECT COUNT (DISTINCT mfr_pn)
                      FROM vqa_pdm_pn_data
                     WHERE (   phase = 'Project Approved'
					       OR phase = 'AMPL'
                           OR phase = 'AMPL1'
                           OR phase = 'AMPL2'
                           OR phase = 'AMPL3'
                           OR phase = 'Supplier Phase Out'
						   OR phase = 'Obsolete'
                           )
                       AND mat_grp = rec1.mat_grp
                       AND mfr_name = rec1.mfr_name),
                disqualify_e =
                   (SELECT COUNT (DISTINCT mfr_pn)
                      FROM vqa_pdm_pn_data
                     WHERE (   phase = 'Disqualify'
                           )
                       AND mat_grp = rec1.mat_grp
                       AND mfr_name = rec1.mfr_name),
                customer_assign_e =
                   (SELECT COUNT (DISTINCT mfr_pn)
                      FROM vqa_pdm_pn_data
                     WHERE phase = 'EMS'
                       AND mat_grp = rec1.mat_grp
                       AND mfr_name = rec1.mfr_name),
                update_date = SYSDATE
          WHERE mfr_name = rec1.mfr_name
            AND mat_grp = rec1.mat_grp
            AND yyyy = TO_CHAR (SYSDATE, 'yyyy')
            AND mm = TO_CHAR (SYSDATE, 'mm');

         IF itracepoint MOD 500 = 0
         THEN
            COMMIT;
         END IF;
      END LOOP;

	  COMMIT;

      UPDATE vqa_avl_comp_evaluation
         SET approve_qty = approve_e - approve_s,
             disqualify_qty = disqualify_e - disqualify_s,
             customer_assign_qty = customer_assign_e - customer_assign_s
       WHERE yyyy = TO_CHAR (SYSDATE, 'yyyy') AND mm = TO_CHAR (SYSDATE, 'mm');

      COMMIT;
   END IF;


   mail_file_bidbdbadmin
              (in_to_name      => 'shuya_chen@usiglobal.com',
               subject         => '[VQA] PL/SQL VQA_PLSQL_COMP_EVALUATION Succeed',
               MESSAGE         =>    '[VQA_PLSQL_COMP_EVALUATION], The total count is  '
                                  || TO_CHAR (itracepoint)
              );
EXCEPTION
   WHEN OTHERS
   THEN
      --有錯誤產生則寄mail
      cerrortext := SQLERRM ();
      mail_file_bidbdbadmin
                  (in_to_name      => 'shuya_chen@usiglobal.com',
                   subject         => '[VQA] PL/SQL VQA_PLSQL_COMP_EVALUATION ERROR',
                   MESSAGE         =>    '[VQA_PLSQL_COMP_EVALUATION], The tracepoint is  '
                                      || itracepoint
                                      || ' and ErrorText= '
                                      || cerrortext
                  );
END vqa_plsql_comp_evaluation;
/

