create PROCEDURE PLSQL_DCF_USI_RFQ_1 (
  outRES OUT VARCHAR2
)
AUTHID DEFINER
is
  CURSOR C_RFQ_PRICE is
    Select distinct
           TRIM(PART_NO) as PART_NO1, TRIM(VENDOR_ID) as VENDOR_ID1,
           ROUND(QUOTE_PRICE,6) as QUOTE_PRICE1, TRIM(QUOTE_CURRENCY) as QUOTE_CURRENCY1,
           TRIM(TO_CHAR(QUOTE_DATE,'YYYYMMDD')) as QUOTE_DATE1
     From RFQ_PRICE
    where TO_CHAR(QUOTE_DATE,'YYYYMMDD') >= TO_CHAR(ADD_MONTHS(SYSDATE,-3),'YYYYMMDD')
      and QUOTE_PRICE > 0;

  --處理 PO_CUTIN_DATE, SHIP_CUTIN_DATE
  CURSOR C_RFQ_PRICE_2 is
    Select distinct
           A.PART_NO, A.VENDOR_ID, A.PO_CUTIN_DATE, A.SHIP_CUTIN_DATE, B.CUSTOMER, B.IBM_PN, B.IBM_VENDOR_NO
     From RFQ_PRICE A, DCF_IBM_LOA_CURRENT B
    where A.PART_NO like B.USI_PN_LIKE || '%'
      and ( A.PO_CUTIN_DATE is NOT NULL or A.SHIP_CUTIN_DATE is NOT NULL );

   nPART_NO          RFQ_PRICE.PART_NO%TYPE;
   nPO_CUTIN_DATE    DCF_USI_MANUAL.PO_CUTIN_DATE%TYPE;
   nSHIP_CUTIN_DATE  DCF_USI_MANUAL.SHIP_CUTIN_DATE%TYPE;
   nCOUNT            NUMBER(5);
 BEGIN
   outRES := 'START';

   --Delete DCF_USI_RFQ
   Delete from DCF_USI_RFQ;
   Commit;
   outRES := 'Delete DCF_USI_RFQ OK';

   nCOUNT := 0;
   FOR REC1 in C_RFQ_PRICE LOOP
     outRES := 'Ins:' || REC1.PART_NO1 || '<>' || REC1.VENDOR_ID1;
     Insert into DCF_USI_RFQ (
            USI_PN,
            USI_VENDOR_NO,
            USI_CURRENCY,
            USI_PRICE,
            PRICE_DATE
          ) values (
            REC1.PART_NO1,
            REC1.VENDOR_ID1,
            REC1.QUOTE_CURRENCY1,
            REC1.QUOTE_PRICE1,
            REC1.QUOTE_DATE1
          );
     nCOUNT := nCOUNT + 1;
     If nCOUNT = 10 Then
       nCOUNT := 0;
       Commit;
     End If;
   END LOOP;
   Commit;
   outRES := 'Update C_RFQ_PRICE OK';

   nCOUNT := 0;
   FOR REC1 in C_RFQ_PRICE_2 LOOP
     nPART_NO := Null;
     nPO_CUTIN_DATE := Null;
     nSHIP_CUTIN_DATE := Null;
     --Check exist or not
     BEGIN
       Select * into nPART_NO, nPO_CUTIN_DATE, nSHIP_CUTIN_DATE From (
         Select USI_PN, NVL(PO_CUTIN_DATE,'NVL'), NVL(SHIP_CUTIN_DATE,'NVL')
           from DCF_USI_MANUAL
          where USI_PN = REC1.PART_NO
            and USI_VENDOR_NO = REC1.VENDOR_ID
            and IBM_PN = REC1.IBM_PN
            and IBM_VENDOR_NO = REC1.IBM_VENDOR_NO
            and CUSTOMER = REC1.CUSTOMER
       ) Where ROWNUM <= 1;
     EXCEPTION
       WHEN OTHERS THEN
         nPART_NO := Null;
     END;
     If nPART_NO is NULL Then
       outRES := 'Ins_2:' || REC1.PART_NO || '<>' || REC1.VENDOR_ID;
       Insert into DCF_USI_MANUAL ( USI_PN, USI_VENDOR_NO, PO_CUTIN_DATE, SHIP_CUTIN_DATE, IBM_PN, IBM_VENDOR_NO, CUSTOMER )
            values ( REC1.PART_NO, REC1.VENDOR_ID, REC1.PO_CUTIN_DATE, REC1.SHIP_CUTIN_DATE,
                     REC1.IBM_PN, REC1.IBM_VENDOR_NO, REC1.CUSTOMER
                   );
     Else
       If nPO_CUTIN_DATE = 'NVL' and nSHIP_CUTIN_DATE = 'NVL' Then
         outRES := 'Upd_2A:' || REC1.PART_NO || '<>' || REC1.VENDOR_ID;
         Update DCF_USI_MANUAL
            set PO_CUTIN_DATE = REC1.PO_CUTIN_DATE,
                SHIP_CUTIN_DATE = REC1.SHIP_CUTIN_DATE
          where USI_PN = REC1.PART_NO
            and USI_VENDOR_NO = REC1.VENDOR_ID
            and IBM_PN = REC1.IBM_PN
            and IBM_VENDOR_NO = REC1.IBM_VENDOR_NO
            and CUSTOMER = REC1.CUSTOMER;
       ElsIf nPO_CUTIN_DATE = 'NVL' Then
         outRES := 'Upd_2A:' || REC1.PART_NO || '<>' || REC1.VENDOR_ID;
         Update DCF_USI_MANUAL
            set PO_CUTIN_DATE = REC1.PO_CUTIN_DATE
          where USI_PN = REC1.PART_NO
            and USI_VENDOR_NO = REC1.VENDOR_ID
            and IBM_PN = REC1.IBM_PN
            and IBM_VENDOR_NO = REC1.IBM_VENDOR_NO
            and CUSTOMER = REC1.CUSTOMER;
       ElsIf nSHIP_CUTIN_DATE = 'NVL' Then
         outRES := 'Upd_2A:' || REC1.PART_NO || '<>' || REC1.VENDOR_ID;
         Update DCF_USI_MANUAL
            set SHIP_CUTIN_DATE = REC1.SHIP_CUTIN_DATE
          where USI_PN = REC1.PART_NO
            and USI_VENDOR_NO = REC1.VENDOR_ID
            and IBM_PN = REC1.IBM_PN
            and IBM_VENDOR_NO = REC1.IBM_VENDOR_NO
            and CUSTOMER = REC1.CUSTOMER;
       End If;
     End If;
     nCOUNT := nCOUNT + 1;
     If nCOUNT = 10 Then
       nCOUNT := 0;
       Commit;
     End If;
   END LOOP;
   Commit;

   outRES := 'SUCCESS';
EXCEPTION
  WHEN OTHERS THEN
    outRES := TRIM(outRES) || ' - ' || TRIM(SUBSTR(SQLERRM,1,100));
    Rollback;
END PLSQL_DCF_USI_RFQ_1;
/

