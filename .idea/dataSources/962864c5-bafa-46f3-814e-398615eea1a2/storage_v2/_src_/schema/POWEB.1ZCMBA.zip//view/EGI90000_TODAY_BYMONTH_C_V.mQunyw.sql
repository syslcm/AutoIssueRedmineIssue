create view EGI90000_TODAY_BYMONTH_C_V as
SELECT a.POST_DATE_YYYYMM,a.ANALYSIS_DATE, a.CUSTOMER_NAME, a.ACTUAL_INV_AMOUNT,
       DECODE((SELECT SUM (b.COGS_AMOUNT)
          FROM EGI91140_MONTH_ACTUAL_C b
         WHERE b.customer_name = a.customer_name
           AND b.post_date_yyyymm = a.POST_DATE_YYYYMM),null,0,(SELECT SUM (b.COGS_AMOUNT)
          FROM EGI91140_MONTH_ACTUAL_C b
         WHERE b.customer_name = a.customer_name
           AND b.post_date_yyyymm = a.POST_DATE_YYYYMM)) AS COGS_AMOUNT
  FROM EGI92000_INV_SUMMARY_MONTH_C a
/

