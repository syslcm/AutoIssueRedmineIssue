create PROCEDURE       PNL3_PLS009_ADJUST_TRX ( --2008/12/30新增:註解請參考PNL2_PLS010_ADJUST_TRX
  --inCOMPANY       in VARCHAR2,
  inPeriod        in VARCHAR2
  --2008/9/17 Create to Process get Amount in Local/USD/TWD
  --Trigger by PNL2_BAD_DEPT_UPLOAD.JSP
)
AUTHID DEFINER
is
--2008/11/7 有發現  SUM(NET_REVENUE) <> 0 OR SUM(NET_COGS)  <> 0 條件成立但dm/dl/oh卻有值的戕況,因此不加入此條件
-- 在INSERT進資料庫時再排除金額=0的資料
     
     a_Rate          number(20,10);
     a_COUNTER       integer;
     --i_COUNTER       integer;
     a_ENDCUSTOMER   PNL3_TRX001_COPA.END_CUSTOMER_ID%TYPE;
     a_AMOUNT        PNL3_TRX001_COPA.AMT_LOCAL%TYPE;
     
 BEGIN
   
   DELETE FROM PNL3_TRX006_ADJUST
   WHERE Period = inPeriod;
   Commit;
    a_RATE  := 0;
    
    --已有END CUSTOMER的資料直接進db
    --2009/3/27加入十號公報,所以在PNL3_PLS005_CAT_GEN_ALL_TRX和PNL3_PLS005_CATEGORY_GEN_TRX都要判斷cogs-vvxx不等於0的金額才要入

    FOR REC1 in (SELECT * 
                    FROM PNL2_UPL007_ADJUST 
                   WHERE PERIOD = inPeriod
                     AND END_CUSTOMER_ID IS NOT NULL ) Loop


                      Insert into PNL3_TRX006_ADJUST
                    (YEAR                , MONTH             , PROFIT_CENTER      , COMPANY_CODE        , END_CUSTOMER_ID    , CUSTOMER_ID      ,
                     CURRENCY_LOCAL      , AMOUNT_LOCAL      , PERIOD             , MATERIAL_GROUP      , MATERIAL_TYPE      , MATERIAL         ,
                     SHIP_TO_PARTY       , AMOUNT_TWD        , EX_RATE_TWD        , AMOUNT_USD          , EX_RATE_USD        , CREATE_DATE      ,
                     UPLOADSITE          , PLANT_CODE        , SOURCE             , CATEGORY           , CUST_GROUP          , SEARCH_TERM      ,
                     SHIP_TO_PARTY_GROUP ,
                     VV006,VV007,VV014,VV015,VV016,VV017,VV018,VV019,
                     VV006_TWD,VV007_TWD,VV014_TWD,VV015_TWD,VV016_TWD,VV017_TWD,VV018_TWD,VV019_TWD,
                     VV006_USD,VV007_USD,VV014_USD,VV015_USD,VV016_USD,VV017_USD,VV018_USD,VV019_USD
                     )
                    Values 
                    (REC1.YEAR           , REC1.MONTH        , REC1.PROFIT_CENTER , REC1.COMPANY_CODE   , REC1.END_CUSTOMER_ID    , REC1.CUSTOMER_ID ,
                     REC1.CURRENCY_LOCAL , REC1.AMOUNT_LOCAL , REC1.PERIOD        , REC1.MATERIAL_GROUP , REC1.MATERIAL_TYPE , REC1.MATERIAL    , 
                     REC1.SHIP_TO_PARTY  , REC1.AMOUNT_TWD   , REC1.EX_RATE_TWD   , REC1.AMOUNT_USD     , REC1.EX_RATE_USD   , SYSDATE          ,
                     REC1.UPLOADSITE     , REC1.PLANT_CODE   , REC1.SOURCE        , REC1.CATEGORY       , REC1.CUST_GROUP    , REC1.SEARCH_TERM ,
                     REC1.SHIP_TO_PARTY_GROUP,
                     REC1.VV006,REC1.VV007,REC1.VV014,REC1.VV015,REC1.VV016,REC1.VV017,REC1.VV018,REC1.VV019,
                     REC1.VV006_TWD,REC1.VV007_TWD,REC1.VV014_TWD,REC1.VV015_TWD,REC1.VV016_TWD,REC1.VV017_TWD,REC1.VV018_TWD,REC1.VV019_TWD,
                     REC1.VV006_USD,REC1.VV007_USD,REC1.VV014_USD,REC1.VV015_USD,REC1.VV016_USD,REC1.VV017_USD,REC1.VV018_USD,REC1.VV019_USD
                     );
                COMMIT;

    END LOOP;
    
     FOR REC1 in (SELECT * 
                    FROM PNL2_UPL007_ADJUST 
                   WHERE PERIOD = inPeriod
                     AND END_CUSTOMER_ID IS NULL ) Loop
        
            --HAVING ( SUM(NET_REVENUE) <> 0 OR SUM(NET_COGS)  <> 0 )
           a_ENDCUSTOMER := NULL;
           a_RATE := 1;
           IF REC1.PROFIT_CENTER = '0000000034' THEN
               a_ENDCUSTOMER := 'UABIT''S CUST';
               Insert into PNL3_TRX006_ADJUST
                    (YEAR                , MONTH             , PROFIT_CENTER      , COMPANY_CODE        , END_CUSTOMER_ID    , CUSTOMER_ID      ,
                     CURRENCY_LOCAL      , AMOUNT_LOCAL      , PERIOD             , MATERIAL_GROUP      , MATERIAL_TYPE      , MATERIAL         ,
                     SHIP_TO_PARTY       , AMOUNT_TWD        , EX_RATE_TWD        , AMOUNT_USD          , EX_RATE_USD        , CREATE_DATE      ,
                     UPLOADSITE          , PLANT_CODE        , SOURCE             , CATEGORY           , CUST_GROUP          , SEARCH_TERM      ,
                     SHIP_TO_PARTY_GROUP ,
                     VV006,VV007,VV014,VV015,VV016,VV017,VV018,VV019,
                     VV006_TWD,VV007_TWD,VV014_TWD,VV015_TWD,VV016_TWD,VV017_TWD,VV018_TWD,VV019_TWD,
                     VV006_USD,VV007_USD,VV014_USD,VV015_USD,VV016_USD,VV017_USD,VV018_USD,VV019_USD
                     )
                    Values 
                    (REC1.YEAR           , REC1.MONTH        , REC1.PROFIT_CENTER , REC1.COMPANY_CODE   , a_ENDCUSTOMER      , REC1.CUSTOMER_ID ,
                     REC1.CURRENCY_LOCAL , REC1.AMOUNT_LOCAL , REC1.PERIOD        , REC1.MATERIAL_GROUP , REC1.MATERIAL_TYPE , REC1.MATERIAL    , 
                     REC1.SHIP_TO_PARTY  , REC1.AMOUNT_TWD   , REC1.EX_RATE_TWD   , REC1.AMOUNT_USD     , REC1.EX_RATE_USD   , SYSDATE          ,
                     REC1.UPLOADSITE     , REC1.PLANT_CODE   , REC1.SOURCE        , REC1.CATEGORY       , REC1.CUST_GROUP    , REC1.SEARCH_TERM ,
                     REC1.SHIP_TO_PARTY_GROUP,
                     REC1.VV006,REC1.VV007,REC1.VV014,REC1.VV015,REC1.VV016,REC1.VV017,REC1.VV018,REC1.VV019,
                     REC1.VV006_TWD,REC1.VV007_TWD,REC1.VV014_TWD,REC1.VV015_TWD,REC1.VV016_TWD,REC1.VV017_TWD,REC1.VV018_TWD,REC1.VV019_TWD,
                     REC1.VV006_USD,REC1.VV007_USD,REC1.VV014_USD,REC1.VV015_USD,REC1.VV016_USD,REC1.VV017_USD,REC1.VV018_USD,REC1.VV019_USD
                     );
                COMMIT;
                    
                    
           ELSIF SUBSTR(REC1.PROFIT_CENTER,1,9) = '000000009' THEN
             IF  SUBSTR(REC1.COMPANY_CODE,1,1) = '9' THEN
               a_ENDCUSTOMER := '投資公司';
               Insert into PNL3_TRX006_ADJUST
                    (YEAR                , MONTH             , PROFIT_CENTER      , COMPANY_CODE        , END_CUSTOMER_ID    , CUSTOMER_ID      ,
                     CURRENCY_LOCAL      , AMOUNT_LOCAL      , PERIOD             , MATERIAL_GROUP      , MATERIAL_TYPE      , MATERIAL         ,
                     SHIP_TO_PARTY       , AMOUNT_TWD        , EX_RATE_TWD        , AMOUNT_USD          , EX_RATE_USD        , CREATE_DATE      ,
                     UPLOADSITE          , PLANT_CODE        , SOURCE             , CATEGORY           , CUST_GROUP          , SEARCH_TERM      ,
                     SHIP_TO_PARTY_GROUP ,
                     VV006,VV007,VV014,VV015,VV016,VV017,VV018,VV019,
                     VV006_TWD,VV007_TWD,VV014_TWD,VV015_TWD,VV016_TWD,VV017_TWD,VV018_TWD,VV019_TWD,
                     VV006_USD,VV007_USD,VV014_USD,VV015_USD,VV016_USD,VV017_USD,VV018_USD,VV019_USD
                     )
                    Values 
                    (REC1.YEAR           , REC1.MONTH        , REC1.PROFIT_CENTER , REC1.COMPANY_CODE   , a_ENDCUSTOMER      , REC1.CUSTOMER_ID ,
                     REC1.CURRENCY_LOCAL , REC1.AMOUNT_LOCAL , REC1.PERIOD        , REC1.MATERIAL_GROUP , REC1.MATERIAL_TYPE , REC1.MATERIAL    , 
                     REC1.SHIP_TO_PARTY  , REC1.AMOUNT_TWD   , REC1.EX_RATE_TWD   , REC1.AMOUNT_USD     , REC1.EX_RATE_USD   , SYSDATE          ,
                     REC1.UPLOADSITE     , REC1.PLANT_CODE   , REC1.SOURCE        , REC1.CATEGORY       , REC1.CUST_GROUP    , REC1.SEARCH_TERM ,
                     REC1.SHIP_TO_PARTY_GROUP,
                     REC1.VV006,REC1.VV007,REC1.VV014,REC1.VV015,REC1.VV016,REC1.VV017,REC1.VV018,REC1.VV019,
                     REC1.VV006_TWD,REC1.VV007_TWD,REC1.VV014_TWD,REC1.VV015_TWD,REC1.VV016_TWD,REC1.VV017_TWD,REC1.VV018_TWD,REC1.VV019_TWD,
                     REC1.VV006_USD,REC1.VV007_USD,REC1.VV014_USD,REC1.VV015_USD,REC1.VV016_USD,REC1.VV017_USD,REC1.VV018_USD,REC1.VV019_USD
                     );
                COMMIT;
             ELSE
               a_COUNTER := 0;
               FOR REC2 IN (SELECT END_CUSTOMER_ID,RATE 
                           FROM PNL3_MAP001_CUSTOMER_RATE 
                          WHERE R_KIND = 'PL01'  --隨便抓一筆來用,反正匯率都一樣
                            AND AREA1  = '4'
                            AND AREA2  = '1'
                            AND AREA3  = '1'
                          --AND COMPANY_CODE = REC1.COMPANY_CODE
                            AND PROFIT_CENTER = REC1.PROFIT_CENTER
                            AND PERIOD = inPeriod) LOOP
                            a_RATE := REC2.RATE;
                            a_ENDCUSTOMER := REC2.END_CUSTOMER_ID;
                            a_COUNTER := 1;
                 Insert into PNL3_TRX006_ADJUST
                    (YEAR                , MONTH             , PROFIT_CENTER      , COMPANY_CODE        , END_CUSTOMER_ID    , CUSTOMER_ID      ,
                     CURRENCY_LOCAL      , AMOUNT_LOCAL      , PERIOD             , MATERIAL_GROUP      , MATERIAL_TYPE      , MATERIAL         ,
                     SHIP_TO_PARTY       , AMOUNT_TWD        , EX_RATE_TWD        , AMOUNT_USD          , EX_RATE_USD        , CREATE_DATE      ,
                     UPLOADSITE          , PLANT_CODE        , SOURCE             , CATEGORY           , CUST_GROUP          , SEARCH_TERM      ,
                     SHIP_TO_PARTY_GROUP ,
                     VV006,VV007,VV014,VV015,VV016,VV017,VV018,VV019,
                     VV006_TWD,VV007_TWD,VV014_TWD,VV015_TWD,VV016_TWD,VV017_TWD,VV018_TWD,VV019_TWD,
                     VV006_USD,VV007_USD,VV014_USD,VV015_USD,VV016_USD,VV017_USD,VV018_USD,VV019_USD
                     )
                    Values 
                    (REC1.YEAR           , REC1.MONTH        , REC1.PROFIT_CENTER , REC1.COMPANY_CODE   , a_ENDCUSTOMER      , REC1.CUSTOMER_ID ,
                     REC1.CURRENCY_LOCAL , ROUND(REC1.AMOUNT_LOCAL * a_RATE,5) , REC1.PERIOD        , REC1.MATERIAL_GROUP , REC1.MATERIAL_TYPE , REC1.MATERIAL    , 
                     REC1.SHIP_TO_PARTY  , ROUND(REC1.AMOUNT_TWD * a_RATE,5)   , REC1.EX_RATE_TWD   , ROUND(REC1.AMOUNT_USD * a_RATE,5)     , REC1.EX_RATE_USD   , SYSDATE          ,
                     REC1.UPLOADSITE     , REC1.PLANT_CODE   , REC1.SOURCE        , REC1.CATEGORY       , REC1.CUST_GROUP    , REC1.SEARCH_TERM ,
                     REC1.SHIP_TO_PARTY_GROUP,
                     ROUND(REC1.VV006 * a_RATE,5),ROUND(REC1.VV007 * a_RATE,5),ROUND(REC1.VV014 * a_RATE,5),ROUND(REC1.VV015 * a_RATE,5),ROUND(REC1.VV016 * a_RATE,5),ROUND(REC1.VV017 * a_RATE,5),ROUND(REC1.VV018 * a_RATE,5),ROUND(REC1.VV019 * a_RATE,5),
                     ROUND(REC1.VV006_TWD * a_RATE,5),ROUND(REC1.VV007_TWD * a_RATE,5),ROUND(REC1.VV014_TWD * a_RATE,5),ROUND(REC1.VV015_TWD * a_RATE,5),ROUND(REC1.VV016_TWD * a_RATE,5),ROUND(REC1.VV017_TWD * a_RATE,5),ROUND(REC1.VV018_TWD * a_RATE,5),ROUND(REC1.VV019_TWD * a_RATE,5),
                     ROUND(REC1.VV006_USD * a_RATE,5),ROUND(REC1.VV007_USD * a_RATE,5),ROUND(REC1.VV014_USD * a_RATE,5),ROUND(REC1.VV015_USD * a_RATE,5),ROUND(REC1.VV016_USD * a_RATE,5),ROUND(REC1.VV017_USD * a_RATE,5),ROUND(REC1.VV018_USD * a_RATE,5),ROUND(REC1.VV019_USD * a_RATE,5)
                     );
                  COMMIT;
               
               END LOOP;
               IF a_COUNTER = 0 THEN
                 FOR REC2 IN (SELECT END_CUSTOMER_ID,RATE 
                           FROM PNL3_MAP001_GLOBAL_CUST_RATE 
                          WHERE R_KIND = 'PL01'  --隨便抓一筆來用,反正匯率都一樣
                            AND AREA1  = '4'
                            AND AREA2  = '1'
                            AND AREA3  = '1'
                          --AND COMPANY_CODE = REC1.COMPANY_CODE
                          --AND PROFIT_CENTER = REC1.PROFIT_CENTER
                            AND PERIOD = inPeriod) LOOP
                            a_RATE := REC2.RATE;
                            a_ENDCUSTOMER := REC2.END_CUSTOMER_ID;
                 Insert into PNL3_TRX006_ADJUST
                    (YEAR                , MONTH             , PROFIT_CENTER      , COMPANY_CODE        , END_CUSTOMER_ID    , CUSTOMER_ID      ,
                     CURRENCY_LOCAL      , AMOUNT_LOCAL      , PERIOD             , MATERIAL_GROUP      , MATERIAL_TYPE      , MATERIAL         ,
                     SHIP_TO_PARTY       , AMOUNT_TWD        , EX_RATE_TWD        , AMOUNT_USD          , EX_RATE_USD        , CREATE_DATE      ,
                     UPLOADSITE          , PLANT_CODE        , SOURCE             , CATEGORY           , CUST_GROUP          , SEARCH_TERM      ,
                     SHIP_TO_PARTY_GROUP ,
                     VV006,VV007,VV014,VV015,VV016,VV017,VV018,VV019,
                     VV006_TWD,VV007_TWD,VV014_TWD,VV015_TWD,VV016_TWD,VV017_TWD,VV018_TWD,VV019_TWD,
                     VV006_USD,VV007_USD,VV014_USD,VV015_USD,VV016_USD,VV017_USD,VV018_USD,VV019_USD
                     )
                    Values 
                    (REC1.YEAR           , REC1.MONTH        , REC1.PROFIT_CENTER , REC1.COMPANY_CODE   , a_ENDCUSTOMER      , REC1.CUSTOMER_ID ,
                     REC1.CURRENCY_LOCAL , ROUND(REC1.AMOUNT_LOCAL * a_RATE,5) , REC1.PERIOD        , REC1.MATERIAL_GROUP , REC1.MATERIAL_TYPE , REC1.MATERIAL    , 
                     REC1.SHIP_TO_PARTY  , ROUND(REC1.AMOUNT_TWD * a_RATE,5)   , REC1.EX_RATE_TWD   , ROUND(REC1.AMOUNT_USD * a_RATE,5)     , REC1.EX_RATE_USD   , SYSDATE          ,
                     REC1.UPLOADSITE     , REC1.PLANT_CODE   , REC1.SOURCE        , REC1.CATEGORY       , REC1.CUST_GROUP    , REC1.SEARCH_TERM ,
                     REC1.SHIP_TO_PARTY_GROUP,
                     ROUND(REC1.VV006 * a_RATE,5),ROUND(REC1.VV007 * a_RATE,5),ROUND(REC1.VV014 * a_RATE,5),ROUND(REC1.VV015 * a_RATE,5),ROUND(REC1.VV016 * a_RATE,5),ROUND(REC1.VV017 * a_RATE,5),ROUND(REC1.VV018 * a_RATE,5),ROUND(REC1.VV019 * a_RATE,5),
                     ROUND(REC1.VV006_TWD * a_RATE,5),ROUND(REC1.VV007_TWD * a_RATE,5),ROUND(REC1.VV014_TWD * a_RATE,5),ROUND(REC1.VV015_TWD * a_RATE,5),ROUND(REC1.VV016_TWD * a_RATE,5),ROUND(REC1.VV017_TWD * a_RATE,5),ROUND(REC1.VV018_TWD * a_RATE,5),ROUND(REC1.VV019_TWD * a_RATE,5),
                     ROUND(REC1.VV006_USD * a_RATE,5),ROUND(REC1.VV007_USD * a_RATE,5),ROUND(REC1.VV014_USD * a_RATE,5),ROUND(REC1.VV015_USD * a_RATE,5),ROUND(REC1.VV016_USD * a_RATE,5),ROUND(REC1.VV017_USD * a_RATE,5),ROUND(REC1.VV018_USD * a_RATE,5),ROUND(REC1.VV019_USD * a_RATE,5)
                     );
                  COMMIT;
               
                 END LOOP;
               END IF;
             END IF;
           ELSE
             a_COUNTER := 0; 
             
                FOR REC2 IN (SELECT END_CUSTOMER_ID,RATE 
                           FROM PNL3_MAP001_CUSTOMER_RATE 
                          WHERE R_KIND = 'PL01'  --隨便抓一筆來用,反正匯率都一樣
                            AND AREA1  = '4'
                            AND AREA2  = '1'
                            AND AREA3  = '1'
                          --AND COMPANY_CODE = REC1.COMPANY_CODE
                            AND PROFIT_CENTER = REC1.PROFIT_CENTER
                            AND PERIOD = inPeriod) LOOP
                            a_RATE := REC2.RATE;
                            a_ENDCUSTOMER := REC2.END_CUSTOMER_ID;
                       a_COUNTER := 1; 
               Insert into PNL3_TRX006_ADJUST
                    (YEAR                , MONTH             , PROFIT_CENTER      , COMPANY_CODE        , END_CUSTOMER_ID    , CUSTOMER_ID      ,
                     CURRENCY_LOCAL      , AMOUNT_LOCAL      , PERIOD             , MATERIAL_GROUP      , MATERIAL_TYPE      , MATERIAL         ,
                     SHIP_TO_PARTY       , AMOUNT_TWD        , EX_RATE_TWD        , AMOUNT_USD          , EX_RATE_USD        , CREATE_DATE      ,
                     UPLOADSITE          , PLANT_CODE        , SOURCE             , CATEGORY           , CUST_GROUP          , SEARCH_TERM      ,
                     SHIP_TO_PARTY_GROUP ,
                     VV006,VV007,VV014,VV015,VV016,VV017,VV018,VV019,
                     VV006_TWD,VV007_TWD,VV014_TWD,VV015_TWD,VV016_TWD,VV017_TWD,VV018_TWD,VV019_TWD,
                     VV006_USD,VV007_USD,VV014_USD,VV015_USD,VV016_USD,VV017_USD,VV018_USD,VV019_USD
                     )
                    Values 
                    (REC1.YEAR           , REC1.MONTH        , REC1.PROFIT_CENTER , REC1.COMPANY_CODE   , a_ENDCUSTOMER      , REC1.CUSTOMER_ID ,
                     REC1.CURRENCY_LOCAL , ROUND(REC1.AMOUNT_LOCAL * a_RATE,5), REC1.PERIOD        , REC1.MATERIAL_GROUP , REC1.MATERIAL_TYPE , REC1.MATERIAL    , 
                     REC1.SHIP_TO_PARTY  , ROUND(REC1.AMOUNT_TWD * a_RATE,5)   , REC1.EX_RATE_TWD   , ROUND(REC1.AMOUNT_USD * a_RATE,5)     , REC1.EX_RATE_USD   , SYSDATE          ,
                     REC1.UPLOADSITE     , REC1.PLANT_CODE   , REC1.SOURCE        , REC1.CATEGORY       , REC1.CUST_GROUP    , REC1.SEARCH_TERM ,
                     REC1.SHIP_TO_PARTY_GROUP,
                     ROUND(REC1.VV006 * a_RATE,5),ROUND(REC1.VV007 * a_RATE,5),ROUND(REC1.VV014 * a_RATE,5),ROUND(REC1.VV015 * a_RATE,5),ROUND(REC1.VV016 * a_RATE,5),ROUND(REC1.VV017 * a_RATE,5),ROUND(REC1.VV018 * a_RATE,5),ROUND(REC1.VV019 * a_RATE,5),
                     ROUND(REC1.VV006_TWD * a_RATE,5),ROUND(REC1.VV007_TWD * a_RATE,5),ROUND(REC1.VV014_TWD * a_RATE,5),ROUND(REC1.VV015_TWD * a_RATE,5),ROUND(REC1.VV016_TWD * a_RATE,5),ROUND(REC1.VV017_TWD * a_RATE,5),ROUND(REC1.VV018_TWD * a_RATE,5),ROUND(REC1.VV019_TWD * a_RATE,5),
                     ROUND(REC1.VV006_USD * a_RATE,5),ROUND(REC1.VV007_USD * a_RATE,5),ROUND(REC1.VV014_USD * a_RATE,5),ROUND(REC1.VV015_USD * a_RATE,5),ROUND(REC1.VV016_USD * a_RATE,5),ROUND(REC1.VV017_USD * a_RATE,5),ROUND(REC1.VV018_USD * a_RATE,5),ROUND(REC1.VV019_USD * a_RATE,5)
                     );
                COMMIT;
               
               END LOOP;
             IF a_COUNTER = 0 THEN 
                FOR REC2 IN (SELECT END_CUSTOMER_ID,RATE 
                           FROM PNL3_MAP001_GLOBAL_CUST_RATE 
                          WHERE R_KIND = 'PL01'  --隨便抓一筆來用,反正匯率都一樣
                            AND AREA1  = '4'
                            AND AREA2  = '1'
                            AND AREA3  = '1'
                          --AND COMPANY_CODE = REC1.COMPANY_CODE
                            --AND PROFIT_CENTER = REC1.PROFIT_CENTER
                            AND PERIOD = inPeriod) LOOP
                            a_RATE := REC2.RATE;
                            a_ENDCUSTOMER := REC2.END_CUSTOMER_ID;
                       a_COUNTER := 1; 
               Insert into PNL3_TRX006_ADJUST
                    (YEAR                , MONTH             , PROFIT_CENTER      , COMPANY_CODE        , END_CUSTOMER_ID    , CUSTOMER_ID      ,
                     CURRENCY_LOCAL      , AMOUNT_LOCAL      , PERIOD             , MATERIAL_GROUP      , MATERIAL_TYPE      , MATERIAL         ,
                     SHIP_TO_PARTY       , AMOUNT_TWD        , EX_RATE_TWD        , AMOUNT_USD          , EX_RATE_USD        , CREATE_DATE      ,
                     UPLOADSITE          , PLANT_CODE        , SOURCE             , CATEGORY           , CUST_GROUP          , SEARCH_TERM      ,
                     SHIP_TO_PARTY_GROUP ,
                     VV006,VV007,VV014,VV015,VV016,VV017,VV018,VV019,
                     VV006_TWD,VV007_TWD,VV014_TWD,VV015_TWD,VV016_TWD,VV017_TWD,VV018_TWD,VV019_TWD,
                     VV006_USD,VV007_USD,VV014_USD,VV015_USD,VV016_USD,VV017_USD,VV018_USD,VV019_USD
                     )
                    Values 
                    (REC1.YEAR           , REC1.MONTH        , REC1.PROFIT_CENTER , REC1.COMPANY_CODE   , a_ENDCUSTOMER      , REC1.CUSTOMER_ID ,
                     REC1.CURRENCY_LOCAL , ROUND(REC1.AMOUNT_LOCAL * a_RATE,5), REC1.PERIOD        , REC1.MATERIAL_GROUP , REC1.MATERIAL_TYPE , REC1.MATERIAL    , 
                     REC1.SHIP_TO_PARTY  , ROUND(REC1.AMOUNT_TWD * a_RATE,5)   , REC1.EX_RATE_TWD   , ROUND(REC1.AMOUNT_USD * a_RATE,5)     , REC1.EX_RATE_USD   , SYSDATE          ,
                     REC1.UPLOADSITE     , REC1.PLANT_CODE   , REC1.SOURCE        , REC1.CATEGORY       , REC1.CUST_GROUP    , REC1.SEARCH_TERM ,
                     REC1.SHIP_TO_PARTY_GROUP,
                     ROUND(REC1.VV006 * a_RATE,5),ROUND(REC1.VV007 * a_RATE,5),ROUND(REC1.VV014 * a_RATE,5),ROUND(REC1.VV015 * a_RATE,5),ROUND(REC1.VV016 * a_RATE,5),ROUND(REC1.VV017 * a_RATE,5),ROUND(REC1.VV018 * a_RATE,5),ROUND(REC1.VV019 * a_RATE,5),
                     ROUND(REC1.VV006_TWD * a_RATE,5),ROUND(REC1.VV007_TWD * a_RATE,5),ROUND(REC1.VV014_TWD * a_RATE,5),ROUND(REC1.VV015_TWD * a_RATE,5),ROUND(REC1.VV016_TWD * a_RATE,5),ROUND(REC1.VV017_TWD * a_RATE,5),ROUND(REC1.VV018_TWD * a_RATE,5),ROUND(REC1.VV019_TWD * a_RATE,5),
                     ROUND(REC1.VV006_USD * a_RATE,5),ROUND(REC1.VV007_USD * a_RATE,5),ROUND(REC1.VV014_USD * a_RATE,5),ROUND(REC1.VV015_USD * a_RATE,5),ROUND(REC1.VV016_USD * a_RATE,5),ROUND(REC1.VV017_USD * a_RATE,5),ROUND(REC1.VV018_USD * a_RATE,5),ROUND(REC1.VV019_USD * a_RATE,5)
                     );
                COMMIT;
               
               END LOOP;
             END IF;
           END IF;
         END LOOP;              

      UPDATE PNL3_TRX006_ADJUST
      SET project_name =
             (SELECT DISTINCT TRIM (sap_project_name)
                         FROM cep_map010_partno_project
                        WHERE fg_material_no =
                                 RPAD (PNL3_TRX006_ADJUST.material,
                                       18,
                                       ' '
                                      ))
    WHERE period = inperiod;

   COMMIT;

   UPDATE PNL3_TRX006_ADJUST
      SET project_type =
                  (SELECT DISTINCT TRIM (project_type)
                              FROM cep_web002_project
                             WHERE project_name =
                                          PNL3_TRX006_ADJUST.project_name)
    --RPAD (PNL3_TRX003_UNUTILIZATION.PROJECT_NAME, 30, ' '))
   WHERE  period = inperiod;

   COMMIT;
   
    
END PNL3_PLS009_ADJUST_TRX;
/

