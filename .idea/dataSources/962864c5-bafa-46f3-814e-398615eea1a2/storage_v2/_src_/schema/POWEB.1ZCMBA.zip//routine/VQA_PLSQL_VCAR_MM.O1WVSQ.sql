create PROCEDURE VQA_PLSQL_VCAR_MM
IS
      /*--------------------------------------------------------------*
         CREATE DATE:  2008/03/19
         PLSQL      :  VQA_PLSQL_VCAR_MM
         Author     :  Jason Lin
         Purpose    :  VCAR Count by month (每月執行一次)
                       TW/SZ/SH/MX
      *---------------------------------------------------------------*
      */


 vPROCEE_YYYYMMDD varchar2(8);
 vPROCEE_YYYYMM   varchar2(6);
 iTracePoint      varchar2(100);
 cErrorText       varchar2(500);

BEGIN

 --抓上月份系統日期
  iTracePoint := '000';
   select * into vPROCEE_YYYYMM, vPROCEE_YYYYMMDD  from (
          select trim(to_char(add_months(SYSDATE,-1), 'YYYYMM')), trim(to_char(add_months(SYSDATE,-1), 'YYYYMM')) || '01'
                 from dual
   );
  
  
  --清除重覆資料
  iTracePoint := '200';
  DELETE from VQA_VCAR_MONTHLY where yyyymm in                                                
    (Select yyyymm from DIMENSION_DATE Where date_key in                                 --ISSUED_DATE所在的yyyymm             
    (select distinct ISSUED_DATE from VQA_SQM_VCAR where substrb(CLOSED_DATE,1,8) in     --CLOSED_DATE在前一個月的ISSUED_DATE
    (Select distinct date_key from DIMENSION_DATE where yyyymm=to_char(add_months(SYSDATE,-1), 'YYYYMM'))));  --前一個月所含的date_key
  
         
         
  -- 計算VCAR 月資料
  iTracePoint := '300';
  Insert into VQA_VCAR_MONTHLY (
                    COMPANY_CODE,YYYY,MM,QUARTER,MANUF,PART_NO,MFR_PN,VCAR_COUNT,DATE_TIME,YYYYMM )
  select A.COMPANY_CODE,B.YYYY,B.MM,B.QUARTER,A.MFR_NAME as MANUF,A.USI_PN as PART_NO,A.MFR_PN,count(A.MFR_PN) as VCAR_COUNT,to_char( sysdate, 'yyyymmddhh24miss') as DATE_TIME,B.YYYYMM
  from VQA_SQM_VCAR A, DIMENSION_DATE B
  where A.CONCLUSION='M'
  and A.STATUS='C'
  and B.DATE_KEY in (Select distinct date_key from DIMENSION_DATE where yyyymm in        
    (Select yyyymm from DIMENSION_DATE Where date_key in                                              
    (select distinct ISSUED_DATE from VQA_SQM_VCAR where substrb(CLOSED_DATE,1,8) in      
    (Select distinct date_key from DIMENSION_DATE where yyyymm=to_char(add_months(SYSDATE,-1), 'YYYYMM')))))   
  and A.ISSUED_DATE=B.DATE_KEY
  group by COMPANY_CODE,YYYY,MM,QUARTER,MFR_NAME,USI_PN,MFR_PN,YYYYMM;
  
  
  -- 計算VCAR WW月資料
  Insert into VQA_VCAR_MONTHLY (
                    COMPANY_CODE,YYYY,MM,QUARTER,MANUF,PART_NO,MFR_PN,VCAR_COUNT,DATE_TIME,YYYYMM )
  select '0000' as COMPANY_CODE,B.YYYY,B.MM,B.QUARTER,A.MFR_NAME as MANUF,A.USI_PN as PART_NO,A.MFR_PN,count(A.MFR_PN) as VCAR_COUNT,to_char( sysdate, 'yyyymmddhh24miss') as DATE_TIME,B.YYYYMM
  from VQA_SQM_VCAR A, DIMENSION_DATE B
  where A.CONCLUSION='M'
  and A.STATUS='C'
  and B.DATE_KEY in (Select distinct date_key from DIMENSION_DATE where yyyymm in        
    (Select yyyymm from DIMENSION_DATE Where date_key in                                              
    (select distinct ISSUED_DATE from VQA_SQM_VCAR where substrb(CLOSED_DATE,1,8) in      
    (Select distinct date_key from DIMENSION_DATE where yyyymm=to_char(add_months(SYSDATE,-1), 'YYYYMM')))))   
  and A.ISSUED_DATE=B.DATE_KEY
  group by YYYY,MM,QUARTER,MFR_NAME,USI_PN,MFR_PN,YYYYMM;
  commit;


EXCEPTION
   When OTHERS Then
    --有錯誤產生則寄mail
    cErrorText := SQLERRM();
    MAIL_FILE_BIDBDBADMIN(in_to_name => 'jason@ms.usi.com.tw', subject => '[VQA-Error] PL/SQL VQA_PLSQL_VCAR_MM ERROR', message => '[Table:VQA_VCAR_MONTHLY], The tracepoint is  ' || iTracePoint || ' and ErrorText= ' || cErrorText) ;

END VQA_PLSQL_VCAR_MM;
/

