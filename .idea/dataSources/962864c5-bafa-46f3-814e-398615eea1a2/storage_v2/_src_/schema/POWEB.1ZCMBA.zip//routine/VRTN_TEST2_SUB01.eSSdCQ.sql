create PROCEDURE "VRTN_TEST2_SUB01" (
  vTW_SITE in VARCHAR2,
  vSZ_SITE in VARCHAR2,
  vSH_SITE in VARCHAR2,
  vQUARTER in VARCHAR2,
  vMATGROUP in VARCHAR2,
  vGV_VENDOR in VARCHAR2
)
IS
    /*
         TEST sub01  VENDOR DATA
         By Susan
     */

      --TW VENDOR SELECT
       CURSOR TW_VENDOR is
       select VENDOR, Q_AMOUNT, Q_MM_SCORE from VRTN_SUM14_QQ_MATGP A
                           where A.QUARTER = vQUARTER
                             and A.MATGROUP = vMATGROUP
                             and A.GV_VENDOR = vGV_VENDOR
                             and A.SITE = vTW_SITE;
      -- GROUP BY QUARTER,GV_VENDOR,MATGROUP,SITE,VENDOR;
      -- SZ VENDOR SELECT
         CURSOR SZ_VENDOR is
         select VENDOR, Q_AMOUNT, Q_MM_SCORE from VRTN_SUM14_QQ_MATGP
                             where QUARTER = vQUARTER
                               and MATGROUP = vMATGROUP
                               and GV_VENDOR = vGV_VENDOR
                               and SITE = vSZ_SITE;
       --GROUP BY QUARTER,GV_VENDOR,MATGROUP,SITE,VENDOR;

       --SH VENDOR SELECT
        CURSOR SH_VENDOR is
        select VENDOR, Q_AMOUNT, Q_MM_SCORE from VRTN_SUM14_QQ_MATGP
                            where QUARTER = vQUARTER
                              and MATGROUP = vMATGROUP
                              and GV_VENDOR = vGV_VENDOR
                              and SITE = vSH_SITE;
        --GROUP BY QUARTER,GV_VENDOR,MATGROUP,SITE,VENDOR;


iTracePoint      varchar2(100);
cErrorText       varchar2(500);
vTW_VENDOR varchar2(100);
vSZ_VENDOR varchar2(100);
vSH_VENDOR varchar2(100);
vTW_AMOUNT NUMBER(15,5);
vSZ_AMOUNT NUMBER(15,5);
vSH_AMOUNT NUMBER(15,5);
vTOT_AMOUNT NUMBER(15,5);
vTW_AMT_SHARE_SITE VRTN_SUM20_GV_QQ_MATGP.TW_AMT_SHARE_SITE%TYPE;
vSZ_AMT_SHARE_SITE VRTN_SUM20_GV_QQ_MATGP.SZ_AMT_SHARE_SITE%TYPE;
vSH_AMT_SHARE_SITE VRTN_SUM20_GV_QQ_MATGP.SH_AMT_SHARE_SITE%TYPE;
vTW_Q_SCORE VRTN_SUM20_GV_QQ_MATGP.TW_Q_SCORE%TYPE;
vSZ_Q_SCORE VRTN_SUM20_GV_QQ_MATGP.SZ_Q_SCORE%TYPE;
vSH_Q_SCORE VRTN_SUM20_GV_QQ_MATGP.SH_Q_SCORE%TYPE;
vTW_SITE_PER VRTN_SUM20_GV_QQ_MATGP.SH_AMT_SHARE_SITE%TYPE;
vSZ_SITE_PER VRTN_SUM20_GV_QQ_MATGP.SH_AMT_SHARE_SITE%TYPE;
vSH_SITE_PER VRTN_SUM20_GV_QQ_MATGP.SH_AMT_SHARE_SITE%TYPE;

BEGIN


     BEGIN
       select * into vTOT_AMOUNT from (
         select round(sum(Q_AMOUNT),5) from VRTN_SUM14_QQ_MATGP
          where QUARTER = vQUARTER
                and MATGROUP = vMATGROUP
            and GV_VENDOR = vGV_VENDOR
          GROUP BY QUARTER,GV_VENDOR,MATGROUP
       );
     EXCEPTION
       When OTHERS Then
         vTOT_AMOUNT := 0;
     END;


     vTW_VENDOR := '';
     vSZ_VENDOR := '';
     vSH_VENDOR := '';
     vTW_AMOUNT := 0;
     vSZ_AMOUNT := 0;
     vSH_AMOUNT := 0;
     vTW_AMT_SHARE_SITE := 0;
     vSH_AMT_SHARE_SITE := 0;
     vSZ_AMT_SHARE_SITE := 0;
     vTW_Q_SCORE := 0;
     vSZ_Q_SCORE := 0;
     vSH_Q_SCORE := 0;


     iTracePoint := '210'; -- TW VENDOR
     for TW_VENDOR_LIST_REC in TW_VENDOR LOOP
           vTW_VENDOR := trim(TW_VENDOR_LIST_REC.VENDOR || trim(NVL(vTW_VENDOR,' ')));
--         vTW_AMOUNT := TW_VENDOR_LIST_REC.Q_AMOUNT + trim(to_char(vTW_AMOUNT));
--         vTW_AMOUNT := TW_VENDOR_LIST_REC.Q_AMOUNT + TO_NUMBER((vTW_AMOUNT),5);
           vTW_AMOUNT := NVL(to_number(vTW_AMOUNT), 0) + TW_VENDOR_LIST_REC.Q_AMOUNT;

--    MAIL_FILE_BIDBDBADMIN(in_to_name => 'shuchin@ms.usi.com.tw', subject => '[VRT] PL/SQL VRTN_TEST2_SUB01 ERROR', message => '[VRTN_TEST2_SUB01], The tracepoint is  ' || iTracePoint || ' TEST= ' ||  vTW_VENDOR || TW_VENDOR_LIST_REC.Q_AMOUNT || 'AMT=' || vTW_AMOUNT || 'TOT=' || vTOT_AMOUNT);


      end loop;



      iTracePoint := '310'; -- SZ VENDOR
      for SZ_VENDOR_LIST_REC in SZ_VENDOR LOOP
         vSZ_VENDOR := trim(SZ_VENDOR_LIST_REC.VENDOR || trim(NVL(vSZ_VENDOR,' ')));
                 vSZ_AMOUNT := NVL(to_number(vSZ_AMOUNT), 0) + SZ_VENDOR_LIST_REC.Q_AMOUNT;

      end loop;


      iTracePoint := '410'; -- SH VENDOR
      for SH_VENDOR_LIST_REC in SH_VENDOR LOOP
         vSH_VENDOR := trim(SH_VENDOR_LIST_REC.VENDOR || trim(NVL(vSH_VENDOR,' ')));
                 vSH_AMOUNT := NVL(to_number(vSH_AMOUNT), 0) + SH_VENDOR_LIST_REC.Q_AMOUNT;

      end loop;


         if vTOT_AMOUNT > 0 then
            vTW_AMT_SHARE_SITE := NVL(to_number(vTW_AMOUNT),0 ) / NVL(to_number(vTOT_AMOUNT), 0);
            vSZ_AMT_SHARE_SITE := NVL(to_number(vSZ_AMOUNT),0 ) / NVL(to_number(vTOT_AMOUNT), 0);
            vSH_AMT_SHARE_SITE := NVL(to_number(vSH_AMOUNT),0 ) / NVL(to_number(vTOT_AMOUNT), 0);
         end if;


     iTracePoint := '510'; -- TW VENDOR SITE PER
     for TW_VENDOR_LIST_REC in TW_VENDOR LOOP
        -- UPDATE SITE PER
        --     Update VRTN_SUM14_QQ_MATGP
        --        set SITE_PER = round(Q_AMOUNT / vTW_AMOUNT, 5)
        --      where QUARTER =  vQUARTER
        --        and SITE = vTW_SITE
        --        and MATGROUP = vMATGROUP
        --        and GV_VENDOR = vGV_VENDOR
        --        and VENDOR = TW_VENDOR_LIST_REC.VENDOR;


         if vTW_AMOUNT > 0 then
            vTW_SITE_PER := TW_VENDOR_LIST_REC.Q_AMOUNT / vTW_AMOUNT;
            vTW_Q_SCORE := NVL(to_number(vTW_Q_SCORE), 0) + TW_VENDOR_LIST_REC.Q_MM_SCORE * vTW_SITE_PER;
            MAIL_FILE_BIDBDBADMIN(in_to_name => 'shuchin@ms.usi.com.tw', subject => '[VRT]TW PL/SQL VRTN_TEST2_SUB01 ERROR', message => '[VRTN_TEST2_SUB01], The tracepoint is  ' || iTracePoint || ' TEST= ' ||  vTW_VENDOR || TW_VENDOR_LIST_REC.Q_AMOUNT || 'AMT=' || vTW_AMOUNT || 'M=>' || vMATGROUP || 'PER='|| vTW_SITE_PER || 'S=' || vTW_Q_SCORE );
         end if;
     end loop;
	 commit;

	 iTracePoint := '520'; -- SZ VENDOR SITE PER
     for SZ_VENDOR_LIST_REC in SZ_VENDOR LOOP

--             Update VRTN_SUM14_QQ_MATGP
--                set SITE_PER = round(Q_AMOUNT / vTW_AMOUNT, 5)
--              where QUARTER =  vQUARTER
--                and SITE = vTW_SITE
--                and MATGROUP = vMATGROUP
--                and GV_VENDOR = vGV_VENDOR
--                and VENDOR = TW_VENDOR_LIST_REC.VENDOR
--             commit;
         if vSZ_AMOUNT > 0 then
            vSZ_SITE_PER := SZ_VENDOR_LIST_REC.Q_AMOUNT / vSZ_AMOUNT;
            vSZ_Q_SCORE := NVL(to_number(vSZ_Q_SCORE), 0) + SZ_VENDOR_LIST_REC.Q_MM_SCORE * vSZ_SITE_PER;
            MAIL_FILE_BIDBDBADMIN(in_to_name => 'shuchin@ms.usi.com.tw', subject => '[VRT]SZ PL/SQL VRTN_TEST2_SUB01 ERROR', message => '[VRTN_TEST2_SUB01], The tracepoint is  ' || iTracePoint || ' TEST= ' ||  vSZ_VENDOR || SZ_VENDOR_LIST_REC.Q_AMOUNT || 'AMT=' || vSZ_AMOUNT || 'M=>' || vMATGROUP || 'PER='|| vSZ_SITE_PER || 'S=' || vSZ_Q_SCORE );
         end if;
     end loop;

	      iTracePoint := '530'; -- SH VENDOR
     for SH_VENDOR_LIST_REC in SH_VENDOR LOOP

--             Update VRTN_SUM14_QQ_MATGP
--                set SITE_PER = round(Q_AMOUNT / vTW_AMOUNT, 5)
--              where QUARTER =  vQUARTER
--                and SITE = vTW_SITE
--                and MATGROUP = vMATGROUP
--                and GV_VENDOR = vGV_VENDOR
--                and VENDOR = TW_VENDOR_LIST_REC.VENDOR
--             commit;
         if vSH_AMOUNT > 0 then
            vSH_SITE_PER := SH_VENDOR_LIST_REC.Q_AMOUNT / vSH_AMOUNT;
            vSH_Q_SCORE := NVL(to_number(vSH_Q_SCORE), 0) + SH_VENDOR_LIST_REC.Q_MM_SCORE * vSH_SITE_PER;
            MAIL_FILE_BIDBDBADMIN(in_to_name => 'shuchin@ms.usi.com.tw', subject => '[VRT]SH PL/SQL VRTN_TEST2_SUB01 ERROR', message => '[VRTN_TEST2_SUB01], The tracepoint is  ' || iTracePoint || ' TEST= ' ||  vSH_VENDOR || SH_VENDOR_LIST_REC.Q_AMOUNT || 'AMT=' || vSH_AMOUNT || 'M=>' || vMATGROUP || 'PER='|| vSH_SITE_PER || 'S=' || vSH_Q_SCORE );
         end if;
     end loop;


     --* Update vendor code
     Update VRTN_SUM20_TEST1
              set TW_VENDOR = vTW_VENDOR,
                  SZ_VENDOR = vSZ_VENDOR,
                  SH_VENDOR = vSH_VENDOR,
                  TW_AMOUNT = vTW_AMOUNT,
                                  SZ_AMOUNT = vSZ_AMOUNT,
                                  SH_AMOUNT = vSH_AMOUNT,
                                  TW_AMT_SHARE_SITE = vTW_AMT_SHARE_SITE,
                                  SZ_AMT_SHARE_SITE = vSZ_AMT_SHARE_SITE,
                                  SH_AMT_SHARE_SITE = vSH_AMT_SHARE_SITE,
                                  TW_Q_SCORE = vTW_Q_SCORE,
                                  SZ_Q_SCORE = vSZ_Q_SCORE,
                                  SH_Q_SCORE = vSH_Q_SCORE
            where GV_VENDOR = vGV_VENDOR
              and MATGROUP = vMATGROUP
              and QUARTER = vQUARTER;
            commit;



EXCEPTION
   When OTHERS Then
    --有錯誤產生則寄mail
      cErrorText := SQLERRM();
      MAIL_FILE_BIDBDBADMIN(in_to_name => 'shuchin@ms.usi.com.tw', subject => '[VRT] PL/SQL VRTN_TEST2_SUB01 ERROR', message => '[VRTN_TEST2_SUB01], The tracepoint is  ' || iTracePoint || ' and ErrorText= ' || cErrorText);


END VRTN_TEST2_SUB01;
/

