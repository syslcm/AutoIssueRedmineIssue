create PROCEDURE "PLSQL_DMS_RPT_CUSTOMER_00"
/*
********************************************************************
  PROG-ID      : PLSQL_DMS_RPT_CUSTOMER_00
  PROG-ACTION  : 依 Dalek 邏輯計算 CUSTOMER DMS ( all BU)
  Author      : Minhorng
  Date         : 2009/01/09
*********************************************************************
*/
is
	iTracePoint           integer;
	cErrorText            varchar2(500);
	t_PERIOD              DMM_RPT001_FG_W_MAX.PERIOD%TYPE;
	p_YYYYMM              varchar2(6);--上個年月
	min_YW_DATE           varchar2(8);
	f_DATE                varchar2(8);
	t_EX_RATE_USD         number(10,5);
	t_DM_RATE             DMS_RPT00_CUSTOMER_T07.DM_RATE%TYPE;
	t_TURNOVER_DAY        DMS_RPT00_CUSTOMER_T07.TURNOVER_DAY%TYPE;
	t_TURNOVER_DAY2       DMS_RPT00_CUSTOMER_T07.TURNOVER_DAY%TYPE;
BEGIN
	cErrorText := ' ';
	--(0) 抓DMM_RPT001_FG_W_MAX + CEP_MAP009_PARTNO_CUSTOMER max(PERIOD)
	iTracePoint := 0;
	t_PERIOD := null;
	min_YW_DATE := null;
	select * into t_PERIOD, min_YW_DATE from (
		select max(a.PERIOD), min(d.YW_DATE) from DMM_RPT001_FG_W_MAX a,
			CEP_MAP009_PARTNO_CUSTOMER b, DMM_UPL001_SELLING c, DMM_RPT001_FG_W d
		where trim(b.FG_MATERIAL_NO) = a.FG
		and c.COMPANY_CODE = a.COMPANY_CODE
		and c.PLANT = a.PLANT
		and c.FG = a.FG
		and c.TO_DATE >= to_char(sysdate,'yyyymmdd')
		and d.COMPANY_CODE = a.COMPANY_CODE
		and d.PLANT = a.PLANT
		and d.FG = a.FG
		and d.PERIOD = a.PERIOD
	);

	--(5) 抓上個年月
	iTracePoint := 5;
	p_YYYYMM := null;
	f_DATE := null;
	select * into p_YYYYMM, f_DATE from (
		select to_char(add_months(sysdate, -1),'yyyymm'),
			(to_char(sysdate,'yyyymm') || '01')
		from DUAL
	);

	--(100) 處理 DMS_RPT00_CUSTOMER_T01 / DMS_RPT00_CUSTOMER_T02
	iTracePoint := 100;
	delete from DMS_RPT00_CUSTOMER_T01;
	commit;
	iTracePoint := 102;
	insert into DMS_RPT00_CUSTOMER_T01 (
		COMPANY_CODE, PLANT, FG, BU, CUSTOMER_NAME,
		SELLING_PRICE, PERIOD, YYYYWW, YW_DATE, FG_QTY,
		COST_USD, YYYYMM
	)
	select COMPANY_CODE, PLANT, FG, BU, trim(upper(END_CUSTOMER_NAME)) as CUSTOMER_NAME,
		SELLING_PRICE, PERIOD, YYYYWW, YW_DATE, FG_QTY,
		sum(COST_MAC) as COST_USD, substr(YW_DATE,1,6) as YYYYMM
	from (
		select b.COMPANY_CODE, b.PLANT, b.FG, b.BU, a.END_CUSTOMER_NAME,
			b.SELLING_PRICE, c.PERIOD, c.YYYYWW, c.YW_DATE, c.FG_QTY, c.COST_MAC
		from CEP_MAP009_PARTNO_CUSTOMER a, DMM_UPL001_SELLING b, DMM_RPT001_FG_W c
		where trim(a.FG_MATERIAL_NO) = b.FG
		and b.FROM_DATE <= c.YW_DATE
		and b.TO_DATE >= c.YW_DATE
		and c.COMPANY_CODE = b.COMPANY_CODE
		and c.PLANT = b.PLANT
		and c.FG = b.FG
		and c.PERIOD = t_PERIOD
		union
		select b.COMPANY_CODE, b.PLANT, b.FG, b.BU, a.END_CUSTOMER_NAME,
			b.SELLING_PRICE, null as PERIOD, null as YYYYWW, c.DATE_KEY as YW_DATE,
			c.FG_QTY, c.COST_MAC
		from CEP_MAP009_PARTNO_CUSTOMER a, DMM_UPL001_SELLING b, DMM_RPT003_FG_D c
		where trim(a.FG_MATERIAL_NO) = b.FG
		and b.FROM_DATE <= c.DATE_KEY
		and b.TO_DATE >= c.DATE_KEY
		and c.COMPANY_CODE = b.COMPANY_CODE
		and c.PLANT = b.PLANT
		and c.FG = b.FG
		and c.DATE_KEY >= f_DATE
		and c.DATE_KEY < min_YW_DATE
	)
	group by COMPANY_CODE, PLANT, FG, BU, trim(upper(END_CUSTOMER_NAME)),
		SELLING_PRICE, PERIOD, YYYYWW, YW_DATE, FG_QTY;
	commit;
	iTracePoint := 104;
	delete from DMS_RPT00_CUSTOMER_T02;
	commit;
	iTracePoint := 106;
	insert into DMS_RPT00_CUSTOMER_T02 (
		BU, CUSTOMER_NAME, YYYYMM, DMS_DM
	)
	select BU, CUSTOMER_NAME, YYYYMM, round(COSTING / SELLING,6)
	from (
		select BU, CUSTOMER_NAME, YYYYMM,
			sum(round(SELLING_PRICE * FG_QTY,6)) as SELLING,
			sum(round(COST_USD * FG_QTY,6)) as COSTING
		from DMS_RPT00_CUSTOMER_T01
		group by BU, CUSTOMER_NAME, YYYYMM
	) where SELLING != 0
	union
	select BU, CUSTOMER_NAME, YYYYMM, 0 as DM
	from (
		select BU, CUSTOMER_NAME, YYYYMM,
			sum(round(SELLING_PRICE * FG_QTY,6)) as SELLING,
			sum(round(COST_USD * FG_QTY,6)) as COSTING
		from DMS_RPT00_CUSTOMER_T01
		group by BU, CUSTOMER_NAME, YYYYMM
	) where SELLING = 0;
	commit;
	--(110) 處理 DMS_RPT00_CUSTOMER_T03 -- 上月實際 DM
	iTracePoint := 110;
	delete from DMS_RPT00_CUSTOMER_T03;
	commit;
	iTracePoint := 112;
	insert into DMS_RPT00_CUSTOMER_T03 (
		BU, CUSTOMER_NAME, YYYYMM, ACT_DM
	)
	select BU, trim(upper(END_CUSTOMER_NAME)) as CUSTOMER_NAME,
		PERIOD,
		round(sum(COGS_MB_USD) / sum(NET_REVENUE_USD),6)
	from (
		select 'A' as ID, a.PERIOD,
			a.COMPANY_CODE, a.PLANT_CODE as PLANT, a.PART_NO as FG,
			a.NET_REVENUE_USD, a.COGS_MB_USD,
			b.END_CUSTOMER_NAME, c.BU
		from KPI_SAP001_COPA_TRX a, CEP_MAP009_PARTNO_CUSTOMER b, DMM_UPL001_SELLING c
		where a.PART_NO = trim(b.FG_MATERIAL_NO)
		and a.PERIOD = p_YYYYMM
		and a.MVTP in ('601','602','633','634','653','653','654')
		and nvl(a.COST_ELEMENT,'0000000000') not in ('0000510902','0000510909','0000510999')
		and a.NET_QTY != 0
		and a.NET_REVENUE_USD is not null
		and a.COGS_MB_USD is not null
		and trim(b.FG_MATERIAL_NO) = c.FG
		and c.COMPANY_CODE = a.COMPANY_CODE
		and c.PLANT = a.PLANT_CODE
		and c.FG = a.PART_NO
		and c.FROM_DATE <= to_char(sysdate,'yyyymmdd')
		and c.TO_DATE >= to_char(sysdate,'yyyymmdd')
		union
		select 'B' as ID, a.PERIOD,
			a.COMPANY_CODE, a.PLANT_CODE as PLANT, a.PART_NO as FG,
			a.NET_REVENUE_USD, a.COGS_MB_USD,
			b.END_CUSTOMER_NAME, c.BU
		from KPI_SAP001_COPA_TRX a, CEP_MAP009_PARTNO_CUSTOMER b, DMM_UPL001_SELLING c
		where a.PART_NO = trim(b.FG_MATERIAL_NO)
		and a.PERIOD = p_YYYYMM
		and a.MVTP is null
		and a.AWTYP not in ('RMRP','PRCHG','COPA','MKPF')
		and nvl(a.COST_ELEMENT,'0000000000') not in ('0000510902','0000510909','0000510999')
		and a.NET_QTY != 0
		and a.NET_REVENUE_USD is not null
		and a.COGS_MB_USD is not null
		and trim(b.FG_MATERIAL_NO) = c.FG
		and c.COMPANY_CODE = a.COMPANY_CODE
		and c.PLANT = a.PLANT_CODE
		and c.FG = a.PART_NO
		and c.FROM_DATE <= to_char(sysdate,'yyyymmdd')
		and c.TO_DATE >= to_char(sysdate,'yyyymmdd')
	)
	group by BU, PERIOD, trim(upper(END_CUSTOMER_NAME))
	having sum(NET_REVENUE_USD) != 0;
	commit;
	--(120) 處理 DMS_RPT00_CUSTOMER_T04 -- Inv. AMT (local currency) / DMS_RPT00_CUSTOMER_T05
	iTracePoint := 120;
	delete from DMS_RPT00_CUSTOMER_T04;
	commit;
	iTracePoint := 122;
	insert into DMS_RPT00_CUSTOMER_T04 (
		BU, CUSTOMER_NAME, YYYYMM, LOCAL_CURRENCY, INV_AMT
	)
	select BU, CUSTOMER_NAME,
		(POST_DATE_YYYY || POST_DATE_MM) as YYYYMM,
		LOCAL_CURRENCY,
		round(sum(UNRESTRICTED_USE_AMT + INSPECT_QTY_AMT + BLOCK_QTY_AMT + OPEN_ORDER_AMT),6) as INV_AMT
	from (
		--正常品
		select distinct b.MFG_SITE, b.PLANT, b.MATERIAL, b.POST_DATE_YYYY, b.POST_DATE_MM,
			b.STORAGE_LOC, b.LOCAL_CURRENCY,
			b.UNRESTRICTED_USE_AMT, b.INSPECT_QTY_AMT, b.BLOCK_QTY_AMT, b.OPEN_ORDER_AMT,
			c.BU,
			(select distinct trim(upper(END_CUSTOMER_NAME)) from CEP_MAP009_PARTNO_CUSTOMER
			where trim(FG_MATERIAL_NO) = c.FG and rownum <= 1) as CUSTOMER_NAME
		from VIEW_EGI0150_END_STORAGELOC b, DMM_UPL001_SELLING c
		where b.POST_DATE_YYYY = substr(p_YYYYMM,1,4)
		and b.POST_DATE_MM = substr(p_YYYYMM,5,2)
		and b.STORAGE_LOC like '0%'
		and b.MFG_SITE = c.COMPANY_CODE
		and b.PLANT = c.PLANT
		and b.MATERIAL = c.FG
		and c.FROM_DATE <= to_char(sysdate,'yyyymmdd')
		and c.TO_DATE >= to_char(sysdate,'yyyymmdd')
		--TW HUB
		union
		select distinct b.MFG_SITE, b.PLANT, b.MATERIAL, b.POST_DATE_YYYY, b.POST_DATE_MM,
			b.STORAGE_LOC, b.LOCAL_CURRENCY,
			b.UNRESTRICTED_USE_AMT, b.INSPECT_QTY_AMT, b.BLOCK_QTY_AMT, b.OPEN_ORDER_AMT,
			c.BU,
			(select distinct trim(upper(END_CUSTOMER_NAME)) from CEP_MAP009_PARTNO_CUSTOMER
			where trim(FG_MATERIAL_NO) = c.FG  and rownum <= 1) as CUSTOMER_NAME
		from VIEW_EGI0150_END_STORAGELOC b, DMM_UPL001_SELLING c
		where b.MFG_SITE = '1100'
		and b.PLANT = '1190'
		and b.POST_DATE_YYYY = substr(p_YYYYMM,1,4)
		and b.POST_DATE_MM = substr(p_YYYYMM,5,2)
		and b.STORAGE_LOC != '2000'
		and b.STORAGE_LOC != '3000'
		and b.STORAGE_LOC != '0001'
		and b.MATERIAL = c.FG
		and c.FROM_DATE <= to_char(sysdate,'yyyymmdd')
		and c.TO_DATE >= to_char(sysdate,'yyyymmdd')
		--SH HUB
		union
		select distinct b.MFG_SITE, b.PLANT, b.MATERIAL, b.POST_DATE_YYYY, b.POST_DATE_MM,
			b.STORAGE_LOC, b.LOCAL_CURRENCY,
			b.UNRESTRICTED_USE_AMT, b.INSPECT_QTY_AMT, b.BLOCK_QTY_AMT, b.OPEN_ORDER_AMT,
			c.BU,
			(select distinct trim(upper(END_CUSTOMER_NAME)) from CEP_MAP009_PARTNO_CUSTOMER
			where trim(FG_MATERIAL_NO) = c.FG  and rownum <= 1) as CUSTOMER_NAME
		from VIEW_EGI0150_END_STORAGELOC b, DMM_UPL001_SELLING c
		where b.MFG_SITE = '1500'
		and b.PLANT = '1591'
		and b.POST_DATE_YYYY = substr(p_YYYYMM,1,4)
		and b.POST_DATE_MM = substr(p_YYYYMM,5,2)
		and b.MATERIAL = c.FG
		and c.FROM_DATE <= to_char(sysdate,'yyyymmdd')
		and c.TO_DATE >= to_char(sysdate,'yyyymmdd')
	)
	group by BU, CUSTOMER_NAME, POST_DATE_YYYY, POST_DATE_MM, LOCAL_CURRENCY;
	commit;
	iTracePoint := 124;
	delete from DMS_RPT00_CUSTOMER_T05;
	commit;
	iTracePoint := 126;
	insert into DMS_RPT00_CUSTOMER_T05 (
		BU, CUSTOMER_NAME, YYYYMM, INV_AMT_USD
	)
	select distinct
		BU, CUSTOMER_NAME, YYYYMM, 0
	from DMS_RPT00_CUSTOMER_T04;
	commit;
	iTracePoint := 128;
	for REC1 in (
		select BU, CUSTOMER_NAME, YYYYMM, LOCAL_CURRENCY,
			sum(INV_AMT) as INV_AMT_L
		from DMS_RPT00_CUSTOMER_T04
		group by BU, CUSTOMER_NAME, YYYYMM, LOCAL_CURRENCY
	) loop
		t_EX_RATE_USD := GET_EXCHANGE_RATE(SUBSTRB(REC1.YYYYMM,1,4),SUBSTRB(REC1.YYYYMM,5,2),REC1.LOCAL_CURRENCY,'USD','T');
		update DMS_RPT00_CUSTOMER_T05 set
			INV_AMT_USD = (INV_AMT_USD + round(REC1.INV_AMT_L * t_EX_RATE_USD,6))
		where BU = REC1.BU
		and CUSTOMER_NAME = REC1.CUSTOMER_NAME
		and YYYYMM = REC1.YYYYMM;
		commit;
	end loop;
	--(130) 處理 DMS_RPT00_CUSTOMER_T06 -- project fcst revenue
	iTracePoint := 130;
	delete from DMS_RPT00_CUSTOMER_T06;
	commit;
	iTracePoint := 132;
	insert into DMS_RPT00_CUSTOMER_T06 (
		BU, CUSTOMER_NAME, YYYYMM, NET_REVENUE_USD
	)
	select BU, CUSTOMER_NAME, trim(F_YEAR || RWF_MM), sum(NET_REVENUE_USD)
	from (
		select a.PROFIT_CENTER, trim(upper(a.END_CUSTOMER_ID)) as CUSTOMER_NAME,
			a.F_YEAR, a.RWF_MM, a.NET_REVENUE_USD,
			(select distinct BU from DMM_OTH004_PROFIT_CENTER
				where COMPANY_CODE = a.COMPANY_CODE
				and PROFIT_CENTER = a.PROFIT_CENTER
			) as BU
		from RWF_SAP001_REVENUE_FORECAST a
		where (a.RWF_YYYY || a.RWF_WEEK) = (
			select MAX(x.RWF_YYYY || x.RWF_WEEK) from RWF_SAP001_REVENUE_FORECAST x
		)
		and a.RWF_MM = to_char(sysdate,'MM')
		and a.F_YEAR = to_char(sysdate,'YYYY')
	)
	group by BU, CUSTOMER_NAME, F_YEAR, RWF_MM;
	commit;
	--(200) temp report
	iTracePoint := 200;
	delete from DMS_RPT00_CUSTOMER_T07;
	commit;
	--(210) ACTUAL
	iTracePoint := 210;
	insert into DMS_RPT00_CUSTOMER_T07 (
		BU, CUSTOMER_NAME, YYYYMM, ACTUAL_FLAG, ORG_DM,
		INV_AMT_USD, NET_REVENUE_USD, TURNOVER_DAY, DM_RATE
	)
	select a.BU, a.CUSTOMER_NAME, a.YYYYMM, 'Y', a.ACT_DM,
		(select sum(nvl(INV_AMT_USD,0)) from DMS_RPT00_CUSTOMER_T05
			where BU = a.BU and CUSTOMER_NAME = a.CUSTOMER_NAME
		) as INV_AMT_USD,
		(select sum(nvl(NET_REVENUE_USD,0)) from DMS_RPT00_CUSTOMER_T06
			where BU = a.BU and CUSTOMER_NAME = a.CUSTOMER_NAME
		) as NET_REVENUE_USD,
		0, a.ACT_DM
	from DMS_RPT00_CUSTOMER_T03 a
	where (a.BU,a.CUSTOMER_NAME) in (
		select BU,CUSTOMER_NAME from DMS_RPT00_CUSTOMER_T02
	);
	commit;
	--(220)turnover day
	iTracePoint := 220;
	update DMS_RPT00_CUSTOMER_T07 set
		TURNOVER_DAY = ceil(nvl(INV_AMT_USD,0) / ( NET_REVENUE_USD * ORG_DM) * 365 / 12)
	where NET_REVENUE_USD != 0
	and ORG_DM != 0;
	commit;
	--(230)FORECAST
	iTracePoint := 230;
	insert into DMS_RPT00_CUSTOMER_T07 (
		BU, CUSTOMER_NAME, YYYYMM, ACTUAL_FLAG, ORG_DM,
		INV_AMT_USD, NET_REVENUE_USD, TURNOVER_DAY, DM_RATE
	)
	select a.BU, a.CUSTOMER_NAME, a.YYYYMM, 'N', a.DMS_DM,
		(select sum(nvl(INV_AMT_USD,0)) from DMS_RPT00_CUSTOMER_T05
			where BU = a.BU and CUSTOMER_NAME = a.CUSTOMER_NAME
		) as INV_AMT_USD,
		(select sum(nvl(NET_REVENUE_USD,0)) from DMS_RPT00_CUSTOMER_T06
			where BU = a.BU and CUSTOMER_NAME = a.CUSTOMER_NAME
		) as NET_REVENUE_USD,
		0, a.DMS_DM
	from DMS_RPT00_CUSTOMER_T02 a
	where (a.BU,a.CUSTOMER_NAME) in (
		select BU,CUSTOMER_NAME from DMS_RPT00_CUSTOMER_T03
	);
	commit;
	--(240) update null 為 0
	iTracePoint := 240;
	update DMS_RPT00_CUSTOMER_T07 set
		INV_AMT_USD = 0
	where nvl(INV_AMT_USD,0) = 0;
	update DMS_RPT00_CUSTOMER_T07 set
		NET_REVENUE_USD = 0
	where nvl(NET_REVENUE_USD,0) = 0;
	commit;
	--(250) 計算 DM
	iTracePoint := 250;
	for REC1 in (
		select distinct BU, CUSTOMER_NAME from DMS_RPT00_CUSTOMER_T07
	) loop
		for REC2 in (
			select YYYYMM, ACTUAL_FLAG, ORG_DM, DM_RATE, TURNOVER_DAY from DMS_RPT00_CUSTOMER_T07
			where BU = REC1.BU and CUSTOMER_NAME = REC1.CUSTOMER_NAME
			order by YYYYMM
		) loop
			if REC2.ACTUAL_FLAG = 'Y' then
				t_DM_RATE := REC2.DM_RATE;
				t_TURNOVER_DAY := REC2.TURNOVER_DAY;
			else
				if t_TURNOVER_DAY >= 30 then
					t_TURNOVER_DAY := t_TURNOVER_DAY - 30;
					update DMS_RPT00_CUSTOMER_T07 set
						DM_RATE = t_DM_RATE,
						TURNOVER_DAY = t_TURNOVER_DAY
					where BU = REC1.BU and CUSTOMER_NAME = REC1.CUSTOMER_NAME
					and YYYYMM = REC2.YYYYMM;
				else
					t_TURNOVER_DAY2 := 30 - t_TURNOVER_DAY;
					update DMS_RPT00_CUSTOMER_T07 set
						DM_RATE = round(((t_DM_RATE * t_TURNOVER_DAY) + (REC2.ORG_DM * t_TURNOVER_DAY2)) / 30,6),
						TURNOVER_DAY = 0
					where BU = REC1.BU and CUSTOMER_NAME = REC1.CUSTOMER_NAME
					and YYYYMM = REC2.YYYYMM;
					t_TURNOVER_DAY := 0;
				end if;
				commit;
			end if;
		end loop;
	end loop;


EXCEPTION
  WHEN OTHERS THEN
    cErrorText := SQLERRM() ;
    MAIL_FILE_BIDBDBADMIN(in_to_name=>'minhorng@ms.usi.com.tw',subject   => '[DMM]PL/SQL PLSQL_DMS_RPT_CUSTOMER_00 ERROR', message => '[PLSQL_DMS_RPT_CUSTOMER_00], The tracepoint is  ' || to_char(iTracePoint) || ' and ErrorText=' || cErrorText) ;
End PLSQL_DMS_RPT_CUSTOMER_00;
/

