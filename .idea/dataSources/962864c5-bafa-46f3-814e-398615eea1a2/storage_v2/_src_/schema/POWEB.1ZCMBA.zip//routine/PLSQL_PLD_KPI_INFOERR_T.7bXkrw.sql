create PROCEDURE       PLSQL_PLD_KPI_INFOERR_T (
	inCompany  in VARCHAR2,
	f_YYYYMMDD in VARCHAR2,
	t_YYYYMMDD in VARCHAR2
)
AUTHID DEFINER
is
	/*
	處理 SAP inforecord upload error log (zd187 / zd387)
	SAP dosnload program: ZRMMW468
	抓前一天資料並寄給相關人員
	*/
	iTracePoint         varchar2(3);
	cErrorText          varchar2(500);
	T_TX_DATE           varchar2(8);
BEGIN
	--(010)抓 PLD_KPI_AUDIT_INFOERR_T-TX_DATE 最大者
	iTracePoint := '010';
	T_TX_DATE := null;
	BEGIN
		select * into T_TX_DATE from (
			select max(TX_DATE) from PLD_KPI_AUDIT_INFOERR_T
			where COMPANY_CODE = inCompany
		);
	EXCEPTION
		WHEN OTHERS THEN
			T_TX_DATE := null;
	END;

	iTracePoint := '020';
	if T_TX_DATE is null then   --未發現資料
		iTracePoint := '100';
		cErrorText := 'Data not found !';
		MAIL_FILE_BIDBDBADMIN(in_to_name=>'minhorng_su@usiglobal.com',subject   => '[PLD KPI]PL/SQL PLSQL_PLD_KPI_INFOERR_T (data not found) - Company: ' || inCompany, message => '[PLSQL_PLD_KPI_INFOERR_T], The tracepoint is  ' || iTracePoint || ' and ErrorText=' || cErrorText) ;
	else
		-- 寫資料到 PLD_KPI_AUDIT_INFOERR
		iTracePoint := '200';
		delete from PLD_KPI_AUDIT_INFOERR
			where COMPANY_CODE = inCompany
			and TX_DATE = T_TX_DATE;
		commit;
		iTracePoint := '210';
		insert into PLD_KPI_AUDIT_INFOERR (
				COMPANY_CODE, TCODE, PART_NO, VENDOR_CODE, TX_DATE, TX_TIME,
				MP_CODE, MP_NAME, MTL_GRP, SOURCER_ID, SOURCER_NAME,
				STATUS_1, STATUS_2, MSG, PLANT
			)
			select COMPANY_CODE, TCODE, PART_NO, VENDOR_CODE, TX_DATE, TX_TIME,
				MP_CODE, MP_NAME, MTL_GRP, SOURCER_ID, SOURCER_NAME,
				STATUS_1, STATUS_2, MSG, PLANT
			from PLD_KPI_AUDIT_INFOERR_T
			where COMPANY_CODE = inCompany
			and TX_DATE = T_TX_DATE;
		commit;

		-- 清除temp table
		iTracePoint := '999';
		delete from PLD_KPI_AUDIT_INFOERR_T
			where COMPANY_CODE = inCompany;
		commit;
	end if;

EXCEPTION
	WHEN OTHERS THEN
		cErrorText := SQLERRM();
		MAIL_FILE_BIDBDBADMIN(in_to_name=>'minhorng_su@usiglobal.com',subject   => '[PLD KPI]PL/SQL PLSQL_PLD_KPI_INFOERR_T ERROR - Company: ' || inCompany, message => '[PLSQL_PLD_KPI_INFOERR_T], The tracepoint is  ' || iTracePoint || ' and ErrorText=' || cErrorText) ;
END PLSQL_PLD_KPI_INFOERR_T;
/

