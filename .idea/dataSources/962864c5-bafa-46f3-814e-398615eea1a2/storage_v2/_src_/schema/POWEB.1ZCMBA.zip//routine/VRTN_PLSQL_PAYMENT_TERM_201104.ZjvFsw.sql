create PROCEDURE         "VRTN_PLSQL_PAYMENT_TERM_201104" IS
  /*
    每月一號執行一次
    1. 抓 VRTN_MAP020_RATE_INDEX - 各階層的分數比率
    2. 抓 PLD_KPI_IR_DETAIL 資料 ( 計算 Payment Term )
    3. 抓 VRTN_MAP040_RANGE_SCORE - 計算 Payment Term 天數換算分數
    4. 將計算後值放到 VRTN_MAP030_SUMMARY_GRAD
    (VRTN_MAP030_SUMMARY_GRAD-L1,L2,L3,L4 參考文件 VRTN_MAP060_LEVEL_DESC)
  *  
  * 2010/06/18 Change add UG SZ- 1400/UG TW -1700 'CC' -SAI015943
  */

  vPROCEE_YYYYMM             varchar2(6);
  vPERCENTAGE_L1             VRTN_MAP020_RATE_INDEX.PERCENTAGE%TYPE;
  vPERCENTAGE_L2             VRTN_MAP020_RATE_INDEX.PERCENTAGE%TYPE;
  vPERCENTAGE_L3             VRTN_MAP020_RATE_INDEX.PERCENTAGE%TYPE;
  vPERCENTAGE_L4             VRTN_MAP020_RATE_INDEX.PERCENTAGE%TYPE;
  vSCORE                     VRTN_MAP040_RANGE_SCORE.SCORES%TYPE;
  vSITE                      varchar2(4);

  iTracePoint                varchar2(100);
  cErrorText                 varchar2(500);

BEGIN
  --抓上個月份
  iTracePoint := '100';
  --vPROCEE_YYYYMM := TO_CHAR(ADD_MONTHS(SYSDATE, -2), 'YYYYMM');
  vPROCEE_YYYYMM  := '202007';

  --抓各階分數
  iTracePoint := '200';
  vPERCENTAGE_L1 := null;
  vPERCENTAGE_L2 := null;
  vPERCENTAGE_L3 := null;
  vPERCENTAGE_L4 := null;
  vSITE := null;
  vSCORE := null;

  for REC1 in ( select LEVEL_S, PERCENTAGE from VRTN_MAP020_RATE_INDEX
                 where INDEX_KEY = 'COST' and TYPE = 'CC' ) loop
    if REC1.LEVEL_S = 'L1' then
      iTracePoint := '210';
      vPERCENTAGE_L1 := REC1.PERCENTAGE;
    elsif REC1.LEVEL_S = 'L2' then
      iTracePoint := '220';
      vPERCENTAGE_L2 := REC1.PERCENTAGE;
    elsif REC1.LEVEL_S = 'L3' then
      iTracePoint := '230';
      vPERCENTAGE_L3 := REC1.PERCENTAGE;
    elsif REC1.LEVEL_S = 'L4' then
      iTracePoint := '240';
      vPERCENTAGE_L4 := REC1.PERCENTAGE;
    end if;
  end loop;

  if vPERCENTAGE_L1 is null or vPERCENTAGE_L2 is null or vPERCENTAGE_L3 is null or vPERCENTAGE_L4 is null then
    --若沒抓到資料則寄 error mail
    iTracePoint := '250';
    cErrorText := 'vPERCENTAGE_L1 is ' || nvl(vPERCENTAGE_L1,'null') || ',vPERCENTAGE_L2 is ' || nvl(vPERCENTAGE_L2,'null') || ',vPERCENTAGE_L3 is ' || nvl(vPERCENTAGE_L3,'null') || ',vPERCENTAGE_L4 is ' || nvl(vPERCENTAGE_L4,'null');
    MAIL_FILE_BIDBDBADMIN(in_to_name => 'shuchin_lin@usiglobal.com', subject => '[VRTN] PL/SQL VRTN_PLSQL_PAYMENT_TERM ERROR', message => '[VRTN_PLSQL_PAYMENT_TERM], The tracepoint is  ' || iTracePoint || 'and ErrorText=' || cErrorText) ;
  else
    --先清舊的資料以避免重覆
    iTracePoint := '300-' || vPROCEE_YYYYMM;
    delete from VRTN_MAP030_SUMMARY_GRAD
     where TYPE = 'CC' and YYYY = substr(vPROCEE_YYYYMM,1,4) and MM = substr(vPROCEE_YYYYMM,5,2);
    commit;

    --放入上月分數
    iTracePoint := '400';
    for REC1 in ( SELECT AL1.COMPANY_CODE as SITE, AL1.COMPANY_CODE, AL1.VENDOR_ID, AL1.MTL_GROUP, AL2.YYYY, AL2.MM, AL2.QUARTER,
                         round( SUM ( (AL3.DAY + AL3.ADD_DAY) * AL1.IR_AMT_TWD ) / SUM( AL1.IR_AMT_TWD ), 0 ) as PAYMENT_TERM
                    FROM POWEB.PLD_KPI_IR_DETAIL AL1, POWEB.DIMENSION_DATE AL2, POWEB.PLD_KPI_PAYMENT_TERM_DAY AL3
                   WHERE AL1.IR_DATE=AL2.DATE_KEY
                     AND AL3.COMPANY_CODE=AL1.COMPANY_CODE
                     AND AL3.PAYMENT_KEY=AL1.PAYMENT_IR
                --   AND AL1.DEPT_CODE_MP NOT IN ('JP', 'UI')
                --   AND AL1.DEPT_CODE_MP2 IN ('NK', 'TT', 'SZ', 'SH')
                     AND (AL1.DEPT_CODE_MP NOT IN ('JP','UI') OR AL1.DEPT_CODE_MP IN NVL(AL1.DEPT_CODE_MP,' '))
                     AND AL1.DEPT_CODE_MP2 IN ('NK', 'TT', 'SZ', 'SH',NVL(AL1.DEPT_CODE_MP,' '))                    
                     AND AL2.YYYYMM = vPROCEE_YYYYMM
                     AND AL1.ACCOUNT_ASSIGNMENT IS NULL
                 --    AND AL1.VENDOR_ID = '0000013609' 0000013627	001
                     AND NOT EXISTS (SELECT AL8.VENDOR_ID FROM POWEB.KPI_MAP015_VEND_RELATED_PARTY AL8
                                                WHERE AL8.START_DATE <= SYSDATE AND AL8.END_DATE >= SYSDATE
                                                  AND AL8.COMPANY_CODE=AL1.COMPANY_CODE
                                                  AND AL8.VENDOR_ID=AL1.VENDOR_ID)
                GROUP BY AL1.COMPANY_CODE, AL1.COMPANY_CODE, AL1.VENDOR_ID, AL1.MTL_GROUP, AL2.YYYY, AL2.MM, AL2.QUARTER ) loop

	  --台灣幫海外 Site 買的不抓
    --  if REC1.COMPANY_CODE = '1100' AND ( REC1.SITE = '1200' OR REC1.SITE = '1500' OR REC1.SITE = '1400' ) then
      --if REC1.COMPANY_CODE = '1100' AND ( REC1.SITE = '1200' OR REC1.SITE = '1500' ) then
      --ADD REC1.PAYMENT_TERM = ''
      if ( REC1.COMPANY_CODE = '1100' AND ( REC1.SITE = '1200' OR REC1.SITE = '1500' ) ) OR REC1.PAYMENT_TERM is null then
         iTracePoint := '405';
         cErrorText := REC1.SITE || '-' || REC1.VENDOR_ID || '-' || REC1.COMPANY_CODE || '-' || vPROCEE_YYYYMM || ' not insert vendor !';

      else

        --計算 Payment Term 分數
        SELECT SCORES INTO vSCORE
          FROM VRTN_MAP040_RANGE_SCORE
         WHERE RANGE_TYPE = 'CC'
           AND RANGE_FROM <= REC1.PAYMENT_TERM
           AND RANGE_TO >= REC1.PAYMENT_TERM;

        if vSCORE is null then
           --若沒抓到資料則寄 error mail
           iTracePoint := '410';
           cErrorText := REC1.SITE || '-' || REC1.VENDOR_ID || '-' || vPROCEE_YYYYMM || ' vSCORE is null';
           MAIL_FILE_BIDBDBADMIN(in_to_name => 'shuchin_lin@usiglobal.com', subject => '[VRTN] PL/SQL VRTN_PLSQL_PAYMENT_TERM ERROR', message => '[VRTN_PLSQL_PAYMENT_TERM], The tracepoint is  ' || iTracePoint || 'and ErrorText=' || cErrorText) ;
        else
          --放到 VRTN_MAP030_SUMMARY_GRAD
          iTracePoint := '420-' || REC1.SITE || '-' || REC1.VENDOR_ID || '-' || vPROCEE_YYYYMM || vSCORE;
          insert into VRTN_MAP030_SUMMARY_GRAD (
                 SITE, LIFNR, MATGROUP, TYPE, YYYY, MM, QUARTER, BUKRS, L1, GRADE_L1, L2, GRADE_L2, L3, GRADE_L3, L4, GRADE_L4
               ) values (
                 REC1.SITE,
                 REC1.VENDOR_ID,
                 REC1.MTL_GROUP,
                 'CC',
                 REC1.YYYY,
                 REC1.MM,
                 REC1.QUARTER,
                 REC1.COMPANY_CODE,
                 'S0',
                 round(vSCORE * vPERCENTAGE_L1, 5),
                 'C0',
                 round(vSCORE * vPERCENTAGE_L2, 5),
                 'CC',
                 round(vSCORE * vPERCENTAGE_L3, 5),
                 'CC',
                 round(vSCORE * vPERCENTAGE_L4, 5)
               );
          commit;
        end if;
	  end if;
    end loop;
  end if;

EXCEPTION
  When OTHERS Then
    --有錯誤產生則寄mail
    cErrorText := SQLERRM();
    MAIL_FILE_BIDBDBADMIN(in_to_name => 'shuchin_lin@usiglobal.com', subject => '[VRTN] PL/SQL VRTN_PLSQL_PAYMENT_TERM ERROR', message => '[VRTN_PLSQL_PAYMENT_TERM], The tracepoint is  ' || iTracePoint || 'and ErrorText=' || cErrorText) ;
END;
/

