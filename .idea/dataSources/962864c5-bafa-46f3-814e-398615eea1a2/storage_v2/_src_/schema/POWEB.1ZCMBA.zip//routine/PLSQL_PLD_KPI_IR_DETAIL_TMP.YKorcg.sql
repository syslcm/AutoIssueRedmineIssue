create PROCEDURE       PLSQL_PLD_KPI_IR_DETAIL_TMP (
  inCOMPANY in VARCHAR2,
  inFrDATE in VARCHAR2,
  inToDATE in VARCHAR2
)
AUTHID DEFINER
is
  --處理 RFQ_MONTH_IR
  CURSOR C_RFQ_MONTH_IR is
    Select distinct A.COMPANY_CODE, A.IR_DOC_NO, A.IR_DOC_ITEM, TO_CHAR(A.IR_DATE,'YYYYMMDD') as IR_DATE,
                    A.PLANT_CODE, A.PART_NO, A.VENDOR_ID, A.MTL_GROUP, A.PART_QTY, A.PART_AMOUNT,
                    A.PART_CURRENCY, A.RATE, A.LOCAL_AMT, A.PROFIT_CENTER, A.MFR_NAME, A.MFR_PART, A.SLOC,
                    A.BUYER_CODE, A.PAYMENT_IR, A.ACCOUNT_ASSIGNMENT,
                    B.PAYMENT_KEY
      from RFQ_MONTH_IR A, RFQ_VENDOR_MASTER B
     Where A.COMPANY_CODE = inCOMPANY
	   and A.COMPANY_CODE = B.COMPANY_CODE
       and A.VENDOR_ID = B.VENDOR_ID
       and TO_CHAR(A.IR_DATE,'YYYYMMDD') >= inFrDATE
       and TO_CHAR(A.IR_DATE,'YYYYMMDD') <= inToDATE;

  --處理 TW DEPT_CODE_MP
  CURSOR C_Z_POWEB_050A is
    Select distinct COMPANY_CODE, BUYER_CODE, DEPT_NAME_KPI
      from Z_POWEB_050A
     Where COMPANY_CODE = '1100';

  --處理 DEPT_CODE_SP
  CURSOR C_DEPT_CODE_SP is
    Select A.SP_CODE, B.MAT_GROUP
      from RFQ_SOURCER_DATA A, RFQ_MTLGROUP_SOURCER B
     where A.SOURCER_ID = B.WORKER_ID
       and A.SOURCER_ID is Not null
       and B.MAT_GROUP is Not null
     Group by A.SP_CODE, B.MAT_GROUP;

  --處理 UI
  CURSOR C_PLD_KPI_VENDOR_UI is
    Select COMPANY_CODE, VENDOR_ID
      from PLD_KPI_VENDOR_UI
     where COMPANY_CODE = inCOMPANY
       and VENDOR_ID is Not Null
     Group by COMPANY_CODE, VENDOR_ID;

  --處理 PLD_KPI_CORE_SUPPLIER
  CURSOR C_PLD_KPI_CORE_SUPPLIER is
    Select MAT_GROUP, MFR_NAME
      from PLD_KPI_CORE_SUPPLIER
     Group by MAT_GROUP, MFR_NAME;

  --處理 PLD_KPI_VENDOR_MAPPING
  CURSOR C_PLD_KPI_VENDOR_MAPPING is
    Select COMPANY_CODE, VENDOR_ID, COMPANY_CODE_ORG, VENDOR_ID_ORG
      from PLD_KPI_VENDOR_MAPPING
	  where COMPANY_CODE = inCOMPANY
     Group by COMPANY_CODE, VENDOR_ID, COMPANY_CODE_ORG, VENDOR_ID_ORG;

   nCOUNT              NUMBER(5);
   nDEPT_CODE_MP       PLD_KPI_IR_DETAIL.DEPT_CODE_MP%TYPE;
   nIR_AMT_USD         PLD_KPI_IR_DETAIL.IR_AMT_USD%TYPE;
   nIR_AMT_TWD         PLD_KPI_IR_DETAIL.IR_AMT_TWD%TYPE;
   nER_CNY_TWD         EGI0020_EXCHANGE_RATE.EXCHANGE_RATE%TYPE;
   nER_JPY_TWD         EGI0020_EXCHANGE_RATE.EXCHANGE_RATE%TYPE;
   nER_MXN_TWD         EGI0020_EXCHANGE_RATE.EXCHANGE_RATE%TYPE;
   nER_USD_TWD         EGI0020_EXCHANGE_RATE.EXCHANGE_RATE%TYPE;
   nGVC                GVM032_GLOBAL_VENDOR_ITEM.GLOBAL_VENDOR_CODE%TYPE;
   cErrorText          varchar2(500);
   iTracePoint         varchar2(3);

 BEGIN
   /*
   -- 清舊資料
   iTracePoint := '900';
   delete from PLD_KPI_IR_DETAIL where IR_DATE <= '20060331';
   commit;
   delete from PLD_KPI_IR_DETAIL where IR_DATE <= '20060630';
   commit;
   delete from PLD_KPI_IR_DETAIL where IR_DATE <= '20060930';
   commit;
   delete from PLD_KPI_IR_DETAIL where IR_DATE <= '20061231';
   commit;
   */

   --Delete PLD_KPI_IR_DETAIL 避免重複
   iTracePoint := '000';
   Delete From PLD_KPI_IR_DETAIL
         Where COMPANY_CODE = inCOMPANY
		   and IR_DATE >= inFrDATE
           and IR_DATE <= inToDATE;
   Commit;

   --抓匯率 CNY -> TWD
   iTracePoint := '001';
   nER_CNY_TWD := Null;
   Select * into nER_CNY_TWD From (
     Select EXCHANGE_RATE from EGI0020_EXCHANGE_RATE
      where (VALID_FROM_DATEYYMM || VALID_FROM_DATEDD) <= inToDATE
        and TRIM(FROM_CURRENCY) = 'CNY'
        and TRIM(TO_CURRENCY) = 'TWD'
      order by (VALID_FROM_DATEYYMM || VALID_FROM_DATEDD) Desc
   ) Where ROWNUM <= 1;

   --抓匯率 JPY -> TWD
   iTracePoint := '002';
   nER_JPY_TWD := Null;
   Select * into nER_JPY_TWD From (
     Select EXCHANGE_RATE from EGI0020_EXCHANGE_RATE
      where (VALID_FROM_DATEYYMM || VALID_FROM_DATEDD) <= inToDATE
        and TRIM(FROM_CURRENCY) = 'JPY'
        and TRIM(TO_CURRENCY) = 'TWD'
      order by (VALID_FROM_DATEYYMM || VALID_FROM_DATEDD) Desc
   ) Where ROWNUM <= 1;

   --抓匯率 MXN -> TWD
   iTracePoint := '003';
   nER_MXN_TWD := Null;
   Select * into nER_MXN_TWD From (
     Select EXCHANGE_RATE from EGI0020_EXCHANGE_RATE
      where (VALID_FROM_DATEYYMM || VALID_FROM_DATEDD) <= inToDATE
        and TRIM(FROM_CURRENCY) = 'MXN'
        and TRIM(TO_CURRENCY) = 'TWD'
      order by (VALID_FROM_DATEYYMM || VALID_FROM_DATEDD) Desc
   ) Where ROWNUM <= 1;

   --抓匯率 USD -> TWD
   iTracePoint := '004';
   nER_USD_TWD := Null;
   Select * into nER_USD_TWD From (
     Select EXCHANGE_RATE from EGI0020_EXCHANGE_RATE
      where (VALID_FROM_DATEYYMM || VALID_FROM_DATEDD) <= inToDATE
        and TRIM(FROM_CURRENCY) = 'USD'
        and TRIM(TO_CURRENCY) = 'TWD'
      order by (VALID_FROM_DATEYYMM || VALID_FROM_DATEDD) Desc
   ) Where ROWNUM <= 1;

   --處理 C_RFQ_MONTH_IR
   iTracePoint := '005';
   nCOUNT := 0;
   FOR REC1 in C_RFQ_MONTH_IR LOOP
     --處理 IR_AMT_USD / IR_AMT_TWD / DEPT_CODE_MP
	 iTracePoint := '010';
     If REC1.COMPANY_CODE = '1100' or REC1.COMPANY_CODE = '1700' Then
	   iTracePoint := '011';
       nIR_AMT_TWD := REC1.LOCAL_AMT;
       nDEPT_CODE_MP := Null;
	   If REC1.COMPANY_CODE = '1700' Then
         nDEPT_CODE_MP := 'TW';
	   End If;
       If REC1.PLANT_CODE = '1210' and REC1.SLOC = '3001' Then
         nDEPT_CODE_MP := 'SZ';
       ElsIf REC1.PLANT_CODE = '1210' and REC1.SLOC = '3010' Then
         nDEPT_CODE_MP := 'SH';
       ElsIf REC1.PLANT_CODE = '1320' and REC1.SLOC = '3000' Then
         nDEPT_CODE_MP := 'JP';
       ElsIf REC1.PLANT_CODE = '2310' and REC1.SLOC = '3000' Then
         nDEPT_CODE_MP := 'MX';
       End If;
     ElsIf REC1.COMPANY_CODE = '1200' or REC1.COMPANY_CODE = '1400' Then
	   iTracePoint := '012';
       nIR_AMT_TWD := ROUND(REC1.LOCAL_AMT * nER_CNY_TWD, 5);
       nDEPT_CODE_MP := 'SZ';
     ElsIf REC1.COMPANY_CODE = '1300' Then
	   iTracePoint := '013';
       nIR_AMT_TWD := ROUND(REC1.LOCAL_AMT * nER_JPY_TWD, 5);
       nDEPT_CODE_MP := 'JP';
     ElsIf REC1.COMPANY_CODE = '1500' Then
	   iTracePoint := '015';
       nIR_AMT_TWD := ROUND(REC1.LOCAL_AMT * nER_CNY_TWD, 5);
       nDEPT_CODE_MP := 'SH';
     ElsIf REC1.COMPANY_CODE = '2300' Then
	   iTracePoint := '023';
       nIR_AMT_TWD := ROUND(REC1.LOCAL_AMT * nER_MXN_TWD, 5);
       nDEPT_CODE_MP := 'MX';
     ElsIf REC1.COMPANY_CODE = '4100' Then
	   iTracePoint := '041';
       nIR_AMT_TWD := ROUND(REC1.LOCAL_AMT * nER_CNY_TWD, 5);
       nDEPT_CODE_MP := 'KS';
     End If;
	 iTracePoint := '030';
     nIR_AMT_USD := ROUND(nIR_AMT_TWD / nER_USD_TWD, 5);
	 iTracePoint := '040';
	 BEGIN
	   iTracePoint := '050';
	   nGVC := null;
       select * into nGVC from (
	     select GLOBAL_VENDOR_CODE from GVM032_GLOBAL_VENDOR_ITEM
         Where COMPANY_CODE = REC1.COMPANY_CODE
         and SAP_VENDOR_CODE = REC1.VENDOR_ID
	   ) where rownum <= 1;
     EXCEPTION
	    WHEN OTHERS THEN
		  nGVC := null;
	 END;
	 iTracePoint := '060';
     Insert into PLD_KPI_IR_DETAIL
          ( COMPANY_CODE, IR_DOC_NO, IR_DOC_ITEM, IR_DATE, PLANT_CODE, PART_NO,
            VENDOR_ID, MTL_GROUP, PART_QTY, PART_AMOUNT, PART_CURRENCY, RATE,
            LOCAL_AMT, PROFIT_CENTER, MFR_NAME, MFR_PART, MTL_SUB_GROUP, DEPT_CODE_MP,
            IR_AMT_USD, IR_AMT_TWD, PAYMENT_KEY, SLOC, BUYER_CODE, PAYMENT_IR, ACCOUNT_ASSIGNMENT, CREATE_DATE,
            GLOBAL_VENDOR_CODE, DEPT_CODE_MP2 )
          values ( REC1.COMPANY_CODE,
                   REC1.IR_DOC_NO,
                   REC1.IR_DOC_ITEM,
                   REC1.IR_DATE,
                   REC1.PLANT_CODE,
                   REC1.PART_NO,
                   REC1.VENDOR_ID,
                   REC1.MTL_GROUP,
                   REC1.PART_QTY,
                   REC1.PART_AMOUNT,
                   REC1.PART_CURRENCY,
                   REC1.RATE,
                   REC1.LOCAL_AMT,
                   REC1.PROFIT_CENTER,
                   REC1.MFR_NAME,
                   REC1.MFR_PART,
                   REC1.MTL_GROUP,
                   nDEPT_CODE_MP,
                   nIR_AMT_USD,
                   nIR_AMT_TWD,
                   REC1.PAYMENT_KEY,
                   REC1.SLOC,
                   REC1.BUYER_CODE,
                   REC1.PAYMENT_IR,
                   REC1.ACCOUNT_ASSIGNMENT,
                   SYSDATE,
                   nGVC,
                   nDEPT_CODE_MP
                 );
     Commit;
   END LOOP;

   --處理 TW / DEPT_CODE_MP
   iTracePoint := '100';
   nCOUNT := 0;
   if inCOMPANY = '1100' then
   FOR REC1 in C_Z_POWEB_050A LOOP
     Update PLD_KPI_IR_DETAIL
        set DEPT_CODE_MP = REC1.DEPT_NAME_KPI,
            DEPT_CODE_MP2 = DECODE(SUBSTRB(BUYER_CODE,1,1),'1','TT','NK')
      Where COMPANY_CODE = REC1.COMPANY_CODE
        and BUYER_CODE = REC1.BUYER_CODE
        and ( DEPT_CODE_MP is NULL or DEPT_CODE_MP = '' );
     Commit;
   END LOOP;
   end if;

   --DEPT_CODE_SP
   iTracePoint := '200';
   nCOUNT := 0;
   FOR REC1 in C_DEPT_CODE_SP LOOP
     Update PLD_KPI_IR_DETAIL
        Set DEPT_CODE_SP = REC1.SP_CODE
      where COMPANY_CODE = inCOMPANY
	    and MTL_GROUP = REC1.MAT_GROUP
        and ( DEPT_CODE_SP is Null or DEPT_CODE_SP = '' );
     Commit;
   END LOOP;

   --處理 UI
   iTracePoint := '300';
   nCOUNT := 0;
   FOR REC1 in C_PLD_KPI_VENDOR_UI LOOP
     Update PLD_KPI_IR_DETAIL
        set DEPT_CODE_MP = 'UI',
            DEPT_CODE_SP = 'UI',
            DEPT_CODE_MP2 = 'UI'
      Where COMPANY_CODE = inCOMPANY
	    and COMPANY_CODE = REC1.COMPANY_CODE
        and VENDOR_ID = REC1.VENDOR_ID;
     Commit;
   END LOOP;

   --PLD_KPI_CORE_SUPPLIER
   iTracePoint := '400';
   nCOUNT := 0;
   FOR REC1 in C_PLD_KPI_CORE_SUPPLIER LOOP
     Update PLD_KPI_IR_DETAIL
        Set CORE_SUPPLIER = 'Y'
      where COMPANY_CODE = inCOMPANY
	    and MTL_GROUP = REC1.MAT_GROUP
        and MFR_NAME = REC1.MFR_NAME
        and ( CORE_SUPPLIER is Null or CORE_SUPPLIER = '' );
     Commit;
   END LOOP;

   iTracePoint := '500';
   Update PLD_KPI_IR_DETAIL
      Set CORE_SUPPLIER = 'N'
    where COMPANY_CODE = inCOMPANY
	and CORE_SUPPLIER = '';
   Commit;

   iTracePoint := '510';
   Update PLD_KPI_IR_DETAIL
      Set CORE_SUPPLIER = 'N'
    where COMPANY_CODE = inCOMPANY
	and CORE_SUPPLIER is null;
   Commit;

   --PLD_KPI_VENDOR_MAPPING
   iTracePoint := '600';
   nCOUNT := 0;
   FOR REC1 in C_PLD_KPI_VENDOR_MAPPING LOOP
     Update PLD_KPI_IR_DETAIL
        Set COMPANY_CODE_NEW = REC1.COMPANY_CODE,
            VENDOR_ID_NEW = REC1.VENDOR_ID
      where COMPANY_CODE = inCOMPANY
	    and COMPANY_CODE = REC1.COMPANY_CODE_ORG
        and VENDOR_ID = REC1.VENDOR_ID_ORG
        and ( COMPANY_CODE_NEW is Null or COMPANY_CODE_NEW = '' )
        and ( VENDOR_ID_NEW is Null or VENDOR_ID_NEW = '' );
     Commit;
   END LOOP;

   iTracePoint := '700';
   Update PLD_KPI_IR_DETAIL
      Set COMPANY_CODE_NEW = COMPANY_CODE,
          VENDOR_ID_NEW = VENDOR_ID
    where COMPANY_CODE = inCOMPANY
	  and ( COMPANY_CODE_NEW is Null or COMPANY_CODE_NEW = '' )
      and ( VENDOR_ID_NEW is Null or VENDOR_ID_NEW = '' );
   Commit;

 EXCEPTION
   WHEN OTHERS THEN
	  cErrorText := substrb(SQLERRM(),1,300);
	  rollback;
	  MAIL_FILE_BIDBDBADMIN(in_to_name=>'minhorng_su@usiglobal.com',subject   => '[PLD KPI]PL/SQL PLSQL_PLD_KPI_IR_DETAIL_TMP ERROR', message => '[PLSQL_PLD_KPI_IR_DETAIL_TMP], The tracepoint is  ' || iTracePoint || ' and ErrorText=' || cErrorText) ;
 END PLSQL_PLD_KPI_IR_DETAIL_TMP;
/

