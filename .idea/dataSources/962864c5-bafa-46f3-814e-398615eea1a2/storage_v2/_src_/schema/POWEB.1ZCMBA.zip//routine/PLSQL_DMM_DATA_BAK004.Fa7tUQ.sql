create PROCEDURE "PLSQL_DMM_DATA_BAK004" (
  b_YYYYMMDD    in VARCHAR2
)
/*
只處理 DMM_RPT004_BOMMAC_D
*/
is
    iTracePoint           integer ;
    cErrorText            varchar2(500) ;
    cCHK1                 varchar2(100) ;
    cCHK2                 varchar2(100) ;
    b_YYYYWK              varchar2(6);
BEGIN
    iTracePoint := 0;
    cErrorText := ' ';
    cCHK1 := ' ';
    cCHK2 := ' ';
    
    b_YYYYWK := 'X';
    BEGIN
        select * into b_YYYYWK from (
            select YYYYWW from DIMENSION_DATE where DATE_KEY = b_YYYYMMDD
        ) where rownum <= 1;
    EXCEPTION
        WHEN OTHERS THEN
            b_YYYYWK := 'X';
    END;
    
  if b_YYYYMMDD > '20110701' or b_YYYYWK = 'X' then
    MAIL_FILE_BIDBDBADMIN(in_to_name=>'minhorng@ms.usi.com.tw',subject   => '[DMM]PL/SQL PLSQL_DMM_DATA_BAK004 ERROR' , message => '[PLSQL_DMM_DATA_BAK004], DATE ErrorText=' || b_YYYYMMDD) ;
  else
    -- DMM_RPT004_BOMMAC_D
    iTracePoint := 240;
    cCHK1 := ' ';
    cCHK2 := ' ';
    for rec2 in (
        select a.COMPANY_CODE, a.PLANT, a.FG, b.DATE_KEY
        from DMM_UPL001_SELLING_BACKUP a, DIMENSION_DATE b
        where a.COMPANY_CODE >= '0000'
        and a.TO_DATE >= '20110101'
        and b.DATE_KEY <= b_YYYYMMDD
        and b.PDM_DATE >= (to_date(b_YYYYMMDD,'yyyymmdd') - 31)
        group by a.COMPANY_CODE, a.PLANT, a.FG, b.DATE_KEY
        order by COMPANY_CODE desc, PLANT, FG, DATE_KEY desc
    ) loop
        iTracePoint := 241;
        cCHK2 := rec2.COMPANY_CODE || ':' || rec2.PLANT || ':' || rec2.FG || ':' || rec2.DATE_KEY;
        iTracePoint := 242;
        delete from DMM_RPT004_BOMMAC_D 
            where DATE_KEY = rec2.DATE_KEY and COMPANY_CODE = rec2.COMPANY_CODE
            and PLANT = rec2.PLANT and FG = rec2.FG;
        commit;
    end loop;
    --
  end if;
  
  --EXECUTE IMMEDIATE 'analyze table DMM_RPT004_BOMMAC_D compute statistics for all indexes for all columns';

EXCEPTION
  WHEN OTHERS THEN
    cErrorText := trim(cCHK2) || '>' || SQLERRM() ;
    rollback;
    MAIL_FILE_BIDBDBADMIN(in_to_name=>'minhorng@ms.usi.com.tw',subject   => '[DMM]PL/SQL PLSQL_DMM_DATA_BAK004 ERROR' , message => '[PLSQL_DMM_DATA_BAK004], The tracepoint is  ' || to_char(iTracePoint) || ' and ErrorText=' || cErrorText) ;
End PLSQL_DMM_DATA_BAK004;
/

