create PROCEDURE       "VQA_PLSQL_MFR_DATA"
AUTHID DEFINER
IS
   /*--------------------------------------------------------------*
      CREATE DATE:  2008/2/257
      PLSQL      :  VQA_PLSQL_MFR_DATA
      Author     :  Shuya
      Purpase    :  每月執行一次
   *---------------------------------------------------------------*/
   vvendor_code       vqa_010_irr_weekly.vendor_code%TYPE;
   vcompany_code      vqa_010_irr_weekly.company_code%TYPE;
   vprocee_yyyymmdd   VARCHAR2 (8);
   vprocee_yyyymm     VARCHAR2 (6);
   itracepoint        VARCHAR2 (100);
   cerrortext         VARCHAR2 (500);
BEGIN
   itracepoint := '000';

   DELETE FROM vqa_pdm_mfr_data;

   INSERT INTO vqa_pdm_mfr_data
      SELECT   trim(mfr.NAME), p2.text01 eng_name, p2.text02 local_name,
               p2.date01 entry_date,
               (SELECT description
                  FROM agile.NODETABLE@pdm
                 WHERE id=mfr.status) status,
               p2.text12 qpa, p2.text11 qsa, p2.text13 gpa, '', mfr.contact,
               mfr.phone, mfr.email, mfr.address
          FROM agile.manufacturers@pdm mfr, agile.page_two@pdm p2
         WHERE mfr.ID = p2.ID AND mfr.NAME IS NOT NULL
      ORDER BY NAME;

   COMMIT;
   mail_file_bidbdbadmin
              (in_to_name      => 'shuya_chen@usiglobal.com',
               subject         => '[VQA] PL/SQL VQA_PLSQL_MFR_DATA Succeed',
               MESSAGE         =>    '[VQA_PLSQL_MFR_DATA], The total count is  '
                                  || TO_CHAR (itracepoint)
              );
EXCEPTION
   WHEN OTHERS
   THEN
      --有錯誤產生則寄mail
      cerrortext := SQLERRM ();
      mail_file_bidbdbadmin
                 (in_to_name      => 'shuya_chen@usiglobal.com',
                  subject         => '[VQA] PL/SQL VQA_PLSQL_MFR_DATA ERROR',
                  MESSAGE         =>    '[VQA_PLSQL_MFR_DATA], The tracepoint is  '
                                     || itracepoint
                                     || ' and ErrorText= '
                                     || cerrortext
                 );
END vqa_plsql_mfr_data;
/

