create PROCEDURE         "VRTN_PLSQL_SUM5_LOC_MM_org" AUTHID DEFINER
IS
  /*
    每月一號執行一次
	2007/08/17 Susan modify add DH,DE Default 0
	2007/08/21 Susan modify for QC 正分
	2007/08/31 Susan modify for QA Default 70分
  */

  vYYYY                      varchar2(4);
  vMM                        varchar2(2);

  Q0_VALUE                   VRTN_MAP060_LEVEL_DESC.VALUE%TYPE;
  QA_VALUE                   VRTN_MAP060_LEVEL_DESC.VALUE%TYPE;
  QB_VALUE                   VRTN_MAP060_LEVEL_DESC.VALUE%TYPE;
  QC_VALUE                   VRTN_MAP060_LEVEL_DESC.VALUE%TYPE;
  QD_VALUE                   VRTN_MAP060_LEVEL_DESC.VALUE%TYPE;
  C0_VALUE                   VRTN_MAP060_LEVEL_DESC.VALUE%TYPE;
  CA_VALUE                   VRTN_MAP060_LEVEL_DESC.VALUE%TYPE;
  CB_VALUE                   VRTN_MAP060_LEVEL_DESC.VALUE%TYPE;
  CC_VALUE                   VRTN_MAP060_LEVEL_DESC.VALUE%TYPE;
  CD_VALUE                   VRTN_MAP060_LEVEL_DESC.VALUE%TYPE;
  D0_VALUE                   VRTN_MAP060_LEVEL_DESC.VALUE%TYPE;
  D1_VALUE                   VRTN_MAP060_LEVEL_DESC.VALUE%TYPE;
  D2_VALUE                   VRTN_MAP060_LEVEL_DESC.VALUE%TYPE;
  D3_VALUE                   VRTN_MAP060_LEVEL_DESC.VALUE%TYPE;
  DE_VALUE                   VRTN_MAP060_LEVEL_DESC.VALUE%TYPE;
  DF_VALUE                   VRTN_MAP060_LEVEL_DESC.VALUE%TYPE;
  DG_VALUE                   VRTN_MAP060_LEVEL_DESC.VALUE%TYPE;
  DH_VALUE                   VRTN_MAP060_LEVEL_DESC.VALUE%TYPE;
  DI_VALUE                   VRTN_MAP060_LEVEL_DESC.VALUE%TYPE;
  DJ_VALUE                   VRTN_MAP060_LEVEL_DESC.VALUE%TYPE;

  iTracePoint                varchar2(100);
  cErrorText                 varchar2(500);

BEGIN
  iTracePoint := '000';
  select * into vYYYY, vMM from (
    select trim(to_char(add_months(SYSDATE,-1), 'YYYY')), trim(to_char(add_months(SYSDATE,-1), 'MM'))
      from dual
  );

  iTracePoint := '100';  --刪除 VRTN_SUM11_MM_MATGP
  delete from VRTN_SUM11_MM_MATGP
   where YYYY = vYYYY
     and MM = vMM;
  commit;

  iTracePoint := '110';
  insert into VRTN_SUM11_MM_MATGP ( SITE, VENDOR, MATGROUP, YYYY, MM, GV_VENDOR, QUARTER, BUKRS, AMOUNT, DATE_TIME,
                                    QB_GRADE, QC_GRADE, QD_GRADE, CA_GRADE, CB_GRADE, DH_GRADE, DE_GRADE, QA_GRADE )
     select SITE, VENDOR, MATGROUP, YYYY, MM, GV_VENDOR, QUARTER, BUKRS, AMOUNT, to_char(SYSDATE, 'yyyymmddhh24miss') as DATE_TIME,
            100, 100, 70, 60, 60, 0, 0,70
       from VRTN_SUM01_AMT_MATGP_M a
      where YYYY = vYYYY
        and MM = vMM;
  commit;

  iTracePoint := '120';  --QA, QB, QC, QD, CA, CB, CC, CD, DE, DF, DG, DH, DI, DJ
  for REC1 in (
     select distinct SITE, LIFNR, MATGROUP, TYPE, YYYY, MM, GRADE_L4
       from VRTN_MAP030_SUMMARY_GRAD
      where YYYY = vYYYY and MM = vMM and L4 is not null
  ) loop
     if REC1.TYPE = 'QA' then
       Update VRTN_SUM11_MM_MATGP
          set QA_GRADE = REC1.GRADE_L4
        where YYYY = vYYYY        and MM = vMM
          and SITE = REC1.SITE    and VENDOR = REC1.LIFNR
          and MATGROUP = REC1.MATGROUP;
     elsif REC1.TYPE = 'QB' then
       Update VRTN_SUM11_MM_MATGP
          set QB_GRADE = (QB_GRADE - abs(REC1.GRADE_L4))
        where YYYY = vYYYY        and MM = vMM
          and SITE = REC1.SITE    and VENDOR = REC1.LIFNR;
     elsif REC1.TYPE = 'QC' then
       Update VRTN_SUM11_MM_MATGP
 --	 Change by susan  2007/08/21
 --         set QC_GRADE = (QC_GRADE - abs(REC1.GRADE_L4))
          set QC_GRADE = REC1.GRADE_L4
        where YYYY = vYYYY        and MM = vMM
          and SITE = REC1.SITE    and VENDOR = REC1.LIFNR;
     elsif REC1.TYPE = 'QD' then
       Update VRTN_SUM11_MM_MATGP
          set QD_GRADE = REC1.GRADE_L4
        where YYYY = vYYYY        and MM = vMM
          and SITE = REC1.SITE    and VENDOR = REC1.LIFNR;
     elsif REC1.TYPE = 'CA' then
       Update VRTN_SUM11_MM_MATGP
          set CA_GRADE = REC1.GRADE_L4
        where YYYY = vYYYY        and MM = vMM
          and SITE = REC1.SITE    and VENDOR = REC1.LIFNR
          and MATGROUP = REC1.MATGROUP;
     elsif REC1.TYPE = 'CB' then
       Update VRTN_SUM11_MM_MATGP
          set CB_GRADE = REC1.GRADE_L4
        where YYYY = vYYYY        and MM = vMM
          and SITE = REC1.SITE    and VENDOR = REC1.LIFNR
          and MATGROUP = REC1.MATGROUP;
     elsif REC1.TYPE = 'CC' then
       Update VRTN_SUM11_MM_MATGP
          set CC_GRADE = REC1.GRADE_L4
        where YYYY = vYYYY        and MM = vMM
          and SITE = REC1.SITE    and VENDOR = REC1.LIFNR
          and MATGROUP = REC1.MATGROUP;
     elsif REC1.TYPE = 'CD' then
       Update VRTN_SUM11_MM_MATGP
          set CD_GRADE = REC1.GRADE_L4
        where YYYY = vYYYY        and MM = vMM
          and SITE = REC1.SITE    and VENDOR = REC1.LIFNR;
     elsif REC1.TYPE = 'DE' then
       Update VRTN_SUM11_MM_MATGP
          set DE_GRADE = REC1.GRADE_L4
        where YYYY = vYYYY        and MM = vMM
          and SITE = REC1.SITE    and VENDOR = REC1.LIFNR
          and MATGROUP = REC1.MATGROUP;
     elsif REC1.TYPE = 'DF' then
       Update VRTN_SUM11_MM_MATGP
          set DF_GRADE = REC1.GRADE_L4
        where YYYY = vYYYY        and MM = vMM
          and SITE = REC1.SITE    and VENDOR = REC1.LIFNR
          and MATGROUP = REC1.MATGROUP;
     elsif REC1.TYPE = 'DG' then
       Update VRTN_SUM11_MM_MATGP
          set DG_GRADE = REC1.GRADE_L4
        where YYYY = vYYYY        and MM = vMM
          and SITE = REC1.SITE    and VENDOR = REC1.LIFNR
          and MATGROUP = REC1.MATGROUP;
     elsif REC1.TYPE = 'DH' then
       Update VRTN_SUM11_MM_MATGP
          set DH_GRADE = REC1.GRADE_L4
        where YYYY = vYYYY        and MM = vMM
          and SITE = REC1.SITE    and VENDOR = REC1.LIFNR;
     elsif REC1.TYPE = 'DI' then
       Update VRTN_SUM11_MM_MATGP
          set DI_GRADE = REC1.GRADE_L4
        where YYYY = vYYYY        and MM = vMM
          and SITE = REC1.SITE    and VENDOR = REC1.LIFNR
          and MATGROUP = REC1.MATGROUP;
     elsif REC1.TYPE = 'DJ' then
       Update VRTN_SUM11_MM_MATGP
          set DJ_GRADE = REC1.GRADE_L4
        where YYYY = vYYYY        and MM = vMM
          and SITE = REC1.SITE    and VENDOR = REC1.LIFNR;
     end if;
     commit;
  end loop;

  iTracePoint := '130';  --D1, D2
  for REC1 in (
     select distinct SITE, LIFNR, MATGROUP, TYPE, YYYY, MM, GRADE_L3
       from VRTN_MAP030_SUMMARY_GRAD
      where YYYY = vYYYY and MM = vMM and TYPE in ('D1','D2')
  ) loop
     if REC1.TYPE = 'D1' then
       Update VRTN_SUM11_MM_MATGP
          set D1_GRADE = REC1.GRADE_L3
        where YYYY = vYYYY        and MM = vMM
          and SITE = REC1.SITE    and VENDOR = REC1.LIFNR
          and MATGROUP = REC1.MATGROUP;
     elsif REC1.TYPE = 'D2' then
       Update VRTN_SUM11_MM_MATGP
          set D2_GRADE = REC1.GRADE_L3
        where YYYY = vYYYY        and MM = vMM
          and SITE = REC1.SITE    and VENDOR = REC1.LIFNR
          and MATGROUP = REC1.MATGROUP;
     end if;
     commit;
  end loop;

  iTracePoint := '200';  --Get VRTN_MAP060_LEVEL_DESC value
  Q0_VALUE := 0;
  QA_VALUE := 0;
  QB_VALUE := 0;
  QC_VALUE := 0;
  QD_VALUE := 0;
  C0_VALUE := 0;
  CA_VALUE := 0;
  CB_VALUE := 0;
  CC_VALUE := 0;
  CD_VALUE := 0;
  D0_VALUE := 0;
  D1_VALUE := 0;
  D2_VALUE := 0;
  D3_VALUE := 0;
  DE_VALUE := 0;
  DF_VALUE := 0;
  DG_VALUE := 0;
  DH_VALUE := 0;
  DI_VALUE := 0;
  DJ_VALUE := 0;

  for REC1 in (
     select distinct LEVEL_S, VALUE from VRTN_MAP060_LEVEL_DESC where VALUE is not null
  ) loop
     if REC1.LEVEL_S = 'Q0' then
       Q0_VALUE := REC1.VALUE;
     elsif REC1.LEVEL_S = 'QA' then
       QA_VALUE := REC1.VALUE;
     elsif REC1.LEVEL_S = 'QB' then
       QB_VALUE := REC1.VALUE;
     elsif REC1.LEVEL_S = 'QC' then
       QC_VALUE := REC1.VALUE;
     elsif REC1.LEVEL_S = 'QD' then
       QD_VALUE := REC1.VALUE;
     elsif REC1.LEVEL_S = 'C0' then
       C0_VALUE := REC1.VALUE;
     elsif REC1.LEVEL_S = 'CA' then
       CA_VALUE := REC1.VALUE;
     elsif REC1.LEVEL_S = 'CB' then
       CB_VALUE := REC1.VALUE;
     elsif REC1.LEVEL_S = 'CC' then
       CC_VALUE := REC1.VALUE;
     elsif REC1.LEVEL_S = 'CD' then
       CD_VALUE := REC1.VALUE;
     elsif REC1.LEVEL_S = 'D0' then
       D0_VALUE := REC1.VALUE;
     elsif REC1.LEVEL_S = 'D1' then
       D1_VALUE := REC1.VALUE;
     elsif REC1.LEVEL_S = 'D2' then
       D2_VALUE := REC1.VALUE;
     elsif REC1.LEVEL_S = 'D3' then
       D3_VALUE := REC1.VALUE;
     elsif REC1.LEVEL_S = 'DE' then
       DE_VALUE := REC1.VALUE;
     elsif REC1.LEVEL_S = 'DF' then
       DF_VALUE := REC1.VALUE;
     elsif REC1.LEVEL_S = 'DG' then
       DG_VALUE := REC1.VALUE;
     elsif REC1.LEVEL_S = 'DH' then
       DH_VALUE := REC1.VALUE;
     elsif REC1.LEVEL_S = 'DI' then
       DI_VALUE := REC1.VALUE;
     elsif REC1.LEVEL_S = 'DJ' then
       DJ_VALUE := REC1.VALUE;
     end if;
  end loop;

  iTracePoint := '211';  --Update VRTN_SUM11_MM_MATGP (1-1)
  Update VRTN_SUM11_MM_MATGP
     set SUBTOT_Q = round( (nvl(QA_GRADE,0) * QA_VALUE) + (nvl(QB_GRADE,0) * QB_VALUE) + (nvl(QC_GRADE,0) * QC_VALUE) + (nvl(QD_GRADE,0) * QD_VALUE), 5)
   where YYYY = vYYYY    and MM = vMM
     and ( QA_GRADE is not null or QB_GRADE is not null or QC_GRADE is not null or QD_GRADE is not null );
  commit;

  iTracePoint := '212';  --Update VRTN_SUM11_MM_MATGP (1-2)
  Update VRTN_SUM11_MM_MATGP
     set SUBTOT_C = round( (nvl(CA_GRADE,0) * CA_VALUE) + (nvl(CB_GRADE,0) * CB_VALUE) + (nvl(CC_GRADE,0) * CC_VALUE) + (nvl(CD_GRADE,0) * CD_VALUE), 5)
   where YYYY = vYYYY    and MM = vMM
     and ( CA_GRADE is not null or CB_GRADE is not null or CC_GRADE is not null or CD_GRADE is not null );
  commit;

  iTracePoint := '213';  --Update VRTN_SUM11_MM_MATGP (1-3)
  Update VRTN_SUM11_MM_MATGP
     set TOT_CQD = round( (nvl(DE_GRADE,0) * DE_VALUE) + (nvl(DF_GRADE,0) * DF_VALUE) + (nvl(DG_GRADE,0) * DG_VALUE) + (nvl(DH_GRADE,0) * DH_VALUE) + (nvl(DI_GRADE,0) * DI_VALUE) + (nvl(DJ_GRADE,0) * DJ_VALUE), 5)
   where YYYY = vYYYY    and MM = vMM
     and ( DE_GRADE is not null or DF_GRADE is not null or DG_GRADE is not null or DH_GRADE is not null or DI_GRADE is not null or DJ_GRADE is not null );
  commit;

  iTracePoint := '220';  --Update VRTN_SUM11_MM_MATGP (2)
  Update VRTN_SUM11_MM_MATGP
     set SUBTOT_D3 = round(TOT_CQD * ( 1 / ( decode(DE_GRADE,null,0,DE_VALUE) + decode(DF_GRADE,null,0,DF_VALUE) + decode(DG_GRADE,null,0,DG_VALUE) +
                                             decode(DH_GRADE,null,0,DH_VALUE) + decode(DI_GRADE,null,0,DI_VALUE) + decode(DJ_GRADE,null,0,DJ_VALUE) ) ), 5)
   where YYYY = vYYYY and MM = vMM
     and TOT_CQD is not null;
  commit;

  iTracePoint := '230';  --Update VRTN_SUM11_MM_MATGP (3)
  Update VRTN_SUM11_MM_MATGP
     set TOT_D1_D2_D3 = round( (nvl(D1_GRADE,0) * D1_VALUE) + (nvl(D2_GRADE,0) * D2_VALUE) + (nvl(SUBTOT_D3,0) * D3_VALUE), 5)
   where YYYY = vYYYY and MM = vMM
     and ( D1_GRADE is not null or D2_GRADE is not null or SUBTOT_D3 is not null );
  commit;

  iTracePoint := '240';  --Update VRTN_SUM11_MM_MATGP (4)
  Update VRTN_SUM11_MM_MATGP
     set SUBTOT_D = round( TOT_D1_D2_D3 * ( 1 / ( decode(D1_GRADE,null,0,D1_VALUE) + decode(D2_GRADE,null,0,D2_VALUE) + decode(SUBTOT_D3,null,0,D3_VALUE) ) ), 5)
   where YYYY = vYYYY and MM = vMM
     and TOT_D1_D2_D3 is not null;
  commit;

  iTracePoint := '250';  --Update VRTN_SUM11_MM_MATGP (5)
  Update VRTN_SUM11_MM_MATGP
     set MM_SCORE = round( ( nvl(SUBTOT_Q,0) * Q0_VALUE ) + ( nvl(SUBTOT_C,0) * C0_VALUE ) + ( nvl(SUBTOT_D,0) * D0_VALUE ), 5)
   where YYYY = vYYYY and MM = vMM
     and ( SUBTOT_Q is not null or SUBTOT_C is not null or SUBTOT_D is not null );
  commit;


  iTracePoint := '300';  --刪除 VRTN_SUM12_MM_VM
  delete from VRTN_SUM12_MM_VM
   where YYYY = vYYYY
     and MM = vMM;
  commit;

  iTracePoint := '310';
  insert into VRTN_SUM12_MM_VM ( SITE, VENDOR, YYYY, MM, GV_VENDOR, QUARTER, BUKRS, AMOUNT, QA_GRADE, QB_GRADE, QC_GRADE,
                                 QD_GRADE, SUBTOT_Q, CA_GRADE, CB_GRADE, CC_GRADE, CD_GRADE, SUBTOT_C, D1_GRADE, D2_GRADE,
                                 DE_GRADE, DF_GRADE, DG_GRADE, DH_GRADE, DI_GRADE, DJ_GRADE, TOT_CQD, SUBTOT_D3,
                                 TOT_D1_D2_D3, SUBTOT_D, MM_SCORE, DATE_TIME )
    select SITE, VENDOR, YYYY, MM, GV_VENDOR, QUARTER, BUKRS, sum(AMOUNT),
           round(sum(QA_GRADE * AMOUNT) / sum(AMOUNT),5),
           round(sum(QB_GRADE * AMOUNT) / sum(AMOUNT),5),
           round(sum(QC_GRADE * AMOUNT) / sum(AMOUNT),5),
           round(sum(QD_GRADE * AMOUNT) / sum(AMOUNT),5),
           round(sum(SUBTOT_Q * AMOUNT) / sum(AMOUNT),5),
           round(sum(CA_GRADE * AMOUNT) / sum(AMOUNT),5),
           round(sum(CB_GRADE * AMOUNT) / sum(AMOUNT),5),
           round(sum(CC_GRADE * AMOUNT) / sum(AMOUNT),5),
           round(sum(CD_GRADE * AMOUNT) / sum(AMOUNT),5),
           round(sum(SUBTOT_C * AMOUNT) / sum(AMOUNT),5),
           round(sum(D1_GRADE * AMOUNT) / sum(AMOUNT),5),
           round(sum(D2_GRADE * AMOUNT) / sum(AMOUNT),5),
           round(sum(DE_GRADE * AMOUNT) / sum(AMOUNT),5),
           round(sum(DF_GRADE * AMOUNT) / sum(AMOUNT),5),
           round(sum(DG_GRADE * AMOUNT) / sum(AMOUNT),5),
           round(sum(DH_GRADE * AMOUNT) / sum(AMOUNT),5),
           round(sum(DI_GRADE * AMOUNT) / sum(AMOUNT),5),
           round(sum(DJ_GRADE * AMOUNT) / sum(AMOUNT),5),
           round(sum(TOT_CQD * AMOUNT) / sum(AMOUNT),5),
           round(sum(SUBTOT_D3 * AMOUNT) / sum(AMOUNT),5),
           round(sum(TOT_D1_D2_D3 * AMOUNT) / sum(AMOUNT),5),
           round(sum(SUBTOT_D * AMOUNT) / sum(AMOUNT),5),
           round(sum(MM_SCORE * AMOUNT) / sum(AMOUNT),5),
           DATE_TIME
      from VRTN_SUM11_MM_MATGP
     where YYYY = vYYYY    and MM = vMM
     group by SITE, VENDOR, YYYY, MM, GV_VENDOR, QUARTER, BUKRS, DATE_TIME;
  commit;

  iTracePoint := '400';  --刪除 VRTN_SUM13_MM_COMBINE
  delete from VRTN_SUM13_MM_COMBINE
   where YYYY = vYYYY
     and MM = vMM;
  commit;

  iTracePoint := '410';
  insert into VRTN_SUM13_MM_COMBINE ( SITE, VENDOR, MATGROUP, YYYY, MM, GV_VENDOR, QUARTER, BUKRS, AMOUNT,
                                      QA_GRADE, QB_GRADE, QC_GRADE, QD_GRADE, SUBTOT_Q, CA_GRADE, CB_GRADE, CC_GRADE,
                                      CD_GRADE, SUBTOT_C, D1_GRADE, D2_GRADE, DE_GRADE, DF_GRADE, DG_GRADE, DH_GRADE,
                                      DI_GRADE, DJ_GRADE, TOT_CQD, SUBTOT_D3, TOT_D1_D2_D3, SUBTOT_D, MM_SCORE, DATE_TIME )
    select SITE, VENDOR, MATGROUP, YYYY, MM, GV_VENDOR, QUARTER, BUKRS, AMOUNT,
           QA_GRADE, QB_GRADE, QC_GRADE, QD_GRADE, SUBTOT_Q, CA_GRADE, CB_GRADE, CC_GRADE,
           CD_GRADE, SUBTOT_C, D1_GRADE, D2_GRADE, DE_GRADE, DF_GRADE, DG_GRADE, DH_GRADE,
           DI_GRADE, DJ_GRADE, TOT_CQD, SUBTOT_D3, TOT_D1_D2_D3, SUBTOT_D, MM_SCORE, DATE_TIME
      from VRTN_SUM11_MM_MATGP
     where YYYY = vYYYY and MM = vMM
    union all
    select SITE, VENDOR, '000' as MATGROUP, YYYY, MM, GV_VENDOR, QUARTER, BUKRS, AMOUNT,
           QA_GRADE, QB_GRADE, QC_GRADE, QD_GRADE, SUBTOT_Q, CA_GRADE, CB_GRADE, CC_GRADE,
           CD_GRADE, SUBTOT_C, D1_GRADE, D2_GRADE, DE_GRADE, DF_GRADE, DG_GRADE, DH_GRADE,
           DI_GRADE, DJ_GRADE, TOT_CQD, SUBTOT_D3, TOT_D1_D2_D3, SUBTOT_D, MM_SCORE, DATE_TIME
      from VRTN_SUM12_MM_VM
     where YYYY = vYYYY and MM = vMM;
  commit;

EXCEPTION
  When OTHERS Then
    --有錯誤產生則寄mail
    cErrorText := SQLERRM();
    MAIL_FILE_BIDBDBADMIN(in_to_name => 'shuchin_lin@usiglobal.com', subject => '[VRTN] PL/SQL VRTN_PLSQL_SUM5_LOC_MM ERROR', message => '[VRTN_PLSQL_SUM5_LOC_MM], The tracepoint is  ' || iTracePoint || ' and ErrorText= ' || cErrorText) ;
END;
/

