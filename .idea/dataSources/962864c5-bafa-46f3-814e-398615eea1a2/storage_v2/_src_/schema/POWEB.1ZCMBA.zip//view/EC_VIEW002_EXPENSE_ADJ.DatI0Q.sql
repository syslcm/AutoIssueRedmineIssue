create view EC_VIEW002_EXPENSE_ADJ as
SELECT company_code, period, DOCUMENT_DATE, DOCUMENT_NUMBER, GROUP_ID, GROUP_ID, department, department,
          cost_center, cost_center, cost_element, amt_local, amt_twd, amt_usd,
          1, amt_local, amt_twd, amt_usd, CATEGORY, name_ch, name_en,
          name_detail, name_detail_en, bg_id, bg, bu, plm, site, YEAR,
          org_order, act_order, data_type, 'N'
     FROM ec_view001_expense
    WHERE isshow = 'Y'
   UNION ALL
-- 0.isshow <> 'Y' 的 Org 攤提到 isshow = 'Y'
   SELECT a.company_code, a.period, DOCUMENT_DATE, DOCUMENT_NUMBER, a.GROUP_ID, b.GROUP_ID, a.department,
          b.department, a.cost_center, b.sap_cost_center, a.cost_element,
          a.amt_local, a.amt_twd, a.amt_usd, b.hc_rate,
          a.amt_local * b.hc_rate, a.amt_twd * b.hc_rate,
          a.amt_usd * b.hc_rate, a.CATEGORY, a.name_ch, name_en, name_detail,
          name_detail_en, bg_id, bg, bu, plm, site, YEAR, report_order,
          act_order, data_type, 'Y'
     FROM ec_view001_expense a, ec_map001_organization b
    WHERE a.isshow <> 'Y' AND b.isshow = 'Y'
--      AND a.company_code = b.company_code(+)
          AND a.period = b.period(+)
--      AND a.cost_center = b.sap_cost_center(+)
/

