create PROCEDURE       ROIC_PLS011_COPA_PCA_ADJ (
  inCompany  in VARCHAR2,
  f_YYYYMMDD in VARCHAR2,
  t_YYYYMMDD in VARCHAR2
)
AUTHID DEFINER
is
/*********************************************************************
  PROG-ID      : ROIC_PLS011_COPA_PCA_ADJ
  PROG-ACTION  : COPA '&' PCA Adjust Data Process Exchange Rate
  Author       : Patty
  Date         : 2019/09/24
  OA No.       : SAI105407
  Process      :
  1. Transfer ROIC_UPL015_COPA_PCA_ADJ Amount to TWD/USD/CNY Amount
  2. Use Function: GET_CROSS_EXCHANGE_RATE
**********************************************************************/
/*---------------------------------------------------------------------
---------------------------------------------------------------------*/
 
 t_CURRENCY_LOC      ROIC_UPL015_COPA_PCA_ADJ.CURRENCY_LOC%TYPE;
 a_EX_RATE_TWD       ROIC_UPL015_COPA_PCA_ADJ.EX_RATE_TWD%TYPE;
 a_EX_RATE_USD       ROIC_UPL015_COPA_PCA_ADJ.EX_RATE_USD%TYPE;
 a_EX_RATE_CNY       ROIC_UPL015_COPA_PCA_ADJ.EX_RATE_CNY%TYPE; 

 CURSOR C_PERIOD is 
       Select DISTINCT A.COMPANY_CODE, A.PERIOD,  A.CURRENCY_LOC 
               FROM ROIC_UPL015_COPA_PCA_ADJ A  
              WHERE A.COMPANY_CODE = inCompany
                AND A.PERIOD >= SUBSTR(f_YYYYMMDD,1,6)
                AND A.PERIOD <= SUBSTR(t_YYYYMMDD,1,6);

             
BEGIN
 
  for REC1 in C_PERIOD loop

    t_CURRENCY_LOC := REC1.CURRENCY_LOC;

    a_EX_RATE_TWD := GET_CROSS_EXCHANGE_RATE(REC1.PERIOD, REC1.COMPANY_CODE, t_CURRENCY_LOC, 'TWD');
    a_EX_RATE_USD := GET_CROSS_EXCHANGE_RATE(REC1.PERIOD, REC1.COMPANY_CODE, t_CURRENCY_LOC, 'USD');
    a_EX_RATE_CNY := GET_CROSS_EXCHANGE_RATE(REC1.PERIOD, REC1.COMPANY_CODE, t_CURRENCY_LOC, 'CNY');

    UPDATE ROIC_UPL015_COPA_PCA_ADJ
      SET EX_RATE_TWD = a_EX_RATE_TWD,
	  EX_RATE_USD = a_EX_RATE_USD,
	  EX_RATE_CNY = a_EX_RATE_CNY,
	  NET_REVENUE_TWD = Round(NET_REVENUE * a_EX_RATE_TWD, 5),
	  NET_REVENUE_USD = Round(NET_REVENUE * a_EX_RATE_USD, 5),
	  NET_REVENUE_CNY = Round(NET_REVENUE * a_EX_RATE_CNY, 5),
	  NET_COGS_TWD = Round(NET_COGS * a_EX_RATE_TWD, 5),
	  NET_COGS_USD = Round(NET_COGS * a_EX_RATE_USD, 5),	
	  NET_COGS_CNY = Round(NET_COGS * a_EX_RATE_CNY, 5)		  
     WHERE COMPANY_CODE = REC1.COMPANY_CODE
        AND PERIOD = REC1.PERIOD;

    Commit;

  end loop;


END ROIC_PLS011_COPA_PCA_ADJ;
/

