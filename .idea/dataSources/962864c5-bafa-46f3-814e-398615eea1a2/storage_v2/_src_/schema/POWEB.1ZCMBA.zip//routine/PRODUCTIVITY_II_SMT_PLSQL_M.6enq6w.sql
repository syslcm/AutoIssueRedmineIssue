create PROCEDURE Productivity_Ii_Smt_Plsql_M
IS
/*-----------------------------------------------------------------------------------------------------------------------------*
        CREATE DATE:  2009/10/02
         PLSQL      :
         Author     :  Shuya
         Purpose    :  PRODUCTIVITY Report by monthly (每月26執行)
                           TW/SZ/SH (month period : 26~25)
*------------------------------------------------------------------------------------------------------------------------------
	  2009/11/13 增加profit center
*------------------------------------------------------------------------------------------------------------------------------*/

 vFROM_YYYYMMDD   VARCHAR2(8);
 vTO_YYYYMMDD     VARCHAR2(8);
 vPROCESS_YYYYMM  VARCHAR2(6);
 vProductivity   NUMBER(13,4);
 iTracePoint    VARCHAR2(100);
 cErrorText     VARCHAR2(500);

BEGIN

    --抓上月份系統日期
    iTracePoint := '000';
    vFROM_YYYYMMDD := TO_CHAR(ADD_MONTHS(SYSDATE-7,-1), 'YYYYMM')||'26';
    vTO_YYYYMMDD := TO_CHAR(SYSDATE-7, 'YYYYMM')||'26';
    vPROCESS_YYYYMM := TO_CHAR(SYSDATE-7, 'YYYYMM');

  --清除重覆資料
  iTracePoint := '200';
  DELETE FROM PRODUCTIVITY_II_SMT_MM_T WHERE COMPANY_CODE IN('1100','1200','1500')
      AND PERIOD = vPROCESS_YYYYMM;
  DELETE FROM PRODUCTIVITY_II_SMT_MM WHERE COMPANY_CODE IN('1100','1200','1500')
      AND PERIOD = vPROCESS_YYYYMM;

  --取稼動資料 TW
  iTracePoint := '300';
  INSERT INTO PRODUCTIVITY_II_SMT_MM_T
   SELECT   '1100', vPROCESS_YYYYMM, SUBSTR (a.model_name, 1, 14) AS usi_pn, LPAD(b.division_code,10,'0'),
            a.support_dept AS original_wo_pd, '',
            ROUND (SUM (a.total_time) / 60, 6) AS HOUR, '', '', '', '', SYSDATE
       FROM forsfis.nk_r_activation_record_t a, (SELECT model_serial, division_code FROM forsfis.nk_c_model_desc2_t GROUP BY model_serial, division_code HAVING division_code IS NOT NULL) b
      WHERE SUBSTR(a.model_name,1,14) = b.model_serial(+)
        AND a.start_time >= TO_DATE (vFROM_YYYYMMDD || ' 00:00:00', 'yyyymmdd hh24:mi:ss')
        AND a.start_time < TO_DATE (vTO_YYYYMMDD || ' 00:00:00', 'yyyymmdd hh24:mi:ss')
        AND (   a.except_id LIKE 'A1%'
             OR a.except_id LIKE 'A2%'
             OR (a.except_id LIKE 'A4%' AND except_id <> 'A4018')
             OR a.except_id LIKE 'A5%'
            )
        AND a.mo_number NOT LIKE '5%'
        AND a.mo_number NOT LIKE '9%'
   GROUP BY SUBSTR (a.model_name, 1, 14), b.division_code, a.support_dept
   ORDER BY SUBSTR (a.model_name, 1, 14), b.division_code, a.support_dept;

  --取稼動資料 SH
  iTracePoint := '400';
  INSERT INTO PRODUCTIVITY_II_SMT_MM_T
   SELECT   '1500', vPROCESS_YYYYMM, SUBSTR (a.model_name, 1, 14) AS usi_pn, LPAD(b.division_code,10,'0'),
            a.support_dept AS original_wo_pd, '',
            ROUND (SUM (a.total_time) / 60, 6) AS HOUR, '', '', '', '', SYSDATE
       FROM forsfis.sh_r_activation_record_t a, (SELECT model_serial, division_code FROM forsfis.sh_c_model_desc2_t GROUP BY model_serial, division_code HAVING division_code IS NOT NULL) b
      WHERE SUBSTR(a.model_name,1,14) = b.model_serial(+)
        AND a.start_time >= TO_DATE (vFROM_YYYYMMDD || ' 00:00:00', 'yyyymmdd hh24:mi:ss')
        AND a.start_time < TO_DATE (vTO_YYYYMMDD || ' 00:00:00', 'yyyymmdd hh24:mi:ss')
        AND (   a.except_id LIKE 'A1%'
             OR a.except_id LIKE 'A2%'
             OR (a.except_id LIKE 'A4%' AND except_id <> 'A4018')
             OR a.except_id LIKE 'A5%'
            )
        --AND mo_number NOT LIKE '5%'
        AND a.mo_number NOT LIKE '9%'
   GROUP BY SUBSTR (a.model_name, 1, 14), b.division_code, a.support_dept
   ORDER BY SUBSTR (a.model_name, 1, 14), b.division_code, a.support_dept;

  --取稼動資料 SZ
  iTracePoint := '500';
  INSERT INTO PRODUCTIVITY_II_SMT_MM_T
   SELECT   '1200', vPROCESS_YYYYMM, SUBSTR (a.model_name, 1, 14) AS usi_pn, LPAD(b.division_code,10,'0'),
            a.support_dept AS original_wo_pd, '',
            ROUND (SUM (a.total_time) / 60, 6) AS HOUR, '', '', '', '', SYSDATE
       FROM forsfis.sz_r_activation_record_t a, (SELECT model_serial, division_code FROM forsfis.sz_c_model_desc2_t GROUP BY model_serial, division_code HAVING division_code IS NOT NULL) b
      WHERE SUBSTR(a.model_name,1,14) = b.model_serial(+)
        AND a.start_time >= TO_DATE (vFROM_YYYYMMDD || ' 00:00:00', 'yyyymmdd hh24:mi:ss')
        AND a.start_time < TO_DATE (vTO_YYYYMMDD || ' 00:00:00', 'yyyymmdd hh24:mi:ss')
        AND (   a.except_id LIKE 'A1%'
             OR a.except_id LIKE 'A2%'
             OR (a.except_id LIKE 'A4%' AND except_id <> 'A4018')
             OR a.except_id LIKE 'A5%'
            )
        --AND mo_number NOT LIKE '5%'
        AND a.mo_number NOT LIKE '9%'
   GROUP BY SUBSTR (a.model_name, 1, 14), b.division_code, a.support_dept
   ORDER BY SUBSTR (a.model_name, 1, 14), b.division_code, a.support_dept;

   --取約當數量，計算當期生產力
   iTracePoint := '600';
   INSERT INTO PRODUCTIVITY_II_SMT_MM
   SELECT b.company_code, b.period, b.usipn, b.profit_center, b.division, b.sum_qty,
          a.activation, a.activation_sum, a.activation_percent, b.sum_qty/a.activation, '0', '0', SYSDATE
     FROM PRODUCTIVITY_II_SMT_MM_T a, productivity_ii_sum_qty b
    WHERE a.company_code(+) = b.company_code
      AND b.usipn = a.usipn(+)
      AND b.period = a.period(+)
	  AND b.division = a.division(+)
	  AND b.profit_center = a.profit_center(+)
	  AND b.period = vPROCESS_YYYYMM
	  AND b.company_code IN('1100','1200','1500');

   --計算總稼動
   iTracePoint := '700';
   FOR rec1 IN (SELECT COMPANY_CODE, DIVISION, SUM(ACTIVATION) AS SUM_ACTIVATION FROM PRODUCTIVITY_II_SMT_MM WHERE period = vPROCESS_YYYYMM AND company_code IN('1100','1200','1500') GROUP BY COMPANY_CODE, DIVISION)
   LOOP
     UPDATE PRODUCTIVITY_II_SMT_MM
        SET ACTIVATION_SUM = rec1.SUM_ACTIVATION
	  WHERE company_code = rec1.company_code
		AND period = vPROCESS_YYYYMM
		AND division = rec1.division;
   END LOOP;

   --計算稼動百分比
   iTracePoint := '800';
   UPDATE PRODUCTIVITY_II_SMT_MM
      SET ACTIVATION_PERCENT = ACTIVATION / ACTIVATION_SUM  WHERE period=vPROCESS_YYYYMM AND company_code IN('1100','1200','1500');

   --取前期生產力 (去年)
   iTracePoint := '900';
   FOR rec1 IN (SELECT * FROM PRODUCTIVITY_II_SMT_MM WHERE period = vPROCESS_YYYYMM AND company_code IN('1100','1200','1500'))
   LOOP
      FOR rec2 IN(
        SELECT Productivity
            FROM PRODUCTIVITY_II_SMT_YY
            WHERE (Productivity IS NOT NULL OR Productivity <> 0)
			  AND ROWNUM = 1
			  AND company_code = rec1.company_code
			  AND YY < SUBSTR(vPROCESS_YYYYMM,1,4)
			  AND division = rec1.division
			  AND usipn = rec1.usipn
			ORDER BY YY DESC)
		LOOP
	      UPDATE PRODUCTIVITY_II_SMT_MM
              SET last_productivity = rec2.Productivity
			  WHERE company_code = rec1.company_code
			    AND period = rec1.period
			    AND usipn = rec1.usipn
			    AND division = rec1.division;
		END LOOP;
   END LOOP;

   --取前期生產力 (若無，取當年第一個月的生產力)
   iTracePoint := '1000';
   FOR rec1 IN (SELECT * FROM PRODUCTIVITY_II_SMT_MM WHERE (last_productivity IS NULL OR last_productivity = 0) AND period = vPROCESS_YYYYMM AND company_code IN('1100','1200','1500'))
   LOOP
      FOR rec3 IN(
      SELECT Productivity
            FROM PRODUCTIVITY_II_SMT_MM
            WHERE  (Productivity IS NOT NULL OR Productivity <> 0)
			  AND company_code = rec1.company_code
			  AND division = rec1.division
			  AND usipn = rec1.usipn
			  AND period LIKE SUBSTR(vPROCESS_YYYYMM,1,4)||'%'
			  AND ROWNUM = 1
			ORDER BY period)
	  LOOP
	    UPDATE PRODUCTIVITY_II_SMT_MM
            SET last_productivity = rec3.Productivity
			WHERE company_code = rec1.company_code
			  AND period = rec1.period
			  AND usipn = rec1.usipn
			  AND division = rec1.division;
	  END LOOP;
   END LOOP;

   --計算基期生產力
   iTracePoint := '1100';
   UPDATE PRODUCTIVITY_II_SMT_MM
      SET BASE_PRODUCTIVITY = ACTIVATION_PERCENT * LAST_PRODUCTIVITY WHERE period=vPROCESS_YYYYMM AND company_code IN('1100','1200','1500');

   --計算基期生產力(若無前期生產力，則以當月生產力*嫁動百分比)
   UPDATE PRODUCTIVITY_II_SMT_MM
      SET BASE_PRODUCTIVITY = ACTIVATION_PERCENT * PRODUCTIVITY WHERE period=vPROCESS_YYYYMM AND company_code IN('1100','1200','1500') AND (BASE_PRODUCTIVITY =0 OR BASE_PRODUCTIVITY IS NULL);

   COMMIT;
EXCEPTION
   WHEN OTHERS THEN
    --有錯誤產生則寄mail
    cErrorText := SQLERRM();
    Mail_File_Bidbdbadmin(in_to_name => 'shuya@ms.usi.com.tw', subject => '[PRODUCTIVITY-Error] PL/SQL PRODUCTIVITY_II_SMT_PLSQL_M ERROR', message => '[Table:PRODUCTIVITY_II_SMT_MM], The tracepoint is  ' || iTracePoint || ' and ErrorText= ' || cErrorText||' and vPROCESS_YYYYMM='||vPROCESS_YYYYMM||' and vFROM_YYYYMMDD='||vFROM_YYYYMMDD||' and vTO_YYYYMMDD='||vTO_YYYYMMDD) ;

END Productivity_Ii_Smt_Plsql_M;
/

