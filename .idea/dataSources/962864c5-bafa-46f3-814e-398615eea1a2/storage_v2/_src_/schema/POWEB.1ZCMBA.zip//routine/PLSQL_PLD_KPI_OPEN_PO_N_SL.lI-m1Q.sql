create PROCEDURE       "PLSQL_PLD_KPI_OPEN_PO_N_SL" (
  inCompany in VARCHAR2,
  f_YYYYMMDD in VARCHAR2,
  t_YYYYMMDD in VARCHAR2
)
AUTHID DEFINER
is

   nCOUNT              NUMBER(5);
   t_CURRENCY_LOCAL    PLD_KPI_OPEN_PO_N_SL.PART_CURRENCY%TYPE;
   a_EX_RATE_USD       PLD_KPI_OPEN_PO_N_SL.EX_RATE_USD%TYPE;
   a_EX_RATE_TWD       PLD_KPI_OPEN_PO_N_SL.EX_RATE_TWD%TYPE;
   cErrorText          varchar2(500);
   iTracePoint         varchar2(3);


 BEGIN
   --(1) 清舊資料
   -- 
       iTracePoint := '000';
    Delete From PLD_KPI_OPEN_PO_N_SL
         Where COMPANY_CODE = inCompany
           and PERIOD in ( select distinct PERIOD from PLD_KPI_OPEN_PO_N_SL_T where COMPANY_CODE = inCompany );
    Commit;

   --(2) 匯率 / Amount
    iTracePoint := 200;
    a_EX_RATE_TWD := Null;
    a_EX_RATE_USD := Null;
    for REC1 in ( select distinct PERIOD from PLD_KPI_OPEN_PO_N_SL_T where COMPANY_CODE = inCompany ) loop
        t_CURRENCY_LOCAL := Null;
        Select LOCAL_CURRENCY into t_CURRENCY_LOCAL From (
            Select distinct LOCAL_CURRENCY from PLD_KPI_OPEN_PO_N_SL_T
            where COMPANY_CODE = inCompany
            and PERIOD = REC1.PERIOD
            and LOCAL_CURRENCY >= '*'
        );
        -- 計算匯率
        a_EX_RATE_USD := GET_EXCHANGE_RATE(SUBSTRB(REC1.PERIOD,1,4),SUBSTRB(REC1.PERIOD,5,2),t_CURRENCY_LOCAL,'USD','T');
        a_EX_RATE_TWD := GET_EXCHANGE_RATE(SUBSTRB(REC1.PERIOD,1,4),SUBSTRB(REC1.PERIOD,5,2),t_CURRENCY_LOCAL,'TWD','T');
        --開始處理amount
        --EX_RATE_xxx, PART_AMOUNT_xxx
        Update PLD_KPI_OPEN_PO_N_SL_T set
            EX_RATE_USD = a_EX_RATE_USD,
            EX_RATE_TWD = a_EX_RATE_TWD,
            PART_AMOUNT_USD = Round(LOCAL_AMT * a_EX_RATE_USD, 5),
            PART_AMOUNT_TWD = Round(LOCAL_AMT * a_EX_RATE_TWD, 5)
        Where COMPANY_CODE = inCompany
        and PERIOD = REC1.PERIOD
        and PART_CURRENCY not in ( 'USD', 'TWD');

        Update PLD_KPI_OPEN_PO_N_SL_T set
            EX_RATE_USD = a_EX_RATE_USD,
            EX_RATE_TWD = a_EX_RATE_TWD,
            PART_AMOUNT_USD = PART_AMOUNT,
            PART_AMOUNT_TWD = Round(LOCAL_AMT * a_EX_RATE_TWD, 5)
        Where COMPANY_CODE = inCompany
        and PERIOD = REC1.PERIOD
        and PART_CURRENCY = 'USD';

        Update PLD_KPI_OPEN_PO_N_SL_T set
            EX_RATE_USD = a_EX_RATE_USD,
            EX_RATE_TWD = a_EX_RATE_TWD,
            PART_AMOUNT_USD = Round(LOCAL_AMT * a_EX_RATE_USD, 5),
            PART_AMOUNT_TWD = PART_AMOUNT
        Where COMPANY_CODE = inCompany
        and PERIOD = REC1.PERIOD
        and PART_CURRENCY = 'TWD';
        Commit;
    end loop;

   --(3) 寫入資料
    iTracePoint := '060';
    for REC1 in ( select distinct PERIOD from PLD_KPI_OPEN_PO_N_SL_T where COMPANY_CODE = inCompany ) loop
        Insert into PLD_KPI_OPEN_PO_N_SL
           ( COMPANY_CODE, PERIOD, PO_NO, PO_ITEM, REQ_DATE, CFM_DATE, PO_TYPE, PLANT_CODE, STORAGE_LOC, 
             PART_NO, ACCOUNT_ASSIGNMENT, VENDOR_ID, MTL_GROUP, REQ_QTY, DEL_QTY, PART_QTY, CFM_QTY, 
             U_PRICE, PART_AMOUNT, PART_CURRENCY, RATE, LOCAL_AMT, PROFIT_CENTER, MFR_NAME, MFR_PART, 
             PART_AMOUNT_USD, PART_AMOUNT_TWD, EX_RATE_USD, EX_RATE_TWD, PRICE_UNIT, SAP_CREATE_DATE, 
             LOCAL_CURRENCY, CREATE_DATE, INT_PART_NO, PAYMENT_KEY, NEW_MATKL, VMI_AT_SUPPLIER )
        select COMPANY_CODE, PERIOD, PO_NO, PO_ITEM, REQ_DATE, CFM_DATE, PO_TYPE, PLANT_CODE, STORAGE_LOC, 
             PART_NO, ACCOUNT_ASSIGNMENT, VENDOR_ID, MTL_GROUP, REQ_QTY, DEL_QTY, PART_QTY, CFM_QTY, 
             U_PRICE, PART_AMOUNT, PART_CURRENCY, RATE, LOCAL_AMT, PROFIT_CENTER, MFR_NAME, MFR_PART, 
             PART_AMOUNT_USD, PART_AMOUNT_TWD, EX_RATE_USD, EX_RATE_TWD, PRICE_UNIT, SAP_CREATE_DATE, 
             LOCAL_CURRENCY, SYSDATE, INT_PART_NO, PAYMENT_KEY, NEW_MATKL, VMI_AT_SUPPLIER
        from PLD_KPI_OPEN_PO_N_SL_T
        where COMPANY_CODE = inCompany
        and PERIOD = REC1.PERIOD;
        Commit;
    END LOOP;

 EXCEPTION
   WHEN OTHERS THEN
      cErrorText := substrb(SQLERRM(),1,300);
      rollback;
      MAIL_FILE_BIDBDBADMIN(in_to_name=>'kathy_huang@usiglobal.com',subject   => '[PLD KPI]PL/SQL PLSQL_PLD_KPI_OPEN_PO_N_SL ERROR', message => '[PLSQL_PLD_KPI_OPEN_PO_N_SL], The tracepoint is  ' || iTracePoint || ' and ErrorText=' || cErrorText) ;
END PLSQL_PLD_KPI_OPEN_PO_N_SL;
/

