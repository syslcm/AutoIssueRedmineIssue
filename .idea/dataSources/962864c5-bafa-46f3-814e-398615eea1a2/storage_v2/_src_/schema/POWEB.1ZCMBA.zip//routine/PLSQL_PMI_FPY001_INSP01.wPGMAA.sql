create PROCEDURE       PLSQL_PMI_FPY001_INSP01(
  inCompany  in VARCHAR2,  --invalid
  f_YYYYMMDD in VARCHAR2,  --invalid
  t_YYYYMMDD in VARCHAR2   --invalid
)
/*********************************************************************
  PROG-ID      : SFIS0170
  PROG-ACTION  : Upload temp table(PMI_SFC001_SITE_FPY_T) into production table(PMI_SFC001_SITE_FPY)
  Author       : Gene
  Date         : 2007/01/05
  Note         : 20070126 by Gene. PMI_SFC001_SITE_FPY New field: WORK_MONTH   
  				 * 20070131 by Gene. 
  				    (1) 當 PMI_SFC001_SITE_FPY_T.WORK_DATE < sysdate ==> 不更新 PMI_SFC001_CURRENT_PROD, 防止補資料時更新到目前的狀況
  				    (2) 刪除一半年前的資料    
  				 * 20070202 by Gene.
  				   (1) 加上 Weekly 的 table:  PMI_SFC001_SITE_FPY_WEEKLY
  				   (2) 加上 Monthly的 table:  PMI_SFC001_SITE_FPY_MONTHLY
  				   (3) 用來記錄 SMT1, SMT2, ASM, ICT, FCT, FPY(SMT1*SMT2*..*FCT) 的良率
  				 * 20070213 by Gene.
  				   PMI_SFC001_SITE_FPY.CREATE_TIME 改為 SYSDATE, 而不是資料在 SFIS 內產生的時間! 這樣畫面上預計下次更新的時間才會更準確。
  				 * 20070416 BY GENE.
  				   當一次有多個 .TXT 要上傳時，Jerry 的 Process 是先將所有的檔案上傳後才 call PLSQL_PMI_FPY001_INSP01()，所以要改下
  				   Proceudre 的作業方式來配合 Jerry 的 Process。
  				 * 20080103 by Gene.
  				   ALTER TABLE PMI_SFC001_SITE_FPY ADD PD_NAME VARCHAR2(16);
  				   ALTER TABLE PMI_SFC001_SITE_FPY ADD MAIN_PRODUCT VARCHAR2(25);
  				   
  				   ALTER TABLE PMI_SFC001_SITE_FPY_T ADD PD_NAME VARCHAR2(16);
  				   ALTER TABLE PMI_SFC001_SITE_FPY_T ADD MAIN_PRODUCT VARCHAR2(25);
  				   所以 procedure 要再 replace 一次。   
  				 * 20080331 BY GENE.
  				   1. PMI_SFC001_SITE_FPY_T (PASS_QTY+FAIL_QTY) > 0; 的資料也要轉，因為 SZ, SH 畫圖時會用到。
  				 * 20090216 BY GENE.
  				   1. debug, 當  (rec_GRP.S_PASS+rec_GRP.S_FAIL) = 0 則 RATE=0
  				 * 20091001 by Gene.
  				   1. debug, 加上 Exception ，防止除數是 0
**********************************************************************/
is
 iTracePoint  integer ;
 cErrorText varchar2(500);

 C_COMPANY  PMI_SFC001_SITE_FPY.COMPANY_CODE%TYPE;
 C_PROFIT   PMI_SFC001_SITE_FPY.PROFIT_CENTER%TYPE;
 C_DATE     PMI_SFC001_SITE_FPY.WORK_DATE%TYPE;
 C_YEAR     PMI_SFC001_SITE_FPY.WORK_YEAR%TYPE;
 C_WEEK     PMI_SFC001_SITE_FPY.WORK_WEEK%TYPE;
 C_MONTH    PMI_SFC001_SITE_FPY.WORK_MONTH%TYPE;
 C_PASS NUMBER(10);
 C_FAIL NUMBER(10);
 C_RATE NUMBER(10,6);
 C_FPY NUMBER (10,6);
 C_SEQ NUMBER(2);
  --======================================================================================================================
  PROCEDURE MOVE_DATA_INTO_PROD_TABLE AS
  BEGIN
    --Delete data in Production table
    iTracePoint := 100;
  
    Delete from  PMI_SFC001_SITE_FPY
      WHERE COMPANY_CODE=C_COMPANY  AND WORK_DATE=C_DATE;
    COMMIT;

    --Insert data into production table
    iTracePoint := 200;
    INSERT INTO PMI_SFC001_SITE_FPY(
       COMPANY_CODE,PROFIT_CENTER,WORK_YEAR,WORK_WEEK,WORK_DATE,SHIFT_DATE,SHIFT,MODEL_NAME,
       USI_PN,LINE_NAME,GROUP_NAME,MAP_GROUP_NAME,PASS_QTY,FAIL_QTY,REPASS_QTY,REFAIL_QTY,CREATE_TIME,WORK_MONTH ,
       PD_NAME, MAIN_PRODUCT
     )
     SELECT COMPANY_CODE,PROFIT_CENTER,WORK_YEAR,WORK_WEEK,WORK_DATE,SHIFT_DATE,SHIFT,MODEL_NAME,
            USI_PN,LINE_NAME,GROUP_NAME,MAP_GROUP_NAME,PASS_QTY,FAIL_QTY,REPASS_QTY,REFAIL_QTY,SYSDATE , SubStr(WORK_DATE,5,2),
            PD_NAME, MAIN_PRODUCT
       FROM PMI_SFC001_SITE_FPY_T
       WHERE COMPANY_CODE=C_COMPANY  AND WORK_DATE=C_DATE;
             --AND (PASS_QTY+FAIL_QTY) > 0;
    COMMIT;

    --計算目前使用中的 USI PN 到 PMI_SFC001_CURRENT_PROD
    --20070131 只有當日的資料才會更新 PMI_SFC001_CURRENT_PROD 的內容  
    IF SUBSTR(C_DATE,1,8) >= TO_CHAR(SYSDATE,'YYYYMMDD') THEN
      iTracePoint := 300;
      DELETE FROM PMI_SFC001_CURRENT_PROD;
      COMMIT;

      iTracePoint := 310;
      INSERT INTO PMI_SFC001_CURRENT_PROD
         (COMPANY_CODE,WORK_DATE, SHIFT_DATE, PROFIT_CENTER, USI_PN, LINE_NAME, MAP_GROUP_NAME, CREATE_TIME)
      SELECT COMPANY_CODE, WORK_DATE, SHIFT_DATE,PROFIT_CENTER,  USI_PN, LINE_NAME, MAP_GROUP_NAME, SYSDATE
        FROM PMI_SFC001_SITE_FPY_T  
         WHERE (PASS_QTY+FAIL_QTY) > 0
        GROUP BY  COMPANY_CODE, WORK_DATE, SHIFT_DATE,PROFIT_CENTER,  USI_PN, LINE_NAME, MAP_GROUP_NAME;
      COMMIT;
    END IF;

    iTracePoint := 400;
    ------------------------------------------------------------------------------------------------------------------------  
    --20070202 BY GENE.
    --(1) 計算 Weekly 的資料  (只保留 12 週)
    Delete FROM PMI_SFC001_SITE_FPY_WEEKLY
      WHERE WORK_YEAR||WORK_WEEK < (SELECT WORK_YEAR||WORK_WEEK FROM PMI_SFC001_SITE_FPY WHERE SHIFT_DATE=TO_CHAR(SYSDATE-(7*12),'YYYYMMDD') AND ROWNUM=1);
    COMMIT;
  
    Delete FROM PMI_SFC001_SITE_FPY_WEEKLY
      WHERE COMPANY_CODE=C_COMPANY AND WORK_YEAR=C_YEAR AND WORK_WEEK = C_WEEK;
    COMMIT;
  
    iTracePoint := 410;  
    FOR rec_profit in (SELECT COMPANY_CODE, PROFIT_CENTER
                         FROM PMI_SFC001_SITE_FPY 
                         WHERE COMPANY_CODE= C_COMPANY 
                         GROUP BY COMPANY_CODE, PROFIT_CENTER )
    LOOP                                  
      C_FPY := 1;       
      C_PASS := 0;
      C_FAIL := 0;
      for rec_GRP in (SELECT MAP_GROUP_NAME, SUM(PASS_QTY) AS S_PASS, SUM(FAIL_QTY) AS S_FAIL FROM PMI_SFC001_SITE_FPY
                    WHERE  WORK_YEAR=C_YEAR 
                       AND WORK_WEEK = C_WEEK    
                       AND COMPANY_CODE=rec_Profit.COMPANY_CODE
                       AND PROFIT_CENTER = rec_Profit.PROFIT_CENTER
                    GROUP BY MAP_GROUP_NAME)
      Loop
        --20090216 BY GENE. 當  (rec_GRP.S_PASS+rec_GRP.S_FAIL) = 0 則 RATE=0
        IF (rec_GRP.S_PASS+rec_GRP.S_FAIL) > 0 THEN
          C_Rate := (rec_GRP.S_PASS/(rec_GRP.S_PASS+rec_GRP.S_FAIL));
        ELSE
          C_RATE := 0;
        end IF;
        
        C_SEQ := 0;
        IF rec_GRP.MAP_GROUP_NAME='SMT1' then
          C_SEQ:= 1;
        ELSIF rec_GRP.MAP_GROUP_NAME='SMT2' then
          C_SEQ:= 2;      
        ELSIF rec_GRP.MAP_GROUP_NAME='ASM' then
          C_SEQ:= 3;      
        ELSIF rec_GRP.MAP_GROUP_NAME='ICT' then
          C_SEQ:= 4;      
        ELSIF rec_GRP.MAP_GROUP_NAME='FCT' then
          C_SEQ:= 5;      
        END IF;      
      
        INSERT INTO PMI_SFC001_SITE_FPY_WEEKLY
         (COMPANY_CODE,PROFIT_CENTER, WORK_YEAR, WORK_WEEK, MAP_GROUP_NAME, GROUP_SEQ, PASS_QTY, FAIL_QTY, YIELD_RATE, CREATE_TIME)
        VALUES
         (rec_Profit.COMPANY_CODE, rec_Profit.PROFIT_CENTER, C_YEAR, C_WEEK, rec_GRP.MAP_GROUP_NAME, C_SEQ,
          rec_GRP.S_PASS, rec_GRP.S_FAIL,C_RATE ,SYSDATE);         
        COMMIT;
        
         --***** FPY = SMT1 * SMT2 * ASM * ICT * FCT (各站良率相乘) 
         C_FPY := C_FPY * C_RATE;       
         C_PASS :=C_PASS + rec_GRP.S_PASS;
         C_FAIL := C_FAIL +  rec_GRP.S_FAIL;  
         --***** --------------------------------------------------
    
      End Loop; --rec_Grp
      --Save FPY      
      C_SEQ:= 6;          
      INSERT INTO PMI_SFC001_SITE_FPY_WEEKLY
         (COMPANY_CODE,PROFIT_CENTER, WORK_YEAR, WORK_WEEK, MAP_GROUP_NAME, GROUP_SEQ, PASS_QTY, FAIL_QTY, YIELD_RATE, CREATE_TIME)
      VALUES
         (rec_Profit.COMPANY_CODE, rec_Profit.PROFIT_CENTER, C_YEAR, C_WEEK, 'FPY', C_SEQ,
          C_PASS, C_FAIL,C_FPY ,SYSDATE);             
      COMMIT;
    END LOOP;  -- rec_Profit
    ------------------------------------------------------------------------------------------------------------------------

    --(1) 計算 Monthly 的資料 (只留 12 個月) 
    Delete FROM PMI_SFC001_SITE_FPY_MONTHLY
     WHERE WORK_YEAR||WORK_MONTH < (SELECT WORK_YEAR||WORK_WEEK FROM PMI_SFC001_SITE_FPY WHERE SHIFT_DATE=TO_CHAR(SYSDATE-(366),'YYYYMMDD') AND ROWNUM=1);
    COMMIT;
    
    Delete FROM PMI_SFC001_SITE_FPY_MONTHLY
      WHERE COMPANY_CODE=C_COMPANY AND WORK_YEAR=C_YEAR AND WORK_MONTH = C_MONTH;
    COMMIT;
    
    iTracePoint := 420;  
    FOR rec_profit in (SELECT COMPANY_CODE, PROFIT_CENTER
                         FROM PMI_SFC001_SITE_FPY 
                         WHERE COMPANY_CODE= C_COMPANY 
                         GROUP BY COMPANY_CODE, PROFIT_CENTER )
    LOOP                                  
      C_FPY := 1;       
      C_PASS := 0;
      C_FAIL := 0;
      for rec_GRP in (SELECT MAP_GROUP_NAME, SUM(PASS_QTY) AS S_PASS, SUM(FAIL_QTY) AS S_FAIL FROM PMI_SFC001_SITE_FPY
                    WHERE  WORK_YEAR=C_YEAR 
                       AND WORK_MONTH = C_MONTH    
                       AND COMPANY_CODE=rec_Profit.COMPANY_CODE
                       AND PROFIT_CENTER = rec_Profit.PROFIT_CENTER
                    GROUP BY MAP_GROUP_NAME)
      Loop       
        iTracePoint := 421;     
        --20091001 by Gene 加上 Exception 
        begin
          C_Rate := (rec_GRP.S_PASS/(rec_GRP.S_PASS+rec_GRP.S_FAIL)); 
        exception 
          when others then
            C_Rate := 0;
        end;
        iTracePoint := 422;     
        
        C_SEQ := 0;
        IF rec_GRP.MAP_GROUP_NAME='SMT1' then
          C_SEQ:= 1;
        ELSIF rec_GRP.MAP_GROUP_NAME='SMT2' then
          C_SEQ:= 2;      
        ELSIF rec_GRP.MAP_GROUP_NAME='ASM' then
          C_SEQ:= 3;      
        ELSIF rec_GRP.MAP_GROUP_NAME='ICT' then
          C_SEQ:= 4;      
        ELSIF rec_GRP.MAP_GROUP_NAME='FCT' then
          C_SEQ:= 5;      
        END IF;       
      
        INSERT INTO PMI_SFC001_SITE_FPY_MONTHLY
         (COMPANY_CODE,PROFIT_CENTER, WORK_YEAR, WORK_MONTH, MAP_GROUP_NAME, GROUP_SEQ, PASS_QTY, FAIL_QTY, YIELD_RATE, CREATE_TIME)
        VALUES
         (rec_Profit.COMPANY_CODE, rec_Profit.PROFIT_CENTER, C_YEAR, C_MONTH, rec_GRP.MAP_GROUP_NAME, C_SEQ,
          rec_GRP.S_PASS, rec_GRP.S_FAIL,C_RATE ,SYSDATE);  
        COMMIT;       
        
         --***** FPY = SMT1 * SMT2 * ASM * ICT * FCT (各站良率相乘) 
         C_FPY := C_FPY * C_RATE;       
         C_PASS :=C_PASS + rec_GRP.S_PASS;
         C_FAIL := C_FAIL +  rec_GRP.S_FAIL;  
         --***** --------------------------------------------------
    
      End Loop; --rec_Grp
      --Save FPY
      C_SEQ:= 6;      
      INSERT INTO PMI_SFC001_SITE_FPY_MONTHLY
         (COMPANY_CODE,PROFIT_CENTER, WORK_YEAR, WORK_MONTH, MAP_GROUP_NAME, GROUP_SEQ, PASS_QTY, FAIL_QTY, YIELD_RATE, CREATE_TIME)
      VALUES
         (rec_Profit.COMPANY_CODE, rec_Profit.PROFIT_CENTER, C_YEAR, C_MONTH, 'FPY', C_SEQ,
          C_PASS, C_FAIL,C_FPY ,SYSDATE);             
      COMMIT;
    END LOOP;  -- rec_Profit
    ------------------------------------------------------------------------------------------------------------------------
  END;
  --======================================================================================================================
  
BEGIN

  -------------------------------------------------------------------------------------
  -------------------------------------------------------------------------------------
  --    MAIN FUNCTION    --------------------------------------------------------------
  -------------------------------------------------------------------------------------
  -------------------------------------------------------------------------------------

  iTracePoint := 0;

  --IN PMI_SFC001_SITE_FPY_T, data was only producted in last time.
  FOR rec1 IN ( SELECT COMPANY_CODE, WORK_DATE ,COUNT(*)
                  FROM PMI_SFC001_SITE_FPY_T
                  --WHERE COMPANY_CODE= inCompany                  
                  GROUP BY COMPANY_CODE, WORK_DATE      
              )
  LOOP    
    
     
    BEGIN           
    
      SELECT COMPANY_CODE, PROFIT_CENTER, WORK_DATE, WORK_YEAR, WORK_WEEK, SUBSTR(WORK_DATE,5,2)
        INTO C_COMPANY, C_PROFIT, C_DATE, C_YEAR, C_WEEK, C_MONTH
        FROM PMI_SFC001_SITE_FPY_T
        WHERE COMPANY_CODE= rec1.COMPANY_CODE
              AND WORK_DATE=rec1.WORK_DATE
              AND ROWNUM=1;                                     
        
      ----------------------------------------------------        
      --20070416 ADD BY GENE.
      ----------------------------------------------------
      MOVE_DATA_INTO_PROD_TABLE;
      ----------------------------------------------------
            
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        --20070416 BY GENE.
        C_PASS := 0;
        --RETURN;        
    END;
  END LOOP;
  
  
  --刪除一年半前的資料
  DELETE FROM PMI_SFC001_SITE_FPY
   WHERE SHIFT_DATE <= TO_CHAR( (SYSDATE-(18*30)),'YYYYMMDD');
    COMMIT;

  iTracePoint := 500;

EXCEPTION
   When OTHERS Then
    --有錯誤產生則寄mail
    cErrorText := SQLERRM();
    MAIL_FILE_BIDBDBADMIN(in_to_name => 'gene@ms.usi.com.tw', subject => '[PMI] PL/SQL PLSQL_PMI_FPY001_INSP01 ERROR', message => '[PLSQL_PMI_FPY001_INSP01], The tracepoint is  ' || iTracePoint || ' and ErrorText= ' || cErrorText) ;
END ;
/

