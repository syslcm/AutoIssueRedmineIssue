create FUNCTION vqa_get_global_vendor_name (
   cmfr_name   IN   vqa_pdm_mfr_data.mfr_name%TYPE
)
   RETURN VARCHAR2
/*********************************************************************
  PROG-ID      : VQA GET GLOBAL VENDOR
  Author       : Shuya
  Date         : 2008/02/277
**********************************************************************/
IS
   CURSOR cur
   IS
      SELECT b.vendor_name
        FROM vqa_avl_relation a, GVM031_GLOBAL_VENDOR b
       WHERE A.GLOBAL_VENDOR_CODE = B.GLOBAL_VENDOR_CODE
	     AND a.manufacturer_name = cmfr_name;

   cmessage   VARCHAR2 (5000);
BEGIN
   cmessage := '';

   FOR rec IN cur
   LOOP
      IF cmessage IS NOT NULL
      THEN
         cmessage := cmessage || ',';
      END IF;

      cmessage := cmessage || rec.vendor_name;
   END LOOP;

   RETURN cmessage;
END vqa_get_global_vendor_name;
/

