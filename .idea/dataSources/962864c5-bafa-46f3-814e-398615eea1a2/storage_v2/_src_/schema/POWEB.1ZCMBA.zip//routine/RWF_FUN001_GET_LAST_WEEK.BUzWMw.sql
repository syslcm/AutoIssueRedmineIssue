create Function RWF_FUN001_GET_LAST_WEEK(cRWF_YYYY in RWF_SAP001_REVENUE_FORECAST.RWF_YYYY%TYPE,cRWF_WEEK in RWF_SAP001_REVENUE_FORECAST.RWF_WEEK%TYPE)
/*********************************************************************
*新增/修改日期 :  2007-01-10
*Programmer    :  Kangi
*申請單號      :  SAI005398
*新增原因      :  GET LAST WEEK FROM TABLE RWF_SAP001_REVENUE_FORECAST
**********************************************************************/
/*********************************************************************
*新增/修改日期 :  20111229
*Programmer    :  Kangi
*申請單號      :  SAI028442
*新增原因      :  GET LAST WEEK FROM TABLE RWF_SYS002_RWF_YYYY_WEEK
**********************************************************************/
return RWF_SAP001_REVENUE_FORECAST.RWF_WEEK%TYPE
is
cLAST_RWF_WEEK  RWF_SAP001_REVENUE_FORECAST.RWF_WEEK%TYPE ;
Begin
       SELECT MAX(RWF_WEEK) INTO cLAST_RWF_WEEK
           FROM RWF_SYS002_RWF_YYYY_WEEK
           WHERE RWF_YYYY = cRWF_YYYY
             AND RWF_WEEK < cRWF_WEEK ;
       return cLAST_RWF_WEEK ;
    Exception
      WHEN NO_DATA_FOUND THEN
         return null ;
End RWF_FUN001_GET_LAST_WEEK;
/

