create PROCEDURE test_pls1_del1 (p_array_size IN PLS_INTEGER DEFAULT 100)
IS
   type row_type is table of rowid index by binary_integer;
   rows row_type;
   CURSOR cur1 IS SELECT rowid rid FROM T1;
 begin
    OPEN cur1;
    FOR vqtd IN 1..500 loop
		 FETCH cur1 BULK COLLECT INTO rows limit p_array_size;
         FORALL i IN 1..rows.COUNT
              DELETE T1 WHERE ROWID = rows(i) ;
    EXIT WHEN cur1%NOTFOUND;
    commit;
    --dbms_lock.sleep(5);
    END LOOP;
    CLOSE cur1;
	commit;
END test_pls1_del1;
/

