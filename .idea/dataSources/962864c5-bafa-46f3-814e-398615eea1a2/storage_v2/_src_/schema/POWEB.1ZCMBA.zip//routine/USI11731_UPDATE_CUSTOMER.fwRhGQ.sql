create PROCEDURE       USI11731_UPDATE_CUSTOMER (
  inCompany  in VARCHAR2,
  t_Period in VARCHAR2
  --2008/9/17 Create to Process get Amount in Local/USD/TWD
  --Trigger by PNL2_BAD_DEPT_UPLOAD.JSP
)
AUTHID DEFINER
is
   


 BEGIN

     update KPI_SAP001_COPA_TRX_TEMP set PDM_CUSTOMER1 = NULL  where pdm_customer1 is not null;
     COMMIT;
     --由料號來判斷end customer id(有ship to)
      update KPI_SAP001_COPA_TRX_TEMP set pdm_customer1 =      (
            select distinct END_CUSTOMER_ID
            from KPI_MAP004_5_COMPOSITE_END_CUS
            where COMPANY_CODE = KPI_SAP001_COPA_TRX_TEMP.COMPANY_CODE
            and PROFIT_CENTER = KPI_SAP001_COPA_TRX_TEMP.PROFIT_CENTER
            --and MTL_GROUP = KPI_SAP001_COPA_TRX_TEMP.MTL_GROUP
            and CUSTOMER_ID = KPI_SAP001_COPA_TRX_TEMP.CUSTOMER_ID
            and SHIP_TO_PARTY = KPI_SAP001_COPA_TRX_TEMP.SHIP_TO_PARTY
            AND SHIP_TO_PARTY IS NOT NULL
            AND PRODUCT_FLAG IS NOT NULL
            and PRODUCT_NO = KPI_SAP001_COPA_TRX_TEMP.PART_NO
            and START_DATE <= TO_DATE(KPI_SAP001_COPA_TRX_TEMP.POSTING_DATE,'YYYYMMDD')
            and END_DATE >= TO_DATE(KPI_SAP001_COPA_TRX_TEMP.POSTING_DATE,'YYYYMMDD')
        )
    Where  pdm_customer1 is Null
      AND  MTL_TYPE <> 'RAW';
	Commit;
    --由料號來判斷end customer id(無ship to)
      update KPI_SAP001_COPA_TRX_TEMP set pdm_customer1 =      (
            select distinct END_CUSTOMER_ID
            from KPI_MAP004_5_COMPOSITE_END_CUS
            where COMPANY_CODE = KPI_SAP001_COPA_TRX_TEMP.COMPANY_CODE
            and PROFIT_CENTER = KPI_SAP001_COPA_TRX_TEMP.PROFIT_CENTER
            --and MTL_GROUP = KPI_SAP001_COPA_TRX_TEMP.MTL_GROUP
            and CUSTOMER_ID = KPI_SAP001_COPA_TRX_TEMP.CUSTOMER_ID
            --and SHIP_TO_PARTY = KPI_SAP001_COPA_TRX_TEMP.SHIP_TO_PARTY
            AND SHIP_TO_PARTY IS NULL
            AND PRODUCT_FLAG IS NOT NULL
            and PRODUCT_NO = KPI_SAP001_COPA_TRX_TEMP.PART_NO
            and START_DATE <= TO_DATE(KPI_SAP001_COPA_TRX_TEMP.POSTING_DATE,'YYYYMMDD')
            and END_DATE >= TO_DATE(KPI_SAP001_COPA_TRX_TEMP.POSTING_DATE,'YYYYMMDD')
        )
    Where  pdm_customer1 is Null
      AND  MTL_TYPE <> 'RAW';
	Commit;
    
    --由material group來判斷end cutomer id (有ship to )
      update KPI_SAP001_COPA_TRX_TEMP set pdm_customer1 =      (
            select distinct END_CUSTOMER_ID
            from KPI_MAP004_5_COMPOSITE_END_CUS
            where COMPANY_CODE = KPI_SAP001_COPA_TRX_TEMP.COMPANY_CODE
            and PROFIT_CENTER = KPI_SAP001_COPA_TRX_TEMP.PROFIT_CENTER
            and MTL_GROUP = KPI_SAP001_COPA_TRX_TEMP.MTL_GROUP
            and CUSTOMER_ID = KPI_SAP001_COPA_TRX_TEMP.CUSTOMER_ID
            and SHIP_TO_PARTY = KPI_SAP001_COPA_TRX_TEMP.SHIP_TO_PARTY
            AND SHIP_TO_PARTY IS NOT NULL
            AND MTL_GROUP_FLAG IS NOT NULL
            AND ROWNUM < 2
            --and PRODUCT_NO = KPI_SAP001_COPA_TRX_TEMP.PART_NO
            and START_DATE <= TO_DATE(KPI_SAP001_COPA_TRX_TEMP.POSTING_DATE,'YYYYMMDD')
            and END_DATE >= TO_DATE(KPI_SAP001_COPA_TRX_TEMP.POSTING_DATE,'YYYYMMDD')
        )
    Where  pdm_customer1 is Null
      AND  MTL_TYPE <> 'RAW';
	Commit;
    --由material group來判斷end cutomer id (無ship to )
      update KPI_SAP001_COPA_TRX_TEMP set pdm_customer1 =      (
            select distinct END_CUSTOMER_ID
            from KPI_MAP004_5_COMPOSITE_END_CUS
            where COMPANY_CODE = KPI_SAP001_COPA_TRX_TEMP.COMPANY_CODE
            and PROFIT_CENTER = KPI_SAP001_COPA_TRX_TEMP.PROFIT_CENTER
            and MTL_GROUP = KPI_SAP001_COPA_TRX_TEMP.MTL_GROUP
            and CUSTOMER_ID = KPI_SAP001_COPA_TRX_TEMP.CUSTOMER_ID
            --and SHIP_TO_PARTY = KPI_SAP001_COPA_TRX_TEMP.SHIP_TO_PARTY
            AND SHIP_TO_PARTY IS NULL
            AND MTL_GROUP_FLAG IS NOT NULL
            AND ROWNUM < 2
            --and PRODUCT_NO = KPI_SAP001_COPA_TRX_TEMP.PART_NO
            and START_DATE <= TO_DATE(KPI_SAP001_COPA_TRX_TEMP.POSTING_DATE,'YYYYMMDD')
            and END_DATE >= TO_DATE(KPI_SAP001_COPA_TRX_TEMP.POSTING_DATE,'YYYYMMDD')
        )
    Where  pdm_customer1 is Null
      AND  MTL_TYPE <> 'RAW';
	Commit;
    --由search term來判斷(但要判斷search term和經管維護的一不一樣)
    	--E. SEARCH_TERM
	Update KPI_SAP001_COPA_TRX_TEMP Set pdm_customer1 = SEARCH_TERM
	--Where COMPANY_CODE = inCompany
	Where pdm_customer1 is Null
    AND  MTL_TYPE <> 'RAW';
    Commit;
    /*
      update KPI_SAP001_COPA_TRX_TEMP set pdm_customer1 =      (
            select distinct END_CUSTOMER_ID
            from KPI_MAP004_5_COMPOSITE_END_CUS
            where COMPANY_CODE = KPI_SAP001_COPA_TRX_TEMP.COMPANY_CODE
            and PROFIT_CENTER = KPI_SAP001_COPA_TRX_TEMP.PROFIT_CENTER
            --and MTL_GROUP = KPI_SAP001_COPA_TRX_TEMP.MTL_GROUP
            and CUSTOMER_ID = KPI_SAP001_COPA_TRX_TEMP.CUSTOMER_ID
            and SHIP_TO_PARTY = KPI_SAP001_COPA_TRX_TEMP.SHIP_TO_PARTY
            AND SHIP_TO_PARTY IS NOT NULL
            AND SEARCH_TERM_FLAG IS NOT NULL
            --and PRODUCT_NO = KPI_SAP001_COPA_TRX_TEMP.PART_NO
            and START_DATE <= TO_DATE(KPI_SAP001_COPA_TRX_TEMP.POSTING_DATE,'YYYYMMDD')
            and END_DATE >= TO_DATE(KPI_SAP001_COPA_TRX_TEMP.POSTING_DATE,'YYYYMMDD')
        )
    Where  pdm_customer1 is Null
      AND  MTL_TYPE <> 'RAW';
	Commit;
    */
END USI11731_UPDATE_CUSTOMER;
/

