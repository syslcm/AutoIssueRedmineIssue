create PROCEDURE       pnl3_pls005_category_gen_trx_1 (
   --inCompany  in VARCHAR2,
   inperiod   IN   VARCHAR2
--2008/10/15 Crate by wenrong
--2008/11/6  要搬到collect_data時,不要再加上mtl_group,ship_to,bill_to,pn等資料,畢竟只是要計算出summary資料而已,不然在200810除了未分配有3萬筆,其他copa/pca/glaccount
--加起來也2萬筆,卻跑出23萬筆的資料
--2008/12/18 因EXPENSE RATE尚未產生但老闆要看,因此從bugdet copy ratio到PNL3_MAP003_EXPENSE_RATE 由PNL3_PLS007_EXPENSE_MAP_TRX_V3 處理,因此
--這裡原本是呼叫PNL3_PLS007_EXPENSE_MAP_TRX_V1也暫由PNL3_PLS007_EXPENSE_MAP_TRX呼叫
-- 2009/2/11 增加執行pnl2_pls001_bad_debt_chang_trx,避免BUG出現
)
AUTHID DEFINER
IS
   --呆帳金額(待寫)
   a_amount_l   pnl3_trx001_copa.amt_twd%TYPE;
   a_amount_t   pnl3_trx001_copa.amt_twd%TYPE;
   a_amount_u   pnl3_trx001_copa.amt_twd%TYPE;
   a_counter    INTEGER;
   a_amt        pnl3_trx001_copa.amt_twd%TYPE;
BEGIN
   pnl3_pls001_copa_trx (inperiod);
                          --將COPA裡正常的資料產生至 PNL2_TRX001_SUMMARY_DATA
   --Revenue比率要在此時產生供後面使用
   pnl3_pls006_revenue_ratio_trx (inperiod);
--在PNL3_PLS001_COPA_TRX裡面執行一次是要做掉COPA COST ELEMENT = 410103以及上傳的revenue但卻是有sap的
--而這裡則是為了沒有sap site的
   pnl3_pls006_expense_ratio_trx (inperiod);
   pnl3_pls002_cogs_trx (inperiod);
--將COPA裡'0000510101','0000510103','0000510104','0000510107',0000510109',0000510110','0000510901','0000510902','0000510903','0000510909','0000510999'
--先產生至PNL2_TRX002_GLACCOUNT , 再由下段PLSQL執行搬至PNL2_TRX001_SUMMARY_DATA
   pnl3_pls003_unut_trx (inperiod);
--將COPA裡'0000510201','0000510301','0000510401','0000510501'先產生至PNL2_TRX003_UN_UTILIZATION
   pnl3_pls004_pca_trx (inperiod);               --產生內移資料至PNL3_PCA_TRX
   pnl3_pls008_realized_trx (inperiod);
                                      --產生已實現資料重新ASSIGN END CUSTOMER
   pnl3_pls009_adjust_trx (inperiod);
--產生調整資料重新ASSIGN END CUSTOMER(2009/1/8原本和已實現一起上傳,2009/2開始上傳一月時分開來)

   --以上PLSQL執行完後再由下段PLSQL執行搬至PNL2_TRX001_SUMMARY_DATA
   --PNL3_PLS007_EXPENSE_MAP_TRX(inPeriod);  --將Earning Model費用資料直接產生至PNL3_TRX005_COLLECT_DETAIL

   --PNL2_PLS002_REALIZED_GM_TRX;產生已實現資料,由WEB驅動PLSQL
   --PNL2_PLS001_BAD_DEBT_TRX :產生費用裡的-呆帳資料,由WEB驅動PLSQL
   BEGIN
      UPDATE pnl3_map007_period_control
         SET period = inperiod
       WHERE period = inperiod;

      IF SQL%NOTFOUND
      THEN
         INSERT INTO pnl3_map007_period_control
                     (period
                     )
              VALUES (inperiod
                     );
      END IF;
   EXCEPTION
      WHEN OTHERS
      THEN
         a_counter := 0;
   END;

   BEGIN
      UPDATE pnl3_map002_year
         SET yyyy = SUBSTRB (inperiod, 1, 4)
       WHERE yyyy = SUBSTRB (inperiod, 1, 4);

      IF SQL%NOTFOUND
      THEN
         INSERT INTO pnl3_map002_year
                     (yyyy
                     )
              VALUES (SUBSTR (inperiod, 1, 4)
                     );
      END IF;
   EXCEPTION
      WHEN OTHERS
      THEN
         UPDATE pnl3_map002_year
            SET yyyy = SUBSTRB (inperiod, 1, 4)
          WHERE yyyy = SUBSTRB (inperiod, 1, 4);
   END;

   DELETE FROM pnl3_trx005_collect_detail
         WHERE period = inperiod;

   COMMIT;

   FOR rec1 IN (SELECT   company_code, period, profit_center, end_customer_id,
                         r_kind, area1, area2, area3, SOURCE,
                         SUM (amt_local) amt_local, SUM (amt_usd) amt_usd,
                         SUM (amt_twd) amt_twd
                    FROM pnl3_trx001_copa
                   WHERE period = inperiod
                GROUP BY company_code,
                         period,
                         profit_center,
                         end_customer_id,
                         r_kind,
                         area1,
                         area2,
                         area3,
                         SOURCE)
   LOOP
      INSERT INTO pnl3_trx005_collect_detail
                  (company_code, period, profit_center,
                   end_customer_id, amt_local, amt_usd,
                   amt_twd, SOURCE, r_kind, area1,
                   area2, area3, create_date
                  )
           VALUES (rec1.company_code, rec1.period, rec1.profit_center,
                   rec1.end_customer_id, rec1.amt_local, rec1.amt_usd,
                   rec1.amt_twd, rec1.SOURCE, rec1.r_kind, rec1.area1,
                   rec1.area2, rec1.area3, SYSDATE
                  );

      COMMIT;
   END LOOP;

   FOR rec1 IN (SELECT   company_code, period, profit_center, end_customer_id,
                         r_kind, area1, area2, area3,
                         SUM (amt_local) amt_local, SUM (amt_usd) amt_usd,
                         SUM (amt_twd) amt_twd
                    FROM pnl3_trx004_pca
                   WHERE period = inperiod
                GROUP BY company_code,
                         period,
                         profit_center,
                         end_customer_id,
                         r_kind,
                         area1,
                         area2,
                         area3)
   LOOP
      INSERT INTO pnl3_trx005_collect_detail
                  (company_code, period, profit_center,
                   end_customer_id, amt_local, amt_usd,
                   amt_twd, SOURCE, r_kind, area1, area2,
                   area3, create_date
                  )
           VALUES (rec1.company_code, rec1.period, rec1.profit_center,
                   rec1.end_customer_id, rec1.amt_local, rec1.amt_usd,
                   rec1.amt_twd, 'PCA', rec1.r_kind, rec1.area1, rec1.area2,
                   rec1.area3, SYSDATE
                  );

      COMMIT;
   END LOOP;

   DELETE FROM pnl3_trx005_collect_detail
         WHERE period = inperiod AND SOURCE = 'GLACCOUNT';

   COMMIT;

   --包含'0000510101','0000510103','0000510104','0000510107',,'0000510901','0000510902','0000510903','0000510909','0000510999'
   FOR rec1 IN (SELECT   company_code, period, profit_center, end_customer_id,
                         r_kind, area1, area2, area3,
                         SUM (amt_local) amt_local, SUM (amt_usd) amt_usd,
                         SUM (amt_twd) amt_twd
                    FROM pnl3_trx002_glaccount
                   WHERE period = inperiod
                GROUP BY company_code,
                         period,
                         profit_center,
                         end_customer_id,
                         r_kind,
                         area1,
                         area2,
                         area3)
   LOOP
      INSERT INTO pnl3_trx005_collect_detail
                  (company_code, period, profit_center,
                   end_customer_id, amt_local, amt_usd,
                   amt_twd, SOURCE, r_kind, area1,
                   area2, area3, create_date
                  )
           VALUES (rec1.company_code, rec1.period, rec1.profit_center,
                   rec1.end_customer_id, rec1.amt_local, rec1.amt_usd,
                   rec1.amt_twd, 'GLACCOUNT', rec1.r_kind, rec1.area1,
                   rec1.area2, rec1.area3, SYSDATE
                  );

      COMMIT;
   END LOOP;

   --包含'0000510109','0000510110','0000510201','0000510301','0000510401','0000510501
   --2008/10/23 User要求分為DL/OH
   DELETE FROM pnl3_trx005_collect_detail
         WHERE period = inperiod AND SOURCE = 'UN-UTILIZATION';

   COMMIT;

   FOR rec1 IN (SELECT   company_code, period, profit_center, end_customer_id,
                         SUM (net_cogs) net_cogs,
                         SUM (net_cogs_usd) net_cogs_usd,
                         SUM (net_cogs_twd) net_cogs_twd,
                         SUM (cogs_mb) cogs_mb, SUM (cogs_mb_usd) cogs_mb_usd,
                         SUM (cogs_mb_twd) cogs_mb_twd, SUM (cogs_lb) cogs_lb,
                         SUM (cogs_lb_usd) cogs_lb_usd,
                         SUM (cogs_lb_twd) cogs_lb_twd, SUM (cogs_ob) cogs_ob,
                         SUM (cogs_ob_usd) cogs_ob_usd,
                         SUM (cogs_ob_twd) cogs_ob_twd
                    FROM pnl3_trx003_unutilization
                   WHERE period = inperiod
                GROUP BY company_code, period, profit_center, end_customer_id)
   LOOP
      IF rec1.cogs_lb <> 0
      THEN
         INSERT INTO pnl3_trx005_collect_detail
                     (company_code, period, profit_center,
                      end_customer_id, amt_local, amt_usd,
                      amt_twd, SOURCE, r_kind, area1, area2,
                      area3, create_date
                     )
              VALUES (rec1.company_code, rec1.period, rec1.profit_center,
                      rec1.end_customer_id, rec1.cogs_lb, rec1.cogs_lb_usd,
                      rec1.cogs_lb_twd, 'UN-UTILIZATION', 'PL01', '2', '5',
                      '0', SYSDATE
                     );

         COMMIT;
      END IF;

      IF rec1.cogs_ob <> 0
      THEN
         INSERT INTO pnl3_trx005_collect_detail
                     (company_code, period, profit_center,
                      end_customer_id, amt_local, amt_usd,
                      amt_twd, SOURCE, r_kind, area1, area2,
                      area3, create_date
                     )
              VALUES (rec1.company_code, rec1.period, rec1.profit_center,
                      rec1.end_customer_id, rec1.cogs_ob, rec1.cogs_ob_usd,
                      rec1.cogs_ob_twd, 'UN-UTILIZATION', 'PL01', '2', '5',
                      '1', SYSDATE
                     );

         COMMIT;
      END IF;
   END LOOP;

   --已實現報表金額(Category 2/2/0)
   DELETE FROM pnl3_trx005_collect_detail
         WHERE period = inperiod AND SOURCE = 'REALIZED_GM';

   COMMIT;

   FOR rec1 IN
      (SELECT   period, profit_center, end_customer_id, company_code,
                SUM (amount_local) amt_local, SUM (amount_usd) amt_usd,
                SUM (amount_twd) amt_twd, SUM (vv006) vv006, SUM (vv007)
                                                                        vv007,
                SUM (vv014) vv014, SUM (vv015) vv015, SUM (vv016) vv016,
                SUM (vv017) vv017, SUM (vv018) vv018, SUM (vv019) vv019
           --FROM PNL2_UPL003_REALIZED_GM  --此為source,有些缺end customer id
       FROM     pnl3_trx007_realized_gm
                                    --改由此table抓,將沒有end customer的都填滿
          WHERE period = inperiod
       GROUP BY period, profit_center, end_customer_id, company_code)
   LOOP
      a_amt :=
           rec1.amt_local
         - rec1.vv006
         - rec1.vv007
         - rec1.vv014
         - rec1.vv015
         - rec1.vv016
         - rec1.vv017
         - rec1.vv018
         - rec1.vv019;

      IF ABS (a_amt) > 0
      THEN
        INSERT INTO pnl3_trx005_collect_detail
                  (company_code, period, profit_center,
                   end_customer_id, amt_local, amt_usd,
                   amt_twd, SOURCE, r_kind, area1, area2, area3,
                   create_date
                  )
             VALUES (rec1.company_code, rec1.period, rec1.profit_center,
                   rec1.end_customer_id, rec1.amt_local, rec1.amt_usd,
                   rec1.amt_twd, 'REALIZED_GM', 'PL01', '2', '2', '0',
                   SYSDATE
                  );

        COMMIT;
      END IF;
   END LOOP;

   --已實現報表金額(Category 2/2/0)
   DELETE FROM pnl3_trx005_collect_detail
         WHERE period = inperiod AND SOURCE = 'CO_ADJUST';

   COMMIT;

   FOR rec1 IN
      (SELECT   period, profit_center, end_customer_id, company_code,
                SUM (amount_local) amt_local, SUM (amount_usd) amt_usd,
                SUM (amount_twd) amt_twd, SUM (vv006) vv006, SUM (vv007)
                                                                        vv007,
                SUM (vv014) vv014, SUM (vv015) vv015, SUM (vv016) vv016,
                SUM (vv017) vv017, SUM (vv018) vv018, SUM (vv019) vv019
           --FROM PNL2_UPL003_REALIZED_GM  --此為source,有些缺end customer id
       FROM     pnl3_trx006_adjust  --改由此table抓,將沒有end customer的都填滿
          WHERE period = inperiod
       GROUP BY period, profit_center, end_customer_id, company_code)
   LOOP
      a_amt :=
           rec1.amt_local
         - rec1.vv006
         - rec1.vv007
         - rec1.vv014
         - rec1.vv015
         - rec1.vv016
         - rec1.vv017
         - rec1.vv018
         - rec1.vv019;

      IF ABS (a_amt) > 0
      THEN
         INSERT INTO pnl3_trx005_collect_detail
                     (company_code, period, profit_center,
                      end_customer_id, amt_local, amt_usd,
                      amt_twd, SOURCE, r_kind, area1, area2, area3,
                      create_date
                     )
              VALUES (rec1.company_code, rec1.period, rec1.profit_center,
                      rec1.end_customer_id, rec1.amt_local, rec1.amt_usd,
                      rec1.amt_twd, 'CO_ADJUST', 'PL01', '2', '2', '0',
                      SYSDATE
                     );

         COMMIT;
      END IF;
   END LOOP;

   --以下在計算加總
    --Net Manufacturing Revenues  (Category:1/4/0)
   DELETE FROM pnl3_trx005_collect_detail
         WHERE period = inperiod
           AND r_kind = 'PL01'
           AND area1 = '1'
           AND area2 = '4'
           AND area3 = '0';

   COMMIT;

   --Gross margin
   DELETE FROM pnl3_trx005_collect_detail
         WHERE period = inperiod
           AND r_kind = 'PL01'
           AND area1 = '3'
           AND area2 = '0'
           AND area3 = '0';

   COMMIT;

   --COGS Subtotal
   DELETE FROM pnl3_trx005_collect_detail
         WHERE period = inperiod
           AND r_kind = 'PL01'
           AND area1 = '2'
           AND area2 = '6'
           AND area3 = '0';

   COMMIT;

   --從Revenue角度來看,但也得考慮到end customer可能沒有Revenue只有成本??雖然不大可能發生,仍要加入這條邏輯(寫在此LOOP後)
   FOR rec1 IN (SELECT   profit_center, end_customer_id, company_code,
                         SUM (amt_local) amt_local, SUM (amt_usd) amt_usd,
                         SUM (amt_twd) amt_twd, SOURCE
                    FROM pnl3_trx005_collect_detail
                   WHERE r_kind = 'PL01'
                     AND period = inperiod
                     AND area1 = '1'
                     AND area2 = '1'
                     AND area3 = '0'
                GROUP BY profit_center, end_customer_id, company_code, SOURCE)
   LOOP
      INSERT INTO pnl3_trx005_collect_detail
                  (company_code, period, profit_center,
                   end_customer_id, amt_local, amt_usd,
                   amt_twd, SOURCE, r_kind, area1, area2, area3,
                   create_date, TYPE
                  )
           VALUES (rec1.company_code, inperiod, rec1.profit_center,
                   rec1.end_customer_id, rec1.amt_local, rec1.amt_usd,
                   rec1.amt_twd, rec1.SOURCE, 'PL01', '1', '4', '0',
                   SYSDATE, 'SUM'
                  );

      COMMIT;
      --Gross margin & COGS Subtotal
      a_amount_l := rec1.amt_local;
      a_amount_t := rec1.amt_twd;
      a_amount_u := rec1.amt_usd;

      FOR rec2 IN (SELECT   profit_center, end_customer_id, company_code,
                            SOURCE, NVL (SUM (amt_local), 0) amt_local,
                            NVL (SUM (amt_usd), 0) amt_usd,
                            NVL (SUM (amt_twd), 0) amt_twd
                       FROM pnl3_trx005_collect_detail
                      WHERE r_kind = 'PL01'
                        AND period = inperiod
                        AND profit_center = rec1.profit_center
                        AND company_code = rec1.company_code
                        AND end_customer_id = rec1.end_customer_id
                        AND SOURCE = rec1.SOURCE
                        AND area1 = '2'
                        AND area2 IN ('2', '3', '4', '5')
                   --AND AREA3  = '0'
                   GROUP BY profit_center,
                            end_customer_id,
                            company_code,
                            SOURCE)
      LOOP
         a_amount_l := a_amount_l - rec2.amt_local;
         a_amount_t := a_amount_t - rec2.amt_twd;
         a_amount_u := a_amount_u - rec2.amt_usd;

         --COGS SubTotal
         INSERT INTO pnl3_trx005_collect_detail
                     (company_code, period, profit_center,
                      end_customer_id, amt_local, amt_usd,
                      amt_twd, SOURCE, r_kind, area1, area2, area3,
                      create_date, TYPE
                     )
              VALUES (rec2.company_code, inperiod, rec2.profit_center,
                      rec2.end_customer_id, rec2.amt_local, rec2.amt_usd,
                      rec2.amt_twd, rec1.SOURCE, 'PL01', '2', '6', '0',
                      SYSDATE, 'SUM'
                     );

         COMMIT;
      END LOOP;

      --Gross margin
      INSERT INTO pnl3_trx005_collect_detail
                  (company_code, period, profit_center,
                   end_customer_id, amt_local, amt_usd, amt_twd,
                   SOURCE, r_kind, area1, area2, area3, create_date, TYPE
                  )
           VALUES (rec1.company_code, inperiod, rec1.profit_center,
                   rec1.end_customer_id, a_amount_l, a_amount_u, a_amount_t,
                   rec1.SOURCE, 'PL01', '3', '0', '0', SYSDATE, 'SUM'
                  );

      COMMIT;
   END LOOP;

   FOR rec1 IN (SELECT   profit_center, end_customer_id, company_code, period,
                         SOURCE, NVL (SUM (amt_local), 0) amt_local,
                         NVL (SUM (amt_usd), 0) amt_usd,
                         NVL (SUM (amt_twd), 0) amt_twd
                    FROM pnl3_trx005_collect_detail
                   WHERE r_kind = 'PL01'
                     AND period = inperiod
                     --AND PROFIT_CENTER = REC1.PROFIT_CENTER
                     --AND COMPANY_CODE = REC1.COMPANY_CODE
                     --AND END_CUSTOMER_ID = REC1.END_CUSTOMER_ID
                     AND area1 = '2'
                     AND area2 IN ('2', '3', '4', '5')
                --AND AREA3  = '0'
                GROUP BY profit_center,
                         end_customer_id,
                         company_code,
                         period,
                         SOURCE)
   LOOP
      a_counter := 0;
      a_amount_l := 0;
      a_amount_t := 0;
      a_amount_u := 0;

      BEGIN
         SELECT   COUNT (*)
             INTO a_counter
             FROM pnl3_trx005_collect_detail
            WHERE r_kind = 'PL01'
              AND period = inperiod
              AND area1 = '1'
              AND area2 = '1'
              AND area3 = '0'
              AND profit_center = rec1.profit_center
              AND end_customer_id = rec1.end_customer_id
              AND company_code = rec1.company_code
              AND SOURCE = rec1.SOURCE
         GROUP BY profit_center, end_customer_id, company_code, SOURCE;

         IF SQL%NOTFOUND
         THEN
            a_counter := 0;
         END IF;
      EXCEPTION
         WHEN OTHERS
         THEN
            a_counter := 0;
      END;

      --表示此PC+SITE+END_CUSTOMER 沒有營收,只有成本
      IF a_counter = 0
      THEN
         INSERT INTO pnl3_trx005_collect_detail
                     (company_code, period, profit_center,
                      end_customer_id, amt_local, amt_usd,
                      amt_twd, SOURCE, r_kind, area1, area2, area3,
                      create_date, TYPE
                     )
              VALUES (rec1.company_code, rec1.period, rec1.profit_center,
                      rec1.end_customer_id, rec1.amt_local, rec1.amt_usd,
                      rec1.amt_twd, rec1.SOURCE, 'PL01', '2', '6', '0',
                      SYSDATE, 'SUM'
                     );

         COMMIT;
         --Gross margin
         a_amount_l := a_amount_l - rec1.amt_local;
         a_amount_t := a_amount_t - rec1.amt_twd;
         a_amount_u := a_amount_u - rec1.amt_usd;

         INSERT INTO pnl3_trx005_collect_detail
                     (company_code, period, profit_center,
                      end_customer_id, amt_local, amt_usd,
                      amt_twd, SOURCE, r_kind, area1, area2, area3,
                      create_date, TYPE
                     )
              VALUES (rec1.company_code, rec1.period, rec1.profit_center,
                      rec1.end_customer_id, a_amount_l, a_amount_u,
                      a_amount_t, rec1.SOURCE, 'PL01', '3', '0', '0',
                      SYSDATE, 'SUM'
                     );

         COMMIT;
      END IF;
   END LOOP;

   pnl2_pls001_bad_debt_chang_trx ('1100', inperiod);
--2009/2/11 重新設定呆帳的end customer id,避免USER上傳時的COPA沒有資料造成END CUSTOMER ID全部是OTHERS
-- 1100 是指上傳的SITE,目前所有呆帳都由TW上傳

   --費用金額(Category 4/X/X)
   IF SUBSTR (inperiod, 1, 4) = '2008'
   THEN
      pnl3_pls010_expense_2008_trx (inperiod);
   ELSE
      pnl3_pls007_expense_map_trx (inperiod);
   END IF;

   --exp.的total 或 subtotal要計算完再加
   FOR rec1 IN (SELECT   profit_center, end_customer_id, company_code, period,
                         SOURCE, NVL (SUM (amt_local), 0) amt_local,
                         NVL (SUM (amt_usd), 0) amt_usd,
                         NVL (SUM (amt_twd), 0) amt_twd
                    FROM pnl3_trx005_collect_detail
                   WHERE r_kind = 'PL01'
                     AND period = inperiod
                     AND area1 = '4'
                     AND area2 = '1'
                     AND area3 BETWEEN '1' AND '89'
                GROUP BY profit_center,
                         end_customer_id,
                         company_code,
                         period,
                         SOURCE)
   LOOP
      INSERT INTO pnl3_trx005_collect_detail
                  (company_code, period, profit_center,
                   end_customer_id, amt_local, amt_usd,
                   amt_twd, SOURCE, r_kind, area1, area2, area3,
                   create_date, TYPE
                  )
           VALUES (rec1.company_code, rec1.period, rec1.profit_center,
                   rec1.end_customer_id, rec1.amt_local, rec1.amt_usd,
                   rec1.amt_twd, rec1.SOURCE, 'PL01', '4', '1', '90',
                   SYSDATE, 'SUM'
                  );

      COMMIT;

      INSERT INTO pnl3_trx005_collect_detail
                  (company_code, period, profit_center,
                   end_customer_id, amt_local, amt_usd, amt_twd, SOURCE,
                   r_kind, area1, area2, area3, create_date, TYPE
                  )
           VALUES (rec1.company_code, rec1.period, rec1.profit_center,
                   rec1.end_customer_id, 0, 0, 0, rec1.SOURCE,
                   'PL01', '4', '1', '0', SYSDATE, 'SUM'
                  );

      COMMIT;
   END LOOP;

   FOR rec1 IN (SELECT   profit_center, end_customer_id, company_code, period,
                         SOURCE
                    FROM pnl3_trx005_collect_detail
                   WHERE r_kind = 'PL01' AND period = inperiod AND area1 = '4'
                GROUP BY profit_center,
                         end_customer_id,
                         company_code,
                         period,
                         SOURCE)
   LOOP
      INSERT INTO pnl3_trx005_collect_detail
                  (company_code, period, profit_center,
                   end_customer_id, amt_local, amt_usd, amt_twd, SOURCE,
                   r_kind, area1, area2, area3, create_date, TYPE
                  )
           VALUES (rec1.company_code, rec1.period, rec1.profit_center,
                   rec1.end_customer_id, 0, 0, 0, rec1.SOURCE,
                   'PL01', '4', '0', '0', SYSDATE, 'SUM'
                  );

      COMMIT;
   END LOOP;

   FOR rec1 IN (SELECT   profit_center, end_customer_id, company_code, period,
                         SOURCE, NVL (SUM (amt_local), 0) amt_local,
                         NVL (SUM (amt_usd), 0) amt_usd,
                         NVL (SUM (amt_twd), 0) amt_twd
                    FROM pnl3_trx005_collect_detail
                   WHERE r_kind = 'PL01'
                     AND period = inperiod
                     AND area1 = '4'
                     AND area2 = '2'
                     AND area3 BETWEEN '1' AND '89'
                GROUP BY profit_center,
                         end_customer_id,
                         company_code,
                         period,
                         SOURCE)
   LOOP
      INSERT INTO pnl3_trx005_collect_detail
                  (company_code, period, profit_center,
                   end_customer_id, amt_local, amt_usd,
                   amt_twd, SOURCE, r_kind, area1, area2, area3,
                   create_date, TYPE
                  )
           VALUES (rec1.company_code, rec1.period, rec1.profit_center,
                   rec1.end_customer_id, rec1.amt_local, rec1.amt_usd,
                   rec1.amt_twd, rec1.SOURCE, 'PL01', '4', '2', '90',
                   SYSDATE, 'SUM'
                  );

      COMMIT;

      INSERT INTO pnl3_trx005_collect_detail
                  (company_code, period, profit_center,
                   end_customer_id, amt_local, amt_usd, amt_twd, SOURCE,
                   r_kind, area1, area2, area3, create_date, TYPE
                  )
           VALUES (rec1.company_code, rec1.period, rec1.profit_center,
                   rec1.end_customer_id, 0, 0, 0, rec1.SOURCE,
                   'PL01', '4', '2', '0', SYSDATE, 'SUM'
                  );

      COMMIT;
   END LOOP;

   FOR rec1 IN (SELECT   profit_center, end_customer_id, company_code, period,
                         SOURCE, NVL (SUM (amt_local), 0) amt_local,
                         NVL (SUM (amt_usd), 0) amt_usd,
                         NVL (SUM (amt_twd), 0) amt_twd
                    FROM pnl3_trx005_collect_detail
                   WHERE r_kind = 'PL01'
                     AND period = inperiod
                     AND area1 = '4'
                     AND area2 = '3'
                     AND area3 BETWEEN '1' AND '89'
                GROUP BY profit_center,
                         end_customer_id,
                         company_code,
                         period,
                         SOURCE)
   LOOP
      INSERT INTO pnl3_trx005_collect_detail
                  (company_code, period, profit_center,
                   end_customer_id, amt_local, amt_usd,
                   amt_twd, SOURCE, r_kind, area1, area2, area3,
                   create_date, TYPE
                  )
           VALUES (rec1.company_code, rec1.period, rec1.profit_center,
                   rec1.end_customer_id, rec1.amt_local, rec1.amt_usd,
                   rec1.amt_twd, rec1.SOURCE, 'PL01', '4', '3', '90',
                   SYSDATE, 'SUM'
                  );

      COMMIT;

      INSERT INTO pnl3_trx005_collect_detail
                  (company_code, period, profit_center,
                   end_customer_id, amt_local, amt_usd, amt_twd, SOURCE,
                   r_kind, area1, area2, area3, create_date, TYPE
                  )
           VALUES (rec1.company_code, rec1.period, rec1.profit_center,
                   rec1.end_customer_id, 0, 0, 0, rec1.SOURCE,
                   'PL01', '4', '3', '0', SYSDATE, 'SUM'
                  );

      COMMIT;
   END LOOP;

   FOR rec1 IN (SELECT   profit_center, end_customer_id, company_code, period,
                         SOURCE, NVL (SUM (amt_local), 0) amt_local,
                         NVL (SUM (amt_usd), 0) amt_usd,
                         NVL (SUM (amt_twd), 0) amt_twd
                    FROM pnl3_trx005_collect_detail
                   WHERE r_kind = 'PL01'
                     AND period = inperiod
                     AND area1 = '4'
                     AND area3 = '90'
                GROUP BY profit_center,
                         end_customer_id,
                         company_code,
                         period,
                         SOURCE)
   LOOP
      INSERT INTO pnl3_trx005_collect_detail
                  (company_code, period, profit_center,
                   end_customer_id, amt_local, amt_usd,
                   amt_twd, SOURCE, r_kind, area1, area2, area3,
                   create_date, TYPE
                  )
           VALUES (rec1.company_code, rec1.period, rec1.profit_center,
                   rec1.end_customer_id, rec1.amt_local, rec1.amt_usd,
                   rec1.amt_twd, rec1.SOURCE, 'PL01', '4', '4', '0',
                   SYSDATE, 'SUM'
                  );

      COMMIT;
   END LOOP;

   FOR rec1 IN (SELECT   company_code, profit_center, end_customer_id,
                         SUM (amt_local) amt_local, SUM (amt_usd) amt_usd,
                         SUM (amt_twd) amt_twd
                    FROM pnl3_trx005_collect_detail
                   WHERE period = inperiod
                     AND r_kind = 'PL01'
                     AND area1 = '3'
                     AND area2 = '0'
                     AND area3 = '0'
                GROUP BY company_code, profit_center, end_customer_id)
   LOOP
      a_counter := 0;
      a_amount_l := rec1.amt_local;
      a_amount_t := rec1.amt_twd;
      a_amount_u := rec1.amt_usd;

      FOR rec2 IN (SELECT   profit_center, end_customer_id, company_code,
                            NVL (SUM (amt_local), 0) amt_local,
                            NVL (SUM (amt_usd), 0) amt_usd,
                            NVL (SUM (amt_twd), 0) amt_twd
                       FROM pnl3_trx005_collect_detail
                      WHERE r_kind = 'PL01'
                        AND period = inperiod
                        AND profit_center = rec1.profit_center
                        AND company_code = rec1.company_code
                        AND end_customer_id = rec1.end_customer_id
                        AND area1 = '4'
                        AND area2 = '4'
                        AND area3 = '0'
                   GROUP BY profit_center, end_customer_id, company_code)
      LOOP
         a_amount_l := a_amount_l + rec2.amt_local;
         a_amount_t := a_amount_t + rec2.amt_twd;
         a_amount_u := a_amount_u + rec2.amt_usd;
         a_counter := a_counter + 1;

         --COGS SubTotal
         INSERT INTO pnl3_trx005_collect_detail
                     (company_code, period, profit_center,
                      end_customer_id, amt_local, amt_usd,
                      amt_twd, SOURCE, r_kind, area1, area2, area3,
                      create_date, TYPE
                     )
              VALUES (rec2.company_code, inperiod, rec2.profit_center,
                      rec2.end_customer_id, a_amount_l, a_amount_u,
                      a_amount_t, 'TOTAL', 'PL01', '4', '5', '0',
                      SYSDATE, 'SUM'
                     );

         COMMIT;
      END LOOP;

      IF a_counter = 0
      THEN
         INSERT INTO pnl3_trx005_collect_detail
                     (company_code, period, profit_center,
                      end_customer_id, amt_local, amt_usd,
                      amt_twd, SOURCE, r_kind, area1, area2, area3,
                      create_date, TYPE
                     )
              VALUES (rec1.company_code, inperiod, rec1.profit_center,
                      rec1.end_customer_id, a_amount_l, a_amount_u,
                      a_amount_t, 'TOTAL', 'PL01', '4', '5', '0',
                      SYSDATE, 'SUM'
                     );

         COMMIT;
      END IF;
   END LOOP;

   FOR rec2 IN (SELECT   profit_center, end_customer_id, company_code,
                         NVL (SUM (amt_local), 0) amt_local,
                         NVL (SUM (amt_usd), 0) amt_usd,
                         NVL (SUM (amt_twd), 0) amt_twd
                    FROM pnl3_trx005_collect_detail
                   WHERE r_kind = 'PL01'
                     AND period = inperiod
                     AND area1 = '4'
                     AND area2 = '4'
                     AND area3 = '0'
                GROUP BY profit_center, end_customer_id, company_code)
   LOOP
      a_amount_l := rec2.amt_local;
      a_amount_t := rec2.amt_twd;
      a_amount_u := rec2.amt_usd;
      a_counter := 0;

      BEGIN
         SELECT COUNT (*)
           INTO a_counter
           FROM pnl3_trx005_collect_detail
          WHERE r_kind = 'PL01'
            AND period = inperiod
            AND profit_center = rec2.profit_center
            AND company_code = rec2.company_code
            AND end_customer_id = rec2.end_customer_id
            AND area1 = '3'
            AND area2 = '0'
            AND area3 = '0';
      EXCEPTION
         WHEN OTHERS
         THEN
            a_counter := 0;
      END;

      IF a_counter = 0
      THEN
         INSERT INTO pnl3_trx005_collect_detail
                     (company_code, period, profit_center,
                      end_customer_id, amt_local, amt_usd,
                      amt_twd, SOURCE, r_kind, area1, area2, area3,
                      create_date, TYPE
                     )
              VALUES (rec2.company_code, inperiod, rec2.profit_center,
                      rec2.end_customer_id, a_amount_l, a_amount_u,
                      a_amount_t, 'TOTAL', 'PL01', '4', '5', '0',
                      SYSDATE, 'SUM'
                     );

         COMMIT;
      END IF;
   END LOOP;

   ---以下兩段UPDATE 指令在將金額由正轉負由負轉正
   UPDATE pnl3_trx005_collect_detail
      SET acct_rate =
             (SELECT rate
                FROM pnl2_map001_acct_mapping
               WHERE r_kind = pnl3_trx005_collect_detail.r_kind
                 AND area1 = pnl3_trx005_collect_detail.area1
                 AND area2 = pnl3_trx005_collect_detail.area2
                 AND area3 = pnl3_trx005_collect_detail.area3)
    WHERE period = inperiod;

   COMMIT;

   UPDATE pnl3_trx005_collect_detail
      SET amt_twd = amt_twd * acct_rate,
          amt_usd = amt_usd * acct_rate,
          amt_local = amt_local * acct_rate
    WHERE period = inperiod;

   COMMIT;
--呆帳金額,待user上傳

--產出另一個報表
 --PNL2_PLS008_GEN_CUS_RPT_TRX(inPeriod);
END pnl3_pls005_category_gen_trx_1;
/

