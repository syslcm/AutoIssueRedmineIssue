create PROCEDURE         "VRTN_PLSQL_SUM6_LOC_QQ" AUTHID DEFINER
IS
  /*
   Susan Create: 
   modify 2007/08/24 by Susan for amount_share_site
          2007/09/26 by Susan for GV_PER
	      2007/10/02 by Susan clear by Susan for site_per SUM14,SUM15
  */

  vYYYYQQ                    varchar2(6);
  vYYYY                      varchar2(4);
  vQ                         varchar2(1);
  vMM1                       varchar2(2);
  vMM2                       varchar2(2);
  vMM3                       varchar2(2);
  vQ_RANKING                 number(5);
  vSITE                      VRTN_SUM14_QQ_MATGP.SITE%TYPE;
  vMATGROUP                  VRTN_SUM14_QQ_MATGP.MATGROUP%TYPE;

  Q0_VALUE                   VRTN_MAP060_LEVEL_DESC.VALUE%TYPE;
  QA_VALUE                   VRTN_MAP060_LEVEL_DESC.VALUE%TYPE;
  QB_VALUE                   VRTN_MAP060_LEVEL_DESC.VALUE%TYPE;
  QC_VALUE                   VRTN_MAP060_LEVEL_DESC.VALUE%TYPE;
  QD_VALUE                   VRTN_MAP060_LEVEL_DESC.VALUE%TYPE;
  C0_VALUE                   VRTN_MAP060_LEVEL_DESC.VALUE%TYPE;
  CA_VALUE                   VRTN_MAP060_LEVEL_DESC.VALUE%TYPE;
  CB_VALUE                   VRTN_MAP060_LEVEL_DESC.VALUE%TYPE;
  CC_VALUE                   VRTN_MAP060_LEVEL_DESC.VALUE%TYPE;
  CD_VALUE                   VRTN_MAP060_LEVEL_DESC.VALUE%TYPE;
  D0_VALUE                   VRTN_MAP060_LEVEL_DESC.VALUE%TYPE;
  D1_VALUE                   VRTN_MAP060_LEVEL_DESC.VALUE%TYPE;
  D2_VALUE                   VRTN_MAP060_LEVEL_DESC.VALUE%TYPE;
  D3_VALUE                   VRTN_MAP060_LEVEL_DESC.VALUE%TYPE;
  DE_VALUE                   VRTN_MAP060_LEVEL_DESC.VALUE%TYPE;
  DF_VALUE                   VRTN_MAP060_LEVEL_DESC.VALUE%TYPE;
  DG_VALUE                   VRTN_MAP060_LEVEL_DESC.VALUE%TYPE;
  DH_VALUE                   VRTN_MAP060_LEVEL_DESC.VALUE%TYPE;
  DI_VALUE                   VRTN_MAP060_LEVEL_DESC.VALUE%TYPE;
  DJ_VALUE                   VRTN_MAP060_LEVEL_DESC.VALUE%TYPE;

  iTracePoint                varchar2(100);
  cErrorText                 varchar2(500);

BEGIN
  iTracePoint := '000';
  select * into vYYYYQQ, vYYYY, vQ from (
    select trim(trim(to_char(add_months(SYSDATE,-1), 'YYYY')) || 'Q' || trim(to_char(add_months(SYSDATE,-1), 'Q'))),
           trim(to_char(add_months(SYSDATE,-1), 'YYYY')), trim(to_char(add_months(SYSDATE,-1), 'Q'))
      from dual
  );

  if vQ = '1' then
    vMM1 := '01';
    vMM2 := '02';
    vMM3 := '03';
  elsif vQ = '2' then
    vMM1 := '04';
    vMM2 := '05';
    vMM3 := '06';
  elsif vQ = '3' then
    vMM1 := '07';
    vMM2 := '08';
    vMM3 := '09';
  else
    vMM1 := '10';
    vMM2 := '11';
    vMM3 := '12';
  end if;

  iTracePoint := '050';  --Get VRTN_MAP060_LEVEL_DESC value
  Q0_VALUE := 0;
  QA_VALUE := 0;
  QB_VALUE := 0;
  QC_VALUE := 0;
  QD_VALUE := 0;
  C0_VALUE := 0;
  CA_VALUE := 0;
  CB_VALUE := 0;
  CC_VALUE := 0;
  CD_VALUE := 0;
  D0_VALUE := 0;
  D1_VALUE := 0;
  D2_VALUE := 0;
  D3_VALUE := 0;
  DE_VALUE := 0;
  DF_VALUE := 0;
  DG_VALUE := 0;
  DH_VALUE := 0;
  DI_VALUE := 0;
  DJ_VALUE := 0;

  for REC1 in (
     select distinct LEVEL_S, VALUE from VRTN_MAP060_LEVEL_DESC where VALUE is not null
  ) loop
     if REC1.LEVEL_S = 'Q0' then
       Q0_VALUE := REC1.VALUE;
     elsif REC1.LEVEL_S = 'QA' then
       QA_VALUE := REC1.VALUE;
     elsif REC1.LEVEL_S = 'QB' then
       QB_VALUE := REC1.VALUE;
     elsif REC1.LEVEL_S = 'QC' then
       QC_VALUE := REC1.VALUE;
     elsif REC1.LEVEL_S = 'QD' then
       QD_VALUE := REC1.VALUE;
     elsif REC1.LEVEL_S = 'C0' then
       C0_VALUE := REC1.VALUE;
     elsif REC1.LEVEL_S = 'CA' then
       CA_VALUE := REC1.VALUE;
     elsif REC1.LEVEL_S = 'CB' then
       CB_VALUE := REC1.VALUE;
     elsif REC1.LEVEL_S = 'CC' then
       CC_VALUE := REC1.VALUE;
     elsif REC1.LEVEL_S = 'CD' then
       CD_VALUE := REC1.VALUE;
     elsif REC1.LEVEL_S = 'D0' then
       D0_VALUE := REC1.VALUE;
     elsif REC1.LEVEL_S = 'D1' then
       D1_VALUE := REC1.VALUE;
     elsif REC1.LEVEL_S = 'D2' then
       D2_VALUE := REC1.VALUE;
     elsif REC1.LEVEL_S = 'D3' then
       D3_VALUE := REC1.VALUE;
     elsif REC1.LEVEL_S = 'DE' then
       DE_VALUE := REC1.VALUE;
     elsif REC1.LEVEL_S = 'DF' then
       DF_VALUE := REC1.VALUE;
     elsif REC1.LEVEL_S = 'DG' then
       DG_VALUE := REC1.VALUE;
     elsif REC1.LEVEL_S = 'DH' then
       DH_VALUE := REC1.VALUE;
     elsif REC1.LEVEL_S = 'DI' then
       DI_VALUE := REC1.VALUE;
     elsif REC1.LEVEL_S = 'DJ' then
       DJ_VALUE := REC1.VALUE;
     end if;
  end loop;


  iTracePoint := '100';  --刪除 VRTN_SUM14_QQ_MATGP
  delete from VRTN_SUM14_QQ_MATGP
   where QUARTER = vYYYYQQ;
  commit;

  iTracePoint := '110';
  insert into VRTN_SUM14_QQ_MATGP ( SITE, VENDOR, MATGROUP, QUARTER, GV_VENDOR, BUKRS, Q_AMOUNT, FROM_DATE, TO_DATE, SITE_PER, AMT_SHARE_SITE, DATE_TIME,
           Q_QA_GRADE, Q_QB_GRADE, Q_QC_GRADE, Q_QD_GRADE, Q_CA_GRADE, Q_CB_GRADE, CC_GRADE, Q_CD_GRADE,
           Q_D1_GRADE, Q_D2_GRADE, Q_DE_GRADE, Q_DF_GRADE, Q_DG_GRADE, Q_DH_GRADE, Q_DI_GRADE, Q_DJ_GRADE,
           Q_SUBTOT_D3, Q_SUBTOT_D, Q_MM_SCORE, GV_PER )
    select a.SITE, a.VENDOR, a.MATGROUP, a.QUARTER, a.GV_VENDOR, a.BUKRS, sum(b.AMOUNT) as Q_AMOUNT,
           a.FROM_DATE, a.TO_DATE, '', '',
           to_char(SYSDATE, 'yyyymmddhh24miss') as DATE_TIME,
           round(sum(b.AMOUNT * b.QA_GRADE) / sum(b.AMOUNT),5) as Q_QA_GRADE,
           round(sum(b.AMOUNT * b.QB_GRADE) / sum(b.AMOUNT),5) as Q_QB_GRADE,
           round(sum(b.AMOUNT * b.QC_GRADE) / sum(b.AMOUNT),5) as Q_QC_GRADE,
           round(sum(b.AMOUNT * b.QD_GRADE) / sum(b.AMOUNT),5) as Q_QD_GRADE,
           round(sum(b.AMOUNT * b.CA_GRADE) / sum(b.AMOUNT),5) as Q_CA_GRADE,
           round(sum(b.AMOUNT * b.CB_GRADE) / sum(b.AMOUNT),5) as Q_CB_GRADE,
           round(sum(b.AMOUNT * b.CC_GRADE) / sum(b.AMOUNT),5) as CC_GRADE,
           round(sum(b.AMOUNT * b.CD_GRADE) / sum(b.AMOUNT),5) as Q_CD_GRADE,
           round(sum(b.AMOUNT * b.D1_GRADE) / sum(b.AMOUNT),5) as Q_D1_GRADE,
           round(sum(b.AMOUNT * b.D2_GRADE) / sum(b.AMOUNT),5) as Q_D2_GRADE,
           round(sum(b.AMOUNT * b.DE_GRADE) / sum(b.AMOUNT),5) as Q_DE_GRADE,
           round(sum(b.AMOUNT * b.DF_GRADE) / sum(b.AMOUNT),5) as Q_DF_GRADE,
           round(sum(b.AMOUNT * b.DG_GRADE) / sum(b.AMOUNT),5) as Q_DG_GRADE,
           round(sum(b.AMOUNT * b.DH_GRADE) / sum(b.AMOUNT),5) as Q_DH_GRADE,
           round(sum(b.AMOUNT * b.DI_GRADE) / sum(b.AMOUNT),5) as Q_DI_GRADE,
           round(sum(b.AMOUNT * b.DJ_GRADE) / sum(b.AMOUNT),5) as Q_DJ_GRADE,
           round(sum(b.AMOUNT * b.SUBTOT_D3) / sum(b.AMOUNT),5) as Q_SUBTOT_D3,
           round(sum(b.AMOUNT * b.SUBTOT_D) / sum(b.AMOUNT),5) as Q_SUBTOT_D,
           round(sum(b.AMOUNT * b.MM_SCORE) / sum(b.AMOUNT),5) as Q_MM_SCORE,
           a.GV_PER
      from VRTN_SUM04_AMT_MATGP_Q a, VRTN_SUM11_MM_MATGP b
     where a.SITE = b.SITE           and a.VENDOR = b.VENDOR
       and a.MATGROUP = b.MATGROUP   and a.QUARTER = b.QUARTER
       and a.GV_VENDOR = b.GV_VENDOR and a.BUKRS = b.BUKRS
       and a.QUARTER = vYYYYQQ
     group by a.SITE, a.VENDOR, a.MATGROUP, a.QUARTER, a.GV_VENDOR, a.BUKRS, a.FROM_DATE, a.TO_DATE, a.SITE_PER, a.GV_PER;
  commit;

  iTracePoint := '120';
  for REC1 in (
     select * from VRTN_SUM11_MM_MATGP where YYYY = vYYYY and MM = vMM1
  ) loop
     Update VRTN_SUM14_QQ_MATGP
        set QA_10_GRADE = REC1.QA_GRADE,
            QB_10_GRADE = REC1.QB_GRADE,
            QC_10_GRADE = REC1.QC_GRADE,
            QD_10_GRADE = REC1.QD_GRADE,
            SUBTOT_10_Q = REC1.SUBTOT_Q,
            CA_10_GRADE = REC1.CA_GRADE,
            CB_10_GRADE = REC1.CB_GRADE,
            CC_10_GRADE = REC1.CC_GRADE,
            CD_10_GRADE = REC1.CD_GRADE,
            SUBTOT_10_C = REC1.SUBTOT_C,
            D1_10_GRADE = REC1.D1_GRADE,
            D2_10_GRADE = REC1.D2_GRADE,
            DE_10_GRADE = REC1.DE_GRADE,
            DF_10_GRADE = REC1.DF_GRADE,
            DG_10_GRADE = REC1.DG_GRADE,
            DH_10_GRADE = REC1.DH_GRADE,
            DI_10_GRADE = REC1.DI_GRADE,
            DJ_10_GRADE = REC1.DJ_GRADE,
            TOT_10_CQD = REC1.TOT_CQD,
            SUBTOT_10_D3 = REC1.SUBTOT_D3,
            TOT_10_D = REC1.TOT_D1_D2_D3,
            SUBTOT_10_D = REC1.SUBTOT_D,
            TOT_10_QCD = REC1.MM_SCORE,
            Q_10_SCORE = REC1.MM_SCORE
      where SITE = REC1.SITE
        and VENDOR = REC1.VENDOR
        and MATGROUP = REC1.MATGROUP
        and QUARTER = REC1.QUARTER;
     commit;
  end loop;

  iTracePoint := '130';
  for REC1 in (
     select * from VRTN_SUM11_MM_MATGP where YYYY = vYYYY and MM = vMM2
  ) loop
     Update VRTN_SUM14_QQ_MATGP
        set QA_11_GRADE = REC1.QA_GRADE,
            QB_11_GRADE = REC1.QB_GRADE,
            QC_11_GRADE = REC1.QC_GRADE,
            QD_11_GRADE = REC1.QD_GRADE,
            SUBTOT_11_Q = REC1.SUBTOT_Q,
            CA_11_GRADE = REC1.CA_GRADE,
            CB_11_GRADE = REC1.CB_GRADE,
            CC_11_GRADE = REC1.CC_GRADE,
            CD_11_GRADE = REC1.CD_GRADE,
            SUBTOT_11_C = REC1.SUBTOT_C,
            D1_11_GRADE = REC1.D1_GRADE,
            D2_11_GRADE = REC1.D2_GRADE,
            DE_11_GRADE = REC1.DE_GRADE,
            DF_11_GRADE = REC1.DF_GRADE,
            DG_11_GRADE = REC1.DG_GRADE,
            DH_11_GRADE = REC1.DH_GRADE,
            DI_11_GRADE = REC1.DI_GRADE,
            DJ_11_GRADE = REC1.DJ_GRADE,
            TOT_11_CQD = REC1.TOT_CQD,
            SUBTOT_11_D3 = REC1.SUBTOT_D3,
            TOT_11_D = REC1.TOT_D1_D2_D3,
            SUBTOT_11_D = REC1.SUBTOT_D,
            TOT_11_QCD = REC1.MM_SCORE,
            Q_11_SCORE = REC1.MM_SCORE
      where SITE = REC1.SITE
        and VENDOR = REC1.VENDOR
        and MATGROUP = REC1.MATGROUP
        and QUARTER = REC1.QUARTER;
     commit;
  end loop;

  iTracePoint := '140';
  for REC1 in (
     select * from VRTN_SUM11_MM_MATGP where YYYY = vYYYY and MM = vMM3
  ) loop
     Update VRTN_SUM14_QQ_MATGP
        set QA_12_GRADE = REC1.QA_GRADE,
            QB_12_GRADE = REC1.QB_GRADE,
            QC_12_GRADE = REC1.QC_GRADE,
            QD_12_GRADE = REC1.QD_GRADE,
            SUBTOT_12_Q = REC1.SUBTOT_Q,
            CA_12_GRADE = REC1.CA_GRADE,
            CB_12_GRADE = REC1.CB_GRADE,
            CC_12_GRADE = REC1.CC_GRADE,
            CD_12_GRADE = REC1.CD_GRADE,
            SUBTOT_12_C = REC1.SUBTOT_C,
            D1_12_GRADE = REC1.D1_GRADE,
            D2_12_GRADE = REC1.D2_GRADE,
            DE_12_GRADE = REC1.DE_GRADE,
            DF_12_GRADE = REC1.DF_GRADE,
            DG_12_GRADE = REC1.DG_GRADE,
            DH_12_GRADE = REC1.DH_GRADE,
            DI_12_GRADE = REC1.DI_GRADE,
            DJ_12_GRADE = REC1.DJ_GRADE,
            TOT_12_CQD = REC1.TOT_CQD,
            SUBTOT_12_D3 = REC1.SUBTOT_D3,
            TOT_12_D = REC1.TOT_D1_D2_D3,
            SUBTOT_12_D = REC1.SUBTOT_D,
            TOT_12_QCD = REC1.MM_SCORE,
            Q_12_SCORE = REC1.MM_SCORE
      where SITE = REC1.SITE
        and VENDOR = REC1.VENDOR
        and MATGROUP = REC1.MATGROUP
        and QUARTER = REC1.QUARTER;
     commit;
  end loop;

  iTracePoint := '151';
  Update VRTN_SUM14_QQ_MATGP
     set SUBTOT_Q = round( (nvl(Q_QA_GRADE,0) * QA_VALUE) + (nvl(Q_QB_GRADE,0) * QB_VALUE) + (nvl(Q_QC_GRADE,0) * QC_VALUE) + (nvl(Q_QD_GRADE,0) * QD_VALUE), 5)
   where QUARTER = vYYYYQQ
     and ( Q_QA_GRADE is not null or Q_QB_GRADE is not null or Q_QC_GRADE is not null or Q_QD_GRADE is not null );
  commit;

  iTracePoint := '152';
  Update VRTN_SUM14_QQ_MATGP
     set SUBTOT_C = round( (nvl(Q_CA_GRADE,0) * CA_VALUE) + (nvl(Q_CB_GRADE,0) * CB_VALUE) + (nvl(CC_GRADE,0) * CC_VALUE) + (nvl(Q_CD_GRADE,0) * CD_VALUE), 5)
   where QUARTER = vYYYYQQ
     and ( Q_CA_GRADE is not null or Q_CB_GRADE is not null or CC_GRADE is not null or Q_CD_GRADE is not null );
  commit;

  iTracePoint := '153';
  Update VRTN_SUM14_QQ_MATGP
     set SUBTOT_D3 = round( (nvl(Q_DE_GRADE,0) * DE_VALUE) + (nvl(Q_DF_GRADE,0) * DF_VALUE) + (nvl(Q_DG_GRADE,0) * DG_VALUE) + (nvl(Q_DH_GRADE,0) * DH_VALUE) + (nvl(Q_DI_GRADE,0) * DI_VALUE) + (nvl(Q_DJ_GRADE,0) * DJ_VALUE), 5)
   where QUARTER = vYYYYQQ
     and ( Q_DE_GRADE is not null or Q_DF_GRADE is not null or Q_DG_GRADE is not null or Q_DH_GRADE is not null or Q_DI_GRADE is not null or Q_DJ_GRADE is not null );
  commit;

  /*
  iTracePoint := '154';
  Update VRTN_SUM14_QQ_MATGP
     set Q_SUBTOT_D3 = round(SUBTOT_D3 * ( 1 / ( decode(Q_DE_GRADE,null,0,DE_VALUE) + decode(Q_DF_GRADE,null,0,DF_VALUE) + decode(Q_DG_GRADE,null,0,DG_VALUE) +
                                             decode(Q_DH_GRADE,null,0,DH_VALUE) + decode(Q_DI_GRADE,null,0,DI_VALUE) + decode(Q_DJ_GRADE,null,0,DJ_VALUE) ) ), 5)
   where QUARTER = vYYYYQQ
     and SUBTOT_D3 is not null;
  commit;
  */

  iTracePoint := '155';
  Update VRTN_SUM14_QQ_MATGP
     set SUBTOT_D = round( (nvl(Q_D1_GRADE,0) * D1_VALUE) + (nvl(Q_D2_GRADE,0) * D2_VALUE) + (nvl(Q_SUBTOT_D3,0) * D3_VALUE), 5)
   where QUARTER = vYYYYQQ
     and ( Q_D1_GRADE is not null or Q_D2_GRADE is not null or Q_SUBTOT_D3 is not null );
  commit;

  /*
  iTracePoint := '156';
  Update VRTN_SUM14_QQ_MATGP
     set Q_SUBTOT_D = round( SUBTOT_D * ( 1 / ( decode(Q_D1_GRADE,null,0,D1_VALUE) + decode(Q_D2_GRADE,null,0,D2_VALUE) + decode(Q_SUBTOT_D3,null,0,D3_VALUE) ) ), 5)
   where QUARTER = vYYYYQQ
     and SUBTOT_D is not null;
  commit;
  */

  iTracePoint := '157';
  Update VRTN_SUM14_QQ_MATGP
     set MM_SCORE = round( ( nvl(SUBTOT_Q,0) * Q0_VALUE ) + ( nvl(SUBTOT_C,0) * C0_VALUE ) + ( nvl(Q_SUBTOT_D,0) * D0_VALUE ), 5)
   where QUARTER = vYYYYQQ
     and ( SUBTOT_Q is not null or SUBTOT_C is not null or Q_SUBTOT_D is not null );
  commit;

  iTracePoint := '160';
  vQ_RANKING := 0;
  vSITE := '0000';
  vMATGROUP := '000';
  for REC1 in (
     select a.SITE, a.VENDOR, a.MATGROUP, a.QUARTER, ( select b.GRADE from VRTN_SUM23_MAPPING_GRADE b where b.RANGE_TYPE = 'SC' and b.RANGE_FROM <= a.MM_SCORE and b.RANGE_TO >= a.MM_SCORE ) as Q_GRADE
       from VRTN_SUM14_QQ_MATGP a
      where a.QUARTER = vYYYYQQ
      order by a.SITE asc, a.MM_SCORE desc, a.SUBTOT_Q desc, a.SUBTOT_C desc, a.Q_SUBTOT_D desc, a.Q_AMOUNT desc
  ) loop
     if vSITE <> REC1.SITE then
       vQ_RANKING := 0;
       vSITE := REC1.SITE;
       vMATGROUP := REC1.MATGROUP;
     end if;
     vQ_RANKING := vQ_RANKING + 1;
     Update VRTN_SUM14_QQ_MATGP
        set Q_GRADE = REC1.Q_GRADE,
            Q_RANKING = vQ_RANKING
      where SITE = REC1.SITE
        and VENDOR = REC1.VENDOR
        and MATGROUP = REC1.MATGROUP
        and QUARTER = REC1.QUARTER;
     commit;
  end loop;

-- Susan mark 2007/08/24
--  iTracePoint := '170';
--  for REC1 in (
--     select a.SITE, a.MATGROUP, a.QUARTER, sum(Q_AMOUNT) as SITE_Q_AMOUNT
--       from VRTN_SUM14_QQ_MATGP a
--      where a.QUARTER = vYYYYQQ
--      group by a.SITE, a.MATGROUP, a.QUARTER
--  ) loop
--     Update VRTN_SUM14_QQ_MATGP
--        set AMT_SHARE_SITE = round(Q_AMOUNT / REC1.SITE_Q_AMOUNT, 5)
--      where SITE = REC1.SITE
--        and MATGROUP = REC1.MATGROUP
--        and QUARTER = REC1.QUARTER;
--     commit;
--  end loop;

-- Susan 2007/09/26
  iTracePoint := '170';
  for REC1 in (
     select a.SITE, a.MATGROUP, a.QUARTER, sum(Q_AMOUNT) as SITE_Q_AMOUNT
       from VRTN_SUM14_QQ_MATGP a
      where a.QUARTER = vYYYYQQ
      group by a.SITE, a.MATGROUP, a.QUARTER
  ) loop
     Update VRTN_SUM14_QQ_MATGP
        set AMT_SHARE_SITE = round(Q_AMOUNT / REC1.SITE_Q_AMOUNT, 5) * 100
      where SITE = REC1.SITE
        and MATGROUP = REC1.MATGROUP
        and QUARTER = REC1.QUARTER;
     commit;
  end loop;


  iTracePoint := '200';  --刪除 VRTN_SUM15_QQ_VM
  delete from VRTN_SUM15_QQ_VM
   where QUARTER = vYYYYQQ;
  commit;

  iTracePoint := '210';
  insert into VRTN_SUM15_QQ_VM ( SITE, VENDOR, QUARTER, GV_VENDOR, BUKRS, Q_AMOUNT, FROM_DATE, TO_DATE, SITE_PER, AMT_SHARE_SITE, DATE_TIME,
           Q_QA_GRADE, Q_QB_GRADE, Q_QC_GRADE, Q_QD_GRADE, Q_CA_GRADE, Q_CB_GRADE, CC_GRADE, Q_CD_GRADE,
           Q_D1_GRADE, Q_D2_GRADE, Q_DE_GRADE, Q_DF_GRADE, Q_DG_GRADE, Q_DH_GRADE, Q_DI_GRADE, Q_DJ_GRADE,
           Q_SUBTOT_D3, Q_SUBTOT_D, Q_MM_SCORE, GV_PER )
    select a.SITE, a.VENDOR, a.QUARTER, a.GV_VENDOR, a.BUKRS, sum(b.AMOUNT) as Q_AMOUNT,
           a.FROM_DATE, a.TO_DATE, '', '',
           to_char(SYSDATE, 'yyyymmddhh24miss') as DATE_TIME,
           round(sum(b.AMOUNT * b.QA_GRADE) / sum(b.AMOUNT),5) as Q_QA_GRADE,
           round(sum(b.AMOUNT * b.QB_GRADE) / sum(b.AMOUNT),5) as Q_QB_GRADE,
           round(sum(b.AMOUNT * b.QC_GRADE) / sum(b.AMOUNT),5) as Q_QC_GRADE,
           round(sum(b.AMOUNT * b.QD_GRADE) / sum(b.AMOUNT),5) as Q_QD_GRADE,
           round(sum(b.AMOUNT * b.CA_GRADE) / sum(b.AMOUNT),5) as Q_CA_GRADE,
           round(sum(b.AMOUNT * b.CB_GRADE) / sum(b.AMOUNT),5) as Q_CB_GRADE,
           round(sum(b.AMOUNT * b.CC_GRADE) / sum(b.AMOUNT),5) as CC_GRADE,
           round(sum(b.AMOUNT * b.CD_GRADE) / sum(b.AMOUNT),5) as Q_CD_GRADE,
           round(sum(b.AMOUNT * b.D1_GRADE) / sum(b.AMOUNT),5) as Q_D1_GRADE,
           round(sum(b.AMOUNT * b.D2_GRADE) / sum(b.AMOUNT),5) as Q_D2_GRADE,
           round(sum(b.AMOUNT * b.DE_GRADE) / sum(b.AMOUNT),5) as Q_DE_GRADE,
           round(sum(b.AMOUNT * b.DF_GRADE) / sum(b.AMOUNT),5) as Q_DF_GRADE,
           round(sum(b.AMOUNT * b.DG_GRADE) / sum(b.AMOUNT),5) as Q_DG_GRADE,
           round(sum(b.AMOUNT * b.DH_GRADE) / sum(b.AMOUNT),5) as Q_DH_GRADE,
           round(sum(b.AMOUNT * b.DI_GRADE) / sum(b.AMOUNT),5) as Q_DI_GRADE,
           round(sum(b.AMOUNT * b.DJ_GRADE) / sum(b.AMOUNT),5) as Q_DJ_GRADE,
           round(sum(b.AMOUNT * b.SUBTOT_D3) / sum(b.AMOUNT),5) as Q_SUBTOT_D3,
           round(sum(b.AMOUNT * b.SUBTOT_D) / sum(b.AMOUNT),5) as Q_SUBTOT_D,
           round(sum(b.AMOUNT * b.MM_SCORE) / sum(b.AMOUNT),5) as Q_MM_SCORE,
           a.GV_PER
      from VRTN_SUM05_AMT_VM_Q a, VRTN_SUM12_MM_VM b
     where a.SITE = b.SITE           and a.VENDOR = b.VENDOR
       and a.QUARTER = b.QUARTER
       and a.GV_VENDOR = b.GV_VENDOR and a.BUKRS = b.BUKRS
       and a.QUARTER = vYYYYQQ
     group by a.SITE, a.VENDOR, a.QUARTER, a.GV_VENDOR, a.BUKRS, a.FROM_DATE, a.TO_DATE, a.SITE_PER, a.GV_PER;
  commit;

  iTracePoint := '220';
  for REC1 in (
     select * from VRTN_SUM12_MM_VM where YYYY = vYYYY and MM = vMM1
  ) loop
     Update VRTN_SUM15_QQ_VM
        set QA_10_GRADE = REC1.QA_GRADE,
            QB_10_GRADE = REC1.QB_GRADE,
            QC_10_GRADE = REC1.QC_GRADE,
            QD_10_GRADE = REC1.QD_GRADE,
            SUBTOT_10_Q = REC1.SUBTOT_Q,
            CA_10_GRADE = REC1.CA_GRADE,
            CB_10_GRADE = REC1.CB_GRADE,
            CC_10_GRADE = REC1.CC_GRADE,
            CD_10_GRADE = REC1.CD_GRADE,
            SUBTOT_10_C = REC1.SUBTOT_C,
            D1_10_GRADE = REC1.D1_GRADE,
            D2_10_GRADE = REC1.D2_GRADE,
            DE_10_GRADE = REC1.DE_GRADE,
            DF_10_GRADE = REC1.DF_GRADE,
            DG_10_GRADE = REC1.DG_GRADE,
            DH_10_GRADE = REC1.DH_GRADE,
            DI_10_GRADE = REC1.DI_GRADE,
            DJ_10_GRADE = REC1.DJ_GRADE,
            TOT_10_CQD = REC1.TOT_CQD,
            SUBTOT_10_D3 = REC1.SUBTOT_D3,
            TOT_10_D = REC1.TOT_D1_D2_D3,
            SUBTOT_10_D = REC1.SUBTOT_D,
            TOT_10_QCD = REC1.MM_SCORE,
            Q_10_SCORE = REC1.MM_SCORE
      where SITE = REC1.SITE
        and VENDOR = REC1.VENDOR
        and QUARTER = REC1.QUARTER;
     commit;
  end loop;

  iTracePoint := '230';
  for REC1 in (
     select * from VRTN_SUM12_MM_VM where YYYY = vYYYY and MM = vMM2
  ) loop
     Update VRTN_SUM15_QQ_VM
        set QA_11_GRADE = REC1.QA_GRADE,
            QB_11_GRADE = REC1.QB_GRADE,
            QC_11_GRADE = REC1.QC_GRADE,
            QD_11_GRADE = REC1.QD_GRADE,
            SUBTOT_11_Q = REC1.SUBTOT_Q,
            CA_11_GRADE = REC1.CA_GRADE,
            CB_11_GRADE = REC1.CB_GRADE,
            CC_11_GRADE = REC1.CC_GRADE,
            CD_11_GRADE = REC1.CD_GRADE,
            SUBTOT_11_C = REC1.SUBTOT_C,
            D1_11_GRADE = REC1.D1_GRADE,
            D2_11_GRADE = REC1.D2_GRADE,
            DE_11_GRADE = REC1.DE_GRADE,
            DF_11_GRADE = REC1.DF_GRADE,
            DG_11_GRADE = REC1.DG_GRADE,
            DH_11_GRADE = REC1.DH_GRADE,
            DI_11_GRADE = REC1.DI_GRADE,
            DJ_11_GRADE = REC1.DJ_GRADE,
            TOT_11_CQD = REC1.TOT_CQD,
            SUBTOT_11_D3 = REC1.SUBTOT_D3,
            TOT_11_D = REC1.TOT_D1_D2_D3,
            SUBTOT_11_D = REC1.SUBTOT_D,
            TOT_11_QCD = REC1.MM_SCORE,
            Q_11_SCORE = REC1.MM_SCORE
      where SITE = REC1.SITE
        and VENDOR = REC1.VENDOR
        and QUARTER = REC1.QUARTER;
     commit;
  end loop;

  iTracePoint := '240';
  for REC1 in (
     select * from VRTN_SUM12_MM_VM where YYYY = vYYYY and MM = vMM3
  ) loop
     Update VRTN_SUM15_QQ_VM
        set QA_12_GRADE = REC1.QA_GRADE,
            QB_12_GRADE = REC1.QB_GRADE,
            QC_12_GRADE = REC1.QC_GRADE,
            QD_12_GRADE = REC1.QD_GRADE,
            SUBTOT_12_Q = REC1.SUBTOT_Q,
            CA_12_GRADE = REC1.CA_GRADE,
            CB_12_GRADE = REC1.CB_GRADE,
            CC_12_GRADE = REC1.CC_GRADE,
            CD_12_GRADE = REC1.CD_GRADE,
            SUBTOT_12_C = REC1.SUBTOT_C,
            D1_12_GRADE = REC1.D1_GRADE,
            D2_12_GRADE = REC1.D2_GRADE,
            DE_12_GRADE = REC1.DE_GRADE,
            DF_12_GRADE = REC1.DF_GRADE,
            DG_12_GRADE = REC1.DG_GRADE,
            DH_12_GRADE = REC1.DH_GRADE,
            DI_12_GRADE = REC1.DI_GRADE,
            DJ_12_GRADE = REC1.DJ_GRADE,
            TOT_12_CQD = REC1.TOT_CQD,
            SUBTOT_12_D3 = REC1.SUBTOT_D3,
            TOT_12_D = REC1.TOT_D1_D2_D3,
            SUBTOT_12_D = REC1.SUBTOT_D,
            TOT_12_QCD = REC1.MM_SCORE,
            Q_12_SCORE = REC1.MM_SCORE
      where SITE = REC1.SITE
        and VENDOR = REC1.VENDOR
        and QUARTER = REC1.QUARTER;
     commit;
  end loop;

  iTracePoint := '251';
  Update VRTN_SUM15_QQ_VM
     set SUBTOT_Q = round( (nvl(Q_QA_GRADE,0) * QA_VALUE) + (nvl(Q_QB_GRADE,0) * QB_VALUE) + (nvl(Q_QC_GRADE,0) * QC_VALUE) + (nvl(Q_QD_GRADE,0) * QD_VALUE), 5)
   where QUARTER = vYYYYQQ
     and ( Q_QA_GRADE is not null or Q_QB_GRADE is not null or Q_QC_GRADE is not null or Q_QD_GRADE is not null );
  commit;

  iTracePoint := '252';
  Update VRTN_SUM15_QQ_VM
     set SUBTOT_C = round( (nvl(Q_CA_GRADE,0) * CA_VALUE) + (nvl(Q_CB_GRADE,0) * CB_VALUE) + (nvl(CC_GRADE,0) * CC_VALUE) + (nvl(Q_CD_GRADE,0) * CD_VALUE), 5)
   where QUARTER = vYYYYQQ
     and ( Q_CA_GRADE is not null or Q_CB_GRADE is not null or CC_GRADE is not null or Q_CD_GRADE is not null );
  commit;

  iTracePoint := '253';
  Update VRTN_SUM15_QQ_VM
     set SUBTOT_D3 = round( (nvl(Q_DE_GRADE,0) * DE_VALUE) + (nvl(Q_DF_GRADE,0) * DF_VALUE) + (nvl(Q_DG_GRADE,0) * DG_VALUE) + (nvl(Q_DH_GRADE,0) * DH_VALUE) + (nvl(Q_DI_GRADE,0) * DI_VALUE) + (nvl(Q_DJ_GRADE,0) * DJ_VALUE), 5)
   where QUARTER = vYYYYQQ
     and ( Q_DE_GRADE is not null or Q_DF_GRADE is not null or Q_DG_GRADE is not null or Q_DH_GRADE is not null or Q_DI_GRADE is not null or Q_DJ_GRADE is not null );
  commit;

  /*
  iTracePoint := '254';
  Update VRTN_SUM15_QQ_VM
     set Q_SUBTOT_D3 = round(SUBTOT_D3 * ( 1 / ( decode(Q_DE_GRADE,null,0,DE_VALUE) + decode(Q_DF_GRADE,null,0,DF_VALUE) + decode(Q_DG_GRADE,null,0,DG_VALUE) +
                                             decode(Q_DH_GRADE,null,0,DH_VALUE) + decode(Q_DI_GRADE,null,0,DI_VALUE) + decode(Q_DJ_GRADE,null,0,DJ_VALUE) ) ), 5)
   where QUARTER = vYYYYQQ
     and SUBTOT_D3 is not null;
  commit;
  */

  iTracePoint := '255';
  Update VRTN_SUM15_QQ_VM
     set SUBTOT_D = round( (nvl(Q_D1_GRADE,0) * D1_VALUE) + (nvl(Q_D2_GRADE,0) * D2_VALUE) + (nvl(Q_SUBTOT_D3,0) * D3_VALUE), 5)
   where QUARTER = vYYYYQQ
     and ( Q_D1_GRADE is not null or Q_D2_GRADE is not null or Q_SUBTOT_D3 is not null );
  commit;

  /*
  iTracePoint := '256';
  Update VRTN_SUM15_QQ_VM
     set Q_SUBTOT_D = round( SUBTOT_D * ( 1 / ( decode(Q_D1_GRADE,null,0,D1_VALUE) + decode(Q_D2_GRADE,null,0,D2_VALUE) + decode(Q_SUBTOT_D3,null,0,D3_VALUE) ) ), 5)
   where QUARTER = vYYYYQQ
     and SUBTOT_D is not null;
  commit;
  */

  iTracePoint := '257';
  Update VRTN_SUM15_QQ_VM
     set MM_SCORE = round( ( nvl(SUBTOT_Q,0) * Q0_VALUE ) + ( nvl(SUBTOT_C,0) * C0_VALUE ) + ( nvl(Q_SUBTOT_D,0) * D0_VALUE ), 5)
   where QUARTER = vYYYYQQ
     and ( SUBTOT_Q is not null or SUBTOT_C is not null or Q_SUBTOT_D is not null );
  commit;

  iTracePoint := '260';
  vQ_RANKING := 0;
  vSITE := '0000';
  vMATGROUP := '000';
  for REC1 in (
     select a.SITE, a.VENDOR, a.QUARTER, ( select b.GRADE from VRTN_SUM23_MAPPING_GRADE b where b.RANGE_TYPE = 'SC' and b.RANGE_FROM <= a.MM_SCORE and b.RANGE_TO >= a.MM_SCORE ) as Q_GRADE
       from VRTN_SUM15_QQ_VM a
      where a.QUARTER = vYYYYQQ
      order by a.SITE asc, a.MM_SCORE desc, a.SUBTOT_Q desc, a.SUBTOT_C desc, a.Q_SUBTOT_D desc, a.Q_AMOUNT desc
  ) loop
     if vSITE <> REC1.SITE then
       vQ_RANKING := 0;
       vSITE := REC1.SITE;
     end if;
     vQ_RANKING := vQ_RANKING + 1;
     Update VRTN_SUM15_QQ_VM
        set Q_GRADE = REC1.Q_GRADE,
            Q_RANKING = vQ_RANKING
      where SITE = REC1.SITE
        and VENDOR = REC1.VENDOR
        and QUARTER = REC1.QUARTER;
     commit;
  end loop;

-- Susan mark
--  iTracePoint := '270';
--  for REC1 in (
--     select a.SITE, a.QUARTER, sum(Q_AMOUNT) as SITE_Q_AMOUNT
--       from VRTN_SUM15_QQ_VM a
--      where a.QUARTER = vYYYYQQ
--      group by a.SITE, a.QUARTER
--  ) loop
--     Update VRTN_SUM15_QQ_VM
--        set AMT_SHARE_SITE = round(Q_AMOUNT / REC1.SITE_Q_AMOUNT, 5)
--      where SITE = REC1.SITE
--        and QUARTER = REC1.QUARTER;
--     commit;
--  end loop;

--Susan adjust 2007/09/27
  iTracePoint := '270';
  for REC1 in (
     select a.SITE, a.QUARTER, sum(Q_AMOUNT) as SITE_Q_AMOUNT
       from VRTN_SUM15_QQ_VM a
      where a.QUARTER = vYYYYQQ
      group by a.SITE, a.QUARTER
  ) loop
     Update VRTN_SUM15_QQ_VM
        set AMT_SHARE_SITE = round(Q_AMOUNT / REC1.SITE_Q_AMOUNT, 5) * 100
      where SITE = REC1.SITE
        and QUARTER = REC1.QUARTER;
     commit;
  end loop;


  iTracePoint := '300';  --刪除 VRTN_SUM16_QQ_COMBINE
  delete from VRTN_SUM16_QQ_COMBINE
   where QUARTER = vYYYYQQ;
  commit;

  iTracePoint := '310';
  insert into VRTN_SUM16_QQ_COMBINE ( SITE, VENDOR, MATGROUP, QUARTER, GV_VENDOR, BUKRS, Q_GRADE, Q_RANKING, Q_AMOUNT,
               FROM_DATE, TO_DATE, DATE_TIME, SITE_PER, AMT_SHARE_SITE, QA_10_GRADE, QA_11_GRADE, QA_12_GRADE, Q_QA_GRADE,
               QB_10_GRADE, QB_11_GRADE, QB_12_GRADE, Q_QB_GRADE, QC_10_GRADE, QC_11_GRADE, QC_12_GRADE, Q_QC_GRADE,
               QD_10_GRADE, QD_11_GRADE, QD_12_GRADE, Q_QD_GRADE, SUBTOT_10_Q, SUBTOT_11_Q, SUBTOT_12_Q, SUBTOT_Q,
               CA_10_GRADE, CA_11_GRADE, CA_12_GRADE, Q_CA_GRADE, CB_10_GRADE, CB_11_GRADE, CB_12_GRADE, Q_CB_GRADE,
               CC_10_GRADE, CC_11_GRADE, CC_12_GRADE, CC_GRADE, CD_10_GRADE, CD_11_GRADE, CD_12_GRADE, Q_CD_GRADE,
               SUBTOT_10_C, SUBTOT_11_C, SUBTOT_12_C, SUBTOT_C, D1_10_GRADE, D1_11_GRADE, D1_12_GRADE, Q_D1_GRADE,
               D2_10_GRADE, D2_11_GRADE, D2_12_GRADE, Q_D2_GRADE, DE_10_GRADE, DE_11_GRADE, DE_12_GRADE, Q_DE_GRADE,
               DF_10_GRADE, DF_11_GRADE, DF_12_GRADE, Q_DF_GRADE, DG_10_GRADE, DG_11_GRADE, DG_12_GRADE, Q_DG_GRADE,
               DH_10_GRADE, DH_11_GRADE, DH_12_GRADE, Q_DH_GRADE, DI_10_GRADE, DI_11_GRADE, DI_12_GRADE, Q_DI_GRADE,
               DJ_10_GRADE, DJ_11_GRADE, DJ_12_GRADE, Q_DJ_GRADE, TOT_10_CQD, TOT_11_CQD, TOT_12_CQD, SUBTOT_10_D3,
               SUBTOT_11_D3, SUBTOT_12_D3, SUBTOT_D3, Q_SUBTOT_D3, TOT_10_D, TOT_11_D, TOT_12_D, SUBTOT_10_D, SUBTOT_11_D,
               SUBTOT_12_D, SUBTOT_D, Q_SUBTOT_D, TOT_10_QCD, TOT_11_QCD, TOT_12_QCD, Q_10_SCORE, Q_11_SCORE, Q_12_SCORE,
               MM_SCORE, Q_MM_SCORE, GV_PER )
    select SITE, VENDOR, MATGROUP, QUARTER, GV_VENDOR, BUKRS, Q_GRADE, Q_RANKING, Q_AMOUNT,
           FROM_DATE, TO_DATE, DATE_TIME, SITE_PER, AMT_SHARE_SITE, QA_10_GRADE, QA_11_GRADE, QA_12_GRADE, Q_QA_GRADE,
           QB_10_GRADE, QB_11_GRADE, QB_12_GRADE, Q_QB_GRADE, QC_10_GRADE, QC_11_GRADE, QC_12_GRADE, Q_QC_GRADE,
           QD_10_GRADE, QD_11_GRADE, QD_12_GRADE, Q_QD_GRADE, SUBTOT_10_Q, SUBTOT_11_Q, SUBTOT_12_Q, SUBTOT_Q,
           CA_10_GRADE, CA_11_GRADE, CA_12_GRADE, Q_CA_GRADE, CB_10_GRADE, CB_11_GRADE, CB_12_GRADE, Q_CB_GRADE,
           CC_10_GRADE, CC_11_GRADE, CC_12_GRADE, CC_GRADE, CD_10_GRADE, CD_11_GRADE, CD_12_GRADE, Q_CD_GRADE,
           SUBTOT_10_C, SUBTOT_11_C, SUBTOT_12_C, SUBTOT_C, D1_10_GRADE, D1_11_GRADE, D1_12_GRADE, Q_D1_GRADE,
           D2_10_GRADE, D2_11_GRADE, D2_12_GRADE, Q_D2_GRADE, DE_10_GRADE, DE_11_GRADE, DE_12_GRADE, Q_DE_GRADE,
           DF_10_GRADE, DF_11_GRADE, DF_12_GRADE, Q_DF_GRADE, DG_10_GRADE, DG_11_GRADE, DG_12_GRADE, Q_DG_GRADE,
           DH_10_GRADE, DH_11_GRADE, DH_12_GRADE, Q_DH_GRADE, DI_10_GRADE, DI_11_GRADE, DI_12_GRADE, Q_DI_GRADE,
           DJ_10_GRADE, DJ_11_GRADE, DJ_12_GRADE, Q_DJ_GRADE, TOT_10_CQD, TOT_11_CQD, TOT_12_CQD, SUBTOT_10_D3,
           SUBTOT_11_D3, SUBTOT_12_D3, SUBTOT_D3, Q_SUBTOT_D3, TOT_10_D, TOT_11_D, TOT_12_D, SUBTOT_10_D, SUBTOT_11_D,
           SUBTOT_12_D, SUBTOT_D, Q_SUBTOT_D, TOT_10_QCD, TOT_11_QCD, TOT_12_QCD, Q_10_SCORE, Q_11_SCORE, Q_12_SCORE,
           MM_SCORE, Q_MM_SCORE, GV_PER
      from VRTN_SUM14_QQ_MATGP where QUARTER = vYYYYQQ
    union all
    select SITE, VENDOR, '000' as MATGROUP, QUARTER, GV_VENDOR, BUKRS, Q_GRADE, Q_RANKING, Q_AMOUNT,
           FROM_DATE, TO_DATE, DATE_TIME, SITE_PER, AMT_SHARE_SITE, QA_10_GRADE, QA_11_GRADE, QA_12_GRADE, Q_QA_GRADE,
           QB_10_GRADE, QB_11_GRADE, QB_12_GRADE, Q_QB_GRADE, QC_10_GRADE, QC_11_GRADE, QC_12_GRADE, Q_QC_GRADE,
           QD_10_GRADE, QD_11_GRADE, QD_12_GRADE, Q_QD_GRADE, SUBTOT_10_Q, SUBTOT_11_Q, SUBTOT_12_Q, SUBTOT_Q,
           CA_10_GRADE, CA_11_GRADE, CA_12_GRADE, Q_CA_GRADE, CB_10_GRADE, CB_11_GRADE, CB_12_GRADE, Q_CB_GRADE,
           CC_10_GRADE, CC_11_GRADE, CC_12_GRADE, CC_GRADE, CD_10_GRADE, CD_11_GRADE, CD_12_GRADE, Q_CD_GRADE,
           SUBTOT_10_C, SUBTOT_11_C, SUBTOT_12_C, SUBTOT_C, D1_10_GRADE, D1_11_GRADE, D1_12_GRADE, Q_D1_GRADE,
           D2_10_GRADE, D2_11_GRADE, D2_12_GRADE, Q_D2_GRADE, DE_10_GRADE, DE_11_GRADE, DE_12_GRADE, Q_DE_GRADE,
           DF_10_GRADE, DF_11_GRADE, DF_12_GRADE, Q_DF_GRADE, DG_10_GRADE, DG_11_GRADE, DG_12_GRADE, Q_DG_GRADE,
           DH_10_GRADE, DH_11_GRADE, DH_12_GRADE, Q_DH_GRADE, DI_10_GRADE, DI_11_GRADE, DI_12_GRADE, Q_DI_GRADE,
           DJ_10_GRADE, DJ_11_GRADE, DJ_12_GRADE, Q_DJ_GRADE, TOT_10_CQD, TOT_11_CQD, TOT_12_CQD, SUBTOT_10_D3,
           SUBTOT_11_D3, SUBTOT_12_D3, SUBTOT_D3, Q_SUBTOT_D3, TOT_10_D, TOT_11_D, TOT_12_D, SUBTOT_10_D, SUBTOT_11_D,
           SUBTOT_12_D, SUBTOT_D, Q_SUBTOT_D, TOT_10_QCD, TOT_11_QCD, TOT_12_QCD, Q_10_SCORE, Q_11_SCORE, Q_12_SCORE,
           MM_SCORE, Q_MM_SCORE, GV_PER
      from VRTN_SUM15_QQ_VM where QUARTER = vYYYYQQ;
  commit;

EXCEPTION
  When OTHERS Then
    --有錯誤產生則寄mail
    cErrorText := SQLERRM();
    MAIL_FILE_BIDBDBADMIN(in_to_name => 'shuchin_lin@usiglobal.com', subject => '[VRTN] PL/SQL VRTN_PLSQL_SUM6_LOC_QQ ERROR', message => '[VRTN_PLSQL_SUM6_LOC_QQ], The tracepoint is  ' || iTracePoint || ' and ErrorText= ' || cErrorText) ;
END;
/

