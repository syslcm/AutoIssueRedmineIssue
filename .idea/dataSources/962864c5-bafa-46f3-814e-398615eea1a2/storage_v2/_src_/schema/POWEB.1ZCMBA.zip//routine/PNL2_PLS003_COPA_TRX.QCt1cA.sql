create PROCEDURE       PNL2_PLS003_COPA_TRX (
  --inCompany  in VARCHAR2,
  t_Period in VARCHAR2
  --2008/11/4 ADD KPI_UPL001_REVENUE_TRX 
)
AUTHID DEFINER
is
  CURSOR C_PNL2_PLS003_R is
      SELECT COMPANY_CODE,PERIOD,PROFIT_CENTER,END_CUSTOMER_ID,
             SUM(NET_REVENUE) AMT_LOCAL,SUM(NET_REVENUE_USD) AMT_USD,SUM(NET_REVENUE_TWD) AMT_TWD,
             SUM(COGS_MB) COGS_DM_LOCAL,SUM(COGS_MB_USD) COGS_DM_USD,SUM(COGS_MB_TWD) COGS_DM_TWD,
             SUM(COGS_LB) COGS_DL_LOCAL,SUM(COGS_LB_USD) COGS_DL_USD,SUM(COGS_LB_TWD) COGS_DL_TWD,
             SUM(COGS_OB) COGS_OH_LOCAL,SUM(COGS_OB_USD) COGS_OH_USD,SUM(COGS_OB_TWD) COGS_OH_TWD
        FROM KPI_SAP001_COPA_TRX
       WHERE  PERIOD = t_Period 
         AND    ( NET_REVENUE <> 0 OR NET_COGS <>  0)
         AND    RELATED_PARTY <> 'Y'
         AND    END_CUSTOMER_ID IS NOT NULL --後面還要有一段程式去補足 沒有end customer又不在下列10個COST ELEMENT出現(9月份竟然沒有問題,8月和7月有問題,是因為end_customer重新update的結果嗎?,end_custer只有做9月份update
         --2008/10/8 V.3.0  Exclude '0000510102','0000510101','0000510103','0000510104','0000510107',,'0000510901','0000510902','0000510903','0000510909','0000510999'
         --AND    ( COST_ELEMENT NOT IN ('0000510109','0000510110','0000510201',
         --                            '0000510301','0000510401','0000510501','0000510102','0000510101','0000510103','0000510104','0000510107','0000510901','0000510902','0000510903','0000510909','0000510999') OR COST_ELEMENT IS NULL)
         AND (COST_ELEMENT NOT IN ('0000510109','0000510110','0000510201','0000510301','0000510401','0000510501') OR COST_ELEMENT IS NULL )
    GROUP BY COMPANY_CODE,PERIOD,PROFIT_CENTER,END_CUSTOMER_ID
      HAVING ( SUM(NET_REVENUE) <> 0 OR SUM(NET_COGS)  <> 0 );

  CURSOR C_PNL2_PLS003_R1 is
      SELECT COMPANY_CODE,PERIOD,PROFIT_CENTER,END_CUSTOMER_ID,
             SUM(NET_REVENUE) AMT_LOCAL,SUM(NET_REVENUE_USD) AMT_USD,SUM(NET_REVENUE_TWD) AMT_TWD,
             SUM(COGS_MB) COGS_DM_LOCAL,SUM(COGS_MB_USD) COGS_DM_USD,SUM(COGS_MB_TWD) COGS_DM_TWD,
             SUM(COGS_LB) COGS_DL_LOCAL,SUM(COGS_LB_USD) COGS_DL_USD,SUM(COGS_LB_TWD) COGS_DL_TWD,
             SUM(COGS_OB) COGS_OH_LOCAL,SUM(COGS_OB_USD) COGS_OH_USD,SUM(COGS_OB_TWD) COGS_OH_TWD
        FROM KPI_SAP001_COPA_TRX
       WHERE  PERIOD = t_Period 
         AND    ( NET_REVENUE <> 0 OR NET_COGS <>  0)
         AND    RELATED_PARTY <> 'Y'
         AND    END_CUSTOMER_ID IS NULL 
         AND (COST_ELEMENT NOT IN ('0000510109','0000510110','0000510201','0000510301','0000510401','0000510501','0000510101','0000510102','0000510103','0000510104','0000510107','0000510901','0000510902','0000510903','0000510909','0000510999') OR COST_ELEMENT IS NULL )
    GROUP BY COMPANY_CODE,PERIOD,PROFIT_CENTER,END_CUSTOMER_ID
      HAVING ( SUM(NET_REVENUE) <> 0 OR SUM(NET_COGS)  <> 0 );
  
  CURSOR C_PNL2_PLS003_R2 is
      SELECT COMPANY_CODE,PERIOD,PROFIT_CENTER,'OTHERS' END_CUSTOMER_ID,
            SUM(NET_REVENUE) AMT_LOCAL,SUM(NET_REVENUE_USD) AMT_USD,SUM(NET_REVENUE_TWD) AMT_TWD
        FROM KPI_UPL001_REVENUE_TRX
       WHERE PERIOD = t_Period
         AND     NET_REVENUE <> 0
         --AND    ( NET_REVENUE <> 0 OR NET_COGS <>  0)
         AND    RELATED_PARTY <> 'Y'
    GROUP BY COMPANY_CODE,PERIOD,PROFIT_CENTER
      --HAVING ( SUM(NET_REVENUE) <> 0 OR SUM(NET_COGS)  <> 0 );
      HAVING  SUM(NET_REVENUE) <> 0 ;
 BEGIN
   DELETE FROM PNL2_TRX001_SUMMARY_DATA
   WHERE Period = t_Period ;
   Commit;
    FOR REC1 in C_PNL2_PLS003_R Loop
         
         Insert into PNL2_TRX001_SUMMARY_DATA (
                COMPANY_CODE    , PERIOD         , PROFIT_CENTER      , END_CUSTOMER_ID ,
                AMT_LOCAL      , AMT_USD            , AMT_TWD         , SOURCE          ,
                R_KIND          , AREA1          ,AREA2               , AREA3            ,
                CREATE_DATE
                      ) VALUES (
                        REC1.COMPANY_CODE       , REC1.PERIOD       , REC1.PROFIT_CENTER      , REC1.END_CUSTOMER_ID ,
                        REC1.AMT_LOCAL    , REC1.AMT_USD            , REC1.AMT_TWD            , 'COPA'               ,
                        'PL01'                  , '1'                 ,'1'                       , '0'                    ,
                        SYSDATE );
          Commit;
          IF REC1.COGS_DM_LOCAL <> 0 THEN
            Insert into PNL2_TRX001_SUMMARY_DATA (
                   COMPANY_CODE    , PERIOD         , PROFIT_CENTER      , END_CUSTOMER_ID ,
                   AMT_LOCAL      , AMT_USD            , AMT_TWD         , SOURCE          ,
                   R_KIND          , AREA1          ,AREA2               , AREA3            ,
                   CREATE_DATE
                   ) VALUES (
                        REC1.COMPANY_CODE       , REC1.PERIOD       , REC1.PROFIT_CENTER      , REC1.END_CUSTOMER_ID ,
                        REC1.COGS_DM_LOCAL, REC1.COGS_DM_USD        , REC1.COGS_DM_TWD        , 'COPA'               ,
                        'PL01'                  , '2'                 , '2'                       , '0'                    ,
                        SYSDATE 
                   );
             Commit;
          END IF;
          
          IF REC1.COGS_DL_LOCAL <> 0 THEN
            Insert into PNL2_TRX001_SUMMARY_DATA (
                   COMPANY_CODE    , PERIOD         , PROFIT_CENTER      , END_CUSTOMER_ID ,
                   AMT_LOCAL      , AMT_USD            , AMT_TWD         , SOURCE          ,
                   R_KIND          , AREA1          ,AREA2               , AREA3            ,
                   CREATE_DATE
                   ) VALUES (
                        REC1.COMPANY_CODE       , REC1.PERIOD       , REC1.PROFIT_CENTER      , REC1.END_CUSTOMER_ID ,
                        REC1.COGS_DL_LOCAL, REC1.COGS_DL_USD        , REC1.COGS_DL_TWD        , 'COPA'               ,
                        'PL01'                  , '2'                 , '3'                       , '0'                    ,
                        SYSDATE 
                   );
             Commit;
          END IF;
          
          
          IF REC1.COGS_OH_LOCAL <> 0 THEN
            Insert into PNL2_TRX001_SUMMARY_DATA (
                   COMPANY_CODE    , PERIOD         , PROFIT_CENTER      , END_CUSTOMER_ID ,
                   AMT_LOCAL      , AMT_USD            , AMT_TWD         , SOURCE          , 
                   R_KIND          , AREA1          ,AREA2               , AREA3            ,
                   CREATE_DATE
                   ) VALUES (
                        REC1.COMPANY_CODE       , REC1.PERIOD       , REC1.PROFIT_CENTER      , REC1.END_CUSTOMER_ID ,
                        REC1.COGS_OH_LOCAL, REC1.COGS_OH_USD        , REC1.COGS_OH_TWD        , 'COPA'               ,
                        'PL01'                  , '2'                 , '4'                      , '0'                    ,
                        SYSDATE 
                   );
             Commit;
          END IF;

    END LOOP;
    
    FOR REC1 in C_PNL2_PLS003_R1 Loop
         
         Insert into PNL2_TRX001_SUMMARY_DATA (
                COMPANY_CODE    , PERIOD         , PROFIT_CENTER      , END_CUSTOMER_ID ,
                AMT_LOCAL      , AMT_USD            , AMT_TWD         , SOURCE          ,
                R_KIND          , AREA1          ,AREA2               , AREA3            ,
                CREATE_DATE
                      ) VALUES (
                        REC1.COMPANY_CODE       , REC1.PERIOD       , REC1.PROFIT_CENTER      , REC1.END_CUSTOMER_ID ,
                        REC1.AMT_LOCAL    , REC1.AMT_USD            , REC1.AMT_TWD            , 'COPA_NCUS'             ,
                        'PL01'                  , '1'                 ,'1'                       , '0'                    ,
                        SYSDATE );
          Commit;
          IF REC1.COGS_DM_LOCAL <> 0 THEN
            Insert into PNL2_TRX001_SUMMARY_DATA (
                   COMPANY_CODE    , PERIOD         , PROFIT_CENTER      , END_CUSTOMER_ID ,
                   AMT_LOCAL      , AMT_USD            , AMT_TWD         , SOURCE          ,  
                   R_KIND          , AREA1          ,AREA2               , AREA3            ,
                   CREATE_DATE
                   ) VALUES (
                        REC1.COMPANY_CODE       , REC1.PERIOD       , REC1.PROFIT_CENTER      , REC1.END_CUSTOMER_ID ,
                        REC1.COGS_DM_LOCAL, REC1.COGS_DM_USD        , REC1.COGS_DM_TWD        , 'COPA_NCUS'             ,
                        'PL01'                  , '2'                 , '2'                       , '0'                    ,
                        SYSDATE 
                   );
             Commit;
          END IF;
          
          IF REC1.COGS_DL_LOCAL <> 0 THEN
            Insert into PNL2_TRX001_SUMMARY_DATA (
                   COMPANY_CODE    , PERIOD         , PROFIT_CENTER      , END_CUSTOMER_ID ,
                   AMT_LOCAL      , AMT_USD            , AMT_TWD         , SOURCE          , 
                   R_KIND          , AREA1          ,AREA2               , AREA3            ,
                   CREATE_DATE
                   ) VALUES (
                        REC1.COMPANY_CODE       , REC1.PERIOD       , REC1.PROFIT_CENTER      , REC1.END_CUSTOMER_ID ,
                        REC1.COGS_DL_LOCAL, REC1.COGS_DL_USD        , REC1.COGS_DL_TWD        , 'COPA_NCUS'             ,
                        'PL01'                  , '2'                 , '3'                       , '0'                    ,
                        SYSDATE 
                   );
             Commit;
          END IF;
          
          
          IF REC1.COGS_OH_LOCAL <> 0 THEN
            Insert into PNL2_TRX001_SUMMARY_DATA (
                   COMPANY_CODE    , PERIOD         , PROFIT_CENTER      , END_CUSTOMER_ID ,
                   AMT_LOCAL      , AMT_USD            , AMT_TWD         , SOURCE          ,
                   R_KIND          , AREA1          ,AREA2               , AREA3            ,
                   CREATE_DATE
                   ) VALUES (
                        REC1.COMPANY_CODE       , REC1.PERIOD       , REC1.PROFIT_CENTER      , REC1.END_CUSTOMER_ID ,
                        REC1.COGS_OH_LOCAL, REC1.COGS_OH_USD        , REC1.COGS_OH_TWD        , 'COPA_NCUS'             ,
                        'PL01'                  , '2'                 , '4'                      , '0'                    ,
                        SYSDATE 
                   );
             Commit;
          END IF;

    END LOOP;
    
    
    
    FOR REC1 in C_PNL2_PLS003_R2 Loop
         
         Insert into PNL2_TRX001_SUMMARY_DATA (
                COMPANY_CODE    , PERIOD         , PROFIT_CENTER      , END_CUSTOMER_ID ,
                AMT_LOCAL      , AMT_USD            , AMT_TWD         , SOURCE          ,
                R_KIND          , AREA1          ,AREA2               , AREA3            ,
                CREATE_DATE
                      ) VALUES (
                        REC1.COMPANY_CODE       , REC1.PERIOD       , REC1.PROFIT_CENTER      , REC1.END_CUSTOMER_ID ,
                        REC1.AMT_LOCAL    , REC1.AMT_USD            , REC1.AMT_TWD            , 'UPL001'               ,
                        'PL01'                  , '1'                 ,'1'                       , '0'                    ,
                        SYSDATE );
          Commit;


    END LOOP;
    
END PNL2_PLS003_COPA_TRX;
/

