create view KPI_VEW005_SUMMARY_COGS as
SELECT   company_code, period,PLANT_CODE, account_no, profit_center,
         partner_profit_center,CURRENCY_LOCAL, SUM (NVL (net_cogs, '0')) net_cogs,
         ex_rate_usd, SUM (net_cogs_usd) net_cogs_usd, ex_rate_twd,
         SUM (net_cogs_twd) net_cogs_twd,
         trnx_type, mtl_type, mtl_type_af,'N' RELATED_PARTY
    FROM kpi_sap002_pca_trx
   WHERE account_no = '0000510905'
     AND trnx_type = 'PRG'
     AND NVL (net_cogs, '0') <> 0
     --AND period = '200602'
GROUP BY company_code,
         account_no,
         period,
         profit_center,
         partner_profit_center,
         trnx_type,
         mtl_type,
         mtl_type_af,
         ex_rate_twd,
         ex_rate_usd,PLANT_CODE,CURRENCY_LOCAL
UNION ALL
--正常COGS(PCA)
/* Formatted on 2006/03/31 17:02 (Formatter Plus v4.8.0) */
SELECT   company_code, period,PLANT_CODE, account_no, profit_center,
         partner_profit_center,CURRENCY_LOCAL, SUM (NVL (net_cogs, '0')) net_cogs,
         ex_rate_usd, SUM (net_cogs_usd) net_cogs_usd, ex_rate_twd,
         SUM (net_cogs_twd) net_cogs_twd,
         trnx_type, mtl_type, mtl_type_af,'N' RELATED_PARTY
    FROM kpi_sap002_pca_trx
   WHERE account_no = '0000510905'
     AND trnx_type = 'PCA'
     AND NVL (net_cogs, '0') <> 0
     --AND period = '200602'
GROUP BY company_code,
         account_no,
         period,
         profit_center,
         partner_profit_center,
         trnx_type,
         mtl_type,
         mtl_type_af,
         ex_rate_twd,
         ex_rate_usd,PLANT_CODE,CURRENCY_LOCAL
--COGS COMMON 減項(PCA)
UNION ALL
SELECT   company_code, period,PLANT_CODE, account_no, profit_center,
         partner_profit_center,CURRENCY_LOCAL, SUM (NVL (net_cogs, '0'))*-1 net_cogs,
         ex_rate_usd, SUM (net_cogs_usd)*-1 net_cogs_usd, ex_rate_twd,
         SUM (net_cogs_twd)*-1 net_cogs_twd,
         trnx_type, mtl_type, mtl_type_af,'N' RELATED_PARTY
    FROM kpi_sap002_pca_trx
   WHERE account_no = '0000410105'
     AND trnx_type = 'PRG'
     AND NVL (net_cogs, '0') <> 0
     --AND period = '200602'
GROUP BY company_code,
         account_no,
         period,
         profit_center,
         partner_profit_center,
         trnx_type,
         mtl_type,
         mtl_type_af,
         ex_rate_twd,
         ex_rate_usd,PLANT_CODE,CURRENCY_LOCAL
UNION ALL
--COPA'COGS (COST_ELEMENT IS NOT NULL)
SELECT   company_code,period,PLANT_CODE, cost_element account_no, profit_center,'' PARTNER_PROFIT_CENTER,CURRENCY_LOCAL,SUM(NVL(NET_COGS,'0'))*-1 AS NET_COGS,
         ex_rate_usd, SUM (net_cogs_usd)*-1 net_cogs_usd, ex_rate_twd,
         SUM (net_cogs_twd)*-1 net_cogs_twd,
         'COPA' TRNX_TYPE,MTL_TYPE,MTL_TYPE_AF,RELATED_PARTY
    FROM KPI_SAP001_COPA_TRX
	WHERE NVL(NET_COGS,'0') <> 0
	  AND COST_ELEMENT IS NOT NULL
	  --AND PERIOD = '200602'
GROUP BY company_code,period, cost_element, profit_center,MTL_TYPE,MTL_TYPE_AF,RELATED_PARTY,ex_rate_usd,ex_rate_twd,PLANT_CODE,CURRENCY_LOCAL
UNION ALL
--COPA'COGS (COST_ELEMENT IS NULL)
SELECT   company_code,period,PLANT_CODE, DECODE(ACCOUNT_ASSIGNMENT,null,'NO-GL_ACCT',NVL(cost_element,'COPA-AA-'||ACCOUNT_ASSIGNMENT)) account_no, profit_center,'' PARTNER_PROFIT_CENTER,CURRENCY_LOCAL,SUM(NVL(NET_COGS,'0')) AS NET_COGS,
         ex_rate_usd, SUM (net_cogs_usd) net_cogs_usd, ex_rate_twd,
         SUM (net_cogs_twd) net_cogs_twd,
         'COPA' TRNX_TYPE,MTL_TYPE,MTL_TYPE_AF,RELATED_PARTY
    FROM KPI_SAP001_COPA_TRX
	WHERE NVL(NET_COGS,'0') <> 0
	  AND COST_ELEMENT IS NULL
	  --AND PERIOD = '200602'
GROUP BY company_code,period, cost_element, profit_center,MTL_TYPE,MTL_TYPE_AF,RELATED_PARTY,ex_rate_usd,ex_rate_twd,PLANT_CODE,CURRENCY_LOCAL,ACCOUNT_ASSIGNMENT
/

