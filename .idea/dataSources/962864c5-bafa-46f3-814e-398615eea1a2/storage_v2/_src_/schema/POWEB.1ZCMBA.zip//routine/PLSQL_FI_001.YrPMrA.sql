create PROCEDURE PLSQL_FI_001
  --f_YYYYMMDD in VARCHAR2

is
 iTracePoint  integer ;
 cErrorText varchar2(500);
 vYYYYMM varchar2(6);
 vYYYY varchar2(4);
 vMM varchar2(2);
 vPROCEE_YYYYMMDD varchar2(8);
 vYYMMWW varchar2(8);
BEGIN
  iTracePoint := '000';


  vPROCEE_YYYYMMDD  :=  to_char(sysdate-1,'YYYYMMDD');
  vPROCEE_YYYYMMDD := '20070601';
  vYYYYMM := substr(vPROCEE_YYYYMMDD,1,6);
  vMM := substr(vPROCEE_YYYYMMDD,5,2);
  vYYMMWW := vYYYYMM || '00';


  iTracePoint := '100';

  If vMM = '06' Then

    update Z_TABLE_SAM SET WIP_DATE = vYYMMWW where substr(WIP_DATE,1,6) = vYYYYMM and substr(WIP_DATE,7,2) > 20;
    Commit;
  End If;

EXCEPTION
   When OTHERS Then
    --有錯誤產生則寄mail
    cErrorText := SQLERRM();
    MAIL_FILE_BIDBDBADMIN(in_to_name => 'sam_chen@ms.usi.com.tw', subject => '[VRT] PL/SQL PLSQL_PP_MFG_VALUE ERROR', message => '[PLSQL_PP_MFG_VALUE], The tracepoint is  ' || iTracePoint || ' and ErrorText= ' || cErrorText) ;


END PLSQL_FI_001;
/

