create PROCEDURE pnl3_pls001_copa_trx (
                                                        --inCompany  in VARCHAR2,
                                                        t_period IN VARCHAR2
                                                                            --2008/11/4 ADD KPI_UPL001_REVENUE_TRX
)
AUTHID DEFINER
IS
--2008/11/7 有發現  SUM(NET_REVENUE) <> 0 OR SUM(NET_COGS)  <> 0 條件成立但dm/dl/oh卻有值的戕況,因此不加入此條件
-- 在INSERT進資料庫時再排除金額=0的資料
--範例在PROFIT_CENTER  23  SITE:1100  金額 -30973  COST_ELEEMENT 510902  這三個pn
--1568-018969-91
--1568-025307-71
--1568-026054-91
--2009/1/20 User要新增數量欄位,考慮到程式將REVENUE/COGS拆成四筆,數量不能四筆都塞會變成4倍,因此只放在REVENEU即可,原本只有AMT<>0的才會寫到資料庫,修改成REVENUE不控此<>0條件
--保證QTY都會寫到REVENUE那筆去
--增加project name,project type

   --2008/11/19  COST ELEMENT 530101溝通後用revenue分掉
   --2009/2/10 針對10號公報,200901月先將其排除掉(排除比較好)因1.SAP2月才上線 所以1月份沒有資料,2.補資料又很麻煩,排除邏輯為
   -- VV006 <> 0   OR VV007 <> 0  OR VV014 <> 0  OR VV015 <> 0  OR VV016 <> 0  OR VV017 <> 0  OR VV018 <> 0  OR VV019 <> 0  而不採用會計科目原因為
   --註********欄位VV18,VV19為負項,所以NET COGS金額是VV06+VV07+...+VV017-VV018-VV019的邏輯,且金額為sap 原幣金額,台幣和日幣要注意
   --前端程式尚未完善,如果金額小還OK,但金額如果太大再找差異時可能忘了是這個原因引起的
   --以下科目 '('0000510907','0000510910','0000510920','0000510908','0000510911','0000510912','0000510913','0000510914','0000510915','0000510916',
   --'0000510921','0000510922','0000510923','0000510924','0000510925','0000510926','0000510919','0000510918','0000510917')
   --轉換 END_CUSTOMER_ID "APPLE" TO "JORDAN"
   CURSOR c_pnl3_pls001_r
   IS
      SELECT   company_code, period, profit_center,
               customer_id AS bill_to_party, ship_to_party, mtl_group,
               part_no, plant_code, mtl_type, cost_element, search_term,
               nvl(SUM (net_revenue),0) amt_local, nvl(SUM (net_revenue_usd),0) amt_usd,
               nvl(SUM (net_revenue_twd),0) amt_twd, nvl(SUM (cogs_mb),0) cogs_dm_local,
               nvl(SUM (cogs_mb_usd),0) cogs_dm_usd, nvl(SUM (cogs_mb_twd),0) cogs_dm_twd,
               nvl(SUM (cogs_lb),0) cogs_dl_local, nvl(SUM (cogs_lb_usd),0) cogs_dl_usd,
               nvl(SUM (cogs_lb_twd),0) cogs_dl_twd, nvl(SUM (cogs_ob),0) cogs_oh_local,
               nvl(SUM (cogs_ob_usd),0) cogs_oh_usd, nvl(SUM (cogs_ob_twd),0) cogs_oh_twd,
               nvl(SUM (net_qty),0) net_qty
          FROM kpi_sap001_copa_trx
         WHERE period = t_period
           AND (net_revenue <> 0 OR net_cogs <> 0)
           AND related_party <> 'Y'
           AND part_no IS NOT NULL
--後面還要有一段程式去補足 沒有Part no又不在下列10個COST ELEMENT出現(9月份竟然沒有問題,8月和7月有問題,是因為end_customer重新update的結果嗎?,end_custer只有做9月份update
           AND (   cost_element NOT IN
                      ('0000530101', '0000510109', '0000510110', '0000510201',
                       '0000510301', '0000510401', '0000510501', '0000510101',
                       '0000510102', '0000510103', '0000510104', '0000510107',
                       '0000510901', '0000510902', '0000510903', '0000510909',
                       '0000510999', '0000410103')
                OR cost_element IS NULL
               )
           AND ( VV006 = 0 AND VV007 = 0  AND VV014 = 0 AND VV015 = 0 AND VV016 = 0 AND VV017 = 0 AND VV018 = 0 AND VV019 = 0 )
      GROUP BY company_code,
               period,
               profit_center,
               customer_id,
               ship_to_party,
               mtl_group,
               part_no,
               plant_code,
               mtl_type,
               cost_element,
               search_term;

   --HAVING ( SUM(NET_REVENUE) <> 0 OR SUM(NET_COGS)  <> 0 );
   CURSOR c_pnl3_pls001_r1
   IS
      SELECT   company_code, period, profit_center,
               customer_id AS bill_to_party, ship_to_party, mtl_group,
               part_no, plant_code, mtl_type, cost_element, search_term,
               nvl(SUM (net_revenue),0) amt_local, nvl(SUM (net_revenue_usd),0) amt_usd,
               nvl(SUM (net_revenue_twd),0) amt_twd, nvl(SUM (cogs_mb),0) cogs_dm_local,
               nvl(SUM (cogs_mb_usd),0) cogs_dm_usd, nvl(SUM (cogs_mb_twd),0) cogs_dm_twd,
               nvl(SUM (cogs_lb),0) cogs_dl_local, nvl(SUM (cogs_lb_usd),0) cogs_dl_usd,
               nvl(SUM (cogs_lb_twd),0) cogs_dl_twd, nvl(SUM (cogs_ob),0) cogs_oh_local,
               nvl(SUM (cogs_ob_usd),0) cogs_oh_usd, nvl(SUM (cogs_ob_twd),0) cogs_oh_twd,
               nvl(SUM (net_qty),0) net_qty
          FROM kpi_sap001_copa_trx
         WHERE period = t_period
           AND (net_revenue <> 0 OR net_cogs <> 0)
           AND related_party <> 'Y'
           AND part_no IS NULL
           AND (   cost_element NOT IN
                      ('0000530101', '0000510109', '0000510110', '0000510201',
                       '0000510301', '0000510401', '0000510501', '0000510101',
                       '0000510102', '0000510103', '0000510104', '0000510107',
                       '0000510901', '0000510902', '0000510903', '0000510909',
                       '0000510999', '0000410103')
                OR cost_element IS NULL
               )
                AND ( VV006 = 0 AND VV007 = 0  AND VV014 = 0 AND VV015 = 0 AND VV016 = 0 AND VV017 = 0 AND VV018 = 0 AND VV019 = 0 )
      GROUP BY company_code,
               period,
               profit_center,
               customer_id,
               ship_to_party,
               mtl_group,
               part_no,
               plant_code,
               mtl_type,
               cost_element,
               search_term;

   CURSOR c_pnl3_pls001_r3
   IS
      SELECT   company_code, period, profit_center,
               customer_id AS bill_to_party, ship_to_party, mtl_group,
               part_no, plant_code, mtl_type, cost_element, search_term,
               nvl(SUM (net_revenue),0) amt_local, nvl(SUM (net_revenue_usd),0) amt_usd,
               nvl(SUM (net_revenue_twd),0) amt_twd, nvl(SUM (cogs_mb),0) cogs_dm_local,
               nvl(SUM (cogs_mb_usd),0) cogs_dm_usd, nvl(SUM (cogs_mb_twd),0) cogs_dm_twd,
               nvl(SUM (cogs_lb),0) cogs_dl_local, nvl(SUM (cogs_lb_usd),0) cogs_dl_usd,
               nvl(SUM (cogs_lb_twd),0) cogs_dl_twd, nvl(SUM (cogs_ob),0) cogs_oh_local,
               nvl(SUM (cogs_ob_usd),0) cogs_oh_usd, nvl(SUM (cogs_ob_twd),0) cogs_oh_twd,
               nvl(SUM (net_qty),0) net_qty
          FROM kpi_sap001_copa_trx
         WHERE period = t_period
           AND (net_revenue <> 0 OR net_cogs <> 0)
           AND related_party <> 'Y'
           --AND part_no IS NULL
           AND cost_element = '0000410103'
      GROUP BY company_code,
               period,
               profit_center,
               customer_id,
               ship_to_party,
               mtl_group,
               part_no,
               plant_code,
               mtl_type,
               cost_element,
               search_term;

   --HAVING ( SUM(NET_REVENUE) <> 0 OR SUM(NET_COGS)  <> 0 );

   ---USER Upload Non-SAP Data
   CURSOR c_pnl3_pls001_r2
   IS
      SELECT   company_code, period, profit_center,
               nvl(SUM (net_revenue),0) amt_local, nvl(SUM (net_revenue_usd),0) amt_usd,
               nvl(SUM (net_revenue_twd),0) amt_twd
          FROM kpi_upl001_revenue_trx
         WHERE period = t_period AND net_revenue <> 0 AND related_party <> 'Y'
      GROUP BY company_code, period, profit_center
        HAVING SUM (net_revenue) <> 0;

--Update FG & END CUSTOMER Mapping
   a_counter   INTEGER;
   a_rate      NUMBER (20, 10);
   a_amount    pnl3_trx001_copa.amt_twd%TYPE;
BEGIN
   DELETE FROM pnl3_trx001_copa
         WHERE period = t_period;

   COMMIT;

   FOR rec1 IN c_pnl3_pls001_r
   LOOP
      --IF rec1.amt_local <> 0
      --THEN
      INSERT INTO pnl3_trx001_copa
                  (company_code, period, profit_center,
                   bill_to_party, ship_to_party, mtl_group,
                   part_no, plant_code, amt_local,
                   amt_usd, amt_twd, SOURCE, mtl_type,
                   cost_element, r_kind, area1, area2, area3,
                   search_term, create_date, net_qty
                  )
           VALUES (rec1.company_code, rec1.period, rec1.profit_center,
                   rec1.bill_to_party, rec1.ship_to_party, rec1.mtl_group,
                   rec1.part_no, rec1.plant_code, rec1.amt_local,
                   rec1.amt_usd, rec1.amt_twd, 'COPA', rec1.mtl_type,
                   rec1.cost_element, 'PL01', '1', '1', '0',
                   rec1.search_term, SYSDATE, rec1.net_qty
                  );

      COMMIT;

      --END IF;
      IF rec1.cogs_dm_local <> 0
      THEN
         INSERT INTO pnl3_trx001_copa
                     (company_code, period, profit_center,
                      bill_to_party, ship_to_party,
                      mtl_group, part_no, plant_code,
                      amt_local, amt_usd,
                      amt_twd, SOURCE, mtl_type,
                      cost_element, r_kind, area1, area2, area3,
                      search_term, create_date
                     )
              VALUES (rec1.company_code, rec1.period, rec1.profit_center,
                      rec1.bill_to_party, rec1.ship_to_party,
                      rec1.mtl_group, rec1.part_no, rec1.plant_code,
                      rec1.cogs_dm_local, rec1.cogs_dm_usd,
                      rec1.cogs_dm_twd, 'COPA', rec1.mtl_type,
                      rec1.cost_element, 'PL01', '2', '2', '0',
                      rec1.search_term, SYSDATE
                     );

         COMMIT;
      END IF;

      IF rec1.cogs_dl_local <> 0
      THEN
         INSERT INTO pnl3_trx001_copa
                     (company_code, period, profit_center,
                      bill_to_party, ship_to_party,
                      mtl_group, part_no, plant_code,
                      amt_local, amt_usd,
                      amt_twd, SOURCE, mtl_type,
                      cost_element, r_kind, area1, area2, area3,
                      search_term, create_date
                     )
              VALUES (rec1.company_code, rec1.period, rec1.profit_center,
                      rec1.bill_to_party, rec1.ship_to_party,
                      rec1.mtl_group, rec1.part_no, rec1.plant_code,
                      rec1.cogs_dl_local, rec1.cogs_dl_usd,
                      rec1.cogs_dl_twd, 'COPA', rec1.mtl_type,
                      rec1.cost_element, 'PL01', '2', '3', '0',
                      rec1.search_term, SYSDATE
                     );

         COMMIT;
      END IF;

      IF rec1.cogs_oh_local <> 0
      THEN
         INSERT INTO pnl3_trx001_copa
                     (company_code, period, profit_center,
                      bill_to_party, ship_to_party,
                      mtl_group, part_no, plant_code,
                      amt_local, amt_usd,
                      amt_twd, SOURCE, mtl_type,
                      cost_element, r_kind, area1, area2, area3,
                      search_term, create_date
                     )
              VALUES (rec1.company_code, rec1.period, rec1.profit_center,
                      rec1.bill_to_party, rec1.ship_to_party,
                      rec1.mtl_group, rec1.part_no, rec1.plant_code,
                      rec1.cogs_oh_local, rec1.cogs_oh_usd,
                      rec1.cogs_oh_twd, 'COPA', rec1.mtl_type,
                      rec1.cost_element, 'PL01', '2', '4', '0',
                      rec1.search_term, SYSDATE
                     );

         COMMIT;
      END IF;
   END LOOP;

   FOR rec1 IN c_pnl3_pls001_r1
   LOOP
      --IF rec1.amt_local <> 0
      --THEN
      INSERT INTO pnl3_trx001_copa
                  (company_code, period, profit_center,
                   bill_to_party, ship_to_party, mtl_group,
                   part_no, plant_code, amt_local,
                   amt_usd, amt_twd, SOURCE, mtl_type,
                   cost_element, r_kind, area1, area2, area3,
                   search_term, create_date, net_qty
                  )
           VALUES (rec1.company_code, rec1.period, rec1.profit_center,
                   rec1.bill_to_party, rec1.ship_to_party, rec1.mtl_group,
                   rec1.part_no, rec1.plant_code, rec1.amt_local,
                   rec1.amt_usd, rec1.amt_twd, 'COPA_NPN', rec1.mtl_type,
                   rec1.cost_element, 'PL01', '1', '1', '0',
                   rec1.search_term, SYSDATE, rec1.net_qty
                  );

      COMMIT;

      --END IF;
      IF rec1.cogs_dm_local <> 0
      THEN
         INSERT INTO pnl3_trx001_copa
                     (company_code, period, profit_center,
                      bill_to_party, ship_to_party,
                      mtl_group, part_no, plant_code,
                      amt_local, amt_usd,
                      amt_twd, SOURCE, mtl_type,
                      cost_element, r_kind, area1, area2, area3,
                      search_term, create_date
                     )
              VALUES (rec1.company_code, rec1.period, rec1.profit_center,
                      rec1.bill_to_party, rec1.ship_to_party,
                      rec1.mtl_group, rec1.part_no, rec1.plant_code,
                      rec1.cogs_dm_local, rec1.cogs_dm_usd,
                      rec1.cogs_dm_twd, 'COPA_NPN', rec1.mtl_type,
                      rec1.cost_element, 'PL01', '2', '2', '0',
                      rec1.search_term, SYSDATE
                     );

         COMMIT;
      END IF;

      IF rec1.cogs_dl_local <> 0
      THEN
         INSERT INTO pnl3_trx001_copa
                     (company_code, period, profit_center,
                      bill_to_party, ship_to_party,
                      mtl_group, part_no, plant_code,
                      amt_local, amt_usd,
                      amt_twd, SOURCE, mtl_type,
                      cost_element, r_kind, area1, area2, area3,
                      search_term, create_date
                     )
              VALUES (rec1.company_code, rec1.period, rec1.profit_center,
                      rec1.bill_to_party, rec1.ship_to_party,
                      rec1.mtl_group, rec1.part_no, rec1.plant_code,
                      rec1.cogs_dl_local, rec1.cogs_dl_usd,
                      rec1.cogs_dl_twd, 'COPA_NPN', rec1.mtl_type,
                      rec1.cost_element, 'PL01', '2', '3', '0',
                      rec1.search_term, SYSDATE
                     );

         COMMIT;
      END IF;

      IF rec1.cogs_oh_local <> 0
      THEN
         INSERT INTO pnl3_trx001_copa
                     (company_code, period, profit_center,
                      bill_to_party, ship_to_party,
                      mtl_group, part_no, plant_code,
                      amt_local, amt_usd,
                      amt_twd, SOURCE, mtl_type,
                      cost_element, r_kind, area1, area2, area3,
                      search_term, create_date
                     )
              VALUES (rec1.company_code, rec1.period, rec1.profit_center,
                      rec1.bill_to_party, rec1.ship_to_party,
                      rec1.mtl_group, rec1.part_no, rec1.plant_code,
                      rec1.cogs_oh_local, rec1.cogs_oh_usd,
                      rec1.cogs_oh_twd, 'COPA_NPN', rec1.mtl_type,
                      rec1.cost_element, 'PL01', '2', '4', '0',
                      rec1.search_term, SYSDATE
                     );

         COMMIT;
      END IF;
   END LOOP;

   UPDATE pnl3_trx001_copa
      SET end_customer_id =
             (SELECT DISTINCT TRIM (end_customer_name)
                         FROM cep_map009_partno_customer
                        WHERE fg_material_no =
                                      RPAD (pnl3_trx001_copa.part_no, 18, ' ')
                          AND last_modify_date <= SYSDATE)
    WHERE period = t_period;

   COMMIT;

   /*
    *  Profit center 20/21 且mtl group 001-059歸Lenovo
    *  其他不屬於20/21 但仍是001-059則歸  其他-材料轉售
    *  不屬於001-059的材料則用search term(但要考慮到如果是cogs-屬於特定cost element則不走這裡)
    *  空白料號-用SEarch term update
    * 2008/11/26 邏輯變動 只要是20/21的材料都叫LENOVO
    * 而其他的如果SEARCH TERM是LENOVO就叫LENOVO,分完後再來做其他-材料轉售
   */
   UPDATE pnl3_trx001_copa
      SET end_customer_id = 'LENOVO'
    WHERE period = t_period
      AND profit_center IN ('0000000020', '0000000021')
      AND mtl_group BETWEEN '001' AND '059'
      AND mtl_type = 'RAW'
      AND end_customer_id IS NULL;

   COMMIT;

   UPDATE pnl3_trx001_copa
      SET end_customer_id = 'LENOVO'
    WHERE period = t_period
      AND (   profit_center NOT IN ('0000000020', '0000000021')
           OR profit_center IS NULL
          )
      AND mtl_group BETWEEN '001' AND '059'
      AND search_term = 'LENOVO'
      AND mtl_type = 'RAW'
      AND end_customer_id IS NULL;

   COMMIT;

   UPDATE pnl3_trx001_copa
      SET end_customer_id = '其他-材料轉售'
    WHERE period = t_period
      AND (   profit_center NOT IN ('0000000020', '0000000021')
           OR profit_center IS NULL
          )
      AND mtl_group BETWEEN '001' AND '059'
      AND mtl_type = 'RAW'
      AND end_customer_id IS NULL;

   COMMIT;

    /*
   Update PNL3_TRX001_COPA
      Set END_CUSTOMER_ID = '其他-材料轉售'
     Where Period = t_Period
      AND PROFIT_CENTER IN ('0000000020','0000000021')
       AND MTL_GROUP NOT BETWEEN '001' AND '059'
       AND MTL_TYPE = 'RAW'
       AND END_CUSTOMER_ID IS NULL;
    commit;
    */
   UPDATE pnl3_trx001_copa
      SET end_customer_id = TRIM (search_term)
    WHERE period = t_period
      AND search_term IS NOT NULL
      AND end_customer_id IS NULL
      AND mtl_type = 'RAW';

   COMMIT;

   --2008/11/12 剩下的直接用SEARCH TERM UPDATE
   UPDATE pnl3_trx001_copa
      SET end_customer_id = TRIM (search_term)
    WHERE period = t_period
      AND search_term IS NOT NULL
      AND end_customer_id IS NULL
      AND (mtl_type <> 'RAW' OR mtl_type IS NULL);

   COMMIT;

   FOR rec1 IN c_pnl3_pls001_r3                                  --'0000410103
   LOOP
      a_amount := 0;

      BEGIN
         SELECT NVL (SUM (amt_twd), 0)
           INTO a_amount
           FROM pnl3_trx001_copa
          WHERE period = t_period
            AND company_code = rec1.company_code
            AND profit_center = rec1.profit_center
            AND area1 = '1'
            AND area2 = '1'
            AND area3 = '0'
            AND amt_twd <> 0;
      EXCEPTION
         WHEN OTHERS
         THEN
            a_amount := 0;
      END;

      IF a_amount = 0
      THEN
         a_amount := 0;

         BEGIN
            SELECT NVL (SUM (amt_twd), 0)
              INTO a_amount
              FROM pnl3_trx001_copa
             WHERE period = t_period
               --AND company_code = rec1.company_code
               AND profit_center = rec1.profit_center
               AND area1 = '1'
               AND area2 = '1'
               AND area3 = '0'
               AND amt_twd <> 0;
         EXCEPTION
            WHEN OTHERS
            THEN
               a_amount := 0;
         END;

         a_rate := 0;

         FOR rec2 IN (SELECT   end_customer_id, NVL (SUM (amt_twd),
                                                     0) amt_twd
                          FROM pnl3_trx001_copa
                         WHERE profit_center = rec1.profit_center
                           --AND company_code = rec1.company_code
                           AND period = t_period
                           AND area1 = '1'
                           AND area2 = '1'
                           AND area3 = '0'
                           AND amt_twd <> 0
                      GROUP BY end_customer_id)
         LOOP
            a_rate := rec2.amt_twd / a_amount;

            --IF rec1.amt_local <> 0
            --THEN
            INSERT INTO pnl3_trx001_copa
                        (company_code, period, profit_center,
                         bill_to_party, ship_to_party,
                         mtl_group, part_no, plant_code,
                         amt_local,
                         amt_usd,
                         amt_twd, SOURCE,
                         mtl_type, cost_element, r_kind, area1, area2,
                         area3, search_term, create_date,
                         end_customer_id, net_qty
                        )
                 VALUES (rec1.company_code, rec1.period, rec1.profit_center,
                         rec1.bill_to_party, rec1.ship_to_party,
                         rec1.mtl_group, rec1.part_no, rec1.plant_code,
                         ROUND (rec1.amt_local * a_rate, 5),
                         ROUND (rec1.amt_usd * a_rate, 5),
                         ROUND (rec1.amt_twd * a_rate, 5), 'COPA',
                         rec1.mtl_type, rec1.cost_element, 'PL01', '1', '1',
                         '0', rec1.search_term, SYSDATE,
                         rec2.end_customer_id, rec1.net_qty
                        );

            COMMIT;

            --END IF;
            IF rec1.cogs_dm_local <> 0
            THEN
               INSERT INTO pnl3_trx001_copa
                           (company_code, period,
                            profit_center, bill_to_party,
                            ship_to_party, mtl_group,
                            part_no, plant_code,
                            amt_local,
                            amt_usd,
                            amt_twd, SOURCE,
                            mtl_type, cost_element, r_kind, area1,
                            area2, area3, search_term, create_date,
                            end_customer_id
                           )
                    VALUES (rec1.company_code, rec1.period,
                            rec1.profit_center, rec1.bill_to_party,
                            rec1.ship_to_party, rec1.mtl_group,
                            rec1.part_no, rec1.plant_code,
                            ROUND (rec1.cogs_dm_local * a_rate, 5),
                            ROUND (rec1.cogs_dm_usd * a_rate, 5),
                            ROUND (rec1.cogs_dm_twd * a_rate, 5), 'COPA',
                            rec1.mtl_type, rec1.cost_element, 'PL01', '2',
                            '2', '0', rec1.search_term, SYSDATE,
                            rec2.end_customer_id
                           );

               COMMIT;
            END IF;

            IF rec1.cogs_dl_local <> 0
            THEN
               INSERT INTO pnl3_trx001_copa
                           (company_code, period,
                            profit_center, bill_to_party,
                            ship_to_party, mtl_group,
                            part_no, plant_code,
                            amt_local,
                            amt_usd,
                            amt_twd, SOURCE,
                            mtl_type, cost_element, r_kind, area1,
                            area2, area3, search_term, create_date,
                            end_customer_id
                           )
                    VALUES (rec1.company_code, rec1.period,
                            rec1.profit_center, rec1.bill_to_party,
                            rec1.ship_to_party, rec1.mtl_group,
                            rec1.part_no, rec1.plant_code,
                            ROUND (rec1.cogs_dl_local * a_rate, 5),
                            ROUND (rec1.cogs_dl_usd * a_rate, 5),
                            ROUND (rec1.cogs_dl_twd * a_rate, 5), 'COPA',
                            rec1.mtl_type, rec1.cost_element, 'PL01', '2',
                            '3', '0', rec1.search_term, SYSDATE,
                            rec2.end_customer_id
                           );

               COMMIT;
            END IF;

            IF rec1.cogs_oh_local <> 0
            THEN
               INSERT INTO pnl3_trx001_copa
                           (company_code, period,
                            profit_center, bill_to_party,
                            ship_to_party, mtl_group,
                            part_no, plant_code,
                            amt_local,
                            amt_usd,
                            amt_twd, SOURCE,
                            mtl_type, cost_element, r_kind, area1,
                            area2, area3, search_term, create_date,
                            end_customer_id
                           )
                    VALUES (rec1.company_code, rec1.period,
                            rec1.profit_center, rec1.bill_to_party,
                            rec1.ship_to_party, rec1.mtl_group,
                            rec1.part_no, rec1.plant_code,
                            ROUND (rec1.cogs_oh_local * a_rate, 5),
                            ROUND (rec1.cogs_oh_usd * a_rate, 5),
                            ROUND (rec1.cogs_oh_twd * a_rate, 5), 'COPA',
                            rec1.mtl_type, rec1.cost_element, 'PL01', '2',
                            '4', '0', rec1.search_term, SYSDATE,
                            rec2.end_customer_id
                           );

               COMMIT;
            END IF;
         END LOOP;
      ELSE
         a_rate := 0;

         FOR rec2 IN (SELECT   end_customer_id,
                               NVL (SUM (amt_twd), 0) amt_twd
                          FROM pnl3_trx001_copa
                         WHERE profit_center = rec1.profit_center
                           AND company_code = rec1.company_code
                           AND period = t_period
                           AND area1 = '1'
                           AND area2 = '1'
                           AND area3 = '0'
                           AND amt_twd <> 0
                      GROUP BY end_customer_id)
         LOOP
            a_rate := rec2.amt_twd / a_amount;

            -- IF rec1.amt_local <> 0
             --THEN
            INSERT INTO pnl3_trx001_copa
                        (company_code, period, profit_center,
                         bill_to_party, ship_to_party,
                         mtl_group, part_no, plant_code,
                         amt_local,
                         amt_usd,
                         amt_twd, SOURCE,
                         mtl_type, cost_element, r_kind, area1, area2,
                         area3, search_term, create_date,
                         end_customer_id, net_qty
                        )
                 VALUES (rec1.company_code, rec1.period, rec1.profit_center,
                         rec1.bill_to_party, rec1.ship_to_party,
                         rec1.mtl_group, rec1.part_no, rec1.plant_code,
                         ROUND (rec1.amt_local * a_rate, 5),
                         ROUND (rec1.amt_usd * a_rate, 5),
                         ROUND (rec1.amt_twd * a_rate, 5), 'COPA',
                         rec1.mtl_type, rec1.cost_element, 'PL01', '1', '1',
                         '0', rec1.search_term, SYSDATE,
                         rec2.end_customer_id, rec1.net_qty
                        );

            COMMIT;

            --END IF;
            IF rec1.cogs_dm_local <> 0
            THEN
               INSERT INTO pnl3_trx001_copa
                           (company_code, period,
                            profit_center, bill_to_party,
                            ship_to_party, mtl_group,
                            part_no, plant_code,
                            amt_local,
                            amt_usd,
                            amt_twd, SOURCE,
                            mtl_type, cost_element, r_kind, area1,
                            area2, area3, search_term, create_date,
                            end_customer_id
                           )
                    VALUES (rec1.company_code, rec1.period,
                            rec1.profit_center, rec1.bill_to_party,
                            rec1.ship_to_party, rec1.mtl_group,
                            rec1.part_no, rec1.plant_code,
                            ROUND (rec1.cogs_dm_local * a_rate, 5),
                            ROUND (rec1.cogs_dm_usd * a_rate, 5),
                            ROUND (rec1.cogs_dm_twd * a_rate, 5), 'COPA',
                            rec1.mtl_type, rec1.cost_element, 'PL01', '2',
                            '2', '0', rec1.search_term, SYSDATE,
                            rec2.end_customer_id
                           );

               COMMIT;
            END IF;

            IF rec1.cogs_dl_local <> 0
            THEN
               INSERT INTO pnl3_trx001_copa
                           (company_code, period,
                            profit_center, bill_to_party,
                            ship_to_party, mtl_group,
                            part_no, plant_code,
                            amt_local,
                            amt_usd,
                            amt_twd, SOURCE,
                            mtl_type, cost_element, r_kind, area1,
                            area2, area3, search_term, create_date,
                            end_customer_id
                           )
                    VALUES (rec1.company_code, rec1.period,
                            rec1.profit_center, rec1.bill_to_party,
                            rec1.ship_to_party, rec1.mtl_group,
                            rec1.part_no, rec1.plant_code,
                            ROUND (rec1.cogs_dl_local * a_rate, 5),
                            ROUND (rec1.cogs_dl_usd * a_rate, 5),
                            ROUND (rec1.cogs_dl_twd * a_rate, 5), 'COPA',
                            rec1.mtl_type, rec1.cost_element, 'PL01', '2',
                            '3', '0', rec1.search_term, SYSDATE,
                            rec2.end_customer_id
                           );

               COMMIT;
            END IF;

            IF rec1.cogs_oh_local <> 0
            THEN
               INSERT INTO pnl3_trx001_copa
                           (company_code, period,
                            profit_center, bill_to_party,
                            ship_to_party, mtl_group,
                            part_no, plant_code,
                            amt_local,
                            amt_usd,
                            amt_twd, SOURCE,
                            mtl_type, cost_element, r_kind, area1,
                            area2, area3, search_term, create_date,
                            end_customer_id
                           )
                    VALUES (rec1.company_code, rec1.period,
                            rec1.profit_center, rec1.bill_to_party,
                            rec1.ship_to_party, rec1.mtl_group,
                            rec1.part_no, rec1.plant_code,
                            ROUND (rec1.cogs_oh_local * a_rate, 5),
                            ROUND (rec1.cogs_oh_usd * a_rate, 5),
                            ROUND (rec1.cogs_oh_twd * a_rate, 5), 'COPA',
                            rec1.mtl_type, rec1.cost_element, 'PL01', '2',
                            '4', '0', rec1.search_term, SYSDATE,
                            rec2.end_customer_id
                           );

               COMMIT;
            END IF;
         END LOOP;
      END IF;
   END LOOP;

   pnl3_pls006_revenue_ratio_trx (t_period);

   --把Revenue ratio搬來這裡,因為上傳的revenue資料要使用

   /*
   Update PNL3_TRX001_COPA
     Set END_CUSTOMER_ID = 'OTHERS'
    Where Period = t_Period
      AND END_CUSTOMER_ID IS NULL;
      */
   FOR rec1 IN c_pnl3_pls001_r2
   LOOP
      --因為組織改變,所以200805月把原本的38改成381,我們還是當成uabit的
      --2008/12/26  只要1101就算UABIT的,不用分到PROFIT CENTER
      IF rec1.company_code = '1101'
      THEN
         --IF REC1.PROFIT_CENTER = '0000000034' OR REC1.PROFIT_CENTER = '0000000038' OR REC1.PROFIT_CENTER = '0000000381' THEN
         INSERT INTO pnl3_trx001_copa
                     (company_code, period, profit_center,
                      amt_local, amt_usd, amt_twd, SOURCE,
                      r_kind, area1, area2, area3, create_date,
                      end_customer_id
                     )
              VALUES (rec1.company_code, rec1.period, rec1.profit_center,
                      rec1.amt_local, rec1.amt_usd, rec1.amt_twd, 'UPL001',
                      'PL01', '1', '1', '0', SYSDATE,
                      'UABIT''S CUST'
                     );

         COMMIT;
      /*ELSE

         Insert into PNL3_TRX001_COPA (
             COMPANY_CODE    , PERIOD         , PROFIT_CENTER      ,
             AMT_LOCAL      , AMT_USD            , AMT_TWD         , SOURCE          ,
             R_KIND          , AREA1          ,AREA2               , AREA3            ,
             CREATE_DATE
                 ) VALUES (
                   REC1.COMPANY_CODE       , REC1.PERIOD       , REC1.PROFIT_CENTER      ,
                   REC1.AMT_LOCAL    , REC1.AMT_USD            , REC1.AMT_TWD            , 'UPL001'               ,
                   'PL01'                  , '1'                 ,'1'                       , '0'                    ,
                   SYSDATE   );
          Commit;
      END IF;
      */
      ELSIF SUBSTR (rec1.company_code, 1, 1) = '9'
      THEN
         INSERT INTO pnl3_trx001_copa
                     (company_code, period, profit_center,
                      amt_local, amt_usd, amt_twd, SOURCE,
                      r_kind, area1, area2, area3, create_date,
                      end_customer_id
                     )
              VALUES (rec1.company_code, rec1.period, rec1.profit_center,
                      rec1.amt_local, rec1.amt_usd, rec1.amt_twd, 'UPL001',
                      'PL01', '1', '1', '0', SYSDATE,
                      '投資公司'
                     );

         COMMIT;
      ELSIF rec1.company_code = '3100'
      THEN          --2008/1和2008/2 還有uk的Revenue,先歸OTHERS,反正以後沒有了
         INSERT INTO pnl3_trx001_copa
                     (company_code, period, profit_center,
                      amt_local, amt_usd, amt_twd, SOURCE,
                      r_kind, area1, area2, area3, create_date,
                      end_customer_id
                     )
              VALUES (rec1.company_code, rec1.period, rec1.profit_center,
                      rec1.amt_local, rec1.amt_usd, rec1.amt_twd, 'UPL001',
                      'PL01', '1', '1', '0', SYSDATE,
                      'OTHERS'
                     );

         COMMIT;
      ELSE
--2008/11 SH有上傳一般的PROFIT CENTER REVENUE,為了計算方便,一律用site+proift center的customer來分掉
         a_counter := 0;

         FOR rec2 IN (SELECT end_customer_id, rate
                        --FROM PNL3_MAP001_GLOBAL_CUST_RATE
                      FROM   pnl3_map001_site_rate
                       WHERE r_kind = 'PL01'  --隨便抓一筆來用,反正匯率都一樣
                         AND area1 = '4'
                         AND area2 = '1'
                         AND area3 = '1'
                         AND company_code = rec1.company_code
                         AND profit_center = rec1.profit_center
                         AND period = rec1.period)
         LOOP
            a_counter := 1;

            INSERT INTO pnl3_trx001_copa
                        (company_code, period, profit_center,
                         end_customer_id,
                         amt_local,
                         amt_usd,
                         amt_twd, SOURCE,
                         r_kind, area1, area2, area3, create_date
                        )
                 VALUES (rec1.company_code, rec1.period, rec1.profit_center,
                         rec2.end_customer_id,
                         ROUND (rec1.amt_local * rec2.rate, 5),
                         ROUND (rec1.amt_usd * rec2.rate, 5),
                         ROUND (rec1.amt_twd * rec2.rate, 5), 'UPL001',
                         'PL01', '1', '1', '0', SYSDATE
                        );

            COMMIT;
         END LOOP;

         IF a_counter = 0
         THEN
            a_counter := 0;

            FOR rec2 IN (SELECT end_customer_id, rate
                           --FROM PNL3_MAP001_GLOBAL_CUST_RATE
                         FROM   pnl3_map001_customer_rate
                          WHERE r_kind = 'PL01'
                            --隨便抓一筆來用,反正匯率都一樣
                            AND area1 = '4'
                            AND area2 = '1'
                            AND area3 = '1'
                            --AND COMPANY_CODE = REC1.COMPANY_CODE
                            AND profit_center = rec1.profit_center
                            AND period = rec1.period)
            LOOP
               a_counter := 1;

               INSERT INTO pnl3_trx001_copa
                           (company_code, period,
                            end_customer_id, profit_center,
                            amt_local,
                            amt_usd,
                            amt_twd, SOURCE,
                            r_kind, area1, area2, area3, create_date
                           )
                    VALUES (rec1.company_code, rec1.period,
                            rec2.end_customer_id, rec1.profit_center,
                            ROUND (rec1.amt_local * rec2.rate, 5),
                            ROUND (rec1.amt_usd * rec2.rate, 5),
                            ROUND (rec1.amt_twd * rec2.rate, 5), 'UPL001',
                            'PL01', '1', '1', '0', SYSDATE
                           );

               COMMIT;
            END LOOP;

            IF a_counter = 0
            THEN
               FOR rec2 IN (SELECT end_customer_id, rate
                              FROM pnl3_map001_global_cust_rate
                             --FROM PNL3_MAP001_CUSTOMER_RATE
                            WHERE  r_kind = 'PL01'
                               --隨便抓一筆來用,反正匯率都一樣
                               AND area1 = '4'
                               AND area2 = '1'
                               AND area3 = '1'
                               --AND COMPANY_CODE = REC1.COMPANY_CODE
                               --AND PROFIT_CENTER = REC1.PROFIT_CENTER
                               AND period = rec1.period)
               LOOP
                  a_counter := 1;

                  INSERT INTO pnl3_trx001_copa
                              (company_code, period,
                               end_customer_id, profit_center,
                               amt_local,
                               amt_usd,
                               amt_twd,
                               SOURCE, r_kind, area1, area2, area3,
                               create_date
                              )
                       VALUES (rec1.company_code, rec1.period,
                               rec2.end_customer_id, rec1.profit_center,
                               ROUND (rec1.amt_local * rec2.rate, 5),
                               ROUND (rec1.amt_usd * rec2.rate, 5),
                               ROUND (rec1.amt_twd * rec2.rate, 5),
                               'UPL001', 'PL01', '1', '1', '0',
                               SYSDATE
                              );

                  COMMIT;
               END LOOP;
            END IF;
         END IF;
      END IF;
   END LOOP;

   UPDATE pnl3_trx001_copa
      SET project_name =
             (SELECT DISTINCT TRIM (sap_project_name)
                         FROM cep_map010_partno_project
                        WHERE fg_material_no =
                                      RPAD (pnl3_trx001_copa.part_no, 18, ' '))
    WHERE period = t_period;

   commit;

   UPDATE pnl3_trx001_copa
      SET project_TYPE =
             (SELECT DISTINCT TRIM (PROJECT_TYPE)
                         FROM CEP_WEB002_PROJECT
                        WHERE PROJECT_NAME = pnl3_trx001_copa.PROJECT_NAME)
                                     -- RPAD (pnl3_trx001_copa.PROJECT_NAME, 30, ' '))
    WHERE period = t_period;

   commit;

   --Add kangi 20130321
   UPDATE pnl3_trx001_copa
      SET END_CUSTOMER_ID = 'JORDAN'
    WHERE UPPER(END_CUSTOMER_ID) = 'APPLE'
      AND period = t_period;
   commit;
   --End Add kangi 20130321
END pnl3_pls001_copa_trx;
/

