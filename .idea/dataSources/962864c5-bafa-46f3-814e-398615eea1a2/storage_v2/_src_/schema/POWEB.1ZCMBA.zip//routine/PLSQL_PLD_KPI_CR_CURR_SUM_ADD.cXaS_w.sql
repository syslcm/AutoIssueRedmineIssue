create PROCEDURE         "PLSQL_PLD_KPI_CR_CURR_SUM_ADD" (
  inCompany  in VARCHAR2,
  f_YYYYMMDD in VARCHAR2,
  t_YYYYMMDD in VARCHAR2
)
/***********************************************************************
  PROG-ID      : PLSQL_PLD_KPI_CR_CURR_SUM_ADD
  PROG-ACTION  : Get IR SUMARY Data From PLD_KPI_IR_DETAIL
                 INSERT INTO PLD_KPI_CR_CURR_IR_SUM
  Author       : KATHY
  Date         : 2007/12/28
  UPDATE Date  : 2008/03/31
-------------------------------------------------------------------------------------------
--Run PLSQL WITH table:KPI_SAP017_ZB027_DATA_T (SEQ-05)
-------------------------------------------------------------------------------------------
*/
--***********************************************************************
AUTHID DEFINER
is

  iFind_Flag   integer ;          ----1=>find , 0=>dosen't find

-- 幣別不是美金的IR資料--直接用 IR_AMT_USD.
  CURSOR C_PLD_KPI_CR_CURR_MONTH_COM1 is
     SELECT SUBSTRB(IR_DATE,1,4) AS YYYY, SUBSTRB(IR_DATE,5,2) AS MM,
            PART_NO, Round(sum(IR_AMT_TWD),5)  AS TT_AMT, 
            Round(sum(PART_QTY),5) AS TT_QTY,  0, to_char(SYSDATE,'YYYYMMDD'),
            Round(sum(IR_AMT_USD),5)  AS TT_AMT_USD
     FROM PLD_KPI_IR_DETAIL
     WHERE IR_DATE >= f_YYYYMMDD
       AND IR_DATE <= t_YYYYMMDD
       AND PART_NO is not null
       AND ACCOUNT_ASSIGNMENT IS NULL
       AND PART_CURRENCY <> 'USD'
       AND GLOBAL_VENDOR_CODE NOT IN ('H00000', 'H00001', 'H00002', 'H00479')
     GROUP BY SUBSTRB(IR_DATE,1,4), SUBSTRB(IR_DATE,5,2), PART_NO
     ORDER BY SUBSTRB(IR_DATE,1,4), SUBSTRB(IR_DATE,5,2), PART_NO;

-- 幣別是美金的IR-折讓資料(ACCOUNT_ASSIGNMENT='Y')--要用 PART_AMOUNT當 USD AMT.
  CURSOR C_PLD_KPI_CR_CURR_MONTH_COM2 is
     SELECT SUBSTRB(IR_DATE,1,4) AS YYYY, SUBSTRB(IR_DATE,5,2) AS MM,
            PART_NO, Round(sum(IR_AMT_TWD),5)*-1  AS TT_AMT, 
            Round(sum(PART_QTY),5)*-1 AS TT_QTY,  0, to_char(SYSDATE,'YYYYMMDD'),
            Round(sum(PART_AMOUNT),5)*-1  AS TT_AMT_USD
     FROM PLD_KPI_IR_DETAIL
     WHERE IR_DATE >= f_YYYYMMDD
       AND IR_DATE <= t_YYYYMMDD
       AND PART_NO is not null
       AND ACCOUNT_ASSIGNMENT = 'Y'
       AND PART_CURRENCY = 'USD'
       AND GLOBAL_VENDOR_CODE NOT IN ('H00000', 'H00001', 'H00002', 'H00479')
     GROUP BY SUBSTRB(IR_DATE,1,4), SUBSTRB(IR_DATE,5,2), PART_NO
     ORDER BY SUBSTRB(IR_DATE,1,4), SUBSTRB(IR_DATE,5,2), PART_NO;

-- 幣別不是美金的IR-折讓資料(ACCOUNT_ASSIGNMENT='Y')--直接用 IR_AMT_USD.
  CURSOR C_PLD_KPI_CR_CURR_MONTH_COM3 is
     SELECT SUBSTRB(IR_DATE,1,4) AS YYYY, SUBSTRB(IR_DATE,5,2) AS MM,
            PART_NO, Round(sum(IR_AMT_TWD),5)*-1  AS TT_AMT, 
            Round(sum(PART_QTY),5)*-1 AS TT_QTY,  0, to_char(SYSDATE,'YYYYMMDD'),
            Round(sum(IR_AMT_USD),5)*-1  AS TT_AMT_USD
     FROM PLD_KPI_IR_DETAIL
     WHERE IR_DATE >= f_YYYYMMDD
       AND IR_DATE <= t_YYYYMMDD
       AND PART_NO is not null
       AND ACCOUNT_ASSIGNMENT = 'Y'
       AND PART_CURRENCY <> 'USD'
       AND GLOBAL_VENDOR_CODE NOT IN ('H00000', 'H00001', 'H00002', 'H00479')
     GROUP BY SUBSTRB(IR_DATE,1,4), SUBSTRB(IR_DATE,5,2), PART_NO
     ORDER BY SUBSTRB(IR_DATE,1,4), SUBSTRB(IR_DATE,5,2), PART_NO;

---*********************************************************************************
begin
-----------------------------------------------------------------------------------------
-- (1)先刪除舊資料f_YYYYMMDD & t_YYYYMMDD in PLD_KPI_CR_CURR_SUM.
-----------------------------------------------------------------------------------------
      delete from PLD_KPI_CR_CURR_IR_SUM
       WHERE YYYY||MM >= SUBSTRB(f_YYYYMMDD,1,6)
         AND YYYY||MM <= SUBSTRB(t_YYYYMMDD,1,6) ;
      commit;

-----------------------------------------------------------------------------------------
-- (2)新增ACCOUNT_ASSIGNMENT IS NULL, 是美金的IR資料 in PLD_KPI_CR_CURR_SUM.
-----------------------------------------------------------------------------------------
      Insert into PLD_KPI_CR_CURR_IR_SUM (
         YYYY, MM, PART_NO, MONTH_AMT, MONTH_QTY, BASE_PRICE, CREATE_DATE, MONTH_AMT_USD,
         BASE_PRICE_USD
      )
      SELECT SUBSTRB(IR_DATE,1,4), SUBSTRB(IR_DATE,5,2),
             PART_NO, Round(sum(IR_AMT_TWD),5), 
             Round(sum(PART_QTY),5),  0,  to_char(SYSDATE,'YYYYMMDD'),
             Round(sum(PART_AMOUNT),5), 0
      FROM PLD_KPI_IR_DETAIL
      WHERE IR_DATE >= f_YYYYMMDD
        AND IR_DATE <= t_YYYYMMDD
        AND PART_NO is not null
        AND ACCOUNT_ASSIGNMENT IS NULL
        AND PART_CURRENCY = 'USD'
        AND GLOBAL_VENDOR_CODE NOT IN ('H00000', 'H00001', 'H00002', 'H00479')
        GROUP BY SUBSTRB(IR_DATE,1,4), SUBSTRB(IR_DATE,5,2), PART_NO
        ORDER BY SUBSTRB(IR_DATE,1,4), SUBSTRB(IR_DATE,5,2), PART_NO;
      Commit;

-----------------------------------------------------------------------------------------
----(3) UPDATE Acc.Assignment IS NULL 不是美金的IR in PLD_KPI_CR_CURR_SUM.
-----------------------------------------------------------------------------------------
      FOR REC1 in C_PLD_KPI_CR_CURR_MONTH_COM1 Loop
---- 檢查 資料存在否, 若不存在則新增, 否則更新資料.
         iFind_Flag :=0 ;
         BEGIN
            SELECT COUNT(*) INTO iFind_Flag FROM PLD_KPI_CR_CURR_IR_SUM
             Where YYYY = REC1.YYYY
               AND MM   = REC1.MM
               AND PART_NO = REC1.PART_NO;
            EXCEPTION
                 WHEN OTHERS THEN
                 NULL ;
        END ;
        IF iFind_Flag > 0 THEN
------若資料已存在, 作更新:
           Update PLD_KPI_CR_CURR_IR_SUM
              Set MONTH_AMT = MONTH_AMT + REC1.TT_AMT,
                  MONTH_QTY = MONTH_QTY + REC1.TT_QTY,
                  MONTH_AMT_USD = MONTH_AMT_USD + REC1.TT_AMT_USD
           Where YYYY = REC1.YYYY
             AND MM   = REC1.MM
             AND PART_NO = REC1.PART_NO;
           Commit;
        ELSE
------不存在, 作新增:
           Insert into PLD_KPI_CR_CURR_IR_SUM (
              YYYY, MM, PART_NO, MONTH_AMT, MONTH_QTY, BASE_PRICE,
                        CREATE_DATE, MONTH_AMT_USD, BASE_PRICE_USD
           )
           SELECT REC1.YYYY, REC1.MM,
                  REC1.PART_NO, REC1.TT_AMT, REC1.TT_QTY, 0,
                       to_char(SYSDATE,'YYYYMMDD'), REC1.TT_AMT_USD, 0
           FROM DUAL;
           Commit;
        END IF;
      END LOOP;

-----------------------------------------------------------------------------------------
--- (4)UPDATE Acc.Assignment='Y' 是美金的IR資料 in PLD_KPI_CR_CURR_SUM.
-----------------------------------------------------------------------------------------
      FOR REC1 in C_PLD_KPI_CR_CURR_MONTH_COM2 Loop
---- 檢查 資料存在否, 若不存在則新增, 否則更新資料.
         iFind_Flag :=0 ;
         BEGIN
            SELECT COUNT(*) INTO iFind_Flag FROM PLD_KPI_CR_CURR_IR_SUM
             Where YYYY = REC1.YYYY
               AND MM   = REC1.MM
               AND PART_NO = REC1.PART_NO;
            EXCEPTION
                 WHEN OTHERS THEN
                 NULL ;
        END ;
        IF iFind_Flag > 0 THEN
------若資料已存在, 作更新:
           Update PLD_KPI_CR_CURR_IR_SUM
              Set MONTH_AMT = MONTH_AMT + REC1.TT_AMT,
                  MONTH_QTY = MONTH_QTY + REC1.TT_QTY,
                  MONTH_AMT_USD = MONTH_AMT_USD + REC1.TT_AMT_USD
           Where YYYY = REC1.YYYY
             AND MM   = REC1.MM
             AND PART_NO = REC1.PART_NO;
           Commit;
        ELSE
------不存在, 作新增:
           Insert into PLD_KPI_CR_CURR_IR_SUM (
              YYYY, MM, PART_NO, MONTH_AMT, MONTH_QTY, BASE_PRICE,
                        CREATE_DATE, MONTH_AMT_USD, BASE_PRICE_USD
           )
           SELECT REC1.YYYY, REC1.MM,
                  REC1.PART_NO, REC1.TT_AMT, REC1.TT_QTY, 0,
                       to_char(SYSDATE,'YYYYMMDD'), REC1.TT_AMT_USD, 0
           FROM DUAL;
           Commit;
        END IF;
      END LOOP;

-----------------------------------------------------------------------------------------
--- (5)UPDATE Acc.Assignment='Y' 不是美金的IR資料 in PLD_KPI_CR_CURR_SUM.
-----------------------------------------------------------------------------------------
      FOR REC1 in C_PLD_KPI_CR_CURR_MONTH_COM3 Loop
---- 檢查 資料存在否, 若不存在則新增, 否則更新資料.
         iFind_Flag :=0 ;
         BEGIN
            SELECT COUNT(*) INTO iFind_Flag FROM PLD_KPI_CR_CURR_IR_SUM
             Where YYYY = REC1.YYYY
               AND MM   = REC1.MM
               AND PART_NO = REC1.PART_NO;
            EXCEPTION
                 WHEN OTHERS THEN
                 NULL ;
        END ;
        IF iFind_Flag > 0 THEN
------若資料已存在, 作更新:
           Update PLD_KPI_CR_CURR_IR_SUM
              Set MONTH_AMT = MONTH_AMT + REC1.TT_AMT,
                  MONTH_QTY = MONTH_QTY + REC1.TT_QTY,
                  MONTH_AMT_USD = MONTH_AMT_USD + REC1.TT_AMT_USD
           Where YYYY = REC1.YYYY
             AND MM   = REC1.MM
             AND PART_NO = REC1.PART_NO;
           Commit;
        ELSE
------不存在, 作新增:
           Insert into PLD_KPI_CR_CURR_IR_SUM (
              YYYY, MM, PART_NO, MONTH_AMT, MONTH_QTY, BASE_PRICE,
                        CREATE_DATE, MONTH_AMT_USD, BASE_PRICE_USD
           )
           SELECT REC1.YYYY, REC1.MM,
                  REC1.PART_NO, REC1.TT_AMT, REC1.TT_QTY, 0,
                       to_char(SYSDATE,'YYYYMMDD'), REC1.TT_AMT_USD, 0
           FROM DUAL;
           Commit;
        END IF;
      END LOOP;
end PLSQL_PLD_KPI_CR_CURR_SUM_ADD;
/

