create PROCEDURE VQA_PLSQL_VCAR_WK
IS
      /*--------------------------------------------------------------*
         CREATE DATE:  2008/03/19
         PLSQL      :  VQA_PLSQL_VCAR_WK
         Author     :  Jason Lin
         Purpose    :  VCAR Count by week (每週執行一次)
                       TW/SZ/SH/MX
      *---------------------------------------------------------------*
      */


 vPROCEE_YYYYMMDD varchar2(8);
 vPROCEE_YYYYMM   varchar2(6);
 iTracePoint      varchar2(100);
 cErrorText       varchar2(500);

BEGIN

 --抓當月份系統日期
  iTracePoint := '000';
  vPROCEE_YYYYMMDD  :=  to_char(sysdate,'YYYYMMDD');
  vPROCEE_YYYYMM :=  SUBSTRB(vPROCEE_YYYYMMDD,1,6);
  
  --清除重覆資料
  iTracePoint := '100';
  DELETE from VQA_VCAR_WEEKLY where yyyyww in                                                
    (Select yyyyww from DIMENSION_DATE Where date_key in                                 --ISSUED_DATE所在的week             
    (select distinct ISSUED_DATE from VQA_SQM_VCAR where substrb(CLOSED_DATE,1,8) in     --CLOSED_DATE在前一星期的ISSUED_DATE
    (Select distinct date_key from DIMENSION_DATE where yyyyww in                        --前一星期所含的date_key            
    (Select yyyyww from DIMENSION_DATE Where date_key = to_char( sysdate - 7, 'yyyymmdd')))));
  
  
  
  -- 計算VCAR 週資料
  iTracePoint := '200';
  Insert into VQA_VCAR_WEEKLY (
                    COMPANY_CODE,YYYY,MM,WEEK,MANUF,PART_NO,MFR_PN,VCAR_COUNT,DATE_TIME,YYYYWW )
  select A.COMPANY_CODE,B.YYYY,B.MM,substrb(yyyyww,5,2) as WEEK,A.MFR_NAME as MANUF,A.USI_PN as PART_NO,A.MFR_PN,count(A.MFR_PN) as VCAR_COUNT,to_char( sysdate, 'yyyymmddhh24miss') as DATE_TIME,B.YYYYWW
  from VQA_SQM_VCAR A, DIMENSION_DATE B
  where A.CONCLUSION='M'
  and A.STATUS='C'
  and B.DATE_KEY in (Select distinct date_key from DIMENSION_DATE where yyyyww in    --被選取week的所有date_key
  (Select yyyyww from DIMENSION_DATE Where date_key in                               --ISSUED_DATE所在的week
  (select distinct ISSUED_DATE from VQA_SQM_VCAR where substrb(CLOSED_DATE,1,8) in   --CLOSED_DATE在前一星期的ISSUED_DATE
  (Select distinct date_key from DIMENSION_DATE where yyyyww in                      --前一星期所含的date_key
  (Select yyyyww from DIMENSION_DATE Where date_key = to_char( sysdate - 7, 'yyyymmdd'))))))
  and A.ISSUED_DATE=B.DATE_KEY
  group by COMPANY_CODE,YYYY,MM,MFR_NAME,USI_PN,MFR_PN,YYYYWW;
  
  -- 計算VCAR WW 週資料
  iTracePoint := '300';
  Insert into VQA_VCAR_WEEKLY (
                      COMPANY_CODE,YYYY,MM,WEEK,MANUF,PART_NO,MFR_PN,VCAR_COUNT,DATE_TIME,YYYYWW )
  select '0000' as COMPANY_CODE,B.YYYY,B.MM,substrb(yyyyww,5,2) as WEEK,A.MFR_NAME as MANUF,A.USI_PN as PART_NO,A.MFR_PN,count(A.MFR_PN) as VCAR_COUNT,to_char( sysdate, 'yyyymmddhh24miss') as DATE_TIME,B.YYYYWW
  from VQA_SQM_VCAR A, DIMENSION_DATE B
  where A.CONCLUSION='M'
  and A.STATUS='C'
  and B.DATE_KEY in (Select distinct date_key from DIMENSION_DATE where yyyyww in      --被選取week的所有date_key
  (Select yyyyww from DIMENSION_DATE Where date_key in                  --ISSUED_DATE所在的week
  (select distinct ISSUED_DATE from VQA_SQM_VCAR where substrb(CLOSED_DATE,1,8) in   --CLOSED_DATE在前一星期的ISSUED_DATE
  (Select distinct date_key from DIMENSION_DATE where yyyyww in                        --前一星期所含的date_key
  (Select yyyyww from DIMENSION_DATE Where date_key = to_char( sysdate - 7, 'yyyymmdd'))))))
  and A.ISSUED_DATE=B.DATE_KEY
  group by YYYY,MM,MFR_NAME,USI_PN,MFR_PN,YYYYWW;
  commit;



EXCEPTION
   When OTHERS Then
    --有錯誤產生則寄mail
    cErrorText := SQLERRM();
    MAIL_FILE_BIDBDBADMIN(in_to_name => 'jason@ms.usi.com.tw', subject => '[VQA-Error] PL/SQL VQA_PLSQL_VCAR_WK ERROR', message => '[Table:VQA_VCAR_WEEKLY], The tracepoint is  ' || iTracePoint || ' and ErrorText= ' || cErrorText) ;

END VQA_PLSQL_VCAR_WK;
/

