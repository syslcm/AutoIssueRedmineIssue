create PROCEDURE       PLD_PLS052_NON_BOM_PO (
/* ********************************************************************
  PROG-ID      : PLD_PLS052_NON_BOM_PO
  PROG-ACTION  : PLD_KPI_RTV_MONTH_PL_BY_MON Get Slow Moving by purchase department
  Author       : Asan Chang
  Date         : 2016/07/21
  OA Number    : SAI061837
*********************************************************************
SAI061837 2016/07/22 新增前先刪除舊PO/PO ITEM，以確保同PO/PO ITEM只會有一筆
********************************************************************* */
   incompany    IN   VARCHAR2,
   f_yyyymmdd   IN   VARCHAR2,
   t_yyyymmdd   IN   VARCHAR2
)
AUTHID DEFINER
IS
   CURSOR pld_kpi_non_bom_po_t
   IS
      SELECT COMPANY_CODE, VENDOR_CODE, VENDOR_NAME, MATERIAL, PO_QTY, PO_UNIT, PO_DATE, 
      PO_NO, PO_ITEM , ITEM_CATEGORY, ACCOUNT_ASSIGN_CATEGORY, MATERIAL_GROUP, PURCHASING_GROUP, PO_PRICE,               
      PO_CURRENCY, PO_EXCHANGE_RATE , PO_PRICE_UNIT, PR_NO, PR_ITEM, GL_ACCOUNT, COST_CENTER,
      PROFIT_CENTER, MAIN_ASSET_NO, ITEM_TXT, SO_NO, SO_ITEM, SHORT_TEXT, 
      PO_ITEM_TEXT1, PO_ITEM_TEXT2, PO_ITEM_TEXT3, PO_ITEM_TEXT4, PO_ITEM_TEXT5, PO_ITEM_TEXT6, 
      PO_PN_PO_TEXT1, PO_PN_PO_TEXT2, PO_PN_PO_TEXT3, PO_PN_PO_TEXT4, PO_PN_PO_TEXT5, PO_PN_PO_TEXT6, 
      MFRPN, PO_CHANGE_DATE                  

      FROM pld_kpi_non_bom_po_t
      where PO_CHANGE_DATE >= f_yyyymmdd
      AND PO_CHANGE_DATE <= t_yyyymmdd
      AND COMPANY_CODE = incompany;


   itracepoint   INTEGER;
BEGIN


   --(1)清除舊的 pld_kpi_non_bom_po 資料

   DELETE FROM pld_kpi_non_bom_po
   where PO_CHANGE_DATE >= to_date(f_yyyymmdd, 'yyyy/mm/dd') 
   AND PO_CHANGE_DATE <= to_date(t_yyyymmdd, 'yyyy/mm/dd') 
   AND COMPANY_CODE = incompany;
   COMMIT;


   FOR REC1 IN pld_kpi_non_bom_po_t LOOP
   
     --(2)清除舊的 PO/PO ITEM 資料
     DELETE FROM pld_kpi_non_bom_po
     where PO_NO = REC1.PO_NO  AND PO_ITEM = REC1.PO_ITEM 
     AND COMPANY_CODE = incompany;
     COMMIT;   
   
   
   --(3)開始處理資料
       INSERT INTO pld_kpi_non_bom_po (
            COMPANY_CODE,        VENDOR_CODE,         VENDOR_NAME,             MATERIAL, 
            PO_QTY,              PO_UNIT,             PO_DATE,                 PO_NO, 
            PO_ITEM ,            ITEM_CATEGORY,       ACCOUNT_ASSIGN_CATEGORY, MATERIAL_GROUP, 
            PURCHASING_GROUP,
            PO_PRICE,            PO_CURRENCY,         PO_EXCHANGE_RATE ,       PO_PRICE_UNIT, 
            PR_NO,               PR_ITEM,             GL_ACCOUNT,              COST_CENTER,
            PROFIT_CENTER,       MAIN_ASSET_NO,       ITEM_TXT,                SO_NO, 
            SO_ITEM,             SHORT_TEXT,          PO_ITEM_TEXT1,           PO_ITEM_TEXT2, 
            PO_ITEM_TEXT3,       PO_ITEM_TEXT4,       PO_ITEM_TEXT5,           PO_ITEM_TEXT6, 
            PO_PN_PO_TEXT1,      PO_PN_PO_TEXT2,      PO_PN_PO_TEXT3,          PO_PN_PO_TEXT4, 
            PO_PN_PO_TEXT5,      PO_PN_PO_TEXT6,      MFRPN,                   PO_CHANGE_DATE
            ) VALUES (
                 
            REC1.COMPANY_CODE,   REC1.VENDOR_CODE,    REC1.VENDOR_NAME,             REC1.MATERIAL, 
            REC1.PO_QTY,         REC1.PO_UNIT, to_date(REC1.PO_DATE, 'yyyy/mm/dd'), REC1.PO_NO, 
            REC1.PO_ITEM ,       REC1.ITEM_CATEGORY,  REC1.ACCOUNT_ASSIGN_CATEGORY, REC1.MATERIAL_GROUP,
            REC1.PURCHASING_GROUP, 
            REC1.PO_PRICE,       REC1.PO_CURRENCY,    REC1.PO_EXCHANGE_RATE ,       REC1.PO_PRICE_UNIT, 
            REC1.PR_NO,          REC1.PR_ITEM,        REC1.GL_ACCOUNT,              REC1.COST_CENTER,
            REC1.PROFIT_CENTER,  REC1.MAIN_ASSET_NO,  REC1.ITEM_TXT,                REC1.SO_NO, 
            REC1.SO_ITEM,        REC1.SHORT_TEXT,     REC1.PO_ITEM_TEXT1,           REC1.PO_ITEM_TEXT2, 
            REC1.PO_ITEM_TEXT3,  REC1.PO_ITEM_TEXT4,  REC1.PO_ITEM_TEXT5,           REC1.PO_ITEM_TEXT6, 
            REC1.PO_PN_PO_TEXT1, REC1.PO_PN_PO_TEXT2, REC1.PO_PN_PO_TEXT3,          REC1.PO_PN_PO_TEXT4, 
            REC1.PO_PN_PO_TEXT5, REC1.PO_PN_PO_TEXT6, REC1.MFRPN,                   to_date(REC1.PO_CHANGE_DATE, 'yyyy/mm/dd')            
             );    
       COMMIT;

   END LOOP;

   --(4) 刪除資料


   DELETE FROM pld_kpi_non_bom_po_t
   where PO_CHANGE_DATE >= f_yyyymmdd
   AND PO_CHANGE_DATE <= t_yyyymmdd
   AND COMPANY_CODE = incompany;
   COMMIT;

   --(4) Send Mail
END PLD_PLS052_NON_BOM_PO;
/

