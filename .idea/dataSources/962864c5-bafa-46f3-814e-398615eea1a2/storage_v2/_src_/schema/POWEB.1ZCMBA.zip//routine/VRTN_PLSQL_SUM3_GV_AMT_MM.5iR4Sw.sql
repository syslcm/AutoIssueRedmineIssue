create PROCEDURE         "VRTN_PLSQL_SUM3_GV_AMT_MM" IS

    /*
     每月執行一次
          VRTN_SUM07_AMT_GV_MATGP_M table
	        VRTN_SUM08_AMT_GV_VM_M table
          Susan 2007/06/27 
                'H00479' 201905
     */


 vPROCEE_YYYYMMDD varchar2(8);
 vPROCEE_YYYYMM   varchar2(6);
 iTracePoint      varchar2(100);
 cErrorText       varchar2(500);
 vCOMPANY_CODE    varchar2(4);
 vYYYYMM          varchar2(6);

BEGIN
    vCOMPANY_CODE := null;
    vYYYYMM := null;

   --抓上個月資料
     iTracePoint := '100';
     vPROCEE_YYYYMM := TO_CHAR(ADD_MONTHS(SYSDATE, -1), 'YYYYMM');



  vCOMPANY_CODE := '1100';
  if vCOMPANY_CODE is null then
     --若沒抓到資料則寄 error mail
     iTracePoint := '110';
     cErrorText := 'No data!';
     MAIL_FILE_BIDBDBADMIN(in_to_name => 'shuchin_lin@usiglobal.com', subject => '[VRT] PL/SQL VRTN_PLSQL_SUM3_GV_AMT_MM ERROR', message => '[VRTN_PLSQL_SUM3_GV_AMT_MM], The tracepoint is  ' || iTracePoint || ' and ErrorText= ' || cErrorText) ;
  else

     --清除舊的 VRTN_SUM07_AMT_GV_MATGP_M 資料
       iTracePoint := '200';
       DELETE FROM VRTN_SUM07_AMT_GV_MATGP_M WHERE YYYY = SUBSTRB(vPROCEE_YYYYMM,1,4)
                                               AND MM   = SUBSTRB(vPROCEE_YYYYMM,5,2);

     --放入上月分數
       iTracePoint := '210';
       for REC1 in ( Select A.GLOBAL_VENDOR_CODE, A.MTL_GROUP, SUBSTRB(A.IR_DATE,1,4) AS YYYY, SUBSTRB(A.IR_DATE,5,2) AS MM,  SUBSTRB(A.IR_DATE,1,4) || C.QUARTER AS QUARTER, round(SUM(A.IR_AMT_TWD), 2) as IR_AMT_TWD
                            from PLD_KPI_IR_DETAIL A, PLD_KPI_VENDOR_MASTER B, DIMENSION_DATE C, VRTN_COMPANY_SITE D
                                where A.COMPANY_CODE is Not Null
                                and A.GLOBAL_VENDOR_CODE is Not Null
							                	and A.COMPANY_CODE = D.MFG_SITE
                                and A.MTL_GROUP is Not Null
                                and A.MTL_GROUP >= '001'
                                and A.MTL_GROUP <= '059'
                            --  and A.PART_NO is Not Null
                                and A.GLOBAL_VENDOR_CODE not in ('H00000','H00001','H00002')                     
                                and A.COMPANY_CODE = B.COMPANY_CODE
                                and A.VENDOR_ID = B.VENDOR_ID                         
                                and SUBSTRB(A.IR_DATE,1,4) = SUBSTRB(vPROCEE_YYYYMM,1,4)
                                and SUBSTRB(A.IR_DATE,5,2) = SUBSTRB(vPROCEE_YYYYMM,5,2)
                                and (SUBSTRB(A.IR_DATE,1,4) || SUBSTRB(A.IR_DATE,5,2) || '01' ) = C.DATE_KEY
              Group by A.GLOBAL_VENDOR_CODE, A.MTL_GROUP, SUBSTRB(A.IR_DATE,1,4), SUBSTRB(A.IR_DATE,5,2), C.QUARTER
              ) loop
      --放到 VRTN_SUM07_AMT_GV_MATGP_M
      iTracePoint := '220-' || REC1.GLOBAL_VENDOR_CODE || '-' || REC1.MTL_GROUP || '-' || vPROCEE_YYYYMM || REC1.YYYY || REC1.MM;
      insert into VRTN_SUM07_AMT_GV_MATGP_M(
                  GV_VENDOR, MATGROUP, YYYY, MM, QUARTER, AMOUNT, VENDOR, SITE, DATE_TIME
           ) values (
           REC1.GLOBAL_VENDOR_CODE,
           REC1.MTL_GROUP,
           REC1.YYYY,
           REC1.MM,
           REC1.QUARTER,
           REC1.IR_AMT_TWD,
           '',
           '',
           to_char(sysdate,'YYYYMMDD')
           );
      commit;
    end loop;
  end if;


  --Process By Vendor
  --增加select matgroup check有值才做
   for REC1 in (SELECT GV_VENDOR, YYYY, MM FROM VRTN_SUM07_AMT_GV_MATGP_M
                       WHERE YYYY = SUBSTRB(vPROCEE_YYYYMM,1,4)
                         AND MM = SUBSTRB(vPROCEE_YYYYMM,5,2)
                         ) loop
      vYYYYMM := REC1.YYYY || REC1.MM;
   end loop;

  if vYYYYMM is null then
     --若沒抓到資料則寄 error mail
     iTracePoint := '300';
     cErrorText := 'No data!';
     MAIL_FILE_BIDBDBADMIN(in_to_name => 'shuchin_lin@usiglobal.com', subject => '[VRT] PL/SQL VRTN_PLSQL_SUM3_GV_AMT_MM ERROR', message => '[VRTN_PLSQL_SUM3_GV_AMT_MM], The tracepoint is  ' || iTracePoint || ' and ErrorText= ' || cErrorText) ;
  else

     --清除舊的 VRTN_SUM08_AMT_GV_VM_M 資料
       iTracePoint := '400';
       DELETE FROM VRTN_SUM08_AMT_GV_VM_M WHERE YYYY = SUBSTRB(vPROCEE_YYYYMM,1,4)
                                            AND MM   = SUBSTRB(vPROCEE_YYYYMM,5,2);

     --放入上月分數
       iTracePoint := '500';
       for REC1 in ( Select GV_VENDOR, YYYY, MM, QUARTER , round(SUM(AMOUNT), 2) as AMOUNT
                            from VRTN_SUM07_AMT_GV_MATGP_M
                                where GV_VENDOR is Not Null
                                and MATGROUP is Not Null
                                and YYYY = SUBSTRB(vPROCEE_YYYYMM,1,4)
                                and MM = SUBSTRB(vPROCEE_YYYYMM,5,2)
              Group by GV_VENDOR, YYYY, MM, QUARTER
              ) loop
      --放到 VRTN_SUM08_AMT_GV_VM_M
      iTracePoint := '510-' || REC1.GV_VENDOR || '-' ||  REC1.YYYY || REC1.MM;
      insert into VRTN_SUM08_AMT_GV_VM_M(
                  GV_VENDOR, YYYY, MM, QUARTER, AMOUNT, VENDOR, SITE, DATE_TIME
           ) values (
           REC1.GV_VENDOR,
           REC1.YYYY,
           REC1.MM,
           REC1.QUARTER,
           REC1.AMOUNT,
           '',
           '',
           to_char(sysdate,'YYYYMMDD')
           );
      commit;
    end loop;
  end if;



EXCEPTION
   When OTHERS Then
    --有錯誤產生則寄mail
      cErrorText := SQLERRM();
      MAIL_FILE_BIDBDBADMIN(in_to_name => 'shuchin_lin@usiglobal.com', subject => '[VRT] PL/SQL VRTN_PLSQL_SUM3_GV_AMT_MM ERROR', message => '[VRTN_PLSQL_SUM3_GV_AMT_MM], The tracepoint is  ' || iTracePoint || ' and ErrorText= ' || cErrorText);


END VRTN_PLSQL_SUM3_GV_AMT_MM;
/

