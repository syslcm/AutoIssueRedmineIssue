create PROCEDURE       ROIC_PLS003_TB_UI (
  inCompany  in VARCHAR2,
  f_YYYYMMDD in VARCHAR2,
  t_YYYYMMDD in VARCHAR2
)
AUTHID DEFINER
is
/*********************************************************************
  PROG-ID      : ROIC_PLS003_TB_UI
  PROG-ACTION  : Trial Balance 
  Author       : Patty
  Date         : 2018/12/20
  OA No.       : SAI091158
  Memo         : For UI Only
  Process      :
  1. Transfer ROIC_SAP003_TB_DATA_UI to ROIC_SAP003_TB_DATA by company_code
**********************************************************************/
/*---------------------------------------------------------------------
-- 2019/01/15 SAI093839 Patty Add transfer TWD/USD/CNY Amount
-- 2019/03/13 SAI096012 Patty 依集團會科類別不同採取不同匯率
--            若類別 = 'IS' => 採取 'C'-中國人民銀行匯率,月平均
--            其他          => 採取 'E'-中國人民銀行匯率,月底收盤價
---------------------------------------------------------------------*/

 t_CURRENCY_LOC      ROIC_SAP003_TB_DATA.WAERS_LOC2%TYPE;
 a_EX_RATE_TWD       ROIC_SAP003_TB_DATA.EXCH_RATE_TWD2%TYPE;
 a_EX_RATE_USD       ROIC_SAP003_TB_DATA.EXCH_RATE_USD2%TYPE;
 a_EX_RATE_CNY       ROIC_SAP003_TB_DATA.EXCH_RATE_CNY2%TYPE; 
 w_YYYY              VARCHAR2(4);
 w_MM                VARCHAR2(2);
 
 CURSOR C_PERIOD is 
       Select DISTINCT COMPANY_CODE, PERIOD FROM ROIC_SAP003_TB_DATA_UI 
              GROUP BY COMPANY_CODE, PERIOD;

BEGIN

  for REC1 in C_PERIOD loop

-- << SAI096012 Begin --
/*---------------------------------------------------------------------
--   --?CURRENCY_LOCAL
--   t_CURRENCY_LOC := Null;
--   Select * into t_CURRENCY_LOC From (
--            Select distinct WAERS_LOC2 from ROIC_SAP003_TB_DATA_UI
--            where COMPANY_CODE = REC1.COMPANY_CODE
--              and PERIOD = REC1.PERIOD
--			  and ROWNUM <= 1
--        );    
--
--   a_EX_RATE_TWD := GET_EXCHANGE_RATE_RWF(SUBSTRB(REC1.PERIOD,1,4),SUBSTRB(REC1.PERIOD,5,2),t_CURRENCY_LOC,'TWD','C');	
--   a_EX_RATE_USD := GET_EXCHANGE_RATE_RWF(SUBSTRB(REC1.PERIOD,1,4),SUBSTRB(REC1.PERIOD,5,2),t_CURRENCY_LOC,'USD','C');	
--   a_EX_RATE_CNY := GET_EXCHANGE_RATE_RWF(SUBSTRB(REC1.PERIOD,1,4),SUBSTRB(REC1.PERIOD,5,2),t_CURRENCY_LOC,'CNY','C');	
---------------------------------------------------------------------*/
-- -- SAI096012 End  >>
                 
   --(1) Delete Old Data  
    DELETE FROM ROIC_SAP003_TB_DATA
           WHERE COMPANY_CODE = REC1.COMPANY_CODE
             AND PERIOD = REC1.PERIOD
             AND SRC    = 'SAP';
    Commit;
 
   --(2) Process Data
-- << SAI096012 Begin --
/*---------------------------------------------------------------------
--    UPDATE ROIC_SAP003_TB_DATA_UI
--      SET SRC = 'SAP',
--          CREATE_USER = 'SYSTEM',
--          EXCH_RATE_TWD2 = a_EX_RATE_TWD,
--          EXCH_RATE_USD2 = a_EX_RATE_USD,
--          EXCH_RATE_CNY2 = a_EX_RATE_CNY,          
--          AMOUNT_TWD2 = Round(AMOUNT_LOC2 * a_EX_RATE_TWD, 5),
--          AMOUNT_USD2 = Round(AMOUNT_LOC2 * a_EX_RATE_USD, 5),
--          AMOUNT_CNY2 = Round(AMOUNT_LOC2 * a_EX_RATE_CNY, 5)              
--      WHERE COMPANY_CODE = REC1.COMPANY_CODE
--             AND PERIOD = REC1.PERIOD;
--   Commit;   

---------------------------------------------------------------------*/

    for REC2 in ( Select DISTINCT A.COMPANY_CODE, A.PERIOD, A.SAP_ACCT, NVL(A.FUN_AREA, ' ') AS FUN_AREA, A.WAERS_LOC2, B.GROUP2 
                        FROM ROIC_SAP003_TB_DATA_UI A, ROIC_VEW001_ACCT_MAPPING B  
                       WHERE A.COMPANY_CODE = REC1.COMPANY_CODE
                         AND A.PERIOD = REC1.PERIOD
                         AND A.COMPANY_CODE = B.COMPANY_CODE(+)
                         AND A.SAP_ACCT = B.SAP_ACCT(+)
                         AND NVL(A.FUN_AREA, ' ') = B.FUN_AREA(+)

		       
    ) loop

         t_CURRENCY_LOC := REC2.WAERS_LOC2;
         w_YYYY         := SUBSTRB(REC2.PERIOD,1,4);
         w_MM           := SUBSTRB(REC2.PERIOD,5,2);
         if REC2.GROUP2 = 'IS' then
            a_EX_RATE_TWD := GET_EXCHANGE_RATE_RWF(w_YYYY,w_MM,t_CURRENCY_LOC,'TWD','C');
            a_EX_RATE_USD := GET_EXCHANGE_RATE_RWF(w_YYYY,w_MM,t_CURRENCY_LOC,'USD','C');
            a_EX_RATE_CNY := GET_EXCHANGE_RATE_RWF(w_YYYY,w_MM,t_CURRENCY_LOC,'CNY','C');	
         else
            a_EX_RATE_TWD := GET_EXCHANGE_RATE_RWF(w_YYYY,w_MM,t_CURRENCY_LOC,'TWD','E');
            a_EX_RATE_USD := GET_EXCHANGE_RATE_RWF(w_YYYY,w_MM,t_CURRENCY_LOC,'USD','E');
            a_EX_RATE_CNY := GET_EXCHANGE_RATE_RWF(w_YYYY,w_MM,t_CURRENCY_LOC,'CNY','E');
         end if; 

         UPDATE ROIC_SAP003_TB_DATA_UI
           SET SRC = 'SAP', 
               CREATE_USER = 'SYSTEM',
	       EXCH_RATE_TWD2 = a_EX_RATE_TWD,
	       EXCH_RATE_USD2 = a_EX_RATE_USD,
	       EXCH_RATE_CNY2 = a_EX_RATE_CNY,		  
	       AMOUNT_TWD2 = Round(AMOUNT_LOC2 * a_EX_RATE_TWD, 5),
	       AMOUNT_USD2 = Round(AMOUNT_LOC2 * a_EX_RATE_USD, 5),
	       AMOUNT_CNY2 = Round(AMOUNT_LOC2 * a_EX_RATE_CNY, 5)
          WHERE COMPANY_CODE = REC2.COMPANY_CODE
            AND PERIOD = REC2.PERIOD
            AND SAP_ACCT = REC2.SAP_ACCT
            AND NVL(FUN_AREA, ' ') = REC2.FUN_AREA;		  

         Commit;

    end loop;     

-- -- SAI096012 End  >>

   --(3) Insert Data     
         -- ROIC_SAP003_TB_DATA_UI -> ROIC_SAP003_TB_DATA
     Insert into ROIC_SAP003_TB_DATA
        Select * From ROIC_SAP003_TB_DATA_UI
         where COMPANY_CODE = REC1.COMPANY_CODE
           and PERIOD = REC1.PERIOD;
     Commit;
 end loop;

END ROIC_PLS003_TB_UI;
/

