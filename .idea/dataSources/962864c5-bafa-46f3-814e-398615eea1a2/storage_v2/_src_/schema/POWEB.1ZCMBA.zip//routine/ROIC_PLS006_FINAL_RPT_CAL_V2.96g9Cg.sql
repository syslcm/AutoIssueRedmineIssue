create PROCEDURE       "ROIC_PLS006_FINAL_RPT_CAL_V2" (
  in_YYYYMM1    IN   VARCHAR2,
  in_RPT_TYPE1   IN   VARCHAR2
)
AUTHID DEFINER
/* ****************************************************************************************
  PROG-ID      : ROIC_PLS006_FINAL_RPT_CAL_V2
  PROG-ACTION  :   
  Author       : Asan Chang
  Date         : 2019/05/29
  OA No.       : SAI099902
 ========================================================================================== 
 2019/06/03 SAI099902 Asan Chang modify Min. Cash ����
 2019/06/04 SAI099902 modify ROIC div 0
 2019/06/04 SAI099902 ����TB��������
 2019/11/22 SAI110229 Asan Chang modify ROIC div 0
 *************************************************************************************/
is
   iReccnt              integer;
   In_YYYY              DIMENSION_DATE.YYYY%TYPE;
   In_MM                DIMENSION_DATE.MM%TYPE; 
   In_PERIOD            DIMENSION_DATE.YYYYMM%TYPE;
   In_RPT_TYPE          varchar2(30);
   From_PERIOD          DIMENSION_DATE.YYYYMM%TYPE; 
   DATE_TRANS           varchar2(10);
   sPROC_NAME           ROIC_PST000_LOG.PROC_NAME%TYPE;
   sRUN_SEQ             ROIC_PST000_LOG.RUN_SEQ%TYPE;
   sRUN_DESC            ROIC_PST000_LOG.RUN_DESC%TYPE;
   sPARAMETER_DESC      ROIC_PST000_LOG.PARAMETER_DESC%TYPE;   
   L_CNT                NUMBER(6);  
   L_waers_loc2         varchar2(30);
   iTracePoint          integer ; 
   In_MM2               integer ;
   inCompany            ROA_PST004_FIXED_ASSETS.COMPANY_CODE%TYPE;
   STR01                varchar2(30);
   STR02                varchar2(30);
   STR03                varchar2(30);
   STR04                varchar2(30);
   STR06                varchar2(30); 
   STR07                varchar2(30);    
   
   TMP_AMT1             NUMBER(15,5);
   TMP_AMT2             NUMBER(15,5); 
   TMP_AMT3             NUMBER(15,5);
   TMP_AMT4             NUMBER(15,5); 
BEGIN
--
  In_YYYY := SUBSTR( in_YYYYMM1, 1, 4);
  In_MM := SUBSTR( in_YYYYMM1, 5, 2); 
  In_MM2 := In_MM;
  In_PERIOD := In_YYYY || In_MM;
  In_RPT_TYPE := in_RPT_TYPE1;
  --In_KIND := in_Kind1;
  DATE_TRANS := In_YYYY ||'-'|| In_MM || '-01';

  sPROC_NAME := 'ROIC_PLS006_FINAL_RPT_CAL_V2';
  sRUN_SEQ   := '000010';
  sRUN_DESC  := 'Start';
  sPARAMETER_DESC := CONCAT(CONCAT(CONCAT('PERIOD=',In_PERIOD),';RPT_TYPE='),In_RPT_TYPE);
  
  --Insert Log
  INSERT INTO ROIC_PST000_LOG
      ( PROC_NAME, RUN_SEQ, RUN_DESC, PARAMETER_DESC )
    VALUES
      ( sPROC_NAME, sRUN_SEQ, sRUN_DESC, sPARAMETER_DESC );
  Commit;

  --Delete old data
  delete ROIC_PST007_FINAL_RPT_CAL WHERE PERIOD = In_PERIOD AND RPT_TYPE = In_RPT_TYPE;
  COMMIT ;   
  
  --get from period
  for REC_PERIOD IN (
    (select TO_CHAR(add_months(TO_DATE(DATE_TRANS, 'YYYY-MM-DD'),-11),'YYYYMM') FROM_PERIOD from dual )
  )
  LOOP
    From_PERIOD := REC_PERIOD.FROM_PERIOD;                 
  END LOOP;
  
  
   for REC_FORMAT2 IN (
       select a.company_code,b.s_order,b.s_desc  from PNL_MAP006_SITE_MAPPING a, ROIC_MAP005_FINAL_FORMAT b
	   where b.caculate = 'N'
  )
  LOOP
    select count(*) INTO L_CNT from  roic_vew005_final_rpt_v2 where period = In_PERIOD and company_code = REC_FORMAT2.company_code
	and s_order = REC_FORMAT2.s_order and s_desc =  REC_FORMAT2.s_desc AND RPT_TYPE = In_RPT_TYPE;            
    if L_CNT <= 0 Then      
      BEGIN 
      select waers_loc2 INTO L_waers_loc2 from  roic_vew005_final_rpt_v2 where period = In_PERIOD and company_code = REC_FORMAT2.company_code and rownum = 1;  
	        
        INSERT INTO ROIC_PST007_FINAL_RPT_CAL
         ( COMPANY_CODE ,PERIOD,RPT_TYPE , S_DESC, WAERS_LOC2, AMOUNT_LOC2, AMOUNT_TWD2, AMOUNT_USD2, AMOUNT_CNY2) 
        VALUES
         ( REC_FORMAT2.COMPANY_CODE ,In_PERIOD ,In_RPT_TYPE, REC_FORMAT2.S_DESC,  L_waers_loc2, 0, 0, 0, 0);           
         
      EXCEPTION
         WHEN NO_DATA_FOUND THEN
         -- 
           L_CNT := 0;    
         END;            
     end if;   	
	

		
  END LOOP;
                   
  /*****************************************************************************************
      (1)OPM
  ************************************************************************************ */
  --OPM=REV-COGS-SG&A
       
      STR01 :=  'OPM';
	  STR02 :=  'REV';                  --GROUP1
	  STR03 :=  'COGS';                 --GROUP1
	  STR04 :=  'SG'|| chr(38) ||'A';   --GROUP4
	  --STR04 :=  'SG&A';
	  
      for REC1 IN (
	    --SQL
        select  AA1.company_code, AA1.period, AA1.waers_loc2, AA1.RPT_TYPE ,
        AA1.amount_loc2+AA2.amount_loc2+AA3.amount_loc2 amount_loc2,
        AA1.amount_twd2+AA2.amount_twd2+AA3.amount_twd2 amount_twd2,
        AA1.amount_usd2+AA2.amount_usd2+AA3.amount_usd2 amount_usd2,
        AA1.amount_cny2+AA2.amount_cny2+AA3.amount_cny2 amount_cny2      
        
        from
        (
          SELECT a.company_code, a.period, a.waers_loc2, a.RPT_TYPE,
            SUM (a.amount_loc2)  amount_loc2,
            SUM (a.amount_twd2)  amount_twd2,
            SUM (a.amount_usd2)  amount_usd2,
            SUM (a.amount_cny2)  amount_cny2
          FROM ROIC_VEW005_FINAL_RPT_V2 a
          WHERE a.S_DESC = STR02 and a.period = In_PERIOD and a.RPT_TYPE = In_RPT_TYPE
          GROUP BY company_code, period, waers_loc2	,RPT_TYPE	    

		  
        ) AA1 left join

        (		
          SELECT a.company_code, a.period, a.waers_loc2,a.RPT_TYPE,
            SUM (a.amount_loc2)  amount_loc2,
            SUM (a.amount_twd2)  amount_twd2,
            SUM (a.amount_usd2)  amount_usd2,
            SUM (a.amount_cny2)  amount_cny2
          FROM ROIC_VEW005_FINAL_RPT_V2 a
          WHERE a.S_DESC = STR03 and a.period = In_PERIOD and a.RPT_TYPE = In_RPT_TYPE
          GROUP BY company_code, period, waers_loc2	,RPT_TYPE	

		  
        ) AA2 on  AA1.company_code = AA2.company_code and  AA1.period = AA2.period
        left join

        (		
          SELECT a.company_code, a.period, a.waers_loc2,a.RPT_TYPE,
            SUM (a.amount_loc2)  amount_loc2,
            SUM (a.amount_twd2)  amount_twd2,
            SUM (a.amount_usd2)  amount_usd2,
            SUM (a.amount_cny2)  amount_cny2
          FROM ROIC_VEW005_FINAL_RPT_V2 a
          WHERE a.S_DESC = STR04 and a.period = In_PERIOD and a.RPT_TYPE = In_RPT_TYPE
          GROUP BY company_code, period, waers_loc2	,RPT_TYPE
		  
		
        ) AA3  on AA2.company_code = AA3.company_code and  AA2.period = AA3.period
             
         
      )
      LOOP
        INSERT INTO ROIC_PST007_FINAL_RPT_CAL
         ( COMPANY_CODE ,PERIOD,RPT_TYPE , S_DESC, WAERS_LOC2, AMOUNT_LOC2, AMOUNT_TWD2, AMOUNT_USD2, AMOUNT_CNY2) 
        VALUES
         ( REC1.COMPANY_CODE ,REC1.PERIOD ,REC1.RPT_TYPE, STR01, REC1.WAERS_LOC2, REC1.AMOUNT_LOC2, REC1.AMOUNT_TWD2, REC1.AMOUNT_USD2, REC1.AMOUNT_CNY2);                 
      END LOOP;    
 
  /*****************************************************************************************
      (2)Min. Cash
  ************************************************************************************ */
  --1. Sep'18 Min. Cash=-{SUM(COGS rolling 12 months)-'SUM(D&A rolling 12 months)+'SUM(SG&A rolling 12 months)}*30/365
  
 
      STR01 :=  'Min. Cash';
	  STR02 :=  'COGS';                 --GROUP1
	  STR03 :=  'SG'|| chr(38) ||'A';   --GROUP4
	  STR04 :=  'D'|| chr(38) ||'A';    --GROUP3
	  --STR04 :=  'SG&A';
  
      for REC1 IN (
	    --SQL
        select  AA1.company_code, AA1.waers_loc2, AA1.RPT_TYPE ,
        ( AA1.amount_loc2 + AA2.amount_loc2 - AA3.amount_loc2 ) * 30 / 365 * -1 amount_loc2,
        ( AA1.amount_twd2 + AA2.amount_twd2 - AA3.amount_twd2 ) * 30 / 365 * -1 amount_twd2,
        ( AA1.amount_usd2 + AA2.amount_usd2 - AA3.amount_usd2 ) * 30 / 365 * -1 amount_usd2,
        ( AA1.amount_cny2 + AA2.amount_cny2 - AA3.amount_cny2 ) * 30 / 365 * -1 amount_cny2   
        
        from
        (
          SELECT a.company_code, a.waers_loc2,a.RPT_TYPE,
            SUM (a.amount_loc2)  amount_loc2,
            SUM (a.amount_twd2)  amount_twd2,
            SUM (a.amount_usd2)  amount_usd2,
            SUM (a.amount_cny2)  amount_cny2
          FROM ROIC_VEW005_FINAL_RPT_V2 a
          WHERE a.S_DESC = STR03 and ( ( a.period <= In_PERIOD and a.period >= From_PERIOD ) and a.RPT_TYPE = In_RPT_TYPE  )
          GROUP BY company_code,  waers_loc2,RPT_TYPE		  		  
		  
		  
        ) AA1 left join

        (

          SELECT a.company_code, a.waers_loc2,a.RPT_TYPE,
            SUM (a.amount_loc2)  amount_loc2,
            SUM (a.amount_twd2)  amount_twd2,
            SUM (a.amount_usd2)  amount_usd2,
            SUM (a.amount_cny2)  amount_cny2
          FROM ROIC_VEW005_FINAL_RPT_V2 a
          WHERE a.S_DESC = STR02 and ( ( a.period <= In_PERIOD and a.period >= From_PERIOD )  and a.RPT_TYPE = In_RPT_TYPE )
          GROUP BY company_code,  waers_loc2,RPT_TYPE			


		  
        ) AA2 on  AA1.company_code = AA2.company_code 
        left join

        (
		
          SELECT a.company_code, a.waers_loc2, a.RPT_TYPE,
            SUM (a.amount_loc2)  amount_loc2,
            SUM (a.amount_twd2)  amount_twd2,
            SUM (a.amount_usd2)  amount_usd2,
            SUM (a.amount_cny2)  amount_cny2
          FROM ROIC_VEW005_FINAL_RPT_V2 a
          WHERE a.S_DESC = STR04 and ( ( a.period <= In_PERIOD and a.period >= From_PERIOD ) and a.RPT_TYPE = In_RPT_TYPE )
          GROUP BY company_code,  waers_loc2,RPT_TYPE
		  
		
        ) AA3  on AA2.company_code = AA3.company_code
         
      )
      LOOP
        INSERT INTO ROIC_PST007_FINAL_RPT_CAL
         ( COMPANY_CODE ,PERIOD ,RPT_TYPE, S_DESC, WAERS_LOC2, AMOUNT_LOC2, AMOUNT_TWD2, AMOUNT_USD2, AMOUNT_CNY2) 
        VALUES
         ( REC1.COMPANY_CODE , In_PERIOD ,REC1.RPT_TYPE, STR01, REC1.WAERS_LOC2, REC1.AMOUNT_LOC2, REC1.AMOUNT_TWD2, REC1.AMOUNT_USD2, REC1.AMOUNT_CNY2);                 
      END LOOP;   
 
  /*****************************************************************************************
      (3)Working Capital
  ************************************************************************************ */
  --2. Working Capital: �C������ AR+Inventory-AP�A ���e rolling �A��12����������
  -- Sep'18 Working Capital={SUM(AR rolling 12 months)+'SUM(INV rolling 12 months)-'SUM(AP rolling 12 months)}/12 

 
      STR01 :=  'Working Capital';
	  STR02 :=  'AR';                 --GROUP1
	  STR03 :=  'INV';                --GROUP1
	  STR04 :=  'AP';                 --GROUP1
	  --STR04 :=  'SG&A';
  
      for REC1 IN (
	    --SQL
        select  AA1.company_code,  AA1.waers_loc2, AA1.RPT_TYPE,
        ( AA1.amount_loc2 + AA2.amount_loc2 - AA3.amount_loc2 ) / 12 amount_loc2,
        ( AA1.amount_twd2 + AA2.amount_twd2 - AA3.amount_twd2 ) / 12 amount_twd2,
        ( AA1.amount_usd2 + AA2.amount_usd2 - AA3.amount_usd2 ) / 12 amount_usd2,
        ( AA1.amount_cny2 + AA2.amount_cny2 - AA3.amount_cny2 ) / 12 amount_cny2        
        
        from
        (
          SELECT a.company_code, a.waers_loc2, a.RPT_TYPE,
            SUM (a.amount_loc2)  amount_loc2,
            SUM (a.amount_twd2)  amount_twd2,
            SUM (a.amount_usd2)  amount_usd2,
            SUM (a.amount_cny2)  amount_cny2
          FROM ROIC_VEW005_FINAL_RPT_V2 a
          WHERE a.S_DESC = STR02 and ( a.period <= In_PERIOD and a.period >= From_PERIOD )
		  and a.RPT_TYPE = In_RPT_TYPE
          GROUP BY company_code,  waers_loc2,RPT_TYPE
        ) AA1 left join

        (
          SELECT a.company_code, a.waers_loc2, a.RPT_TYPE,
            SUM (a.amount_loc2)  amount_loc2,
            SUM (a.amount_twd2)  amount_twd2,
            SUM (a.amount_usd2)  amount_usd2,
            SUM (a.amount_cny2)  amount_cny2
          FROM ROIC_VEW005_FINAL_RPT_V2 a
          WHERE a.S_DESC = STR03 and ( a.period <= In_PERIOD and a.period >= From_PERIOD )
		  and a.RPT_TYPE = In_RPT_TYPE
          GROUP BY company_code,  waers_loc2,RPT_TYPE
        ) AA2 on  AA1.company_code = AA2.company_code
        left join

        (
          SELECT a.company_code, a.waers_loc2, a.RPT_TYPE,
            SUM (a.amount_loc2)  amount_loc2,
            SUM (a.amount_twd2)  amount_twd2,
            SUM (a.amount_usd2)  amount_usd2,
            SUM (a.amount_cny2)  amount_cny2
          FROM ROIC_VEW005_FINAL_RPT_V2 a
          WHERE a.S_DESC = STR04 and ( a.period <= In_PERIOD and a.period >= From_PERIOD )
		  and a.RPT_TYPE = In_RPT_TYPE
          GROUP BY company_code,  waers_loc2,RPT_TYPE
        ) AA3  on AA2.company_code = AA3.company_code 
        
         
      )
      LOOP
        INSERT INTO ROIC_PST007_FINAL_RPT_CAL
         ( COMPANY_CODE ,PERIOD ,RPT_TYPE, S_DESC, WAERS_LOC2, AMOUNT_LOC2, AMOUNT_TWD2, AMOUNT_USD2, AMOUNT_CNY2) 
        VALUES
         ( REC1.COMPANY_CODE ,In_PERIOD ,REC1.RPT_TYPE, STR01, REC1.WAERS_LOC2, REC1.AMOUNT_LOC2, REC1.AMOUNT_TWD2, REC1.AMOUNT_USD2, REC1.AMOUNT_CNY2);                 
      END LOOP;  

  /*****************************************************************************************
      (4)PP&E
  ************************************************************************************ */
  --3. PP&E �G �C������ PP&E (���e rolling�A��12��������)
  --PP&E �]�t :FA-Building,Electricity,Land+FA-Equitment+FA-Others+Right of use asset Land Occ Government
  -- Sep'18 PP&E={rolling 12 months(FA-Land+FA-Building,Electricity+FA-Equitment +FA-Others+Right of use asset Land Occ Government)}/12 

     
 
      STR01 :=  'PP'|| chr(38) ||'E';
	  --STR04 :=  'SG&A';
  
      for REC1 IN (
	    --SQL

          SELECT a.company_code, a.waers_loc2, a.RPT_TYPE,
            SUM (a.amount_loc2)/ 12  amount_loc2 ,
            SUM (a.amount_twd2)/ 12  amount_twd2 ,
            SUM (a.amount_usd2)/ 12  amount_usd2 ,
            SUM (a.amount_cny2)/ 12  amount_cny2 
          FROM ROIC_VEW008_FINAL_RPT_VAR a
          WHERE a.S_DESC = STR01 and ( a.period <= In_PERIOD and a.period >= From_PERIOD )
		  and a.RPT_TYPE = In_RPT_TYPE
          GROUP BY company_code,  waers_loc2,RPT_TYPE		
		
      )
      LOOP
        INSERT INTO ROIC_PST007_FINAL_RPT_CAL
         ( COMPANY_CODE ,PERIOD,RPT_TYPE , S_DESC, WAERS_LOC2, AMOUNT_LOC2, AMOUNT_TWD2, AMOUNT_USD2, AMOUNT_CNY2) 
        VALUES
         ( REC1.COMPANY_CODE ,In_PERIOD ,REC1.RPT_TYPE, STR01, REC1.WAERS_LOC2, REC1.AMOUNT_LOC2, REC1.AMOUNT_TWD2, REC1.AMOUNT_USD2, REC1.AMOUNT_CNY2);                 
      END LOOP;  
	  
    /*****************************************************************************************
      (5)NI �]after tax�^
    ************************************************************************************ */
    --4. NI  ( after tax )�G �p�� OPM * �]1-���q�����|�v�^�A ���e rolling �[�`12����
    --PS.���e���������|�v 18%,���O�d������������
	-- Sep'18 NI �]after tax�^=OPM*(1- �����|�v) rolling 12 months 

	
      STR01 :=  'NI  ( after tax )';
	  STR02 :=  'REV';                  --GROUP1
	  STR03 :=  'COGS';                 --GROUP1
	  STR04 :=  'SG'|| chr(38) ||'A';   --GROUP4
	  --STR04 :=  'SG&A';
	  
      for REC1 IN (
	    --SQL
        select  AA1.company_code, AA1.waers_loc2, AA4.TAX_RATE , AA1.RPT_TYPE,
        ((AA1.amount_loc2+AA2.amount_loc2+AA3.amount_loc2) * ( 1 - AA4.TAX_RATE ) )   amount_loc2,
        ((AA1.amount_twd2+AA2.amount_twd2+AA3.amount_twd2) * ( 1 - AA4.TAX_RATE ) )   amount_twd2,
        ((AA1.amount_usd2+AA2.amount_usd2+AA3.amount_usd2) * ( 1 - AA4.TAX_RATE ) )   amount_usd2,
        ((AA1.amount_cny2+AA2.amount_cny2+AA3.amount_cny2) * ( 1 - AA4.TAX_RATE ) )   amount_cny2        
        
        from
        (
		  
          SELECT a.company_code, a.waers_loc2,a.RPT_TYPE,
            SUM (a.amount_loc2)  amount_loc2,
            SUM (a.amount_twd2)  amount_twd2,
            SUM (a.amount_usd2)  amount_usd2,
            SUM (a.amount_cny2)  amount_cny2
          FROM ROIC_VEW005_FINAL_RPT_V2 a
          WHERE a.S_DESC = STR02 and ( a.period <= In_PERIOD and a.period >= From_PERIOD )
		  and a.RPT_TYPE = In_RPT_TYPE
          GROUP BY company_code,  waers_loc2,RPT_TYPE	  
		  
        ) AA1 left join

        (
		
          SELECT a.company_code, a.waers_loc2, a.RPT_TYPE,
            SUM (a.amount_loc2)  amount_loc2,
            SUM (a.amount_twd2)  amount_twd2,
            SUM (a.amount_usd2)  amount_usd2,
            SUM (a.amount_cny2)  amount_cny2
          FROM ROIC_VEW005_FINAL_RPT_V2 a
          WHERE a.S_DESC = STR03 and ( a.period <= In_PERIOD and a.period >= From_PERIOD )
		  and a.RPT_TYPE = In_RPT_TYPE
          GROUP BY company_code,  waers_loc2,RPT_TYPE	
        ) AA2 on  AA1.company_code = AA2.company_code 
        left join

        (

          SELECT a.company_code, a.waers_loc2, a.RPT_TYPE,
            SUM (a.amount_loc2)  amount_loc2,
            SUM (a.amount_twd2)  amount_twd2,
            SUM (a.amount_usd2)  amount_usd2,
            SUM (a.amount_cny2)  amount_cny2
          FROM ROIC_VEW005_FINAL_RPT_V2 a
          WHERE a.S_DESC = STR04 and ( a.period <= In_PERIOD and a.period >= From_PERIOD )
		  and a.RPT_TYPE = In_RPT_TYPE
          GROUP BY company_code,  waers_loc2 ,RPT_TYPE	
		
        ) AA3  on AA2.company_code = AA3.company_code
		left join
		
		(
        select * from ROIC_UPL001_TAX_RATE where  ( START_DATE <= In_PERIOD and END_DATE >= In_PERIOD )
		)
		AA4 on AA1.company_code = AA4.company_code
			         
      )
      LOOP
        INSERT INTO ROIC_PST007_FINAL_RPT_CAL
         ( COMPANY_CODE ,PERIOD ,RPT_TYPE, S_DESC, WAERS_LOC2, AMOUNT_LOC2, AMOUNT_TWD2, AMOUNT_USD2, AMOUNT_CNY2) 
        VALUES
         ( REC1.COMPANY_CODE ,In_PERIOD ,REC1.RPT_TYPE, STR01, REC1.WAERS_LOC2, REC1.AMOUNT_LOC2, REC1.AMOUNT_TWD2, REC1.AMOUNT_USD2, REC1.AMOUNT_CNY2);                 
      END LOOP;

    /*****************************************************************************************
      (6)Current NI ( after tax )
    ************************************************************************************ */
    --Current NI ( after tax )
	
      STR01 :=  'Current NI ( after tax )';
	  STR02 :=  'REV';                  --GROUP1
	  STR03 :=  'COGS';                 --GROUP1
	  STR04 :=  'SG'|| chr(38) ||'A';   --GROUP4
	  --STR04 :=  'SG&A';
	  
      for REC1 IN (
	    --SQL
        select  AA1.company_code, AA1.waers_loc2, AA4.TAX_RATE , AA1.RPT_TYPE , 
        ((AA1.amount_loc2+AA2.amount_loc2+AA3.amount_loc2) * ( 1 - AA4.TAX_RATE ) )   amount_loc2,
        ((AA1.amount_twd2+AA2.amount_twd2+AA3.amount_twd2) * ( 1 - AA4.TAX_RATE ) )   amount_twd2,
        ((AA1.amount_usd2+AA2.amount_usd2+AA3.amount_usd2) * ( 1 - AA4.TAX_RATE ) )   amount_usd2,
        ((AA1.amount_cny2+AA2.amount_cny2+AA3.amount_cny2) * ( 1 - AA4.TAX_RATE ) )   amount_cny2        
        
        from
        (
		  
          SELECT a.company_code, a.waers_loc2, a.RPT_TYPE,
            SUM (a.amount_loc2)  amount_loc2,
            SUM (a.amount_twd2)  amount_twd2,
            SUM (a.amount_usd2)  amount_usd2,
            SUM (a.amount_cny2)  amount_cny2
          FROM ROIC_VEW005_FINAL_RPT_V2 a
          WHERE a.S_DESC = STR02 and ( a.period = In_PERIOD ) and a.RPT_TYPE = In_RPT_TYPE
          GROUP BY company_code,  waers_loc2, RPT_TYPE			  
		  
        ) AA1 left join

        (
		
          SELECT a.company_code, a.waers_loc2, a.RPT_TYPE,
            SUM (a.amount_loc2)  amount_loc2,
            SUM (a.amount_twd2)  amount_twd2,
            SUM (a.amount_usd2)  amount_usd2,
            SUM (a.amount_cny2)  amount_cny2
          FROM ROIC_VEW005_FINAL_RPT_V2 a
          WHERE a.S_DESC = STR03 and ( a.period = In_PERIOD ) and a.RPT_TYPE = In_RPT_TYPE
          GROUP BY company_code,  waers_loc2, RPT_TYPE	
		  
        ) AA2 on  AA1.company_code = AA2.company_code 
        left join

        (
		
          SELECT a.company_code, a.waers_loc2, a.RPT_TYPE,
            SUM (a.amount_loc2)  amount_loc2,
            SUM (a.amount_twd2)  amount_twd2,
            SUM (a.amount_usd2)  amount_usd2,
            SUM (a.amount_cny2)  amount_cny2
          FROM ROIC_VEW005_FINAL_RPT_V2 a
          WHERE a.S_DESC = STR04 and ( a.period = In_PERIOD ) and a.RPT_TYPE = In_RPT_TYPE
          GROUP BY company_code,  waers_loc2, RPT_TYPE			
		
        ) AA3  on AA2.company_code = AA3.company_code
		left join
		(
        select * from ROIC_UPL001_TAX_RATE where  ( START_DATE <= In_PERIOD and END_DATE >= In_PERIOD )
		)
		AA4 on AA1.company_code = AA4.company_code
		

		
         
      )
      LOOP
        INSERT INTO ROIC_PST007_FINAL_RPT_CAL
         ( COMPANY_CODE ,PERIOD ,RPT_TYPE, S_DESC, WAERS_LOC2, AMOUNT_LOC2, AMOUNT_TWD2, AMOUNT_USD2, AMOUNT_CNY2) 
        VALUES
         ( REC1.COMPANY_CODE ,In_PERIOD ,REC1.RPT_TYPE, STR01, REC1.WAERS_LOC2, REC1.AMOUNT_LOC2, REC1.AMOUNT_TWD2, REC1.AMOUNT_USD2, REC1.AMOUNT_CNY2);                 
      END LOOP;

    /*****************************************************************************************
      (7)Subtotal
    ************************************************************************************ */
    --Subtotal = Min. Cash + Working Capital + PP&E

	
      STR01 :=  'Subtotal';
	  STR02 :=  'Min. Cash';                  
	  STR03 :=  'Working Capital';                 
	  STR04 :=  'PP'|| chr(38) ||'E';   

	  
      for REC1 IN (

        select  AA1.company_code, AA1.period, AA1.waers_loc2, AA1.RPT_TYPE,
        SUM ( AA1.amount_loc2 ) amount_loc2, 
        SUM ( AA1.amount_twd2 ) amount_twd2,
        SUM ( AA1.amount_usd2 ) amount_usd2,
        SUM ( AA1.amount_cny2 ) amount_cny2
        FROM  ROIC_PST007_FINAL_RPT_CAL  AA1
        WHERE ( S_DESC = STR02	OR S_DESC = STR03 OR S_DESC = STR04 ) AND AA1.period = In_PERIOD
		and AA1.RPT_TYPE = In_RPT_TYPE
        GROUP BY AA1.company_code, AA1.period, AA1.waers_loc2, AA1.RPT_TYPE	
         
      )
      LOOP
        INSERT INTO ROIC_PST007_FINAL_RPT_CAL
         ( COMPANY_CODE ,PERIOD,RPT_TYPE , S_DESC, WAERS_LOC2, AMOUNT_LOC2, AMOUNT_TWD2, AMOUNT_USD2, AMOUNT_CNY2) 
        VALUES
         ( REC1.COMPANY_CODE ,In_PERIOD ,REC1.RPT_TYPE, STR01, REC1.WAERS_LOC2, REC1.AMOUNT_LOC2, REC1.AMOUNT_TWD2, REC1.AMOUNT_USD2, REC1.AMOUNT_CNY2);                 
      END LOOP;	
        
    /*****************************************************************************************
      (8)ROIC
    ************************************************************************************ */
    --5. �C�������i�� ROIC �G ���l NI =�]after tax�^�A���� = Subtotal = Min. Cash + Working Capital + PP&E
    -- Sep'18 ROIC=NI �]after tax�^/Subtotal 

	
      STR01 :=  'ROIC'; 
      STR02 :=  'NI  ( after tax )'; 
	  STR03 :=  'Subtotal';                  
	                   

	  /*
      for REC1 IN (
        select  AA1.company_code, AA1.period, AA1.waers_loc2, AA1.RPT_TYPE ,
        ( AA1.amount_loc2 / decode(AA2.amount_loc2,0,1) ) amount_loc2,
        ( AA1.amount_twd2 / decode(AA2.amount_twd2,0,1) ) amount_twd2,
        ( AA1.amount_usd2 / decode(AA2.amount_usd2,0,1) ) amount_usd2,
        ( AA1.amount_cny2 / decode(AA2.amount_cny2,0,1) ) amount_cny2        
        
        from
        
        (
        select  AA.company_code, AA.period, AA.waers_loc2, AA.RPT_TYPE,
        SUM ( AA.amount_loc2 ) amount_loc2, 
        SUM ( AA.amount_twd2 ) amount_twd2,
        SUM ( AA.amount_usd2 ) amount_usd2,
        SUM ( AA.amount_cny2 ) amount_cny2
        FROM  ROIC_PST007_FINAL_RPT_CAL  AA
        WHERE ( S_DESC = STR02 ) AND AA.period = In_PERIOD
		and AA.RPT_TYPE = In_RPT_TYPE
        GROUP BY AA.company_code, AA.period, AA.waers_loc2	,AA.RPT_TYPE
        ) AA1 left join 
        
        (
        select  AA.company_code, AA.period, AA.waers_loc2, AA.RPT_TYPE,
        SUM ( AA.amount_loc2 ) amount_loc2,
        SUM ( AA.amount_twd2 ) amount_twd2,
        SUM ( AA.amount_usd2 ) amount_usd2,
        SUM ( AA.amount_cny2 ) amount_cny2
        FROM  ROIC_PST007_FINAL_RPT_CAL  AA
        WHERE ( S_DESC = STR03 ) AND AA.period = In_PERIOD
		and AA.RPT_TYPE = In_RPT_TYPE
        GROUP BY AA.company_code, AA.period, AA.waers_loc2	,AA.RPT_TYPE 
        	
       ) AA2 on  AA1.company_code = AA2.company_code and  AA1.period = AA2.period

      
 
      )
      LOOP
        INSERT INTO ROIC_PST007_FINAL_RPT_CAL
         ( COMPANY_CODE ,PERIOD,RPT_TYPE , S_DESC, WAERS_LOC2, AMOUNT_LOC2, AMOUNT_TWD2, AMOUNT_USD2, AMOUNT_CNY2) 
        VALUES
         ( REC1.COMPANY_CODE ,In_PERIOD ,REC1.RPT_TYPE, STR01, REC1.WAERS_LOC2, REC1.AMOUNT_LOC2, REC1.AMOUNT_TWD2, REC1.AMOUNT_USD2, REC1.AMOUNT_CNY2);                 
      END LOOP;	 
      */
	  FOR REC1 IN (
        select  AA1.company_code, AA1.period, AA1.waers_loc2, AA1.RPT_TYPE,
        --( AA1.amount_loc2 / AA2.amount_loc2 ) amount_loc2,		
        --( AA1.amount_twd2 / AA2.amount_twd2 ) amount_twd2,
        --( AA1.amount_usd2 / AA2.amount_usd2 ) amount_usd2,
        --( AA1.amount_cny2 / AA2.amount_cny2 ) amount_cny2  
		--decode(AA1.amount_loc2,0,(AA1.amount_loc2 / AA2.amount_loc2)) amount_loc2,		
		--decode(AA1.amount_twd2,0,(AA1.amount_twd2 / AA2.amount_twd2)) amount_twd2,		
		--decode(AA1.amount_usd2,0,(AA1.amount_usd2 / AA2.amount_usd2)) amount_usd2,
        --decode(AA1.amount_cny2,0,(AA1.amount_cny2 / AA2.amount_cny2)) amount_cny2		
        AA1.amount_loc2 loc2_A, AA2.amount_loc2 loc2_B, 
        AA1.amount_twd2 twd2_A, AA2.amount_twd2 twd2_B,
        AA1.amount_usd2 usd2_A, AA2.amount_usd2 usd2_B,
        AA1.amount_cny2 cny2_A, AA2.amount_cny2 cny2_B
        from
        
        (
        select  AA.company_code, AA.period, AA.waers_loc2, AA.RPT_TYPE,
        SUM ( AA.amount_loc2 ) amount_loc2,
        SUM ( AA.amount_twd2 ) amount_twd2,
        SUM ( AA.amount_usd2 ) amount_usd2,
        SUM ( AA.amount_cny2 ) amount_cny2
        FROM  ROIC_PST007_FINAL_RPT_CAL  AA
        WHERE ( S_DESC = STR02 ) AND AA.period = In_PERIOD     
        and AA.RPT_TYPE = In_RPT_TYPE
        GROUP BY AA.company_code, AA.period, AA.waers_loc2, AA.RPT_TYPE	
        ) AA1,  
        
        (
        select  AA.company_code, AA.period, AA.waers_loc2, AA.RPT_TYPE,
        SUM ( AA.amount_loc2 ) amount_loc2,
        SUM ( AA.amount_twd2 ) amount_twd2,
        SUM ( AA.amount_usd2 ) amount_usd2,
        SUM ( AA.amount_cny2 ) amount_cny2
        FROM  ROIC_PST007_FINAL_RPT_CAL  AA
        WHERE ( S_DESC = STR03 ) AND AA.period = In_PERIOD
        and AA.RPT_TYPE = In_RPT_TYPE
        GROUP BY AA.company_code, AA.period, AA.waers_loc2, AA.RPT_TYPE		
        ) AA2        
        
		where
        AA1.company_code = AA2.company_code AND
        AA1.period = AA2.period     
      )
      LOOP 
        IF REC1.loc2_A = 0 OR REC1.loc2_B = 0  THEN  
          TMP_AMT1 := 0;
        ELSE         
          TMP_AMT1 :=  REC1.loc2_A / REC1.loc2_B;
        end IF;      
        IF REC1.twd2_A = 0 OR REC1.twd2_B = 0  THEN  
          TMP_AMT2 := 0;
        ELSE         
          TMP_AMT2 :=  REC1.twd2_A / REC1.twd2_B;
        end IF;          
        IF REC1.usd2_A = 0 OR REC1.usd2_B = 0  THEN   
          TMP_AMT3 := 0;
        ELSE         
          TMP_AMT3 :=  REC1.usd2_A / REC1.twd2_B;
        end IF; 
        IF REC1.cny2_A = 0 OR REC1.cny2_B = 0  THEN   
          TMP_AMT4 := 0;
        ELSE         
          TMP_AMT4 :=  REC1.cny2_A / REC1.cny2_B;
        end IF;         
                
        INSERT INTO ROIC_PST007_FINAL_RPT_CAL
         ( COMPANY_CODE ,PERIOD , RPT_TYPE,S_DESC, WAERS_LOC2, AMOUNT_LOC2, AMOUNT_TWD2, AMOUNT_USD2, AMOUNT_CNY2) 
        VALUES
         ( REC1.COMPANY_CODE,In_PERIOD ,REC1.RPT_TYPE , STR01, REC1.WAERS_LOC2, TMP_AMT1, TMP_AMT2, TMP_AMT3, TMP_AMT4);                 
      END LOOP;	 
 

  
  -----------------------------------------
  sRUN_SEQ   := '000020';
  sRUN_DESC  := 'End';

  --Insert Log
  INSERT INTO ROIC_PST000_LOG
      ( PROC_NAME, RUN_SEQ, RUN_DESC, PARAMETER_DESC )
    VALUES
      ( sPROC_NAME, sRUN_SEQ, sRUN_DESC, sPARAMETER_DESC );
  Commit;
  
END ROIC_PLS006_FINAL_RPT_CAL_V2;
/

