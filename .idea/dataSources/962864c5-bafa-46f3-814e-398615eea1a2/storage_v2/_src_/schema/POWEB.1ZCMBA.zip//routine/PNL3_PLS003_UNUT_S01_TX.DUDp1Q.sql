create PROCEDURE       PNL3_PLS003_UNUT_S01_TX (
  inCOMPANY       in VARCHAR2,
  inPeriod        in VARCHAR2,
  inPROFIT_CENTER in VARCHAR2,
  inGLAccount     in VARCHAR ,
  inAmount        in Number,
  inTOTAL_HRS     in Number,
  inRevenue       in Number,
  inRevenue_usd   in Number,
  inRevenue_twd   in Number,
  inCOGS          in Number,
  inCOGS_usd      in Number,
  inCOGS_twd      in Number,
  inDM            in Number,
  inDM_usd        in Number,
  inDM_twd        in Number,
  inDL            in Number,
  inDL_usd        in Number,
  inDL_twd        in Number, 
  inOH            in Number,
  inOH_usd        in Number,
  inOH_twd        in Number
)
AUTHID DEFINER
is

     
     a_Rate          number(20,10);
     a_Miss_Rate     number(20,10); --找不到end customer時用revenue來分
     a_TOTAL_HRS     PNL2_TRX003_UN_UTILIZATION.TOTAL_HRS%TYPE;
     a_COUNTER       integer;  --record count
     a_ENDCUSTOMER   PNL3_TRX001_COPA.END_CUSTOMER_ID%TYPE;
     a_NET_REVENUE   KPI_SAP001_COPA_TRX.NET_REVENUE%TYPE;
     a_REVENUE_LOCAL KPI_SAP001_COPA_TRX.NET_REVENUE%TYPE;
     a_REVENUE_TWD   KPI_SAP001_COPA_TRX.NET_REVENUE%TYPE;
     a_REVENUE_USD   KPI_SAP001_COPA_TRX.NET_REVENUE%TYPE;
     a_COGS_DM_LOCAL KPI_SAP001_COPA_TRX.NET_REVENUE%TYPE;
     a_COGS_DM_TWD   KPI_SAP001_COPA_TRX.NET_REVENUE%TYPE;
     a_COGS_DM_USD   KPI_SAP001_COPA_TRX.NET_REVENUE%TYPE;
     a_COGS_DL_LOCAL KPI_SAP001_COPA_TRX.NET_REVENUE%TYPE;
     a_COGS_DL_TWD   KPI_SAP001_COPA_TRX.NET_REVENUE%TYPE;
     a_COGS_DL_USD   KPI_SAP001_COPA_TRX.NET_REVENUE%TYPE;
     a_COGS_OH_LOCAL KPI_SAP001_COPA_TRX.NET_REVENUE%TYPE;
     a_COGS_OH_TWD   KPI_SAP001_COPA_TRX.NET_REVENUE%TYPE;
     a_COGS_OH_USD   KPI_SAP001_COPA_TRX.NET_REVENUE%TYPE;
     a_COGS_LOCAL    KPI_SAP001_COPA_TRX.NET_REVENUE%TYPE;
     a_COGS_TWD      KPI_SAP001_COPA_TRX.NET_REVENUE%TYPE;
     a_COGS_USD      KPI_SAP001_COPA_TRX.NET_REVENUE%TYPE;
     o_REVENUE       KPI_SAP001_COPA_TRX.NET_REVENUE%TYPE;
     o_COGS          KPI_SAP001_COPA_TRX.NET_REVENUE%TYPE;
     
 BEGIN
   

      a_RATE  := 0;
      FOR REC1 in (SELECT PART_NO,NVL(SUM(TOTAL_HRS),0) TOTAL_HRS FROM KPI_SAP012_EXPENSE_HISTORY
                      WHERE COMPANY_CODE = inCOMPANY 
                        AND PROFIT_CENTER = inPROFIT_CENTER
                        AND PERIOD = inPeriod
                        AND TRANSACTION = 'RKL'
                        GROUP BY PART_NO ORDER BY TOTAL_HRS DESC) Loop
        --有出現TOTAL_HRS = 0 的料號,則此料號不入
        IF REC1.TOTAL_HRS <> 0 THEN                
          a_Rate := REC1.TOTAL_HRS / inTOTAL_HRS;
         IF a_Rate <> 0 THEN
          a_REVENUE_LOCAL := 0;
          a_REVENUE_TWD   := 0;
          a_REVENUE_USD   := 0;
          a_COGS_DM_LOCAL := 0;
          a_COGS_DM_TWD   := 0;
          a_COGS_DM_USD   := 0;
          a_COGS_DL_LOCAL := 0;
          a_COGS_DL_TWD   := 0;
          a_COGS_DL_USD   := 0;
          a_COGS_OH_LOCAL := 0;
          a_COGS_OH_TWD   := 0;
          a_COGS_OH_USD   := 0;
          a_COGS_LOCAL    := 0;
          a_COGS_TWD      := 0;
          a_COGS_USD      := 0;
          o_REVENUE       := 0;
          o_COGS          := 0;

            
          a_COUNTER := 0;
          a_ENDCUSTOMER := NULL;
          FOR REC99 IN (SELECT END_CUSTOMER_ID 
             FROM PNL3_TRX001_COPA
            WHERE PART_NO =  REC1.PART_NO
              AND PROFIT_CENTER = inPROFIT_CENTER
              AND SOURCE <> 'UPL001'
              AND COMPANY_CODE = inCOMPANY
              AND PERIOD = inPeriod
           GROUP BY END_CUSTOMER_ID) LOOP
             a_COUNTER := a_COUNTER + 1;
             a_ENDCUSTOMER := REC99.END_CUSTOMER_ID;
          END LOOP;
        
          IF a_COUNTER = 1 AND  a_ENDCUSTOMER IS NOT NULL THEN  
        
            INSERT INTO PNL3_TRX003_UNUTILIZATION (
               COMPANY_CODE         ,PERIOD       ,PROFIT_CENTER      ,
               PART_NO              ,TOTAL_HRS    ,PN_HRS             ,         
               NET_REVENUE          ,NET_REVENUE_TWD ,NET_REVENUE_USD ,
               NET_COGS             ,NET_COGS_TWD    ,NET_COGS_USD    ,
               COGS_MB              ,COGS_MB_TWD     ,COGS_MB_USD     ,
               COGS_LB              ,COGS_LB_TWD     ,COGS_LB_USD     ,
               COGS_OB              ,COGS_OB_TWD     ,COGS_OB_USD     ,
               O_NET_REVENUE        ,O_NET_COGS      ,
               RATE                 ,COST_ELEMENT    ,END_CUSTOMER_ID ,
               SQL_METHOD           ,CUSTOMER_RATE   ,
               CREATE_DATE     
            ) VALUES(
               inCOMPANY            ,inPeriod     ,inPROFIT_CENTER    ,
               REC1.PART_NO         ,inTOTAL_HRS  ,REC1.TOTAL_HRS     ,
               round(inRevenue * a_RATE , 5),
               round(inRevenue_TWD * a_RATE , 5)  ,
               round(inRevenue_USD * a_RATE , 5)  , 
               round(inCOGS * a_RATE , 5)   ,
               round(inCOGS_TWD * a_RATE , 5)     ,
               round(inCOGS_USD * a_RATE , 5)     ,               
               round(inDM * a_RATE , 5),
               round(inDM_TWD * a_RATE , 5)  ,
               round(inDM_USD * a_RATE , 5)  ,                
               round(inDL * a_RATE , 5),
               round(inDL_TWD * a_RATE , 5)  ,
               round(inDL_USD * a_RATE , 5)  , 
               round(inOH * a_RATE , 5),
               round(inOH_TWD * a_RATE , 5)  ,
               round(inOH_USD * a_RATE , 5)  , 
               o_REVENUE,
               o_COGS,
               a_RATE,
               inGLAccount, 
               a_ENDCUSTOMER, 
               'WH<>0/T_AMT<>0',
               1               ,
               SYSDATE
            );
            commit;
          ELSE  --找不到end_customer或有多個end_customer時,依end customer 營收比率來分
            a_ENDCUSTOMER := NULL;
            a_NET_REVENUE := 0;

          
            IF inAmount = 0 THEN   -- NET_REVENUE =0的狀況,多發生在Profit center 9X ,全部歸到Others
               INSERT INTO PNL3_TRX003_UNUTILIZATION (
                  COMPANY_CODE         ,PERIOD       ,PROFIT_CENTER      ,
                  PART_NO              ,TOTAL_HRS    ,PN_HRS             ,         
                  NET_REVENUE          ,NET_REVENUE_TWD ,NET_REVENUE_USD ,
                  NET_COGS             ,NET_COGS_TWD    ,NET_COGS_USD    ,
                  COGS_MB              ,COGS_MB_TWD     ,COGS_MB_USD     ,
                  COGS_LB              ,COGS_LB_TWD     ,COGS_LB_USD     ,
                  COGS_OB              ,COGS_OB_TWD     ,COGS_OB_USD     ,
                  O_NET_REVENUE        ,O_NET_COGS      ,
                  RATE                 ,COST_ELEMENT    ,END_CUSTOMER_ID ,
                  SQL_METHOD           ,CUSTOMER_RATE   ,
                  CREATE_DATE     
               ) VALUES(
                  inCOMPANY            ,inPeriod     ,inPROFIT_CENTER    ,
                  REC1.PART_NO         ,inTOTAL_HRS  ,REC1.TOTAL_HRS     ,
                  round(inRevenue * a_RATE , 5),
                  round(inRevenue_TWD * a_RATE , 5)  ,
                  round(inRevenue_USD * a_RATE , 5)  , 
                  round(inCOGS * a_RATE , 5)   ,
                  round(inCOGS_TWD * a_RATE , 5)     ,
                  round(inCOGS_USD * a_RATE , 5)     ,               
                  round(inDM * a_RATE , 5),
                  round(inDM_TWD * a_RATE , 5)  ,
                  round(inDM_USD * a_RATE , 5)  ,                
                  round(inDL * a_RATE , 5),
                  round(inDL_TWD * a_RATE , 5)  ,
                  round(inDL_USD * a_RATE , 5)  , 
                  round(inOH * a_RATE , 5),
                  round(inOH_TWD * a_RATE , 5)  ,
                  round(inOH_USD * a_RATE , 5)  , 
                  o_REVENUE,
                  o_COGS,
                  a_RATE,
                  inGLAccount, 
                  NULL, 
                  'WH<>0/T_AMT=0',
                  1              ,
                  SYSDATE
               );
               commit;
            ELSE --依照營收來分
               a_Miss_RATE  := 0;
               FOR REC97 in (SELECT END_CUSTOMER_ID,NVL(SUM(AMT_TWD),0) AMT_TWD FROM PNL3_TRX001_COPA 
                        WHERE PROFIT_CENTER = inPROFIT_CENTER
                          AND SOURCE <> 'UPL001'
                          --AND COMPANY_CODE = inCOMPANY --不能加入COMPANY_CODE條件,因為PC在某個SITE可能只有COGS沒有營收
                          AND PERIOD = inPeriod
                          GROUP BY END_CUSTOMER_ID) Loop
                   a_Miss_Rate := REC97.AMT_TWD / inAmount;
                   INSERT INTO PNL3_TRX003_UNUTILIZATION (
                        COMPANY_CODE         ,PERIOD       ,PROFIT_CENTER      ,
                        PART_NO              ,TOTAL_HRS    ,PN_HRS             ,         
                        NET_REVENUE          ,NET_REVENUE_TWD ,NET_REVENUE_USD ,
                        NET_COGS             ,NET_COGS_TWD    ,NET_COGS_USD    ,
                        COGS_MB              ,COGS_MB_TWD     ,COGS_MB_USD     ,
                        COGS_LB              ,COGS_LB_TWD     ,COGS_LB_USD     ,
                        COGS_OB              ,COGS_OB_TWD     ,COGS_OB_USD     ,
                        O_NET_REVENUE        ,O_NET_COGS      ,
                        RATE                 ,COST_ELEMENT    ,END_CUSTOMER_ID ,
                        SQL_METHOD           ,CUSTOMER_RATE   ,
                        CREATE_DATE     
                   ) VALUES(
                        inCOMPANY            ,inPeriod     ,inPROFIT_CENTER    ,
                        REC1.PART_NO         ,inTOTAL_HRS  ,REC1.TOTAL_HRS     ,
                        round(inRevenue * a_RATE * a_Miss_RATE , 5),
                        round(inRevenue_TWD * a_RATE * a_Miss_RATE, 5)  ,
                        round(inRevenue_USD * a_RATE * a_Miss_RATE, 5)  , 
                        round(inCOGS * a_RATE * a_Miss_RATE, 5)   ,
                        round(inCOGS_TWD * a_RATE * a_Miss_RATE, 5)     ,
                        round(inCOGS_USD * a_RATE * a_Miss_RATE, 5)     ,               
                        round(inDM * a_RATE * a_Miss_RATE, 5),
                        round(inDM_TWD * a_RATE * a_Miss_RATE, 5)  ,
                        round(inDM_USD * a_RATE * a_Miss_RATE, 5)  ,                
                        round(inDL * a_RATE * a_Miss_RATE, 5),
                        round(inDL_TWD * a_RATE * a_Miss_RATE, 5)  ,
                        round(inDL_USD * a_RATE * a_Miss_RATE, 5)  , 
                        round(inOH * a_RATE * a_Miss_RATE, 5),
                        round(inOH_TWD * a_RATE * a_Miss_RATE, 5)  ,
                        round(inOH_USD * a_RATE * a_Miss_RATE, 5)  , 
                        o_REVENUE,
                        o_COGS,
                        a_RATE,
                        inGLAccount, 
                        REC97.END_CUSTOMER_ID, 
                        'WH<>0/T_AMT<>0',
                        a_Miss_RATE    ,
                        SYSDATE
                   );
                   commit;
               END LOOP;
            END IF;
          END IF;
         END IF;
        END IF;              
      END LOOP;
 
   
   
   
    
END PNL3_PLS003_UNUT_S01_TX;
/

