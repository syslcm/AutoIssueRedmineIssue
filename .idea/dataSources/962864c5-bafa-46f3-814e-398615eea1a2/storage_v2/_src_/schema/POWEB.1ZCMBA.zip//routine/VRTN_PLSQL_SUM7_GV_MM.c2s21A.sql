create PROCEDURE         "VRTN_PLSQL_SUM7_GV_MM" AUTHID DEFINER
IS
  /*
    Susan Create: 
        Golbal monthly
        1. By Matgroup
        2. By Vendor
        3. COMBINE
        By Susan
    2010/09/14 Add GVC_TRACK SAI017501  
  */

  vYYYY                      varchar2(4);
  vMM                        varchar2(2);
  vQA_GRADE          VRTN_SUM11_MM_MATGP.QA_GRADE%TYPE;
  vQB_GRADE          VRTN_SUM11_MM_MATGP.QB_GRADE%TYPE;
  vQC_GRADE          VRTN_SUM11_MM_MATGP.QC_GRADE%TYPE;
  vQD_GRADE          VRTN_SUM11_MM_MATGP.QD_GRADE%TYPE;
  vSUBTOT_Q          VRTN_SUM11_MM_MATGP.SUBTOT_Q%TYPE;
  vCA_GRADE          VRTN_SUM11_MM_MATGP.CA_GRADE%TYPE;
  vCB_GRADE          VRTN_SUM11_MM_MATGP.CB_GRADE%TYPE;
  vCC_GRADE          VRTN_SUM11_MM_MATGP.CC_GRADE%TYPE;
  vCD_GRADE          VRTN_SUM11_MM_MATGP.CD_GRADE%TYPE;
  vSUBTOT_C          VRTN_SUM11_MM_MATGP.SUBTOT_C%TYPE;
  vD1_GRADE          VRTN_SUM11_MM_MATGP.D1_GRADE%TYPE;
  vD2_GRADE          VRTN_SUM11_MM_MATGP.D2_GRADE%TYPE;
  vDE_GRADE          VRTN_SUM11_MM_MATGP.DE_GRADE%TYPE;
  vDF_GRADE          VRTN_SUM11_MM_MATGP.DF_GRADE%TYPE;
  vDG_GRADE          VRTN_SUM11_MM_MATGP.DG_GRADE%TYPE;
  vDH_GRADE          VRTN_SUM11_MM_MATGP.DH_GRADE%TYPE;
  vDI_GRADE          VRTN_SUM11_MM_MATGP.DI_GRADE%TYPE;
  vDJ_GRADE          VRTN_SUM11_MM_MATGP.DJ_GRADE%TYPE;
  vSUBTOT_D3         VRTN_SUM11_MM_MATGP.SUBTOT_D3%TYPE;
  vSUBTOT_D          VRTN_SUM11_MM_MATGP.SUBTOT_D%TYPE;
  vMM_SCORE          VRTN_SUM11_MM_MATGP.MM_SCORE%TYPE;
  vTOT_CQD           VRTN_SUM11_MM_MATGP.TOT_CQD%TYPE;
  vTOT_D1_D2_D3      VRTN_SUM11_MM_MATGP.TOT_D1_D2_D3%TYPE;


  iTracePoint                varchar2(100);
  cErrorText                 varchar2(500);

BEGIN
  iTracePoint := '000';
  select * into vYYYY, vMM from (
    select trim(to_char(add_months(SYSDATE,-1), 'YYYY')), trim(to_char(add_months(SYSDATE,-1), 'MM'))
      from dual
  );

 

  iTracePoint := '100';  --刪除 VRTN_SUM17_GV_MM_MATGP
  delete from VRTN_SUM17_GV_MM_MATGP
   where YYYY = vYYYY
     and MM = vMM;
  commit;


  iTracePoint := '110';
  insert into VRTN_SUM17_GV_MM_MATGP (GV_VENDOR, MATGROUP, YYYY, MM, QUARTER, AMOUNT, VENDOR, SITE, DATE_TIME
                                      )
--                                     ,QB_GRADE, QC_GRADE, QD_GRADE, CA_GRADE, CB_GRADE )
     select GV_VENDOR, MATGROUP, YYYY, MM, QUARTER, AMOUNT, VENDOR, SITE, to_char(SYSDATE, 'yyyymmddhh24miss') as DATE_TIME
--            ,100, 100, 70, 60, 60
       from VRTN_SUM07_AMT_GV_MATGP_M a
       where YYYY = vYYYY
         and MM = vMM;
  commit;

  iTracePoint := '120'; --MATGROUP, GV_VENDOR
  for REC1 in (
     select distinct MATGROUP, GV_VENDOR from VRTN_SUM17_GV_MM_MATGP c
      where YYYY = vYYYY and MM = vMM
  ) loop
     select * into vQA_GRADE, vQB_GRADE, vQC_GRADE, vQD_GRADE, vSUBTOT_Q, vCA_GRADE, vCB_GRADE, vCC_GRADE, vCD_GRADE, vSUBTOT_C, vD1_GRADE, vD2_GRADE, vDE_GRADE, vDF_GRADE, vDG_GRADE, vDH_GRADE, vDI_GRADE, vDJ_GRADE,
                   vTOT_CQD, vSUBTOT_D3, vTOT_D1_D2_D3, vSUBTOT_D, vMM_SCORE
                   from (
                 select round(sum(QA_GRADE * GV_PER),5) AS vQA_GRADE,
                        round(sum(QB_GRADE * GV_PER),5) AS vQB_GRADE,
                        round(sum(QC_GRADE * GV_PER),5) AS vQC_GRADE,
                        round(sum(QD_GRADE * GV_PER),5) AS vQD_GRADE,
                        round(sum(SUBTOT_Q * GV_PER),5) AS vSUBTOT_Q,
                        round(sum(CA_GRADE * GV_PER),5) AS vCA_GRADE,
                        round(sum(CB_GRADE * GV_PER),5) AS vCB_GRADE,
                        round(sum(CC_GRADE * GV_PER),5) AS vCC_GRADE,
                        round(sum(CD_GRADE * GV_PER),5) AS vCD_GRADE,
                        round(sum(SUBTOT_C * GV_PER),5) AS vSUBTOT_C,
                        round(sum(D1_GRADE * GV_PER),5) AS vD1_GRADE,
                        round(sum(D2_GRADE * GV_PER),5) AS vD2_GRADE,
                        round(sum(DE_GRADE * GV_PER),5) AS vDE_GRADE,
                        round(sum(DF_GRADE * GV_PER),5) AS vDF_GRADE,
                        round(sum(DG_GRADE * GV_PER),5) AS vDG_GRADE,
                        round(sum(DH_GRADE * GV_PER),5) AS vDH_GRADE,
                        round(sum(DI_GRADE * GV_PER),5) AS vDI_GRADE,
                        round(sum(DJ_GRADE * GV_PER),5) AS vDJ_GRADE,
                        round(sum(TOT_CQD * GV_PER),5) AS vTOT_CQD,
                        round(sum(SUBTOT_D3 * GV_PER),5) AS vSUBTOT_D3,
                        round(sum(TOT_D1_D2_D3 * GV_PER),5) AS vTOT_D1_D2_D3,
                        round(sum(SUBTOT_D * GV_PER),5) AS vSUBTOT_D,
                        round(sum(MM_SCORE * GV_PER),5) AS vMM_SCORE
         from VRTN_SUM01_AMT_MATGP_M a, VRTN_SUM11_MM_MATGP b
              where a.YYYY = vYYYY
                and a.MM = vMM
                and a.MATGROUP = REC1.MATGROUP
                and a.GV_VENDOR = REC1.GV_VENDOR
                and a.YYYY = b.YYYY
                and a.MM  = b.mm
                and a.SITE = b.SITE
                and a.VENDOR = b.VENDOR
                and a.MATGROUP = b.MATGROUP
         );

          --PROCESS SCORE
                 if vQA_GRADE > '100' then
            vQA_GRADE := '100';
         end if;
                 if vQB_GRADE > '100' then
            vQB_GRADE := '100';
         end if;
                 if vQC_GRADE > '100' then
            vQC_GRADE := '100';
         end if;
                 if vQD_GRADE > '100' then
            vQD_GRADE := '100';
         end if;
                 if vSUBTOT_Q > '100' then
            vSUBTOT_Q := '100';
         end if;
                 if vCA_GRADE > '100' then
            vCA_GRADE := '100';
         end if;
                 if vCB_GRADE > '100' then
            vCB_GRADE := '100';
         end if;
                 if vCC_GRADE > '100' then
            vCC_GRADE := '100';
         end if;
                 if vCD_GRADE > '100' then
            vCD_GRADE := '100';
         end if;
                 if vSUBTOT_C > '100' then
            vSUBTOT_C := '100';
         end if;
                 if vD1_GRADE > '100' then
            vD1_GRADE := '100';
         end if;
                 if vD2_GRADE > '100' then
            vD2_GRADE := '100';
         end if;
                 if vDE_GRADE > '100' then
            vDE_GRADE := '100';
         end if;
                 if vDF_GRADE > '100' then
            vDF_GRADE := '100';
         end if;
                 if vDG_GRADE > '100' then
            vDG_GRADE := '100';
         end if;
                 if vDH_GRADE > '100' then
            vDH_GRADE := '100';
         end if;
                 if vDI_GRADE > '100' then
            vDI_GRADE := '100';
         end if;
                 if vDJ_GRADE > '100' then
            vDJ_GRADE := '100';
         end if;
         if vTOT_CQD > '100' then
            vTOT_CQD := '100';
         end if;
                 if vSUBTOT_D3 > '100' then
            vSUBTOT_D3 := '100';
         end if;
                 if vTOT_D1_D2_D3 > '100' then
            vTOT_D1_D2_D3 := '100';
         end if;
         if vSUBTOT_D > '100' then
            vSUBTOT_D := '100';
         end if;
                 if vMM_SCORE > '100' then
            vMM_SCORE := '100';
         end if;


         UPDate VRTN_SUM17_GV_MM_MATGP
                            set QA_GRADE = vQA_GRADE,
                                QB_GRADE = vQB_GRADE,
                                QC_GRADE = vQC_GRADE,
                                QD_GRADE = vQD_GRADE,
                                SUBTOT_Q = vSUBTOT_Q,
                                CA_GRADE = vCA_GRADE,
                                CB_GRADE = vCB_GRADE,
                                CC_GRADE = vCC_GRADE,
                                CD_GRADE = vCD_GRADE,
                                SUBTOT_C = vSUBTOT_C,
                                D1_GRADE = vD1_GRADE,
                                D2_GRADE = vD2_GRADE,
                                DE_GRADE = vDE_GRADE,
                                DF_GRADE = vDF_GRADE,
                                DG_GRADE = vDG_GRADE,
                                DH_GRADE = vDH_GRADE,
                                DI_GRADE = vDI_GRADE,
                                DJ_GRADE = vDJ_GRADE,
                                TOT_CQD  = vTOT_CQD,
                                SUBTOT_D3 = vSUBTOT_D3,
                                TOT_D1_D2_D3 = vTOT_D1_D2_D3,
                                SUBTOT_D = vSUBTOT_D,
                                MM_SCORE = vMM_SCORE

        where YYYY = vYYYY
          and MM = vMM
          and MATGROUP = REC1.MATGROUP
          and GV_VENDOR = REC1.GV_VENDOR;
       commit;

  end loop;

  -- Susan 2010/09/14
  iTracePoint := '130';
  for REC1 in (
     select a.GV_VENDOR, a.YYYY, a.MM, a.MATGROUP,
      ( select b.GVC_TRACK from GVM031_GLOBAL_VENDOR b where b.GLOBAL_VENDOR_CODE = a.GV_VENDOR) as GVC_TRACK     
      from VRTN_SUM17_GV_MM_MATGP a
      where YYYY = vYYYY
        and MM = vMM      
      group by a.GV_VENDOR, a.YYYY, a.MM, a.MATGROUP
  ) loop
     Update VRTN_SUM17_GV_MM_MATGP
        set GVC_TRACK = REC1.GVC_TRACK
      where GV_VENDOR = REC1.GV_VENDOR
        and MATGROUP = REC1.MATGROUP
        and YYYY = vYYYY
        and MM = vMM;
     commit;
  end loop;  
  

-- Gobal by VENDOR
  iTracePoint := '200';  --刪除  VRTN_SUM18_GV_MM_VM
  delete from  VRTN_SUM18_GV_MM_VM
   where YYYY = vYYYY
     and MM = vMM;
  commit;

  iTracePoint := '210';
  insert into VRTN_SUM18_GV_MM_VM (GV_VENDOR, YYYY, MM, QUARTER, AMOUNT, VENDOR, SITE, DATE_TIME
                                      )
     select GV_VENDOR, YYYY, MM, QUARTER, AMOUNT, VENDOR, SITE, to_char(SYSDATE, 'yyyymmddhh24miss') as DATE_TIME
       from VRTN_SUM08_AMT_GV_VM_M  a
       where YYYY = vYYYY
         and MM = vMM;
  commit;


  iTracePoint := '220'; --GV_VENDOR
  for REC1 in (
     select distinct GV_VENDOR from VRTN_SUM18_GV_MM_VM c
      where YYYY = vYYYY and MM = vMM
  ) loop
     select * into vQA_GRADE, vQB_GRADE, vQC_GRADE, vQD_GRADE, vSUBTOT_Q, vCA_GRADE, vCB_GRADE, vCC_GRADE, vCD_GRADE, vSUBTOT_C, vD1_GRADE, vD2_GRADE, vDE_GRADE, vDF_GRADE, vDG_GRADE, vDH_GRADE, vDI_GRADE, vDJ_GRADE,
                   vTOT_CQD, vSUBTOT_D3, vTOT_D1_D2_D3, vSUBTOT_D, vMM_SCORE
                   from (
                 select round(sum(QA_GRADE * GV_PER),5) AS vQA_GRADE,
                        round(sum(QB_GRADE * GV_PER),5) AS vQB_GRADE,
                        round(sum(QC_GRADE * GV_PER),5) AS vQC_GRADE,
                        round(sum(QD_GRADE * GV_PER),5) AS vQD_GRADE,
                        round(sum(SUBTOT_Q * GV_PER),5) AS vSUBTOT_Q,
                        round(sum(CA_GRADE * GV_PER),5) AS vCA_GRADE,
                        round(sum(CB_GRADE * GV_PER),5) AS vCB_GRADE,
                        round(sum(CC_GRADE * GV_PER),5) AS vCC_GRADE,
                        round(sum(CD_GRADE * GV_PER),5) AS vCD_GRADE,
                        round(sum(SUBTOT_C * GV_PER),5) AS vSUBTOT_C,
                        round(sum(D1_GRADE * GV_PER),5) AS vD1_GRADE,
                        round(sum(D2_GRADE * GV_PER),5) AS vD2_GRADE,
                        round(sum(DE_GRADE * GV_PER),5) AS vDE_GRADE,
                        round(sum(DF_GRADE * GV_PER),5) AS vDF_GRADE,
                        round(sum(DG_GRADE * GV_PER),5) AS vDG_GRADE,
                        round(sum(DH_GRADE * GV_PER),5) AS vDH_GRADE,
                        round(sum(DI_GRADE * GV_PER),5) AS vDI_GRADE,
                        round(sum(DJ_GRADE * GV_PER),5) AS vDJ_GRADE,
                        round(sum(TOT_CQD * GV_PER),5) AS vTOT_CQD,
                        round(sum(SUBTOT_D3 * GV_PER),5) AS vSUBTOT_D3,
                        round(sum(TOT_D1_D2_D3 * GV_PER),5) AS vTOT_D1_D2_D3,
                        round(sum(SUBTOT_D * GV_PER),5) AS vSUBTOT_D,
                        round(sum(MM_SCORE * GV_PER),5) AS vMM_SCORE
         from VRTN_SUM02_AMT_VM_M a, VRTN_SUM12_MM_VM b
              where a.YYYY = vYYYY
                and a.MM = vMM
                and a.GV_VENDOR = REC1.GV_VENDOR
                and a.YYYY = b.YYYY
                and a.MM  = b.mm
                and a.SITE = b.SITE
                and a.VENDOR = b.VENDOR
         );

          --PROCESS SCORE
                 if vQA_GRADE > '100' then
            vQA_GRADE := '100';
         end if;
                 if vQB_GRADE > '100' then
            vQB_GRADE := '100';
         end if;
                 if vQC_GRADE > '100' then
            vQC_GRADE := '100';
         end if;
                 if vQD_GRADE > '100' then
            vQD_GRADE := '100';
         end if;
                 if vSUBTOT_Q > '100' then
            vSUBTOT_Q := '100';
         end if;
                 if vCA_GRADE > '100' then
            vCA_GRADE := '100';
         end if;
                 if vCB_GRADE > '100' then
            vCB_GRADE := '100';
         end if;
                 if vCC_GRADE > '100' then
            vCC_GRADE := '100';
         end if;
                 if vCD_GRADE > '100' then
            vCD_GRADE := '100';
         end if;
                 if vSUBTOT_C > '100' then
            vSUBTOT_C := '100';
         end if;
                 if vD1_GRADE > '100' then
            vD1_GRADE := '100';
         end if;
                 if vD2_GRADE > '100' then
            vD2_GRADE := '100';
         end if;
                 if vDE_GRADE > '100' then
            vDE_GRADE := '100';
         end if;
                 if vDF_GRADE > '100' then
            vDF_GRADE := '100';
         end if;
                 if vDG_GRADE > '100' then
            vDG_GRADE := '100';
         end if;
                 if vDH_GRADE > '100' then
            vDH_GRADE := '100';
         end if;
                 if vDI_GRADE > '100' then
            vDI_GRADE := '100';
         end if;
                 if vDJ_GRADE > '100' then
            vDJ_GRADE := '100';
         end if;
         if vTOT_CQD > '100' then
            vTOT_CQD := '100';
         end if;
                 if vSUBTOT_D3 > '100' then
            vSUBTOT_D3 := '100';
         end if;
                 if vTOT_D1_D2_D3 > '100' then
            vTOT_D1_D2_D3 := '100';
         end if;
         if vSUBTOT_D > '100' then
            vSUBTOT_D := '100';
         end if;
                 if vMM_SCORE > '100' then
            vMM_SCORE := '100';
         end if;


         UPDate VRTN_SUM18_GV_MM_VM
                            set QA_GRADE = vQA_GRADE,
                                QB_GRADE = vQB_GRADE,
                                QC_GRADE = vQC_GRADE,
                                QD_GRADE = vQD_GRADE,
                                SUBTOT_Q = vSUBTOT_Q,
                                CA_GRADE = vCA_GRADE,
                                CB_GRADE = vCB_GRADE,
                                CC_GRADE = vCC_GRADE,
                                CD_GRADE = vCD_GRADE,
                                SUBTOT_C = vSUBTOT_C,
                                D1_GRADE = vD1_GRADE,
                                D2_GRADE = vD2_GRADE,
                                DE_GRADE = vDE_GRADE,
                                DF_GRADE = vDF_GRADE,
                                DG_GRADE = vDG_GRADE,
                                DH_GRADE = vDH_GRADE,
                                DI_GRADE = vDI_GRADE,
                                DJ_GRADE = vDJ_GRADE,
                                TOT_CQD  = vTOT_CQD,
                                SUBTOT_D3 = vSUBTOT_D3,
                                TOT_D1_D2_D3 = vTOT_D1_D2_D3,
                                SUBTOT_D = vSUBTOT_D,
                                MM_SCORE = vMM_SCORE

        where YYYY = vYYYY
          and MM = vMM
          and GV_VENDOR = REC1.GV_VENDOR;
       commit;

  end loop;

   -- Susan 2010/09/14
  iTracePoint := '230';
  for REC1 in (
     select a.GV_VENDOR, a.YYYY, a.MM, 
      ( select b.GVC_TRACK from GVM031_GLOBAL_VENDOR b where b.GLOBAL_VENDOR_CODE = a.GV_VENDOR) as GVC_TRACK     
      from VRTN_SUM18_GV_MM_VM a
      where YYYY = vYYYY
        and MM = vMM      
      group by a.GV_VENDOR, a.YYYY, a.MM
  ) loop
     Update VRTN_SUM18_GV_MM_VM
        set GVC_TRACK = REC1.GVC_TRACK
      where GV_VENDOR = REC1.GV_VENDOR
        and YYYY = vYYYY
        and MM = vMM;
     commit;
  end loop;  
  



  iTracePoint := '400';  --刪除 VRTN_SUM19_GV_MM_COMBINE
  delete from VRTN_SUM19_GV_MM_COMBINE
   where YYYY = vYYYY
     and MM = vMM;
  commit;

  iTracePoint := '410';
  insert into VRTN_SUM19_GV_MM_COMBINE (GV_VENDOR, MATGROUP, YYYY, MM, QUARTER, AMOUNT,
                                      QA_GRADE, QB_GRADE, QC_GRADE, QD_GRADE, SUBTOT_Q, CA_GRADE, CB_GRADE, CC_GRADE,
                                      CD_GRADE, SUBTOT_C, D1_GRADE, D2_GRADE, DE_GRADE, DF_GRADE, DG_GRADE, DH_GRADE,
                                      DI_GRADE, DJ_GRADE, TOT_CQD, SUBTOT_D3, TOT_D1_D2_D3, SUBTOT_D, MM_SCORE,
                                                          SITE, VENDOR, DATE_TIME, GVC_TRACK )
    select GV_VENDOR, MATGROUP, YYYY, MM, QUARTER, AMOUNT,
           QA_GRADE, QB_GRADE, QC_GRADE, QD_GRADE, SUBTOT_Q, CA_GRADE, CB_GRADE, CC_GRADE,
           CD_GRADE, SUBTOT_C, D1_GRADE, D2_GRADE, DE_GRADE, DF_GRADE, DG_GRADE, DH_GRADE,
           DI_GRADE, DJ_GRADE, TOT_CQD, SUBTOT_D3, TOT_D1_D2_D3, SUBTOT_D, MM_SCORE, SITE, VENDOR, DATE_TIME, GVC_TRACK
      from  VRTN_SUM17_GV_MM_MATGP
     where YYYY = vYYYY and MM = vMM
    union all
    select GV_VENDOR, '000', YYYY, MM, QUARTER, AMOUNT,
           QA_GRADE, QB_GRADE, QC_GRADE, QD_GRADE, SUBTOT_Q, CA_GRADE, CB_GRADE, CC_GRADE,
           CD_GRADE, SUBTOT_C, D1_GRADE, D2_GRADE, DE_GRADE, DF_GRADE, DG_GRADE, DH_GRADE,
           DI_GRADE, DJ_GRADE, TOT_CQD, SUBTOT_D3, TOT_D1_D2_D3, SUBTOT_D, MM_SCORE, SITE, VENDOR, DATE_TIME, GVC_TRACK
      from VRTN_SUM18_GV_MM_VM
     where YYYY = vYYYY and MM = vMM;
  commit;



EXCEPTION
  When OTHERS Then
    --有錯誤產生則寄mail
    cErrorText := SQLERRM();
    MAIL_FILE_BIDBDBADMIN(in_to_name => 'shuchin_lin@usiglobal.com', subject => '[VRTN] PL/SQL VRTN_PLSQL_SUM7_LOC_MM ERROR', message => '[VRTN_PLSQL_SUM7_LOC_MM"], The tracepoint is  ' || iTracePoint || ' and ErrorText= ' || cErrorText) ;
END VRTN_PLSQL_SUM7_GV_MM;
/

