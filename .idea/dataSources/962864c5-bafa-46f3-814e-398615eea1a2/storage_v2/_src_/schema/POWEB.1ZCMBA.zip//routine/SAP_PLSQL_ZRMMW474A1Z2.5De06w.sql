create PROCEDURE         "SAP_PLSQL_ZRMMW474A1Z2" (
  inCompany  in VARCHAR2,
  f_YYYYMMDD in VARCHAR2,
  t_YYYYMMDD in VARCHAR2
)
AUTHID DEFINER
is
	t_YYYYTT            SAP_ZRMMW474A1_PO_W_T.YYYYTT%TYPE;
	cTracePoint         varchar2(3);
	cErrorText          varchar2(500) ;
BEGIN
	--抓最大的 YYYYTT
	cTracePoint := '100';
	select max(YYYYTT) into t_YYYYTT from SAP_ZRMMW474A1_PO_W_T
		where COMPANY_CODE = inCompany;

	-- 清舊有資料 SAP_ZRMMW474A1_PO_W
	cTracePoint := '200';
	delete from SAP_ZRMMW474A1_PO_W
		where COMPANY_CODE = inCompany and YYYYTT = t_YYYYTT;
	commit;

	--寫入資料到 SAP_ZRMMW474A1_PO_W
	cTracePoint := '300';
	insert into SAP_ZRMMW474A1_PO_W
		select * from SAP_ZRMMW474A1_PO_W_T
		where COMPANY_CODE = inCompany and YYYYTT = t_YYYYTT;
	commit;

	-- 清過久資料 SAP_ZRMMW474A1_PO_W_BAK
	cTracePoint := '410';
	delete from SAP_ZRMMW474A1_PO_W_BAK
		where COMPANY_CODE = inCompany
		and YYYYTT <= to_char(sysdate - 130,'yyyyww');
	commit;

	--將 35 天前資料搬到 SAP_ZRMMW474A1_PO_W_BAK
	cTracePoint := '420';
	insert into SAP_ZRMMW474A1_PO_W_BAK
		select * from SAP_ZRMMW474A1_PO_W
		where COMPANY_CODE = inCompany
		and YYYYTT <= to_char(sysdate - 35,'yyyyww');
	commit;

	--清除 SAP_ZRMMW474A1_PO_W 的 35 天前資料
	cTracePoint := '430';
	delete from SAP_ZRMMW474A1_PO_W
		where COMPANY_CODE = inCompany
		and YYYYTT <= to_char(sysdate - 35,'yyyyww');
	commit;

	--update FLAG1 (Y: Calculating date / N: TW spec. plant & SZ *-C)
	if inCompany = '1100' then
		--"TW + Profit center 23 + PN 開頭 58 + PN desc含PCBA" 同時成立時, 此筆 PO 搬到 "TW spec. plant & SZ *-C"
		cTracePoint := '510';
		update SAP_ZRMMW474A1_PO_W set FLAG1 = 'N'
		where COMPANY_CODE = inCompany
		and WERKS <= '1140'
		and FLAG1 is null
		and MATNR like '58%'
		and PRCTR = '0000000023'
		and upper(MAKTX) like '%PCBA%';
		commit;
		cTracePoint := '512';
		update SAP_ZRMMW474A1_PO_W
			set FLAG1 = 'Y'
		where COMPANY_CODE = inCompany
		and WERKS in ('1110','1120','1130','1140')
		and FLAG1 is null;
	elsif inCompany = '1700' then
		--"TW17 + Profit center 23 + PN 開頭 58 + PN desc含PCBA" 同時成立時, 此筆 PO 搬到 "TW spec. plant & SZ *-C"
		-- 若非 Plant 1710 亦 搬到 "TW spec. plant & SZ *-C"
		cTracePoint := '510';
		update SAP_ZRMMW474A1_PO_W set FLAG1 = 'N'
		where COMPANY_CODE = inCompany
		and WERKS = '1710'
		and FLAG1 is null
		and MATNR like '58%'
		and PRCTR = '0000000023'
		and upper(MAKTX) like '%PCBA%';
		commit;
		cTracePoint := '512';
		update SAP_ZRMMW474A1_PO_W
			set FLAG1 = 'Y'
		where COMPANY_CODE = inCompany
		and WERKS = '1710'
		and FLAG1 is null;
	elsif inCompany = '1200' or inCompany = '1400' then
		cTracePoint := '520';
		update SAP_ZRMMW474A1_PO_W
			set FLAG1 = 'Y'
		where COMPANY_CODE = inCompany
		and MATNR not like '%-C'
		and FLAG1 is null;
	else
		cTracePoint := '530';
		update SAP_ZRMMW474A1_PO_W
			set FLAG1 = 'Y'
		where COMPANY_CODE = inCompany
		and FLAG1 is null;
	end if;
	commit;
	cTracePoint := '540';
	update SAP_ZRMMW474A1_PO_W
		set FLAG1 = 'N'
	where COMPANY_CODE = inCompany
	and FLAG1 is null;
	commit;

	/*
	cTracePoint := '600';
	DBMS_STATS.GATHER_TABLE_STATS
	(
		ownname => 'POWEB',
		tabname => 'SAP_ZRMMW474A1_PO_W',
		estimate_percent => DBMS_STATS.AUTO_SAMPLE_SIZE,
		cascade => true,
		method_opt => 'for all indexed columns size 10'  -- 最高到254，愈高，取樣愈準，但也花愈多時間
    );
	commit;
	*/
EXCEPTION
  WHEN OTHERS THEN
    cErrorText := trim(cTracePoint) || '>' || SQLERRM() ;
    MAIL_FILE_BIDBDBADMIN(in_to_name=>'shuchin_lin@usiglobal.com',subject   => '[BI]PL/SQL SAP_PLSQL_ZRMMW474A1 ERROR - Company: ' || inCompany, message => '[SAP_PLSQL_ZRMMW474A1], ErrorText=' || cErrorText) ;
END SAP_PLSQL_ZRMMW474A1Z2;
/

