create PROCEDURE "PLSQL_MAC_FG_COST_LIST" (
  nCOMPANY_CODE in MAC_FG_COST_LIST.COMPANY_CODE%TYPE,
  f_YYYYMMDD    in VARCHAR2,
  t_YYYYMMDD    in VARCHAR2
)
/*********************************************************************
  PROG-ID      : PLSQL_MAC_FG_COST_LIST
  PROG-ACTION  : 匯集 FG Bom cost 到 table MAC_FG_COST_LIST
  Author       : Minhorng
  Date         : 2008/02/14
**********************************************************************/
is
	iTracePoint           integer ;
	cErrorText            varchar2(500) ;
	cCHK1                 varchar2(100) ;
	cCHK2                 varchar2(100) ;
	tPERIOD_C             MAC_FG_COST_LIST.PERIOD%TYPE;
	tPERIOD_P             MAC_FG_COST_LIST.PERIOD%TYPE;
	--usd
	tCOST_MAC             MAC_FG_COST_LIST.COST_MAC%TYPE;
	tINFOREC_MAC          MAC_FG_COST_LIST.INFOREC_MAC%TYPE;
	tCOST_MAC_P           MAC_FG_COST_LIST.COST_MAC_P%TYPE;
	tINFOREC_MAC_P        MAC_FG_COST_LIST.INFOREC_MAC_P%TYPE;
	--loc
	tCOST_MAC_LOC         MAC_FG_COST_LIST.COST_MAC_LOC%TYPE;
	tINFOREC_MAC_LOC      MAC_FG_COST_LIST.INFOREC_MAC_LOC%TYPE;
	tCOST_MAC_LOC_P       MAC_FG_COST_LIST.COST_MAC_LOC_P%TYPE;
	tINFOREC_MAC_LOC_P    MAC_FG_COST_LIST.INFOREC_MAC_LOC_P%TYPE;

BEGIN
	--抓 PERIOD
	cErrorText := ' ';
	iTracePoint := 50;
	cCHK1 := ' ';
	cCHK2 := ' ';
	select * into tPERIOD_C from (
		select to_char(to_date(f_YYYYMMDD,'yyyymmdd'),'iyyyiw') from dual
	) where rownum <= 1;

	iTracePoint := 100;
	select * into tPERIOD_P from (
		select to_char(to_date(f_YYYYMMDD,'yyyymmdd') - 7,'iyyyiw') from dual
	) where rownum <= 1;


	--清舊的或非實際值
	iTracePoint := 150;
	delete from MAC_FG_COST_LIST where COMPANY_CODE = nCOMPANY_CODE and PERIOD = tPERIOD_C;
	delete from MAC_FG_COST_LIST where COMPANY_CODE = nCOMPANY_CODE and PERIOD <> YYYYWW;
	commit;


	--處理 MAC_PART_LIST  (以後預估週次須與當週比)
	iTracePoint := 200;
	cCHK1 := ' ';
	cCHK2 := ' ';
	for REC1 in (
		select * from MAC_PART_LIST where COMPANY_CODE = nCOMPANY_CODE and PERIOD = tPERIOD_C
		order by PERIOD, COMPANY_CODE, ISSUE_PLANT, COMPONENT, YYYYWW
	) loop
		cCHK2 := trim(REC1.PERIOD) || trim(REC1.COMPANY_CODE) || trim(REC1.ISSUE_PLANT) || trim(REC1.COMPONENT);
		if cCHK1 <> cCHK2 then
			if REC1.PERIOD = REC1.YYYYWW then
				--當週值, 做為以後預估週次的比對基準
				tCOST_MAC := REC1.MAC_USD;
				tINFOREC_MAC := REC1.INFOREC_USD;
				tCOST_MAC_LOC := REC1.MAC_LOC;
				tINFOREC_MAC_LOC := REC1.INFOREC_LOC;
				cCHK1 := cCHK2;
			end if;
		end if;
		if cCHK1 = cCHK2 then
			--update table
			update MAC_PART_LIST set
				MAC_LOC_P = tCOST_MAC_LOC,
				INFOREC_LOC_P = tINFOREC_MAC_LOC,
				MAC_USD_P = tCOST_MAC,
				INFOREC_USD_P = tINFOREC_MAC
			where PERIOD = REC1.PERIOD
			and COMPANY_CODE = REC1.COMPANY_CODE
			and ISSUE_PLANT = REC1.ISSUE_PLANT
			and COMPONENT = REC1.COMPONENT
			and YYYYWW = REC1.YYYYWW;
			commit;
		end if;
	end loop;


	--處理 MAC_INFOREC_LIST  (以後預估週次須與當週比)
	iTracePoint := 300;
	cCHK1 := ' ';
	cCHK2 := ' ';
	for REC1 in (
		select * from MAC_INFOREC_LIST where COMPANY_CODE = nCOMPANY_CODE and PERIOD = tPERIOD_C
		order by PERIOD, COMPANY_CODE, PLANT, COMPONENT, MPN, VENDOR_CODE, YYYYWW
	) loop
		cCHK2 := trim(REC1.PERIOD) || trim(REC1.COMPANY_CODE) || trim(REC1.PLANT) || trim(REC1.COMPONENT) || trim(REC1.MPN) || trim(REC1.VENDOR_CODE);
		if cCHK1 <> cCHK2 then
			if REC1.PERIOD = REC1.YYYYWW then
				--當週值, 做為以後預估週次的比對基準
				tINFOREC_MAC := REC1.INFOREC_USD;
				tINFOREC_MAC_LOC := REC1.INFOREC_LOC;
				cCHK1 := cCHK2;
			end if;
		end if;
		--update table
		if cCHK1 = cCHK2 then
			update MAC_INFOREC_LIST set
				INFOREC_LOC_P = tINFOREC_MAC_LOC,
				INFOREC_USD_P = tINFOREC_MAC
			where PERIOD = REC1.PERIOD
			and COMPANY_CODE = REC1.COMPANY_CODE
			and PLANT = REC1.PLANT
			and COMPONENT = REC1.COMPONENT
			and MPN = REC1.MPN
			and VENDOR_CODE = REC1.VENDOR_CODE
			and YYYYWW = REC1.YYYYWW;
		commit;
		end if;
	end loop;


	--清 MAC_BOMCOST_RPT 本週避免重複
	iTracePoint := 400;
	cCHK1 := ' ';
	cCHK2 := ' ';
	delete from MAC_BOMCOST_RPT where COMPANY_CODE = nCOMPANY_CODE and PERIOD = tPERIOD_C;
	commit;

	--insert  MAC_BOMCOST_RPT
	iTracePoint := 450;
	insert into MAC_BOMCOST_RPT
		SELECT AL1.PERIOD, AL1.YW_DATE, AL1.COMPANY_CODE, AL1.PLANT, AL1.FG, AL1.SN, AL1.LV, AL1.SFG, AL1.ALT_GRP,
			decode(AL1.ALT_GRP, null, 100, nvl(AL1.BOM_USAGE,0)) as BOM_USAGE, AL1.ITEM_NO, AL1.COMPONENT,
			AL1.ISSUE_PLANT, AL1.MTL_GRP, AL1.REQD_QTY, AL1.ROW_LV,
			decode(AL3.PART_TYPE, null, 'Y', decode(AL3.PART_TYPE,'TP','Y','N')) as USI_CONT, AL4.MPN, AL4.VENDOR_CODE,
			AL4.QTA, AL2.MAC_LOC, AL2.MAC_USD, AL2.MAC_LOC_P, AL2.MAC_USD_P,
			AL4.INFOREC_LOC, AL4.INFOREC_USD, AL4.INFOREC_LOC_P, AL4.INFOREC_USD_P, AL2.INFOREC_USED,
			nvl(AL2.YYYYWW, AL1.PERIOD) as YYYYWW
		FROM POWEB.MAC_BOM_LIST AL1, POWEB.MAC_PART_LIST AL2, POWEB.RFQ_LOA_PART AL3, POWEB.MAC_INFOREC_LIST AL4
		WHERE AL1.PERIOD = AL2.PERIOD (+) AND AL1.COMPANY_CODE = AL2.COMPANY_CODE (+)
		AND AL1.ISSUE_PLANT = AL2.ISSUE_PLANT (+) AND AL1.COMPONENT = AL2.COMPONENT (+)
		AND AL2.PERIOD = AL4.PERIOD (+) AND AL2.COMPANY_CODE = AL4.COMPANY_CODE (+)
		AND AL2.ISSUE_PLANT = AL4.PLANT (+) AND AL2.COMPONENT = AL4.COMPONENT (+)
		AND AL2.YYYYWW = AL4.YYYYWW (+) AND AL2.COMPONENT = AL3.PART_NO (+)
		AND AL1.COMPANY_CODE = nCOMPANY_CODE and AL1.PERIOD = tPERIOD_C;
	commit;


	--處理本週資料 (當週須比上週資料; 而以後預估週次須與當週比)
	iTracePoint := 800;
	cCHK1 := ' ';
	cCHK2 := ' ';
	for REC1 in (
		select PERIOD, COMPANY_CODE, PLANT, FG, USI_CONT, YYYYWW, YW_DATE,
			nvl(sum(round(BOM_USAGE * QTA * MAC_USD * REQD_QTY / 10000,6)),0) as COST_MAC,
			nvl(sum(round(BOM_USAGE * QTA * INFOREC_USD * REQD_QTY / 10000,6)),0) as INFOREC_MAC,
			nvl(sum(round(BOM_USAGE * QTA * MAC_LOC * REQD_QTY / 10000,6)),0) as COST_MAC_LOC,
			nvl(sum(round(BOM_USAGE * QTA * INFOREC_LOC * REQD_QTY / 10000,6)),0) as INFOREC_MAC_LOC
		from (
			select AL1.PERIOD, AL1.COMPANY_CODE, AL1.PLANT, AL1.FG, decode(AL1.ALT_GRP, null, 100, AL1.BOM_USAGE) as BOM_USAGE,
				round(AL1.REQD_QTY / 10000,6) as REQD_QTY, nvl(AL2.YYYYWW, AL1.PERIOD) as YYYYWW, AL1.YW_DATE,
				decode(AL3.PART_TYPE, null, 'Y', decode(AL3.PART_TYPE,'TP','Y','N')) as USI_CONT,
				AL4.QTA, AL2.MAC_USD, AL2.INFOREC_USD, AL2.MAC_LOC, AL2.INFOREC_LOC
				from POWEB.MAC_BOM_LIST AL1, POWEB.MAC_PART_LIST AL2, POWEB.RFQ_LOA_PART AL3, POWEB.MAC_INFOREC_LIST AL4
				where AL1.PERIOD = AL2.PERIOD (+) and AL1.COMPANY_CODE = AL2.COMPANY_CODE (+)
				and AL1.ISSUE_PLANT = AL2.ISSUE_PLANT (+) and AL1.COMPONENT = AL2.COMPONENT (+)
				and AL2.PERIOD = AL4.PERIOD (+) and AL2.COMPANY_CODE = AL4.COMPANY_CODE (+)
				and AL2.ISSUE_PLANT = AL4.PLANT (+) and AL2.COMPONENT = AL4.COMPONENT (+)
				and AL2.YYYYWW = AL4.YYYYWW (+) and AL2.COMPONENT = AL3.PART_NO (+)
				and AL1.COMPANY_CODE = nCOMPANY_CODE and AL1.PERIOD = tPERIOD_C
		)
		group by PERIOD, COMPANY_CODE, PLANT, FG, USI_CONT, YYYYWW, YW_DATE
		order by PERIOD, COMPANY_CODE, PLANT, FG, USI_CONT, YYYYWW
	) loop
		cCHK2 := trim(REC1.PERIOD) || trim(REC1.COMPANY_CODE) || trim(REC1.PLANT) || trim(REC1.FG) || trim(REC1.USI_CONT);
		if REC1.PERIOD = REC1.YYYYWW then
			--當週值, 做為以後預估週次的比對基準
			tCOST_MAC := REC1.COST_MAC;
			tINFOREC_MAC := REC1.INFOREC_MAC;
			tCOST_MAC_LOC := REC1.COST_MAC_LOC;
			tINFOREC_MAC_LOC := REC1.INFOREC_MAC_LOC;
			--抓上週值來當本週的比對基準, 若無資料則放本週
			begin
				select * into tCOST_MAC_P, tINFOREC_MAC_P, tCOST_MAC_LOC_P, tINFOREC_MAC_LOC_P from (
					select COST_MAC_P, INFOREC_MAC_P, COST_MAC_LOC_P, INFOREC_MAC_LOC_P from MAC_FG_COST_LIST
						where COMPANY_CODE = REC1.COMPANY_CODE
						and PLANT = REC1.PLANT
						and FG = REC1.FG
						and USI_CONT = REC1.USI_CONT
						and PERIOD = tPERIOD_P
				) where rownum <= 1;
			exception
				when others then
					tCOST_MAC_P := tCOST_MAC;
					tINFOREC_MAC_P := tINFOREC_MAC;
					tCOST_MAC_LOC_P := tCOST_MAC_LOC;
					tINFOREC_MAC_LOC_P := tINFOREC_MAC_LOC;
			end;
		else
			--用當週值做為以後預估週次的比對基準
			tCOST_MAC_P := tCOST_MAC;
			tINFOREC_MAC_P := tINFOREC_MAC;
			tCOST_MAC_LOC_P := tCOST_MAC_LOC;
			tINFOREC_MAC_LOC_P := tINFOREC_MAC_LOC;
		end if;
		--insert table
		insert into MAC_FG_COST_LIST (
			PERIOD, COMPANY_CODE, PLANT, FG, YYYYWW, COST_MAC, COST_MAC_P, INFOREC_MAC, INFOREC_MAC_P,
			USI_CONT, YW_DATE, COST_MAC_LOC, COST_MAC_LOC_P, INFOREC_MAC_LOC, INFOREC_MAC_LOC_P
		) values (
			REC1.PERIOD, REC1.COMPANY_CODE, REC1.PLANT, REC1.FG, REC1.YYYYWW,
			REC1.COST_MAC,
			tCOST_MAC_P,
			REC1.INFOREC_MAC,
			tINFOREC_MAC_P,
			REC1.USI_CONT,
			REC1.YW_DATE,
			REC1.COST_MAC_LOC,
			tCOST_MAC_LOC_P,
			REC1.INFOREC_MAC_LOC,
			tINFOREC_MAC_LOC_P
		);
		commit;
	end loop;



EXCEPTION
  WHEN OTHERS THEN
    cErrorText := trim(cCHK2) || '>' || SQLERRM() ;
    MAIL_FILE_BIDBDBADMIN(in_to_name=>'minhorng@ms.usi.com.tw',subject   => '[MAC]PL/SQL PLSQL_MAC_FG_COST_LIST ERROR - Company: ' || nCOMPANY_CODE, message => '[PLSQL_MAC_FG_COST_LIST], The tracepoint is  ' || to_char(iTracePoint) || ' and ErrorText=' || cErrorText) ;
End PLSQL_MAC_FG_COST_LIST;
/

