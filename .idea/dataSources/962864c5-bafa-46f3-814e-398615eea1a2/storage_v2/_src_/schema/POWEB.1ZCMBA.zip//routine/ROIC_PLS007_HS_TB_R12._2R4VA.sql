create PROCEDURE       ROIC_PLS007_HS_TB_R12 (
  t_YYYYMMDD in VARCHAR2,
  w_USER     in VARCHAR2
)
AUTHID DEFINER
is
/*********************************************************************
  PROG-ID      : ROIC_PLS007_HS_TB_R12
  PROG-ACTION  : Trial Balance - 投資架構 Roll Up 12 Months
  Author       : Patty
  Date         : 2019/05/16
  OA No.       : SAI097956
  Process      : Excute Procedure ROIC_PLS007_HS_TB_R12_BTO &
                                  ROIC_PLS007_HS_TB_R12_G1_BTO
**********************************************************************/
/*---------------------------------------------------------------------

---------------------------------------------------------------------*/
  sPROC_NAME         ROIC_PST000_LOG.PROC_NAME%TYPE;
  sRUN_SEQ           ROIC_PST000_LOG.RUN_SEQ%TYPE;
  sRUN_DESC          ROIC_PST000_LOG.RUN_DESC%TYPE;
  sPARAMETER_DESC    ROIC_PST000_LOG.PARAMETER_DESC%TYPE;       
  t_PERIOD           ROIC_SAP003_TB_DATA.PERIOD%TYPE;  

             
BEGIN

  t_PERIOD := SUBSTR(t_YYYYMMDD,1,6);

  sPROC_NAME := 'ROIC_PLS007_HS_TB_R12';
  sRUN_SEQ   := '000010';
  sRUN_DESC  := 'Start';
  sPARAMETER_DESC := CONCAT(CONCAT(CONCAT('t_PERIOD=',t_PERIOD),';w_USER='),w_USER);
 
  --Insert Log
  INSERT INTO ROIC_PST000_LOG
      ( PROC_NAME, RUN_SEQ, RUN_DESC, PARAMETER_DESC )
    VALUES
      ( sPROC_NAME, sRUN_SEQ, sRUN_DESC, sPARAMETER_DESC );
  Commit;

  --Exec Store Procedure
  ROIC_PLS007_HS_TB_R12_BTO(t_PERIOD);

  ROIC_PLS007_HS_TB_R12_G1_BTO(t_PERIOD);

  sRUN_SEQ   := '000020';
  sRUN_DESC  := 'End';

  --Insert Log
  INSERT INTO ROIC_PST000_LOG
      ( PROC_NAME, RUN_SEQ, RUN_DESC, PARAMETER_DESC )
    VALUES
      ( sPROC_NAME, sRUN_SEQ, sRUN_DESC, sPARAMETER_DESC );
  Commit;

END ROIC_PLS007_HS_TB_R12;
/

