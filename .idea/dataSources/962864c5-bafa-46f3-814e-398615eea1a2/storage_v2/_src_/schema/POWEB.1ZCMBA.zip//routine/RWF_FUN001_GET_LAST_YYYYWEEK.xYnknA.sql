create Function RWF_FUN001_GET_LAST_YYYYWEEK(cRWF_YYYY in RWF_SAP001_REVENUE_FORECAST.RWF_YYYY%TYPE,cRWF_WEEK in RWF_SAP001_REVENUE_FORECAST.RWF_WEEK%TYPE)
/*********************************************************************
*新增/修改日期 :  2009-05-06
*Programmer    :  Kangi
*申請單號      :  SAI005398
*新增原因      :  GET LAST YYYYWEEK FROM TABLE RWF_SAP001_REVENUE_FORECAST
**********************************************************************/
/*********************************************************************
*新增/修改日期 :  20111229
*Programmer    :  Kangi
*申請單號      :  SAI028442
*新增原因      :  GET LAST WEEK FROM TABLE RWF_SYS002_RWF_YYYY_WEEK
**********************************************************************/
return RWF_SAP001_REVENUE_FORECAST.RWF_WEEK%TYPE
is
cLAST_RWF_YYYYWEEK  VARCHAR2(6) ;
Begin
       SELECT MAX(RWF_YYYY||RWF_WEEK) INTO cLAST_RWF_YYYYWEEK
           FROM RWF_SYS002_RWF_YYYY_WEEK
           WHERE RWF_YYYY||RWF_WEEK < cRWF_YYYY||cRWF_WEEK ;
       return cLAST_RWF_YYYYWEEK ;
    Exception
      WHEN NO_DATA_FOUND THEN
         return null ;
End RWF_FUN001_GET_LAST_YYYYWEEK;
/

