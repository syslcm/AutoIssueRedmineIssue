create PROCEDURE         "VRTN_PLSQL_QQ_GV" IS

    /*
           CREATE DATE:  2007/11/12
           PLSQL      :  VRTN_PLSQL_QQ_GV
                 Author     :  Susan Lin
                 Purpase    :  New VRTN_QQ_VENDOR_GV &Process score = 0
           ----------------------------------------------------------
           2007/11/30 Susan change for SITE vendor process
           2007/12/05 Susan change for site grade
           2010/07/08 Susan UGSZ UGTW
           2013/01/17 Susan add 
     */


 vPROCEE_YYYYMMDD varchar2(8);
 vPROCEE_YYYYMM   varchar2(6);
 iTracePoint      varchar2(100);
 cErrorText       varchar2(500);
 vCOMPANY_CODE    varchar2(4);
 vYYYYMM          varchar2(6);
 vSTART_DATE      varchar2(8);
 vEND_DATE        varchar2(8);
 vQUARTER         varchar2(8);
 vCK_GV_VENDOR    varchar2(10);
 vIR_AMT_TWD                PLD_KPI_IR_DETAIL.IR_AMT_TWD%TYPE;

BEGIN
    vCOMPANY_CODE := null;
    vYYYYMM := null;
    vSTART_DATE := null;
    vEND_DATE := null;
    
   select * into vQUARTER from (
    select trim(trim(to_char(add_months(SYSDATE,-1), 'YYYY')) || 'Q' || trim(to_char(add_months(SYSDATE,-1), 'Q')))
      from dual
   );
           
     --抓季起始區間資料
         for REC1 in (Select MIN(DATE_KEY) AS DATE_KEY
                             FROM DIMENSION_DATE
                             WHERE QUARTER = SUBSTRB(vQUARTER,5,2)
                               AND YYYY = SUBSTRB(vQUARTER,1,4)
                               ) loop
            vSTART_DATE := REC1.DATE_KEY;
         end loop;
    --抓季終上區間資料
        for REC1 in (Select MAX(DATE_KEY) AS DATE_KEY
                            FROM DIMENSION_DATE
                            WHERE QUARTER = SUBSTRB(vQUARTER,5,2)
                              AND YYYY = SUBSTRB(vQUARTER,1,4)
                             ) loop
            vEND_DATE := REC1.DATE_KEY;
        end loop;
  


  if vQUARTER is null then
     --若沒抓到資料則寄 error mail
     iTracePoint := '110';
     cErrorText := 'QUARTER error!';
     MAIL_FILE_BIDBDBADMIN(in_to_name => 'shuchin_lin@usiglobal.com', subject => '[VRTN] PL/SQL VRTN_PLSQL_QQ_GV ERROR', message => '[VRTN_PLSQL_QQ_GV], The tracepoint is  ' || iTracePoint || ' and ErrorText= ' || cErrorText) ;
  else

     --清除舊的 VRTN_QQ_VENDOR_GV 資料
       iTracePoint := '200';
       DELETE FROM VRTN_QQ_VENDOR_GV WHERE QUARTER = SUBSTRB(vQUARTER,1,6);

     --放入季交易資料
       iTracePoint := '210';
               Insert into VRTN_QQ_VENDOR_GV ( QUARTER, GV_VENDOR, SUBTOT_Q, SUBTOT_C, Q_SUBTOT_D, Q_MM_SCORE, Q_GRADE, Q_AMOUNT, TW_VENDOR, TW_AMOUNT, TW_AMT_SHARE_SITE, TW_SUBTOT_Q, TW_SUBTOT_C, TW_SUBTOT_D, TW_Q_SCORE, TW_GRADE, SZ_VENDOR, SZ_AMOUNT, SZ_AMT_SHARE_SITE, SZ_SUBTOT_Q, SZ_SUBTOT_C, SZ_SUBTOT_D, SZ_Q_SCORE, SZ_GRADE, SH_VENDOR, SH_AMOUNT, SH_AMT_SHARE_SITE, SH_SUBTOT_Q, SH_SUBTOT_C, SH_SUBTOT_D, SH_Q_SCORE, SH_GRADE,
                          UGSZ_VENDOR, UGSZ_AMOUNT,  UGSZ_AMT_SHARE_SITE, UGSZ_SUBTOT_Q, UGSZ_SUBTOT_C, UGSZ_SUBTOT_D, UGSZ_Q_SCORE, UGSZ_GRADE,             
                          UGTW_VENDOR, UGTW_AMOUNT, UGTW_AMT_SHARE_SITE, UGTW_SUBTOT_Q, UGTW_SUBTOT_C, UGTW_SUBTOT_D, UGTW_Q_SCORE, UGTW_GRADE,
                          KS_VENDOR, KS_AMOUNT, KS_AMT_SHARE_SITE, KS_SUBTOT_Q, KS_SUBTOT_C, KS_SUBTOT_D, KS_Q_SCORE, KS_GRADE,
                   --//
                          MX_VENDOR, MX_AMOUNT, MX_AMT_SHARE_SITE, MX_SUBTOT_Q, MX_SUBTOT_C, MX_SUBTOT_D, MX_Q_SCORE, MX_GRADE,
                            MODIFY_FLAG, MODIFY_DATE, FROM_DATE, TO_DATE, DATE_TIME )
                      select QUARTER, GV_VENDOR,round((SUBTOT_Q),1) as SUBTOT_Q,round((SUBTOT_C),1) as SUBTOT_C, round((Q_SUBTOT_D),1) as Q_SUBTOT_D, round((Q_MM_SCORE),1) as Q_MM_SCORE, Q_GRADE, Q_AMOUNT, TW_VENDOR, TW_AMOUNT, TW_AMT_SHARE_SITE, round((TW_SUBTOT_Q),1) as TW_SUBTOT_Q, round((TW_SUBTOT_C),1) as TW_SUBTOT_C, round((TW_SUBTOT_D),1) as TW_SUBTOT_D, round((TW_Q_SCORE),1) as TW_Q_SCORE,
                        (select b.GRADE as TW_GRADE From VRTN_SUM23_MAPPING_GRADE b where b.RANGE_TYPE = 'SC' and b.RANGE_FROM <= TW_Q_SCORE and b.RANGE_TO >= TW_Q_SCORE ) as TW_GRADE,
                         SZ_VENDOR, SZ_AMOUNT, SZ_AMT_SHARE_SITE, round((SZ_SUBTOT_Q),1) as SZ_SUBTOT_Q, round((SZ_SUBTOT_C),1) as SZ_SUBTOT_C, round((SZ_SUBTOT_D),1) as SZ_SUBTOT_D, round((SZ_Q_SCORE),1) as SZ_Q_SCORE,
                        (select b.GRADE as SZ_GRADE From VRTN_SUM23_MAPPING_GRADE b where b.RANGE_TYPE = 'SC' and b.RANGE_FROM <= SZ_Q_SCORE and b.RANGE_TO >= SZ_Q_SCORE ) as SZ_GRADE,
                         SH_VENDOR, SH_AMOUNT, SH_AMT_SHARE_SITE, round((SH_SUBTOT_Q),1) as SH_SUBTOT_Q, round((SH_SUBTOT_C),1) as SH_SUBTOT_C, round((SH_SUBTOT_D),1) as SH_SUBTOT_D, round((SH_Q_SCORE),1) as SH_Q_SCORE,
                        (select b.GRADE as SH_GRADE From VRTN_SUM23_MAPPING_GRADE b where b.RANGE_TYPE = 'SC' and b.RANGE_FROM <= SH_Q_SCORE and b.RANGE_TO >= SH_Q_SCORE ) as SH_GRADE,
                         UGSZ_VENDOR, UGSZ_AMOUNT, UGSZ_AMT_SHARE_SITE, round((UGSZ_SUBTOT_Q),1) as UGSZ_SUBTOT_Q, round((UGSZ_SUBTOT_C),1) as UGSZ_SUBTOT_C, round((UGSZ_SUBTOT_D),1) as UGSZ_SUBTOT_D, round((UGSZ_Q_SCORE),1) as UGSZ_Q_SCORE,                     
                          (select b.GRADE as UGSZ_GRADE From VRTN_SUM23_MAPPING_GRADE b where b.RANGE_TYPE = 'SC' and b.RANGE_FROM <= UGSZ_Q_SCORE and b.RANGE_TO >= UGSZ_Q_SCORE ) as UGSZ_GRADE,
                         UGTW_VENDOR, UGTW_AMOUNT, UGTW_AMT_SHARE_SITE, round((UGTW_SUBTOT_Q),1) as UGTW_SUBTOT_Q, round((UGTW_SUBTOT_C),1) as UGTW_SUBTOT_C, round((UGTW_SUBTOT_D),1) as UGTW_SUBTOT_D, round((UGTW_Q_SCORE),1) as UGTW_Q_SCORE,
                          (select b.GRADE as UGTW_GRADE From VRTN_SUM23_MAPPING_GRADE b where b.RANGE_TYPE = 'SC' and b.RANGE_FROM <= UGTW_Q_SCORE and b.RANGE_TO >= UGTW_Q_SCORE ) as UGTW_GRADE,                                                 
                         KS_VENDOR, KS_AMOUNT, KS_AMT_SHARE_SITE, round((KS_SUBTOT_Q),1) as KS_SUBTOT_Q, round((KS_SUBTOT_C),1) as KS_SUBTOT_C, round((KS_SUBTOT_D),1) as KS_SUBTOT_D, round((KS_Q_SCORE),1) as KS_Q_SCORE,
                          (select b.GRADE as KS_GRADE From VRTN_SUM23_MAPPING_GRADE b where b.RANGE_TYPE = 'SC' and b.RANGE_FROM <= KS_Q_SCORE and b.RANGE_TO >= KS_Q_SCORE ) as KS_GRADE, 
                   --//      
                         MX_VENDOR, MX_AMOUNT, MX_AMT_SHARE_SITE, round((MX_SUBTOT_Q),1) as MX_SUBTOT_Q, round((MX_SUBTOT_C),1) as MX_SUBTOT_C, round((MX_SUBTOT_D),1) as MX_SUBTOT_D, round((MX_Q_SCORE),1) as MX_Q_SCORE,
                          (select b.GRADE as MX_GRADE From VRTN_SUM23_MAPPING_GRADE b where b.RANGE_TYPE = 'SC' and b.RANGE_FROM <= MX_Q_SCORE and b.RANGE_TO >= MX_Q_SCORE ) as MX_GRADE,                               
                         '' AS MODIFY_FLAG, '' AS MODIFY_DATE, FROM_DATE, TO_DATE, to_char(SYSDATE, 'yyyymmddhh24miss') as DATE_TIME
                  from VRTN_SUM22_GV_QQ_COMBINE
                  where QUARTER = vQUARTER
                    and MATGROUP= '000';
                  commit;

       iTracePoint := '220';
           for REC1 in (
               select * from  VRTN_QQ_VENDOR_GV
                        where QUARTER = vQUARTER
              ) loop

                  if REC1.SUBTOT_Q = '' then
                     REC1.SUBTOT_Q := '0';
                  end if;
                  if REC1.SUBTOT_C = '' then
                     REC1.SUBTOT_C := '0';
                  end if;
                  if REC1.Q_SUBTOT_D = '' then
                     REC1.Q_SUBTOT_D := '0';
                  end if;
                  if REC1.Q_MM_SCORE = '' then
                     REC1.Q_MM_SCORE := '0';
                  end if;
                  if REC1.TW_AMT_SHARE_SITE = '' then
                     REC1.TW_AMT_SHARE_SITE := '0';
                  end if;
                  if REC1.TW_SUBTOT_Q = '' then
                     REC1.TW_SUBTOT_Q := '0';
                  end if;
                  if REC1.TW_SUBTOT_C = '' then
                     REC1.TW_SUBTOT_C := '0';
                  end if;
                  if REC1.TW_SUBTOT_D = '' then
                     REC1.TW_SUBTOT_D := '0';
                  end if;
                  if REC1.TW_Q_SCORE  = '' then
                     REC1.TW_Q_SCORE  := '0';
                  end if;
                  if REC1.SZ_AMT_SHARE_SITE = '' then
                     REC1.SZ_AMT_SHARE_SITE := '0';
                  end if;
                  if REC1.SZ_SUBTOT_Q  = '' then
                     REC1.SZ_SUBTOT_Q  := '0';
                  end if;
                  if REC1.SZ_SUBTOT_C  = '' then
                     REC1.SZ_SUBTOT_C  := '0';
                  end if;
                  if REC1.SZ_SUBTOT_D  = '' then
                     REC1.SZ_SUBTOT_D  := '0';
                  end if;
                  if REC1.SZ_Q_SCORE  = '' then
                     REC1.SZ_Q_SCORE  := '0';
                  end if;
                  if REC1.SH_AMT_SHARE_SITE = '' then
                     REC1.SH_AMT_SHARE_SITE := '0';
                  end if;
                  if REC1.SH_SUBTOT_Q  = '' then
                     REC1.SH_SUBTOT_Q  := '0';
                  end if;
                  if REC1.SH_SUBTOT_C  = '' then
                     REC1.SH_SUBTOT_C  := '0';
                  end if;
                  if REC1.SH_SUBTOT_D  = '' then
                     REC1.SH_SUBTOT_D  := '0';
                  end if;
                  if REC1.SH_Q_SCORE  = '' then
                     REC1.SH_Q_SCORE  := '0';
                  end if;

                 
-- Add for GRADE By susan 2008/01/18
                  if REC1.TW_Q_SCORE = '0' and
                     REC1.TW_SUBTOT_Q = '0' and REC1.TW_SUBTOT_C = '0' and REC1.TW_SUBTOT_D = '0' then
                     REC1.TW_GRADE := '';
                  end if;

                  if REC1.SZ_Q_SCORE = '0' and
                     REC1.SZ_SUBTOT_Q = '0' and REC1.SZ_SUBTOT_C = '0' and REC1.SZ_SUBTOT_D = '0' then
                     REC1.SZ_GRADE := '';
                  end if;

                  if REC1.SH_Q_SCORE = '0' and
                     REC1.SH_SUBTOT_Q = '0' and REC1.SH_SUBTOT_C = '0' and REC1.SH_SUBTOT_D = '0' then
                     REC1.SH_GRADE := '';
                  end if;

                  if REC1.UGSZ_AMT_SHARE_SITE = '' then
                     REC1.UGSZ_AMT_SHARE_SITE := '0';
                  end if;
                  if REC1.UGSZ_SUBTOT_Q  = '' then
                     REC1.UGSZ_SUBTOT_Q  := '0';
                  end if;
                  if REC1.UGSZ_SUBTOT_C  = '' then
                     REC1.UGSZ_SUBTOT_C  := '0';
                  end if;
                  if REC1.UGSZ_SUBTOT_D  = '' then
                     REC1.UGSZ_SUBTOT_D  := '0';
                  end if;
                  if REC1.UGSZ_Q_SCORE  = '' then
                     REC1.UGSZ_Q_SCORE  := '0';
                  end if;                  
                 if REC1.UGSZ_Q_SCORE = '0' and
                     REC1.UGSZ_SUBTOT_Q = '0' and REC1.UGSZ_SUBTOT_C = '0' and REC1.UGSZ_SUBTOT_D = '0' then
                     REC1.UGSZ_GRADE := '';
                 end if;
                  if REC1.UGTW_AMT_SHARE_SITE = '' then
                     REC1.UGTW_AMT_SHARE_SITE := '0';
                  end if;
                  if REC1.UGTW_SUBTOT_Q  = '' then
                     REC1.UGTW_SUBTOT_Q  := '0';
                  end if;
                  if REC1.UGTW_SUBTOT_C  = '' then
                     REC1.UGTW_SUBTOT_C  := '0';
                  end if;
                  if REC1.UGTW_SUBTOT_D  = '' then
                     REC1.UGTW_SUBTOT_D  := '0';
                  end if;
                  if REC1.UGTW_Q_SCORE  = '' then
                     REC1.UGTW_Q_SCORE  := '0';
                  end if;                  
                 if REC1.UGTW_Q_SCORE = '0' and
                     REC1.UGTW_SUBTOT_Q = '0' and REC1.UGTW_SUBTOT_C = '0' and REC1.UGTW_SUBTOT_D = '0' then
                     REC1.UGTW_GRADE := '';
                 end if;
--
                if REC1.KS_AMT_SHARE_SITE = '' then
                     REC1.KS_AMT_SHARE_SITE := '0';
                  end if;
                  if REC1.KS_SUBTOT_Q  = '' then
                     REC1.KS_SUBTOT_Q  := '0';
                  end if;
                  if REC1.KS_SUBTOT_C  = '' then
                     REC1.KS_SUBTOT_C  := '0';
                  end if;
                  if REC1.KS_SUBTOT_D  = '' then
                     REC1.KS_SUBTOT_D  := '0';
                  end if;
                  if REC1.KS_Q_SCORE  = '' then
                     REC1.KS_Q_SCORE  := '0';
                  end if;                  
                 if REC1.KS_Q_SCORE = '0' and
                     REC1.KS_SUBTOT_Q = '0' and REC1.KS_SUBTOT_C = '0' and REC1.KS_SUBTOT_D = '0' then
                     REC1.KS_GRADE := '';
                 end if;                  
                  
                if REC1.MX_AMT_SHARE_SITE = '' then
                     REC1.MX_AMT_SHARE_SITE := '0';
                  end if;
                  if REC1.MX_SUBTOT_Q  = '' then
                     REC1.MX_SUBTOT_Q  := '0';
                  end if;
                  if REC1.MX_SUBTOT_C  = '' then
                     REC1.MX_SUBTOT_C  := '0';
                  end if;
                  if REC1.MX_SUBTOT_D  = '' then
                     REC1.MX_SUBTOT_D  := '0';
                  end if;
                  if REC1.MX_Q_SCORE  = '' then
                     REC1.MX_Q_SCORE  := '0';
                  end if;                  
                 if REC1.MX_Q_SCORE = '0' and
                     REC1.MX_SUBTOT_Q = '0' and REC1.MX_SUBTOT_C = '0' and REC1.MX_SUBTOT_D = '0' then
                     REC1.MX_GRADE := '';
                 end if;    
                  Update VRTN_QQ_VENDOR_GV
                         set SUBTOT_Q   = REC1.SUBTOT_Q,
                             SUBTOT_C   = REC1.SUBTOT_C,
                             Q_SUBTOT_D = REC1.Q_SUBTOT_D,
                             Q_MM_SCORE = REC1.Q_MM_SCORE,
                             TW_AMT_SHARE_SITE = REC1.TW_AMT_SHARE_SITE,
                             TW_SUBTOT_Q = REC1.TW_SUBTOT_Q,
                             TW_SUBTOT_C = REC1.TW_SUBTOT_C,
                             TW_SUBTOT_D = REC1.TW_SUBTOT_D,
                             TW_Q_SCORE  = REC1.TW_Q_SCORE,
                             TW_GRADE = REC1.TW_GRADE,
                             SZ_AMT_SHARE_SITE = REC1.SZ_AMT_SHARE_SITE,
                             SZ_SUBTOT_Q = REC1.SZ_SUBTOT_Q,
                             SZ_SUBTOT_C = REC1.SZ_SUBTOT_C,
                             SZ_SUBTOT_D = REC1.SZ_SUBTOT_D,
                             SZ_Q_SCORE  = REC1.SZ_Q_SCORE,
                             SZ_GRADE = REC1.SZ_GRADE,
                             SH_AMT_SHARE_SITE = REC1.SH_AMT_SHARE_SITE,
                             SH_SUBTOT_Q = REC1.SH_SUBTOT_Q,
                             SH_SUBTOT_C = REC1.SH_SUBTOT_C,
                             SH_SUBTOT_D = REC1.SH_SUBTOT_D,
                             SH_Q_SCORE  = REC1.SH_Q_SCORE,
                             SH_GRADE = REC1.SH_GRADE,
                             UGSZ_AMT_SHARE_SITE = REC1.UGSZ_AMT_SHARE_SITE,
                             UGSZ_SUBTOT_Q = REC1.UGSZ_SUBTOT_Q,
                             UGSZ_SUBTOT_C = REC1.UGSZ_SUBTOT_C,
                             UGSZ_SUBTOT_D = REC1.UGSZ_SUBTOT_D,
                             UGSZ_Q_SCORE  = REC1.UGSZ_Q_SCORE,
                             UGSZ_GRADE = REC1.UGSZ_GRADE,
                             UGTW_AMT_SHARE_SITE = REC1.UGTW_AMT_SHARE_SITE,
                             UGTW_SUBTOT_Q = REC1.UGTW_SUBTOT_Q,
                             UGTW_SUBTOT_C = REC1.UGTW_SUBTOT_C,
                             UGTW_SUBTOT_D = REC1.UGTW_SUBTOT_D,
                             UGTW_Q_SCORE  = REC1.UGTW_Q_SCORE,
                             UGTW_GRADE    = REC1.UGTW_GRADE,
                             KS_AMT_SHARE_SITE = REC1.KS_AMT_SHARE_SITE,
                             KS_SUBTOT_Q = REC1.KS_SUBTOT_Q,
                             KS_SUBTOT_C = REC1.KS_SUBTOT_C,
                             KS_SUBTOT_D = REC1.KS_SUBTOT_D,
                             KS_Q_SCORE  = REC1.KS_Q_SCORE,
                             KS_GRADE    = REC1.KS_GRADE,
                            --//
                             MX_AMT_SHARE_SITE = REC1.MX_AMT_SHARE_SITE,
                             MX_SUBTOT_Q = REC1.MX_SUBTOT_Q,
                             MX_SUBTOT_C = REC1.MX_SUBTOT_C,
                             MX_SUBTOT_D = REC1.MX_SUBTOT_D,
                             MX_Q_SCORE  = REC1.MX_Q_SCORE,
                             MX_GRADE    = REC1.MX_GRADE                             
                         where QUARTER  = vQUARTER
                           and GV_VENDOR = REC1.GV_VENDOR;

                  commit;
                end loop;


    --清除舊的 VRTN_QQ_VENDOR_GV 資料
      iTracePoint := '300';
      DELETE FROM VRTN_QQ_MAIL_LIST WHERE QUARTER = SUBSTRB(vQUARTER,1,6);

    --清除舊的 VRTN_QQ_VENDOR_GV_LIST 資料
      iTracePoint := '310';
      DELETE FROM VRTN_QQ_VENDOR_GV_LIST WHERE QUARTER = SUBSTRB(vQUARTER,1,6);


    --放入當季分數to EMAIL
    iTracePoint := '320';
      for REC1 in ( select distinct a.QUARTER as QUARTER, a.GV_VENDOR as GV_VENDOR,
                    substr(a.TW_VENDOR,1,10) as TW_V1, substr(a.TW_VENDOR,11,10) as TW_V2,substr(a.TW_VENDOR,21,10) as TW_V3, substr(a.TW_VENDOR,31,10) as TW_V4,substr(a.TW_VENDOR,41,10) as TW_V5,
                    substr(a.SZ_VENDOR,1,10) as SZ_V1, substr(a.SZ_VENDOR,11,10) as SZ_V2,substr(a.SZ_VENDOR,21,10) as SZ_V3, substr(a.SZ_VENDOR,31,10) as SZ_V4,substr(a.SZ_VENDOR,41,10) as SZ_V5,
                    substr(a.SH_VENDOR,1,10) as SH_V1, substr(a.SH_VENDOR,11,10) as SH_V2,substr(a.SH_VENDOR,21,10) as SH_V3, substr(a.SH_VENDOR,31,10) as SH_V4,substr(a.SH_VENDOR,41,10) as SH_V5,
                    substr(a.UGSZ_VENDOR,1,10) as UGSZ_V1, substr(a.UGSZ_VENDOR,11,10) as UGSZ_V2,substr(a.UGSZ_VENDOR,21,10) as UGSZ_V3, substr(a.UGSZ_VENDOR,31,10) as UGSZ_V4,substr(a.UGSZ_VENDOR,41,10) as UGSZ_V5,
                    substr(a.UGTW_VENDOR,1,10) as UGTW_V1, substr(a.UGTW_VENDOR,11,10) as UGTW_V2,substr(a.UGTW_VENDOR,21,10) as UGTW_V3, substr(a.UGTW_VENDOR,31,10) as UGTW_V4,substr(a.UGTW_VENDOR,41,10) as UGTW_V5,
                    substr(a.KS_VENDOR,1,10) as KS_V1, substr(a.KS_VENDOR,11,10) as KS_V2, substr(a.KS_VENDOR,21,10) as KS_V3, substr(a.KS_VENDOR,31,10) as KS_V4, substr(a.KS_VENDOR,41,10) as KS_V5,
                    substr(a.MX_VENDOR,1,10) as MX_V1, substr(a.MX_VENDOR,11,10) as MX_V2, substr(a.MX_VENDOR,21,10) as MX_V3, substr(a.MX_VENDOR,31,10) as MX_V4, substr(a.MX_VENDOR,41,10) as MX_V5                    
       from VRTN_QQ_VENDOR_GV a
            where a.QUARTER = vQUARTER
--            where QUARTER = '2007Q4'
--            Group by a.QUARTER , a.GV_VENDOR
--                     a.TW_VENDOR, a.SZ_VENDOR
--                     substr(a.TW_VENDOR,1,10) , substr(a.TW_VENDOR,11,10),substr(a.TW_VENDOR,21,10), substr(a.TW_VENDOR,31,10),substr(a.TW_VENDOR,41,10),
--                     substr(a.SZ_VENDOR,1,10), substr(a.SZ_VENDOR,11,10),substr(a.SZ_VENDOR,21,10), substr(a.SZ_VENDOR,31,10),substr(a.SZ_VENDOR,41,10),
--                     substr(a.SH_VENDOR,1,10), substr(a.SH_VENDOR,11,10),substr(a.SH_VENDOR,21,10), substr(a.SH_VENDOR,31,10),substr(a.SH_VENDOR,41,10)
                     ) loop

--      iTracePoint := '330'; --INSERT VRTN_QQ_VENDOR_GV_LIST
--      --放到 VRTN_QQ_VENDOR_GV_LIST
--      if REC1.GV_VENDOR is not null then
--         Insert into VRTN_QQ_VENDOR_GV_LIST (
--                  QUARTER, GV_VENDOR, VM_SEND_FLAG , VM_SEND_DATE
--                  ) values (
--                 REC1.QUARTER,
--                 REC1.GV_VENDOR,
--                 '',
--                 to_char(SYSDATE, 'yyyymmddhh24miss')
--                );
--         commit;
--       end if;


     iTracePoint := '340'; --INSERT VRTN_QQ_MAIL_LIST
     --放到 VRTN_QQ_MAIL_LIST
       if REC1.TW_V1 is not null then
          Insert into VRTN_QQ_MAIL_LIST (
                  QUARTER, GV_VENDOR, COMPANY_CODE, VENDOR, VM_SEND_FLAG, TX_TIME
                  ) values (
                 REC1.QUARTER,
                 REC1.GV_VENDOR,
                 '1100',
                 REC1.TW_V1,
                 '',
                 to_char(SYSDATE, 'yyyymmddhh24miss')
                );
          commit;
        end if;
       if REC1.TW_V2 is not null then
          Insert into VRTN_QQ_MAIL_LIST (
                  QUARTER, GV_VENDOR, COMPANY_CODE, VENDOR, VM_SEND_FLAG, TX_TIME
                  ) values (
                 REC1.QUARTER,
                 REC1.GV_VENDOR,
                 '1100',
                 REC1.TW_V2,
                 '',
                 to_char(SYSDATE, 'yyyymmddhh24miss')
                );
          commit;
        end if;
       if REC1.TW_V3 is not null then
          Insert into VRTN_QQ_MAIL_LIST (
                  QUARTER, GV_VENDOR, COMPANY_CODE, VENDOR, VM_SEND_FLAG, TX_TIME
                  ) values (
                 REC1.QUARTER,
                 REC1.GV_VENDOR,
                 '1100',
                 REC1.TW_V3,
                 '',
                 to_char(SYSDATE, 'yyyymmddhh24miss')
                );
          commit;
        end if;
       if REC1.TW_V4 is not null then
          Insert into VRTN_QQ_MAIL_LIST (
                  QUARTER, GV_VENDOR, COMPANY_CODE, VENDOR, VM_SEND_FLAG, TX_TIME
                  ) values (
                 REC1.QUARTER,
                 REC1.GV_VENDOR,
                 '1100',
                 REC1.TW_V4,
                 '',
                 to_char(SYSDATE, 'yyyymmddhh24miss')
                );
          commit;
        end if;
       if REC1.TW_V5 is not null then
          Insert into VRTN_QQ_MAIL_LIST (
                  QUARTER, GV_VENDOR, COMPANY_CODE, VENDOR, VM_SEND_FLAG, TX_TIME
                  ) values (
                 REC1.QUARTER,
                 REC1.GV_VENDOR,
                 '1100',
                 REC1.TW_V5,
                 '',
                 to_char(SYSDATE, 'yyyymmddhh24miss')
                );
          commit;
        end if;
       if REC1.SZ_V1 is not null then
          Insert into VRTN_QQ_MAIL_LIST (
                  QUARTER, GV_VENDOR, COMPANY_CODE, VENDOR, VM_SEND_FLAG, TX_TIME
                  ) values (
                 REC1.QUARTER,
                 REC1.GV_VENDOR,
                 '1200',
                 REC1.SZ_V1,
                 '',
                 to_char(SYSDATE, 'yyyymmddhh24miss')
                );
          commit;
        end if;
       if REC1.SZ_V2 is not null then
          Insert into VRTN_QQ_MAIL_LIST (
                  QUARTER, GV_VENDOR, COMPANY_CODE, VENDOR, VM_SEND_FLAG, TX_TIME
                  ) values (
                 REC1.QUARTER,
                 REC1.GV_VENDOR,
                 '1200',
                 REC1.SZ_V2,
                 '',
                 to_char(SYSDATE, 'yyyymmddhh24miss')
                );
          commit;
        end if;
       if REC1.SZ_V3 is not null then
          Insert into VRTN_QQ_MAIL_LIST (
                  QUARTER, GV_VENDOR, COMPANY_CODE, VENDOR, VM_SEND_FLAG, TX_TIME
                  ) values (
                 REC1.QUARTER,
                 REC1.GV_VENDOR,
                 '1200',
                 REC1.SZ_V3,
                 '',
                 to_char(SYSDATE, 'yyyymmddhh24miss')
                );
          commit;
        end if;
       if REC1.SZ_V4 is not null then
          Insert into VRTN_QQ_MAIL_LIST (
                  QUARTER, GV_VENDOR, COMPANY_CODE, VENDOR, VM_SEND_FLAG, TX_TIME
                  ) values (
                 REC1.QUARTER,
                 REC1.GV_VENDOR,
                 '1200',
                 REC1.SZ_V4,
                 '',
                 to_char(SYSDATE, 'yyyymmddhh24miss')
                );
          commit;
        end if;
       if REC1.SZ_V5 is not null then
          Insert into VRTN_QQ_MAIL_LIST (
                  QUARTER, GV_VENDOR, COMPANY_CODE, VENDOR, VM_SEND_FLAG, TX_TIME
                  ) values (
                 REC1.QUARTER,
                 REC1.GV_VENDOR,
                 '1200',
                 REC1.SZ_V5,
                 '',
                 to_char(SYSDATE, 'yyyymmddhh24miss')
                );
          commit;
       end if;
       if REC1.SH_V1 is not null then
          Insert into VRTN_QQ_MAIL_LIST (
                  QUARTER, GV_VENDOR, COMPANY_CODE, VENDOR, VM_SEND_FLAG, TX_TIME
                  ) values (
                 REC1.QUARTER,
                 REC1.GV_VENDOR,
                 '1500',
                 REC1.SH_V1,
                 '',
                 to_char(SYSDATE, 'yyyymmddhh24miss')
                );
          commit;
        end if;
       if REC1.SH_V2 is not null then
          Insert into VRTN_QQ_MAIL_LIST (
                  QUARTER, GV_VENDOR, COMPANY_CODE, VENDOR, VM_SEND_FLAG, TX_TIME
                  ) values (
                 REC1.QUARTER,
                 REC1.GV_VENDOR,
                 '1500',
                 REC1.SH_V2,
                 '',
                 to_char(SYSDATE, 'yyyymmddhh24miss')
                );
          commit;
        end if;
       if REC1.SH_V3 is not null then
          Insert into VRTN_QQ_MAIL_LIST (
                  QUARTER, GV_VENDOR, COMPANY_CODE, VENDOR, VM_SEND_FLAG, TX_TIME
                  ) values (
                 REC1.QUARTER,
                 REC1.GV_VENDOR,
                 '1500',
                 REC1.SH_V3,
                 '',
                 to_char(SYSDATE, 'yyyymmddhh24miss')
                );
          commit;
        end if;
       if REC1.SH_V4 is not null then
          Insert into VRTN_QQ_MAIL_LIST (
                  QUARTER, GV_VENDOR, COMPANY_CODE, VENDOR, VM_SEND_FLAG, TX_TIME
                  ) values (
                 REC1.QUARTER,
                 REC1.GV_VENDOR,
                 '1500',
                 REC1.SH_V4,
                 '',
                 to_char(SYSDATE, 'yyyymmddhh24miss')
                );
          commit;
        end if;
       if REC1.SH_V5 is not null then
          Insert into VRTN_QQ_MAIL_LIST (
                  QUARTER, GV_VENDOR, COMPANY_CODE, VENDOR, VM_SEND_FLAG, TX_TIME
                  ) values (
                 REC1.QUARTER,
                 REC1.GV_VENDOR,
                 '1500',
                 REC1.SH_V5,
                 '',
                 to_char(SYSDATE, 'yyyymmddhh24miss')
                );
          commit;
        end if;
        --
        if REC1.UGSZ_V1 is not null then
          Insert into VRTN_QQ_MAIL_LIST (
                  QUARTER, GV_VENDOR, COMPANY_CODE, VENDOR, VM_SEND_FLAG, TX_TIME
                  ) values (
                 REC1.QUARTER,
                 REC1.GV_VENDOR,
                 '1400',
                 REC1.UGSZ_V1,
                 '',
                 to_char(SYSDATE, 'yyyymmddhh24miss')
                );
          commit;
        end if;
       if REC1.UGSZ_V2 is not null then
          Insert into VRTN_QQ_MAIL_LIST (
                  QUARTER, GV_VENDOR, COMPANY_CODE, VENDOR, VM_SEND_FLAG, TX_TIME
                  ) values (
                 REC1.QUARTER,
                 REC1.GV_VENDOR,
                 '1400',
                 REC1.UGSZ_V2,
                 '',
                 to_char(SYSDATE, 'yyyymmddhh24miss')
                );
          commit;
       end if;
       if REC1.UGSZ_V3 is not null then
          Insert into VRTN_QQ_MAIL_LIST (
                  QUARTER, GV_VENDOR, COMPANY_CODE, VENDOR, VM_SEND_FLAG, TX_TIME
                  ) values (
                 REC1.QUARTER,
                 REC1.GV_VENDOR,
                 '1400',
                 REC1.UGSZ_V3,
                 '',
                 to_char(SYSDATE, 'yyyymmddhh24miss')
                );
          commit;
        end if;
       if REC1.UGSZ_V4 is not null then
          Insert into VRTN_QQ_MAIL_LIST (
                  QUARTER, GV_VENDOR, COMPANY_CODE, VENDOR, VM_SEND_FLAG, TX_TIME
                  ) values (
                 REC1.QUARTER,
                 REC1.GV_VENDOR,
                 '1400',
                 REC1.UGSZ_V4,
                 '',
                 to_char(SYSDATE, 'yyyymmddhh24miss')
                );
          commit;
        end if;
       if REC1.UGSZ_V5 is not null then
          Insert into VRTN_QQ_MAIL_LIST (
                  QUARTER, GV_VENDOR, COMPANY_CODE, VENDOR, VM_SEND_FLAG, TX_TIME
                  ) values (
                 REC1.QUARTER,
                 REC1.GV_VENDOR,
                 '1400',
                 REC1.UGSZ_V5,
                 '',
                 to_char(SYSDATE, 'yyyymmddhh24miss')
                );
          commit;
        end if;
        if REC1.UGTW_V1 is not null then
          Insert into VRTN_QQ_MAIL_LIST (
                  QUARTER, GV_VENDOR, COMPANY_CODE, VENDOR, VM_SEND_FLAG, TX_TIME
                  ) values (
                 REC1.QUARTER,
                 REC1.GV_VENDOR,
                 '1700',
                 REC1.UGTW_V1,
                 '',
                 to_char(SYSDATE, 'yyyymmddhh24miss')
                );
          commit;
        end if;
       if REC1.UGTW_V2 is not null then
          Insert into VRTN_QQ_MAIL_LIST (
                  QUARTER, GV_VENDOR, COMPANY_CODE, VENDOR, VM_SEND_FLAG, TX_TIME
                  ) values (
                 REC1.QUARTER,
                 REC1.GV_VENDOR,
                 '1700',
                 REC1.UGTW_V2,
                 '',
                 to_char(SYSDATE, 'yyyymmddhh24miss')
                );
          commit;
        end if;
       if REC1.UGTW_V3 is not null then
          Insert into VRTN_QQ_MAIL_LIST (
                  QUARTER, GV_VENDOR, COMPANY_CODE, VENDOR, VM_SEND_FLAG, TX_TIME
                  ) values (
                 REC1.QUARTER,
                 REC1.GV_VENDOR,
                 '1700',
                 REC1.UGTW_V3,
                 '',
                 to_char(SYSDATE, 'yyyymmddhh24miss')
                );
          commit;
        end if;
       if REC1.UGTW_V4 is not null then
          Insert into VRTN_QQ_MAIL_LIST (
                  QUARTER, GV_VENDOR, COMPANY_CODE, VENDOR, VM_SEND_FLAG, TX_TIME
                  ) values (
                 REC1.QUARTER,
                 REC1.GV_VENDOR,
                 '1700',
                 REC1.UGTW_V4,
                 '',
                 to_char(SYSDATE, 'yyyymmddhh24miss')
                );
          commit;
        end if;
        if REC1.UGTW_V5 is not null then
          Insert into VRTN_QQ_MAIL_LIST (
                  QUARTER, GV_VENDOR, COMPANY_CODE, VENDOR, VM_SEND_FLAG, TX_TIME
                  ) values (
                 REC1.QUARTER,
                 REC1.GV_VENDOR,
                 '1700',
                 REC1.UGTW_V5,
                 '',
                 to_char(SYSDATE, 'yyyymmddhh24miss')
                );
          commit;
        end if;
      --UGKS 
       if REC1.KS_V1 is not null then
          Insert into VRTN_QQ_MAIL_LIST (
                  QUARTER, GV_VENDOR, COMPANY_CODE, VENDOR, VM_SEND_FLAG, TX_TIME
                  ) values (
                 REC1.QUARTER,
                 REC1.GV_VENDOR,
                 '4100',
                 REC1.KS_V1,
                 '',
                 to_char(SYSDATE, 'yyyymmddhh24miss')
                );
          commit;
        end if;         
        if REC1.KS_V2 is not null then
          Insert into VRTN_QQ_MAIL_LIST (
                  QUARTER, GV_VENDOR, COMPANY_CODE, VENDOR, VM_SEND_FLAG, TX_TIME
                  ) values (
                 REC1.QUARTER,
                 REC1.GV_VENDOR,
                 '4100',
                 REC1.KS_V2,
                 '',
                 to_char(SYSDATE, 'yyyymmddhh24miss')
                );
          commit;
        end if;          
        if REC1.KS_V3 is not null then
          Insert into VRTN_QQ_MAIL_LIST (
                  QUARTER, GV_VENDOR, COMPANY_CODE, VENDOR, VM_SEND_FLAG, TX_TIME
                  ) values (
                 REC1.QUARTER,
                 REC1.GV_VENDOR,
                 '4100',
                 REC1.KS_V3,
                 '',
                 to_char(SYSDATE, 'yyyymmddhh24miss')
                );
          commit;
        end if;                 
        if REC1.KS_V4 is not null then
          Insert into VRTN_QQ_MAIL_LIST (
                  QUARTER, GV_VENDOR, COMPANY_CODE, VENDOR, VM_SEND_FLAG, TX_TIME
                  ) values (
                 REC1.QUARTER,
                 REC1.GV_VENDOR,
                 '4100',
                 REC1.KS_V4,
                 '',
                 to_char(SYSDATE, 'yyyymmddhh24miss')
                );
          commit;
        end if;            
        if REC1.KS_V5 is not null then
          Insert into VRTN_QQ_MAIL_LIST (
                  QUARTER, GV_VENDOR, COMPANY_CODE, VENDOR, VM_SEND_FLAG, TX_TIME
                  ) values (
                 REC1.QUARTER,
                 REC1.GV_VENDOR,
                 '4100',
                 REC1.KS_V5,
                 '',
                 to_char(SYSDATE, 'yyyymmddhh24miss')
                );
          commit;
        end if;
--2019/04/16
       if REC1.MX_V1 is not null then
          Insert into VRTN_QQ_MAIL_LIST (
                  QUARTER, GV_VENDOR, COMPANY_CODE, VENDOR, VM_SEND_FLAG, TX_TIME
                  ) values (
                 REC1.QUARTER,
                 REC1.GV_VENDOR,
                 '2300',
                 REC1.MX_V1,
                 '',
                 to_char(SYSDATE, 'yyyymmddhh24miss')
                );
          commit;
        end if;         
        if REC1.MX_V2 is not null then
          Insert into VRTN_QQ_MAIL_LIST (
                  QUARTER, GV_VENDOR, COMPANY_CODE, VENDOR, VM_SEND_FLAG, TX_TIME
                  ) values (
                 REC1.QUARTER,
                 REC1.GV_VENDOR,
                 '2300',
                 REC1.MX_V2,
                 '',
                 to_char(SYSDATE, 'yyyymmddhh24miss')
                );
          commit;
        end if;          
        if REC1.MX_V3 is not null then
          Insert into VRTN_QQ_MAIL_LIST (
                  QUARTER, GV_VENDOR, COMPANY_CODE, VENDOR, VM_SEND_FLAG, TX_TIME
                  ) values (
                 REC1.QUARTER,
                 REC1.GV_VENDOR,
                 '2300',
                 REC1.MX_V3,
                 '',
                 to_char(SYSDATE, 'yyyymmddhh24miss')
                );
          commit;
        end if;                 
        if REC1.MX_V4 is not null then
          Insert into VRTN_QQ_MAIL_LIST (
                  QUARTER, GV_VENDOR, COMPANY_CODE, VENDOR, VM_SEND_FLAG, TX_TIME
                  ) values (
                 REC1.QUARTER,
                 REC1.GV_VENDOR,
                 '2300',
                 REC1.MX_V4,
                 '',
                 to_char(SYSDATE, 'yyyymmddhh24miss')
                );
          commit;
        end if;            
        if REC1.MX_V5 is not null then
          Insert into VRTN_QQ_MAIL_LIST (
                  QUARTER, GV_VENDOR, COMPANY_CODE, VENDOR, VM_SEND_FLAG, TX_TIME
                  ) values (
                 REC1.QUARTER,
                 REC1.GV_VENDOR,
                 '2300',
                 REC1.MX_V5,
                 '',
                 to_char(SYSDATE, 'yyyymmddhh24miss')
                );
          commit;
        end if;
--//
       end loop;
       
--      --清除舊的 VRTN_QQ_VENDOR_GV 資料-H00479 
--       iTracePoint := '410';
--       DELETE FROM VRTN_QQ_VENDOR_GV WHERE GV_VENDOR = 'H00479' AND
--                   QUARTER = SUBSTRB(vQUARTER,1,6); 
--       
--      --放到 VRTN_QQ_VENDOR_GV - 20150612
--      iTracePoint := '420'; 
--      Insert into VRTN_QQ_VENDOR_GV ( QUARTER, GV_VENDOR, SUBTOT_Q, SUBTOT_C, Q_SUBTOT_D, Q_MM_SCORE, Q_GRADE, Q_AMOUNT,
--                          TW_VENDOR, TW_AMOUNT, TW_AMT_SHARE_SITE, TW_SUBTOT_Q, TW_SUBTOT_C, TW_SUBTOT_D, TW_Q_SCORE, TW_GRADE,
--                          SZ_VENDOR, SZ_AMOUNT, SZ_AMT_SHARE_SITE, SZ_SUBTOT_Q, SZ_SUBTOT_C, SZ_SUBTOT_D, SZ_Q_SCORE, SZ_GRADE,
--                          SH_VENDOR, SH_AMOUNT, SH_AMT_SHARE_SITE, SH_SUBTOT_Q, SH_SUBTOT_C, SH_SUBTOT_D, SH_Q_SCORE, SH_GRADE,
--                          UGSZ_VENDOR, UGSZ_AMOUNT,  UGSZ_AMT_SHARE_SITE, UGSZ_SUBTOT_Q, UGSZ_SUBTOT_C, UGSZ_SUBTOT_D, UGSZ_Q_SCORE, UGSZ_GRADE,
--                          UGTW_VENDOR, UGTW_AMOUNT, UGTW_AMT_SHARE_SITE, UGTW_SUBTOT_Q, UGTW_SUBTOT_C, UGTW_SUBTOT_D, UGTW_Q_SCORE, UGTW_GRADE,
--                          KS_VENDOR, KS_AMOUNT, KS_AMT_SHARE_SITE, KS_SUBTOT_Q, KS_SUBTOT_C, KS_SUBTOT_D, KS_Q_SCORE, KS_GRADE,
--                          MX_VENDOR, MX_AMOUNT, MX_AMT_SHARE_SITE, MX_SUBTOT_Q, MX_SUBTOT_C, MX_SUBTOT_D, MX_Q_SCORE, MX_GRADE,                                                                                                                     
--                            MODIFY_FLAG, MODIFY_DATE, FROM_DATE, TO_DATE, DATE_TIME
--                            ) values (
--                            vQUARTER,
--                            'H00479',
--                            '100',
--                            '100',
--                            '100',
--                            '100',
--                            'A+',
--                            '0',
--                            '0',
--                            '0',
--                            '0',
--                            '0',
--                            '0',
--                            '0',
--                            '0',
--                            '0',
--                            '0',
--                            '0',
--                            '0',
--                            '0',
--                            '0',
--                            '0',
--                            '0',
--                            '0',
--                            '0000012468',
--                            '0',
--                            '1',
--                            '100',
--                            '100',
--                            '100',
--                            '100',
--                            'A+',
--                            '0',
--                            '0',
--                            '0',
--                            '0',
--                            '0',
--                            '0',
--                            '0',
--                            '0',
--                            '0',
--                            '0',
--                           '0',
--                            '0',
--                            '0',
--                            '0',
--                            '0',
--                            '0',
--                            '0',
--                            '0',
--                            '0',
--                            '0',
--                            '0',
--                            --
--                            '0',                            
--                            '0',
--                            '0',
--                            '0',
--                            '0',
--                            '0',
--                            '0',                                                                                                                     
--                            '0',
--                            --
--                            '0',
--                            '0',
--                            '0',
--                            '',
--                            '',
--                           vSTART_DATE,
--                           vEND_DATE,       
--                           to_char(SYSDATE, 'yyyymmddhh24miss')
--                             );
--                      commit;
--
      
  

  end if;

EXCEPTION
   When OTHERS Then
    --有錯誤產生則寄mail
      cErrorText := SQLERRM();
      MAIL_FILE_BIDBDBADMIN(in_to_name => 'shuchin_lin@usiglobal.com', subject => '[VRTN] PL/SQL VRTN_PLSQL_QQ_GV ERROR', message => '[VRTN_PLSQL_QQ_GV], The tracepoint is  ' || iTracePoint || ' and ErrorText= ' || cErrorText);


END VRTN_PLSQL_QQ_GV;
/

