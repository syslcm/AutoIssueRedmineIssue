create PROCEDURE       "ROA_PLS012_CAL_M_ROLL_12M_NEW" (
  in_YYYYMM1  in VARCHAR2
  ,in_Kind1 in VARCHAR2
)
AUTHID DEFINER
/* ****************************************************************************************
  PROG-ID      : ROA_PLS012_CAL_M_ROLL_12M_NEW
  PROG-ACTION  :   
  Author       : Asan Chang
  Date         : 2020/07/22
  OA No.       : SAI123889
 ****************************************************************************************
 
 *************************************************************************************/
is
   iReccnt              integer;
   In_YYYY              DIMENSION_DATE.YYYY%TYPE;
   In_MM                DIMENSION_DATE.MM%TYPE; 
   In_PERIOD            DIMENSION_DATE.YYYYMM%TYPE;
   From_PERIOD          DIMENSION_DATE.YYYYMM%TYPE;
   DATE_TRANS           varchar2(10);
   In_KIND              varchar2(2); 
   USI_KIND             varchar2(2);
   PC_KIND              varchar2(2);
   This_ACC             varchar2(6);
   L_CNT                NUMBER(6);
   iTracePoint          integer ; 
   In_MM2               integer ;
   inCompany            ROA_PST004_FIXED_ASSETS.COMPANY_CODE%TYPE;
   STR01                varchar2(30);
   STR02                varchar2(30);
   STR03                varchar2(10);
   STR04                varchar2(2);
   STR06                varchar2(20); 
   STR07                varchar2(20); 
   STR08                varchar2(20);  
   STR09                varchar2(800);
   STR10                varchar2(250);
BEGIN
--
  In_YYYY := SUBSTR( in_YYYYMM1, 1, 4);
  In_MM := SUBSTR( in_YYYYMM1, 5, 2); 
  --In_MM2 := In_MM;
  In_MM2 := 12;
  In_PERIOD := In_YYYY || In_MM;
  In_KIND := in_Kind1;
  DATE_TRANS := In_YYYY ||'-'|| In_MM || '-01';

  delete ROA_PST006_M_DATA_ROLL_12M_NEW WHERE PERIOD = In_PERIOD AND D_KIND = In_KIND ;
  COMMIT ;   
  
  --get from period
  for REC_PERIOD IN (
    (select TO_CHAR(add_months(TO_DATE(DATE_TRANS, 'YYYY-MM-DD'),-11),'YYYYMM') FROM_PERIOD from dual )
  )
  LOOP
    From_PERIOD := REC_PERIOD.FROM_PERIOD;                 
  END LOOP;
  
                   
  /*****************************************************************************************
      (1)Kind = 01-PC
  ************************************************************************************ */
  if In_KIND IN ('01') THEN 
      iTracePoint := 100 ;  
 
   --(1-01-A) --------  
      STR01 :=  'A00200';
      STR02 :=  'Net Mfg Revenues';
      STR06 :=  'USI'; 
      STR07 :=  'USI(No Bravo)';      
      
      for REC1 IN (
          
          select STR01 D_ACC, TT2.PC,(TT2.AMOUNT/12/30*1000*CCC.DAYS) AMOUNT from
            (
            select TT.PC, sum( TT.amount  ) AMOUNT from
              ( select LPAD(a.pc, 10, '0') PC, a.YYYY||a.Month period , sum( a.amount ) AMOUNT from PNL_MSA001_EM_DATA a
              where 
              --YYYY = In_YYYY and Month = In_MM AND 
              acct_id<> ' ' AND ACCT_NAME = STR02
			  AND ( GRP_CODE = 'UG' OR GRP_CODE = 'USI' )
              GROUP BY PC,a.YYYY||a.Month ORDER BY PC,a.YYYY||a.Month
              ) TT
            where period <= In_PERIOD and period >= From_PERIOD
            GROUP BY PC ORDER BY PC
            )TT2, ROA_UPL010_CCC_DAYS CCC
            WHERE TT2.PC = CCC.PC AND CCC.PERIOD = In_PERIOD          
            
      )
      LOOP
        INSERT INTO ROA_PST006_M_DATA_ROLL_12M_NEW
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,REC1.PC ,REC1.D_ACC, (REC1.AMOUNT));                 
      END LOOP; 
 
 
      
  --(1-01-B) --------      
      STR01 :=  'A00800';
      for REC1 IN (
          SELECT STR01 D_ACC, pc, sum( upl_amt ) AMOUNT FROM ROA_UPL004_AR_AP_INV_DATA a
		  JOIN PNL_MAP006_SITE_MAPPING b ON a.COMPANY_CODE = b.COMPANY_CODE
		  WHERE
          PERIOD = In_PERIOD AND TYPE IN ( 'AR' )
		  AND GRP_CODE = 'UG'
          GROUP BY PC ORDER BY PC    
      )
      LOOP
        INSERT INTO ROA_PST006_M_DATA_ROLL_12M_NEW
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,REC1.PC ,REC1.D_ACC, REC1.AMOUNT);                 
      END LOOP;    
      
--(1-02) --------  
      STR01 :=  'A00900';
      for REC1 IN (
          SELECT STR01 D_ACC, pc, sum( upl_amt ) AMOUNT FROM ROA_UPL004_AR_AP_INV_DATA a
		  JOIN PNL_MAP006_SITE_MAPPING b ON a.COMPANY_CODE = b.COMPANY_CODE
		  WHERE
          PERIOD = In_PERIOD AND TYPE IN  ( 'INV', 'ADJ INV' ) 
		  AND GRP_CODE = 'UG'
          GROUP BY PC ORDER BY PC    
      )
      LOOP
        INSERT INTO ROA_PST006_M_DATA_ROLL_12M_NEW
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,REC1.PC ,REC1.D_ACC, REC1.AMOUNT);                 
      END LOOP; 
           
  --(1-03) --------  
      STR01 :=  'A01500';
      for REC1 IN (
          SELECT STR01 D_ACC, pc, sum( upl_amt ) AMOUNT FROM ROA_UPL004_AR_AP_INV_DATA a
		  JOIN PNL_MAP006_SITE_MAPPING b ON a.COMPANY_CODE = b.COMPANY_CODE
		  WHERE
          PERIOD = In_PERIOD AND TYPE IN  ( 'AP' ) 
		  AND GRP_CODE = 'UG'
          GROUP BY PC ORDER BY PC    
      )
      LOOP
        INSERT INTO ROA_PST006_M_DATA_ROLL_12M_NEW
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,REC1.PC ,REC1.D_ACC, REC1.AMOUNT);                 
      END LOOP;       

  --(1-04) --------  
      STR01 :=  'A01000';
      for REC1 IN (
          SELECT STR01 D_ACC, pc, sum( UPL_AMT_LOC  * EX_RATE_TWD ) AMOUNT FROM ROA_PST004_FIXED_ASSETS a
		  JOIN PNL_MAP006_SITE_MAPPING b ON a.COMPANY_CODE = b.COMPANY_CODE
		  WHERE
          PERIOD = In_PERIOD AND S_SEQ IN ( '10' ) AND TYPE ='2'
		  AND GRP_CODE = 'UG'
          GROUP BY PC ORDER BY PC    
      )
      LOOP
        INSERT INTO ROA_PST006_M_DATA_ROLL_12M_NEW
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,REC1.PC ,REC1.D_ACC, REC1.AMOUNT);                 
      END LOOP; 

  --(1-05) --------  
      STR01 :=  'A01100';
      for REC1 IN (
          SELECT STR01 D_ACC, pc, sum( UPL_AMT_LOC  * EX_RATE_TWD ) AMOUNT FROM ROA_PST004_FIXED_ASSETS a
		  JOIN PNL_MAP006_SITE_MAPPING b ON a.COMPANY_CODE = b.COMPANY_CODE
		  WHERE
          PERIOD = In_PERIOD AND S_SEQ IN ( '20' ) AND TYPE ='2'
		  AND GRP_CODE = 'UG'
          GROUP BY PC ORDER BY PC    
      )
      LOOP
        INSERT INTO ROA_PST006_M_DATA_ROLL_12M_NEW
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,REC1.PC ,REC1.D_ACC, REC1.AMOUNT);                 
      END LOOP;    

  --(1-06) --------  
      STR01 :=  'A03000';
      for REC1 IN (
          SELECT STR01 D_ACC, pc, sum( UPL_AMT_LOC  * EX_RATE_TWD ) AMOUNT FROM ROA_PST004_FIXED_ASSETS a
		  JOIN PNL_MAP006_SITE_MAPPING b ON a.COMPANY_CODE = b.COMPANY_CODE
		  WHERE
          PERIOD = In_PERIOD AND S_SEQ IN ( '20' ) AND TYPE ='2'
		  AND GRP_CODE = 'UG'
          GROUP BY PC ORDER BY PC    
      )
      LOOP
        INSERT INTO ROA_PST006_M_DATA_ROLL_12M_NEW
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,REC1.PC ,REC1.D_ACC, REC1.AMOUNT);                 
      END LOOP; 
          


  --(1-07) --------  
      STR01 :=  'A01200';
      for REC1 IN (
          SELECT STR01 D_ACC, pc, sum( UPL_AMT_LOC  * EX_RATE_TWD ) AMOUNT FROM ROA_PST004_FIXED_ASSETS a
		  JOIN PNL_MAP006_SITE_MAPPING b ON a.COMPANY_CODE = b.COMPANY_CODE
		  WHERE
          PERIOD = In_PERIOD AND S_SEQ IN ( '30','40' ) AND TYPE ='2'
		  AND GRP_CODE = 'UG'
          GROUP BY PC ORDER BY PC    
      )
      LOOP
        INSERT INTO ROA_PST006_M_DATA_ROLL_12M_NEW
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,REC1.PC ,REC1.D_ACC, REC1.AMOUNT);                 
      END LOOP;  
           
  --(1-08) --------  
      STR01 :=  'A03200';
      for REC1 IN (
          SELECT STR01 D_ACC, pc, sum( UPL_AMT_LOC  * EX_RATE_TWD ) AMOUNT FROM ROA_PST004_FIXED_ASSETS a
		  JOIN PNL_MAP006_SITE_MAPPING b ON a.COMPANY_CODE = b.COMPANY_CODE
		  WHERE
          PERIOD = In_PERIOD AND S_SEQ IN ( '20','30','40' ) AND TYPE ='2'
		  AND GRP_CODE = 'UG'
          GROUP BY PC ORDER BY PC    
      )
      LOOP
        INSERT INTO ROA_PST006_M_DATA_ROLL_12M_NEW
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,REC1.PC ,REC1.D_ACC, REC1.AMOUNT);                 
      END LOOP;      

  --(1-09) --------  
      STR01 :=  'A02900';
      for REC1 IN (
          SELECT STR01 D_ACC, pc, sum( UPL_AMT_LOC  * EX_RATE_TWD ) AMOUNT FROM ROA_PST004_FIXED_ASSETS a
		  JOIN PNL_MAP006_SITE_MAPPING b ON a.COMPANY_CODE = b.COMPANY_CODE
		  WHERE
          PERIOD = In_PERIOD AND S_SEQ IN ( '10','20','30','40' ) AND TYPE ='2'
		  AND GRP_CODE = 'UG'
          GROUP BY PC ORDER BY PC    
      )
      LOOP
        INSERT INTO ROA_PST006_M_DATA_ROLL_12M_NEW
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,REC1.PC ,REC1.D_ACC, REC1.AMOUNT);                 
      END LOOP;
      
  --(1-10) --------  
      STR01 :=  'A02100';
      STR02 :=  'Net Mfg Revenues';
      for REC1 IN (
          SELECT STR01 D_ACC, LPAD(pc, 10, '0') PC, sum( amount ) AMOUNT FROM PNL_MSA001_EM_DATA WHERE
          YYYY = In_YYYY AND MONTH = In_MM AND acct_id<> ' ' AND ACCT_NAME = STR02
		  AND ( GRP_CODE = 'UG' OR GRP_CODE = 'USI' )
          GROUP BY PC ORDER BY PC    
      )
      LOOP
        INSERT INTO ROA_PST006_M_DATA_ROLL_12M_NEW
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,REC1.PC ,REC1.D_ACC, (REC1.AMOUNT * 1000 ));                 
      END LOOP; 
      
  --(1-11) --------  
      STR01 :=  'A02200';
      STR02 :=  '07.050';
      for REC1 IN (
          SELECT STR01 D_ACC, LPAD(pc, 10, '0') PC, sum( amount ) AMOUNT FROM PNL_MSA001_EM_DATA WHERE
          YYYY = In_YYYY AND MONTH = In_MM AND acct_id <> ' ' AND acct_id <= STR02
		  AND ( GRP_CODE = 'UG' OR GRP_CODE = 'USI' )
          GROUP BY PC ORDER BY PC    
      )
      LOOP
        INSERT INTO ROA_PST006_M_DATA_ROLL_12M_NEW
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,REC1.PC ,REC1.D_ACC, (REC1.AMOUNT * 1000 ));                 
      END LOOP;       

  --(1-12) --------  
      STR01 :=  'A04000';
      for REC1 IN (
          SELECT STR01 D_ACC, pc, sum( UPL_AMT_LOC  * EX_RATE_TWD ) AMOUNT FROM ROA_PST004_FIXED_ASSETS a
		  JOIN PNL_MAP006_SITE_MAPPING b ON a.COMPANY_CODE = b.COMPANY_CODE
		  WHERE
          PERIOD = In_PERIOD AND S_SEQ IN ( '10' ) AND TYPE ='1'
		  AND GRP_CODE = 'UG'
          GROUP BY PC ORDER BY PC    
      )
      LOOP
        INSERT INTO ROA_PST006_M_DATA_ROLL_12M_NEW
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,REC1.PC ,REC1.D_ACC, REC1.AMOUNT);                 
      END LOOP;

  --(1-13) --------  
      STR01 :=  'A03600';
      for REC1 IN (
          SELECT STR01 D_ACC, pc, sum( UPL_AMT_LOC  * EX_RATE_TWD ) AMOUNT FROM ROA_PST004_FIXED_ASSETS a
		  JOIN PNL_MAP006_SITE_MAPPING b ON a.COMPANY_CODE = b.COMPANY_CODE
		  WHERE
          PERIOD = In_PERIOD AND S_SEQ IN ( '20' ) AND TYPE ='1'
		  AND GRP_CODE = 'UG'
          GROUP BY PC ORDER BY PC    
      )
      LOOP
        INSERT INTO ROA_PST006_M_DATA_ROLL_12M_NEW
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,REC1.PC ,REC1.D_ACC, REC1.AMOUNT);                 
      END LOOP;

  --(1-13) --------  
      STR01 :=  'A04100';
      for REC1 IN (
          SELECT STR01 D_ACC, pc, sum( UPL_AMT_LOC  * EX_RATE_TWD ) AMOUNT FROM ROA_PST004_FIXED_ASSETS a
		  JOIN PNL_MAP006_SITE_MAPPING b ON a.COMPANY_CODE = b.COMPANY_CODE
		  WHERE
          PERIOD = In_PERIOD AND S_SEQ IN ( '20' ) AND TYPE ='1'
		  AND GRP_CODE = 'UG'
          GROUP BY PC ORDER BY PC    
      )
      LOOP
        INSERT INTO ROA_PST006_M_DATA_ROLL_12M_NEW
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,REC1.PC ,REC1.D_ACC, REC1.AMOUNT);                 
      END LOOP;
                
  --(1-14) --------  
      STR01 :=  'A04200';
      for REC1 IN (
          SELECT STR01 D_ACC, pc, sum( UPL_AMT_LOC  * EX_RATE_TWD ) AMOUNT FROM ROA_PST004_FIXED_ASSETS a
		  JOIN PNL_MAP006_SITE_MAPPING b ON a.COMPANY_CODE = b.COMPANY_CODE
		  WHERE
          PERIOD = In_PERIOD AND S_SEQ IN ( '30','40' ) AND TYPE ='1'
		  AND GRP_CODE = 'UG'
          GROUP BY PC ORDER BY PC    
      )
      LOOP
        INSERT INTO ROA_PST006_M_DATA_ROLL_12M_NEW
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,REC1.PC ,REC1.D_ACC, REC1.AMOUNT);                 
      END LOOP;             

  --(1-15) --------  
      STR01 :=  'A03800';
      for REC1 IN (
          SELECT STR01 D_ACC, pc, sum( UPL_AMT_LOC  * EX_RATE_TWD ) AMOUNT FROM ROA_PST004_FIXED_ASSETS a
		  JOIN PNL_MAP006_SITE_MAPPING b ON a.COMPANY_CODE = b.COMPANY_CODE
		  WHERE
          PERIOD = In_PERIOD AND S_SEQ IN ( '20','30','40' ) AND TYPE ='1'
		  AND GRP_CODE = 'UG'
          GROUP BY PC ORDER BY PC    
      )
      LOOP
        INSERT INTO ROA_PST006_M_DATA_ROLL_12M_NEW
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,REC1.PC ,REC1.D_ACC, REC1.AMOUNT);                 
      END LOOP; 
  
  --* 2017/07/20 SAI065848 Asan Chang By PC -> subtotal�L����(A01400)
  --(1-16) --------      
      STR01 :=  'A01400';
      for REC1 IN (              
          SELECT D_KEY,   SUM( D_AMOUNT ) AMOUNT
          FROM ROA_PST006_M_DATA_ROLL_12M_NEW
          WHERE PERIOD = In_PERIOD
          AND D_KIND = D_KIND AND D_ACC in ( 'A00200','A00300','A00400','A00500','A00600', 'A00700',
                                             'A00800','A00900','A01000','A01100','A01200', 'A01300')
          GROUP BY D_KEY
          order by D_KEY

      )
      LOOP
        INSERT INTO ROA_PST006_M_DATA_ROLL_12M_NEW
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,REC1.D_KEY ,STR01, REC1.AMOUNT);                 
      END LOOP;
  
    --(1-16_2) --------  
      STR01 :=  'A03400';
      for REC1 IN (              
          SELECT D_KEY,   SUM( D_AMOUNT ) AMOUNT
          FROM ROA_PST006_M_DATA_ROLL_12M_NEW
          WHERE PERIOD = In_PERIOD
          AND D_KIND = D_KIND AND D_ACC in ( 'A00200','A00800','A00900','A04000','A04100','A04200')
          GROUP BY D_KEY
          order by D_KEY

      )
      LOOP
        INSERT INTO ROA_PST006_M_DATA_ROLL_12M_NEW
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,REC1.D_KEY ,STR01, REC1.AMOUNT);                 
      END LOOP;
      
 
     --(1-16_3) --------  
      STR01 :=  'A04400';
      for REC1 IN (              
          SELECT D_KEY,   SUM( D_AMOUNT ) AMOUNT
          FROM ROA_PST006_M_DATA_ROLL_12M_NEW
          WHERE PERIOD = In_PERIOD
          AND D_KIND = D_KIND AND D_ACC in ( 'A00200','A00800','A00900','A01000','A01100','A01200')
          GROUP BY D_KEY
          order by D_KEY

      )
      LOOP
        INSERT INTO ROA_PST006_M_DATA_ROLL_12M_NEW
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,REC1.D_KEY ,STR01, REC1.AMOUNT);              
      END LOOP;

    --(1-16_4) --------  
      STR01 :=  'A04600';
      for REC1 IN (              
          SELECT D_KEY,   SUM( D_AMOUNT ) AMOUNT
          FROM ROA_PST006_M_DATA_ROLL_12M_NEW
          WHERE PERIOD = In_PERIOD
          AND D_KIND = D_KIND AND D_ACC in ( 'A00200','A00800','A00900','A04000','A04100','A04200')
          GROUP BY D_KEY
          order by D_KEY

      )
      LOOP
        INSERT INTO ROA_PST006_M_DATA_ROLL_12M_NEW
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,REC1.D_KEY ,STR01, REC1.AMOUNT);                 
      END LOOP; 
      
    --(1-17) -------- 
      STR01 :=  'A01700';
      for REC1 IN (              
           select b.pc , (a.AMOUNT1 - b.AMOUNT2) AMOUNT from
          (
          SELECT D_KEY,   SUM( D_AMOUNT ) AMOUNT1
          FROM ROA_PST006_M_DATA_ROLL_12M_NEW
          WHERE PERIOD = In_PERIOD
          AND D_KIND = D_KIND AND D_ACC in ( 'A01400')
          GROUP BY D_KEY
          order by D_KEY
          ) a,
          (
          SELECT  pc, sum( upl_amt ) AMOUNT2 FROM ROA_UPL004_AR_AP_INV_DATA WHERE
          PERIOD = In_PERIOD AND TYPE IN  ( 'AP' )
          GROUP BY PC ORDER BY PC
          ) b
          where a.D_KEY = b.PC
      )
      LOOP
        INSERT INTO ROA_PST006_M_DATA_ROLL_12M_NEW
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,REC1.PC,STR01, REC1.AMOUNT);                 
      END LOOP;


  --(1-18) --------  
      STR01 :=  'C_NIB_Y_22';
      --STR02 :=  In_YYYY || '01';
      for REC1 IN (
        SELECT D_KEY,  (( SUM( D_AMOUNT ) / In_MM2 ) * 12)  AMOUNT
        FROM ROA_PST006_M_DATA_ROLL_12M_NEW
        WHERE PERIOD >= From_PERIOD and  PERIOD <= In_PERIOD
        AND D_KIND = In_KIND AND D_ACC = 'A02200'
      GROUP BY D_KEY
      order by D_KEY
  
      )
      LOOP
        INSERT INTO ROA_PST006_M_DATA_ROLL_12M_NEW
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND, REC1.D_KEY ,STR01, REC1.AMOUNT);                 
      END LOOP; 

  --(1-19) --------  
      STR01 :=  'C_SUB_A_14';
      --STR02 :=  In_YYYY || '01';
      for REC1 IN (
        SELECT D_KEY,  ( SUM( D_AMOUNT ) / In_MM2 )  AMOUNT
        FROM ROA_PST006_M_DATA_ROLL_12M_NEW
        WHERE PERIOD >= From_PERIOD and  PERIOD <= In_PERIOD
        AND D_KIND = In_KIND AND D_ACC = 'A01400'
      GROUP BY D_KEY
      order by D_KEY
  
      )
      LOOP
        INSERT INTO ROA_PST006_M_DATA_ROLL_12M_NEW
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND, REC1.D_KEY ,STR01, REC1.AMOUNT);                 
      END LOOP; 

  --(1-20) --------  
      STR01 :=  'C_EQU_A_17';
      --STR02 :=  In_YYYY || '01';
      for REC1 IN (
        SELECT D_KEY,  ( SUM( D_AMOUNT ) / In_MM2 )  AMOUNT
        FROM ROA_PST006_M_DATA_ROLL_12M_NEW
        WHERE PERIOD >= From_PERIOD and  PERIOD <= In_PERIOD
        AND D_KIND = In_KIND AND D_ACC = 'A01700'
      GROUP BY D_KEY
      order by D_KEY
  
      )
      LOOP
        INSERT INTO ROA_PST006_M_DATA_ROLL_12M_NEW
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND, REC1.D_KEY ,STR01, REC1.AMOUNT);                 
      END LOOP;

  --(1-21) --------  
      STR01 :=  'C_REV_Y_21';
      --STR02 :=  In_YYYY || '01';
      for REC1 IN (
        SELECT D_KEY,  (( SUM( D_AMOUNT ) / In_MM2 )* 12)  AMOUNT
        FROM ROA_PST006_M_DATA_ROLL_12M_NEW
        WHERE PERIOD >= From_PERIOD and  PERIOD <= In_PERIOD
        AND D_KIND = In_KIND AND D_ACC = 'A02100'
      GROUP BY D_KEY
      order by D_KEY
  
      )
      LOOP
        INSERT INTO ROA_PST006_M_DATA_ROLL_12M_NEW
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND, REC1.D_KEY ,STR01, REC1.AMOUNT);                 
      END LOOP;

  --(1-22) --------  
      STR01 :=  'C_SFA_A_10N12';
      --STR02 :=  In_YYYY || '01';
      for REC1 IN (
        SELECT D_KEY,  ( SUM( D_AMOUNT ) / In_MM2 )  AMOUNT
        FROM ROA_PST006_M_DATA_ROLL_12M_NEW
        WHERE PERIOD >= From_PERIOD and  PERIOD <= In_PERIOD
        AND D_KIND = In_KIND AND D_ACC in ( 'A01000', 'A01100', 'A01200')
      GROUP BY D_KEY
      order by D_KEY
  
      )
      LOOP
        INSERT INTO ROA_PST006_M_DATA_ROLL_12M_NEW
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND, REC1.D_KEY ,STR01, REC1.AMOUNT);                 
      END LOOP;

  --(1-23) --------  
      STR01 :=  'C_BV1_A_30';
      --STR02 :=  In_YYYY || '01';
      for REC1 IN (
        SELECT D_KEY,  ( SUM( D_AMOUNT ) / In_MM2 )  AMOUNT
        FROM ROA_PST006_M_DATA_ROLL_12M_NEW
        WHERE PERIOD >= From_PERIOD and  PERIOD <= In_PERIOD
        AND D_KIND = In_KIND AND D_ACC in ( 'A03000' )
      GROUP BY D_KEY
      order by D_KEY
  
      )
      LOOP
        INSERT INTO ROA_PST006_M_DATA_ROLL_12M_NEW
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND, REC1.D_KEY ,STR01, REC1.AMOUNT);                 
      END LOOP;

  --(1-24) --------  
      STR01 :=  'C_BV2_A_32';
      --STR02 :=  In_YYYY || '01';
      for REC1 IN (
        SELECT D_KEY,  ( SUM( D_AMOUNT ) / In_MM2 )  AMOUNT
        FROM ROA_PST006_M_DATA_ROLL_12M_NEW
        WHERE PERIOD >= From_PERIOD and  PERIOD <= In_PERIOD
        AND D_KIND = In_KIND AND D_ACC in ( 'A03200' )
      GROUP BY D_KEY
      order by D_KEY
  
      )
      LOOP
        INSERT INTO ROA_PST006_M_DATA_ROLL_12M_NEW
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND, REC1.D_KEY ,STR01, REC1.AMOUNT);                 
      END LOOP;

  --(1-25) --------  
      STR01 :=  'C_OV1_A_34';
      --STR02 :=  In_YYYY || '01';
      for REC1 IN (
        SELECT D_KEY,  ( SUM( D_AMOUNT ) / In_MM2 )  AMOUNT
        FROM ROA_PST006_M_DATA_ROLL_12M_NEW
        WHERE PERIOD >= From_PERIOD and  PERIOD <= In_PERIOD
        AND D_KIND = In_KIND AND D_ACC in ( 'A03400' )
      GROUP BY D_KEY
      order by D_KEY
  
      )
      LOOP
        INSERT INTO ROA_PST006_M_DATA_ROLL_12M_NEW
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND, REC1.D_KEY ,STR01, REC1.AMOUNT);                 
      END LOOP;


  --(1-26) --------  
      STR01 :=  'C_OV2_A_36';
      --STR02 :=  In_YYYY || '01';
      for REC1 IN (
        SELECT D_KEY,  ( SUM( D_AMOUNT ) / In_MM2 )  AMOUNT
        FROM ROA_PST006_M_DATA_ROLL_12M_NEW
        WHERE PERIOD >= From_PERIOD and  PERIOD <= In_PERIOD
        AND D_KIND = In_KIND AND D_ACC in ( 'A03600' )
      GROUP BY D_KEY
      order by D_KEY
  
      )
      LOOP
        INSERT INTO ROA_PST006_M_DATA_ROLL_12M_NEW
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND, REC1.D_KEY ,STR01, REC1.AMOUNT);                 
      END LOOP;

  --(1-27) --------  
      STR01 :=  'C_OV3_A_38';
      --STR02 :=  In_YYYY || '01';
      for REC1 IN (
        SELECT D_KEY,  ( SUM( D_AMOUNT ) / In_MM2 )  AMOUNT
        FROM ROA_PST006_M_DATA_ROLL_12M_NEW
        WHERE PERIOD >= From_PERIOD and  PERIOD <= In_PERIOD
        AND D_KIND = In_KIND AND D_ACC in ( 'A03800' )
      GROUP BY D_KEY
      order by D_KEY
  
      )
      LOOP
        INSERT INTO ROA_PST006_M_DATA_ROLL_12M_NEW
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND, REC1.D_KEY ,STR01, REC1.AMOUNT);                 
      END LOOP;
      
  --(1-28) --------  
      STR01 :=  'C_BV3_A_44';
      --STR02 :=  In_YYYY || '01';
      for REC1 IN (
        SELECT D_KEY,  ( SUM( D_AMOUNT ) / In_MM2 )  AMOUNT
        FROM ROA_PST006_M_DATA_ROLL_12M_NEW
        WHERE PERIOD >= From_PERIOD and  PERIOD <= In_PERIOD
        AND D_KIND = In_KIND AND D_ACC in ( 'A04400' )
      GROUP BY D_KEY
      order by D_KEY
  
      )
      LOOP
        INSERT INTO ROA_PST006_M_DATA_ROLL_12M_NEW
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND, REC1.D_KEY ,STR01, REC1.AMOUNT);                 
      END LOOP;   

  --(1-29) --------  
      STR01 :=  'C_OV4_A_46';
      --STR02 :=  In_YYYY || '01';
      for REC1 IN (
        SELECT D_KEY,  ( SUM( D_AMOUNT ) / In_MM2 )  AMOUNT
        FROM ROA_PST006_M_DATA_ROLL_12M_NEW
        WHERE PERIOD >= From_PERIOD and  PERIOD <= In_PERIOD
        AND D_KIND = In_KIND AND D_ACC in ( 'A04600' )
      GROUP BY D_KEY
      order by D_KEY
  
      )
      LOOP
        INSERT INTO ROA_PST006_M_DATA_ROLL_12M_NEW
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND, REC1.D_KEY ,STR01, REC1.AMOUNT);                 
      END LOOP;       

      delete  FROM   ROA_PST006_M_DATA_ROLL_12M_NEW WHERE ( D_KEY = STR06 OR D_KEY = STR07 ) AND D_KIND = In_KIND AND PERIOD = In_PERIOD;
      COMMIT; 


/*****************************************************************************************
      (3)Kind = 09-USI
  ************************************************************************************ */    
  ELSIF In_KIND IN ('09') THEN
    In_KIND := '09'; 
    STR06 :=  'UG';


  --(3-26) --------      
      STR01 :=  'A00200';
      for REC1 IN (
          select SUM(a.upl_amt * b.WEIGHTS ) Amount from ROA_UPL003_BS_DATA a 
		  join ROA_MAP002_BS_ACCOUNT b on b.S_DESC = a.S_DESC 
		  where b.account = 'Cash' and PERIOD = In_PERIOD 
          and a.company_code = STR06               
      )
      LOOP
        INSERT INTO ROA_PST006_M_DATA_ROLL_12M_NEW
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR06 ,STR01, REC1.AMOUNT);                 
      END LOOP;  
      
  --(3-27) --------      
      STR01 :=  'A00400';
      for REC1 IN (
          select SUM(a.upl_amt * b.WEIGHTS ) Amount from ROA_UPL003_BS_DATA a 
		  join ROA_MAP002_BS_ACCOUNT b on b.S_DESC = a.S_DESC 
		  where b.account = 'Financial Asset' and PERIOD = In_PERIOD 
          and a.company_code = STR06                 
      )
      LOOP
        INSERT INTO ROA_PST006_M_DATA_ROLL_12M_NEW
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR06 ,STR01, REC1.AMOUNT);                 
      END LOOP;

  --(3-28) --------      
      STR01 :=  'A00500';
      for REC1 IN (
          select SUM(a.upl_amt * b.WEIGHTS ) Amount from ROA_UPL003_BS_DATA a 
		  join ROA_MAP002_BS_ACCOUNT b on b.S_DESC = a.S_DESC 
		  where b.account = 'Others Receivable' and PERIOD = In_PERIOD  
          and a.company_code = STR06               
      )
      LOOP
        INSERT INTO ROA_PST006_M_DATA_ROLL_12M_NEW
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR06 ,STR01, REC1.AMOUNT);                 
      END LOOP;
      
  --(3-29) --------      
      STR01 :=  'A00600';
      for REC1 IN (
          select SUM(a.upl_amt * b.WEIGHTS ) Amount from ROA_UPL003_BS_DATA a 
		  join ROA_MAP002_BS_ACCOUNT b on b.S_DESC = a.S_DESC 
		  where b.account = 'Deferred Tax' and PERIOD = In_PERIOD 
          and a.company_code = STR06               
      )
      LOOP
        INSERT INTO ROA_PST006_M_DATA_ROLL_12M_NEW
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR06 ,STR01, REC1.AMOUNT);                 
      END LOOP;      
      
  --(3-30) --------      
      STR01 :=  'A00700';
      for REC1 IN (
          select SUM(a.upl_amt * b.WEIGHTS ) Amount from ROA_UPL003_BS_DATA a 
		  join ROA_MAP002_BS_ACCOUNT b on b.S_DESC = a.S_DESC 
		  where b.account = 'Deferred charges' and PERIOD = In_PERIOD 
          and a.company_code = STR06                
      )
      LOOP
        INSERT INTO ROA_PST006_M_DATA_ROLL_12M_NEW
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR06 ,STR01, REC1.AMOUNT);                 
      END LOOP;

  --(3-31) --------      
      STR01 :=  'A01400';
      for REC1 IN (
          select SUM(a.upl_amt * b.WEIGHTS ) Amount from ROA_UPL003_BS_DATA a 
		  join ROA_MAP002_BS_ACCOUNT b on b.S_DESC = a.S_DESC 
		  where b.account = 'Total assets' and PERIOD = In_PERIOD 
          and a.company_code = STR06                
      )
      LOOP
        INSERT INTO ROA_PST006_M_DATA_ROLL_12M_NEW
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR06 ,STR01, REC1.AMOUNT);                 
      END LOOP;

  --(3-32) --------      
      STR01 :=  'A01700';
      for REC1 IN (
          select SUM(a.upl_amt * b.WEIGHTS ) Amount from ROA_UPL003_BS_DATA a 		  
		  join ROA_MAP002_BS_ACCOUNT b on b.S_DESC = a.S_DESC 
		  where b.account = 'Equity' and PERIOD = In_PERIOD      
          and a.company_code = STR06                
      )
      LOOP
        INSERT INTO ROA_PST006_M_DATA_ROLL_12M_NEW
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR06 ,STR01, REC1.AMOUNT);                 
      END LOOP;
      
   --(3-33) --------      
      STR01 :=  'A01800';
      for REC1 IN (              
          select (Amount1-Amount2) Amount from
          (
          select SUM(a.upl_amt * b.WEIGHTS ) Amount1 from ROA_UPL003_BS_DATA a 
		  join ROA_MAP002_BS_ACCOUNT b on b.S_DESC = a.S_DESC 
		  where b.account = 'Total liabilities' and PERIOD = In_PERIOD   
          and a.company_code = STR06  ),
          (
          select SUM(a.upl_amt * b.WEIGHTS ) Amount2 from ROA_UPL003_BS_DATA a 
		  join ROA_MAP002_BS_ACCOUNT b on b.S_DESC = a.S_DESC 
		  where b.account = 'AP-3rd' and PERIOD = In_PERIOD      
          and a.company_code = STR06   )


      )
      LOOP
        INSERT INTO ROA_PST006_M_DATA_ROLL_12M_NEW
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR06 ,STR01, REC1.AMOUNT);                 
      END LOOP;     
                
  --(3-01) --------      
      STR01 :=  'A00800';
      for REC1 IN (
          select SUM(a.upl_amt * b.WEIGHTS ) Amount from ROA_UPL003_BS_DATA a 
		  join ROA_MAP002_BS_ACCOUNT b on b.S_DESC = a.S_DESC 
		  where b.account = 'AR-3rd' and PERIOD = In_PERIOD   
          and a.company_code = STR06             
      )
      LOOP
        INSERT INTO ROA_PST006_M_DATA_ROLL_12M_NEW
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR06 ,STR01, REC1.AMOUNT);                 
      END LOOP;   
      
--(3-02) --------  
      STR01 :=  'A00900';
      for REC1 IN (
          --select SUM(a.upl_amt * b.WEIGHTS ) Amount from ROA_UPL003_BS_DATA a join ROA_MAP002_BS_ACCOUNT b
          --on b.S_DESC = a.S_DESC where b.account = 'INV' and PERIOD = In_PERIOD     
          --and company_code = STR06     
          select a.AMOUNT1+b.AMOUNT2 Amount from
          (select SUM(a.upl_amt * b.WEIGHTS ) AMOUNT1 from ROA_UPL003_BS_DATA a 
		  join ROA_MAP002_BS_ACCOUNT b on b.S_DESC = a.S_DESC 
		  where b.account = 'INV' and PERIOD = In_PERIOD   
          and a.company_code = STR06 ) a,
          (SELECT  decode(sum(upl_amt),null,0,sum(upl_amt)) AMOUNT2 FROM ROA_UPL004_AR_AP_INV_DATA a
          JOIN PNL_MAP006_SITE_MAPPING b ON a.COMPANY_CODE = b.COMPANY_CODE 
          WHERE  
          b.GRP_CODE = 'UG' AND
          PERIOD = In_PERIOD AND TYPE IN  ( 'ADJ INV' )) b       
      )
      LOOP
        INSERT INTO ROA_PST006_M_DATA_ROLL_12M_NEW
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR06 ,STR01, REC1.AMOUNT);                 
      END LOOP; 
           
  --(3-03) --------  
      STR01 :=  'A01500';
      for REC1 IN (
          select SUM(a.upl_amt * b.WEIGHTS ) Amount from ROA_UPL003_BS_DATA a 
		  join ROA_MAP002_BS_ACCOUNT b on b.S_DESC = a.S_DESC 
		  where b.account = 'AP-3rd' and PERIOD = In_PERIOD   
          and a.company_code = STR06              
      )
      LOOP
        INSERT INTO ROA_PST006_M_DATA_ROLL_12M_NEW
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR06 ,STR01, REC1.AMOUNT);                 
      END LOOP;      

  --(3-04) --------  
      STR01 :=  'A01000';
      for REC1 IN (
          SELECT STR01 D_ACC,  sum( UPL_AMT_LOC  * EX_RATE_TWD ) AMOUNT FROM ROA_PST004_FIXED_ASSETS a 
		  JOIN PNL_MAP006_SITE_MAPPING b ON a.COMPANY_CODE = b.COMPANY_CODE
		  WHERE
          PERIOD = In_PERIOD AND S_SEQ IN ( '10' ) AND TYPE ='2'   
          AND b.GRP_CODE = 'UG'		  
              
      )
      LOOP
        INSERT INTO ROA_PST006_M_DATA_ROLL_12M_NEW
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR06 ,REC1.D_ACC, REC1.AMOUNT);                 
      END LOOP; 

  --(3-05) --------  
      STR01 :=  'A01100';
      for REC1 IN (
          SELECT STR01 D_ACC,  sum( UPL_AMT_LOC  * EX_RATE_TWD ) AMOUNT FROM ROA_PST004_FIXED_ASSETS a
		  JOIN PNL_MAP006_SITE_MAPPING b ON a.COMPANY_CODE = b.COMPANY_CODE
		  WHERE
          PERIOD = In_PERIOD AND S_SEQ IN ( '20' ) AND TYPE ='2'
          AND b.GRP_CODE = 'UG'	    
      )
      LOOP
        INSERT INTO ROA_PST006_M_DATA_ROLL_12M_NEW
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR06 ,REC1.D_ACC, REC1.AMOUNT);                 
      END LOOP;    

  --(3-06) --------  
      STR01 :=  'A03000';
      for REC1 IN (
          SELECT STR01 D_ACC,  sum( UPL_AMT_LOC  * EX_RATE_TWD ) AMOUNT FROM ROA_PST004_FIXED_ASSETS a
		  JOIN PNL_MAP006_SITE_MAPPING b ON a.COMPANY_CODE = b.COMPANY_CODE
		  WHERE
          PERIOD = In_PERIOD AND S_SEQ IN ( '20' ) AND TYPE ='2'
          AND b.GRP_CODE = 'UG'	    
      )
      LOOP
        INSERT INTO ROA_PST006_M_DATA_ROLL_12M_NEW
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR06 ,REC1.D_ACC, REC1.AMOUNT);                 
      END LOOP;   
      

      
      
  --(3-07) --------  
      STR01 :=  'A01200';
      for REC1 IN (
          SELECT STR01 D_ACC,  sum( UPL_AMT_LOC  * EX_RATE_TWD ) AMOUNT FROM ROA_PST004_FIXED_ASSETS a
		  JOIN PNL_MAP006_SITE_MAPPING b ON a.COMPANY_CODE = b.COMPANY_CODE
		  WHERE
          PERIOD = In_PERIOD AND S_SEQ IN ( '30','40' ) AND TYPE ='2'
          AND b.GRP_CODE = 'UG'	    
      )
      LOOP
        INSERT INTO ROA_PST006_M_DATA_ROLL_12M_NEW
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR06 ,REC1.D_ACC, REC1.AMOUNT);                 
      END LOOP;  
           
  --(3-08) --------  
      STR01 :=  'A03200';
      for REC1 IN (
          SELECT STR01 D_ACC,  sum( UPL_AMT_LOC  * EX_RATE_TWD ) AMOUNT FROM ROA_PST004_FIXED_ASSETS a
		  JOIN PNL_MAP006_SITE_MAPPING b ON a.COMPANY_CODE = b.COMPANY_CODE
		  WHERE
          PERIOD = In_PERIOD AND S_SEQ IN ( '20','30','40' ) AND TYPE ='2'
          AND b.GRP_CODE = 'UG'	    
      )
      LOOP
        INSERT INTO ROA_PST006_M_DATA_ROLL_12M_NEW
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR06 ,REC1.D_ACC, REC1.AMOUNT);                 
      END LOOP;      

  --(3-09) --------  
      STR01 :=  'A02900';
      for REC1 IN (
          SELECT STR01 D_ACC,  sum( UPL_AMT_LOC  * EX_RATE_TWD ) AMOUNT FROM ROA_PST004_FIXED_ASSETS a
		  JOIN PNL_MAP006_SITE_MAPPING b ON a.COMPANY_CODE = b.COMPANY_CODE
		  WHERE
          PERIOD = In_PERIOD AND S_SEQ IN ( '10','20','30','40' ) AND TYPE ='2'
          AND b.GRP_CODE = 'UG'	    
      )
      LOOP
        INSERT INTO ROA_PST006_M_DATA_ROLL_12M_NEW
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR06 ,REC1.D_ACC, REC1.AMOUNT);                 
      END LOOP;
      
  --(3-10) --------  
      STR01 :=  'A02100';
      STR02 :=  'Net Mfg Revenues';
      for REC1 IN (
          SELECT STR01 D_ACC,   sum( amount ) AMOUNT FROM PNL_MSA001_EM_DATA a
		  WHERE
          YYYY = In_YYYY AND MONTH = In_MM AND acct_id<> ' ' AND ACCT_NAME = STR02
          AND ( GRP_CODE = 'UG' OR GRP_CODE = 'USI' )    
      )
      LOOP
        INSERT INTO ROA_PST006_M_DATA_ROLL_12M_NEW
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR06 ,REC1.D_ACC, (REC1.AMOUNT * 1000 ));                 
      END LOOP; 
      
  --(3-11) --------  
      STR01 :=  'A02200';
      STR02 :=  '07.050';
      for REC1 IN (
          SELECT STR01 D_ACC,   sum( amount ) AMOUNT FROM PNL_MSA001_EM_DATA WHERE
          YYYY = In_YYYY AND MONTH = In_MM AND acct_id <> ' ' AND acct_id <= STR02
          AND ( GRP_CODE = 'UG' OR GRP_CODE = 'USI' )      
      )
      LOOP
        INSERT INTO ROA_PST006_M_DATA_ROLL_12M_NEW
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR06 ,REC1.D_ACC, (REC1.AMOUNT * 1000 ));                 
      END LOOP;       

  --(3-12) --------  
      STR01 :=  'A04000';
      for REC1 IN (
          SELECT STR01 D_ACC,  sum( UPL_AMT_LOC  * EX_RATE_TWD ) AMOUNT FROM ROA_PST004_FIXED_ASSETS a
		  JOIN PNL_MAP006_SITE_MAPPING b ON a.COMPANY_CODE = b.COMPANY_CODE
		  WHERE
          PERIOD = In_PERIOD AND S_SEQ IN ( '10' ) AND TYPE ='1'
		  AND b.GRP_CODE = 'UG'	 
              
      )
      LOOP
        INSERT INTO ROA_PST006_M_DATA_ROLL_12M_NEW
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR06 ,REC1.D_ACC, REC1.AMOUNT);                 
      END LOOP;

  --(3-13) --------  
      STR01 :=  'A03600';
      for REC1 IN (
          SELECT STR01 D_ACC,  sum( UPL_AMT_LOC  * EX_RATE_TWD ) AMOUNT FROM ROA_PST004_FIXED_ASSETS a
		  JOIN PNL_MAP006_SITE_MAPPING b ON a.COMPANY_CODE = b.COMPANY_CODE
		  WHERE
          PERIOD = In_PERIOD AND S_SEQ IN ( '20' ) AND TYPE ='1'
          AND b.GRP_CODE = 'UG'	     
      )
      LOOP
        INSERT INTO ROA_PST006_M_DATA_ROLL_12M_NEW
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR06 ,REC1.D_ACC, REC1.AMOUNT);                 
      END LOOP;

  --(3-13) --------  
      STR01 :=  'A04100';
      for REC1 IN (
          SELECT STR01 D_ACC,  sum( UPL_AMT_LOC  * EX_RATE_TWD ) AMOUNT FROM ROA_PST004_FIXED_ASSETS a
		  JOIN PNL_MAP006_SITE_MAPPING b ON a.COMPANY_CODE = b.COMPANY_CODE
		  WHERE
          PERIOD = In_PERIOD AND S_SEQ IN ( '20' ) AND TYPE ='1'
          AND b.GRP_CODE = 'UG'	     
      )
      LOOP
        INSERT INTO ROA_PST006_M_DATA_ROLL_12M_NEW
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR06 ,REC1.D_ACC, REC1.AMOUNT);                 
      END LOOP;
                
  --(3-14) --------  
      STR01 :=  'A04200';
      for REC1 IN (
          SELECT STR01 D_ACC,  sum( UPL_AMT_LOC  * EX_RATE_TWD ) AMOUNT FROM ROA_PST004_FIXED_ASSETS a
		  JOIN PNL_MAP006_SITE_MAPPING b ON a.COMPANY_CODE = b.COMPANY_CODE
		  WHERE
          PERIOD = In_PERIOD AND S_SEQ IN ( '30','40' ) AND TYPE ='1'
          AND b.GRP_CODE = 'UG'	     
      )
      LOOP
        INSERT INTO ROA_PST006_M_DATA_ROLL_12M_NEW
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR06 ,REC1.D_ACC, REC1.AMOUNT);                 
      END LOOP;             

  --(3-15) --------  
      STR01 :=  'A03800';
      for REC1 IN (
          SELECT STR01 D_ACC,  sum( UPL_AMT_LOC  * EX_RATE_TWD ) AMOUNT FROM ROA_PST004_FIXED_ASSETS a
		  JOIN PNL_MAP006_SITE_MAPPING b ON a.COMPANY_CODE = b.COMPANY_CODE
		  WHERE
          PERIOD = In_PERIOD AND S_SEQ IN ( '20','30','40' ) AND TYPE ='1'
          AND b.GRP_CODE = 'UG'	     
      )
      LOOP
        INSERT INTO ROA_PST006_M_DATA_ROLL_12M_NEW
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR06 ,REC1.D_ACC, REC1.AMOUNT);                 
      END LOOP; 

  --(3-16_2) --------  
      STR01 :=  'A03400';
      for REC1 IN (
          select (a.AMOUNT1 - b.AMOUNT2 + c.AMOUNT3 ) AMOUNT from
          ( select SUM(a.upl_amt * b.WEIGHTS ) AMOUNT1 from ROA_UPL003_BS_DATA a 
		  join ROA_MAP002_BS_ACCOUNT b on b.S_DESC = a.S_DESC 
		  where b.account = 'Total assets' and PERIOD = In_PERIOD
          and a.company_code = STR06 
          ) a,
          (SELECT SUM( D_AMOUNT ) AMOUNT2
          FROM ROA_PST006_M_DATA_ROLL_12M_NEW
          WHERE PERIOD = In_PERIOD
          AND D_KIND = In_KIND AND D_ACC in ( 'A01000','A01100','A01200')
          ) b,
          (SELECT SUM( D_AMOUNT ) AMOUNT3
          FROM ROA_PST006_M_DATA_ROLL_12M_NEW
          WHERE PERIOD = In_PERIOD
          AND D_KIND = In_KIND AND D_ACC in ( 'A04000','A04100','A04200')
          ) c                         
      )
      LOOP
        INSERT INTO ROA_PST006_M_DATA_ROLL_12M_NEW
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR06 ,STR01, REC1.AMOUNT);                 
      END LOOP;

    --(3-16_3) --------  
      STR01 :=  'A04400';
      for REC1 IN (              
          SELECT SUM( D_AMOUNT ) AMOUNT
          FROM ROA_PST006_M_DATA_ROLL_12M_NEW
          WHERE PERIOD = In_PERIOD
          AND D_KIND = In_KIND AND D_ACC in ( 'A00200','A00800','A00900','A01000','A01100','A01200')
      )
      LOOP
        INSERT INTO ROA_PST006_M_DATA_ROLL_12M_NEW
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR06 ,STR01, REC1.AMOUNT);              
      END LOOP;

    --(3-16_4) --------  
      STR01 :=  'A04600';
      for REC1 IN (              
          SELECT SUM( D_AMOUNT ) AMOUNT
          FROM ROA_PST006_M_DATA_ROLL_12M_NEW
          WHERE PERIOD = In_PERIOD
          AND D_KIND = In_KIND AND D_ACC in ( 'A00200','A00800','A00900','A04000','A04100','A04200')

      )
      LOOP
        INSERT INTO ROA_PST006_M_DATA_ROLL_12M_NEW
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR06 ,STR01, REC1.AMOUNT);                  
      END LOOP; 

  --(3-16) --------  
      STR01 :=  'C_NIB_Y_22';
      --STR02 :=  In_YYYY || '01';
      for REC1 IN (
        SELECT (( SUM( D_AMOUNT ) / In_MM2 ) * 12)  AMOUNT
        FROM ROA_PST006_M_DATA_ROLL_12M_NEW
        WHERE PERIOD >= From_PERIOD and  PERIOD <= In_PERIOD
        AND D_KIND = In_KIND AND D_ACC = 'A02200' 
      )
      LOOP
        INSERT INTO ROA_PST006_M_DATA_ROLL_12M_NEW
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND, STR06 ,STR01, REC1.AMOUNT);                 
      END LOOP; 

  --(3-17) --------  
      STR01 :=  'C_SUB_A_14';
      --STR02 :=  In_YYYY || '01';
      for REC1 IN (
        SELECT ( SUM( D_AMOUNT ) / In_MM2 )  AMOUNT
        FROM ROA_PST006_M_DATA_ROLL_12M_NEW
        WHERE PERIOD >= From_PERIOD and  PERIOD <= In_PERIOD
        AND D_KIND = In_KIND AND D_ACC = 'A01400'  
      )
      LOOP
        INSERT INTO ROA_PST006_M_DATA_ROLL_12M_NEW
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND, STR06 ,STR01, REC1.AMOUNT);                 
      END LOOP; 

  --(3-18) --------  
      STR01 :=  'C_EQU_A_17';
      --STR02 :=  In_YYYY || '01';
      for REC1 IN (
        SELECT ( SUM( D_AMOUNT ) / In_MM2 )  AMOUNT
        FROM ROA_PST006_M_DATA_ROLL_12M_NEW
        WHERE PERIOD >= From_PERIOD and  PERIOD <= In_PERIOD
        AND D_KIND = In_KIND AND D_ACC = 'A01700'  
      )
      LOOP
        INSERT INTO ROA_PST006_M_DATA_ROLL_12M_NEW
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND, STR06 ,STR01, REC1.AMOUNT);                 
      END LOOP;

  --(3-19) --------  
      STR01 :=  'C_REV_Y_21';
      --STR02 :=  In_YYYY || '01';
      for REC1 IN (
        SELECT   (( SUM( D_AMOUNT ) / In_MM2 )* 12)  AMOUNT
        FROM ROA_PST006_M_DATA_ROLL_12M_NEW
        WHERE PERIOD >= From_PERIOD and  PERIOD <= In_PERIOD
        AND D_KIND = In_KIND AND D_ACC = 'A02100'  
      )
      LOOP
        INSERT INTO ROA_PST006_M_DATA_ROLL_12M_NEW
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND, STR06 ,STR01, REC1.AMOUNT);                 
      END LOOP;

  --(3-20) --------  
      STR01 :=  'C_SFA_A_10N12';
      --STR02 :=  In_YYYY || '01';
      for REC1 IN (
        SELECT   ( SUM( D_AMOUNT ) / In_MM2 )  AMOUNT
        FROM ROA_PST006_M_DATA_ROLL_12M_NEW
        WHERE PERIOD >= From_PERIOD and  PERIOD <= In_PERIOD
        AND D_KIND = In_KIND AND D_ACC in ( 'A01000', 'A01100', 'A01200')  
      )
      LOOP
        INSERT INTO ROA_PST006_M_DATA_ROLL_12M_NEW
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND, STR06 ,STR01, REC1.AMOUNT);                 
      END LOOP;

  --(3-21) --------  
      STR01 :=  'C_BV1_A_30';
      --STR02 :=  In_YYYY || '01';
      for REC1 IN (
        SELECT ( SUM( D_AMOUNT ) / In_MM2 )  AMOUNT
        FROM ROA_PST006_M_DATA_ROLL_12M_NEW
        WHERE PERIOD >= From_PERIOD and  PERIOD <= In_PERIOD
        AND D_KIND = In_KIND AND D_ACC in ( 'A03000' )  
      )
      LOOP
        INSERT INTO ROA_PST006_M_DATA_ROLL_12M_NEW
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND, STR06 ,STR01, REC1.AMOUNT);                 
      END LOOP;

  --(3-22) --------  
      STR01 :=  'C_BV2_A_32';
      --STR02 :=  In_YYYY || '01';
      for REC1 IN (
        SELECT ( SUM( D_AMOUNT ) / In_MM2 )  AMOUNT
        FROM ROA_PST006_M_DATA_ROLL_12M_NEW
        WHERE PERIOD >= From_PERIOD and  PERIOD <= In_PERIOD
        AND D_KIND = In_KIND AND D_ACC in ( 'A03200' )
      )
      LOOP
        INSERT INTO ROA_PST006_M_DATA_ROLL_12M_NEW
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND, STR06 ,STR01, REC1.AMOUNT);                 
      END LOOP;

  --(3-23) --------  
      STR01 :=  'C_OV1_A_34';
      --STR02 :=  In_YYYY || '01';
      for REC1 IN (
        SELECT ( SUM( D_AMOUNT ) / In_MM2 )  AMOUNT
        FROM ROA_PST006_M_DATA_ROLL_12M_NEW
        WHERE PERIOD >= From_PERIOD and  PERIOD <= In_PERIOD
        AND D_KIND = In_KIND AND D_ACC in ( 'A03400' )  
      )
      LOOP
        INSERT INTO ROA_PST006_M_DATA_ROLL_12M_NEW
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND, STR06 ,STR01, REC1.AMOUNT);                 
      END LOOP;


  --(3-24) --------  
      STR01 :=  'C_OV2_A_36';
      --STR02 :=  In_YYYY || '01';
      for REC1 IN (
        SELECT ( SUM( D_AMOUNT ) / In_MM2 )  AMOUNT
        FROM ROA_PST006_M_DATA_ROLL_12M_NEW
        WHERE PERIOD >= From_PERIOD and  PERIOD <= In_PERIOD
        AND D_KIND = In_KIND AND D_ACC in ( 'A03600' )  
      )
      LOOP
        INSERT INTO ROA_PST006_M_DATA_ROLL_12M_NEW
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND, STR06 ,STR01, REC1.AMOUNT);                 
      END LOOP;

  --(3-25) --------  
      STR01 :=  'C_OV3_A_38';
      --STR02 :=  In_YYYY || '01';
      for REC1 IN (
        SELECT  ( SUM( D_AMOUNT ) / In_MM2 )  AMOUNT
        FROM ROA_PST006_M_DATA_ROLL_12M_NEW
        WHERE PERIOD >= From_PERIOD and  PERIOD <= In_PERIOD
        AND D_KIND = In_KIND AND D_ACC in ( 'A03800' )  
      )
      LOOP
        INSERT INTO ROA_PST006_M_DATA_ROLL_12M_NEW
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND, STR06 ,STR01, REC1.AMOUNT);                 
      END LOOP;
  
  --(3-26) --------  
      STR01 :=  'C_BV3_A_44';
      --STR02 :=  In_YYYY || '01';
      for REC1 IN (
        SELECT  ( SUM( D_AMOUNT ) / In_MM2 )  AMOUNT
        FROM ROA_PST006_M_DATA_ROLL_12M_NEW
        WHERE PERIOD >= From_PERIOD and  PERIOD <= In_PERIOD
        AND D_KIND = In_KIND AND D_ACC in ( 'A04400' )  
      )
      LOOP
        INSERT INTO ROA_PST006_M_DATA_ROLL_12M_NEW
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND, STR06 ,STR01, REC1.AMOUNT);                 
      END LOOP; 
      
  --(3-27) --------  
      STR01 :=  'C_OV4_A_46';
      --STR02 :=  In_YYYY || '01';
      for REC1 IN (
        SELECT  ( SUM( D_AMOUNT ) / In_MM2 )  AMOUNT
        FROM ROA_PST006_M_DATA_ROLL_12M_NEW
        WHERE PERIOD >= From_PERIOD and  PERIOD <= In_PERIOD
        AND D_KIND = In_KIND AND D_ACC in ( 'A04600' )  
      )
      LOOP
        INSERT INTO ROA_PST006_M_DATA_ROLL_12M_NEW
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND, STR06 ,STR01, REC1.AMOUNT);                 
      END LOOP;  
              
      delete  FROM   ROA_PST006_M_DATA_ROLL_12M_NEW WHERE D_KEY = STR06 AND D_KIND <> In_KIND AND PERIOD = In_PERIOD;
      COMMIT;  
         
  
  
  /*****************************************************************************************
      (4)Kind = 10-USI-COMMON
  ************************************************************************************ */
  ELSIF In_KIND IN ('10') THEN    
    In_KIND := '10'; 
    USI_KIND := '09';
    PC_KIND := '01';
    STR06 :=  'UG'; 
    STR08 :=  'USI-COMMON';
 
    
  --(4-26) --------      
      STR01 :=  'A00200';
      for REC1 IN (
          
          --select SUM(a.upl_amt * b.WEIGHTS ) Amount from ROA_UPL003_BS_DATA a join ROA_MAP002_BS_ACCOUNT b
          --on b.S_DESC = a.S_DESC where b.account = 'Cash' and PERIOD = In_PERIOD 
          --and company_code = STR06  
          --����PC cash 20180926
          --����9�}�YPC 20180927
          
           select (T1.AMOUNT1-T2.AMOUNT2) AMOUNT from
          (select SUM(a.upl_amt * b.WEIGHTS ) AMOUNT1 from ROA_UPL003_BS_DATA a 
		  join ROA_MAP002_BS_ACCOUNT b on b.S_DESC = a.S_DESC 
		  where b.account = 'Cash' and PERIOD = In_PERIOD 
          and a.company_code = STR06 ) T1,
          ( SELECT  SUM( D_AMOUNT ) AMOUNT2 FROM ROA_PST006_M_DATA_ROLL_12M_NEW WHERE PERIOD = In_PERIOD
          AND D_KIND = PC_KIND AND D_ACC in ( 'A00200') and D_KEY not like '000000009%' )  T2                       
      )
      LOOP
        INSERT INTO ROA_PST006_M_DATA_ROLL_12M_NEW
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR08 ,STR01, REC1.AMOUNT);                 
      END LOOP;  
      
  --(4-27) --------      
      STR01 :=  'A00400';
      for REC1 IN (
          select SUM(a.upl_amt * b.WEIGHTS ) Amount from ROA_UPL003_BS_DATA a 
		  join ROA_MAP002_BS_ACCOUNT b on b.S_DESC = a.S_DESC  
		  where b.account = 'Financial Asset' and PERIOD = In_PERIOD 
          and a.company_code = STR06                 
      )
      LOOP
        INSERT INTO ROA_PST006_M_DATA_ROLL_12M_NEW
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR08 ,STR01, REC1.AMOUNT);                 
      END LOOP;

  --(4-28) --------      
      STR01 :=  'A00500';
      for REC1 IN (
          select SUM(a.upl_amt * b.WEIGHTS ) Amount from ROA_UPL003_BS_DATA a 
		  join ROA_MAP002_BS_ACCOUNT b on b.S_DESC = a.S_DESC      
		  where b.account = 'Others Receivable' and PERIOD = In_PERIOD    
          and a.company_code = STR06               
      )
      LOOP
        INSERT INTO ROA_PST006_M_DATA_ROLL_12M_NEW
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR08 ,STR01, REC1.AMOUNT);                 
      END LOOP;
      
  --(4-29) --------      
      STR01 :=  'A00600';
      for REC1 IN (
          select SUM(a.upl_amt * b.WEIGHTS ) Amount from ROA_UPL003_BS_DATA a 
		  join ROA_MAP002_BS_ACCOUNT b on b.S_DESC = a.S_DESC    
		  where b.account = 'Deferred Tax' and PERIOD = In_PERIOD  
          and a.company_code = STR06               
      )
      LOOP
        INSERT INTO ROA_PST006_M_DATA_ROLL_12M_NEW
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR08 ,STR01, REC1.AMOUNT);                 
      END LOOP;      
      
  --(4-30) --------      
      STR01 :=  'A00700';
      for REC1 IN (
          select SUM(a.upl_amt * b.WEIGHTS ) Amount from ROA_UPL003_BS_DATA a 
		  join ROA_MAP002_BS_ACCOUNT b on b.S_DESC = a.S_DESC   
		  where b.account = 'Deferred charges' and PERIOD = In_PERIOD
          and a.company_code = STR06                
      )
      LOOP
        INSERT INTO ROA_PST006_M_DATA_ROLL_12M_NEW
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR08 ,STR01, REC1.AMOUNT);                 
      END LOOP;
     
  --(4-31) --------     
      STR01 :=  'A01400';
      for REC1 IN ( 
          select b.D_AMOUNT-a.AMOUNT AMOUNT from
          ( SELECT  SUM( D_AMOUNT ) AMOUNT FROM ROA_PST006_M_DATA_ROLL_12M_NEW WHERE PERIOD = In_PERIOD
          AND D_KIND = D_KIND AND D_ACC in ( 'A00200','A00300','A00400','A00500','A00600', 'A00700',
                                             'A00800','A00900','A01000','A01100','A01200', 'A01300')
          and D_KEY IN  ( select PC FROM ROA_UPL009_EXCLUDE_PC_LISTS WHERE D_KIND = In_KIND ) ) a ,
          ( select SUM(a.upl_amt * b.WEIGHTS ) D_AMOUNT from ROA_UPL003_BS_DATA a 
		  join ROA_MAP002_BS_ACCOUNT b on b.S_DESC = a.S_DESC 
		  where b.account = 'Total assets' and PERIOD = In_PERIOD    
          and a.company_code = STR06 ) b       
          --select b.D_AMOUNT-a.AMOUNT AMOUNT from
          --( SELECT  SUM( D_AMOUNT ) AMOUNT FROM ROA_PST006_M_DATA_ROLL_12M_NEW WHERE PERIOD = In_PERIOD
          --AND D_KIND = PC_KIND AND D_ACC = STR01
          --and D_KEY IN  ( select PC FROM ROA_UPL009_EXCLUDE_PC_LISTS WHERE D_KIND = In_KIND ) ) a ,
          --( SELECT  SUM( D_AMOUNT ) AMOUNT FROM ROA_PST006_M_DATA_ROLL_12M_NEW WHERE PERIOD = In_PERIOD
          --AND D_KIND = USI_KIND AND D_ACC = STR01 ) b                
      )
      LOOP
        INSERT INTO ROA_PST006_M_DATA_ROLL_12M_NEW
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR08 ,STR01, REC1.AMOUNT);                 
      END LOOP;

  --(4-32) --------      
      STR01 :=  'A01700';
      for REC1 IN (
          select b.D_AMOUNT-a.AMOUNT AMOUNT from
          ( SELECT  SUM( D_AMOUNT ) AMOUNT FROM ROA_PST006_M_DATA_ROLL_12M_NEW WHERE PERIOD = In_PERIOD
          AND D_KIND = D_KIND AND D_ACC = STR01
          and D_KEY IN  ( select PC FROM ROA_UPL009_EXCLUDE_PC_LISTS WHERE D_KIND = In_KIND ) ) a ,
          ( select SUM(a.upl_amt * b.WEIGHTS ) D_AMOUNT from ROA_UPL003_BS_DATA a 
		  join ROA_MAP002_BS_ACCOUNT b on b.S_DESC = a.S_DESC 
		  where b.account = 'Equity' and PERIOD = In_PERIOD       
          and a.company_code = STR06 ) b                 
      )
      LOOP
        INSERT INTO ROA_PST006_M_DATA_ROLL_12M_NEW
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR08 ,STR01, REC1.AMOUNT);                 
      END LOOP;   
      
   --(4-33) --------      
      STR01 :=  'A01800';
      for REC1 IN (              
          select (Amount1-Amount2) Amount from
          (
          select SUM(a.upl_amt * b.WEIGHTS ) Amount1 from ROA_UPL003_BS_DATA a 
		  join ROA_MAP002_BS_ACCOUNT b on b.S_DESC = a.S_DESC 
		  where b.account = 'Total liabilities' and PERIOD = In_PERIOD 
          and a.company_code = STR06  ),
          (
          select SUM(a.upl_amt * b.WEIGHTS ) Amount2 from ROA_UPL003_BS_DATA a 
		  join ROA_MAP002_BS_ACCOUNT b on b.S_DESC = a.S_DESC
		  JOIN PNL_MAP006_SITE_MAPPING c ON a.COMPANY_CODE = c.COMPANY_CODE 
		  where b.account = 'AP-3rd' and PERIOD = In_PERIOD
		  AND c.GRP_CODE = 'UG'
          and a.company_code = STR06   )


      )
      LOOP
        INSERT INTO ROA_PST006_M_DATA_ROLL_12M_NEW
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR08 ,STR01, REC1.AMOUNT);                 
      END LOOP;        
    
  --(4-01) --------  
  --    
      STR01 :=  'A00800';
      for REC1 IN ( 
          select b.D_AMOUNT-a.AMOUNT AMOUNT from
          ( SELECT sum( upl_amt ) AMOUNT FROM ROA_UPL004_AR_AP_INV_DATA a
		    JOIN PNL_MAP006_SITE_MAPPING b ON a.COMPANY_CODE = b.COMPANY_CODE		    			
		    WHERE
            PERIOD = In_PERIOD AND TYPE IN ( 'AR' )  
			AND b.GRP_CODE = 'UG' 
			AND  ( PC IN  ( select PC FROM ROA_UPL009_EXCLUDE_PC_LISTS WHERE D_KIND = In_KIND ) ) ) a ,
          ( select D_AMOUNT from ROA_PST006_M_DATA_ROLL_12M_NEW where period = In_PERIOD
          and D_KIND = USI_KIND and D_KEY = STR06 and D_ACC = STR01) b              
      )
      LOOP
        INSERT INTO ROA_PST006_M_DATA_ROLL_12M_NEW
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR08 ,STR01, REC1.AMOUNT);                 
      END LOOP;    
      
--(4-02) --------  
      STR01 :=  'A00900';
      for REC1 IN (  
          select b.D_AMOUNT-a.AMOUNT AMOUNT from
          ( SELECT sum( upl_amt ) AMOUNT FROM ROA_UPL004_AR_AP_INV_DATA a
		    JOIN PNL_MAP006_SITE_MAPPING b ON a.COMPANY_CODE = b.COMPANY_CODE
			WHERE
            PERIOD = In_PERIOD AND TYPE IN  ( 'INV', 'ADJ INV' ) 
			AND b.GRP_CODE = 'UG'
			AND ( PC IN  ( select PC FROM ROA_UPL009_EXCLUDE_PC_LISTS WHERE D_KIND = In_KIND ) )  ) a ,
          ( select D_AMOUNT from ROA_PST006_M_DATA_ROLL_12M_NEW where period = In_PERIOD
          and D_KIND = USI_KIND and D_KEY = STR06 and D_ACC = STR01) b             
      )
      LOOP
        INSERT INTO ROA_PST006_M_DATA_ROLL_12M_NEW
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR08 ,STR01, REC1.AMOUNT);                  
      END LOOP; 
  --(4-03) --------  
      STR01 :=  'A01500';
      for REC1 IN (       
          select b.D_AMOUNT-a.AMOUNT AMOUNT from
          ( SELECT sum( upl_amt ) AMOUNT FROM ROA_UPL004_AR_AP_INV_DATA a
		    JOIN PNL_MAP006_SITE_MAPPING b ON a.COMPANY_CODE = b.COMPANY_CODE
		    WHERE
            PERIOD = In_PERIOD AND TYPE IN  ( 'AP' ) 
			AND b.GRP_CODE = 'UG'
			AND ( PC IN  ( select PC FROM ROA_UPL009_EXCLUDE_PC_LISTS WHERE D_KIND = In_KIND ) )  ) a ,
          ( select SUM(a.upl_amt * b.WEIGHTS ) D_AMOUNT from ROA_UPL003_BS_DATA a join ROA_MAP002_BS_ACCOUNT b
          on b.S_DESC = a.S_DESC where b.account = 'AP-3rd' and PERIOD = In_PERIOD   
          and company_code = STR06 ) b       
      )
      LOOP
        INSERT INTO ROA_PST006_M_DATA_ROLL_12M_NEW
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR08 ,STR01, REC1.AMOUNT);                   
      END LOOP;        

  --(4-04) --------  
      STR01 :=  'A01000';
      for REC1 IN (    
          select b.D_AMOUNT-a.AMOUNT AMOUNT from
          ( SELECT sum( UPL_AMT_LOC  * EX_RATE_TWD ) AMOUNT FROM ROA_PST004_FIXED_ASSETS a
		    JOIN PNL_MAP006_SITE_MAPPING b ON a.COMPANY_CODE = b.COMPANY_CODE
		    WHERE
            PERIOD = In_PERIOD AND S_SEQ IN ( '10' ) AND TYPE ='2' 
			AND b.GRP_CODE = 'UG'
			AND ( PC IN  ( select PC FROM ROA_UPL009_EXCLUDE_PC_LISTS WHERE D_KIND = In_KIND ) ) ) a, 
          ( select D_AMOUNT from ROA_PST006_M_DATA_ROLL_12M_NEW where period = In_PERIOD
          and D_KIND = USI_KIND and D_KEY = STR06 and D_ACC = STR01 ) b          
            
      )
      LOOP
        INSERT INTO ROA_PST006_M_DATA_ROLL_12M_NEW
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR08 ,STR01, REC1.AMOUNT);                  
      END LOOP; 

  --(4-05) --------  
      STR01 :=  'A01100';
      for REC1 IN (  
          select b.D_AMOUNT-a.AMOUNT AMOUNT from
          ( SELECT sum( UPL_AMT_LOC  * EX_RATE_TWD ) AMOUNT FROM ROA_PST004_FIXED_ASSETS a
		    JOIN PNL_MAP006_SITE_MAPPING b ON a.COMPANY_CODE = b.COMPANY_CODE
		    WHERE
            PERIOD = In_PERIOD AND S_SEQ IN ( '20' ) AND TYPE ='2' 
			AND b.GRP_CODE = 'UG'
			AND ( PC IN  ( select PC FROM ROA_UPL009_EXCLUDE_PC_LISTS WHERE D_KIND = In_KIND ) ) ) a, 
          ( select D_AMOUNT from ROA_PST006_M_DATA_ROLL_12M_NEW where period = In_PERIOD
          and D_KIND = USI_KIND and D_KEY = STR06 and D_ACC = STR01 ) b    
      )
      LOOP
        INSERT INTO ROA_PST006_M_DATA_ROLL_12M_NEW
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR08 ,STR01, REC1.AMOUNT);               
      END LOOP;    

  --(4-06) --------  
      STR01 :=  'A03000';
      for REC1 IN (  
          select b.D_AMOUNT-a.AMOUNT AMOUNT from 
          ( SELECT STR01 D_ACC,  sum( UPL_AMT_LOC  * EX_RATE_TWD ) AMOUNT FROM ROA_PST004_FIXED_ASSETS a
		    JOIN PNL_MAP006_SITE_MAPPING b ON a.COMPANY_CODE = b.COMPANY_CODE
		    WHERE
            PERIOD = In_PERIOD AND S_SEQ IN ( '20' ) AND TYPE ='2' 
			AND b.GRP_CODE = 'UG'
			AND ( PC IN  ( select PC FROM ROA_UPL009_EXCLUDE_PC_LISTS WHERE D_KIND = In_KIND ) ) ) a, 
          ( select D_AMOUNT from ROA_PST006_M_DATA_ROLL_12M_NEW where period = In_PERIOD
          and D_KIND = USI_KIND and D_KEY = STR06 and D_ACC = STR01 ) b   
      )
      LOOP
        INSERT INTO ROA_PST006_M_DATA_ROLL_12M_NEW
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR08 ,STR01, REC1.AMOUNT);                
      END LOOP;  
       

  --(4-07) --------  
      STR01 :=  'A01200';
      for REC1 IN (
          select b.D_AMOUNT-a.AMOUNT AMOUNT from
          ( SELECT sum( UPL_AMT_LOC  * EX_RATE_TWD ) AMOUNT FROM ROA_PST004_FIXED_ASSETS a
		    JOIN PNL_MAP006_SITE_MAPPING b ON a.COMPANY_CODE = b.COMPANY_CODE
		    WHERE
            PERIOD = In_PERIOD AND S_SEQ IN ( '30','40' ) AND TYPE ='2' 
			AND b.GRP_CODE = 'UG'
			AND ( PC IN  ( select PC FROM ROA_UPL009_EXCLUDE_PC_LISTS WHERE D_KIND = In_KIND ) )  ) a, 
          ( select D_AMOUNT from ROA_PST006_M_DATA_ROLL_12M_NEW where period = In_PERIOD
          and D_KIND = USI_KIND and D_KEY = STR06 and D_ACC = STR01 ) b  
      )
      LOOP
        INSERT INTO ROA_PST006_M_DATA_ROLL_12M_NEW
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR08 ,STR01, REC1.AMOUNT);                
      END LOOP;  
           
  --(4-08) --------  
      STR01 :=  'A03200';
      for REC1 IN (  
          select b.D_AMOUNT-a.AMOUNT AMOUNT from
          ( SELECT sum( UPL_AMT_LOC  * EX_RATE_TWD ) AMOUNT FROM ROA_PST004_FIXED_ASSETS a
		    JOIN PNL_MAP006_SITE_MAPPING b ON a.COMPANY_CODE = b.COMPANY_CODE
		    WHERE
            PERIOD = In_PERIOD AND S_SEQ IN ( '20','30','40' ) AND TYPE ='2'  
			AND b.GRP_CODE = 'UG'
			AND ( PC IN  ( select PC FROM ROA_UPL009_EXCLUDE_PC_LISTS WHERE D_KIND = In_KIND ) ) ) a, 
          ( select D_AMOUNT from ROA_PST006_M_DATA_ROLL_12M_NEW where period = In_PERIOD
          and D_KIND = USI_KIND and D_KEY = STR06 and D_ACC = STR01 ) b     
      )
      LOOP
        INSERT INTO ROA_PST006_M_DATA_ROLL_12M_NEW
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR08 ,STR01, REC1.AMOUNT);                
      END LOOP;      

  --(4-09) --------  
      STR01 :=  'A02900';
      for REC1 IN ( 
          select b.D_AMOUNT-a.AMOUNT AMOUNT from
          ( SELECT sum( UPL_AMT_LOC  * EX_RATE_TWD ) AMOUNT FROM ROA_PST004_FIXED_ASSETS a
		    JOIN PNL_MAP006_SITE_MAPPING b ON a.COMPANY_CODE = b.COMPANY_CODE
		    WHERE
            PERIOD = In_PERIOD AND S_SEQ IN ( '10','20','30','40' ) AND TYPE ='2' 
		    AND b.GRP_CODE = 'UG'
		    AND ( PC IN  ( select PC FROM ROA_UPL009_EXCLUDE_PC_LISTS WHERE D_KIND = In_KIND ) )) a, 
          ( select D_AMOUNT from ROA_PST006_M_DATA_ROLL_12M_NEW where period = In_PERIOD
          and D_KIND = USI_KIND and D_KEY = STR06 and D_ACC = STR01 ) b    
      )
      LOOP
        INSERT INTO ROA_PST006_M_DATA_ROLL_12M_NEW
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR08 ,STR01, REC1.AMOUNT);                
      END LOOP;
      
  --(4-10) --------  
      STR01 :=  'A02100';
      STR02 :=  'Net Mfg Revenues';
      for REC1 IN (  
          select a.amount1 - b.amount2 amount from
          ( SELECT sum( amount ) AMOUNT1  FROM PNL_MSA001_EM_DATA WHERE
          YYYY = In_YYYY AND MONTH = In_MM AND acct_id <> ' ' AND ACCT_NAME = STR02 
		  AND ( GRP_CODE = 'UG' OR GRP_CODE = 'USI' ) ) a,
          ( SELECT sum( amount ) AMOUNT2  FROM PNL_MSA001_EM_DATA WHERE
          YYYY = In_YYYY AND MONTH = In_MM AND acct_id <> ' ' AND ACCT_NAME = STR02 
		  AND ( GRP_CODE = 'UG' OR GRP_CODE = 'USI' ) AND ( PC IN  ( select SUBSTR(PC, 9, 2) FROM ROA_UPL009_EXCLUDE_PC_LISTS WHERE D_KIND = In_KIND ) ) ) b
      )
      LOOP
        INSERT INTO ROA_PST006_M_DATA_ROLL_12M_NEW
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR08 ,STR01, (REC1.AMOUNT * 1000 ));                
      END LOOP; 
      
  --(4-11) --------  
      STR01 :=  'A02200';
      STR02 :=  '07.050';
      for REC1 IN (        
          select a.amount1 - b.amount2 amount from
          ( SELECT sum( amount ) AMOUNT1  FROM PNL_MSA001_EM_DATA WHERE
          YYYY = In_YYYY AND MONTH = In_MM AND acct_id <> ' ' AND acct_id <= STR02 
		  AND ( GRP_CODE = 'UG' OR GRP_CODE = 'USI' ) ) a,
          ( SELECT sum( amount ) AMOUNT2  FROM PNL_MSA001_EM_DATA WHERE
          YYYY = In_YYYY AND MONTH = In_MM AND acct_id <> ' ' AND acct_id <= STR02 
		  AND ( GRP_CODE = 'UG' OR GRP_CODE = 'USI' ) AND ( PC IN  ( select SUBSTR(PC, 9, 2) FROM ROA_UPL009_EXCLUDE_PC_LISTS WHERE D_KIND = In_KIND ) ) ) b             
      )
      LOOP
        INSERT INTO ROA_PST006_M_DATA_ROLL_12M_NEW
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR08 ,STR01, (REC1.AMOUNT * 1000) );                 
      END LOOP;       

  --(4-12) --------  
      STR01 :=  'A04000';
      for REC1 IN (
          select b.D_AMOUNT-a.AMOUNT AMOUNT from
          ( SELECT sum( UPL_AMT_LOC  * EX_RATE_TWD ) AMOUNT FROM ROA_PST004_FIXED_ASSETS a
		  JOIN PNL_MAP006_SITE_MAPPING b ON a.COMPANY_CODE = b.COMPANY_CODE
		  WHERE
          PERIOD = In_PERIOD AND S_SEQ IN ( '10' ) AND TYPE ='1' 
		  AND b.GRP_CODE = 'UG'
		  AND ( PC IN  ( select PC FROM ROA_UPL009_EXCLUDE_PC_LISTS WHERE D_KIND = In_KIND ) ) ) a, 
          ( select D_AMOUNT from ROA_PST006_M_DATA_ROLL_12M_NEW where period = In_PERIOD
          and D_KIND = USI_KIND and D_KEY = STR06 and D_ACC = STR01 ) b     
      )
      LOOP
        INSERT INTO ROA_PST006_M_DATA_ROLL_12M_NEW
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR08 ,STR01, REC1.AMOUNT);                 
      END LOOP;

  --(4-13) --------  
      STR01 :=  'A03600';
      for REC1 IN ( 
          select b.D_AMOUNT-a.AMOUNT AMOUNT from
          ( SELECT sum( UPL_AMT_LOC  * EX_RATE_TWD ) AMOUNT FROM ROA_PST004_FIXED_ASSETS a
		  JOIN PNL_MAP006_SITE_MAPPING b ON a.COMPANY_CODE = b.COMPANY_CODE
		  WHERE
          PERIOD = In_PERIOD AND S_SEQ IN ( '20' ) AND TYPE ='1' 
		  AND b.GRP_CODE = 'UG'
		  AND ( PC IN  ( select PC FROM ROA_UPL009_EXCLUDE_PC_LISTS WHERE D_KIND = In_KIND ) ) ) a, 
          ( select D_AMOUNT from ROA_PST006_M_DATA_ROLL_12M_NEW where period = In_PERIOD
          and D_KIND = USI_KIND and D_KEY = STR06 and D_ACC = STR01 ) b     
      )
      LOOP
        INSERT INTO ROA_PST006_M_DATA_ROLL_12M_NEW
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR08 ,STR01, REC1.AMOUNT);                 
      END LOOP;

  --(4-13) --------  
      STR01 :=  'A04100';
      for REC1 IN (
          select b.D_AMOUNT-a.AMOUNT AMOUNT from
          ( SELECT sum( UPL_AMT_LOC  * EX_RATE_TWD ) AMOUNT FROM ROA_PST004_FIXED_ASSETS a
		  JOIN PNL_MAP006_SITE_MAPPING b ON a.COMPANY_CODE = b.COMPANY_CODE
		  WHERE
          PERIOD = In_PERIOD AND S_SEQ IN ( '20' ) AND TYPE ='1' 
		  AND b.GRP_CODE = 'UG'
		  AND ( PC IN  ( select PC FROM ROA_UPL009_EXCLUDE_PC_LISTS WHERE D_KIND = In_KIND ) ) ) a, 
          ( select D_AMOUNT from ROA_PST006_M_DATA_ROLL_12M_NEW where period = In_PERIOD
          and D_KIND = USI_KIND and D_KEY = STR06 and D_ACC = STR01 ) b               
      )
      LOOP
        INSERT INTO ROA_PST006_M_DATA_ROLL_12M_NEW
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR08 ,STR01, REC1.AMOUNT);               
      END LOOP;
                
  --(4-14) --------  
      STR01 :=  'A04200';
      for REC1 IN (   
          select b.D_AMOUNT-a.AMOUNT AMOUNT from
          ( SELECT sum( UPL_AMT_LOC  * EX_RATE_TWD ) AMOUNT FROM ROA_PST004_FIXED_ASSETS a
		  JOIN PNL_MAP006_SITE_MAPPING b ON a.COMPANY_CODE = b.COMPANY_CODE
		  WHERE
          PERIOD = In_PERIOD AND S_SEQ IN ( '30','40' ) AND TYPE ='1'  
		  AND b.GRP_CODE = 'UG'
		  AND ( PC IN  ( select PC FROM ROA_UPL009_EXCLUDE_PC_LISTS WHERE D_KIND = In_KIND ) )) a, 
          ( select D_AMOUNT from ROA_PST006_M_DATA_ROLL_12M_NEW where period = In_PERIOD
          and D_KIND = USI_KIND and D_KEY = STR06 and D_ACC = STR01 ) b   
      )
      LOOP
        INSERT INTO ROA_PST006_M_DATA_ROLL_12M_NEW
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR08 ,STR01, REC1.AMOUNT);               
      END LOOP;             

  --(4-15) --------  
      STR01 :=  'A03800';
      for REC1 IN ( 
          select b.D_AMOUNT-a.AMOUNT AMOUNT from
          ( SELECT sum( UPL_AMT_LOC  * EX_RATE_TWD ) AMOUNT FROM ROA_PST004_FIXED_ASSETS a
		  JOIN PNL_MAP006_SITE_MAPPING b ON a.COMPANY_CODE = b.COMPANY_CODE
		  WHERE
          PERIOD = In_PERIOD AND S_SEQ IN ( '20','30','40' ) AND TYPE ='1'  
		  AND b.GRP_CODE = 'UG'
		  AND ( PC IN  ( select PC FROM ROA_UPL009_EXCLUDE_PC_LISTS WHERE D_KIND = In_KIND ) )) a,
          ( select D_AMOUNT from ROA_PST006_M_DATA_ROLL_12M_NEW where period = In_PERIOD
          and D_KIND = USI_KIND and D_KEY = STR06 and D_ACC = STR01 ) b             
      )
      LOOP
        INSERT INTO ROA_PST006_M_DATA_ROLL_12M_NEW
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR08 ,STR01, REC1.AMOUNT);                
      END LOOP; 

  --(4-15_2) --------       
      STR01 :=  'A03400';
      for REC1 IN (
          select b.D_AMOUNT-a.AMOUNT AMOUNT from
          ( SELECT SUM( D_AMOUNT )  AMOUNT FROM ROA_PST006_M_DATA_ROLL_12M_NEW
          WHERE PERIOD = In_PERIOD 
          AND D_KIND = PC_KIND AND D_ACC in ( 'A03400' ) AND D_KEY IN  ( select PC FROM ROA_UPL009_EXCLUDE_PC_LISTS WHERE D_KIND = In_KIND ) ) a ,
          ( SELECT SUM( D_AMOUNT )  D_AMOUNT FROM ROA_PST006_M_DATA_ROLL_12M_NEW
          WHERE PERIOD = In_PERIOD 
          AND D_KIND = USI_KIND AND D_ACC in ( 'A03400' ) ) b                 
      )
      LOOP
        INSERT INTO ROA_PST006_M_DATA_ROLL_12M_NEW
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR08 ,STR01, REC1.AMOUNT);                 
      END LOOP;                   

  --(4-16) --------  
      STR01 :=  'C_NIB_Y_22';
      --STR02 :=  In_YYYY || '01';
      for REC1 IN (  
         select b.D_AMOUNT-a.D_AMOUNT AMOUNT from       
         ( select SUM(D_AMOUNT) D_AMOUNT from ROA_PST006_M_DATA_ROLL_12M_NEW where period = In_PERIOD
         and D_KIND = PC_KIND and D_KEY IN  ( select PC FROM ROA_UPL009_EXCLUDE_PC_LISTS WHERE D_KIND = In_KIND ) and D_ACC = STR01 ) a,      
         ( select D_AMOUNT from ROA_PST006_M_DATA_ROLL_12M_NEW where period = In_PERIOD
         and D_KIND = USI_KIND and D_KEY = STR06 and D_ACC = STR01 ) b
  
      )
      LOOP
        INSERT INTO ROA_PST006_M_DATA_ROLL_12M_NEW
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR08 ,STR01, REC1.AMOUNT);                 
      END LOOP; 

  --(4-17) --------  
      STR01 :=  'C_SUB_A_14';
      --STR02 :=  In_YYYY || '01';
      for REC1 IN (  
         select b.D_AMOUNT-a.D_AMOUNT AMOUNT from       
         ( select SUM(D_AMOUNT) D_AMOUNT from ROA_PST006_M_DATA_ROLL_12M_NEW where period = In_PERIOD
         and D_KIND = PC_KIND and D_KEY IN  ( select PC FROM ROA_UPL009_EXCLUDE_PC_LISTS WHERE D_KIND = In_KIND ) and D_ACC = STR01 ) a,      
         ( select D_AMOUNT from ROA_PST006_M_DATA_ROLL_12M_NEW where period = In_PERIOD
         and D_KIND = USI_KIND and D_KEY = STR06 and D_ACC = STR01 ) b
  
      )
      LOOP
        INSERT INTO ROA_PST006_M_DATA_ROLL_12M_NEW
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR08 ,STR01, REC1.AMOUNT);                 
      END LOOP; 

  --(4-18) --------  
      STR01 :=  'C_EQU_A_17';
      --STR02 :=  In_YYYY || '01';
      for REC1 IN (  
         select b.D_AMOUNT-a.D_AMOUNT AMOUNT from       
         ( select SUM(D_AMOUNT) D_AMOUNT from ROA_PST006_M_DATA_ROLL_12M_NEW where period = In_PERIOD
         and D_KIND = PC_KIND and D_KEY IN  ( select PC FROM ROA_UPL009_EXCLUDE_PC_LISTS WHERE D_KIND = In_KIND ) and D_ACC = STR01 ) a,      
         ( select D_AMOUNT from ROA_PST006_M_DATA_ROLL_12M_NEW where period = In_PERIOD
         and D_KIND = USI_KIND and D_KEY = STR06 and D_ACC = STR01 ) b
  
      )
      LOOP
        INSERT INTO ROA_PST006_M_DATA_ROLL_12M_NEW
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR08 ,STR01, REC1.AMOUNT);                 
      END LOOP;

  --(4-19) --------  
      STR01 :=  'C_REV_Y_21';
      --STR02 :=  In_YYYY || '01';
      for REC1 IN (  
         select b.D_AMOUNT-a.D_AMOUNT AMOUNT from       
         ( select SUM(D_AMOUNT) D_AMOUNT from ROA_PST006_M_DATA_ROLL_12M_NEW where period = In_PERIOD
         and D_KIND = PC_KIND and D_KEY IN  ( select PC FROM ROA_UPL009_EXCLUDE_PC_LISTS WHERE D_KIND = In_KIND ) and D_ACC = STR01 ) a,      
         ( select D_AMOUNT from ROA_PST006_M_DATA_ROLL_12M_NEW where period = In_PERIOD
         and D_KIND = USI_KIND and D_KEY = STR06 and D_ACC = STR01 ) b
  
      )
      LOOP
        INSERT INTO ROA_PST006_M_DATA_ROLL_12M_NEW
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR08 ,STR01, REC1.AMOUNT);                 
      END LOOP;

  --(4-20) --------  
      STR01 :=  'C_SFA_A_10N12';
      --STR02 :=  In_YYYY || '01';
      for REC1 IN (  
         select b.D_AMOUNT-a.D_AMOUNT AMOUNT from       
         ( select SUM(D_AMOUNT) D_AMOUNT from ROA_PST006_M_DATA_ROLL_12M_NEW where period = In_PERIOD
         and D_KIND = PC_KIND and D_KEY IN  ( select PC FROM ROA_UPL009_EXCLUDE_PC_LISTS WHERE D_KIND = In_KIND ) and D_ACC = STR01 ) a,      
         ( select D_AMOUNT from ROA_PST006_M_DATA_ROLL_12M_NEW where period = In_PERIOD
         and D_KIND = USI_KIND and D_KEY = STR06 and D_ACC = STR01 ) b
  
      )
      LOOP
        INSERT INTO ROA_PST006_M_DATA_ROLL_12M_NEW
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR08 ,STR01, REC1.AMOUNT);                 
      END LOOP;

  --(4-21) --------  
      STR01 :=  'C_BV1_A_30';
      --STR02 :=  In_YYYY || '01';
      for REC1 IN (  
         select b.D_AMOUNT-a.D_AMOUNT AMOUNT from       
         ( select SUM(D_AMOUNT) D_AMOUNT from ROA_PST006_M_DATA_ROLL_12M_NEW where period = In_PERIOD
         and D_KIND = PC_KIND and D_KEY IN  ( select PC FROM ROA_UPL009_EXCLUDE_PC_LISTS WHERE D_KIND = In_KIND ) and D_ACC = STR01 ) a,      
         ( select D_AMOUNT from ROA_PST006_M_DATA_ROLL_12M_NEW where period = In_PERIOD
         and D_KIND = USI_KIND and D_KEY = STR06 and D_ACC = STR01 ) b
  
      )
      LOOP
        INSERT INTO ROA_PST006_M_DATA_ROLL_12M_NEW
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR08 ,STR01, REC1.AMOUNT);                 
      END LOOP;

  --(4-22) --------  
      STR01 :=  'C_BV2_A_32';
      --STR02 :=  In_YYYY || '01';
      for REC1 IN (  
         select b.D_AMOUNT-a.D_AMOUNT AMOUNT from       
         ( select SUM(D_AMOUNT) D_AMOUNT from ROA_PST006_M_DATA_ROLL_12M_NEW where period = In_PERIOD
         and D_KIND = PC_KIND and D_KEY IN  ( select PC FROM ROA_UPL009_EXCLUDE_PC_LISTS WHERE D_KIND = In_KIND ) and D_ACC = STR01 ) a,      
         ( select D_AMOUNT from ROA_PST006_M_DATA_ROLL_12M_NEW where period = In_PERIOD
         and D_KIND = USI_KIND and D_KEY = STR06 and D_ACC = STR01 ) b
  
      )
      LOOP
        INSERT INTO ROA_PST006_M_DATA_ROLL_12M_NEW
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR08 ,STR01, REC1.AMOUNT);                 
      END LOOP;

  --(4-23) --------  
      STR01 :=  'C_OV1_A_34';
      --STR02 :=  In_YYYY || '01';
      for REC1 IN (  
         select b.D_AMOUNT-a.D_AMOUNT AMOUNT from       
         ( select SUM(D_AMOUNT) D_AMOUNT from ROA_PST006_M_DATA_ROLL_12M_NEW where period = In_PERIOD
         and D_KIND = PC_KIND and D_KEY IN  ( select PC FROM ROA_UPL009_EXCLUDE_PC_LISTS WHERE D_KIND = In_KIND ) and D_ACC = STR01 ) a,      
         ( select D_AMOUNT from ROA_PST006_M_DATA_ROLL_12M_NEW where period = In_PERIOD
         and D_KIND = USI_KIND and D_KEY = STR06 and D_ACC = STR01 ) b
  
      )
      LOOP
        INSERT INTO ROA_PST006_M_DATA_ROLL_12M_NEW
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR08 ,STR01, REC1.AMOUNT);                 
      END LOOP;


  --(4-24) --------  
      STR01 :=  'C_OV2_A_36';
      --STR02 :=  In_YYYY || '01';
      for REC1 IN (  
         select b.D_AMOUNT-a.D_AMOUNT AMOUNT from       
         ( select SUM(D_AMOUNT) D_AMOUNT from ROA_PST006_M_DATA_ROLL_12M_NEW where period = In_PERIOD
         and D_KIND = PC_KIND and D_KEY IN  ( select PC FROM ROA_UPL009_EXCLUDE_PC_LISTS WHERE D_KIND = In_KIND ) and D_ACC = STR01 ) a,      
         ( select D_AMOUNT from ROA_PST006_M_DATA_ROLL_12M_NEW where period = In_PERIOD
         and D_KIND = USI_KIND and D_KEY = STR06 and D_ACC = STR01 ) b
  
      )
      LOOP
        INSERT INTO ROA_PST006_M_DATA_ROLL_12M_NEW
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR08 ,STR01, REC1.AMOUNT);                 
      END LOOP;

  --(4-25) --------  
      STR01 :=  'C_OV3_A_38';
      --STR02 :=  In_YYYY || '01';
      for REC1 IN (  
         select b.D_AMOUNT-a.D_AMOUNT AMOUNT from       
         ( select SUM(D_AMOUNT) D_AMOUNT from ROA_PST006_M_DATA_ROLL_12M_NEW where period = In_PERIOD
         and D_KIND = PC_KIND and D_KEY IN  ( select PC FROM ROA_UPL009_EXCLUDE_PC_LISTS WHERE D_KIND = In_KIND ) and D_ACC = STR01 ) a,      
         ( select D_AMOUNT from ROA_PST006_M_DATA_ROLL_12M_NEW where period = In_PERIOD
         and D_KIND = USI_KIND and D_KEY = STR06 and D_ACC = STR01 ) b
  
      )
      LOOP
        INSERT INTO ROA_PST006_M_DATA_ROLL_12M_NEW
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR08 ,STR01, REC1.AMOUNT);                 
      END LOOP;   
    
  --(4-99) --------      
      STR01 :=  'C_BV3_A_44';
      for REC1 IN (
          select b.D_AMOUNT-a.AMOUNT AMOUNT from
          ( SELECT SUM( D_AMOUNT )  AMOUNT FROM ROA_PST006_M_DATA_ROLL_12M_NEW
          WHERE PERIOD = In_PERIOD 
          AND D_KIND = PC_KIND AND D_ACC in ( 'C_BV3_A_44' ) AND D_KEY IN  ( select PC FROM ROA_UPL009_EXCLUDE_PC_LISTS WHERE D_KIND = In_KIND ) ) a ,
          ( SELECT SUM( D_AMOUNT )  D_AMOUNT FROM ROA_PST006_M_DATA_ROLL_12M_NEW
          WHERE PERIOD = In_PERIOD 
          AND D_KIND = USI_KIND AND D_ACC in ( 'C_BV3_A_44' ) ) b
                
      )
      LOOP
        INSERT INTO ROA_PST006_M_DATA_ROLL_12M_NEW
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR08 ,STR01, REC1.AMOUNT);                 
      END LOOP;    
      
  --(4-98) --------      
      STR01 :=  'C_OV4_A_46';
      for REC1 IN (
          select b.D_AMOUNT-a.AMOUNT AMOUNT from
          ( SELECT SUM( D_AMOUNT )  AMOUNT FROM ROA_PST006_M_DATA_ROLL_12M_NEW
          WHERE PERIOD = In_PERIOD 
          AND D_KIND = PC_KIND AND D_ACC in ( 'C_OV4_A_46' ) AND D_KEY IN  ( select PC FROM ROA_UPL009_EXCLUDE_PC_LISTS WHERE D_KIND = In_KIND ) ) a ,
          ( SELECT SUM( D_AMOUNT )  D_AMOUNT FROM ROA_PST006_M_DATA_ROLL_12M_NEW
          WHERE PERIOD = In_PERIOD 
          AND D_KIND = USI_KIND AND D_ACC in ( 'C_OV4_A_46' ) ) b                 
      )
      LOOP
        INSERT INTO ROA_PST006_M_DATA_ROLL_12M_NEW
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR08 ,STR01, REC1.AMOUNT);                 
      END LOOP;   
 

  --(4-97) --------      
      STR01 :=  'A04400';
      for REC1 IN (
          select b.D_AMOUNT-a.AMOUNT AMOUNT from
          ( SELECT SUM( D_AMOUNT )  AMOUNT FROM ROA_PST006_M_DATA_ROLL_12M_NEW
          WHERE PERIOD = In_PERIOD 
          AND D_KIND = PC_KIND AND D_ACC in ( 'A04400' ) AND D_KEY IN  ( select PC FROM ROA_UPL009_EXCLUDE_PC_LISTS WHERE D_KIND = In_KIND ) ) a ,
          ( SELECT SUM( D_AMOUNT )  D_AMOUNT FROM ROA_PST006_M_DATA_ROLL_12M_NEW
          WHERE PERIOD = In_PERIOD 
          AND D_KIND = USI_KIND AND D_ACC in ( 'A04400' ) ) b                 
      )
      LOOP
        INSERT INTO ROA_PST006_M_DATA_ROLL_12M_NEW
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR08 ,STR01, REC1.AMOUNT);                 
      END LOOP;   

  --(4-97) --------      
      STR01 :=  'A04600';
      for REC1 IN (
          select b.D_AMOUNT-a.AMOUNT AMOUNT from
          ( SELECT SUM( D_AMOUNT )  AMOUNT FROM ROA_PST006_M_DATA_ROLL_12M_NEW
          WHERE PERIOD = In_PERIOD 
          AND D_KIND = PC_KIND AND D_ACC in ( 'A04600' ) AND D_KEY IN  ( select PC FROM ROA_UPL009_EXCLUDE_PC_LISTS WHERE D_KIND = In_KIND ) ) a ,
          ( SELECT SUM( D_AMOUNT )  D_AMOUNT FROM ROA_PST006_M_DATA_ROLL_12M_NEW
          WHERE PERIOD = In_PERIOD 
          AND D_KIND = USI_KIND AND D_ACC in ( 'A04600' ) ) b                 
      )
      LOOP
        INSERT INTO ROA_PST006_M_DATA_ROLL_12M_NEW
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR08 ,STR01, REC1.AMOUNT);                 
      END LOOP; 
      delete  FROM   ROA_PST006_M_DATA_ROLL_12M_NEW WHERE D_KEY = STR08 AND D_KIND <> In_KIND AND PERIOD = In_PERIOD;
      COMMIT;      
  END IF;       
  
  
END ROA_PLS012_CAL_M_ROLL_12M_NEW;
/

