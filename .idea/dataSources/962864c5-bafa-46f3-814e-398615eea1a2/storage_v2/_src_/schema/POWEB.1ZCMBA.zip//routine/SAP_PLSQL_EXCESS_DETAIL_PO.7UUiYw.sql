create PROCEDURE         "SAP_PLSQL_EXCESS_DETAIL_PO" AUTHID DEFINER
IS

      /*--------------------------------------------------------------*
         CREATE DATE:  2008/09/17
         PLSQL      :  SAP_PLSQL_EXCESS_DETAIL_PO
         Author     :  Susan Lin
         Purpase    :  EXCESS DETAIL(By 每月執行一次)
                       TW
      *---------------------------------------------------------------*
      */


 vCompany_code SAP_EXCESS_DETAIL_PO_T.Company_code%TYPE;
 vPROCEE_YYYYMMDD varchar2(8);
 vPROCEE_YYYYMM   varchar2(6);
 iTracePoint      varchar2(100);
 cErrorText       varchar2(500);

BEGIN

  --抓上月份By系統日期
   iTracePoint := '000';
    select * into vPROCEE_YYYYMM, vPROCEE_YYYYMMDD  from (
           select trim(to_char(add_months(SYSDATE,-1), 'YYYYMM')), trim(to_char(add_months(SYSDATE,-1), 'YYYYMM')) || '01'
                  from dual
    );

--
--   for REC1 in ( select COMPANY_CODE, PLANT, SLOC, YYYYMM, MATERIAL, DMQTY, EINDT, D_QTY, PO, ITEM, MATTYPE, RAWDESC, DALIY_LOT_SIZE, CW, RW, LT, ROUNDING, MIN_LOT_SIZE, CREATE_DATE, PO_QTY, OPEN_QTY, CURRENCY, EX_RATE, NETPRC, PEINH, NETPRC1, CUR_MAC, NETPRC2, VMNAME, VENDOR, MPN, MFRNR, EXTYPE, EXQTY1, EXQTY2, EXAMT1,IRQTY1, IRQAMT1, ST_QTY, MNG01, PURGRP, PURNAME, PSTYP, EXTYPE_ST, POTYPE, D_QTY_OLD, YYYYMM_OLD, PONC, NON_QTY, CAN_QTY, MATGROUP, BSTYP, PRCTR, MD04_USE, MB51_USE, TX_DATE
--                  from SAP_EXCESS_DETAIL_PO_T
--                       where YYYY =  substr(vPROCEE_YYYYMM,1,4)
--                         and MM =   substr(vPROCEE_YYYYMM,5,2)
--                        ) loop
--     if REC1.COMPANY_CODE is not null then
--       iTracePoint := '100';
--       vCompany_code := REC1.Company_code;
--     end if;
--   end loop;
--
--   if vCOMPANY_CODE is null then
--     --若沒抓到資料則寄 error mail
--     iTracePoint := '200';
--     cErrorText := 'No data!';
--     MAIL_FILE_BIDBDBADMIN(in_to_name => 'shuchin@ms.usi.com.tw', subject => '[VQA] PL/SQL SAP_PLSQL_EXCESS_DETAIL_PO ERROR', message => '[SAP_EXCESS_DETAIL_PO_T], The tracepoint is  ' || iTracePoint || ' and ErrorText= ' || cErrorText) ;
--   else
--
--   --清除重覆資料 SAP_EXCESS_DETAIL_PO
--       DELETE FROM SAP_EXCESS_DETAIL_PO where YYYY =  substr(vPROCEE_YYYYMM,1,4)
--                                          and MM =   substr(vPROCEE_YYYYMM,5,2);
--     Commit;
--
--   --抓 Weekly 資料放到 SAP_EXCESS_DETAIL_PO
--   iTracePoint := '300';
--     insert into SAP_EXCESS_DETAIL_PO ( COMPANY_CODE, PLANT, SLOC, YYYYMM, MATERIAL, DMQTY, EINDT, D_QTY, PO, ITEM, MATTYPE, RAWDESC, DALIY_LOT_SIZE, CW, RW, LT, ROUNDING, MIN_LOT_SIZE, CREATE_DATE, PO_QTY, OPEN_QTY, CURRENCY, EX_RATE, NETPRC, PEINH, NETPRC1, CUR_MAC, NETPRC2, VMNAME, VENDOR, MPN, MFRNR, EXTYPE, EXQTY1, EXQTY2, EXAMT1,IRQTY1, IRQAMT1, ST_QTY, MNG01, PURGRP, PURNAME, PSTYP, EXTYPE_ST, POTYPE, D_QTY_OLD, YYYYMM_OLD, PONC, NON_QTY, CAN_QTY, MATGROUP, BSTYP, PRCTR, MD04_USE, MB51_USE, TX_DATE
--   )
--     Select COMPANY_CODE, PLANT, SLOC, YYYYMM, MATERIAL, DMQTY, EINDT, D_QTY, PO, ITEM, MATTYPE, RAWDESC, DALIY_LOT_SIZE, CW, RW, LT, ROUNDING, MIN_LOT_SIZE, CREATE_DATE, PO_QTY, OPEN_QTY, CURRENCY, EX_RATE, NETPRC, PEINH, NETPRC1, CUR_MAC, NETPRC2, VMNAME, VENDOR, MPN, MFRNR, EXTYPE, EXQTY1, EXQTY2, EXAMT1,IRQTY1, IRQAMT1, ST_QTY, MNG01, PURGRP, PURNAME, PSTYP, EXTYPE_ST, POTYPE, D_QTY_OLD, YYYYMM_OLD, PONC, NON_QTY, CAN_QTY, MATGROUP, BSTYP, PRCTR, MD04_USE, MB51_USE, TX_DATE
--                  from (
--      Select COMPANY_CODE, PLANT, SLOC, YYYYMM, MATERIAL, DMQTY, EINDT, D_QTY, PO, ITEM, MATTYPE, RAWDESC, DALIY_LOT_SIZE, CW, RW, LT, ROUNDING, MIN_LOT_SIZE, CREATE_DATE, PO_QTY, OPEN_QTY, CURRENCY, EX_RATE, NETPRC, PEINH, NETPRC1, CUR_MAC, NETPRC2, VMNAME, VENDOR, MPN, MFRNR, EXTYPE, EXQTY1, EXQTY2, EXAMT1,IRQTY1, IRQAMT1, ST_QTY, MNG01, PURGRP, PURNAME, PSTYP, EXTYPE_ST, POTYPE, D_QTY_OLD, YYYYMM_OLD, PONC, NON_QTY, CAN_QTY, MATGROUP, BSTYP, PRCTR, MD04_USE, MB51_USE, TX_DATE
--        from SAP_EXCESS_DETAIL_PO_T
--          where a.YYYY = substr(vPROCEE_YYYYMM,1,6)
--          );
-- --       ) group by COMPANY_CODE, PlANT, SLOC, YYYYMM, MANUF, PART_NO, PTYPE, MATGROUP;
--        commit;
--
--
--
--
--   end if;



EXCEPTION
   When OTHERS Then
    --有錯誤產生則寄mail
    cErrorText := SQLERRM();
    MAIL_FILE_BIDBDBADMIN(in_to_name => 'shuchin_lin@usiglobal.com', subject => '[SAP] PL/SQL SAP_PLSQL_EXCESS_DETAIL_PO ERROR', message => '[SAP_EXCESS_DETAIL_PO], The tracepoint is  ' || iTracePoint || ' and ErrorText= ' || cErrorText) ;

END SAP_PLSQL_EXCESS_DETAIL_PO;
/

