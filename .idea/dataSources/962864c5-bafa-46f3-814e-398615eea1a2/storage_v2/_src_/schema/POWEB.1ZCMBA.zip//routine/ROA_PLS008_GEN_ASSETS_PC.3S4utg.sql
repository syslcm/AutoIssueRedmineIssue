create PROCEDURE       ROA_PLS008_GEN_ASSETS_PC (
/* ********************************************************************
  PROG-ID      : ROA_PLS008_GEN_ASSETS_PC
  PROG-ACTION  : 
  Author       : Asan Chang
  Date         : 2017/05/04
  OA Number    : SAI071408
  Description  : Generate data of fixed assets
********************************************************************* 
* 2017/07/06 SAI071408 Asan Chang add from_company_code
********************************************************************* 
*/
   YYYYMM       IN   VARCHAR2
)      
AUTHID DEFINER
IS     
   CURSOR FROM_DATA
   IS
   
   select company_code,from_company_code, period, pc, S_seq, sum(acQ_VAL) ORIGNAL_VALUE ,sum(book_val)  BOOK_VALUE
   FROM
   ROA_PST003_ALLOC_TO_PC
   WHERE PERIOD = YYYYMM
   group by   company_code,from_company_code,period, pc, S_seq
   order by   company_code,from_company_code,period, pc, S_seq ;
  
   itracepoint         INTEGER;
   tmp_ALLOC_TYPE      VARCHAR(2);              --分攤方式 ex:01,02,03...
   tmp_PC              VARCHAR2(10 BYTE);
   tmp_WW_RATIO        NUMBER(15,2);
   tmp_LEGAL_RATIO     NUMBER(15,2);
   TMP_AMT1            NUMBER(15,5);
   TMP_AMT2            NUMBER(15,5);   
   t_CURRENCY_LOCAL    pld_kpi_non_bom_ir.IR_CURRENCY%TYPE;
   p_CURRENCY_LOCAL    pld_kpi_non_bom_ir.IR_CURRENCY%TYPE;   
	 a_EX_RATE_CNY       EMPS_SAP001_DAILY_DN_ZF430.EX_RATE_CNY%TYPE;
	 a_EX_RATE_USD       EMPS_SAP001_DAILY_DN_ZF430.EX_RATE_USD%TYPE;
	 a_EX_RATE_TWD       EMPS_SAP001_DAILY_DN_ZF430.EX_RATE_TWD%TYPE;
	 NOW_COMPANY_CODE    VARCHAR(4); 
	 CNT                 INTEGER;  
   ------------------------sub function ------------------------
  PROCEDURE INSERT_DATA (
    in_COMPANY_CODE      IN VARCHAR2,
    in_FM_COMPANY_CODE   IN VARCHAR2,
    in_TYPE              IN VARCHAR2,
    in_S_SEQ             IN VARCHAR2,
    in_PC                IN VARCHAR2,
    in_UPL_AMT_LOC       IN NUMBER,
    in_COMPANY_CURR      IN VARCHAR2,
    in_EX_RATE_TWD       IN NUMBER,
    in_EX_RATE_USD       IN NUMBER,
    in_EX_RATE_CNY       IN NUMBER,
    in_CREATE_USER       IN VARCHAR2     
    
  ) IS
  BEGIN
   --(3)開始處理資料
     INSERT INTO ROA_PST004_FIXED_ASSETS_FM_PC (
       PERIOD,
       COMPANY_CODE,
       FROM_COMPANY_CODE,
       TYPE,
       S_SEQ,
       PC,
       UPL_AMT_LOC,
       COMPANY_CURR,
       EX_RATE_TWD,
       EX_RATE_USD,
       EX_RATE_CNY,
       CREATE_USER,
       CREATE_DATE
       ) VALUES (                                 
       YYYYMM ,
       in_COMPANY_CODE,
       in_FM_COMPANY_CODE,
       in_TYPE,
       in_S_SEQ,
       in_PC,
       in_UPL_AMT_LOC,
       in_COMPANY_CURR,
       in_EX_RATE_TWD,
       in_EX_RATE_USD,
       in_EX_RATE_CNY,
       in_CREATE_USER,
       SYSDATE
       );   
       COMMIT;
  END INSERT_DATA;
  ------------------------sub function ------------------------  
  
  
BEGIN
  --(1)清除舊資料
  delete FROM ROA_PST004_FIXED_ASSETS_FM_PC
  where PERIOD       = YYYYMM;
  COMMIT;  
         
     
  CNT := 0;   
    
  FOR REC1 IN FROM_DATA LOOP
     CNT := CNT + 1;
     IF CNT = 1 then 
       NOW_COMPANY_CODE := REC1.COMPANY_CODE;
       --計算匯率
       --R:用路透社匯率 table:KPI_MAP013_EXCHANGE_RATE_END
       select COMPANY_CURR INTO t_CURRENCY_LOCAL FROM PNL_MAP006_SITE_MAPPING WHERE COMPANY_CODE = NOW_COMPANY_CODE;
       a_EX_RATE_USD := Get_Exchange_Rate(SUBSTRB(REC1.PERIOD,1,4),SUBSTRB(REC1.PERIOD,5,2),t_CURRENCY_LOCAL,'USD','R') ;
       a_EX_RATE_TWD := Get_Exchange_Rate(SUBSTRB(REC1.PERIOD,1,4),SUBSTRB(REC1.PERIOD,5,2),t_CURRENCY_LOCAL,'TWD','R') ;
       a_EX_RATE_CNY := Get_Exchange_Rate(SUBSTRB(REC1.PERIOD,1,4),SUBSTRB(REC1.PERIOD,5,2),t_CURRENCY_LOCAL,'CNY','R') ;
        
     Else
       IF REC1.COMPANY_CODE <> NOW_COMPANY_CODE then
         NOW_COMPANY_CODE := REC1.COMPANY_CODE;
         --計算匯率
         --R:用路透社匯率 table:KPI_MAP013_EXCHANGE_RATE_END
         select COMPANY_CURR INTO t_CURRENCY_LOCAL FROM PNL_MAP006_SITE_MAPPING WHERE COMPANY_CODE = NOW_COMPANY_CODE;
         a_EX_RATE_USD := Get_Exchange_Rate(SUBSTRB(REC1.PERIOD,1,4),SUBSTRB(REC1.PERIOD,5,2),t_CURRENCY_LOCAL,'USD','R') ;
         a_EX_RATE_TWD := Get_Exchange_Rate(SUBSTRB(REC1.PERIOD,1,4),SUBSTRB(REC1.PERIOD,5,2),t_CURRENCY_LOCAL,'TWD','R') ;
         a_EX_RATE_CNY := Get_Exchange_Rate(SUBSTRB(REC1.PERIOD,1,4),SUBSTRB(REC1.PERIOD,5,2),t_CURRENCY_LOCAL,'CNY','R') ;       
       end if;
     end if;
    
     INSERT_DATA ( REC1.COMPANY_CODE,REC1.FROM_COMPANY_CODE,'1',REC1.S_SEQ, REC1.PC,REC1.ORIGNAL_VALUE,t_CURRENCY_LOCAL,
     a_EX_RATE_TWD,a_EX_RATE_USD,a_EX_RATE_CNY, 'NEW');
 
     INSERT_DATA ( REC1.COMPANY_CODE,REC1.FROM_COMPANY_CODE,'2',REC1.S_SEQ, REC1.PC,REC1.BOOK_VALUE,t_CURRENCY_LOCAL,
     a_EX_RATE_TWD,a_EX_RATE_USD,a_EX_RATE_CNY, 'NEW');        

  END LOOP; 
  
     

  --


END ROA_PLS008_GEN_ASSETS_PC;
/

