create PROCEDURE         "PLSQL_VRT_WH001_INCOMING_EXCEP" (
  YYYYMM in VARCHAR2
)
is
 iTracePoint  integer ;
 cErrorText varchar2(500);


  CURSOR C_WH001_INCOMING_EXCEP is
    Select NVL(B.MTL_GROUP,'999') as MTL_GROUP,A.*
      from VRT_WH001_INCOMING_EXCEP A, PLD_KPI_PN_MTLGRP_SUBGRP B
     where A.PART = B.PART_NO(+)
	   and A.MATGROUP is null;

BEGIN

  iTracePoint := '200';
  FOR REC1 in C_WH001_INCOMING_EXCEP Loop
    Update VRT_WH001_INCOMING_EXCEP
       set MATGROUP = REC1.MTL_GROUP
     where SITE = REC1.SITE
       and LIFNR = REC1.LIFNR
       and SERIALNO = REC1.SERIALNO
       and ENTRY_DATE = REC1.ENTRY_DATE
       and SYSDATETIME = REC1.SYSDATETIME
       and PART = REC1.PART;
    Commit;
  END LOOP;

EXCEPTION
   When OTHERS Then
    --有錯誤產生則寄mail
    cErrorText := SQLERRM();
    MAIL_FILE_BIDBDBADMIN(in_to_name => 'shuchin_lin@usiglobal.com', subject => '[VRT] PL/SQL PLSQL_VRT_WH001_INCOMING_EXCEP', message => '[PLSQL_VRT_WH001_INCOMING_EXCEP], The tracepoint is  ' || iTracePoint || ' and ErrorText= ' || cErrorText || ' and YYYYMM= ' || YYYYMM) ;

END PLSQL_VRT_WH001_INCOMING_EXCEP;
/

