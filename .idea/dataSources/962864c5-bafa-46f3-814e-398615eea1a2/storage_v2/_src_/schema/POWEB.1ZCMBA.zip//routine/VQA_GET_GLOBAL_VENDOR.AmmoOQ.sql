create FUNCTION vqa_get_global_vendor (
   cmfr_name   IN   vqa_pdm_mfr_data.mfr_name%TYPE
)
   RETURN VARCHAR2
/*********************************************************************
  PROG-ID      : VQA GET GLOBAL VENDOR
  Author       : Shuya
  Date         : 2008/02/277
**********************************************************************/
IS
   CURSOR cur
   IS
      SELECT global_vendor_code
        FROM vqa_avl_relation
       WHERE manufacturer_name = cmfr_name;

   cmessage   VARCHAR2 (5000);
BEGIN
   cmessage := '';

   FOR rec IN cur
   LOOP
      IF cmessage IS NOT NULL
      THEN
         cmessage := cmessage || ',<br>';
      END IF;

      cmessage := cmessage || rec.global_vendor_code;
   END LOOP;

   RETURN cmessage;
END vqa_get_global_vendor;
/

