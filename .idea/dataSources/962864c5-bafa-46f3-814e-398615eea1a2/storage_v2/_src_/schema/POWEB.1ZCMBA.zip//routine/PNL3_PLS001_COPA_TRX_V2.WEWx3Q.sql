create PROCEDURE       PNL3_PLS001_COPA_TRX_V2 (
  --inCompany  in VARCHAR2,
  t_Period in VARCHAR2
  --2008/11/4 ADD KPI_UPL001_REVENUE_TRX 
)
AUTHID DEFINER
is
 
--2008/11/7 有發現  SUM(NET_REVENUE) <> 0 OR SUM(NET_COGS)  <> 0 條件成立但dm/dl/oh卻有值的戕況,因此不加入此條件
-- 在INSERT進資料庫時再排除金額=0的資料
--範例在PROFIT_CENTER  23  SITE:1100  金額 -30973  COST_ELEEMENT 510902  這三個pn
--1568-018969-91
--1568-025307-71
--1568-026054-91
--2008/11/26 修改邏輯:針對材料部份20/21的不管MTL GROUP,只要是材料都叫LENOVO,而其他的材料如果SEARCH TERM是LENOVO就叫LENOVO

--2008/11/19  COST ELEMENT 530101溝通後用revenue分掉
 CURSOR C_PNL3_PLS001_R is
      SELECT COMPANY_CODE,PERIOD,PROFIT_CENTER,CUSTOMER_ID as BILL_TO_PARTY,SHIP_TO_PARTY,MTL_GROUP,PART_NO,PLANT_CODE,MTL_TYPE,COST_ELEMENT,SEARCH_TERM,
             SUM(NET_REVENUE) AMT_LOCAL,SUM(NET_REVENUE_USD) AMT_USD,SUM(NET_REVENUE_TWD) AMT_TWD,
             SUM(COGS_MB) COGS_DM_LOCAL,SUM(COGS_MB_USD) COGS_DM_USD,SUM(COGS_MB_TWD) COGS_DM_TWD,
             SUM(COGS_LB) COGS_DL_LOCAL,SUM(COGS_LB_USD) COGS_DL_USD,SUM(COGS_LB_TWD) COGS_DL_TWD,
             SUM(COGS_OB) COGS_OH_LOCAL,SUM(COGS_OB_USD) COGS_OH_USD,SUM(COGS_OB_TWD) COGS_OH_TWD
        FROM KPI_SAP001_COPA_TRX
       WHERE  PERIOD = t_Period 
         AND    ( NET_REVENUE <> 0 OR NET_COGS <>  0)
         AND    RELATED_PARTY <> 'Y'
         AND    PART_NO IS NOT NULL --後面還要有一段程式去補足 沒有Part no又不在下列10個COST ELEMENT出現(9月份竟然沒有問題,8月和7月有問題,是因為end_customer重新update的結果嗎?,end_custer只有做9月份update
         AND (COST_ELEMENT NOT IN ('0000530101','0000510109','0000510110','0000510201','0000510301','0000510401','0000510501','0000510101','0000510102','0000510103','0000510104','0000510107','0000510901','0000510902','0000510903','0000510909','0000510999') OR COST_ELEMENT IS NULL )  
    GROUP BY COMPANY_CODE,PERIOD,PROFIT_CENTER,CUSTOMER_ID,SHIP_TO_PARTY,MTL_GROUP,PART_NO,PLANT_CODE,MTL_TYPE,COST_ELEMENT,SEARCH_TERM;
      --HAVING ( SUM(NET_REVENUE) <> 0 OR SUM(NET_COGS)  <> 0 );



  CURSOR C_PNL3_PLS001_R1 is
      SELECT COMPANY_CODE,PERIOD,PROFIT_CENTER,CUSTOMER_ID as BILL_TO_PARTY,SHIP_TO_PARTY,MTL_GROUP,PART_NO,PLANT_CODE,MTL_TYPE,COST_ELEMENT,SEARCH_TERM,
             SUM(NET_REVENUE) AMT_LOCAL,SUM(NET_REVENUE_USD) AMT_USD,SUM(NET_REVENUE_TWD) AMT_TWD,
             SUM(COGS_MB) COGS_DM_LOCAL,SUM(COGS_MB_USD) COGS_DM_USD,SUM(COGS_MB_TWD) COGS_DM_TWD,
             SUM(COGS_LB) COGS_DL_LOCAL,SUM(COGS_LB_USD) COGS_DL_USD,SUM(COGS_LB_TWD) COGS_DL_TWD,
             SUM(COGS_OB) COGS_OH_LOCAL,SUM(COGS_OB_USD) COGS_OH_USD,SUM(COGS_OB_TWD) COGS_OH_TWD
        FROM KPI_SAP001_COPA_TRX
       WHERE  PERIOD = t_Period 
         AND    ( NET_REVENUE <> 0 OR NET_COGS <>  0)
         AND    RELATED_PARTY <> 'Y'
         AND    PART_NO IS NULL 
         AND (COST_ELEMENT NOT IN ('0000530101','0000510109','0000510110','0000510201','0000510301','0000510401','0000510501','0000510101','0000510102','0000510103','0000510104','0000510107','0000510901','0000510902','0000510903','0000510909','0000510999') OR COST_ELEMENT IS NULL )
    GROUP BY COMPANY_CODE,PERIOD,PROFIT_CENTER,CUSTOMER_ID,SHIP_TO_PARTY,MTL_GROUP,PART_NO,PLANT_CODE,MTL_TYPE,COST_ELEMENT,SEARCH_TERM;
      --HAVING ( SUM(NET_REVENUE) <> 0 OR SUM(NET_COGS)  <> 0 );
  
  
---USER Upload Non-SAP Data
  
  CURSOR C_PNL3_PLS001_R2 is
      SELECT COMPANY_CODE,PERIOD,PROFIT_CENTER,
            SUM(NET_REVENUE) AMT_LOCAL,SUM(NET_REVENUE_USD) AMT_USD,SUM(NET_REVENUE_TWD) AMT_TWD
        FROM KPI_UPL001_REVENUE_TRX
       WHERE PERIOD = t_Period
         AND     NET_REVENUE <> 0
         AND    RELATED_PARTY <> 'Y'
    GROUP BY COMPANY_CODE,PERIOD,PROFIT_CENTER
      HAVING  SUM(NET_REVENUE) <> 0 ;
      
--Update FG & END CUSTOMER Mapping
      
 BEGIN
   DELETE FROM PNL3_TRX001_COPA
   WHERE Period = t_Period ;
   Commit;
    FOR REC1 in C_PNL3_PLS001_R Loop
         IF REC1.AMT_LOCAL <> 0 THEN
           Insert into PNL3_TRX001_COPA (
                COMPANY_CODE    , PERIOD         , PROFIT_CENTER      , BILL_TO_PARTY , SHIP_TO_PARTY, MTL_GROUP, PART_NO,PLANT_CODE,
                AMT_LOCAL      , AMT_USD            , AMT_TWD         , SOURCE          ,MTL_TYPE,COST_ELEMENT,
                R_KIND          , AREA1          ,AREA2               , AREA3            ,SEARCH_TERM,
                CREATE_DATE
                      ) VALUES (
                        REC1.COMPANY_CODE       , REC1.PERIOD       , REC1.PROFIT_CENTER      , REC1.BILL_TO_PARTY , REC1.SHIP_TO_PARTY, REC1.MTL_GROUP, REC1.PART_NO,REC1.PLANT_CODE,
                        REC1.AMT_LOCAL    , REC1.AMT_USD            , REC1.AMT_TWD            , 'COPA'               ,REC1.MTL_TYPE,REC1.COST_ELEMENT,
                        'PL01'                  , '1'                 ,'1'                       , '0'                    ,REC1.SEARCH_TERM,
                        SYSDATE );
            Commit;
          END IF;
          IF REC1.COGS_DM_LOCAL <> 0 THEN
            Insert into PNL3_TRX001_COPA (
                   COMPANY_CODE    , PERIOD         , PROFIT_CENTER      , BILL_TO_PARTY , SHIP_TO_PARTY, MTL_GROUP, PART_NO,PLANT_CODE,
                   AMT_LOCAL      , AMT_USD            , AMT_TWD         , SOURCE          ,MTL_TYPE,COST_ELEMENT,
                   R_KIND          , AREA1          ,AREA2               , AREA3            ,SEARCH_TERM,
                   CREATE_DATE
                   ) VALUES (
                        REC1.COMPANY_CODE       , REC1.PERIOD       , REC1.PROFIT_CENTER      , REC1.BILL_TO_PARTY , REC1.SHIP_TO_PARTY, REC1.MTL_GROUP, REC1.PART_NO,REC1.PLANT_CODE,
                        REC1.COGS_DM_LOCAL, REC1.COGS_DM_USD        , REC1.COGS_DM_TWD        , 'COPA'               ,REC1.MTL_TYPE,REC1.COST_ELEMENT,
                        'PL01'                  , '2'                 , '2'                       , '0'                    ,REC1.SEARCH_TERM,
                        SYSDATE 
                   );
             Commit;
          END IF;
          
          IF REC1.COGS_DL_LOCAL <> 0 THEN
            Insert into PNL3_TRX001_COPA (
                   COMPANY_CODE    , PERIOD         , PROFIT_CENTER      , BILL_TO_PARTY , SHIP_TO_PARTY, MTL_GROUP, PART_NO,PLANT_CODE,
                   AMT_LOCAL      , AMT_USD            , AMT_TWD         , SOURCE          ,MTL_TYPE,COST_ELEMENT,
                   R_KIND          , AREA1          ,AREA2               , AREA3            ,SEARCH_TERM,
                   CREATE_DATE
                   ) VALUES (
                        REC1.COMPANY_CODE       , REC1.PERIOD       , REC1.PROFIT_CENTER      , REC1.BILL_TO_PARTY , REC1.SHIP_TO_PARTY, REC1.MTL_GROUP, REC1.PART_NO,REC1.PLANT_CODE,
                        REC1.COGS_DL_LOCAL, REC1.COGS_DL_USD        , REC1.COGS_DL_TWD        , 'COPA'               ,REC1.MTL_TYPE,REC1.COST_ELEMENT,
                        'PL01'                  , '2'                 , '3'                       , '0'                    ,REC1.SEARCH_TERM,
                        SYSDATE 
                   );
             Commit;
          END IF;
          
          
          IF REC1.COGS_OH_LOCAL <> 0 THEN
            Insert into PNL3_TRX001_COPA (
                   COMPANY_CODE    , PERIOD         , PROFIT_CENTER      , BILL_TO_PARTY , SHIP_TO_PARTY, MTL_GROUP, PART_NO,PLANT_CODE,
                   AMT_LOCAL      , AMT_USD            , AMT_TWD         , SOURCE          ,MTL_TYPE, COST_ELEMENT,
                   R_KIND          , AREA1          ,AREA2               , AREA3            ,SEARCH_TERM,
                   CREATE_DATE
                   ) VALUES (
                        REC1.COMPANY_CODE       , REC1.PERIOD       , REC1.PROFIT_CENTER      , REC1.BILL_TO_PARTY , REC1.SHIP_TO_PARTY, REC1.MTL_GROUP, REC1.PART_NO,REC1.PLANT_CODE,
                        REC1.COGS_OH_LOCAL, REC1.COGS_OH_USD        , REC1.COGS_OH_TWD        , 'COPA'               ,REC1.MTL_TYPE,REC1.COST_ELEMENT,
                        'PL01'                  , '2'                 , '4'                      , '0'                    ,REC1.SEARCH_TERM,
                        SYSDATE 
                   );
             Commit;
          END IF;

    END LOOP;
    
    FOR REC1 in C_PNL3_PLS001_R1 Loop
         IF REC1.AMT_LOCAL <> 0 THEN
            Insert into PNL3_TRX001_COPA (
                COMPANY_CODE    , PERIOD         , PROFIT_CENTER      , BILL_TO_PARTY , SHIP_TO_PARTY, MTL_GROUP, PART_NO,PLANT_CODE,
                AMT_LOCAL      , AMT_USD            , AMT_TWD         , SOURCE          ,MTL_TYPE,COST_ELEMENT,
                R_KIND          , AREA1          ,AREA2               , AREA3            ,SEARCH_TERM,
                CREATE_DATE
                      ) VALUES (
                        REC1.COMPANY_CODE       , REC1.PERIOD       , REC1.PROFIT_CENTER      , REC1.BILL_TO_PARTY , REC1.SHIP_TO_PARTY, REC1.MTL_GROUP, REC1.PART_NO,REC1.PLANT_CODE,
                        REC1.AMT_LOCAL    , REC1.AMT_USD            , REC1.AMT_TWD            , 'COPA_NPN'             ,REC1.MTL_TYPE,REC1.COST_ELEMENT,
                        'PL01'                  , '1'                 ,'1'                       , '0'                    ,REC1.SEARCH_TERM,
                        SYSDATE );
             Commit;
          END IF;
          
          IF REC1.COGS_DM_LOCAL <> 0 THEN
            Insert into PNL3_TRX001_COPA (
                   COMPANY_CODE    , PERIOD         , PROFIT_CENTER      , BILL_TO_PARTY , SHIP_TO_PARTY, MTL_GROUP, PART_NO,PLANT_CODE,
                   AMT_LOCAL      , AMT_USD            , AMT_TWD         , SOURCE          ,MTL_TYPE,  COST_ELEMENT,
                   R_KIND          , AREA1          ,AREA2               , AREA3            ,SEARCH_TERM,
                   CREATE_DATE
                   ) VALUES (
                        REC1.COMPANY_CODE       , REC1.PERIOD       , REC1.PROFIT_CENTER      , REC1.BILL_TO_PARTY , REC1.SHIP_TO_PARTY, REC1.MTL_GROUP, REC1.PART_NO,REC1.PLANT_CODE,
                        REC1.COGS_DM_LOCAL, REC1.COGS_DM_USD        , REC1.COGS_DM_TWD        , 'COPA_NPN'             ,REC1.MTL_TYPE,REC1.COST_ELEMENT,
                        'PL01'                  , '2'                 , '2'                       , '0'                    ,REC1.SEARCH_TERM,
                        SYSDATE 
                   );
             Commit;
          END IF;
          
          IF REC1.COGS_DL_LOCAL <> 0 THEN
            Insert into PNL3_TRX001_COPA (
                   COMPANY_CODE    , PERIOD         , PROFIT_CENTER      , BILL_TO_PARTY , SHIP_TO_PARTY, MTL_GROUP, PART_NO,PLANT_CODE,
                   AMT_LOCAL      , AMT_USD            , AMT_TWD         , SOURCE          ,MTL_TYPE, COST_ELEMENT,
                   R_KIND          , AREA1          ,AREA2               , AREA3            ,SEARCH_TERM,
                   CREATE_DATE
                   ) VALUES (
                        REC1.COMPANY_CODE       , REC1.PERIOD       , REC1.PROFIT_CENTER      , REC1.BILL_TO_PARTY , REC1.SHIP_TO_PARTY, REC1.MTL_GROUP, REC1.PART_NO,REC1.PLANT_CODE,
                        REC1.COGS_DL_LOCAL, REC1.COGS_DL_USD        , REC1.COGS_DL_TWD        , 'COPA_NPN'             ,REC1.MTL_TYPE,REC1.COST_ELEMENT,
                        'PL01'                  , '2'                 , '3'                       , '0'                    ,REC1.SEARCH_TERM,
                        SYSDATE 
                   );
             Commit;
          END IF;
          
          
          IF REC1.COGS_OH_LOCAL <> 0 THEN
            Insert into PNL3_TRX001_COPA (
                   COMPANY_CODE    , PERIOD         , PROFIT_CENTER      , BILL_TO_PARTY , SHIP_TO_PARTY, MTL_GROUP, PART_NO,PLANT_CODE,
                   AMT_LOCAL      , AMT_USD            , AMT_TWD         , SOURCE          ,MTL_TYPE,COST_ELEMENT,
                   R_KIND          , AREA1          ,AREA2               , AREA3            ,SEARCH_TERM,
                   CREATE_DATE
                   ) VALUES (
                        REC1.COMPANY_CODE       , REC1.PERIOD       , REC1.PROFIT_CENTER      , REC1.BILL_TO_PARTY , REC1.SHIP_TO_PARTY, REC1.MTL_GROUP, REC1.PART_NO,REC1.PLANT_CODE,
                        REC1.COGS_OH_LOCAL, REC1.COGS_OH_USD        , REC1.COGS_OH_TWD        , 'COPA_NPN'             ,REC1.MTL_TYPE,REC1.COST_ELEMENT,
                        'PL01'                  , '2'                 , '4'                      , '0'                    ,REC1.SEARCH_TERM,
                        SYSDATE 
                   );
             Commit;
          END IF;

    END LOOP;
    
	Update PNL3_TRX001_COPA
		Set END_CUSTOMER_ID = (
			select DISTINCT TRIM(END_CUSTOMER_NAME)
			from CEP_MAP009_PARTNO_CUSTOMER
			where TRIM(FG_MATERIAL_NO) = TRIM(PNL3_TRX001_COPA.PART_NO)
			and LAST_MODIFY_DATE <= SYSDATE
		)
	Where Period = t_Period;
	Commit;
    
    
    /*
     *  Profit center 20/21 且mtl group 001-059歸Lenovo
     *  其他不屬於20/21 但仍是001-059則歸  其他-材料轉售
     *  不屬於001-059的材料則用search term(但要考慮到如果是cogs-屬於特定cost element則不走這裡)
     *  空白料號-用SEarch term update
    */
	Update PNL3_TRX001_COPA
	   Set END_CUSTOMER_ID = 'LENOVO'
     Where Period = t_Period
	   AND PROFIT_CENTER IN ('0000000020','0000000021')
       AND MTL_GROUP BETWEEN '001' AND '059'
       AND MTL_TYPE = 'RAW'
       AND END_CUSTOMER_ID IS NULL;
    commit;

	Update PNL3_TRX001_COPA
	   Set END_CUSTOMER_ID = '其他-材料轉售'
     Where Period = t_Period
	   AND (PROFIT_CENTER NOT IN ('0000000020','0000000021') OR PROFIT_CENTER IS NULL)
       AND MTL_GROUP BETWEEN '001' AND '059'
       AND MTL_TYPE = 'RAW'
       AND END_CUSTOMER_ID IS NULL;
    commit;

    /*
	Update PNL3_TRX001_COPA
	   Set END_CUSTOMER_ID = '其他-材料轉售'
     Where Period = t_Period
	   AND PROFIT_CENTER IN ('0000000020','0000000021')
       AND MTL_GROUP NOT BETWEEN '001' AND '059'
       AND MTL_TYPE = 'RAW'
       AND END_CUSTOMER_ID IS NULL;
    commit;
    */
    
	Update PNL3_TRX001_COPA
	   Set END_CUSTOMER_ID = TRIM(SEARCH_TERM)
     Where Period = t_Period
       AND SEARCH_TERM IS NOT NULL
       AND END_CUSTOMER_ID IS NULL
       AND MTL_TYPE = 'RAW';
    commit;
    
    --2008/11/12 剩下的直接用SEARCH TERM UPDATE
	Update PNL3_TRX001_COPA
	   Set END_CUSTOMER_ID = TRIM(SEARCH_TERM)
     Where Period = t_Period
       AND SEARCH_TERM IS NOT NULL
       AND END_CUSTOMER_ID IS NULL
       AND (MTL_TYPE <> 'RAW' or MTL_TYPE IS NULL);
    commit;
       /*
    Update PNL3_TRX001_COPA
	   Set END_CUSTOMER_ID = 'OTHERS'
     Where Period = t_Period
       AND END_CUSTOMER_ID IS NULL;
       */
       
       
    FOR REC1 in C_PNL3_PLS001_R2 Loop 
        --因為組織改變,所以200805月把原本的38改成381,我們還是當成uabit的
         IF REC1.COMPANY_CODE  = '1101' THEN
           IF REC1.PROFIT_CENTER = '0000000034' OR REC1.PROFIT_CENTER = '0000000038' OR REC1.PROFIT_CENTER = '0000000381' THEN
              Insert into PNL3_TRX001_COPA (
                  COMPANY_CODE    , PERIOD         , PROFIT_CENTER      , 
                  AMT_LOCAL      , AMT_USD            , AMT_TWD         , SOURCE          ,
                  R_KIND          , AREA1          ,AREA2               , AREA3            ,
                  CREATE_DATE    ,END_CUSTOMER_ID
                      ) VALUES (
                        REC1.COMPANY_CODE       , REC1.PERIOD       , REC1.PROFIT_CENTER      , 
                        REC1.AMT_LOCAL    , REC1.AMT_USD            , REC1.AMT_TWD            , 'UPL001'               ,
                        'PL01'                  , '1'                 ,'1'                       , '0'                    ,
                        SYSDATE ,'UABIT''S CUST');
               Commit;
           ELSE

              Insert into PNL3_TRX001_COPA (
                  COMPANY_CODE    , PERIOD         , PROFIT_CENTER      , 
                  AMT_LOCAL      , AMT_USD            , AMT_TWD         , SOURCE          ,
                  R_KIND          , AREA1          ,AREA2               , AREA3            ,
                  CREATE_DATE     
                      ) VALUES (
                        REC1.COMPANY_CODE       , REC1.PERIOD       , REC1.PROFIT_CENTER      , 
                        REC1.AMT_LOCAL    , REC1.AMT_USD            , REC1.AMT_TWD            , 'UPL001'               ,
                        'PL01'                  , '1'                 ,'1'                       , '0'                    ,
                        SYSDATE   );
               Commit;
           END IF;
         ELSIF SUBSTR(REC1.COMPANY_CODE,1,1) = '9' THEN
              Insert into PNL3_TRX001_COPA (
                  COMPANY_CODE    , PERIOD         , PROFIT_CENTER      , 
                  AMT_LOCAL      , AMT_USD            , AMT_TWD         , SOURCE          ,
                  R_KIND          , AREA1          ,AREA2               , AREA3            ,
                  CREATE_DATE    ,END_CUSTOMER_ID
                      ) VALUES (
                        REC1.COMPANY_CODE       , REC1.PERIOD       , REC1.PROFIT_CENTER      , 
                        REC1.AMT_LOCAL    , REC1.AMT_USD            , REC1.AMT_TWD            , 'UPL001'               ,
                        'PL01'                  , '1'                 ,'1'                       , '0'                    ,
                        SYSDATE ,'投資公司');
               Commit;
         ELSIF  REC1.COMPANY_CODE  = '3100' THEN  --2008/1和2008/2 還有uk的Revenue,先歸OTHERS,反正以後沒有了
              Insert into PNL3_TRX001_COPA (
                  COMPANY_CODE    , PERIOD         , PROFIT_CENTER      , 
                  AMT_LOCAL      , AMT_USD            , AMT_TWD         , SOURCE          ,
                  R_KIND          , AREA1          ,AREA2               , AREA3            ,
                  CREATE_DATE    ,END_CUSTOMER_ID
                      ) VALUES (
                        REC1.COMPANY_CODE       , REC1.PERIOD       , REC1.PROFIT_CENTER      , 
                        REC1.AMT_LOCAL    , REC1.AMT_USD            , REC1.AMT_TWD            , 'UPL001'               ,
                        'PL01'                  , '1'                 ,'1'                       , '0'                    ,
                        SYSDATE ,'OTHERS');
               Commit;
         ELSE
              Insert into PNL3_TRX001_COPA (
                  COMPANY_CODE    , PERIOD         , PROFIT_CENTER      , 
                  AMT_LOCAL      , AMT_USD            , AMT_TWD         , SOURCE          ,
                  R_KIND          , AREA1          ,AREA2               , AREA3            ,
                  CREATE_DATE    
                      ) VALUES (
                        REC1.COMPANY_CODE       , REC1.PERIOD       , REC1.PROFIT_CENTER      , 
                        REC1.AMT_LOCAL    , REC1.AMT_USD            , REC1.AMT_TWD            , 'UPL001'               ,
                        'PL01'                  , '1'                 ,'1'                       , '0'                    ,
                        SYSDATE );
               Commit;
         END IF;

    END LOOP;
    
END PNL3_PLS001_COPA_TRX_V2;
/

