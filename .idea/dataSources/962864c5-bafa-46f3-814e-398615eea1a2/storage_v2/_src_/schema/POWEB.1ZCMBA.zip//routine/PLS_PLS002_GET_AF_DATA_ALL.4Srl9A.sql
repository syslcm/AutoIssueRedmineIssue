create PROCEDURE       "PLS_PLS002_GET_AF_DATA_ALL" (
  f_YYYYMM in VARCHAR2
)
AUTHID DEFINER
/*********************************************************************
  PROG-ID      : PLS_PLS002_GET_AF_DATA_ALL
                 ( called by ??? - 每次重新計算 by Site分攤EM資料時)
  PROG-ACTION  : 由 AFR_UPL001_AF_REPORT_DATA ＆ PNL_MSA001_EM_DATA &
                 PLS_PST004_ADJ
                 產生 (1)AF Data, (2)EM-AF Data, (3)EM after Adj. by Site
                 => PLS_PST005_AF_DATA
  Author       : KATHY
  Date         : 2014/06/20
  OA No.       : SAI043515
 ======================================================================                 
--Modify       : 2019/08/29 - SAI104649 - Kathy
--                      1.PNL_MSA001_EM_DATA Mapping to PNL_MAP007_ACCMAPPING
--                      2.Use PNL_MAP007_ACCMAPPING.ACCT_ID_AF to replace
--                           PNL_MSA001_EM_DATA.ACCT_ID 
-- 2019/12/05 SAI110406 Pattty Modify:
--                      1.Rename Procedure from 'PLS_PLS002_GET_AF_DATA' to 'PLS_PLS002_GET_AF_DATA_ALL'
--                      2.New field RPT_GRP = 'ALL'  
**********************************************************************/
is

  sRPT_GRP           PLS_PST005_AF_DATA.RPT_GRP%TYPE;            -- SAI110406

BEGIN


  sRPT_GRP := 'ALL';                                             -- SAI110406

-- -------------------------------------------------------------------------------
    /*   先刪除 AF 當月 DATA   */
-- -------------------------------------------------------------------------------
   DELETE FROM PLS_PST005_AF_DATA WHERE PERIOD = f_YYYYMM
                                    AND RPT_GRP = sRPT_GRP;      -- SAI110406

-- -------------------------------------------------------------------------------
    /*   產生 AF 當月 DATA   */
-- -------------------------------------------------------------------------------
   Insert into PLS_PST005_AF_DATA (
          PERIOD, KIND, PROFIT_CENTER, SITE, ACCT_ID, CURRENCY, AMOUNT, RPT_GRP
         )
   SELECT A.PERIOD, 'AF' AS Kind, A.pc as PROFIT_CENTER,
          A.company_code as SITE, F.ACCT_ID,
          'CNY' as CURRENCY,
          SUM(A.AMOUNT_LOC * b.sign * C.TO_CNY_RATE) as AMOUNT,
          sRPT_GRP AS RPT_GRP
   FROM AFR_UPL001_AF_REPORT_DATA A,
        AFR_MAP003_FORMAT_DTL_SUM B,
        AFR_MAP005_EX_RATE C,
        PNL_MAP006_SITE_MAPPING D,
        PLS_MAP002_AF_ACCT_MAPPING F
   WHERE A.PERIOD = f_YYYYMM
     AND A.ACCT_ID_DTL = B.ACCT_ID_DTL
     AND B.ACCT_ID_SUM = F.AF_ACCT_ID
     AND A.AMOUNT_LOC <> 0
     AND A.PERIOD = C.PERIOD
     AND A.CURRENCY_LOC = C.FROM_CURRENCY
     AND A.COMPANY_CODE = D.COMPANY_CODE
     AND A.CURRENCY_LOC = D.COMPANY_CURR
     AND C.GRP_CODE = D.GRP_CODE
     AND D.PLS_SITE = 'Y'
     AND F.YYYY = SUBSTRB(f_YYYYMM,1,4)
     AND F.EM_ORG = 'Y'
   GROUP BY A.PERIOD, A.pc, A.company_code, F.ACCT_ID;
   Commit;
--
-- -------------------------------------------------------------------------------
    /*   產生 AF與EM 當月差異數(AF)   */
-- -------------------------------------------------------------------------------
   Insert into PLS_PST005_AF_DATA (
          PERIOD, KIND, PROFIT_CENTER, SITE, ACCT_ID, CURRENCY, AMOUNT, RPT_GRP
         )
   SELECT A.PERIOD, 'AX' AS Kind, A.pc as PROFIT_CENTER,
          'V998' as SITE, F.ACCT_ID,
          'CNY' as CURRENCY,
          SUM(A.AMOUNT_LOC * b.sign * C.TO_CNY_RATE * -1) as AMOUNT,
          sRPT_GRP AS RPT_GRP
   FROM AFR_UPL001_AF_REPORT_DATA A,
        AFR_MAP003_FORMAT_DTL_SUM B,
        AFR_MAP005_EX_RATE C,
        PNL_MAP006_SITE_MAPPING D,
        PLS_MAP002_AF_ACCT_MAPPING F
   WHERE A.PERIOD = f_YYYYMM
     AND A.ACCT_ID_DTL = B.ACCT_ID_DTL
     AND B.ACCT_ID_SUM = F.AF_ACCT_ID
     AND A.AMOUNT_LOC <> 0
     AND A.PERIOD = C.PERIOD
     AND A.CURRENCY_LOC = C.FROM_CURRENCY
     AND A.COMPANY_CODE = D.COMPANY_CODE
     AND A.CURRENCY_LOC = D.COMPANY_CURR
     AND C.GRP_CODE = D.GRP_CODE
     AND D.PLS_SITE = 'Y'
     AND F.YYYY = SUBSTRB(f_YYYYMM,1,4)
     AND F.EM_ORG = 'Y'
   GROUP BY A.PERIOD, A.pc, F.ACCT_ID;
   Commit;
--
-- -------------------------------------------------------------------------------
    /*   產生 AF與EM 當月差異數(EM)   */
-- -------------------------------------------------------------------------------
   Insert into PLS_PST005_AF_DATA (
          PERIOD, KIND, PROFIT_CENTER, SITE, ACCT_ID, CURRENCY, AMOUNT, RPT_GRP
         )
   SELECT concat(A.YYYY, A.MONTH) AS PERIOD,
         'AY' AS Kind,
          a.PROFIT_CENTER,
         'V998' as SITE,
  ------ F.ACCT_ID,                     -- 2019/08/29 
         F.ACCT_ID_AF,                  -- 2019/08/29 
         'CNY' as CURRENCY,
          SUM(A.AMOUNT * C.TO_CNY_RATE) * 1000 as AMOUNT,
         sRPT_GRP AS RPT_GRP
   FROM PNL_MSA001_EM_DATA A,
        AFR_MAP005_EX_RATE C,
        PNL_MAP006_SITE_MAPPING D,
--------PLS_MAP003_EM_ACCT_MAPPING F    -- 2019/08/29 change to use MAP007
        PNL_MAP007_ACCMAPPING F         -- 2019/08/29
   WHERE A.YYYY = SUBSTRB(f_YYYYMM,1,4)
     AND A.MONTH= SUBSTRB(f_YYYYMM,5,2)
-----AND A.ACCT_ID = F.EM_ACCT_ID       -- 2019/08/29
     AND A.ACCOUNT = F.ACCNO            -- 2019/08/29
     AND A.AMOUNT <> 0
     AND concat(A.YYYY, A.MONTH) = C.PERIOD
     AND A.COMPANY_CODE = D.COMPANY_CODE
     AND C.FROM_CURRENCY = 'TWD'
     AND C.GRP_CODE ='USI'
-----AND F.YYYY = SUBSTRB(f_YYYYMM,1,4)  -- 2019/08/29
-----AND F.EM_ORG = 'Y'                  -- 2019/08/29
   GROUP BY A.YYYY, A.MONTH, a.PROFIT_CENTER, F.ACCT_ID_AF;
   Commit;
--
-- -------------------------------------------------------------------------------
    /*   產生 EM-after adjustment data   */
-- -------------------------------------------------------------------------------
   Insert into PLS_PST005_AF_DATA (
          PERIOD, KIND, PROFIT_CENTER, SITE, ACCT_ID, CURRENCY, AMOUNT, RPT_GRP
         )
   SELECT PERIOD,
         'EM' AS KIND,
          PROFIT_CENTER,
          SITE,
          ACCT_ID,
          CURRENCY,
          AMOUNT,
          sRPT_GRP AS RPT_GRP
   FROM PLS_PST004_ADJ
   WHERE PERIOD = f_YYYYMM
     AND RPT_GRP = sRPT_GRP;             -- SAI110406
   Commit;
--
-- -------------------------------------------------------------------------------

END PLS_PLS002_GET_AF_DATA_ALL;
/

