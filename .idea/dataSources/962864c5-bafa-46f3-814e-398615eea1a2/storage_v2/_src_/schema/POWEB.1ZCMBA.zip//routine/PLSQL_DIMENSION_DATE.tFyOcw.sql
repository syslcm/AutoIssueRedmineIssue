create PROCEDURE         "PLSQL_DIMENSION_DATE" (
  inDATE IN VARCHAR2
)
AUTHID DEFINER
is
   /*
   執行前需先修改 session 語系:
   alter session set  NLS_DATE_LANGUAGE = AMERICAN;
   */
   nDATE                DATE;
   nCOUNT               NUMBER(3);
   nDATE_KEY            DIMENSION_DATE.DATE_KEY%TYPE;
   nYYYY                DIMENSION_DATE.YYYY%TYPE;
   nMM                  DIMENSION_DATE.MM%TYPE;
   nDD                  DIMENSION_DATE.DD%TYPE;
   nQUARTER             DIMENSION_DATE.QUARTER%TYPE;
   nWEEK                DIMENSION_DATE.WEEK%TYPE;
   nDAY_OF_WK           DIMENSION_DATE.DAY_OF_WK%TYPE;
   nDAY_OF_YEAR         DIMENSION_DATE.DAY_OF_YEAR%TYPE;
   nMONTH_NAME          DIMENSION_DATE.MONTH_NAME%TYPE;
   nMONTH_ABB           DIMENSION_DATE.MONTH_ABB%TYPE;
   nDAY_OF_WK_NAME      DIMENSION_DATE.DAY_OF_WK_NAME%TYPE;
   nDAY_OF_WK_ABB       DIMENSION_DATE.DAY_OF_WK_ABB%TYPE;
   nMONTH_LASTDAY1      DIMENSION_DATE.DATE_KEY%TYPE;
   nMONTH_LASTDAY2      DIMENSION_DATE.MONTH_LASTDAY%TYPE;
BEGIN
  --LOOP START
  
  FOR nCOUNT IN 0 .. 366 LOOP
    nDATE := TO_DATE(inDATE,'YYYYMMDD') + nCOUNT;
    If TO_CHAR(nDATE,'YYYY') <> SUBSTR(inDATE,1,4) Then
      EXIT;
    End If;
    --Get data
    Select * into nDATE_KEY, nQUARTER, nWEEK, nDAY_OF_WK, nDAY_OF_YEAR, nMONTH_NAME, nMONTH_ABB,
                  nDAY_OF_WK_NAME, nDAY_OF_WK_ABB, nMONTH_LASTDAY1
      from (
        Select TRIM(TO_CHAR(nDATE,'YYYYMMDD')),
               TRIM('Q' || TO_CHAR(nDATE,'Q')),
               TRIM(TO_CHAR(nDATE,'WW')),
               TRIM(TO_CHAR(TO_NUMBER(TO_CHAR(nDATE,'D')) - 1)),
               TRIM(TO_CHAR(nDATE,'DDD')),
               TRIM(TO_CHAR(nDATE,'MONTH')),
               TRIM(TO_CHAR(nDATE,'MON')),
               TRIM(TO_CHAR(nDATE,'DAY')),
               TRIM(TO_CHAR(nDATE,'DY')),
               TRIM(TO_CHAR(LAST_DAY(nDATE),'YYYYMMDD'))
          from DUAL
    );
    nYYYY := SUBSTR(nDATE_KEY,1,4);
    nMM := SUBSTR(nDATE_KEY,5,2);
    nDD := SUBSTR(nDATE_KEY,7,2);
    If nDATE_KEY = nMONTH_LASTDAY1 Then
      nMONTH_LASTDAY2 := 'Y';
    Else
      nMONTH_LASTDAY2 := 'N';
    End If;
    --UPDATE DB
    BEGIN
      Insert into DIMENSION_DATE (
             DATE_KEY, YYYY, MM, DD, QUARTER, WEEK, DAY_OF_WK, DAY_OF_YEAR,
             MONTH_NAME, MONTH_ABB, DAY_OF_WK_NAME, DAY_OF_WK_ABB, MONTH_LASTDAY,
			 YYYYMM, YYYYWW, PDM_DATE
           ) values (
             nDATE_KEY, nYYYY, nMM, nDD, nQUARTER, nWEEK, nDAY_OF_WK, nDAY_OF_YEAR,
             nMONTH_NAME, nMONTH_ABB, nDAY_OF_WK_NAME, nDAY_OF_WK_ABB, nMONTH_LASTDAY2,
			 substr(nDATE_KEY,1,6),
			 TO_CHAR(TO_DATE(nDATE_KEY,'YYYYMMDD'), 'IYYYIW'),
			 TO_DATE(nDATE_KEY,'YYYYMMDD')
           );
      Commit;
    EXCEPTION
      WHEN OTHERS THEN
        Rollback;
    END;
  END LOOP;
END PLSQL_DIMENSION_DATE;
/

