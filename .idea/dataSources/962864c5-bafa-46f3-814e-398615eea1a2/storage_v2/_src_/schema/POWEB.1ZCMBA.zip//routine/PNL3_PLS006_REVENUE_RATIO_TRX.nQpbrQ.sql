create PROCEDURE       PNL3_PLS006_REVENUE_RATIO_TRX (
  --inCompany  in VARCHAR2,
  inPeriod in VARCHAR2
  --此程式在產生END CUSTOMER REVENUE比率,原本在測試時期供費用比率計算
  --現在供GM (也就是COGS)的使用,Revenue比率有三種
  --1. Global(只看全公司END CUSTOMER的比率
  --2. Profit center+End customer 看Profit center下的end customer比率
  --3. Profit center+ site + End Customer 依site + profit center來看end customer的比率<--只有特定Profit center會用到
  --2011/1/7 2010/12 pc 90的revenu 是0,會有除0的錯誤,所以加上判斷 HAVING SUM(AMT_TWD) > 0 
)
AUTHID DEFINER
is

  --site + profit center的 end customer revenue比率
  CURSOR C_PNL2_REVENUE is
     SELECT COMPANY_CODE,PROFIT_CENTER,SUM(AMT_TWD) AMT_TWD
     FROM  PNL3_TRX001_COPA
     WHERE PERIOD = inPeriod 
     AND AREA1 = '1'
     AND AREA2 = '1'
     AND AREA3 = '0'
     --AND SOURCE <> 'UPL001'
     GROUP BY COMPANY_CODE,PROFIT_CENTER
     HAVING SUM(AMT_TWD) > 0 ;
     
  --profit center的 end customer revenue比率   
 CURSOR C_PNL2_REVENUE_P is
     SELECT PROFIT_CENTER,SUM(AMT_TWD) AMT_TWD
     FROM  PNL3_TRX001_COPA
     WHERE PERIOD = inPeriod 
     AND AREA1 = '1'
     AND AREA2 = '1'
     AND AREA3 = '0'
     --AND SOURCE <> 'UPL001'
     GROUP BY PROFIT_CENTER
     HAVING SUM(AMT_TWD) > 0 ;
     
   --全公司 end customer revenue比率  
  CURSOR C_PNL3_REVENUE_C is
     SELECT END_CUSTOMER_ID,SUM(AMT_TWD) AMT_TWD
     FROM  PNL3_TRX001_COPA
     WHERE PERIOD = inPeriod 
     AND AREA1 = '1'
     AND AREA2 = '1'
     AND AREA3 = '0'
     --AND SOURCE <> 'UPL001'
     GROUP BY END_CUSTOMER_ID
     HAVING SUM(AMT_TWD) > 0 ;
     
     
     
     
     a_Rate          PNL3_MAP001_CUSTOMER_RATE.RATE%TYPE;
     a_Revenue       PNL3_TRX001_COPA.AMT_TWD%TYPE;
 BEGIN
 
   ----> SITE + Profit center的邏輯
   DELETE FROM PNL3_MAP001_SITE_RATE
   WHERE Period = inPeriod ;
   Commit;
   

   FOR REC1 in C_PNL2_REVENUE Loop
        FOR REC2 in (SELECT COMPANY_CODE,END_CUSTOMER_ID,SUM(AMT_TWD) AMT_TWD FROM PNL3_TRX001_COPA 
                      WHERE PROFIT_CENTER = REC1.PROFIT_CENTER
                        AND PERIOD = inPeriod
                        AND COMPANY_CODE = REC1.COMPANY_CODE
                        AND AREA1 = '1'
                        AND AREA2 = '1'
                        AND AREA3 = '0'
                        AND AMT_TWD <> 0
                        --AND SOURCE <> 'UPL001'
                        GROUP BY COMPANY_CODE,END_CUSTOMER_ID ORDER BY AMT_TWD DESC) Loop
            --2008/12/4 因UPLOAD的資料未上,所以只有COGS沒有Reverue,因此要加入判斷REC1.AMT_TWD <> 0,否則會有問題,待user 上傳後即無問題
            if REC1.AMT_TWD = 0 THEN
              a_Rate := 0;
            ELSE            
              a_Rate :=  REC2.AMT_TWD / REC1.AMT_TWD;
            END IF;   
               

            INSERT INTO PNL3_MAP001_SITE_RATE
                  (PERIOD   ,PROFIT_CENTER   ,COMPANY_CODE   ,END_CUSTOMER_ID ,
                   R_KIND   ,AREA1           ,AREA2          ,AREA3           ,
                   RATE     ,CHANGE_DATE
                  )
                  VALUES (
                   inPeriod ,REC1.PROFIT_CENTER , REC2.COMPANY_CODE,REC2.END_CUSTOMER_ID,
                   'PL01'   ,'4'                 , '1'              ,'1'                  ,
                   a_Rate   ,sysdate
                  );
            COMMIT;      
            INSERT INTO PNL3_MAP001_SITE_RATE
                  (PERIOD   ,PROFIT_CENTER   ,COMPANY_CODE   ,END_CUSTOMER_ID ,
                   R_KIND   ,AREA1           ,AREA2          ,AREA3           ,
                   RATE     ,CHANGE_DATE
                  )
                  VALUES (
                   inPeriod ,REC1.PROFIT_CENTER , REC2.COMPANY_CODE,REC2.END_CUSTOMER_ID,
                   'PL01'   ,'4'                 , '1'             , '2'                  ,
                   a_Rate   ,sysdate
                  );
            COMMIT;      
            INSERT INTO PNL3_MAP001_SITE_RATE
                  (PERIOD   ,PROFIT_CENTER   ,COMPANY_CODE   ,END_CUSTOMER_ID ,
                   R_KIND   ,AREA1           ,AREA2          ,AREA3           ,
                   RATE     ,CHANGE_DATE
                  )
                  VALUES (
                   inPeriod ,REC1.PROFIT_CENTER , REC2.COMPANY_CODE,REC2.END_CUSTOMER_ID,
                   'PL01'   ,'4'                 , '1'             , '3'                  ,
                   a_Rate   ,sysdate
                  );
            COMMIT;      
            INSERT INTO PNL3_MAP001_SITE_RATE
                  (PERIOD   ,PROFIT_CENTER   ,COMPANY_CODE   ,END_CUSTOMER_ID ,
                   R_KIND   ,AREA1           ,AREA2          ,AREA3           ,
                   RATE     ,CHANGE_DATE
                  )
                  VALUES (
                   inPeriod ,REC1.PROFIT_CENTER , REC2.COMPANY_CODE,REC2.END_CUSTOMER_ID,
                   'PL01'   ,'4'                 , '1'              ,'4'                  ,
                   a_Rate   ,sysdate
                  );  
            COMMIT;      
            INSERT INTO PNL3_MAP001_SITE_RATE
                  (PERIOD   ,PROFIT_CENTER   ,COMPANY_CODE   ,END_CUSTOMER_ID ,
                   R_KIND   ,AREA1           ,AREA2          ,AREA3           ,
                   RATE     ,CHANGE_DATE
                  )
                  VALUES (
                   inPeriod ,REC1.PROFIT_CENTER , REC2.COMPANY_CODE,REC2.END_CUSTOMER_ID,
                   'PL01'   ,'4'                 , '1'             , '5'                  ,
                   a_Rate   ,sysdate
                  );
            COMMIT;      
            INSERT INTO PNL3_MAP001_SITE_RATE
                  (PERIOD   ,PROFIT_CENTER   ,COMPANY_CODE   ,END_CUSTOMER_ID ,
                   R_KIND   ,AREA1           ,AREA2          ,AREA3           ,
                   RATE     ,CHANGE_DATE
                  )
                  VALUES (
                   inPeriod ,REC1.PROFIT_CENTER , REC2.COMPANY_CODE,REC2.END_CUSTOMER_ID,
                   'PL01'   ,'4'                 , '1'              ,'6'                  ,
                   a_Rate   ,sysdate
                  );    
            COMMIT;      
            INSERT INTO PNL3_MAP001_SITE_RATE
                  (PERIOD   ,PROFIT_CENTER   ,COMPANY_CODE   ,END_CUSTOMER_ID ,
                   R_KIND   ,AREA1           ,AREA2          ,AREA3           ,
                   RATE     ,CHANGE_DATE
                  )
                  VALUES (
                   inPeriod ,REC1.PROFIT_CENTER , REC2.COMPANY_CODE,REC2.END_CUSTOMER_ID,
                   'PL01'   ,'4'                 , '1'             , '7'                  ,
                   a_Rate   ,sysdate
                  );  
            COMMIT;      
            INSERT INTO PNL3_MAP001_SITE_RATE
                  (PERIOD   ,PROFIT_CENTER   ,COMPANY_CODE   ,END_CUSTOMER_ID ,
                   R_KIND   ,AREA1           ,AREA2          ,AREA3           ,
                   RATE     ,CHANGE_DATE
                  )
                  VALUES (
                   inPeriod ,REC1.PROFIT_CENTER , REC2.COMPANY_CODE,REC2.END_CUSTOMER_ID,
                   'PL01'   ,'4'                 , '2'              ,'1'                  ,
                   a_Rate   ,sysdate
                  );
            COMMIT;      
            INSERT INTO PNL3_MAP001_SITE_RATE
                  (PERIOD   ,PROFIT_CENTER   ,COMPANY_CODE   ,END_CUSTOMER_ID ,
                   R_KIND   ,AREA1           ,AREA2          ,AREA3           ,
                   RATE     ,CHANGE_DATE
                  )
                  VALUES (
                   inPeriod ,REC1.PROFIT_CENTER , REC2.COMPANY_CODE,REC2.END_CUSTOMER_ID,
                   'PL01'   ,'4'                 , '2'             , '2'                  ,
                   a_Rate   ,sysdate
                  );
            COMMIT;      
            INSERT INTO PNL3_MAP001_SITE_RATE
                  (PERIOD   ,PROFIT_CENTER   ,COMPANY_CODE   ,END_CUSTOMER_ID ,
                   R_KIND   ,AREA1           ,AREA2          ,AREA3           ,
                   RATE     ,CHANGE_DATE
                  )
                  VALUES (
                   inPeriod ,REC1.PROFIT_CENTER , REC2.COMPANY_CODE,REC2.END_CUSTOMER_ID,
                   'PL01'   ,'4'                 , '2'              ,'3'                  ,
                   a_Rate   ,sysdate
                  );
            COMMIT;      
            INSERT INTO PNL3_MAP001_SITE_RATE
                  (PERIOD   ,PROFIT_CENTER   ,COMPANY_CODE   ,END_CUSTOMER_ID ,
                   R_KIND   ,AREA1           ,AREA2          ,AREA3           ,
                   RATE     ,CHANGE_DATE
                  )
                  VALUES (
                   inPeriod ,REC1.PROFIT_CENTER , REC2.COMPANY_CODE,REC2.END_CUSTOMER_ID,
                   'PL01'   ,'4'                 , '2'             , '4'                  ,
                   a_Rate   ,sysdate
                  ); 
            COMMIT;      
            INSERT INTO PNL3_MAP001_SITE_RATE
                  (PERIOD   ,PROFIT_CENTER   ,COMPANY_CODE   ,END_CUSTOMER_ID ,
                   R_KIND   ,AREA1           ,AREA2          ,AREA3           ,
                   RATE     ,CHANGE_DATE
                  )
                  VALUES (
                   inPeriod ,REC1.PROFIT_CENTER , REC2.COMPANY_CODE,REC2.END_CUSTOMER_ID,
                   'PL01'   ,'4'                 , '3'              ,'1'                  ,
                   a_Rate   ,sysdate
                  );
            COMMIT;      
            INSERT INTO PNL3_MAP001_SITE_RATE
                  (PERIOD   ,PROFIT_CENTER   ,COMPANY_CODE   ,END_CUSTOMER_ID ,
                   R_KIND   ,AREA1           ,AREA2          ,AREA3           ,
                   RATE     ,CHANGE_DATE
                  )
                  VALUES (
                   inPeriod ,REC1.PROFIT_CENTER , REC2.COMPANY_CODE,REC2.END_CUSTOMER_ID,
                   'PL01'   ,'4'                 , '3'             , '2'                  ,
                   a_Rate   ,sysdate
                  );
            COMMIT;      
            INSERT INTO PNL3_MAP001_SITE_RATE
                  (PERIOD   ,PROFIT_CENTER   ,COMPANY_CODE   ,END_CUSTOMER_ID ,
                   R_KIND   ,AREA1           ,AREA2          ,AREA3           ,
                   RATE     ,CHANGE_DATE
                  )
                  VALUES (
                   inPeriod ,REC1.PROFIT_CENTER , REC2.COMPANY_CODE,REC2.END_CUSTOMER_ID,
                   'PL01'   ,'4'                 , '3'              ,'3'                  ,
                   a_Rate   ,sysdate
                  );
            COMMIT;      
            INSERT INTO PNL3_MAP001_SITE_RATE
                  (PERIOD   ,PROFIT_CENTER   ,COMPANY_CODE   ,END_CUSTOMER_ID ,
                   R_KIND   ,AREA1           ,AREA2          ,AREA3           ,
                   RATE     ,CHANGE_DATE
                  )
                  VALUES (
                   inPeriod ,REC1.PROFIT_CENTER , REC2.COMPANY_CODE,REC2.END_CUSTOMER_ID,
                   'PL01'   ,'4'                 , '3'             , '4'                  ,
                   a_Rate   ,sysdate
                  );
            COMMIT;       
        END LOOP;
   END LOOP;
   
   ---- site + profit center 的?輯結束點
   
   
   
   ----> 以PROFIT CENTER來看 CUSTOMER REVENUE比率 邏輯開始 ----->
      DELETE FROM PNL3_MAP001_CUSTOMER_RATE
   WHERE Period = inPeriod ;
   Commit;
   

   FOR REC1 in C_PNL2_REVENUE_P Loop
        FOR REC2 in (SELECT END_CUSTOMER_ID,SUM(AMT_TWD) AMT_TWD FROM PNL3_TRX001_COPA 
                      WHERE PROFIT_CENTER = REC1.PROFIT_CENTER
                        AND PERIOD = inPeriod
                        --AND COMPANY_CODE = REC1.COMPANY_CODE
                        AND AREA1 = '1'
                        AND AREA2 = '1'
                        AND AREA3 = '0'
                        AND AMT_TWD <> 0
                        --AND SOURCE <> 'UPL001'
                        GROUP BY END_CUSTOMER_ID ORDER BY AMT_TWD DESC) Loop
            a_Rate :=  REC2.AMT_TWD / REC1.AMT_TWD;   
               

            INSERT INTO PNL3_MAP001_CUSTOMER_RATE
                  (PERIOD   ,PROFIT_CENTER   ,END_CUSTOMER_ID ,
                   R_KIND   ,AREA1           ,AREA2          ,AREA3           ,
                   RATE     ,CHANGE_DATE
                  )
                  VALUES (
                   inPeriod ,REC1.PROFIT_CENTER  ,REC2.END_CUSTOMER_ID,
                   'PL01'   ,'4'                 , '1'              ,'1'                  ,
                   a_Rate   ,sysdate
                  );
            COMMIT;      
            INSERT INTO PNL3_MAP001_CUSTOMER_RATE
                  (PERIOD   ,PROFIT_CENTER   ,END_CUSTOMER_ID ,
                   R_KIND   ,AREA1           ,AREA2          ,AREA3           ,
                   RATE     ,CHANGE_DATE
                  )
                  VALUES (
                   inPeriod ,REC1.PROFIT_CENTER ,REC2.END_CUSTOMER_ID,
                   'PL01'   ,'4'                 , '1'             , '2'                  ,
                   a_Rate   ,sysdate
                  );
            COMMIT;      
            INSERT INTO PNL3_MAP001_CUSTOMER_RATE
                  (PERIOD   ,PROFIT_CENTER   ,END_CUSTOMER_ID ,
                   R_KIND   ,AREA1           ,AREA2          ,AREA3           ,
                   RATE     ,CHANGE_DATE
                  )
                  VALUES (
                   inPeriod ,REC1.PROFIT_CENTER ,REC2.END_CUSTOMER_ID,
                   'PL01'   ,'4'                 , '1'             , '3'                  ,
                   a_Rate   ,sysdate
                  );
            COMMIT;      
            INSERT INTO PNL3_MAP001_CUSTOMER_RATE
                  (PERIOD   ,PROFIT_CENTER   ,END_CUSTOMER_ID ,
                   R_KIND   ,AREA1           ,AREA2          ,AREA3           ,
                   RATE     ,CHANGE_DATE
                  )
                  VALUES (
                   inPeriod ,REC1.PROFIT_CENTER ,REC2.END_CUSTOMER_ID,
                   'PL01'   ,'4'                 , '1'              ,'4'                  ,
                   a_Rate   ,sysdate
                  );  
            COMMIT;      
            INSERT INTO PNL3_MAP001_CUSTOMER_RATE
                  (PERIOD   ,PROFIT_CENTER   ,END_CUSTOMER_ID ,
                   R_KIND   ,AREA1           ,AREA2          ,AREA3           ,
                   RATE     ,CHANGE_DATE
                  )
                  VALUES (
                   inPeriod ,REC1.PROFIT_CENTER ,REC2.END_CUSTOMER_ID,
                   'PL01'   ,'4'                 , '1'             , '5'                  ,
                   a_Rate   ,sysdate
                  );
            COMMIT;      
            INSERT INTO PNL3_MAP001_CUSTOMER_RATE
                  (PERIOD   ,PROFIT_CENTER   ,END_CUSTOMER_ID ,
                   R_KIND   ,AREA1           ,AREA2          ,AREA3           ,
                   RATE     ,CHANGE_DATE
                  )
                  VALUES (
                   inPeriod ,REC1.PROFIT_CENTER ,REC2.END_CUSTOMER_ID,
                   'PL01'   ,'4'                 , '1'              ,'6'                  ,
                   a_Rate   ,sysdate
                  );    
            COMMIT;      
            INSERT INTO PNL3_MAP001_CUSTOMER_RATE
                  (PERIOD   ,PROFIT_CENTER   ,END_CUSTOMER_ID ,
                   R_KIND   ,AREA1           ,AREA2          ,AREA3           ,
                   RATE     ,CHANGE_DATE
                  )
                  VALUES (
                   inPeriod ,REC1.PROFIT_CENTER ,REC2.END_CUSTOMER_ID,
                   'PL01'   ,'4'                 , '1'             , '7'                  ,
                   a_Rate   ,sysdate
                  );  
            COMMIT;      
            INSERT INTO PNL3_MAP001_CUSTOMER_RATE
                  (PERIOD   ,PROFIT_CENTER      ,END_CUSTOMER_ID ,
                   R_KIND   ,AREA1           ,AREA2          ,AREA3           ,
                   RATE     ,CHANGE_DATE
                  )
                  VALUES (
                   inPeriod ,REC1.PROFIT_CENTER ,REC2.END_CUSTOMER_ID,
                   'PL01'   ,'4'                 , '2'              ,'1'                  ,
                   a_Rate   ,sysdate
                  );
            COMMIT;      
            INSERT INTO PNL3_MAP001_CUSTOMER_RATE
                  (PERIOD   ,PROFIT_CENTER    ,END_CUSTOMER_ID ,
                   R_KIND   ,AREA1           ,AREA2          ,AREA3           ,
                   RATE     ,CHANGE_DATE
                  )
                  VALUES (
                   inPeriod ,REC1.PROFIT_CENTER ,REC2.END_CUSTOMER_ID,
                   'PL01'   ,'4'                 , '2'             , '2'                  ,
                   a_Rate   ,sysdate
                  );
            COMMIT;      
            INSERT INTO PNL3_MAP001_CUSTOMER_RATE
                  (PERIOD   ,PROFIT_CENTER   ,END_CUSTOMER_ID ,
                   R_KIND   ,AREA1           ,AREA2          ,AREA3           ,
                   RATE     ,CHANGE_DATE
                  )
                  VALUES (
                   inPeriod ,REC1.PROFIT_CENTER ,REC2.END_CUSTOMER_ID,
                   'PL01'   ,'4'                 , '2'              ,'3'                  ,
                   a_Rate   ,sysdate
                  );
            COMMIT;      
            INSERT INTO PNL3_MAP001_CUSTOMER_RATE
                  (PERIOD   ,PROFIT_CENTER      ,END_CUSTOMER_ID ,
                   R_KIND   ,AREA1           ,AREA2          ,AREA3           ,
                   RATE     ,CHANGE_DATE
                  )
                  VALUES (
                   inPeriod ,REC1.PROFIT_CENTER ,REC2.END_CUSTOMER_ID,
                   'PL01'   ,'4'                 , '2'             , '4'                  ,
                   a_Rate   ,sysdate
                  ); 
            COMMIT;      
            INSERT INTO PNL3_MAP001_CUSTOMER_RATE
                  (PERIOD   ,PROFIT_CENTER      ,END_CUSTOMER_ID ,
                   R_KIND   ,AREA1           ,AREA2          ,AREA3           ,
                   RATE     ,CHANGE_DATE
                  )
                  VALUES (
                   inPeriod ,REC1.PROFIT_CENTER ,REC2.END_CUSTOMER_ID,
                   'PL01'   ,'4'                 , '3'              ,'1'                  ,
                   a_Rate   ,sysdate
                  );
            COMMIT;      
            INSERT INTO PNL3_MAP001_CUSTOMER_RATE
                  (PERIOD   ,PROFIT_CENTER      ,END_CUSTOMER_ID ,
                   R_KIND   ,AREA1           ,AREA2          ,AREA3           ,
                   RATE     ,CHANGE_DATE
                  )
                  VALUES (
                   inPeriod ,REC1.PROFIT_CENTER ,REC2.END_CUSTOMER_ID,
                   'PL01'   ,'4'                 , '3'             , '2'                  ,
                   a_Rate   ,sysdate
                  );
            COMMIT;      
            INSERT INTO PNL3_MAP001_CUSTOMER_RATE
                  (PERIOD   ,PROFIT_CENTER      ,END_CUSTOMER_ID ,
                   R_KIND   ,AREA1           ,AREA2          ,AREA3           ,
                   RATE     ,CHANGE_DATE
                  )
                  VALUES (
                   inPeriod ,REC1.PROFIT_CENTER ,REC2.END_CUSTOMER_ID,
                   'PL01'   ,'4'                 , '3'              ,'3'                  ,
                   a_Rate   ,sysdate
                  );
            COMMIT;      
            INSERT INTO PNL3_MAP001_CUSTOMER_RATE
                  (PERIOD   ,PROFIT_CENTER   ,END_CUSTOMER_ID ,
                   R_KIND   ,AREA1           ,AREA2          ,AREA3           ,
                   RATE     ,CHANGE_DATE
                  )
                  VALUES (
                   inPeriod ,REC1.PROFIT_CENTER ,REC2.END_CUSTOMER_ID,
                   'PL01'   ,'4'                 , '3'             , '4'                  ,
                   a_Rate   ,sysdate
                  );
            COMMIT;       
        END LOOP;
   END LOOP;
   
   ----> 以PROFIT CENTER來看 CUSTOMER REVENUE比率 邏輯結束<-------------
   
   ----> 全公司的END CUSTOMER REVENUE比率(不看SITE和PROFIT CENTER) 開始
   DELETE FROM PNL3_MAP001_GLOBAL_CUST_RATE
   WHERE Period = inPeriod ;
   Commit;
   
   a_REVENUE := 0;
   BEGIN
     SELECT SUM(AMT_TWD) INTO a_REVENUE
       FROM  PNL3_TRX001_COPA
      WHERE PERIOD = inPeriod 
        AND AREA1 = '1'
        AND AREA2 = '1'
        AND AREA3 = '0';
        --AND SOURCE <> 'UPL001';
   EXCEPTION 
     WHEN OTHERS THEN
       a_REVENUE := 0;
   END;
   IF a_REVENUE <> 0 THEN
      FOR REC1 in C_PNL3_REVENUE_C Loop
           a_Rate :=  REC1.AMT_TWD / a_REVENUE;   
               

            INSERT INTO PNL3_MAP001_GLOBAL_CUST_RATE
                  (PERIOD   ,END_CUSTOMER_ID ,
                   R_KIND   ,AREA1           ,AREA2          ,AREA3           ,
                   RATE     ,CHANGE_DATE
                  )
                  VALUES (
                   inPeriod ,REC1.END_CUSTOMER_ID,
                   'PL01'   ,'4'                 , '1'              ,'1'                  ,
                   a_Rate   ,sysdate
                  );
            COMMIT;      
            INSERT INTO PNL3_MAP001_GLOBAL_CUST_RATE
                  (PERIOD   ,END_CUSTOMER_ID ,
                   R_KIND   ,AREA1           ,AREA2          ,AREA3           ,
                   RATE     ,CHANGE_DATE
                  )
                  VALUES (
                   inPeriod ,REC1.END_CUSTOMER_ID,
                   'PL01'   ,'4'                 , '1'             , '2'                  ,
                   a_Rate   ,sysdate
                  );
            COMMIT;      
            INSERT INTO PNL3_MAP001_GLOBAL_CUST_RATE
                  (PERIOD   ,END_CUSTOMER_ID ,
                   R_KIND   ,AREA1           ,AREA2          ,AREA3           ,
                   RATE     ,CHANGE_DATE
                  )
                  VALUES (
                   inPeriod ,REC1.END_CUSTOMER_ID,
                   'PL01'   ,'4'                 , '1'             , '3'                  ,
                   a_Rate   ,sysdate
                  );
            COMMIT;      
            INSERT INTO PNL3_MAP001_GLOBAL_CUST_RATE
                  (PERIOD   ,END_CUSTOMER_ID ,
                   R_KIND   ,AREA1           ,AREA2          ,AREA3           ,
                   RATE     ,CHANGE_DATE
                  )
                  VALUES (
                   inPeriod ,REC1.END_CUSTOMER_ID,
                   'PL01'   ,'4'                 , '1'              ,'4'                  ,
                   a_Rate   ,sysdate
                  );  
            COMMIT;      
            INSERT INTO PNL3_MAP001_GLOBAL_CUST_RATE
                  (PERIOD   ,END_CUSTOMER_ID ,
                   R_KIND   ,AREA1           ,AREA2          ,AREA3           ,
                   RATE     ,CHANGE_DATE
                  )
                  VALUES (
                   inPeriod ,REC1.END_CUSTOMER_ID,
                   'PL01'   ,'4'                 , '1'             , '5'                  ,
                   a_Rate   ,sysdate
                  );
            COMMIT;      
            INSERT INTO PNL3_MAP001_GLOBAL_CUST_RATE
                  (PERIOD   ,END_CUSTOMER_ID ,
                   R_KIND   ,AREA1           ,AREA2          ,AREA3           ,
                   RATE     ,CHANGE_DATE
                  )
                  VALUES (
                   inPeriod ,REC1.END_CUSTOMER_ID,
                   'PL01'   ,'4'                 , '1'              ,'6'                  ,
                   a_Rate   ,sysdate
                  );    
            COMMIT;      
            INSERT INTO PNL3_MAP001_GLOBAL_CUST_RATE
                  (PERIOD   ,END_CUSTOMER_ID ,
                   R_KIND   ,AREA1           ,AREA2          ,AREA3           ,
                   RATE     ,CHANGE_DATE
                  )
                  VALUES (
                   inPeriod ,REC1.END_CUSTOMER_ID,
                   'PL01'   ,'4'                 , '1'             , '7'                  ,
                   a_Rate   ,sysdate
                  );  
            COMMIT;      
            INSERT INTO PNL3_MAP001_GLOBAL_CUST_RATE
                  (PERIOD   ,END_CUSTOMER_ID ,
                   R_KIND   ,AREA1           ,AREA2          ,AREA3           ,
                   RATE     ,CHANGE_DATE
                  )
                  VALUES (
                   inPeriod ,REC1.END_CUSTOMER_ID,
                   'PL01'   ,'4'                 , '2'              ,'1'                  ,
                   a_Rate   ,sysdate
                  );
            COMMIT;      
            INSERT INTO PNL3_MAP001_GLOBAL_CUST_RATE
                  (PERIOD   ,END_CUSTOMER_ID ,
                   R_KIND   ,AREA1           ,AREA2          ,AREA3           ,
                   RATE     ,CHANGE_DATE
                  )
                  VALUES (
                   inPeriod ,REC1.END_CUSTOMER_ID,
                   'PL01'   ,'4'                 , '2'             , '2'                  ,
                   a_Rate   ,sysdate
                  );
            COMMIT;      
            INSERT INTO PNL3_MAP001_GLOBAL_CUST_RATE
                  (PERIOD   ,END_CUSTOMER_ID ,
                   R_KIND   ,AREA1           ,AREA2          ,AREA3           ,
                   RATE     ,CHANGE_DATE
                  )
                  VALUES (
                   inPeriod ,REC1.END_CUSTOMER_ID,
                   'PL01'   ,'4'                 , '2'              ,'3'                  ,
                   a_Rate   ,sysdate
                  );
            COMMIT;      
            INSERT INTO PNL3_MAP001_GLOBAL_CUST_RATE
                  (PERIOD   ,END_CUSTOMER_ID ,
                   R_KIND   ,AREA1           ,AREA2          ,AREA3           ,
                   RATE     ,CHANGE_DATE
                  )
                  VALUES (
                   inPeriod ,REC1.END_CUSTOMER_ID,
                   'PL01'   ,'4'                 , '2'             , '4'                  ,
                   a_Rate   ,sysdate
                  ); 
            COMMIT;      
            INSERT INTO PNL3_MAP001_GLOBAL_CUST_RATE
                  (PERIOD   ,END_CUSTOMER_ID ,
                   R_KIND   ,AREA1           ,AREA2          ,AREA3           ,
                   RATE     ,CHANGE_DATE
                  )
                  VALUES (
                   inPeriod ,REC1.END_CUSTOMER_ID,
                   'PL01'   ,'4'                 , '3'              ,'1'                  ,
                   a_Rate   ,sysdate
                  );
            COMMIT;      
            INSERT INTO PNL3_MAP001_GLOBAL_CUST_RATE
                  (PERIOD   ,END_CUSTOMER_ID ,
                   R_KIND   ,AREA1           ,AREA2          ,AREA3           ,
                   RATE     ,CHANGE_DATE
                  )
                  VALUES (
                   inPeriod ,REC1.END_CUSTOMER_ID,
                   'PL01'   ,'4'                 , '3'             , '2'                  ,
                   a_Rate   ,sysdate
                  );
            COMMIT;      
            INSERT INTO PNL3_MAP001_GLOBAL_CUST_RATE
                  (PERIOD   ,END_CUSTOMER_ID ,
                   R_KIND   ,AREA1           ,AREA2          ,AREA3           ,
                   RATE     ,CHANGE_DATE
                  )
                  VALUES (
                   inPeriod ,REC1.END_CUSTOMER_ID,
                   'PL01'   ,'4'                 , '3'              ,'3'                  ,
                   a_Rate   ,sysdate
                  );
            COMMIT;      
            INSERT INTO PNL3_MAP001_GLOBAL_CUST_RATE
                  (PERIOD   ,END_CUSTOMER_ID ,
                   R_KIND   ,AREA1           ,AREA2          ,AREA3           ,
                   RATE     ,CHANGE_DATE
                  )
                  VALUES (
                   inPeriod ,REC1.END_CUSTOMER_ID,
                   'PL01'   ,'4'                 , '3'             , '4'                  ,
                   a_Rate   ,sysdate
                  );
            COMMIT;   
      END LOOP;
   END IF;

    ----> 全公司的END CUSTOMER REVENUE比率(不看SITE和PROFIT CENTER) 邏輯結束 <----
END PNL3_PLS006_REVENUE_RATIO_TRX;
/

