create PROCEDURE test_pls2_insert (p_array_size IN PLS_INTEGER DEFAULT 1000)
IS
   type row_type is table of KPI_SAP001_COPA_TRX%rowtype index by binary_integer;
   rows row_type;
   CURSOR cur1 IS SELECT * FROM KPI_SAP001_COPA_TRX where period like '2012%';
 begin
    OPEN cur1;
    FOR vqtd IN 1..50000 loop
         FETCH cur1 BULK COLLECT INTO rows limit p_array_size;
         FORALL i IN 1..rows.COUNT
              INSERT INTO T1 VALUES rows(i);
    EXIT WHEN cur1%NOTFOUND;
    commit;
    --dbms_lock.sleep(5);
    END LOOP;
    CLOSE cur1;
    commit;
END test_pls2_insert;
/

