create PROCEDURE       PNL2_PLS006_EM_TRX (
  inPeriod        in VARCHAR2
  
  --2008/9/17 Create to Process get Amount in Local/USD/TWD
  --Trigger by PNL2_BAD_DEPT_UPLOAD.JSP
)
AUTHID DEFINER
is
   a_YEAR    PNL_MSA001_EM_DATA.YYYY%TYPE;
   a_MONTH   PNL_MSA001_EM_DATA.MONTH%TYPE;
   a_AREA1         PNL2_MAP002_EM_PNL_CLASS.AREA1%TYPE;
   a_AREA2         PNL2_MAP002_EM_PNL_CLASS.AREA2%TYPE;
   a_AREA3         PNL2_MAP002_EM_PNL_CLASS.AREA3%TYPE;
     
 BEGIN
   
   a_YEAR    := SUBSTRB(inPeriod,1,4);
   a_MONTH   := SUBSTRB(inPeriod,5,6);
      a_AREA1  := NULL;
      a_AREA2  := NULL;
      a_AREA3  := NULL;
      
      DELETE PNL2_TRX001_SUMMARY_DATA WHERE PERIOD = inPeriod AND SOURCE = 'EM';
      COMMIT;
      
      FOR REC1 in (       SELECT COMPANY_CODE, PROFIT_CENTER,ACCT_ID,SUM(AMOUNT) AMT,SUM(AMOUNT_USD) AMT_USD
            FROM PNL_MSA001_EM_DATA
           --WHERE PERIOD = inPeriod
           WHERE YYYY = a_YEAR
             AND MONTH = a_MONTH
             GROUP BY COMPANY_CODE,PROFIT_CENTER,ACCT_ID) Loop

        a_AREA1  := NULL;
        a_AREA2  := NULL;
        a_AREA3  := NULL;
        BEGIN
            SELECT AREA1,AREA2,AREA3 INTO a_AREA1,a_AREA2,a_AREA3
              FROM PNL2_MAP002_EM_PNL_CLASS
             WHERE  ACCT_ID = REC1.ACCT_ID 
               AND  R_KIND = 'PL01'
               AND  START_DATE <= SYSDATE
               AND  END_DATE >= SYSDATE;
        EXCEPTION
          WHEN OTHERS Then
             a_AREA1 := null;
             a_AREA2 := null;
             a_AREA3 := null;
        END;
        
        PNL2_PLS006_EM_S01_TRX(REC1.COMPANY_CODE,REC1.PROFIT_CENTER,inPeriod,REC1.AMT,REC1.AMT_USD,a_AREA1,a_AREA2,a_AREA3);


                       
      END LOOP;
 
   
   
   
    
END PNL2_PLS006_EM_TRX;
/

