create PROCEDURE       "ROA_PLS010_CAL_QUARTER_DATA" (
  in_YYYYQQ1  in VARCHAR2
  ,in_Kind1 in VARCHAR2
)
AUTHID DEFINER
/* ****************************************************************************************
  PROG-ID      : ROA_PLS010_CAL_QUARTER_DATA
  PROG-ACTION  :   
  Author       : Asan Chang
  Date         : 2017/08/15
  OA No.       : SAI074422
 ========================================================================================== 

 *************************************************************************************/
is
   iReccnt              integer;
   In_YYYY              DIMENSION_DATE.YYYY%TYPE;
   In_MM                DIMENSION_DATE.MM%TYPE; 
   In_PERIOD            DIMENSION_DATE.YYYYMM%TYPE;
   To_PERIOD            DIMENSION_DATE.YYYYMM%TYPE;
   From_PERIOD          DIMENSION_DATE.YYYYMM%TYPE;
   Bt_PERIOD            DIMENSION_DATE.YYYYMM%TYPE;
   In_KIND              varchar2(2); 
   USI_KIND             varchar2(2);
   PC_KIND              varchar2(2);
   This_ACC             varchar2(6);
   L_CNT                NUMBER(6);
   iTracePoint          integer ; 
   In_MM2               integer ;
   inCompany            ROA_PST004_FIXED_ASSETS.COMPANY_CODE%TYPE;
   STR01                varchar2(30);
   STR02                varchar2(30);
   STR03                varchar2(10);
   STR04                varchar2(2);
   STR06                varchar2(20); 
   STR07                varchar2(20); 
  
BEGIN
--
  In_YYYY := SUBSTR( in_YYYYQQ1, 1, 4);  
  In_MM := SUBSTR( in_YYYYQQ1, 5, 2); 
  --In_MM2 := In_MM;
  In_MM2 := 3;
  In_PERIOD := In_YYYY || In_MM;

  
  CASE In_MM
    WHEN 'Q1' THEN
      From_PERIOD :=  In_YYYY || '01';
      Bt_PERIOD   :=  In_YYYY || '02';
      To_PERIOD   :=  In_YYYY || '03';
    WHEN 'Q2' THEN
      From_PERIOD :=  In_YYYY || '04';
      Bt_PERIOD   :=  In_YYYY || '05';
      To_PERIOD   :=  In_YYYY || '06';
    WHEN 'Q3' THEN
      From_PERIOD :=  In_YYYY || '07';
      Bt_PERIOD   :=  In_YYYY || '08';
      To_PERIOD   :=  In_YYYY || '09';
    WHEN 'Q4' THEN
      From_PERIOD :=  In_YYYY || '10';
      Bt_PERIOD   :=  In_YYYY || '11';
      To_PERIOD   :=  In_YYYY || '12';
  END CASE;
  
  In_KIND := in_Kind1;

  delete ROA_PST001_MONTH_DATA WHERE PERIOD = In_PERIOD AND D_KIND = In_KIND ;
  COMMIT ;
  delete ROA_PST001_MONTH_DATA WHERE PERIOD = From_PERIOD AND D_KIND = In_KIND AND D_ACC = 'C_NIB_Q_22';
  COMMIT ;
  delete ROA_PST001_MONTH_DATA WHERE PERIOD = Bt_PERIOD AND D_KIND = In_KIND AND D_ACC = 'C_NIB_Q_22';
  COMMIT ;
  delete ROA_PST001_MONTH_DATA WHERE PERIOD = To_PERIOD AND D_KIND = In_KIND AND D_ACC = 'C_NIB_Q_22';
  COMMIT ;   
  

                   
  /*****************************************************************************************
      (1)Kind = 01-PC
  ************************************************************************************ */
  if In_KIND IN ('01') THEN 
      iTracePoint := 100 ;  
      
  --(1-18) --------  
      STR01 :=  'C_NIB_Q_22';
      for REC1 IN (
        SELECT D_KEY,  (( SUM( D_AMOUNT ) / In_MM2 ) * 3)  AMOUNT
        FROM ROA_PST001_MONTH_DATA
        WHERE PERIOD >= From_PERIOD and  PERIOD <= To_PERIOD
        AND D_KIND = In_KIND AND D_ACC = 'A02200'
      GROUP BY D_KEY
      order by D_KEY
  
      )
      LOOP
        INSERT INTO ROA_PST001_MONTH_DATA
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND, REC1.D_KEY ,STR01, REC1.AMOUNT); 
        
        
        -------------------------------------------------------------------
        --insert to month (1)  
        INSERT INTO ROA_PST001_MONTH_DATA
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( From_PERIOD, In_KIND, REC1.D_KEY ,STR01, REC1.AMOUNT); 
        
        --insert to month (2)         
        INSERT INTO ROA_PST001_MONTH_DATA
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( Bt_PERIOD, In_KIND, REC1.D_KEY ,STR01, REC1.AMOUNT);  
         
        --insert to month (3)         
        INSERT INTO ROA_PST001_MONTH_DATA
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( To_PERIOD, In_KIND, REC1.D_KEY ,STR01, REC1.AMOUNT); 
        -------------------------------------------------------------------  
                                              
      END LOOP; 
 


/*****************************************************************************************
      (3)Kind = 09-USI
  ************************************************************************************ */    
  ELSIF In_KIND IN ('09') THEN
    In_KIND := '09'; 
    STR06 :=  'USI';   
                


  --(3-16) --------  
      STR01 :=  'C_NIB_Q_22';
      STR02 :=  In_YYYY || '01';
      for REC1 IN (
        SELECT (( SUM( D_AMOUNT ) / In_MM2 ) * 3)  AMOUNT
        FROM ROA_PST001_MONTH_DATA
        WHERE PERIOD >= From_PERIOD and  PERIOD <= To_PERIOD
        AND D_KIND = In_KIND AND D_ACC = 'A02200' 
      )
      LOOP
        INSERT INTO ROA_PST001_MONTH_DATA
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND, STR06 ,STR01, REC1.AMOUNT); 
         
        ------------------------------------------------------------------- 
        --insert to month (1)  
        INSERT INTO ROA_PST001_MONTH_DATA
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( From_PERIOD, In_KIND, STR06 ,STR01, REC1.AMOUNT); 
        
        --insert to month (2)         
        INSERT INTO ROA_PST001_MONTH_DATA
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( Bt_PERIOD, In_KIND, STR06 ,STR01, REC1.AMOUNT);  
         
        --insert to month (3)         
        INSERT INTO ROA_PST001_MONTH_DATA
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( To_PERIOD, In_KIND, STR06 ,STR01, REC1.AMOUNT);           
        ------------------------------------------------------------------- 
         
                         
      END LOOP; 


      
  /*****************************************************************************************
      (2)Kind = 08-USI(no Bravo)
  ************************************************************************************ */
  ELSIF In_KIND IN ('08') THEN    
    In_KIND := '08'; 
    USI_KIND := '09';
    PC_KIND := '01';
    STR06 :=  'USI'; 
    STR07 :=  'USI(No Bravo)';
    STR03 :=  '0000000080';     
    STR04 :=  '80';
    


  --(2-16) --------  
      STR01 :=  'C_NIB_Q_22';
      for REC1 IN (  
         select b.D_AMOUNT-a.D_AMOUNT AMOUNT from       
         ( select D_AMOUNT from ROA_PST001_MONTH_DATA where period = In_PERIOD
         and D_KIND = PC_KIND and D_KEY = STR03 and D_ACC = STR01 ) a,      
         ( select D_AMOUNT from ROA_PST001_MONTH_DATA where period = In_PERIOD
         and D_KIND = USI_KIND and D_KEY = STR06 and D_ACC = STR01 ) b
  
      )
      LOOP
        INSERT INTO ROA_PST001_MONTH_DATA
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( In_PERIOD, In_KIND,STR07 ,STR01, REC1.AMOUNT);  
         
        ------------------------------------------------------------------- 
        --insert to month (1)  
        INSERT INTO ROA_PST001_MONTH_DATA
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( From_PERIOD, In_KIND, STR07 ,STR01, REC1.AMOUNT); 
        
        --insert to month (2)         
        INSERT INTO ROA_PST001_MONTH_DATA
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( Bt_PERIOD, In_KIND, STR07 ,STR01, REC1.AMOUNT);  
         
        --insert to month (3)         
        INSERT INTO ROA_PST001_MONTH_DATA
         ( PERIOD, D_KIND , D_KEY ,D_ACC, D_AMOUNT) 
        VALUES
         ( To_PERIOD, In_KIND, STR07 ,STR01, REC1.AMOUNT);           
        -------------------------------------------------------------------          
         
                        
      END LOOP; 


  
  END IF;

  

END ROA_PLS010_CAL_QUARTER_DATA;
/

