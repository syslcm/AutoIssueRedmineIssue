create view CPM_VIEW001_DETAIL as
SELECT "COMPANY_CODE", "PLANT_CODE", "PERIOD", "PART_NO", "PROFIT_CENTER",
          "CUST_GROUP", "SEARCH_TERM", "CUSTOMER_ID", "SHIP_TO_PARTY",
          "MTL_GROUP", "SHIP_TO_PARTY_GROUP", "SOLD_TO_PARTY", "GROSS_QTY",
          "NET_QTY", "GROSS_REVENUE", "NET_REVENUE", "GROSS_COGS", "NET_COGS",
          "CURRENCY_LOCAL", "EX_RATE_USD", "EX_RATE_TWD", "NET_COGS_TWD",
          "END_CUSTOMER_ID", "COST_ELEMENT", "RELATED_PARTY", "MTL_TYPE",
          "VV021", "VV022", "VV023", "VV027", "VV028", "VV035", "VV037",
          "VV038", "VV039", "VV040", "VV006", "VV007", "VV014", "VV015",
          "VV016", "VV017", "VV018", "VV019", "PROJECT_TYPE", "PROJECT_NAME",
          "GROSS_REVENUE_TWD", "GROSS_REVENUE_USD", "NET_REVENUE_TWD",
          "NET_REVENUE_USD", "VV021_TWD", "VV021_USD", "VV022_TWD",
          "VV022_USD", "VV023_TWD", "VV023_USD", "VV027_TWD", "VV027_USD",
          "VV035_TWD", "VV035_USD", "VV037_TWD", "VV037_USD", "VV038_TWD",
          "VV038_USD", "VV039_TWD", "VV039_USD", "VV040_TWD", "VV040_USD",
          "VV006_TWD", "VV006_USD", "VV007_TWD", "VV007_USD", "VV014_TWD",
          "VV014_USD", "VV015_TWD", "VV015_USD", "VV016_TWD", "VV016_USD",
          "VV017_TWD", "VV017_USD", "VV018_TWD", "VV018_USD", "VV019_TWD",
          "VV019_USD", "NET_COGS_USD", "GROSS_COGS_TWD", "GROSS_COGS_USD",
          "DATA_SOURCE", "CREATE_DATE", "DATA_SOURCE2", "COGS_DM",
          "COGS_DM_TWD", "COGS_DM_USD", "COGS_DL", "COGS_DL_TWD",
          "COGS_DL_USD", "COGS_OH", "COGS_OH_TWD", "COGS_OH_USD",
          "VV029","VV029_TWD","VV029_USD",
          "VV030","VV030_TWD","VV030_USD",
          "VV034","VV034_TWD","VV034_USD",
          (SELECT bg_id
             FROM kpi_map002_bg_map b
            WHERE a.company_code = b.company_code
              AND a.profit_center = b.profit_center
              AND b.start_date <= SYSDATE
              AND b.end_date >= SYSDATE) bg,
          (SELECT bg_desc
             FROM kpi_map002_bg_map b
            WHERE a.company_code = b.company_code
              AND a.profit_center = b.profit_center
              AND b.start_date <= SYSDATE
              AND b.end_date >= SYSDATE) bg_desc,
          (SELECT bu_id
             FROM kpi_map002_bg_map b
            WHERE a.company_code = b.company_code
              AND a.profit_center = b.profit_center
              AND b.start_date <= SYSDATE
              AND b.end_date >= SYSDATE) bu,
          (SELECT bu_desc
             FROM kpi_map002_bg_map b
            WHERE a.company_code = b.company_code
              AND a.profit_center = b.profit_center
              AND b.start_date <= SYSDATE
              AND b.end_date >= SYSDATE) bu_desc
     FROM cpm_trx001_copa a
/

