create PROCEDURE       VQA_PLSQL_LFO_SAP_DOWNLOAD (
 inCompany  in VQA_LFO_WO_QPA.COMPANY_CODE%TYPE,
  f_YYYYMMDD in VARCHAR2,
  t_YYYYMMDD in VARCHAR2
)
IS
      /*--------------------------------------------------------------*
         CREATE DATE:  2008/03/24
         PLSQL      :  VQA_PLSQL_LFO_SAP_DOWNLOAD
         Author     :  Shuya
         Purpose    :  Download by dqy (每天執行)
                       TW/SH
      *---------------------------------------------------------------*
      */


 vCompany_code    VQA_SQM_VCAR.Company_code%TYPE;
 iTracePoint      varchar2(100);
 cErrorText       varchar2(500);

BEGIN

 --抓當月份系統日期
  iTracePoint := '100';

  for REC1 in ( select * from VQA_LFO_WO_QPA_T where company_code = inCompany) loop
    if REC1.COMPANY_CODE is not null then
      iTracePoint := '110';
      vCompany_code := REC1.Company_code;
    end if;
  end loop;

 if vCOMPANY_CODE is null then
   --若沒抓到資料則寄 error mail
   iTracePoint := '120';
   cErrorText := 'No data!';
   MAIL_FILE_BIDBDBADMIN(in_to_name => 'shuya_chen@usiglobal.com', subject => '[VQA] PL/SQL VQA_PLSQL_LFO_SAP_DOWNLOAD ERROR', message => '[Table:VQA_LFO_WO_QPA_T, The tracepoint is  ' || iTracePoint || ' and ErrorText= ' || cErrorText) ;
 else

     --清除舊資料
    iTracePoint := '150';
    DELETE from VQA_LFO_WO_QPA
           where COMPANY_CODE = inCompany
             and WORK_ORDER in (Select DISTINCT WORK_ORDER from VQA_LFO_WO_QPA_T);
    DELETE from VQA_LFO_WO_QPA
           where COMPANY_CODE = inCompany
             and up_date < sysdate -90;
    Commit;

   iTracePoint := '200';
   Insert into VQA_LFO_WO_QPA
          Select * from VQA_LFO_WO_QPA_T
              where COMPANY_CODE = inCompany;
   Commit;
    --清除Temp資料
    iTracePoint := '300';
    DELETE from VQA_LFO_WO_QPA_T
          where COMPANY_CODE = inCompany;
    Commit;

    MAIL_FILE_BIDBDBADMIN(in_to_name => 'shuya_chen@usiglobal.com', subject => '[VQA] PL/SQL VQA_PLSQL_LFO_SAP_DOWNLOAD Success', message => '[Table:VQA_LFO_WO_QPA_T]') ;

 end if;


EXCEPTION
   When OTHERS Then
    --有錯誤產生則寄mail
    cErrorText := SQLERRM();
    MAIL_FILE_BIDBDBADMIN(in_to_name => 'shuya_chen@usiglobal.com', subject => '[VQA] PL/SQL VQA_PLSQL_LFO_SAP_DOWNLOAD ERROR', message => '[Table:VQA_LFO_WO_QPA_T], The tracepoint is  ' || iTracePoint || ' and ErrorText= ' || cErrorText) ;

END VQA_PLSQL_LFO_SAP_DOWNLOAD;
/

