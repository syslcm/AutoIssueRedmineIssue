create PROCEDURE         "PLSQL_PLD_KPI_LOA_BY_Q_CREATE" (
  inCompany  in VARCHAR2,
  f_YYYYMMDD in VARCHAR2,
  t_YYYYMMDD in VARCHAR2
)
/***********************************************************************
  PROG-ID      : PLSQL_PLD_KPI_LOA_BY_Q_CREATE
  PROG-ACTION  : Get LOA Data From POWEB.RFQ_LOA_PM@RFQPRD.WORLD
                 INSERT INTO PLD_KPI_LOA_BY_QUARTER
  Author       : KATHY
  Date         : 2008/04/14
  UPDATE Date  : 2008/XX/XX
-------------------------------------------------------------------------------------------
--Run PLSQL WITH table:KPI_SAP017_ZB027_DATA_T (SEQ-04)
-------------------------------------------------------------------------------------------
*/
--***********************************************************************
AUTHID DEFINER
is

  iFind_Flag   integer ;          ----1=>find , 0=>dosen't find
  cYear        char(4) ;
  cQuarter     char(2) ;
  cMM          char(2) ;

---*********************************************************************************
begin
-----------------------------------------------------------------------------------------
-- (1)判斷系統日為何年，何季.
-----------------------------------------------------------------------------------------
      cYear := SUBSTRB(to_char(SYSDATE,'YYYYMMDD'),1,4);
      cMM   := SUBSTRB(to_char(SYSDATE,'YYYYMMDD'),5,2);
      IF ( cMM = '01' OR cMM = '02' ) THEN
           cQuarter := 'Q1';
      END IF;
      IF ( cMM = '04' OR cMM = '05' ) THEN
           cQuarter := 'Q2';
      END IF;
      IF ( cMM = '07' OR cMM = '08' ) THEN
           cQuarter := 'Q3';
      END IF;
      IF ( cMM = '10' OR cMM = '11' ) THEN
           cQuarter := 'Q4';
      END IF;

-----------------------------------------------------------------------------------------
-- (2)當月份不為 03,06,09,12 時, 才轉資料, 先刪除舊資料.
-----------------------------------------------------------------------------------------
      IF ( cMM != '03' AND cMM != '06' AND
           cMM != '09' AND cMM != '12' ) THEN
         delete from PLD_KPI_LOA_BY_QUARTER
          WHERE YYYY = cYear
            AND QUARTER = cQuarter ;
         commit;

-----------------------------------------------------------------------------------------
-- (3)再新增 LOA 資料.
-----------------------------------------------------------------------------------------
         Insert INTO PLD_KPI_LOA_BY_QUARTER (
            PART_NO, YYYY, QUARTER
         )
         SELECT PART_NO, cYear as YYYY, cQuarter as QUARTER
           FROM RFQ_LOA_PM@RFQPRD.WORLD;
         Commit;
      END IF;

end PLSQL_PLD_KPI_LOA_BY_Q_CREATE;
/

