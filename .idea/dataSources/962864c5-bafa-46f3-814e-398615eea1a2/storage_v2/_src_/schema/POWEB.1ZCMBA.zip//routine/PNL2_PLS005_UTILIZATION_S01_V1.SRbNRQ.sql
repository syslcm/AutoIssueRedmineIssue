create PROCEDURE       PNL2_PLS005_UTILIZATION_S01_V1 (
  inCOMPANY       in VARCHAR2,
  inPeriod        in VARCHAR2,
  inPROFIT_CENTER in VARCHAR2,
  --inAMT           in Number,
  inTOTAL_HRS     in NUMBER,
  inGLAccount     in VARCHAR
  -----------------------------------------
  --Keep 2008/10/16 Version
  -----------------------------------------
)
AUTHID DEFINER
is

     
     a_Rate          number(15,5);
     a_Miss_Rate     number(15,5); --找不到end customer時用revenue來分
     a_COUNTER       integer;  --record count
     a_ENDCUSTOMER   KPI_SAP001_COPA_TRX.END_CUSTOMER_ID%TYPE;
     a_NET_REVENUE   KPI_SAP001_COPA_TRX.NET_REVENUE%TYPE;
     a_REVENUE_LOCAL KPI_SAP001_COPA_TRX.NET_REVENUE%TYPE;
     a_REVENUE_TWD   KPI_SAP001_COPA_TRX.NET_REVENUE%TYPE;
     a_REVENUE_USD   KPI_SAP001_COPA_TRX.NET_REVENUE%TYPE;
     a_COGS_DM_LOCAL KPI_SAP001_COPA_TRX.NET_REVENUE%TYPE;
     a_COGS_DM_TWD   KPI_SAP001_COPA_TRX.NET_REVENUE%TYPE;
     a_COGS_DM_USD   KPI_SAP001_COPA_TRX.NET_REVENUE%TYPE;
     a_COGS_DL_LOCAL KPI_SAP001_COPA_TRX.NET_REVENUE%TYPE;
     a_COGS_DL_TWD   KPI_SAP001_COPA_TRX.NET_REVENUE%TYPE;
     a_COGS_DL_USD   KPI_SAP001_COPA_TRX.NET_REVENUE%TYPE;
     a_COGS_OH_LOCAL KPI_SAP001_COPA_TRX.NET_REVENUE%TYPE;
     a_COGS_OH_TWD   KPI_SAP001_COPA_TRX.NET_REVENUE%TYPE;
     a_COGS_OH_USD   KPI_SAP001_COPA_TRX.NET_REVENUE%TYPE;
     a_COGS_LOCAL    KPI_SAP001_COPA_TRX.NET_REVENUE%TYPE;
     a_COGS_TWD      KPI_SAP001_COPA_TRX.NET_REVENUE%TYPE;
     a_COGS_USD      KPI_SAP001_COPA_TRX.NET_REVENUE%TYPE;
     o_REVENUE       KPI_SAP001_COPA_TRX.NET_REVENUE%TYPE;
     o_COGS          KPI_SAP001_COPA_TRX.NET_REVENUE%TYPE;
     
 BEGIN
   

      a_RATE  := 0;
      FOR REC1 in (SELECT PART_NO,SUM(TOTAL_HRS) TOTAL_HRS FROM KPI_SAP012_EXPENSE_HISTORY
                      WHERE COMPANY_CODE = inCOMPANY 
                        AND PROFIT_CENTER = inPROFIT_CENTER
                        AND PERIOD = inPeriod
                        AND TRANSACTION = 'RKL'
                        GROUP BY PART_NO) Loop
        --有出現TOTAL_HRS = 0的料號,則此料號不入
        IF REC1.TOTAL_HRS <> 0 THEN                
          a_Rate := ABS(REC1.TOTAL_HRS / inTOTAL_HRS);
          a_REVENUE_LOCAL := 0;
          a_REVENUE_TWD   := 0;
          a_REVENUE_USD   := 0;
          a_COGS_DM_LOCAL := 0;
          a_COGS_DM_TWD   := 0;
          a_COGS_DM_USD   := 0;
          a_COGS_DL_LOCAL := 0;
          a_COGS_DL_TWD   := 0;
          a_COGS_DL_USD   := 0;
          a_COGS_OH_LOCAL := 0;
          a_COGS_OH_TWD   := 0;
          a_COGS_OH_USD   := 0;
          a_COGS_LOCAL    := 0;
          a_COGS_TWD      := 0;
          a_COGS_USD      := 0;
          o_REVENUE       := 0;
          o_COGS          := 0;
          BEGIN
              SELECT SUM(NET_REVENUE), SUM(NET_REVENUE_USD), SUM(NET_REVENUE_TWD) ,
                     SUM(NET_COGS)   , SUM(NET_COGS_USD)   , SUM(NET_COGS_TWD)    ,
                              SUM(COGS_MB) ,SUM(COGS_MB_USD) ,SUM(COGS_MB_TWD) ,
                              SUM(COGS_LB) ,SUM(COGS_LB_USD) ,SUM(COGS_LB_TWD) ,
                              SUM(COGS_OB) ,SUM(COGS_OB_USD) ,SUM(COGS_OB_TWD) ,
                              SUM(NET_REVENUE),SUM(NET_COGS)
                INTO a_REVENUE_LOCAL,a_REVENUE_USD,a_REVENUE_TWD,
                     a_COGS_LOCAL   ,a_COGS_USD   ,a_COGS_TWD   ,
                     a_COGS_DM_LOCAL,a_COGS_DM_USD,a_COGS_DM_TWD,
                     a_COGS_DL_LOCAL,a_COGS_DL_USD,a_COGS_DL_TWD,
                     a_COGS_OH_LOCAL,a_COGS_OH_USD,a_COGS_OH_TWD,
                     o_REVENUE      ,o_COGS
                FROM KPI_SAP001_COPA_TRX
               WHERE  PERIOD = inPeriod 
                 AND  COMPANY_CODE = inCOMPANY
                 AND  PROFIT_CENTER = inPROFIT_CENTER
                 AND    ( NET_REVENUE <> 0 OR NET_COGS <>  0)
                 AND    RELATED_PARTY <> 'Y'
                 --AND    END_CUSTOMER_ID IS NULL
                 AND COST_ELEMENT = inGLAccount --in ('0000510201','0000510301','0000510401','0000510501')
            GROUP BY COMPANY_CODE,PROFIT_CENTER,PERIOD
              HAVING ( SUM(NET_REVENUE) <> 0 OR SUM(NET_COGS)  <> 0 );
          EXCEPTION
            WHEN OTHERS Then
             a_REVENUE_LOCAL := 0;
             a_REVENUE_TWD   := 0;
             a_REVENUE_USD   := 0;
             a_COGS_DM_LOCAL := 0;
             a_COGS_DM_TWD   := 0;
             a_COGS_DM_USD   := 0;
             a_COGS_DL_LOCAL := 0;
             a_COGS_DL_TWD   := 0;
             a_COGS_DL_USD   := 0;
             a_COGS_OH_LOCAL := 0;
             a_COGS_OH_TWD   := 0;
             a_COGS_OH_USD   := 0;
             a_COGS_LOCAL    := 0;
             a_COGS_TWD      := 0;
             a_COGS_USD      := 0;
             o_REVENUE       := 0;
             o_COGS          := 0;
          END;
          a_COUNTER := 0;
          a_ENDCUSTOMER := NULL;
          FOR REC99 IN (SELECT END_CUSTOMER_ID 
             FROM KPI_MAP005_END_CUSTOMER_COM
            WHERE PROFIT_CENTER = inPROFIT_CENTER
              AND PRODUCT_NO =  REC1.PART_NO
              AND COMPANY_CODE = inCOMPANY
           GROUP BY END_CUSTOMER_ID) LOOP
             a_COUNTER := a_COUNTER + 1;
             a_ENDCUSTOMER := REC99.END_CUSTOMER_ID;
          END LOOP;
        
          IF a_COUNTER = 1 AND  a_ENDCUSTOMER <> NULL THEN  
        
            INSERT INTO PNL2_TRX003_UN_UTILIZATION (
               COMPANY_CODE         ,PERIOD       ,PROFIT_CENTER      ,
               PART_NO              ,TOTAL_HRS    ,PN_HRS             ,         
               NET_REVENUE          ,NET_REVENUE_TWD ,NET_REVENUE_USD ,
               NET_COGS             ,NET_COGS_TWD    ,NET_COGS_USD    ,
               COGS_MB              ,COGS_MB_TWD     ,COGS_MB_USD     ,
               COGS_LB              ,COGS_LB_TWD     ,COGS_LB_USD     ,
               COGS_OB              ,COGS_OB_TWD     ,COGS_OB_USD     ,
               O_NET_REVENUE        ,O_NET_COGS      ,
               RATE                 ,COST_ELEMENT    ,END_CUSTOMER_ID ,
               CREATE_DATE     
            ) VALUES(
               inCOMPANY            ,inPeriod     ,inPROFIT_CENTER    ,
               REC1.PART_NO         ,inTOTAL_HRS  ,REC1.TOTAL_HRS     ,
               round(a_REVENUE_LOCAL * a_RATE , 5),
               round(a_REVENUE_TWD * a_RATE , 5)  ,
               round(a_REVENUE_USD * a_RATE , 5)  , 
               round(a_COGS_LOCAL * a_RATE , 5)   ,
               round(a_COGS_TWD * a_RATE , 5)     ,
               round(a_COGS_USD * a_RATE , 5)     ,               
               round(a_COGS_DM_LOCAL * a_RATE , 5),
               round(a_COGS_DM_TWD * a_RATE , 5)  ,
               round(a_COGS_DM_USD * a_RATE , 5)  ,                
               round(a_COGS_DL_LOCAL * a_RATE , 5),
               round(a_COGS_DL_TWD * a_RATE , 5)  ,
               round(a_COGS_DL_USD * a_RATE , 5)  , 
               round(a_COGS_OH_LOCAL * a_RATE , 5),
               round(a_COGS_OH_TWD * a_RATE , 5)  ,
               round(a_COGS_OH_USD * a_RATE , 5)  , 
               o_REVENUE,
               o_COGS,
               a_RATE,
               inGLAccount, 
               a_ENDCUSTOMER, 
               SYSDATE
            );
            commit;
          ELSE  --找不到end_customer或有多個end_customer時,依end customer 營收比率來分
            a_ENDCUSTOMER := NULL;
            a_NET_REVENUE := 0;
            BEGIN 
              SELECT SUM(NET_REVENUE_TWD) INTO a_NET_REVENUE
                          FROM  KPI_SAP001_COPA_TRX
                         WHERE PERIOD = inPeriod 
                           AND COMPANY_CODE = inCOMPANY
                           AND PROFIT_CENTER = inPROFIT_CENTER
                           AND RELATED_PARTY <> 'Y'
                           AND NET_REVENUE <> 0;
            IF SQL%NOTFOUND THEN
              a_NET_REVENUE := 0;
            END IF;
            EXCEPTION
               WHEN OTHERS THEN
              a_NET_REVENUE := 0;
            END;
          
            IF a_NET_REVENUE = 0 THEN   --不會發生 NET_REVENUE =0的狀況,除非這個PROFIT_CENTER被拆成其他或合併了,但只要進得來這裡表示有費用發生
               INSERT INTO PNL2_TRX003_UN_UTILIZATION (
                  COMPANY_CODE         ,PERIOD       ,PROFIT_CENTER      ,
                  PART_NO              ,TOTAL_HRS    ,PN_HRS             ,         
                  NET_REVENUE          ,NET_REVENUE_TWD ,NET_REVENUE_USD ,
                  NET_COGS             ,NET_COGS_TWD    ,NET_COGS_USD    ,
                  COGS_MB              ,COGS_MB_TWD     ,COGS_MB_USD     ,
                  COGS_LB              ,COGS_LB_TWD     ,COGS_LB_USD     ,
                  COGS_OB              ,COGS_OB_TWD     ,COGS_OB_USD     ,
                  O_NET_REVENUE        ,O_NET_COGS      ,
                  RATE                 ,COST_ELEMENT    ,--END_CUSTOMER_ID ,
                  CREATE_DATE     
               ) VALUES(
                  inCOMPANY            ,inPeriod     ,inPROFIT_CENTER    ,
                  REC1.PART_NO         ,inTOTAL_HRS  ,REC1.TOTAL_HRS     ,
                  round(a_REVENUE_LOCAL * a_RATE , 5),
                  round(a_REVENUE_TWD * a_RATE , 5)  ,
                  round(a_REVENUE_USD * a_RATE , 5)  , 
                  round(a_COGS_LOCAL * a_RATE , 5)   ,
                  round(a_COGS_TWD * a_RATE , 5)     ,
                  round(a_COGS_USD * a_RATE , 5)     ,               
                  round(a_COGS_DM_LOCAL * a_RATE , 5),
                  round(a_COGS_DM_TWD * a_RATE , 5)  ,
                  round(a_COGS_DM_USD * a_RATE , 5)  ,                
                  round(a_COGS_DL_LOCAL * a_RATE , 5),
                  round(a_COGS_DL_TWD * a_RATE , 5)  ,
                  round(a_COGS_DL_USD * a_RATE , 5)  , 
                  round(a_COGS_OH_LOCAL * a_RATE , 5),
                  round(a_COGS_OH_TWD * a_RATE , 5)  ,
                  round(a_COGS_OH_USD * a_RATE , 5)  , 
                  o_REVENUE,
                  o_COGS,
                  a_RATE,
                  inGLAccount, 
                  --a_ENDCUSTOMER, 
                  SYSDATE
               );
               commit;
            ELSE --依照營收來分
               a_Miss_RATE  := 0;
               FOR REC97 in (SELECT END_CUSTOMER_ID,SUM(NET_REVENUE_TWD) AMT_TWD FROM KPI_SAP001_COPA_TRX 
                        WHERE COMPANY_CODE = inCOMPANY 
                          AND PROFIT_CENTER = inPROFIT_CENTER
                          AND PERIOD = inPeriod
                          AND RELATED_PARTY <> 'Y'
                          AND NET_REVENUE <> 0
                          GROUP BY END_CUSTOMER_ID) Loop
                   a_Miss_Rate := REC97.AMT_TWD / a_NET_REVENUE;
                   INSERT INTO PNL2_TRX003_UN_UTILIZATION (
                        COMPANY_CODE         ,PERIOD       ,PROFIT_CENTER      ,
                        PART_NO              ,TOTAL_HRS    ,PN_HRS             ,         
                        NET_REVENUE          ,NET_REVENUE_TWD ,NET_REVENUE_USD ,
                        NET_COGS             ,NET_COGS_TWD    ,NET_COGS_USD    ,
                        COGS_MB              ,COGS_MB_TWD     ,COGS_MB_USD     ,
                        COGS_LB              ,COGS_LB_TWD     ,COGS_LB_USD     ,
                        COGS_OB              ,COGS_OB_TWD     ,COGS_OB_USD     ,
                        O_NET_REVENUE        ,O_NET_COGS      ,
                        RATE                 ,COST_ELEMENT    ,END_CUSTOMER_ID ,
                        CREATE_DATE     
                   ) VALUES(
                        inCOMPANY            ,inPeriod     ,inPROFIT_CENTER    ,
                        REC1.PART_NO         ,inTOTAL_HRS  ,REC1.TOTAL_HRS     ,
                        round(a_REVENUE_LOCAL * a_RATE * a_Miss_RATE , 5),
                        round(a_REVENUE_TWD * a_RATE * a_Miss_RATE, 5)  ,
                        round(a_REVENUE_USD * a_RATE * a_Miss_RATE, 5)  , 
                        round(a_COGS_LOCAL * a_RATE * a_Miss_RATE, 5)   ,
                        round(a_COGS_TWD * a_RATE * a_Miss_RATE, 5)     ,
                        round(a_COGS_USD * a_RATE * a_Miss_RATE, 5)     ,               
                        round(a_COGS_DM_LOCAL * a_RATE * a_Miss_RATE, 5),
                        round(a_COGS_DM_TWD * a_RATE * a_Miss_RATE, 5)  ,
                        round(a_COGS_DM_USD * a_RATE * a_Miss_RATE, 5)  ,                
                        round(a_COGS_DL_LOCAL * a_RATE * a_Miss_RATE, 5),
                        round(a_COGS_DL_TWD * a_RATE * a_Miss_RATE, 5)  ,
                        round(a_COGS_DL_USD * a_RATE * a_Miss_RATE, 5)  , 
                        round(a_COGS_OH_LOCAL * a_RATE * a_Miss_RATE, 5),
                        round(a_COGS_OH_TWD * a_RATE * a_Miss_RATE, 5)  ,
                        round(a_COGS_OH_USD * a_RATE * a_Miss_RATE, 5)  , 
                        o_REVENUE,
                        o_COGS,
                        a_RATE,
                        inGLAccount, 
                        REC97.END_CUSTOMER_ID, 
                        SYSDATE
                   );
                   commit;
               END LOOP;
            END IF;
          END IF;

        END IF;              
      END LOOP;
 
   
   
   
    
END PNL2_PLS005_UTILIZATION_S01_V1;
/

