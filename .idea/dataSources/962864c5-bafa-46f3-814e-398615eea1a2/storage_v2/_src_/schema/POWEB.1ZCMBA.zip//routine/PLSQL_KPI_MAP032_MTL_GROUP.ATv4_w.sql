create PROCEDURE         "PLSQL_KPI_MAP032_MTL_GROUP" (
  inCompany  in VARCHAR2,
  f_YYYYMMDD in VARCHAR2,
  t_YYYYMMDD in VARCHAR2
)
/***********************************************************************
  PROG-ID      : PLSQL_KPI_MAP032_MTL_GROUP
  PROG-ACTION  : Get MTL_GROUP From EGI0011_MTL_GROUP
                 INSERT INTO KPI_MAP032_MTL_GROUP
  Author       : KATHY
  Date         : 2012/06/05
  UPDATE Date  : 20xx/XX/XX
-------------------------------------------------------------------------------------------
--Run PLSQL WITH table:KPI_SAP017_ZB027_DATA_T (SEQ-02) company_code='1700'
-------------------------------------------------------------------------------------------
*/
--***********************************************************************
AUTHID DEFINER
is

BEGIN
  DELETE FROM KPI_MAP032_MTL_GROUP;

   Insert into KPI_MAP032_MTL_GROUP (
          MFG_SITE, MATERIAL_GROUP,
          MTL_GROUP_DESC, EXTRICITY_DATE )
   Select trim(MFG_SITE), trim(MATERIAL_GROUP),
          trim(MTL_GROUP_DESC), trim(EXTRICITY_DATE)
     from EGI0011_MTL_GROUP
     order by MFG_SITE, MATERIAL_GROUP;
   Commit;

END PLSQL_KPI_MAP032_MTL_GROUP;
/

