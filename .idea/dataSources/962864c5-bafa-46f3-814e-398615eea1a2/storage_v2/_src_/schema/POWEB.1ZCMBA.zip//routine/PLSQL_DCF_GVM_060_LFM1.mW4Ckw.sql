create PROCEDURE PLSQL_DCF_GVM_060_LFM1 (
  inCOMPANY_CODE IN GVM_060_SAP_DATA_LFM1.COMPANY_CODE%TYPE
)
AUTHID DEFINER
is
	/*
	由 DCF_ETL_SAP.exe 執行
	update GVM032_GLOBAL_VENDOR_ITEM from SAP-LFM1
	( PAYMENT_TERM, INCOTERM, INCOTERM_2 )
	*/
  iTracePoint                varchar2(100);
  cErrorText                 varchar2(500);

BEGIN

  iTracePoint := '1';
  FOR REC1 in (
    select a.* from GVM_060_SAP_DATA_LFM1 a, GVM032_GLOBAL_VENDOR_ITEM b
     where a.COMPANY_CODE = inCOMPANY_CODE
       and a.COMPANY_CODE = b.COMPANY_CODE and a.SAP_VENDOR_CODE = b.SAP_VENDOR_CODE
       and ( nvl(a.PAYMENT_TERM,'null') <> nvl(b.PAYMENT_TERM,'null')
          or nvl(a.INCOTERM,'null') <> nvl(b.INCOTERM,'null')
          or nvl(a.INCOTERM_2,'null') <> nvl(b.INCOTERM_2,'null')
          or nvl(a.VAT_REG_NO,'null') <> nvl(b.VAT_REG_NO,'null')
          )
  ) LOOP
     iTracePoint := '1-' || REC1.SAP_VENDOR_CODE;
     Update GVM032_GLOBAL_VENDOR_ITEM
        Set PAYMENT_TERM = REC1.PAYMENT_TERM,
            INCOTERM = REC1.INCOTERM,
            INCOTERM_2 = REC1.INCOTERM_2,
            VAT_REG_NO = REC1.VAT_REG_NO
      Where COMPANY_CODE = REC1.COMPANY_CODE and SAP_VENDOR_CODE = REC1.SAP_VENDOR_CODE;
     Commit;
  END LOOP;

  iTracePoint := '200';

EXCEPTION
   When OTHERS Then
    --有錯誤產生則寄mail
    cErrorText := SQLERRM();
    MAIL_FILE_BIDBDBADMIN(in_to_name => 'lily_sys@ms.usi.com.tw', subject => '[DCF] PL/SQL PLSQL_DCF_GVM_060_LFM1 ERROR', message => '[PLSQL_DCF_GVM_060_LFM1], The tracepoint is  ' || iTracePoint || ' and ErrorText= ' || cErrorText) ;
END PLSQL_DCF_GVM_060_LFM1;
/

