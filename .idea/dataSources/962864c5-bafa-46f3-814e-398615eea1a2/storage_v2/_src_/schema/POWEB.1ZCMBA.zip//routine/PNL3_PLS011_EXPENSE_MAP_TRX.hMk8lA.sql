create PROCEDURE pnl3_pls011_expense_map_trx (  --和pnl3_pls007_expense_map_trx 只差在insert table不同
   --inCompany  in VARCHAR2,
   inperiod   IN   VARCHAR2
)
AUTHID DEFINER
IS
   --2008/11/14  Revenue 只能以profit center觀點來看,不要加入company_code,像22 在CA只有成本,沒有營收,所以就會漏掉
   --            原本為參考先前邏輯,用profit_center +site
   --如果COMAPNY_CODE是9開頭的,則歸給投資公司這個客戶
   --如果PROFIT_CENTER 為 9 或 G 開頭, 則用全公司的CUSTOMER 營收來分攤
   --以上先執行第一個邏輯再執行第二個再第三個
   --2008/12/18 採用BUGET RATIO,但針對PROFIT CENTER 9或g開頭的仍採用GLOBAL CUSTOMER Revenue
     --處理費用(Expcense-從Earning Model來),2008/12/19的邏輯是佣金和材料費另外處理,由USER直接上傳,原因是USER 條件太多
   --其他的費用改用人數比率來計算
   --2008/12/31 修正材料費和佣金的比率不從revenue ratio而改從head count ratio,當初有講說從head count 來,但沒有改到,真奇怪
   -- 但要注意如果一個profit center只有一個end customer,而佣金和材料費也是,這樣要全部歸給這個end customer
   --2009/1/8 運費也參照材料費,佣金邏輯,上傳格式一致
   --2009/1/12 2009年後就沒有PROFIT CENTER9X的了,會計流程將不會走這條路,因此在pnl3_pls007_expense_map_trx裡的9x和34和G都會消失,但2008年的則按
   --stanley的邏輯來區分1.投資公司的部份，不分攤費用
   --2.其他profit center 9開頭的，先按profit center的revenue分到profit center，然後再按照該profit center 的headcount分掉
   --3. profit center28, 33, 32直接按revenue分掉
   --2009/1/13 Profit center G的會net掉,但有時user會出錯,所以加入只要是G的就排除,避免USER出錯而造成我們DEBUG的要死
   --2009/1/15 加入呆帳和after service,下午4:00和USER開會,針對上傳的部份,如果超過原EM的金額,則要回沖差異金額給其他END CUSTOMER,PNL報表的金額一定要和EM平
   --2009/2/2 將PNL3_PLS010_EXPENSE_2008_TRX的邏輯搬過來,原pnl3_pls007_expense_map_trx的邏輯放在pnl3_pls007_expense_map_trx_v8
   --2009/2/9 比率原本都註解成'--隨便抓一筆來用,反正匯率都一樣' 固定抓area1='4',area2='1',area3='1',但因要區分RD和非RD的比率,所以要抓自己的AREA值才行
   --2009/2/17 呆帳以上傳的為主,不和EM判斷差異(原本一開始的定義,後來因為先寫其他佣金.運費的邏輯所以也誤把呆帳的邏輯也統一了,但照理說呆帳的金額要和EM一致才行
   --可在SAP用FS10N來查看
   --2009/2/18 profit center9開頭的在2009年理應和G的一樣要分乾淨,因此不用再用其他profit center去分攤去費用
   --2009/2/25 修改,如果是屬於USER上傳但某些PROFIT CENTER沒有上傳時沿用原本邏輯,避免company code的金額跑掉了
   --2009/3/10 PROFIT CENTER 34有呆帳,所以邏輯要變動,不然會double算
   --2009/3/11 決定如果上傳費用大於或小於EM,但又沒有客戶去分攤這些金額時,則客戶用空白表示
   --2010/6/7 上傳的SALES BG ALLOCATE和 CORPORATE ALLOCATE並沒有和  PNL3_PLS007_EXPENSE_MAP_TRX
   --同步
   --2014/12/8 因為 Adm exp 和 RD exp. 沒有寫入 pnl3_trx005_collect_detail_pn ,造成金額不合 ,修改須要寫入
   --Adm exp.AREA1= '4',AREA2= '2',AREA3 IN ('1','2','3','4') &
   --RD exp.AREA1= '4',AREA2= '3',AREA3 IN ('1','2','3','4') Profit Center 90 & 99
   CURSOR c_ww_ratio
   IS
      SELECT   end_customer_id, SUM (amt_twd) amt_twd
          FROM pnl3_trx001_copa
         WHERE period = inperiod
           AND area1 = '1'
           AND area2 = '1'
           AND area3 = '0'
           AND amt_twd <> 0
           AND end_customer_id NOT IN (SELECT end_customer_id
                                         FROM pnl2_upl005_commission
                                        WHERE period = inperiod)
      GROUP BY end_customer_id
      ORDER BY amt_twd DESC;

   CURSOR c_raw_ratio
   IS
      SELECT   end_customer_id, SUM (amt_twd) amt_twd
          FROM pnl3_trx001_copa
         WHERE period = inperiod
           AND area1 = '1'
           AND area2 = '1'
           AND area3 = '0'
           AND amt_twd <> 0
           AND end_customer_id NOT IN (SELECT end_customer_id
                                         FROM pnl2_upl004_rawexpense
                                        WHERE period = inperiod)
      GROUP BY end_customer_id
      ORDER BY amt_twd DESC;

   --抓profit center的Revenue(包含UPLOAD 的)
   CURSOR c_pnl2_revenue_p
   IS
      SELECT   profit_center, SUM (amt_twd) amt_twd
          FROM pnl3_trx001_copa
         WHERE r_kind = 'PL01'
           AND area1 = '1'
           AND area2 = '1'
           AND area3 = '0'
           AND period = inperiod
           AND profit_center NOT IN ('0000000090', '0000000099')
      GROUP BY profit_center;

   a_year      pnl_msa001_em_data.yyyy%TYPE;
   a_month     pnl_msa001_em_data.MONTH%TYPE;
   a_ousd      pnl2_upl005_commission.amount_usd%TYPE;
   a_otwd      pnl2_upl005_commission.amount_twd%TYPE;
   a_usd       pnl2_upl005_commission.amount_usd%TYPE;
   a_twd       pnl2_upl005_commission.amount_twd%TYPE;
   t_usd       pnl2_upl005_commission.amount_usd%TYPE;
   t_twd       pnl2_upl005_commission.amount_twd%TYPE;
   n_usd       pnl2_upl005_commission.amount_usd%TYPE;
   n_twd       pnl2_upl005_commission.amount_twd%TYPE;
   a_amount    pnl3_trx001_copa.amt_twd%TYPE;
   l_amount    pnl3_trx001_copa.amt_twd%TYPE;
   t_amount    pnl3_trx001_copa.amt_twd%TYPE;
   a_counter   INTEGER;
   b_counter   INTEGER;
   a_rate      NUMBER (20, 10);
BEGIN
   a_year := SUBSTRB (inperiod, 1, 4);
   a_month := SUBSTRB (inperiod, 5, 6);

   DELETE FROM pnl3_trx005_collect_detail_pn
         WHERE period = inperiod AND SOURCE = 'EXPENSE';

   COMMIT;
   t_amount := 0;

   BEGIN
      SELECT SUM (amt_twd)
        INTO t_amount
        FROM pnl3_trx001_copa
       WHERE r_kind = 'PL01'
         AND area1 = '1'
         AND area2 = '1'
         AND area3 = '0'
         AND profit_center NOT IN ('0000000090', '0000000099')
         AND period = inperiod;
   EXCEPTION
      WHEN OTHERS
      THEN
         t_amount := 0;
   END;

   --呆帳費用可以透過mapping table 'PNL2_MAP002_EM_PNL_CLASS'將其END DATE調整就不會進來改由user上傳(寫在最後面)來處理
   --原本的佣金和材料費用是含在sales和rd的某一個大項裡,所以在用headcount比率分攤前就要扣除這些金額和客戶後剩下的
   --金額再用headcount比率(不含上傳的客戶)來分攤掉
   --佣金,是放在SALES裡的Attribution directly,材料費用則是放在RD的Attribution directly,
   FOR rec1 IN (SELECT profit_center, company_code, amount, amount_usd,
                       r_kind, area1, area2, area3
                  FROM pnl_msa001_em_data a, pnl2_map002_em_pnl_class b
                 WHERE yyyy = a_year
                   AND MONTH = a_month
                   AND type_2 = 'Actual'
                   AND a.acct_id = b.acct_id
                   AND r_kind = 'PL01'
                 -- AND profit_center = '0000000012'
                   --AND area1 = '4'
                  -- AND area2 = '1'
                   --AND area3 = '1'
                   --and area3 = '6'
                   AND SYSDATE BETWEEN start_date AND end_date)
   LOOP
      IF rec1.profit_center = '0000000034'
      THEN
         IF rec1.r_kind = 'PL01'
            AND rec1.area1 = '4'
            AND rec1.area2 = '1'
            AND rec1.area3 = '3'
         THEN
            a_twd := 0;
         ELSE
             INSERT INTO pnl3_trx005_collect_detail_pn
                     (company_code, period, profit_center,
                      end_customer_id, amt_local,
                      amt_usd,
                      amt_twd, SOURCE, r_kind,
                      area1, area2, area3, create_date
                     )
              VALUES (rec1.company_code, inperiod, rec1.profit_center,
                      'UABIT''S CUST', ROUND (rec1.amount * 1000, 5),
                      ROUND (rec1.amount_usd * 1000, 5),
                      ROUND (rec1.amount * 1000, 5), 'EXPENSE', rec1.r_kind,
                      rec1.area1, rec1.area2, rec1.area3, SYSDATE
                     );

             COMMIT;
         END IF;
      ELSIF rec1.profit_center = '0000000381'
      THEN
         a_counter := 0;

         FOR rec3 IN (SELECT end_customer_id, rate
                        FROM pnl3_map001_customer_rate
                       WHERE r_kind = 'PL01'
                         --隨便抓一筆來用,反正匯率都一樣
                         AND area1 = rec1.area1
                         AND area2 = rec1.area2
                         AND area3 = rec1.area3
                         --AND COMPANY_CODE = REC1.COMPANY_CODE
                         AND profit_center = rec1.profit_center
                         AND period = inperiod)
         LOOP
            a_counter := 1;

            INSERT INTO pnl3_trx005_collect_detail_pn
                        (company_code, period, profit_center,
                         end_customer_id,
                         amt_local,
                         amt_usd,
                         amt_twd,
                         SOURCE, r_kind, area1, area2,
                         area3, create_date
                        )
                 VALUES (rec1.company_code, inperiod, rec1.profit_center,
                         rec3.end_customer_id,
                         ROUND (rec1.amount * 1000 * rec3.rate, 5),
                         ROUND (rec1.amount_usd * 1000 * rec3.rate, 5),
                         ROUND (rec1.amount * 1000 * rec3.rate, 5),
                         'EXPENSE', rec1.r_kind, rec1.area1, rec1.area2,
                         rec1.area3, SYSDATE
                        );

            COMMIT;
         END LOOP;

         IF a_counter = 0
         THEN
            FOR rec3 IN (SELECT end_customer_id, rate
                           FROM pnl3_map001_global_cust_rate
                          WHERE r_kind = 'PL01'
                            --隨便抓一筆來用,反正匯率都一樣
                            AND area1 = rec1.area1
                            AND area2 = rec1.area2
                            AND area3 = rec1.area3
                            --AND COMPANY_CODE = REC1.COMPANY_CODE
                            --AND PROFIT_CENTER = REC1.PROFIT_CENTER
                            AND period = inperiod)
            LOOP
               INSERT INTO pnl3_trx005_collect_detail_pn
                           (company_code, period, profit_center,
                            end_customer_id,
                            amt_local,
                            amt_usd,
                            amt_twd,
                            SOURCE, r_kind, area1, area2,
                            area3, create_date
                           )
                    VALUES (rec1.company_code, inperiod, rec1.profit_center,
                            rec3.end_customer_id,
                            ROUND (rec1.amount * 1000 * rec3.rate, 5),
                            ROUND (rec1.amount_usd * 1000 * rec3.rate, 5),
                            ROUND (rec1.amount * 1000 * rec3.rate, 5),
                            'EXPENSE', rec1.r_kind, rec1.area1, rec1.area2,
                            rec1.area3, SYSDATE
                           );

               COMMIT;
            END LOOP;
         END IF;
      ELSIF SUBSTR (rec1.profit_center, 1, 1) = 'G'
      THEN
         a_counter := 0;
      ELSIF SUBSTR (rec1.profit_center, 1, 9) = '000000009'
      THEN
         a_counter := 0;
		 --Add kangi 20141208
		 IF rec1.AREA1= '4' THEN
		    IF rec1.AREA2= '2' OR rec1.AREA2= '3' THEN
			   IF rec1.AREA3 = '1' OR rec1.AREA3 = '2' OR rec1.AREA3 = '3' OR rec1.AREA3 = '4' THEN
		            INSERT INTO pnl3_trx005_collect_detail_pn
                           (company_code, period, profit_center,
                            end_customer_id,
                            amt_local,
                            amt_usd,
                            amt_twd,
                            SOURCE, r_kind, area1, area2,
                            area3, create_date
                           )
                    VALUES (rec1.company_code, inperiod, rec1.profit_center,
                            null,
                            ROUND (rec1.amount * 1000 , 5),
                            ROUND (rec1.amount_usd * 1000 , 5),
                            ROUND (rec1.amount * 1000 , 5),
                            'EXPENSE', rec1.r_kind, rec1.area1, rec1.area2,
                            rec1.area3, SYSDATE
                           );

                    COMMIT;
			   END IF;
			END IF;
         END IF;
		 --End Add kangi 20141208
      ELSE                            --正常的Profit center,不是屬於34/9X或G的
         IF     rec1.r_kind = 'PL01'
--呆帳,原本談定是抓上傳的,但可能會遇到某些USER沒有上傳,所以就變成和運算..邏輯一樣,會計的金額要扣掉呆帳金額來處理
--但不檢查該PC是否有無上傳,會在上傳時檢查兩邊金額是否一致,提醒user上傳正確金額
            AND rec1.area1 = '4'
            AND rec1.area2 = '1'
            AND rec1.area3 = '3'
         THEN
            a_twd := 0;
         ELSE
--先檢查屬於上傳的是否有金額,如沒有金額則用原有邏輯,避免SITE金額跑掉,但呆帳不管,因為會計一定要上傳正確,如果正確就不會出現呆帳邏輯,而直接歸屬 2009/2/25
            a_twd := 0;

            IF     rec1.r_kind = 'PL01'                              --材料費
               AND rec1.area1 = '4'
               AND rec1.area2 = '3'
               AND rec1.area3 = '2'
            THEN
               a_twd := 0;

               BEGIN
                  SELECT NVL (SUM (amount_twd), 0)
                    INTO a_twd
                    FROM pnl2_upl004_rawexpense
                   WHERE period = inperiod
                     AND profit_center = rec1.profit_center;
               EXCEPTION
                  WHEN OTHERS
                  THEN
                     a_twd := 0;
               END;
            ELSIF     rec1.r_kind = 'PL01'                              --佣金
                  AND rec1.area1 = '4'
                  AND rec1.area2 = '1'
                  AND rec1.area3 = '5'
            THEN
               a_twd := 0;

               BEGIN
                  SELECT NVL (SUM (amount_twd), 0)
                    INTO a_twd
                    FROM pnl2_upl005_commission
                   WHERE period = inperiod
                     AND profit_center = rec1.profit_center;
               EXCEPTION
                  WHEN OTHERS
                  THEN
                     a_twd := 0;
               END;
           ELSIF     rec1.r_kind = 'PL01'                              --BG ALLOCATE
                  AND rec1.area1 = '4'
                  AND rec1.area2 = '1'
                  AND rec1.area3 = '6'
            THEN
               a_twd := 0;

               BEGIN
                  SELECT NVL (SUM (amount_twd), 0)
                    INTO a_twd
                    FROM pnl2_upl011_salesbg
                   WHERE period = inperiod
                     AND profit_center = rec1.profit_center;
               EXCEPTION
                  WHEN OTHERS
                  THEN
                     a_twd := 0;
               END;
            ELSIF     rec1.r_kind = 'PL01'                              --Corporation ALLOCATE
                  AND rec1.area1 = '4'
                  AND rec1.area2 = '1'
                  AND rec1.area3 = '7'
            THEN
               a_twd := 0;

               BEGIN
                  SELECT NVL (SUM (amount_twd), 0)
                    INTO a_twd
                    FROM pnl2_upl012_salescorp
                   WHERE period = inperiod
                     AND profit_center = rec1.profit_center;
               EXCEPTION
                  WHEN OTHERS
                  THEN
                     a_twd := 0;
               END;
            ELSIF     rec1.r_kind = 'PL01'        --運貨成本(只有某些bu的需求)
                  AND rec1.area1 = '4'
                  AND rec1.area2 = '1'
                  AND rec1.area3 = '1'
            THEN
               a_twd := 0;

               BEGIN
                  SELECT NVL (SUM (amount_twd), 0)
                    INTO a_twd
                    FROM pnl2_upl008_export
                   WHERE period = inperiod
                     AND profit_center = rec1.profit_center;
               EXCEPTION
                  WHEN OTHERS
                  THEN
                     a_twd := 0;
               END;
            ELSIF     rec1.r_kind = 'PL01'                     --After service
                  AND rec1.area1 = '4'
                  AND rec1.area2 = '1'
                  AND rec1.area3 = '2'
            THEN
               a_twd := 0;

               BEGIN
                  SELECT NVL (SUM (amount_twd), 0)
                    INTO a_twd
                    FROM pnl2_upl009_afterservice
                   WHERE period = inperiod
                     AND profit_center = rec1.profit_center;
               EXCEPTION
                  WHEN OTHERS
                  THEN
                     a_twd := 0;
               END;
            END IF;

            IF a_twd <> 0              --表示有上傳金額,要用上傳金額邏輯來處理
            THEN
               a_twd := 0;
            ELSE
               IF (   rec1.profit_center = '0000000028'
                   OR rec1.profit_center = '0000000032'
                   OR rec1.profit_center = '0000000033'
                  )
               THEN
                  a_counter := 0;

                  FOR rec2 IN (SELECT end_customer_id, rate
                                 FROM pnl3_map001_customer_rate
                                WHERE r_kind = 'PL01'
                                  --隨便抓一筆來用,反正匯率都一樣
                                  AND area1 = rec1.area1
                                  AND area2 = rec1.area2
                                  AND area3 = rec1.area3
                                  --AND COMPANY_CODE = REC1.COMPANY_CODE
                                  AND profit_center = rec1.profit_center
                                  AND period = inperiod)
                  LOOP
                     a_counter := 1;

                     INSERT INTO pnl3_trx005_collect_detail_pn
                                 (company_code, period,
                                  profit_center, end_customer_id,
                                  amt_local,
                                  amt_usd,
                                  amt_twd,
                                  SOURCE, r_kind, area1,
                                  area2, area3, create_date
                                 )
                          VALUES (rec1.company_code, inperiod,
                                  rec1.profit_center, rec2.end_customer_id,
                                  ROUND (rec1.amount * 1000 * rec2.rate, 5),
                                  ROUND (rec1.amount_usd * 1000 * rec2.rate,
                                         5),
                                  ROUND (rec1.amount * 1000 * rec2.rate, 5),
                                  'EXPENSE', rec1.r_kind, rec1.area1,
                                  rec1.area2, rec1.area3, SYSDATE
                                 );

                     COMMIT;
                  END LOOP;

                  IF a_counter = 0
                  THEN
                     FOR rec2 IN (SELECT end_customer_id, rate
                                    FROM pnl3_map001_global_cust_rate
                                   WHERE r_kind = 'PL01'
                                     --隨便抓一筆來用,反正匯率都一樣
                                     AND area1 = rec1.area1
                                     AND area2 = rec1.area2
                                     AND area3 = rec1.area3
                                     --AND COMPANY_CODE = REC1.COMPANY_CODE
                                     --AND PROFIT_CENTER = REC1.PROFIT_CENTER
                                     AND period = inperiod)
                     LOOP
                        INSERT INTO pnl3_trx005_collect_detail_pn
                                    (company_code, period,
                                     profit_center,
                                     end_customer_id,
                                     amt_local,
                                     amt_usd,
                                     amt_twd,
                                     SOURCE, r_kind, area1,
                                     area2, area3, create_date
                                    )
                             VALUES (rec1.company_code, inperiod,
                                     rec1.profit_center,
                                     rec2.end_customer_id,
                                     ROUND (rec1.amount * 1000 * rec2.rate, 5),
                                     ROUND (rec1.amount_usd * 1000 * rec2.rate,
                                            5
                                           ),
                                     ROUND (rec1.amount * 1000 * rec2.rate, 5),
                                     'EXPENSE', rec1.r_kind, rec1.area1,
                                     rec1.area2, rec1.area3, SYSDATE
                                    );

                        COMMIT;
                     END LOOP;
                  END IF;
               ELSE   --不屬於28/32/33
                  a_counter := 0;

                  FOR rec2 IN (SELECT end_customer_id, rate
                                 FROM pnl3_map003_expense_ratio
                                WHERE r_kind = rec1.r_kind
                                  AND area1 = rec1.area1
                                  AND area2 = rec1.area2
                                  AND area3 = rec1.area3
                                  AND company_code = rec1.company_code
                                  AND profit_center = rec1.profit_center
                                  AND period = inperiod
                                  AND rate <> 0)
                  LOOP
                     a_counter := 1;

                     INSERT INTO pnl3_trx005_collect_detail_pn
                                 (company_code, period,
                                  profit_center, end_customer_id,
                                  amt_local,
                                  amt_usd,
                                  amt_twd,
                                  SOURCE, r_kind, area1,
                                  area2, area3, create_date
                                 )
                          VALUES (rec1.company_code, inperiod,
                                  rec1.profit_center, rec2.end_customer_id,
                                  ROUND (rec1.amount * 1000 * rec2.rate, 5),
                                  ROUND (rec1.amount_usd * 1000 * rec2.rate,
                                         5),
                                  ROUND (rec1.amount * 1000 * rec2.rate, 5),
                                  'EXPENSE', rec1.r_kind, rec1.area1,
                                  rec1.area2, rec1.area3, SYSDATE
                                 );

                     COMMIT;
                  END LOOP;

                  IF a_counter = 0
                  THEN
                     FOR rec2 IN (SELECT end_customer_id, rate
                                    FROM pnl3_map003_expense_pc_ratio
                                   WHERE r_kind = rec1.r_kind
                                     AND area1 = rec1.area1
                                     AND area2 = rec1.area2
                                     AND area3 = rec1.area3
                                     AND period = inperiod
                                     AND rate <> 0
                                     --AND company_code = rec1.company_code
                                     AND profit_center = rec1.profit_center)
                     LOOP
                        a_counter := 1;

                        INSERT INTO pnl3_trx005_collect_detail_pn
                                    (company_code, period,
                                     profit_center,
                                     end_customer_id,
                                     amt_local,
                                     amt_usd,
                                     amt_twd,
                                     SOURCE, r_kind, area1,
                                     area2, area3, create_date
                                    )
                             VALUES (rec1.company_code, inperiod,
                                     rec1.profit_center,
                                     rec2.end_customer_id,
                                     ROUND (rec1.amount * 1000 * rec2.rate, 5),
                                     ROUND (rec1.amount_usd * 1000 * rec2.rate,
                                            5
                                           ),
                                     ROUND (rec1.amount * 1000 * rec2.rate, 5),
                                     'EXPENSE', rec1.r_kind, rec1.area1,
                                     rec1.area2, rec1.area3, SYSDATE
                                    );

                        COMMIT;
                     END LOOP;
                  END IF;

                  IF a_counter = 0
                  THEN
                     FOR rec2 IN (SELECT end_customer_id, rate
                                    FROM pnl3_map003_expense_ww_ratio
                                   WHERE r_kind = rec1.r_kind
                                     AND area1 = rec1.area1
                                     AND area2 = rec1.area2
                                     AND area3 = rec1.area3
                                     AND period = inperiod
                                     AND rate <> 0)
                     --AND company_code = rec1.company_code
                     --AND profit_center = rec1.profit_center)
                     LOOP
                        INSERT INTO pnl3_trx005_collect_detail_pn
                                    (company_code, period,
                                     profit_center,
                                     end_customer_id,
                                     amt_local,
                                     amt_usd,
                                     amt_twd,
                                     SOURCE, r_kind, area1,
                                     area2, area3, create_date
                                    )
                             VALUES (rec1.company_code, inperiod,
                                     rec1.profit_center,
                                     rec2.end_customer_id,
                                     ROUND (rec1.amount * 1000 * rec2.rate, 5),
                                     ROUND (rec1.amount_usd * 1000 * rec2.rate,
                                            5
                                           ),
                                     ROUND (rec1.amount * 1000 * rec2.rate, 5),
                                     'EXPENSE', rec1.r_kind, rec1.area1,
                                     rec1.area2, rec1.area3, SYSDATE
                                    );

                        COMMIT;
                     END LOOP;
                  END IF;
               END IF;
            END IF;
         END IF;
      END IF;
   END LOOP;



   --佣金扣掉上傳處理開始,沒有SITE的觀念---
   a_amount := 0;

   FOR rec1 IN (SELECT   profit_center, r_kind, area1, area2, area3,
                         NVL (SUM (amount), 0) * 1000 AS amt_twd,
                         NVL (SUM (amount_usd), 0) * 1000 AS amt_usd
                    FROM pnl_msa001_em_data a, pnl2_map002_em_pnl_class b
                   WHERE yyyy = a_year
                     AND MONTH = a_month
                     AND type_2 = 'Actual'
                     --AND a.profit_center = '0000000011'
                     AND a.acct_id = b.acct_id
                     AND r_kind = 'PL01'
                     AND area1 = '4'
                     AND area2 = '1'
                     AND area3 = '5'
                     --and area2 = '1'
                     --and area3 = '6'
                     AND SYSDATE BETWEEN start_date AND end_date
                GROUP BY profit_center, r_kind, area1, area2, area3)
   LOOP
      IF SUBSTR (rec1.profit_center, 1, 1) = 'G'
      THEN
         a_counter := 0;
      ELSIF    rec1.profit_center = '0000000034'
            OR SUBSTR (rec1.profit_center, 1, 9) = '000000009'
      THEN
         a_usd := 0;
         a_twd := 0;
         a_ousd := rec1.amt_usd;
         a_otwd := rec1.amt_twd;
      ELSE
         a_usd := 0;
         a_twd := 0;
         a_ousd := rec1.amt_usd;
         a_otwd := rec1.amt_twd;

         BEGIN
            SELECT NVL (SUM (amount_usd), 0), NVL (SUM (amount_twd), 0)
              INTO a_usd, a_twd
              FROM pnl2_upl005_commission
             WHERE period = inperiod AND profit_center = rec1.profit_center;
         --AND company_code = rec1.company_code;
         EXCEPTION
            WHEN OTHERS
            THEN
               a_usd := 0;
               a_twd := 0;
         END;

         IF a_twd <> 0
         THEN
            --該profit center在RD/SALES的Directly 大項裡只有材料費/佣金一個科目,且金額都給upload上來的customer,所以不用再分了
            IF a_otwd > 0
            THEN
               IF a_twd <> 0
               THEN
                  a_otwd := a_twd + a_otwd;
                  a_ousd := a_usd + a_ousd;
               END IF;
            ELSE
               a_otwd := a_otwd * -1;
               a_ousd := a_ousd * -1;

--該profit center在RD/SALES的Directly 大項裡只有材料費/佣金一個科目,且金額都給upload上來的customer,所以不用再分了
               IF a_twd <> 0
               THEN
                  IF a_otwd < a_twd
                  THEN                            --差異金額要補回,所以不用-1
                     a_otwd := a_twd - a_otwd;
                     a_ousd := a_usd - a_ousd;
                  ELSIF a_otwd = a_twd
                  THEN
                     a_otwd := 0;
                     a_ousd := 0;
                  ELSE                                    --上傳金額小於EM金額
                     a_otwd := (a_otwd - a_twd) * -1;
                     a_ousd := (a_ousd - a_usd) * -1;
                  END IF;
               ELSE
                  a_otwd := a_otwd * -1;
                  a_ousd := a_ousd * -1;
               END IF;
            END IF;

            IF a_otwd <> 0 and abs(a_otwd) > 100 --金額差異超過100元的才要計算
            THEN
               a_counter := 0;

               IF (   rec1.profit_center = '0000000028'
                   OR rec1.profit_center = '0000000032'
                   OR rec1.profit_center = '0000000033'
                  )
               THEN
                  FOR rec3 IN
                     (SELECT SUM (amt_twd) amt_twd
                        FROM pnl3_trx001_copa
                       WHERE profit_center = rec1.profit_center
                         AND period = inperiod
                         AND end_customer_id NOT IN (
                                SELECT end_customer_id
                                  FROM pnl2_upl005_commission
                                 WHERE period = inperiod
                                   AND profit_center =
                                                pnl3_trx001_copa.profit_center))
                  LOOP


                     FOR rec2 IN
                        (SELECT   end_customer_id, SUM (amt_twd) amt_twd
                             FROM pnl3_trx001_copa
                            WHERE profit_center = rec1.profit_center
                              AND period = inperiod
                              AND end_customer_id NOT IN (
                                     SELECT end_customer_id
                                       FROM pnl2_upl005_commission
                                      WHERE period = inperiod
                                        AND profit_center =
                                                pnl3_trx001_copa.profit_center)
                           HAVING SUM (amt_twd) <> 0
                         GROUP BY end_customer_id)
                     LOOP
                        a_counter := 1;
                        a_rate := rec2.amt_twd / rec3.amt_twd;

                        INSERT INTO pnl3_trx005_collect_detail_pn
                                    (company_code, period, profit_center,
                                     end_customer_id,
                                     amt_local,
                                     amt_usd,
                                     amt_twd, SOURCE,
                                     r_kind, area1, area2,
                                     area3, create_date
                                    )
                             VALUES ('1100', inperiod, rec1.profit_center,
                                     rec2.end_customer_id,
                                     ROUND (a_otwd * a_rate, 5),
                                     ROUND (a_ousd * a_rate, 5),
                                     ROUND (a_otwd * a_rate, 5), 'EXPENSE',
                                     rec1.r_kind, rec1.area1, rec1.area2,
                                     rec1.area3, SYSDATE
                                    );

                        COMMIT;
                     END LOOP;
                  END LOOP;

                  IF a_counter = 0
                  --表示找不到,可能為原因只有一個就是只有一個END CUSTOMER.,其他還輯不可能出現
                  THEN
                     FOR rec2 IN (SELECT end_customer_id, rate
                                    FROM pnl3_map001_customer_rate
                                   WHERE r_kind = rec1.r_kind
                                     AND area1 = rec1.area1
                                     AND area2 = rec1.area2
                                     AND area3 = rec1.area3
                                     AND period = inperiod
                                     AND profit_center = rec1.profit_center
                                     AND rate <> 0)
                     LOOP
                        a_counter := 1;

                        INSERT INTO pnl3_trx005_collect_detail_pn
                                    (company_code, period, profit_center,
                                     end_customer_id,
                                     amt_local,
                                     amt_usd,
                                     amt_twd,
                                     SOURCE, r_kind, area1,
                                     area2, area3, create_date
                                    )
                             VALUES ('1100', inperiod, rec1.profit_center,
                                     rec2.end_customer_id,
                                     ROUND (a_otwd * rec2.rate, 5),
                                     ROUND (a_ousd * rec2.rate, 5),
                                     ROUND (a_otwd * rec2.rate, 5),
                                     'EXPENSE', rec1.r_kind, rec1.area1,
                                     rec1.area2, rec1.area3, SYSDATE
                                    );

                        COMMIT;
                     END LOOP;
                  END IF;

                  IF a_counter = 0
                  --表示找不到,2009/3/11邏輯,金額歸給空白的end customer
                  THEN

                        a_counter := 1;

                        INSERT INTO pnl3_trx005_collect_detail_pn
                                    (company_code, period, profit_center,
                                     end_customer_id,
                                     amt_local,
                                     amt_usd,
                                     amt_twd,
                                     SOURCE, r_kind, area1,
                                     area2, area3, create_date
                                    )
                             VALUES ('1100', inperiod, rec1.profit_center,
                                     null,
                                     ROUND (a_otwd , 5),
                                     ROUND (a_ousd , 5),
                                     ROUND (a_otwd , 5),
                                     'EXPENSE', rec1.r_kind, rec1.area1,
                                     rec1.area2, rec1.area3, SYSDATE
                                    );

                        COMMIT;

                  END IF;


               ELSE                                        ---不是屬於28,32,33
                  FOR rec3 IN
                     (SELECT SUM (headcount) headcount
                        FROM pnl2_upl006_headcount
                       WHERE profit_center = rec1.profit_center
                         AND period = inperiod
                         AND CATEGORY <> 'RD'
                         AND end_customer_id NOT IN (
                                SELECT end_customer_id
                                  FROM pnl2_upl005_commission
                                 WHERE period = inperiod
                                   AND profit_center =
                                           pnl2_upl006_headcount.profit_center))
                  LOOP


                     FOR rec2 IN
                        (SELECT   end_customer_id, SUM (headcount) headcount
                             FROM pnl2_upl006_headcount
                            WHERE profit_center = rec1.profit_center
                              AND period = inperiod
                              AND CATEGORY <> 'RD'
                              AND end_customer_id NOT IN (
                                     SELECT end_customer_id
                                       FROM pnl2_upl005_commission
                                      WHERE period = inperiod
                                        AND profit_center =
                                               pnl2_upl006_headcount.profit_center)
                           HAVING SUM (headcount) <> 0
                         GROUP BY end_customer_id)
                     LOOP
                        a_counter := 1;
                        a_rate := rec2.headcount / rec3.headcount;

                        INSERT INTO pnl3_trx005_collect_detail_pn
                                    (company_code, period, profit_center,
                                     end_customer_id,
                                     amt_local,
                                     amt_usd,
                                     amt_twd, SOURCE,
                                     r_kind, area1, area2,
                                     area3, create_date
                                    )
                             VALUES ('1100', inperiod, rec1.profit_center,
                                     rec2.end_customer_id,
                                     ROUND (a_otwd * a_rate, 5),
                                     ROUND (a_ousd * a_rate, 5),
                                     ROUND (a_otwd * a_rate, 5), 'EXPENSE',
                                     rec1.r_kind, rec1.area1, rec1.area2,
                                     rec1.area3, SYSDATE
                                    );

                        COMMIT;
                     END LOOP;
                  END LOOP;

                  IF a_counter = 0
                  --表示找不到,可能為原因只有一個就是只有一個END CUSTOMER.,其他還輯不可能出現
                  THEN
                     FOR rec2 IN (SELECT end_customer_id, rate
                                    FROM pnl3_map003_expense_pc_ratio
                                   WHERE r_kind = rec1.r_kind
                                     AND area1 = rec1.area1
                                     AND area2 = rec1.area2
                                     AND area3 = rec1.area3
                                     AND period = inperiod
                                     AND profit_center = rec1.profit_center
                                     AND rate <> 0)
                     LOOP
                        a_counter := 1;

                        INSERT INTO pnl3_trx005_collect_detail_pn
                                    (company_code, period, profit_center,
                                     end_customer_id,
                                     amt_local,
                                     amt_usd,
                                     amt_twd,
                                     SOURCE, r_kind, area1,
                                     area2, area3, create_date
                                    )
                             VALUES ('1100', inperiod, rec1.profit_center,
                                     rec2.end_customer_id,
                                     ROUND (a_otwd * rec2.rate, 5),
                                     ROUND (a_ousd * rec2.rate, 5),
                                     ROUND (a_otwd * rec2.rate, 5),
                                     'EXPENSE', rec1.r_kind, rec1.area1,
                                     rec1.area2, rec1.area3, SYSDATE
                                    );

                        COMMIT;
                     END LOOP;
                  END IF;

                  IF a_counter = 0
                  --表示找不到,2009/3/11邏輯,金額歸給空白的end customer
                  THEN

                        a_counter := 1;

                        INSERT INTO pnl3_trx005_collect_detail_pn
                                    (company_code, period, profit_center,
                                     end_customer_id,
                                     amt_local,
                                     amt_usd,
                                     amt_twd,
                                     SOURCE, r_kind, area1,
                                     area2, area3, create_date
                                    )
                             VALUES ('1100', inperiod, rec1.profit_center,
                                     null,
                                     ROUND (a_otwd , 5),
                                     ROUND (a_ousd , 5),
                                     ROUND (a_otwd , 5),
                                     'EXPENSE', rec1.r_kind, rec1.area1,
                                     rec1.area2, rec1.area3, SYSDATE
                                    );

                        COMMIT;

                  END IF;

               END IF;
            END IF;
         END IF;
      END IF;
   END LOOP;

   --材料費扣掉上傳處理開始,沒有SITE的觀念---
   a_amount := 0;

   BEGIN
      SELECT SUM (amt_twd)
        INTO a_amount
        FROM pnl3_trx001_copa
       WHERE period = inperiod
         AND area1 = '1'
         AND area2 = '1'
         AND area3 = '0'
         AND amt_twd <> 0
         AND end_customer_id NOT IN (SELECT end_customer_id
                                       FROM pnl2_upl004_rawexpense
                                      WHERE period = inperiod);
   EXCEPTION
      WHEN OTHERS
      THEN
         a_amount := 0;
   END;

   FOR rec1 IN (SELECT   profit_center, r_kind, area1, area2, area3,
                         NVL (SUM (amount), 0) * 1000 AS amt_twd,
                         NVL (SUM (amount_usd), 0) * 1000 AS amt_usd
                    FROM pnl_msa001_em_data a, pnl2_map002_em_pnl_class b
                   WHERE yyyy = a_year
                     AND MONTH = a_month
                     AND type_2 = 'Actual'
                     --AND a.profit_center = '0000000034'
                     AND a.acct_id = b.acct_id
                     AND r_kind = 'PL01'
                     AND area1 = '4'
                     AND area2 = '3'
                     AND area3 = '2'
                     --and area2 = '1'
                     --and area3 = '6'
                     AND SYSDATE BETWEEN start_date AND end_date
                GROUP BY profit_center, r_kind, area1, area2, area3)
   LOOP
      IF    rec1.profit_center = '0000000034'
         OR SUBSTR (rec1.profit_center, 1, 9) = '000000009'
         OR SUBSTR (rec1.profit_center, 1, 1) = 'G'
      THEN
         a_usd := 0;
         a_twd := 0;
         a_ousd := rec1.amt_usd;
         a_otwd := rec1.amt_twd;
      ELSE
         a_usd := 0;
         a_twd := 0;
         a_ousd := rec1.amt_usd;
         a_otwd := rec1.amt_twd;

         BEGIN
            SELECT NVL (SUM (amount_usd), 0), NVL (SUM (amount_twd), 0)
              INTO a_usd, a_twd
              FROM pnl2_upl004_rawexpense
             WHERE period = inperiod AND profit_center = rec1.profit_center;
         --AND company_code = rec1.company_code;
         EXCEPTION
            WHEN OTHERS
            THEN
               a_usd := 0;
               a_twd := 0;
         END;

         IF a_twd <> 0
         THEN
--該profit center在RD/SALES的Directly 大項裡只有材料費/佣金一個科目,且金額都給upload上來的customer,所以不用再分了
            IF a_otwd > 0
            THEN                                 --原本呆帳討到錢了,所以變正,
               IF a_twd <> 0
               THEN
                  a_otwd := a_twd + a_otwd;
                  a_ousd := a_usd + a_ousd;
               END IF;
            ELSE
               a_otwd := a_otwd * -1;
               a_ousd := a_ousd * -1;

--該profit center在RD/SALES的Directly 大項裡只有材料費/佣金一個科目,且金額都給upload上來的customer,所以不用再分了
               IF a_twd <> 0
               THEN
                  IF a_otwd < a_twd
                  THEN                            --差異金額要補回,所以不用-1
                     a_otwd := a_twd - a_otwd;
                     a_ousd := a_usd - a_ousd;
                  ELSIF a_otwd = a_twd
                  THEN
                     a_otwd := 0;
                     a_ousd := 0;
                  ELSE                                    --上傳金額小於EM金額
                     a_otwd := (a_otwd - a_twd) * -1;
                     a_ousd := (a_ousd - a_usd) * -1;
                  END IF;
               ELSE
                  a_otwd := a_otwd * -1;
                  a_ousd := a_ousd * -1;
               END IF;
            END IF;

            IF a_otwd <> 0 and abs(a_otwd) > 100 --金額差異超過100元的才要計算
            THEN
               a_counter := 0;

               IF (   rec1.profit_center = '0000000028'
                   OR rec1.profit_center = '0000000032'
                   OR rec1.profit_center = '0000000033'
                  )
               THEN
                  FOR rec3 IN
                     (SELECT SUM (amt_twd) amt_twd
                        FROM pnl3_trx001_copa
                       WHERE profit_center = rec1.profit_center
                         AND period = inperiod
                         AND end_customer_id NOT IN (
                                SELECT end_customer_id
                                  FROM pnl2_upl004_rawexpense
                                 WHERE period = inperiod
                                   AND profit_center =
                                                pnl3_trx001_copa.profit_center))
                  LOOP


                     FOR rec2 IN
                        (SELECT   end_customer_id, SUM (amt_twd) amt_twd
                             FROM pnl3_trx001_copa
                            WHERE profit_center = rec1.profit_center
                              AND period = inperiod
                              AND end_customer_id NOT IN (
                                     SELECT end_customer_id
                                       FROM pnl2_upl004_rawexpense
                                      WHERE period = inperiod
                                        AND profit_center =
                                                pnl3_trx001_copa.profit_center)
                           HAVING SUM (amt_twd) <> 0
                         GROUP BY end_customer_id)
                     LOOP
                        a_counter := 1;
                        a_rate := rec2.amt_twd / rec3.amt_twd;

                        INSERT INTO pnl3_trx005_collect_detail_pn
                                    (company_code, period, profit_center,
                                     end_customer_id,
                                     amt_local,
                                     amt_usd,
                                     amt_twd, SOURCE,
                                     r_kind, area1, area2,
                                     area3, create_date, pdm_project
                                    )
                             VALUES ('1100', inperiod, rec1.profit_center,
                                     rec2.end_customer_id,
                                     ROUND (a_otwd * a_rate, 5),
                                     ROUND (a_ousd * a_rate, 5),
                                     ROUND (a_otwd * a_rate, 5), 'EXPENSE',
                                     rec1.r_kind, rec1.area1, rec1.area2,
                                     rec1.area3, SYSDATE, NULL
                                    );

                        COMMIT;
                     END LOOP;
                  END LOOP;

                  IF a_counter = 0
                  --表示找不到,可能為原因只有一個就是只有一個END CUSTOMER.,其他還輯不可能出現
                  THEN
                     FOR rec2 IN (SELECT end_customer_id, rate
                                    FROM pnl3_map001_customer_rate
                                   WHERE r_kind = rec1.r_kind
                                     AND area1 = rec1.area1
                                     AND area2 = rec1.area2
                                     AND area3 = rec1.area3
                                     AND period = inperiod
                                     AND profit_center = rec1.profit_center
                                     AND rate <> 0)
                     LOOP
                        a_counter := 1;

                        INSERT INTO pnl3_trx005_collect_detail_pn
                                    (company_code, period, profit_center,
                                     end_customer_id,
                                     amt_local,
                                     amt_usd,
                                     amt_twd,
                                     SOURCE, r_kind, area1,
                                     area2, area3, create_date, pdm_project
                                    )
                             VALUES ('1100', inperiod, rec1.profit_center,
                                     rec2.end_customer_id,
                                     ROUND (a_otwd * rec2.rate, 5),
                                     ROUND (a_ousd * rec2.rate, 5),
                                     ROUND (a_otwd * rec2.rate, 5),
                                     'EXPENSE', rec1.r_kind, rec1.area1,
                                     rec1.area2, rec1.area3, SYSDATE, NULL
                                    );

                        COMMIT;
                     END LOOP;
                  END IF;

                  IF a_counter = 0
                  --表示找不到,2009/3/11邏輯,金額歸給空白的end customer
                  THEN

                        a_counter := 1;

                        INSERT INTO pnl3_trx005_collect_detail_pn
                                    (company_code, period, profit_center,
                                     end_customer_id,
                                     amt_local,
                                     amt_usd,
                                     amt_twd,
                                     SOURCE, r_kind, area1,
                                     area2, area3, create_date
                                    )
                             VALUES ('1100', inperiod, rec1.profit_center,
                                     null,
                                     ROUND (a_otwd , 5),
                                     ROUND (a_ousd , 5),
                                     ROUND (a_otwd , 5),
                                     'EXPENSE', rec1.r_kind, rec1.area1,
                                     rec1.area2, rec1.area3, SYSDATE
                                    );

                        COMMIT;

                  END IF;

               ELSE                                        ---不是屬於28,32,33
                  FOR rec3 IN
                     (SELECT SUM (headcount) headcount
                        FROM pnl2_upl006_headcount
                       WHERE profit_center = rec1.profit_center
                         AND period = inperiod
                         AND CATEGORY = 'RD'
                         AND end_customer_id NOT IN (
                                SELECT end_customer_id
                                  FROM pnl2_upl004_rawexpense
                                 WHERE period = inperiod
                                   AND profit_center =
                                           pnl2_upl006_headcount.profit_center))
                  LOOP


                     FOR rec2 IN
                        (SELECT   end_customer_id, SUM (headcount) headcount
                             FROM pnl2_upl006_headcount
                            WHERE profit_center = rec1.profit_center
                              AND period = inperiod
                              AND CATEGORY = 'RD'
                              AND end_customer_id NOT IN (
                                     SELECT end_customer_id
                                       FROM pnl2_upl004_rawexpense
                                      WHERE period = inperiod
                                        AND profit_center =
                                               pnl2_upl006_headcount.profit_center)
                           HAVING SUM (headcount) <> 0
                         GROUP BY end_customer_id)
                     LOOP
                        a_counter := 1;
                        a_rate := rec2.headcount / rec3.headcount;

                        INSERT INTO pnl3_trx005_collect_detail_pn
                                    (company_code, period, profit_center,
                                     end_customer_id,
                                     amt_local,
                                     amt_usd,
                                     amt_twd, SOURCE,
                                     r_kind, area1, area2,
                                     area3, create_date, pdm_project
                                    )
                             VALUES ('1100', inperiod, rec1.profit_center,
                                     rec2.end_customer_id,
                                     ROUND (a_otwd * a_rate, 5),
                                     ROUND (a_ousd * a_rate, 5),
                                     ROUND (a_otwd * a_rate, 5), 'EXPENSE',
                                     rec1.r_kind, rec1.area1, rec1.area2,
                                     rec1.area3, SYSDATE, NULL
                                    );

                        COMMIT;
                     END LOOP;
                  END LOOP;

                  IF a_counter = 0
                  --表示找不到,可能為原因只有一個就是只有一個END CUSTOMER.,其他還輯不可能出現
                  THEN
                     FOR rec2 IN (SELECT end_customer_id, rate
                                    FROM pnl3_map003_expense_pc_ratio
                                   WHERE r_kind = rec1.r_kind
                                     AND area1 = rec1.area1
                                     AND area2 = rec1.area2
                                     AND area3 = rec1.area3
                                     AND period = inperiod
                                     AND profit_center = rec1.profit_center
                                     AND rate <> 0)
                     LOOP
                        a_counter := 1;

                        INSERT INTO pnl3_trx005_collect_detail_pn
                                    (company_code, period, profit_center,
                                     end_customer_id,
                                     amt_local,
                                     amt_usd,
                                     amt_twd,
                                     SOURCE, r_kind, area1,
                                     area2, area3, create_date, pdm_project
                                    )
                             VALUES ('1100', inperiod, rec1.profit_center,
                                     rec2.end_customer_id,
                                     ROUND (a_otwd * rec2.rate, 5),
                                     ROUND (a_ousd * rec2.rate, 5),
                                     ROUND (a_otwd * rec2.rate, 5),
                                     'EXPENSE', rec1.r_kind, rec1.area1,
                                     rec1.area2, rec1.area3, SYSDATE, NULL
                                    );

                        COMMIT;
                     END LOOP;
                  END IF;

                  IF a_counter = 0
                  --表示找不到,2009/3/11邏輯,金額歸給空白的end customer
                  THEN

                        a_counter := 1;

                        INSERT INTO pnl3_trx005_collect_detail_pn
                                    (company_code, period, profit_center,
                                     end_customer_id,
                                     amt_local,
                                     amt_usd,
                                     amt_twd,
                                     SOURCE, r_kind, area1,
                                     area2, area3, create_date
                                    )
                             VALUES ('1100', inperiod, rec1.profit_center,
                                     null,
                                     ROUND (a_otwd , 5),
                                     ROUND (a_ousd , 5),
                                     ROUND (a_otwd , 5),
                                     'EXPENSE', rec1.r_kind, rec1.area1,
                                     rec1.area2, rec1.area3, SYSDATE
                                    );

                        COMMIT;

                  END IF;

               END IF;
            END IF;
         END IF;
      END IF;
   END LOOP;

   --運費扣掉上傳處理開始,沒有SITE的觀念---
   a_amount := 0;

   FOR rec1 IN (SELECT   profit_center, r_kind, area1, area2, area3,
                         NVL (SUM (amount), 0) * 1000 AS amt_twd,
                         NVL (SUM (amount_usd), 0) * 1000 AS amt_usd
                    FROM pnl_msa001_em_data a, pnl2_map002_em_pnl_class b
                   WHERE yyyy = a_year
                     AND MONTH = a_month
                     AND type_2 = 'Actual'
                     --AND a.profit_center = '0000000011'
                     AND a.acct_id = b.acct_id
                     AND r_kind = 'PL01'
                     AND area1 = '4'
                     AND area2 = '1'
                     AND area3 = '1'
                     --and area2 = '1'
                     --and area3 = '6'
                     AND SYSDATE BETWEEN start_date AND end_date
                GROUP BY profit_center, r_kind, area1, area2, area3)
   LOOP
      IF SUBSTR (rec1.profit_center, 1, 1) = 'G'
      THEN
         a_counter := 0;
      ELSIF    rec1.profit_center = '0000000034'
            OR SUBSTR (rec1.profit_center, 1, 9) = '000000009'
      THEN
         a_usd := 0;
         a_twd := 0;
         a_ousd := rec1.amt_usd;
         a_otwd := rec1.amt_twd;
      ELSE
         a_usd := 0;
         a_twd := 0;
         a_ousd := rec1.amt_usd;
         a_otwd := rec1.amt_twd;

         BEGIN
            SELECT NVL (SUM (amount_usd), 0), NVL (SUM (amount_twd), 0)
              INTO a_usd, a_twd
              FROM pnl2_upl008_export
             WHERE period = inperiod AND profit_center = rec1.profit_center;
         --AND company_code = rec1.company_code;
         EXCEPTION
            WHEN OTHERS
            THEN
               a_usd := 0;
               a_twd := 0;
         END;

         IF a_twd <> 0
         THEN
            IF a_otwd > 0
            THEN                                 --原本呆帳討到錢了,所以變正,
               IF a_twd <> 0
               THEN
                  a_otwd := a_twd + a_otwd;
                  a_ousd := a_usd + a_ousd;
               END IF;
            ELSE
               a_otwd := a_otwd * -1;
               a_ousd := a_ousd * -1;

--該profit center在RD/SALES的Directly 大項裡只有材料費/佣金一個科目,且金額都給upload上來的customer,所以不用再分了
               IF a_twd <> 0
               THEN
                  IF a_otwd < a_twd
                  THEN                            --差異金額要補回,所以不用-1
                     a_otwd := a_twd - a_otwd;
                     a_ousd := a_usd - a_ousd;
                  ELSIF a_otwd = a_twd
                  THEN
                     a_otwd := 0;
                     a_ousd := 0;
                  ELSE                                    --上傳金額小於EM金額
                     a_otwd := (a_otwd - a_twd) * -1;
                     a_ousd := (a_ousd - a_usd) * -1;
                  END IF;
               ELSE
                  a_otwd := a_otwd * -1;
                  a_ousd := a_ousd * -1;
               END IF;
            END IF;

            IF a_otwd <> 0 and abs(a_otwd) > 100 --金額差異超過100元的才要計算
            THEN
               a_counter := 0;

               IF (   rec1.profit_center = '0000000028'
                   OR rec1.profit_center = '0000000032'
                   OR rec1.profit_center = '0000000033'
                  )
               THEN
                  FOR rec3 IN
                     (SELECT SUM (amt_twd) amt_twd
                        FROM pnl3_trx001_copa
                       WHERE profit_center = rec1.profit_center
                         AND period = inperiod
                         AND end_customer_id NOT IN (
                                SELECT end_customer_id
                                  FROM pnl2_upl008_export
                                 WHERE period = inperiod
                                   AND profit_center =
                                                pnl3_trx001_copa.profit_center))
                  LOOP


                     FOR rec2 IN
                        (SELECT   end_customer_id, SUM (amt_twd) amt_twd
                             FROM pnl3_trx001_copa
                            WHERE profit_center = rec1.profit_center
                              AND period = inperiod
                              AND end_customer_id NOT IN (
                                     SELECT end_customer_id
                                       FROM pnl2_upl008_export
                                      WHERE period = inperiod
                                        AND profit_center =
                                                pnl3_trx001_copa.profit_center)
                           HAVING SUM (amt_twd) <> 0
                         GROUP BY end_customer_id)
                     LOOP
                        a_counter := 1;
                        a_rate := rec2.amt_twd / rec3.amt_twd;

                        INSERT INTO pnl3_trx005_collect_detail_pn
                                    (company_code, period, profit_center,
                                     end_customer_id,
                                     amt_local,
                                     amt_usd,
                                     amt_twd, SOURCE,
                                     r_kind, area1, area2,
                                     area3, create_date
                                    )
                             VALUES ('1100', inperiod, rec1.profit_center,
                                     rec2.end_customer_id,
                                     ROUND (a_otwd * a_rate, 5),
                                     ROUND (a_ousd * a_rate, 5),
                                     ROUND (a_otwd * a_rate, 5), 'EXPENSE',
                                     rec1.r_kind, rec1.area1, rec1.area2,
                                     rec1.area3, SYSDATE
                                    );

                        COMMIT;
                     END LOOP;
                  END LOOP;

                  IF a_counter = 0
                  --表示找不到,可能為原因只有一個就是只有一個END CUSTOMER.,其他還輯不可能出現
                  THEN
                     FOR rec2 IN (SELECT end_customer_id, rate
                                    FROM pnl3_map001_customer_rate
                                   WHERE r_kind = rec1.r_kind
                                     AND area1 = rec1.area1
                                     AND area2 = rec1.area2
                                     AND area3 = rec1.area3
                                     AND period = inperiod
                                     AND profit_center = rec1.profit_center
                                     AND rate <> 0)
                     LOOP
                        a_counter := 1;

                        INSERT INTO pnl3_trx005_collect_detail_pn
                                    (company_code, period, profit_center,
                                     end_customer_id,
                                     amt_local,
                                     amt_usd,
                                     amt_twd,
                                     SOURCE, r_kind, area1,
                                     area2, area3, create_date
                                    )
                             VALUES ('1100', inperiod, rec1.profit_center,
                                     rec2.end_customer_id,
                                     ROUND (a_otwd * rec2.rate, 5),
                                     ROUND (a_ousd * rec2.rate, 5),
                                     ROUND (a_otwd * rec2.rate, 5),
                                     'EXPENSE', rec1.r_kind, rec1.area1,
                                     rec1.area2, rec1.area3, SYSDATE
                                    );

                        COMMIT;
                     END LOOP;
                  END IF;

                  IF a_counter = 0
                  --表示找不到,2009/3/11邏輯,金額歸給空白的end customer
                  THEN

                        a_counter := 1;

                        INSERT INTO pnl3_trx005_collect_detail_pn
                                    (company_code, period, profit_center,
                                     end_customer_id,
                                     amt_local,
                                     amt_usd,
                                     amt_twd,
                                     SOURCE, r_kind, area1,
                                     area2, area3, create_date
                                    )
                             VALUES ('1100', inperiod, rec1.profit_center,
                                     null,
                                     ROUND (a_otwd , 5),
                                     ROUND (a_ousd , 5),
                                     ROUND (a_otwd , 5),
                                     'EXPENSE', rec1.r_kind, rec1.area1,
                                     rec1.area2, rec1.area3, SYSDATE
                                    );

                        COMMIT;

                  END IF;

               ELSE                                        ---不是屬於28,32,33
                  FOR rec3 IN
                     (SELECT SUM (headcount) headcount
                        FROM pnl2_upl006_headcount
                       WHERE profit_center = rec1.profit_center
                         AND period = inperiod
                         AND CATEGORY <> 'RD'
                         AND end_customer_id NOT IN (
                                SELECT end_customer_id
                                  FROM pnl2_upl008_export
                                 WHERE period = inperiod
                                   AND profit_center =
                                           pnl2_upl006_headcount.profit_center))
                  LOOP


                     FOR rec2 IN
                        (SELECT   end_customer_id, SUM (headcount) headcount
                             FROM pnl2_upl006_headcount
                            WHERE profit_center = rec1.profit_center
                              AND period = inperiod
                              AND CATEGORY <> 'RD'
                              AND end_customer_id NOT IN (
                                     SELECT end_customer_id
                                       FROM pnl2_upl008_export
                                      WHERE period = inperiod
                                        AND profit_center =
                                               pnl2_upl006_headcount.profit_center)
                           HAVING SUM (headcount) <> 0
                         GROUP BY end_customer_id)
                     LOOP
                        a_counter := 1;
                        a_rate := rec2.headcount / rec3.headcount;

                        INSERT INTO pnl3_trx005_collect_detail_pn
                                    (company_code, period, profit_center,
                                     end_customer_id,
                                     amt_local,
                                     amt_usd,
                                     amt_twd, SOURCE,
                                     r_kind, area1, area2,
                                     area3, create_date
                                    )
                             VALUES ('1100', inperiod, rec1.profit_center,
                                     rec2.end_customer_id,
                                     ROUND (a_otwd * a_rate, 5),
                                     ROUND (a_ousd * a_rate, 5),
                                     ROUND (a_otwd * a_rate, 5), 'EXPENSE',
                                     rec1.r_kind, rec1.area1, rec1.area2,
                                     rec1.area3, SYSDATE
                                    );

                        COMMIT;
                     END LOOP;
                  END LOOP;

                  IF a_counter = 0
                  --表示找不到,可能為原因只有一個就是只有一個END CUSTOMER.,其他還輯不可能出現
                  THEN
                     FOR rec2 IN (SELECT end_customer_id, rate
                                    FROM pnl3_map003_expense_pc_ratio
                                   WHERE r_kind = rec1.r_kind
                                     AND area1 = rec1.area1
                                     AND area2 = rec1.area2
                                     AND area3 = rec1.area3
                                     AND period = inperiod
                                     AND profit_center = rec1.profit_center
                                     AND rate <> 0)
                     LOOP
                        a_counter := 1;

                        INSERT INTO pnl3_trx005_collect_detail_pn
                                    (company_code, period, profit_center,
                                     end_customer_id,
                                     amt_local,
                                     amt_usd,
                                     amt_twd,
                                     SOURCE, r_kind, area1,
                                     area2, area3, create_date
                                    )
                             VALUES ('1100', inperiod, rec1.profit_center,
                                     rec2.end_customer_id,
                                     ROUND (a_otwd * rec2.rate, 5),
                                     ROUND (a_ousd * rec2.rate, 5),
                                     ROUND (a_otwd * rec2.rate, 5),
                                     'EXPENSE', rec1.r_kind, rec1.area1,
                                     rec1.area2, rec1.area3, SYSDATE
                                    );

                        COMMIT;
                     END LOOP;
                  END IF;

                  IF a_counter = 0
                  --表示找不到,2009/3/11邏輯,金額歸給空白的end customer
                  THEN

                        a_counter := 1;

                        INSERT INTO pnl3_trx005_collect_detail_pn
                                    (company_code, period, profit_center,
                                     end_customer_id,
                                     amt_local,
                                     amt_usd,
                                     amt_twd,
                                     SOURCE, r_kind, area1,
                                     area2, area3, create_date
                                    )
                             VALUES ('1100', inperiod, rec1.profit_center,
                                     null,
                                     ROUND (a_otwd , 5),
                                     ROUND (a_ousd , 5),
                                     ROUND (a_otwd , 5),
                                     'EXPENSE', rec1.r_kind, rec1.area1,
                                     rec1.area2, rec1.area3, SYSDATE
                                    );

                        COMMIT;

                  END IF;

               END IF;
            END IF;
         END IF;
      END IF;
   END LOOP;

   --呆帳扣掉上傳處理開始,沒有SITE的觀念---
   --2009/1/15 套用新邏輯後20/21只有一個客戶,所以要將差額重分配時找不到客戶可以分配
   --2009/2/17 呆帳以上傳金額為主
   --2009/3/10 全部用上傳金額(在上傳時就要和EM比對了),所以這裡不在做處理,直接搬到pnl3_trx005_collect_detail去放
   a_amount := 0;
   /*
   FOR rec1 IN (SELECT   profit_center, r_kind, area1, area2, area3,
                         NVL (SUM (amount), 0) * 1000 AS amt_twd,
                         NVL (SUM (amount_usd), 0) * 1000 AS amt_usd
                    FROM pnl_msa001_em_data a, pnl2_map002_em_pnl_class b
                   WHERE yyyy = a_year
                     AND MONTH = a_month
                     AND type_2 = 'Actual'
                     --AND a.profit_center = '0000000020'
                     AND a.acct_id = b.acct_id
                     AND r_kind = 'PL01'
                     AND area1 = '4'
                     AND area2 = '1'
                     AND area3 = '3'
                     --and area2 = '1'
                     --and area3 = '6'
                     AND SYSDATE BETWEEN start_date AND end_date
                GROUP BY profit_center, r_kind, area1, area2, area3)
   LOOP
      IF SUBSTR (rec1.profit_center, 1, 1) = 'G'
      THEN
         a_counter := 0;
      ELSIF  --  rec1.profit_center = '0000000034'
            SUBSTR (rec1.profit_center, 1, 9) = '000000009'
      THEN
         a_usd := 0;
         a_twd := 0;
         a_ousd := rec1.amt_usd;
         a_otwd := rec1.amt_twd;
      ELSE
         a_usd := 0;
         a_twd := 0;
         a_ousd := rec1.amt_usd;
         a_otwd := rec1.amt_twd;

         BEGIN
            SELECT NVL (SUM (amount_usd), 0), NVL (SUM (amount_twd), 0)
              INTO a_usd, a_twd
              FROM pnl2_upl002_bad_debt
             WHERE period = inperiod AND profit_center = rec1.profit_center;
         --AND company_code = rec1.company_code;
         EXCEPTION
            WHEN OTHERS
            THEN
               a_usd := 0;
               a_twd := 0;
         END;

         n_usd := 0;
         n_twd := 0;

         IF a_otwd > 0
         THEN                                     --原本呆帳討到錢了,所以變正,
            IF a_twd <> 0
            THEN
               a_otwd := a_twd + a_otwd;
               a_ousd := a_usd + a_ousd;
            END IF;
         ELSE
            a_otwd := a_otwd * -1;
            a_ousd := a_ousd * -1;

--該profit center在RD/SALES的Directly 大項裡只有材料費/佣金一個科目,且金額都給upload上來的customer,所以不用再分了
            IF a_twd <> 0
            THEN
               IF a_otwd < a_twd
               THEN                               --差異金額要補回,所以不用-1
                  a_otwd := a_twd - a_otwd;
                  a_ousd := a_usd - a_ousd;
               ELSIF a_otwd = a_twd
               THEN
                  a_otwd := 0;
                  a_ousd := 0;
               ELSE                                       --上傳金額小於EM金額
                  a_otwd := (a_otwd - a_twd) * -1;
                  a_ousd := (a_ousd - a_usd) * -1;
               END IF;
            ELSE
               a_otwd := a_otwd * -1;
               a_ousd := a_ousd * -1;
            END IF;
         END IF;

         IF a_otwd <> 0 and abs(a_otwd) > 100 --金額差異超過100元的才要計算
         THEN
            IF rec1.profit_center = '0000000034' THEN
                     INSERT INTO pnl3_trx005_collect_detail_pn
                     (company_code, period, profit_center,
                      end_customer_id, amt_local,
                      amt_usd,
                      amt_twd, SOURCE, r_kind,
                      area1, area2, area3, create_date
                     )
              VALUES ('1100', inperiod, rec1.profit_center,
                      'UABIT''S CUST', ROUND (a_otwd * 1000, 5),
                      ROUND (a_oUSd * 1000, 5),
                      ROUND (a_otwd* 1000, 5), 'EXPENSE', rec1.r_kind,
                      rec1.area1, rec1.area2, rec1.area3, SYSDATE
                     );

         COMMIT;
            ELSE
            a_counter := 0;

            IF (   rec1.profit_center = '0000000028'
                OR rec1.profit_center = '0000000032'
                OR rec1.profit_center = '0000000033'
               )
            THEN
               FOR rec3 IN
                  (SELECT SUM (amt_twd) amt_twd
                     FROM pnl3_trx001_copa
                    WHERE profit_center = rec1.profit_center
                      AND period = inperiod
                      AND end_customer_id NOT IN (
                             SELECT end_customer_id
                               FROM pnl2_upl002_bad_debt
                              WHERE period = inperiod
                                AND profit_center =
                                                pnl3_trx001_copa.profit_center))
               LOOP
                  a_counter := 1;

                  FOR rec2 IN
                     (SELECT   end_customer_id, SUM (amt_twd) amt_twd
                          FROM pnl3_trx001_copa
                         WHERE profit_center = rec1.profit_center
                           AND period = inperiod
                           AND end_customer_id NOT IN (
                                  SELECT end_customer_id
                                    FROM pnl2_upl002_bad_debt
                                   WHERE period = inperiod
                                     AND profit_center =
                                                pnl3_trx001_copa.profit_center)
                        HAVING SUM (amt_twd) <> 0
                      GROUP BY end_customer_id)
                  LOOP
                     a_rate := rec2.amt_twd / rec3.amt_twd;

                     INSERT INTO pnl3_trx005_collect_detail_pn
                                 (company_code, period, profit_center,
                                  end_customer_id,
                                  amt_local,
                                  amt_usd,
                                  amt_twd, SOURCE,
                                  r_kind, area1, area2,
                                  area3, create_date
                                 )
                          VALUES ('1100', inperiod, rec1.profit_center,
                                  rec2.end_customer_id,
                                  ROUND (a_otwd * a_rate, 5),
                                  ROUND (a_ousd * a_rate, 5),
                                  ROUND (a_otwd * a_rate, 5), 'EXPENSE',
                                  rec1.r_kind, rec1.area1, rec1.area2,
                                  rec1.area3, SYSDATE
                                 );

                     COMMIT;
                  END LOOP;
               END LOOP;

               IF a_counter = 0
               --表示找不到,可能為原因只有一個就是只有一個END CUSTOMER.,其他還輯不可能出現
               THEN
                  FOR rec2 IN (SELECT end_customer_id, rate
                                 FROM pnl3_map001_customer_rate
                                WHERE r_kind = rec1.r_kind
                                  AND area1 = rec1.area1
                                  AND area2 = rec1.area2
                                  AND area3 = rec1.area3
                                  AND period = inperiod
                                  AND profit_center = rec1.profit_center
                                  AND rate <> 0)
                  LOOP
                     a_counter := 1;

                     INSERT INTO pnl3_trx005_collect_detail_pn
                                 (company_code, period, profit_center,
                                  end_customer_id,
                                  amt_local,
                                  amt_usd,
                                  amt_twd, SOURCE,
                                  r_kind, area1, area2,
                                  area3, create_date
                                 )
                          VALUES ('1100', inperiod, rec1.profit_center,
                                  rec2.end_customer_id,
                                  ROUND (a_otwd * rec2.rate, 5),
                                  ROUND (a_ousd * rec2.rate, 5),
                                  ROUND (a_otwd * rec2.rate, 5), 'EXPENSE',
                                  rec1.r_kind, rec1.area1, rec1.area2,
                                  rec1.area3, SYSDATE
                                 );

                     COMMIT;
                  END LOOP;
               END IF;
            ELSE                                           ---不是屬於28,32,33
               FOR rec3 IN
                  (SELECT SUM (headcount) headcount
                     FROM pnl2_upl006_headcount
                    WHERE profit_center = rec1.profit_center
                      AND period = inperiod
                      AND CATEGORY <> 'RD'
                      AND end_customer_id NOT IN (
                             SELECT end_customer_id
                               FROM pnl2_upl002_bad_debt
                              WHERE period = inperiod
                                AND profit_center =
                                           pnl2_upl006_headcount.profit_center))
               LOOP
                  a_counter := 1;

                  FOR rec2 IN
                     (SELECT   end_customer_id, SUM (headcount) headcount
                          FROM pnl2_upl006_headcount
                         WHERE profit_center = rec1.profit_center
                           AND period = inperiod
                           AND CATEGORY <> 'RD'
                           AND end_customer_id NOT IN (
                                  SELECT end_customer_id
                                    FROM pnl2_upl002_bad_debt
                                   WHERE period = inperiod
                                     AND profit_center =
                                            pnl2_upl006_headcount.profit_center)
                        HAVING SUM (headcount) <> 0
                      GROUP BY end_customer_id)
                  LOOP
                     a_rate := rec2.headcount / rec3.headcount;

                     INSERT INTO pnl3_trx005_collect_detail_pn
                                 (company_code, period, profit_center,
                                  end_customer_id,
                                  amt_local,
                                  amt_usd,
                                  amt_twd, SOURCE,
                                  r_kind, area1, area2,
                                  area3, create_date
                                 )
                          VALUES ('1100', inperiod, rec1.profit_center,
                                  rec2.end_customer_id,
                                  ROUND (a_otwd * a_rate, 5),
                                  ROUND (a_ousd * a_rate, 5),
                                  ROUND (a_otwd * a_rate, 5), 'EXPENSE',
                                  rec1.r_kind, rec1.area1, rec1.area2,
                                  rec1.area3, SYSDATE
                                 );

                     COMMIT;
                  END LOOP;
               END LOOP;

               IF a_counter = 0
               --表示找不到,可能為原因只有一個就是只有一個END CUSTOMER.,其他還輯不可能出現
               THEN
                  FOR rec2 IN (SELECT end_customer_id, rate
                                 FROM pnl3_map003_expense_pc_ratio
                                WHERE r_kind = rec1.r_kind
                                  AND area1 = rec1.area1
                                  AND area2 = rec1.area2
                                  AND area3 = rec1.area3
                                  AND period = inperiod
                                  AND profit_center = rec1.profit_center
                                  AND rate <> 0)
                  LOOP
                     a_counter := 1;

                     INSERT INTO pnl3_trx005_collect_detail_pn
                                 (company_code, period, profit_center,
                                  end_customer_id,
                                  amt_local,
                                  amt_usd,
                                  amt_twd, SOURCE,
                                  r_kind, area1, area2,
                                  area3, create_date
                                 )
                          VALUES ('1100', inperiod, rec1.profit_center,
                                  rec2.end_customer_id,
                                  ROUND (a_otwd * rec2.rate, 5),
                                  ROUND (a_ousd * rec2.rate, 5),
                                  ROUND (a_otwd * rec2.rate, 5), 'EXPENSE',
                                  rec1.r_kind, rec1.area1, rec1.area2,
                                  rec1.area3, SYSDATE
                                 );

                     COMMIT;
                  END LOOP;
               END IF;
            END IF;
            END IF;
         END IF;
      END IF;
   END LOOP;
    */
   ---------------------------------呆帳處理結束

   --After Service扣掉上傳處理開始,沒有SITE的觀念---
   a_amount := 0;

   FOR rec1 IN (SELECT   profit_center, r_kind, area1, area2, area3,
                         NVL (SUM (amount), 0) * 1000 AS amt_twd,
                         NVL (SUM (amount_usd), 0) * 1000 AS amt_usd
                    FROM pnl_msa001_em_data a, pnl2_map002_em_pnl_class b
                   WHERE yyyy = a_year
                     AND MONTH = a_month
                     AND type_2 = 'Actual'
                     --AND a.profit_center = '0000000011'
                     AND a.acct_id = b.acct_id
                     AND r_kind = 'PL01'
                     AND area1 = '4'
                     AND area2 = '1'
                     AND area3 = '2'
                     --and area2 = '1'
                     --and area3 = '6'
                     AND SYSDATE BETWEEN start_date AND end_date
                GROUP BY profit_center, r_kind, area1, area2, area3)
   LOOP
      IF SUBSTR (rec1.profit_center, 1, 1) = 'G'
      THEN
         a_counter := 0;
      ELSIF    rec1.profit_center = '0000000034'
            OR SUBSTR (rec1.profit_center, 1, 9) = '000000009'
      THEN
         a_usd := 0;
         a_twd := 0;
         a_ousd := rec1.amt_usd;
         a_otwd := rec1.amt_twd;
      ELSE
         a_usd := 0;
         a_twd := 0;
         a_ousd := rec1.amt_usd;
         a_otwd := rec1.amt_twd;

         BEGIN
            SELECT NVL (SUM (amount_usd), 0), NVL (SUM (amount_twd), 0)
              INTO a_usd, a_twd
              FROM pnl2_upl009_afterservice
             WHERE period = inperiod AND profit_center = rec1.profit_center;
         --AND company_code = rec1.company_code;
         EXCEPTION
            WHEN OTHERS
            THEN
               a_usd := 0;
               a_twd := 0;
         END;

         IF a_twd <> 0
         THEN
            IF a_otwd > 0
            THEN                                 --原本呆帳討到錢了,所以變正,
               IF a_twd <> 0
               THEN
                  a_otwd := a_twd + a_otwd;
                  a_ousd := a_usd + a_ousd;
               END IF;
            ELSE
               a_otwd := a_otwd * -1;
               a_ousd := a_ousd * -1;

--該profit center在RD/SALES的Directly 大項裡只有材料費/佣金一個科目,且金額都給upload上來的customer,所以不用再分了
               IF a_twd <> 0
               THEN
                  IF a_otwd < a_twd
                  THEN                            --差異金額要補回,所以不用-1
                     a_otwd := a_twd - a_otwd;
                     a_ousd := a_usd - a_ousd;
                  ELSIF a_otwd = a_twd
                  THEN
                     a_otwd := 0;
                     a_ousd := 0;
                  ELSE                                    --上傳金額小於EM金額
                     a_otwd := (a_otwd - a_twd) * -1;
                     a_ousd := (a_ousd - a_usd) * -1;
                  END IF;
               ELSE
                  a_otwd := a_otwd * -1;
                  a_ousd := a_ousd * -1;
               END IF;
            END IF;

            IF a_otwd <> 0 and abs(a_otwd) > 100 --金額差異超過100元的才要計算
            THEN
               a_counter := 0;

               IF (   rec1.profit_center = '0000000028'
                   OR rec1.profit_center = '0000000032'
                   OR rec1.profit_center = '0000000033'
                  )
               THEN
                  FOR rec3 IN
                     (SELECT SUM (amt_twd) amt_twd
                        FROM pnl3_trx001_copa
                       WHERE profit_center = rec1.profit_center
                         AND period = inperiod
                         AND end_customer_id NOT IN (
                                SELECT end_customer_id
                                  FROM pnl2_upl009_afterservice
                                 WHERE period = inperiod
                                   AND profit_center =
                                                pnl3_trx001_copa.profit_center))
                  LOOP


                     FOR rec2 IN
                        (SELECT   end_customer_id, SUM (amt_twd) amt_twd
                             FROM pnl3_trx001_copa
                            WHERE profit_center = rec1.profit_center
                              AND period = inperiod
                              AND end_customer_id NOT IN (
                                     SELECT end_customer_id
                                       FROM pnl2_upl009_afterservice
                                      WHERE period = inperiod
                                        AND profit_center =
                                                pnl3_trx001_copa.profit_center)
                           HAVING SUM (amt_twd) <> 0
                         GROUP BY end_customer_id)
                     LOOP

                        a_counter := 1;
                        a_rate := rec2.amt_twd / rec3.amt_twd;

                        INSERT INTO pnl3_trx005_collect_detail_pn
                                    (company_code, period, profit_center,
                                     end_customer_id,
                                     amt_local,
                                     amt_usd,
                                     amt_twd, SOURCE,
                                     r_kind, area1, area2,
                                     area3, create_date
                                    )
                             VALUES ('1100', inperiod, rec1.profit_center,
                                     rec2.end_customer_id,
                                     ROUND (a_otwd * a_rate, 5),
                                     ROUND (a_ousd * a_rate, 5),
                                     ROUND (a_otwd * a_rate, 5), 'EXPENSE',
                                     rec1.r_kind, rec1.area1, rec1.area2,
                                     rec1.area3, SYSDATE
                                    );

                        COMMIT;
                     END LOOP;
                  END LOOP;

                  IF a_counter = 0
                  --表示找不到,可能為原因只有一個就是只有一個END CUSTOMER.,其他還輯不可能出現
                  THEN
                     FOR rec2 IN (SELECT end_customer_id, rate
                                    FROM pnl3_map001_customer_rate
                                   WHERE r_kind = rec1.r_kind
                                     AND area1 = rec1.area1
                                     AND area2 = rec1.area2
                                     AND area3 = rec1.area3
                                     AND period = inperiod
                                     AND profit_center = rec1.profit_center
                                     AND rate <> 0)
                     LOOP
                        a_counter := 1;

                        INSERT INTO pnl3_trx005_collect_detail_pn
                                    (company_code, period, profit_center,
                                     end_customer_id,
                                     amt_local,
                                     amt_usd,
                                     amt_twd,
                                     SOURCE, r_kind, area1,
                                     area2, area3, create_date
                                    )
                             VALUES ('1100', inperiod, rec1.profit_center,
                                     rec2.end_customer_id,
                                     ROUND (a_otwd * rec2.rate, 5),
                                     ROUND (a_ousd * rec2.rate, 5),
                                     ROUND (a_otwd * rec2.rate, 5),
                                     'EXPENSE', rec1.r_kind, rec1.area1,
                                     rec1.area2, rec1.area3, SYSDATE
                                    );

                        COMMIT;
                     END LOOP;
                  END IF;

                  IF a_counter = 0
                  --表示找不到,2009/3/11邏輯,金額歸給空白的end customer
                  THEN

                        a_counter := 1;

                        INSERT INTO pnl3_trx005_collect_detail_pn
                                    (company_code, period, profit_center,
                                     end_customer_id,
                                     amt_local,
                                     amt_usd,
                                     amt_twd,
                                     SOURCE, r_kind, area1,
                                     area2, area3, create_date
                                    )
                             VALUES ('1100', inperiod, rec1.profit_center,
                                     null,
                                     ROUND (a_otwd , 5),
                                     ROUND (a_ousd , 5),
                                     ROUND (a_otwd , 5),
                                     'EXPENSE', rec1.r_kind, rec1.area1,
                                     rec1.area2, rec1.area3, SYSDATE
                                    );

                        COMMIT;

                  END IF;

               ELSE                                        ---不是屬於28,32,33
                  FOR rec3 IN
                     (SELECT SUM (headcount) headcount
                        FROM pnl2_upl006_headcount
                       WHERE profit_center = rec1.profit_center
                         AND period = inperiod
                         AND CATEGORY <> 'RD'
                         AND end_customer_id NOT IN (
                                SELECT end_customer_id
                                  FROM pnl2_upl009_afterservice
                                 WHERE period = inperiod
                                   AND profit_center =
                                           pnl2_upl006_headcount.profit_center))
                  LOOP


                     FOR rec2 IN
                        (SELECT   end_customer_id, SUM (headcount) headcount
                             FROM pnl2_upl006_headcount
                            WHERE profit_center = rec1.profit_center
                              AND period = inperiod
                              AND CATEGORY <> 'RD'
                              AND end_customer_id NOT IN (
                                     SELECT end_customer_id
                                       FROM pnl2_upl009_afterservice
                                      WHERE period = inperiod
                                        AND profit_center =
                                               pnl2_upl006_headcount.profit_center)
                           HAVING SUM (headcount) <> 0
                         GROUP BY end_customer_id)
                     LOOP
                        a_counter := 1;
                        a_rate := rec2.headcount / rec3.headcount;

                        INSERT INTO pnl3_trx005_collect_detail_pn
                                    (company_code, period, profit_center,
                                     end_customer_id,
                                     amt_local,
                                     amt_usd,
                                     amt_twd, SOURCE,
                                     r_kind, area1, area2,
                                     area3, create_date
                                    )
                             VALUES ('1100', inperiod, rec1.profit_center,
                                     rec2.end_customer_id,
                                     ROUND (a_otwd * a_rate, 5),
                                     ROUND (a_ousd * a_rate, 5),
                                     ROUND (a_otwd * a_rate, 5), 'EXPENSE',
                                     rec1.r_kind, rec1.area1, rec1.area2,
                                     rec1.area3, SYSDATE
                                    );

                        COMMIT;
                     END LOOP;
                  END LOOP;

                  IF a_counter = 0
                  --表示找不到,可能為原因只有一個就是只有一個END CUSTOMER.,其他還輯不可能出現
                  THEN
                     FOR rec2 IN (SELECT end_customer_id, rate
                                    FROM pnl3_map003_expense_pc_ratio
                                   WHERE r_kind = rec1.r_kind
                                     AND area1 = rec1.area1
                                     AND area2 = rec1.area2
                                     AND area3 = rec1.area3
                                     AND period = inperiod
                                     AND profit_center = rec1.profit_center
                                     AND rate <> 0)
                     LOOP
                        a_counter := 1;

                        INSERT INTO pnl3_trx005_collect_detail_pn
                                    (company_code, period, profit_center,
                                     end_customer_id,
                                     amt_local,
                                     amt_usd,
                                     amt_twd,
                                     SOURCE, r_kind, area1,
                                     area2, area3, create_date
                                    )
                             VALUES ('1100', inperiod, rec1.profit_center,
                                     rec2.end_customer_id,
                                     ROUND (a_otwd * rec2.rate, 5),
                                     ROUND (a_ousd * rec2.rate, 5),
                                     ROUND (a_otwd * rec2.rate, 5),
                                     'EXPENSE', rec1.r_kind, rec1.area1,
                                     rec1.area2, rec1.area3, SYSDATE
                                    );

                        COMMIT;
                     END LOOP;
                  END IF;

                  IF a_counter = 0
                  --表示找不到,2009/3/11邏輯,金額歸給空白的end customer
                  THEN

                        a_counter := 1;

                        INSERT INTO pnl3_trx005_collect_detail_pn
                                    (company_code, period, profit_center,
                                     end_customer_id,
                                     amt_local,
                                     amt_usd,
                                     amt_twd,
                                     SOURCE, r_kind, area1,
                                     area2, area3, create_date
                                    )
                             VALUES ('1100', inperiod, rec1.profit_center,
                                     null,
                                     ROUND (a_otwd , 5),
                                     ROUND (a_ousd , 5),
                                     ROUND (a_otwd , 5),
                                     'EXPENSE', rec1.r_kind, rec1.area1,
                                     rec1.area2, rec1.area3, SYSDATE
                                    );

                        COMMIT;

                  END IF;

               END IF;
            END IF;
         END IF;
      END IF;
   END LOOP;

   ---------------------------------After Service處理結束

  --BG ALLOCATE扣掉上傳處理開始,沒有SITE的觀念---
   --特殊邏輯:即使該customer已有上傳金額,但仍要納入計算,(因為這塊有含薪資...等費用)
   a_amount := 0;

   FOR rec1 IN (SELECT   profit_center, r_kind, area1, area2, area3,
                         NVL (SUM (amount), 0) * 1000 AS amt_twd,
                         NVL (SUM (amount_usd), 0) * 1000 AS amt_usd
                    FROM pnl_msa001_em_data a, pnl2_map002_em_pnl_class b
                   WHERE yyyy = a_year
                     AND MONTH = a_month
                     AND type_2 = 'Actual'
                     --AND a.profit_center = '0000000011'
                     AND a.acct_id = b.acct_id
                     AND r_kind = 'PL01'
                     AND area1 = '4'
                     AND area2 = '1'
                     AND area3 = '6'
                     --and area2 = '1'
                     --and area3 = '6'
                     AND SYSDATE BETWEEN start_date AND end_date
                GROUP BY profit_center, r_kind, area1, area2, area3)
   LOOP
      IF SUBSTR (rec1.profit_center, 1, 1) = 'G'
      THEN
         a_counter := 0;
      ELSIF    rec1.profit_center = '0000000034'
            OR SUBSTR (rec1.profit_center, 1, 9) = '000000009'
      THEN
         a_usd := 0;
         a_twd := 0;
         a_ousd := rec1.amt_usd;
         a_otwd := rec1.amt_twd;
      ELSE
         a_usd := 0;
         a_twd := 0;
         a_ousd := rec1.amt_usd;
         a_otwd := rec1.amt_twd;

         BEGIN
            SELECT NVL (SUM (amount_usd), 0), NVL (SUM (amount_twd), 0)
              INTO a_usd, a_twd
              FROM pnl2_upl011_salesbg
             WHERE period = inperiod AND profit_center = rec1.profit_center;
         --AND company_code = rec1.company_code;
         EXCEPTION
            WHEN OTHERS
            THEN
               a_usd := 0;
               a_twd := 0;
         END;

         IF a_twd <> 0
         THEN
            IF a_otwd > 0
            THEN                                 --原本呆帳討到錢了,所以變正,
               IF a_twd <> 0
               THEN
                  a_otwd := a_twd + a_otwd;
                  a_ousd := a_usd + a_ousd;
               END IF;
            ELSE
               a_otwd := a_otwd * -1;
               a_ousd := a_ousd * -1;

--該profit center在RD/SALES的Directly 大項裡只有材料費/佣金一個科目,且金額都給upload上來的customer,所以不用再分了
               IF a_twd <> 0
               THEN
                  IF a_otwd < a_twd
                  THEN                            --差異金額要補回,所以不用-1
                     a_otwd := a_twd - a_otwd;
                     a_ousd := a_usd - a_ousd;
                  ELSIF a_otwd = a_twd
                  THEN
                     a_otwd := 0;
                     a_ousd := 0;
                  ELSE                                    --上傳金額小於EM金額
                     a_otwd := (a_otwd - a_twd) * -1;
                     a_ousd := (a_ousd - a_usd) * -1;
                  END IF;
               ELSE
                  a_otwd := a_otwd * -1;
                  a_ousd := a_ousd * -1;
               END IF;
            END IF;

            IF a_otwd <> 0 and abs(a_otwd) > 100 --金額差異超過100元的才要計算
            THEN
               a_counter := 0;

               IF (   rec1.profit_center = '0000000028'
                   OR rec1.profit_center = '0000000032'
                   OR rec1.profit_center = '0000000033'
                  )
               THEN
                  FOR rec3 IN
                     (SELECT SUM (amt_twd) amt_twd
                        FROM pnl3_trx001_copa
                       WHERE profit_center = rec1.profit_center
                         AND period = inperiod)
                  LOOP


                     FOR rec2 IN
                        (SELECT   end_customer_id, SUM (amt_twd) amt_twd
                             FROM pnl3_trx001_copa
                            WHERE profit_center = rec1.profit_center
                              AND period = inperiod
                           HAVING SUM (amt_twd) <> 0
                         GROUP BY end_customer_id)
                     LOOP
                        a_counter := 1;
                        a_rate := rec2.amt_twd / rec3.amt_twd;

                        INSERT INTO pnl3_trx005_collect_detail_pn
                                    (company_code, period, profit_center,
                                     end_customer_id,
                                     amt_local,
                                     amt_usd,
                                     amt_twd, SOURCE,
                                     r_kind, area1, area2,
                                     area3, create_date
                                    )
                             VALUES ('1100', inperiod, rec1.profit_center,
                                     rec2.end_customer_id,
                                     ROUND (a_otwd * a_rate, 5),
                                     ROUND (a_ousd * a_rate, 5),
                                     ROUND (a_otwd * a_rate, 5), 'EXPENSE',
                                     rec1.r_kind, rec1.area1, rec1.area2,
                                     rec1.area3, SYSDATE
                                    );

                        COMMIT;
                     END LOOP;
                  END LOOP;

                  IF a_counter = 0
                  --表示找不到,可能為原因只有一個就是只有一個END CUSTOMER.,其他還輯不可能出現
                  THEN
                     FOR rec2 IN (SELECT end_customer_id, rate
                                    FROM pnl3_map001_customer_rate
                                   WHERE r_kind = rec1.r_kind
                                     AND area1 = rec1.area1
                                     AND area2 = rec1.area2
                                     AND area3 = rec1.area3
                                     AND period = inperiod
                                     AND profit_center = rec1.profit_center
                                     AND rate <> 0)
                     LOOP
                        a_counter := 1;

                        INSERT INTO pnl3_trx005_collect_detail_pn
                                    (company_code, period, profit_center,
                                     end_customer_id,
                                     amt_local,
                                     amt_usd,
                                     amt_twd,
                                     SOURCE, r_kind, area1,
                                     area2, area3, create_date
                                    )
                             VALUES ('1100', inperiod, rec1.profit_center,
                                     rec2.end_customer_id,
                                     ROUND (a_otwd * rec2.rate, 5),
                                     ROUND (a_ousd * rec2.rate, 5),
                                     ROUND (a_otwd * rec2.rate, 5),
                                     'EXPENSE', rec1.r_kind, rec1.area1,
                                     rec1.area2, rec1.area3, SYSDATE
                                    );

                        COMMIT;
                     END LOOP;
                  END IF;

                  IF a_counter = 0
                  --表示找不到,2009/3/11邏輯,金額歸給空白的end customer
                  THEN

                        a_counter := 1;

                        INSERT INTO pnl3_trx005_collect_detail_pn
                                    (company_code, period, profit_center,
                                     end_customer_id,
                                     amt_local,
                                     amt_usd,
                                     amt_twd,
                                     SOURCE, r_kind, area1,
                                     area2, area3, create_date
                                    )
                             VALUES ('1100', inperiod, rec1.profit_center,
                                     null,
                                     ROUND (a_otwd , 5),
                                     ROUND (a_ousd , 5),
                                     ROUND (a_otwd , 5),
                                     'EXPENSE', rec1.r_kind, rec1.area1,
                                     rec1.area2, rec1.area3, SYSDATE
                                    );

                        COMMIT;

                  END IF;

               ELSE                                        ---不是屬於28,32,33
                  FOR rec3 IN
                     (SELECT SUM (headcount) headcount
                        FROM pnl2_upl006_headcount
                       WHERE profit_center = rec1.profit_center
                         AND period = inperiod
                         AND CATEGORY <> 'RD')
                  LOOP


                     FOR rec2 IN
                        (SELECT   end_customer_id, SUM (headcount) headcount
                             FROM pnl2_upl006_headcount
                            WHERE profit_center = rec1.profit_center
                              AND period = inperiod
                              AND CATEGORY <> 'RD'
                           HAVING SUM (headcount) <> 0
                         GROUP BY end_customer_id)
                     LOOP
                        a_counter := 1;
                        a_rate := rec2.headcount / rec3.headcount;

                        INSERT INTO pnl3_trx005_collect_detail_pn
                                    (company_code, period, profit_center,
                                     end_customer_id,
                                     amt_local,
                                     amt_usd,
                                     amt_twd, SOURCE,
                                     r_kind, area1, area2,
                                     area3, create_date
                                    )
                             VALUES ('1100', inperiod, rec1.profit_center,
                                     rec2.end_customer_id,
                                     ROUND (a_otwd * a_rate, 5),
                                     ROUND (a_ousd * a_rate, 5),
                                     ROUND (a_otwd * a_rate, 5), 'EXPENSE',
                                     rec1.r_kind, rec1.area1, rec1.area2,
                                     rec1.area3, SYSDATE
                                    );

                        COMMIT;
                     END LOOP;
                  END LOOP;

                  IF a_counter = 0
                  --表示找不到,可能為原因只有一個就是只有一個END CUSTOMER.,其他還輯不可能出現
                  THEN
                     FOR rec2 IN (SELECT end_customer_id, rate
                                    FROM pnl3_map003_expense_pc_ratio
                                   WHERE r_kind = rec1.r_kind
                                     AND area1 = rec1.area1
                                     AND area2 = rec1.area2
                                     AND area3 = rec1.area3
                                     AND period = inperiod
                                     AND profit_center = rec1.profit_center
                                     AND rate <> 0)
                     LOOP
                        a_counter := 1;

                        INSERT INTO pnl3_trx005_collect_detail_pn
                                    (company_code, period, profit_center,
                                     end_customer_id,
                                     amt_local,
                                     amt_usd,
                                     amt_twd,
                                     SOURCE, r_kind, area1,
                                     area2, area3, create_date
                                    )
                             VALUES ('1100', inperiod, rec1.profit_center,
                                     rec2.end_customer_id,
                                     ROUND (a_otwd * rec2.rate, 5),
                                     ROUND (a_ousd * rec2.rate, 5),
                                     ROUND (a_otwd * rec2.rate, 5),
                                     'EXPENSE', rec1.r_kind, rec1.area1,
                                     rec1.area2, rec1.area3, SYSDATE
                                    );

                        COMMIT;
                     END LOOP;
                  END IF;

                  IF a_counter = 0
                  --表示找不到,2009/3/11邏輯,金額歸給空白的end customer
                  THEN

                        a_counter := 1;

                        INSERT INTO pnl3_trx005_collect_detail_pn
                                    (company_code, period, profit_center,
                                     end_customer_id,
                                     amt_local,
                                     amt_usd,
                                     amt_twd,
                                     SOURCE, r_kind, area1,
                                     area2, area3, create_date
                                    )
                             VALUES ('1100', inperiod, rec1.profit_center,
                                     null,
                                     ROUND (a_otwd , 5),
                                     ROUND (a_ousd , 5),
                                     ROUND (a_otwd , 5),
                                     'EXPENSE', rec1.r_kind, rec1.area1,
                                     rec1.area2, rec1.area3, SYSDATE
                                    );

                        COMMIT;

                  END IF;

               END IF;
            END IF;
         END IF;
      END IF;
   END LOOP;

   ---------------------------------BG ALLOCATE處理結束



   --Corporation ALLOCATE扣掉上傳處理開始,沒有SITE的觀念---
   --特殊邏輯:即使該customer已有上傳金額,但仍要納入計算,(因為這塊有含薪資...等費用)
   a_amount := 0;

   FOR rec1 IN (SELECT   profit_center, r_kind, area1, area2, area3,
                         NVL (SUM (amount), 0) * 1000 AS amt_twd,
                         NVL (SUM (amount_usd), 0) * 1000 AS amt_usd
                    FROM pnl_msa001_em_data a, pnl2_map002_em_pnl_class b
                   WHERE yyyy = a_year
                     AND MONTH = a_month
                     AND type_2 = 'Actual'
                     --AND a.profit_center = '0000000011'
                     AND a.acct_id = b.acct_id
                     AND r_kind = 'PL01'
                     AND area1 = '4'
                     AND area2 = '1'
                     AND area3 = '7'
                     --and area2 = '1'
                     --and area3 = '6'
                     AND SYSDATE BETWEEN start_date AND end_date
                GROUP BY profit_center, r_kind, area1, area2, area3)
   LOOP
      IF SUBSTR (rec1.profit_center, 1, 1) = 'G'
      THEN
         a_counter := 0;
      ELSIF    rec1.profit_center = '0000000034'
            OR SUBSTR (rec1.profit_center, 1, 9) = '000000009'
      THEN
         a_usd := 0;
         a_twd := 0;
         a_ousd := rec1.amt_usd;
         a_otwd := rec1.amt_twd;
      ELSE
         a_usd := 0;
         a_twd := 0;
         a_ousd := rec1.amt_usd;
         a_otwd := rec1.amt_twd;

         BEGIN
            SELECT NVL (SUM (amount_usd), 0), NVL (SUM (amount_twd), 0)
              INTO a_usd, a_twd
              FROM pnl2_upl012_salescorp
             WHERE period = inperiod AND profit_center = rec1.profit_center;
         --AND company_code = rec1.company_code;
         EXCEPTION
            WHEN OTHERS
            THEN
               a_usd := 0;
               a_twd := 0;
         END;

         IF a_twd <> 0
         THEN
            IF a_otwd > 0
            THEN                                 --原本呆帳討到錢了,所以變正,
               IF a_twd <> 0
               THEN
                  a_otwd := a_twd + a_otwd;
                  a_ousd := a_usd + a_ousd;
               END IF;
            ELSE
               a_otwd := a_otwd * -1;
               a_ousd := a_ousd * -1;

--該profit center在RD/SALES的Directly 大項裡只有材料費/佣金一個科目,且金額都給upload上來的customer,所以不用再分了
               IF a_twd <> 0
               THEN
                  IF a_otwd < a_twd
                  THEN                            --差異金額要補回,所以不用-1
                     a_otwd := a_twd - a_otwd;
                     a_ousd := a_usd - a_ousd;
                  ELSIF a_otwd = a_twd
                  THEN
                     a_otwd := 0;
                     a_ousd := 0;
                  ELSE                                    --上傳金額小於EM金額
                     a_otwd := (a_otwd - a_twd) * -1;
                     a_ousd := (a_ousd - a_usd) * -1;
                  END IF;
               ELSE
                  a_otwd := a_otwd * -1;
                  a_ousd := a_ousd * -1;
               END IF;
            END IF;

            IF a_otwd <> 0 and abs(a_otwd) > 100 --金額差異超過100元的才要計算
            THEN
               a_counter := 0;

               IF (   rec1.profit_center = '0000000028'
                   OR rec1.profit_center = '0000000032'
                   OR rec1.profit_center = '0000000033'
                  )
               THEN
                  FOR rec3 IN
                     (SELECT SUM (amt_twd) amt_twd
                        FROM pnl3_trx001_copa
                       WHERE profit_center = rec1.profit_center
                         AND period = inperiod)
                  LOOP


                     FOR rec2 IN
                        (SELECT   end_customer_id, SUM (amt_twd) amt_twd
                             FROM pnl3_trx001_copa
                            WHERE profit_center = rec1.profit_center
                              AND period = inperiod
                           HAVING SUM (amt_twd) <> 0
                         GROUP BY end_customer_id)
                     LOOP
                        a_counter := 1;
                        a_rate := rec2.amt_twd / rec3.amt_twd;

                        INSERT INTO pnl3_trx005_collect_detail_pn
                                    (company_code, period, profit_center,
                                     end_customer_id,
                                     amt_local,
                                     amt_usd,
                                     amt_twd, SOURCE,
                                     r_kind, area1, area2,
                                     area3, create_date
                                    )
                             VALUES ('1100', inperiod, rec1.profit_center,
                                     rec2.end_customer_id,
                                     ROUND (a_otwd * a_rate, 5),
                                     ROUND (a_ousd * a_rate, 5),
                                     ROUND (a_otwd * a_rate, 5), 'EXPENSE',
                                     rec1.r_kind, rec1.area1, rec1.area2,
                                     rec1.area3, SYSDATE
                                    );

                        COMMIT;
                     END LOOP;
                  END LOOP;

                  IF a_counter = 0
                  --表示找不到,可能為原因只有一個就是只有一個END CUSTOMER.,其他還輯不可能出現
                  THEN
                     FOR rec2 IN (SELECT end_customer_id, rate
                                    FROM pnl3_map001_customer_rate
                                   WHERE r_kind = rec1.r_kind
                                     AND area1 = rec1.area1
                                     AND area2 = rec1.area2
                                     AND area3 = rec1.area3
                                     AND period = inperiod
                                     AND profit_center = rec1.profit_center
                                     AND rate <> 0)
                     LOOP
                        a_counter := 1;

                        INSERT INTO pnl3_trx005_collect_detail_pn
                                    (company_code, period, profit_center,
                                     end_customer_id,
                                     amt_local,
                                     amt_usd,
                                     amt_twd,
                                     SOURCE, r_kind, area1,
                                     area2, area3, create_date
                                    )
                             VALUES ('1100', inperiod, rec1.profit_center,
                                     rec2.end_customer_id,
                                     ROUND (a_otwd * rec2.rate, 5),
                                     ROUND (a_ousd * rec2.rate, 5),
                                     ROUND (a_otwd * rec2.rate, 5),
                                     'EXPENSE', rec1.r_kind, rec1.area1,
                                     rec1.area2, rec1.area3, SYSDATE
                                    );

                        COMMIT;
                     END LOOP;
                  END IF;

                  IF a_counter = 0
                  --表示找不到,2009/3/11邏輯,金額歸給空白的end customer
                  THEN

                        a_counter := 1;

                        INSERT INTO pnl3_trx005_collect_detail_pn
                                    (company_code, period, profit_center,
                                     end_customer_id,
                                     amt_local,
                                     amt_usd,
                                     amt_twd,
                                     SOURCE, r_kind, area1,
                                     area2, area3, create_date
                                    )
                             VALUES ('1100', inperiod, rec1.profit_center,
                                     null,
                                     ROUND (a_otwd , 5),
                                     ROUND (a_ousd , 5),
                                     ROUND (a_otwd , 5),
                                     'EXPENSE', rec1.r_kind, rec1.area1,
                                     rec1.area2, rec1.area3, SYSDATE
                                    );

                        COMMIT;

                  END IF;

               ELSE                                        ---不是屬於28,32,33
                  FOR rec3 IN
                     (SELECT SUM (headcount) headcount
                        FROM pnl2_upl006_headcount
                       WHERE profit_center = rec1.profit_center
                         AND period = inperiod
                         AND CATEGORY <> 'RD')
                  LOOP


                     FOR rec2 IN
                        (SELECT   end_customer_id, SUM (headcount) headcount
                             FROM pnl2_upl006_headcount
                            WHERE profit_center = rec1.profit_center
                              AND period = inperiod
                              AND CATEGORY <> 'RD'
                           HAVING SUM (headcount) <> 0
                         GROUP BY end_customer_id)
                     LOOP
                        a_counter := 1;
                        a_rate := rec2.headcount / rec3.headcount;

                        INSERT INTO pnl3_trx005_collect_detail_pn
                                    (company_code, period, profit_center,
                                     end_customer_id,
                                     amt_local,
                                     amt_usd,
                                     amt_twd, SOURCE,
                                     r_kind, area1, area2,
                                     area3, create_date
                                    )
                             VALUES ('1100', inperiod, rec1.profit_center,
                                     rec2.end_customer_id,
                                     ROUND (a_otwd * a_rate, 5),
                                     ROUND (a_ousd * a_rate, 5),
                                     ROUND (a_otwd * a_rate, 5), 'EXPENSE',
                                     rec1.r_kind, rec1.area1, rec1.area2,
                                     rec1.area3, SYSDATE
                                    );

                        COMMIT;
                     END LOOP;
                  END LOOP;

                  IF a_counter = 0
                  --表示找不到,可能為原因只有一個就是只有一個END CUSTOMER.,其他還輯不可能出現
                  THEN
                     FOR rec2 IN (SELECT end_customer_id, rate
                                    FROM pnl3_map003_expense_pc_ratio
                                   WHERE r_kind = rec1.r_kind
                                     AND area1 = rec1.area1
                                     AND area2 = rec1.area2
                                     AND area3 = rec1.area3
                                     AND period = inperiod
                                     AND profit_center = rec1.profit_center
                                     AND rate <> 0)
                     LOOP
                        a_counter := 1;

                        INSERT INTO pnl3_trx005_collect_detail_pn
                                    (company_code, period, profit_center,
                                     end_customer_id,
                                     amt_local,
                                     amt_usd,
                                     amt_twd,
                                     SOURCE, r_kind, area1,
                                     area2, area3, create_date
                                    )
                             VALUES ('1100', inperiod, rec1.profit_center,
                                     rec2.end_customer_id,
                                     ROUND (a_otwd * rec2.rate, 5),
                                     ROUND (a_ousd * rec2.rate, 5),
                                     ROUND (a_otwd * rec2.rate, 5),
                                     'EXPENSE', rec1.r_kind, rec1.area1,
                                     rec1.area2, rec1.area3, SYSDATE
                                    );

                        COMMIT;
                     END LOOP;
                  END IF;

                  IF a_counter = 0
                  --表示找不到,2009/3/11邏輯,金額歸給空白的end customer
                  THEN

                        a_counter := 1;

                        INSERT INTO pnl3_trx005_collect_detail_pn
                                    (company_code, period, profit_center,
                                     end_customer_id,
                                     amt_local,
                                     amt_usd,
                                     amt_twd,
                                     SOURCE, r_kind, area1,
                                     area2, area3, create_date
                                    )
                             VALUES ('1100', inperiod, rec1.profit_center,
                                     null,
                                     ROUND (a_otwd , 5),
                                     ROUND (a_ousd , 5),
                                     ROUND (a_otwd , 5),
                                     'EXPENSE', rec1.r_kind, rec1.area1,
                                     rec1.area2, rec1.area3, SYSDATE
                                    );

                        COMMIT;

                  END IF;

               END IF;
            END IF;
         END IF;
      END IF;
   END LOOP;

   ---------------------------------Corporation ALLOCATE處理結束

   ---呆帳處理開始----->
   FOR rec2 IN (SELECT *
                  FROM pnl2_upl002_bad_debt
                 WHERE period = inperiod AND amount_local <> 0)
   LOOP

      INSERT INTO pnl3_trx005_collect_detail_pn
                  (company_code, period, profit_center,
                   end_customer_id, amt_local,
                   amt_usd, amt_twd, SOURCE,
                   r_kind, area1, area2, area3, create_date
                  )
           VALUES (rec2.company_code, inperiod, rec2.profit_center,
                   rec2.end_customer_id, rec2.amount_local * -1,
                   rec2.amount_usd * -1, rec2.amount_twd * -1, 'EXPENSE',
                   'PL01', '4', '1', '3', SYSDATE
                  );

      COMMIT;
   END LOOP;

   ---呆帳處理邏輯結束  <-----

   ---After Service處理開始----->
   FOR rec2 IN (SELECT *
                  FROM pnl2_upl009_afterservice
                 WHERE period = inperiod AND amount_local <> 0)
   LOOP
      INSERT INTO pnl3_trx005_collect_detail_pn
                  (company_code, period, profit_center,
                   end_customer_id, amt_local,
                   amt_usd, amt_twd, SOURCE,
                   r_kind, area1, area2, area3, create_date
                  )
           VALUES (rec2.company_code, inperiod, rec2.profit_center,
                   rec2.end_customer_id, rec2.amount_local * -1,
                   rec2.amount_usd * -1, rec2.amount_twd * -1, 'EXPENSE',
                   'PL01', '4', '1', '2', SYSDATE
                  );

      COMMIT;
   END LOOP;

   ---呆帳處理邏輯結束  <-----

   ---佣金處理開始----->
   FOR rec2 IN (SELECT *
                  FROM pnl2_upl005_commission
                 WHERE period = inperiod AND amount_local <> 0)
   LOOP
      INSERT INTO pnl3_trx005_collect_detail_pn
                  (company_code, period, profit_center,
                   end_customer_id, amt_local,
                   amt_usd, amt_twd, SOURCE,
                   r_kind, area1, area2, area3, create_date
                  )
           VALUES (rec2.company_code, inperiod, rec2.profit_center,
                   rec2.end_customer_id, rec2.amount_local * -1,
                   rec2.amount_usd * -1, rec2.amount_twd * -1, 'EXPENSE',
                   'PL01', '4', '1', '5', SYSDATE
                  );

      COMMIT;
   END LOOP;

   ---佣金處理邏輯結束  <-----

   ---材料費處理開始----->
   FOR rec2 IN (SELECT *
                  FROM pnl2_upl004_rawexpense
                 WHERE period = inperiod AND amount_local <> 0)
   LOOP
      INSERT INTO pnl3_trx005_collect_detail_pn
                  (company_code, period, profit_center,
                   end_customer_id, amt_local,
                   amt_usd, amt_twd, SOURCE,
                   pdm_project, r_kind, area1, area2, area3, create_date
                  )
           VALUES (rec2.company_code, inperiod, rec2.profit_center,
                   rec2.end_customer_id, rec2.amount_local * -1,
                   rec2.amount_usd * -1, rec2.amount_twd * -1, 'EXPENSE',
                   NULL, 'PL01', '4', '3', '2', SYSDATE
                  );

      COMMIT;
   END LOOP;

---材料費處理邏輯結束  <-----

   ---運費處理開始----->
   FOR rec2 IN (SELECT *
                  FROM pnl2_upl008_export
                 WHERE period = inperiod AND amount_local <> 0)
   LOOP
      INSERT INTO pnl3_trx005_collect_detail_pn
                  (company_code, period, profit_center,
                   end_customer_id, amt_local,
                   amt_usd, amt_twd, SOURCE,
                   r_kind, area1, area2, area3, create_date
                  )
           VALUES (rec2.company_code, inperiod, rec2.profit_center,
                   rec2.end_customer_id, rec2.amount_local * -1,
                   rec2.amount_usd * -1, rec2.amount_twd * -1, 'EXPENSE',
                   'PL01', '4', '1', '1', SYSDATE
                  );

      COMMIT;
   END LOOP;
---運費處理邏輯結束  <-----

  ---BG ALLOCATE處理開始----->
   FOR rec2 IN (SELECT *
                  FROM pnl2_upl011_salesbg
                 WHERE period = inperiod AND amount_local <> 0)
   LOOP
      INSERT INTO pnl3_trx005_collect_detail_pn
                  (company_code, period, profit_center,
                   end_customer_id, amt_local,
                   amt_usd, amt_twd, SOURCE,
                   r_kind, area1, area2, area3, create_date
                  )
           VALUES (rec2.company_code, inperiod, rec2.profit_center,
                   rec2.end_customer_id, rec2.amount_local * -1,
                   rec2.amount_usd * -1, rec2.amount_twd * -1, 'EXPENSE',
                   'PL01', '4', '1', '6', SYSDATE
                  );

      COMMIT;
   END LOOP;
   ---BG ALLOCATE處理邏輯結束  <-----

   ---CORPOARTION ALLOCATE處理開始----->
      FOR rec2 IN (SELECT *
                  FROM pnl2_upl012_salescorp
                 WHERE period = inperiod AND amount_local <> 0)
   LOOP
      INSERT INTO pnl3_trx005_collect_detail_pn
                  (company_code, period, profit_center,
                   end_customer_id, amt_local,
                   amt_usd, amt_twd, SOURCE,
                   r_kind, area1, area2, area3, create_date
                  )
           VALUES (rec2.company_code, inperiod, rec2.profit_center,
                   rec2.end_customer_id, rec2.amount_local * -1,
                   rec2.amount_usd * -1, rec2.amount_twd * -1, 'EXPENSE',
                   'PL01', '4', '1', '7', SYSDATE
                  );

      COMMIT;
   END LOOP;
   ---Corporation ALLOCATE處理邏輯結束  <-----

/* 此sql可以查出會計上傳的費用和user上傳的費用,因為有些user上傳的費用會大於會計上傳費用
SELECT PROFIT_CENTER,AREA1,AREA2,AREA3,SUM(amount), SUM(amount_usd),
                  (SELECT SUM(AMOUNT_TWD) FROM PNL2_UPL004_RAWEXPENSE WHERE PROFIT_CENTER = A.PROFIT_CENTER AND PERIOD = '200811') RAWEXPENSE,
                  (SELECT SUM(AMOUNT_TWD) FROM PNL2_UPL005_COMMISSION WHERE PROFIT_CENTER = A.PROFIT_CENTER AND PERIOD = '200811') COMMISSION
                  FROM pnl_msa001_em_data a, pnl2_map002_em_pnl_class b
                 WHERE yyyy = '2008'
                   AND MONTH = '11'
                   AND type_2 = 'Actual'
                   AND a.acct_id = b.acct_id
                   AND profit_center BETWEEN '0000000011' AND '0000000099'
                   AND ((area1 = '4' AND area2 = '1' and area3 = '5') OR (area1 = '4' AND area2 = '1' and area3 = '1') OR (area1 = '4' AND area2 = '3' and area3 = '2'))
                   --and area3 = '6'
                   AND SYSDATE BETWEEN start_date AND end_date
                   GROUP BY PROFIT_CENTER,AREA1,AREA2,AREA3
*/
END pnl3_pls011_expense_map_trx;
/

