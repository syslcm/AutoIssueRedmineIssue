create PROCEDURE PLSQL_PTP_INTEL_WEEKLY_4 (
  outRES OUT VARCHAR2
)
AUTHID DEFINER
is
  --抓LT, MOQ (COMPANY: 1500/1510 )
  CURSOR C_SAP_MATERIAL_PLANT is
    Select A.COMPANY_CODE, A.PART_NO, A.LT, A.MOQ
      From SAP_MATERIAL_PLANT A, PTP_INTEL_WEEKLY_REPORT B
     where A.PART_NO = B.INTEL_PART
       and A.COMPANY_CODE = '1500'
       and ( A.PLANT = '1510' or A.PLANT = '1520' )
     Group by A.COMPANY_CODE, A.PART_NO, A.LT, A.MOQ;

  --抓Open PO Qty 1(不管供應商 - PO_CUTIN_DATE)
  CURSOR C_PTP_INTEL_USI_MANUAL1 is
    Select A.USI_PN, SUM(NVL(B.REQ_QTY,0) - NVL(B.DEL_QTY,0)) as OPEN_PO_QTY
      From PTP_INTEL_USI_MANUAL A, POWEB_DAILY_PO B, PTP_INTEL_CONTROL_PO C
     where A.USI_PN is NOT Null
       and B.PART_NO = A.USI_PN
       and B.COMPANY_CODE in ('1500')
       and C.USI_PN = B.PART_NO
       and TO_DATE(C.SHIP_CUTIN_DATE,'YYYYMMDD') > TO_DATE(B.REQ_DATE,'YYYYMMDD')
       and C.SHIP_CUTIN_DATE is NOT Null
     Group by A.USI_PN;

  --抓Open PO Qty 2(不管供應商 - SHIP_CUTIN_DATE)
  CURSOR C_PTP_INTEL_USI_MANUAL2 is
    Select A.USI_PN, SUM(NVL(B.REQ_QTY,0) - NVL(B.DEL_QTY,0)) as OPEN_PO_QTY
      From PTP_INTEL_USI_MANUAL A, POWEB_DAILY_PO B, PTP_INTEL_CONTROL_PO C
     where A.USI_PN is NOT Null
       and B.PART_NO = A.USI_PN
       and B.COMPANY_CODE in ('1500')
       and C.USI_PN = B.PART_NO
       and TO_DATE(C.PO_CUTIN_DATE,'YYYYMMDD') > TO_DATE(B.POCRE_DATE,'YYYYMMDD')
       and C.PO_CUTIN_DATE is NOT Null
     Group by A.USI_PN;

  --抓Stock
  CURSOR C_EGI0150_END_STORAGELOC is
    Select TRIM(A.MFG_SITE) as MFG_SITE, TRIM(A.MATERIAL) as MATERIAL, SUM(A.UNRESTRICTED_USE) as STOCK
      From EGI0150_END_STORAGELOC A, DCF_CONTROL_STOCK C
     where TRIM(A.MFG_SITE) = '1500'
       and A.PLANT <> '9999'
       and A.MFG_SITE = C.MFG_SITE
       and A.PLANT = C.PLANT
       and A.POST_DATE_YYYY = C.POST_DATE_YYYY
       and A.POST_DATE_MM = C.POST_DATE_MM
	   and Exists (
	         Select B.USI_PN from PTP_INTEL_WEEKLY_REPORT B
			  where TRIM(B.USI_PN) like TRIM(A.MATERIAL) || '%'
			    and B.USI_PN is Not Null
	       )
     Group by TRIM(A.MFG_SITE), TRIM(A.MATERIAL);

  --抓各料號的Description/Mfg/Mfg PN/Material Group...
  CURSOR C_EGI0010_MATL_MASTER is
    Select distinct
           A.USI_PN,
           TRIM(B.DESCRIPTION) as USI_PN_DESCRIPTION,
           TRIM(B.MANUFACTURE_NUMBER) as USI_MFG,
           TRIM(B.MANUFACTURE_PART) as USI_MFG_PN,
           TRIM(B.MATERIAL_GROUP) as MATERIAL_GROUP
      From PTP_INTEL_WEEKLY_REPORT A, EGI0010_MATL_MASTER B
     where TRIM(B.MFG_SITE) in ('1100','1200','1300','1500','2300')
       and TRIM(B.MATERIAL) = A.USI_PN
       and A.USI_PN is NOT NULL
     Group by A.USI_PN, B.DESCRIPTION, B.MANUFACTURE_NUMBER, B.MANUFACTURE_PART, B.MATERIAL_GROUP;

   --算No. (有USI P/N)
  CURSOR C_PTP_INTEL_WEEKLY_REPORT is
    Select INTEL_PART, SUPPLIER,
           USI_PN,
           NVL(USI_VENDOR_CODE,'ZZZZZZZZZZ') as USI_VENDOR
      From PTP_INTEL_WEEKLY_REPORT
     Order by INTEL_PART, SUPPLIER, USI_PN, NVL(USI_VENDOR_CODE,'ZZZZZZZZZZ');

  --抓對不到USI PN的Intel PN
  CURSOR C_PTP_INTEL_CURRENT is
    Select distinct
           B.VERSION, B.COMMODITY, B.COMMODITY_SPECIALIST, B.INTEL_PART, B.INTEL_DESCRIPTION,
           B.SUPPLIER, B.WEIGHTED_COST, B.CONTRACT_PRICE, B.INTEL_ALLOCATION, B.EFFECTIVITY_DATE, B.INTEL_COMMENT
      From PTP_INTEL_CURRENT B
     where NOT EXISTS (
	    Select B.INTEL_PART from PTP_INTEL_WEEKLY_REPORT C
		 where C.INTEL_PART = B.INTEL_PART
		   and C.SUPPLIER = B.SUPPLIER
	  )
     Order by B.INTEL_PART, B.SUPPLIER;

  --處理 RFQ_BOM_USAGE -> 設QTA_FLAG
  CURSOR C_RFQ_BOM_USAGE is
    Select A.COMPONENT_NO
      From RFQ_BOM_USAGE A
     where ( A.PART_NO, A.ALTER_ITEM_GROUP ) in (
             Select B.PART_NO, B.ALTER_ITEM_GROUP
               from RFQ_BOM_USAGE B, PTP_INTEL_WEEKLY_REPORT C
              where C.USI_PN like B.COMPONENT_NO || '%'
                and C.QTA_FLAG = 'Y'
                and C.USI_PN is Not Null
           )
     Group by A.COMPONENT_NO;


   nCOUNT              NUMBER(5);
   nBLOCKED            PTP_INTEL_WEEKLY_REPORT.BLOCKED%TYPE;
   nNO                 PTP_INTEL_WEEKLY_REPORT.NO%TYPE;

 BEGIN
   outRES := 'START';
   --抓LT, MOQ (COMPANY: 1500/1510 )
   nCOUNT := 0;
   FOR REC1 in C_SAP_MATERIAL_PLANT LOOP
     Update PTP_INTEL_WEEKLY_REPORT
        set USI_LT_SH = REC1.LT,
            USI_MOQ_SH = REC1.MOQ
      where INTEL_PART = REC1.PART_NO;
   nCOUNT := nCOUNT + 1;
   If nCOUNT = 100 Then
       Commit;
       nCOUNT := 0;
     End If;
   END LOOP;
   Commit;
   outRES := 'UPDATE C_SAP_MATERIAL_PLANT OK';

   --抓Open PO Qty 1
   nCOUNT := 0;
   FOR REC1 in C_PTP_INTEL_USI_MANUAL1 LOOP
     outRES := 'C_PTP_INTEL_USI_MANUAL1:' || REC1.USI_PN;
     Update PTP_INTEL_WEEKLY_REPORT
        set OPEN_PO_SH = REC1.OPEN_PO_QTY
      where USI_PN = REC1.USI_PN;
     nCOUNT := nCOUNT + 1;
     If nCOUNT = 100 Then
       Commit;
       nCOUNT := 0;
     End If;
   END LOOP;
   Commit;
   outRES := 'UPDATE C_PTP_INTEL_USI_MANUAL1 OK';

   --抓Open PO Qty 2
   nCOUNT := 0;
   FOR REC1 in C_PTP_INTEL_USI_MANUAL2 LOOP
     outRES := 'C_PTP_INTEL_USI_MANUAL2:' || REC1.USI_PN;
     Update PTP_INTEL_WEEKLY_REPORT
        set OPEN_PO_SH = REC1.OPEN_PO_QTY
      where USI_PN = REC1.USI_PN;
     nCOUNT := nCOUNT + 1;
     If nCOUNT = 100 Then
       Commit;
       nCOUNT := 0;
     End If;
   END LOOP;
   Commit;
   outRES := 'UPDATE C_PTP_INTEL_USI_MANUAL2 OK';

   --抓Stock
   nCOUNT := 0;
   FOR REC1 in C_EGI0150_END_STORAGELOC LOOP
     Update PTP_INTEL_WEEKLY_REPORT
        set USI_STOCK_SH = REC1.STOCK
      where USI_PN Like Trim(REC1.MATERIAL) || '%'
        and USI_PN is Not Null;
   nCOUNT := nCOUNT + 1;
   If nCOUNT = 100 Then
       Commit;
       nCOUNT := 0;
     End If;
   END LOOP;
   Commit;
   outRES := 'UPDATE C_EGI0150_END_STORAGELOC OK';

   --抓各料號的Description/Mfg/Mfg PN...
   nCOUNT := 0;
   FOR REC1 in C_EGI0010_MATL_MASTER LOOP
     nBLOCKED := NULL;
     BEGIN
       Select * into nBLOCKED From (
         Select 'X' from SAP_AMPL
          where PART_NO = REC1.USI_PN
            and ( BLOCKED is NOT NULL or DELE_FLAG is NOT NULL )
            and VALID_FROM <= TO_CHAR(SYSDATE,'YYYYMMDD')
            and VALID_TO >= TO_CHAR(SYSDATE,'YYYYMMDD')
       ) Where ROWNUM <= 1;
     EXCEPTION
       WHEN OTHERS THEN
         nBLOCKED := NULL;
     END;
     --PTP_INTEL_WEEKLY_REPORT
     Update PTP_INTEL_WEEKLY_REPORT
        set USI_PN_DESCRIPTION = REC1.USI_PN_DESCRIPTION,
            MATERIAL_GROUP = REC1.MATERIAL_GROUP,
            USI_MFG = REC1.USI_MFG,
            USI_MFG_PN = REC1.USI_MFG_PN,
            BLOCKED = nBLOCKED
      where USI_PN = REC1.USI_PN
        and USI_PN is NOT Null;
   nCOUNT := nCOUNT + 1;
   If nCOUNT = 100 Then
       Commit;
       nCOUNT := 0;
     End If;
   END LOOP;
   Commit;
   outRES := 'UPDATE C_EGI0010_MATL_MASTER OK';

   --算No. (有USI P/N)
   nNO := 0;
   nCOUNT := 0;
   FOR REC1 in C_PTP_INTEL_WEEKLY_REPORT LOOP
     outRES := 'C_PTP_INTEL_WEEKLY_REPORT:' || REC1.INTEL_PART || '<>' || REC1.SUPPLIER || '<>' || REC1.USI_PN || '<>' || REC1.USI_VENDOR;
     nNO := nNO + 1;
     Update PTP_INTEL_WEEKLY_REPORT
        set NO = nNO
      where INTEL_PART = REC1.INTEL_PART
        and SUPPLIER = REC1.SUPPLIER
        and USI_PN = REC1.USI_PN
        and NVL(USI_VENDOR_CODE,'ZZZZZZZZZZ') = REC1.USI_VENDOR;
     If nCOUNT = 100 Then
       Commit;
       nCOUNT := 0;
     End If;
   END LOOP;
   Commit;
   outRES := 'Upd C_PTP_INTEL_WEEKLY_REPORT OK';

   --抓對不到USI PN的Intel PN
   nCOUNT := 0;
   FOR REC1 in C_PTP_INTEL_CURRENT LOOP
     outRES := 'C_PTP_INTEL_CURRENT:' || REC1.INTEL_PART || '<>' || REC1.SUPPLIER;
     nNO := nNO + 1;
     Insert into PTP_INTEL_WEEKLY_REPORT (
                 VERSION, COMMODITY, COMMODITY_SPECIALIST, INTEL_PART, INTEL_DESCRIPTION,
                 SUPPLIER, WEIGHTED_COST, CONTRACT_PRICE, INTEL_ALLOCATION,
                 EFFECTIVITY_DATE, INTEL_COMMENT, NO
               ) values (
                 REC1.VERSION, REC1.COMMODITY, REC1.COMMODITY_SPECIALIST, REC1.INTEL_PART, REC1.INTEL_DESCRIPTION,
                 REC1.SUPPLIER, REC1.WEIGHTED_COST, REC1.CONTRACT_PRICE, REC1.INTEL_ALLOCATION,
                 REC1.EFFECTIVITY_DATE, REC1.INTEL_COMMENT, nNO
               );
     If nCOUNT = 100 Then
       Commit;
       nCOUNT := 0;
     End If;
   END LOOP;
   Commit;
   outRES := 'Upd C_PTP_INTEL_CURRENT OK';

   --處理 RFQ_BOM_USAGE -> 設QTA_FLAG
   nCOUNT := 0;
   FOR REC1 in C_RFQ_BOM_USAGE LOOP
     outRES := 'C_RFQ_BOM_USAGE:' || REC1.COMPONENT_NO;
     Update PTP_INTEL_WEEKLY_REPORT
        set QTA_FLAG = 'Y'
      where USI_PN like REC1.COMPONENT_NO || '%'
        and NVL(QTA_FLAG,'N') = 'N';
     nCOUNT := nCOUNT + 1;
     If nCOUNT = 100 Then
       Commit;
       nCOUNT := 0;
     End If;
   END LOOP;
   Commit;
   outRES := 'UPDATE C_RFQ_BOM_USAGE OK';

   Update PTP_INTEL_WEEKLY_REPORT
      set QTA_FLAG = 'N'
    where QTA_FLAG is Null;
   Commit;

   outRES := 'SUCCESS';
 EXCEPTION
   WHEN OTHERS THEN
     outRES := TRIM(outRES) || ' - ' || TRIM(SUBSTR(SQLERRM,1,100));
     Rollback;
 END PLSQL_PTP_INTEL_WEEKLY_4;
/

