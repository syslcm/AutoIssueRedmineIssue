create view CMO_VEW002_VERSION as
select FCST_VERSION, FCST_YEAR, FCST_WEEK, FCST_DATE, rownum as SN
from (
select distinct *
from CMO_UPL002_VERSION
order by FCST_VERSION asc
)
/

