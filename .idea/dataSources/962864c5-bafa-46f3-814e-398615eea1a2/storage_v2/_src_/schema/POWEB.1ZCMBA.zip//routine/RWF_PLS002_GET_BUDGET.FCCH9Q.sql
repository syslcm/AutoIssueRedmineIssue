create PROCEDURE       RWF_PLS002_GET_BUDGET (
  inCompany  in VARCHAR2,
  f_YYYYMMDD in VARCHAR2,
  t_YYYYMMDD in VARCHAR2
)
AUTHID DEFINER
/*********************************************************************
  PROG-ID      : RWF_PLS002_GET_BUDGET
  PROG-ACTION  : GET BUDGET's SUMMARY REVENUE FROM SQL SERVER TO BIDB
  Author       : KANGI
  Date         : 2007/02/12
**********************************************************************/
/*********************************************************************
  Modify-ACTION  : If PC_ID = 90 , change to 'USI-COMMON'
  Modify Author       : KANGI
  Modify Date         : 2007/03/16
**********************************************************************/
/*********************************************************************
  Modify-ACTION  : Add YYYY to Exchange Rate Table
  Modify Author       : KANGI
  Modify Date         : 2007/09/13
**********************************************************************/
/*********************************************************************
  Modify-ACTION  : 美金(USD) 為基準
                   Add CNY Amount
                   BUDGET BGT_MAS009_EXCH_RATE 改為BGT_MAS019_EXCH_RATE(每月匯率)
  Modify Author       : KANGI
  Modify Date         : 2011/12/29
  OA                  : SAI028442
**********************************************************************/
is
   cCURRENT_PERIOD KPI_SAP001_COPA_TRX.PERIOD%TYPE ;
   dBILLING_END_DATE_BY_MON RWF_SAP002_REVENUE_ACTUAL.BILLING_END_DATE_BY_MON%TYPE;
   iTracePoint  integer ;
   cErrorText varchar2(500) ;
   cRWF_YYYY RWF_SAP002_REVENUE_ACTUAL.RWF_YYYY%TYPE;
 BEGIN
   iTracePoint := 100 ;
   cRWF_YYYY := TO_CHAR(SYSDATE,'YYYY');
   --cRWF_YYYY := '2012' ;
   ----DELETE RWF_ZOT001_REVENUE_BUDGET
   DELETE RWF_ZOT001_REVENUE_BUDGET WHERE RWF_YYYY = cRWF_YYYY;
   iTracePoint := 200 ;
   IF cRWF_YYYY = '2007' THEN
      iTracePoint := 210 ;
      ----INSERT RWF_ZOT001_REVENUE_BUDGET FROM SQLSERVER's BUDGET(BGT_TRN006_REV_N_EXP),PC_ID NOT IN ('12','25')
      INSERT INTO RWF_ZOT001_REVENUE_BUDGET
      SELECT A.YYYY,A.MM,'BUDGET' RWF_TYPE,A.SITE,LPAD(DECODE(A.PC_ID,90,'USI-COMMON',A.PC_ID),10,'0')  PROFIT_CENTER,
             LPAD(A.ALLOC_PC_ID,10,'0') RECEIVE_PROFIT_CENTER ,NULL CUSTOMER_ID,NULL END_CUSTOMER_NAME,A.ALLOC_AMT NET_REVENUE,
             A.ALLOC_AMT*B.TO_USD_RATE NET_REVENUE_USD,A.ALLOC_AMT*B.TO_TWD_RATE NET_REVENUE_TWD,TO_CHAR(SYSDATE,'YYYYMMDD')
           --Add kangi 20111229
            ,A.ALLOC_AMT*B.TO_CNY_RATE NET_REVENUE_CNY
           --End Add kangi 20111229
      --Modify kangi 20111229
      --FROM BGT_TRN006_REV_N_EXP@BUDGET_MSSQL A, BGT_MAS009_EXCH_RATE@BUDGET_MSSQL B Remark kangi 20111229
        FROM BGT_TRN006_REV_N_EXP@BUDGET_MSSQL A, BGT_MAS019_EXCH_RATE@BUDGET_MSSQL B
      --End Modify kangi 20111229
         WHERE  A.GROUP_ID = '01'
           AND A.ALLOC_TYPE = 'Z'
           AND B.FROM_CURRENCY = 'USD'
           AND B.YYYY = cRWF_YYYY
           AND A.ALLOC_AMT <> 0
           AND A.YYYY = cRWF_YYYY
           AND A.PC_ID <> '25'
           AND A.PC_ID <> '12'
         --Add kangi 20111229
           AND A.MM = B.MM
         --End Add kangi 20111229
               ORDER BY A.YYYY,A.MM;


       iTracePoint := 220 ;
       ----INSERT RWF_ZOT001_REVENUE_BUDGET FROM SQLSERVER's BUDGET(TRN001_REV) ,PC_ID IN ('12','25')
       INSERT INTO RWF_ZOT001_REVENUE_BUDGET
       SELECT A.YYYY,A.MM,'BUDGET' RWF_TYPE,A.SITE,
           LPAD(DECODE(A.MG_ID,'526','11','527','11','558','11','560','12','561','12','562','12','542','13','511','25','532','25','517','26','515','36'),10,'0') PROFIT_CENTER,
           LPAD(A.PC_ID,10,'0') RECEIVE_PROFIT_CENTER,
           NULL CUSTOMER_ID,NULL END_CUSTOMER_NAME,SUM(A.QTY*A.ASP) NET_REVENUE,
           SUM(A.QTY*A.ASP*B.TO_USD_RATE) NET_REVENUE_USD,SUM(A.QTY*A.ASP*B.TO_TWD_RATE) NET_REVENUE_TWD,TO_CHAR(SYSDATE,'YYYYMMDD')
           --Add kangi 20111229
          ,SUM(A.QTY*A.ASP*B.TO_CNY_RATE) NET_REVENUE_CNY
           --End Add kangi 20111229
     --FROM BGT_TRN001_REV@BUDGET_MSSQL A, BGT_MAS009_EXCH_RATE@BUDGET_MSSQL B Remark kangi 20111229
       FROM BGT_TRN001_REV@BUDGET_MSSQL A, BGT_MAS019_EXCH_RATE@BUDGET_MSSQL B
     --End Modify kangi 20111229
           WHERE A.PC_ID IN ('12','25')
             AND B.FROM_CURRENCY = 'USD'
             AND B.YYYY = cRWF_YYYY
             AND A.QTY*A.ASP <> 0
             AND A.YYYY = cRWF_YYYY
             --Add kangi 20111229
             AND A.MM = B.MM
             --End Add kangi 20111229
        GROUP BY A.YYYY,A.MM,A.SITE,A.PC_ID,LPAD(DECODE(A.MG_ID,'526','11','527','11','558','11','560','12','561','12','562','12','542','13','511','25','532','25','517','26','515','36'),10,'0') ;
   ELSE
        iTracePoint := 230 ;
        ----INSERT RWF_ZOT001_REVENUE_BUDGET FROM SQLSERVER's BUDGET(BGT_TRN006_REV_N_EXP),PC_ID NOT IN ('37')
        INSERT INTO RWF_ZOT001_REVENUE_BUDGET
        SELECT A.YYYY,A.MM,'BUDGET' RWF_TYPE,A.SITE,LPAD(DECODE(A.PC_ID,90,'USI-COMMON',A.PC_ID),10,'0')  PROFIT_CENTER,
             LPAD(A.ALLOC_PC_ID,10,'0') RECEIVE_PROFIT_CENTER ,NULL CUSTOMER_ID,NULL END_CUSTOMER_NAME,A.ALLOC_AMT NET_REVENUE,
             A.ALLOC_AMT*B.TO_USD_RATE NET_REVENUE_USD,A.ALLOC_AMT*B.TO_TWD_RATE NET_REVENUE_TWD,TO_CHAR(SYSDATE,'YYYYMMDD')
         --Add kangi 20111229
            ,A.ALLOC_AMT*B.TO_CNY_RATE NET_REVENUE_CNY
         --End Add kangi 20111229
         --Modify kangi 20111229
         --FROM BGT_TRN006_REV_N_EXP@BUDGET_MSSQL A, BGT_MAS009_EXCH_RATE@BUDGET_MSSQL B Remark kangi 20111229
           FROM BGT_TRN006_REV_N_EXP@BUDGET_MSSQL A, BGT_MAS019_EXCH_RATE@BUDGET_MSSQL B
         --End Modify kangi 20111229
          WHERE  A.GROUP_ID = '01'
            AND A.ALLOC_TYPE = 'Z'
            AND B.FROM_CURRENCY = 'USD'
            AND B.YYYY = cRWF_YYYY
            AND A.ALLOC_AMT <> 0
            AND A.YYYY = cRWF_YYYY
            AND A.PC_ID <> '37'
          --Add kangi 20111229
            AND A.MM = B.MM
          --End Add kangi 20111229
               ORDER BY A.YYYY,A.MM;


         iTracePoint := 240 ;
         ----INSERT RWF_ZOT001_REVENUE_BUDGET FROM SQLSERVER's BUDGET(TRN001_REV) ,PC_ID IN ('37')
         INSERT INTO RWF_ZOT001_REVENUE_BUDGET
         SELECT A.YYYY,A.MM,'BUDGET' RWF_TYPE,A.SITE,
            LPAD(DECODE(A.MG_ID,'556','38','578','38','37'),10,'0') PROFIT_CENTER,
            LPAD(A.PC_ID,10,'0') RECEIVE_PROFIT_CENTER,
            NULL CUSTOMER_ID,NULL END_CUSTOMER_NAME,SUM(A.QTY*A.ASP) NET_REVENUE,
            SUM(A.QTY*A.ASP*B.TO_USD_RATE) NET_REVENUE_USD,SUM(A.QTY*A.ASP*B.TO_TWD_RATE) NET_REVENUE_TWD,TO_CHAR(SYSDATE,'YYYYMMDD')
            --Add kangi 20111229
           ,SUM(A.QTY*A.ASP*B.TO_CNY_RATE) NET_REVENUE_CNY
            --End Add kangi 20111229
          --FROM BGT_TRN001_REV@BUDGET_MSSQL A,BGT_MAS009_EXCH_RATE@BUDGET_MSSQL B Remark kangi 20111229
            FROM BGT_TRN001_REV@BUDGET_MSSQL A, BGT_MAS019_EXCH_RATE@BUDGET_MSSQL B
          --End Modify kangi 20111229
            WHERE A.PC_ID IN ('37')
              AND B.FROM_CURRENCY = 'USD'
              AND B.YYYY = cRWF_YYYY
              AND A.QTY*A.ASP <> 0
              AND A.YYYY = cRWF_YYYY
            --Add kangi 20111229
              AND A.MM = B.MM
            --End Add kangi 20111229
          GROUP BY A.YYYY,A.MM,A.SITE,A.PC_ID,LPAD(DECODE(A.MG_ID,'556','38','578','38','37'),10,'0') ;

    END IF;







   iTracePoint := 300 ;
   ----UPDATE RELATED COMPANY FOR UABIT
   UPDATE RWF_ZOT001_REVENUE_BUDGET
   SET COMPANY_CODE = '1101'
   WHERE COMPANY_CODE like '11%'
      AND COMPANY_CODE not in ('1100')
      AND RWF_YYYY = cRWF_YYYY;

   iTracePoint := 400 ;
   COMMIT ;
 EXCEPTION
     WHEN OTHERS THEN
            --rollback ;
            cErrorText := SQLERRM() ;
            MAIL_FILE_BIDBDBADMIN(in_to_name=>'kangi@ms.usi.com.tw',subject   => 'PL/SQL RWF_PLS002_GET_BUDGET ERROR', message => '[RWF_PLS002_GET_BUDGET], The tracepoint is  ' || to_char(iTracePoint) || 'and ErrorText=' || cErrorText) ;
            DBMS_OUTPUT.PUT_LINE(SUBSTR(cErrorText,1,255));
            DBMS_OUTPUT.PUT_LINE(TO_CHAR(iTracePoint));
END RWF_PLS002_GET_BUDGET;
/

