create PROCEDURE PRODUTIVITY_SMT_REPORT2_TRX (
  inCompany  IN VARCHAR2,
  f_YYYYMMDD IN VARCHAR2,
  t_YYYYMMDD IN VARCHAR2
)
AUTHID DEFINER
IS
  --處理 ORGINAL ACCOUNT
  CURSOR C_ROUTING_T IS
    SELECT           COMPANY_CODE ,
       PERIOD          ,
       USIPN           ,
       PLANT           ,
       GROUP_NUMBER    ,
       GROUP_COUNTER   ,
       WORK_CENTER     ,
       CONVERSION_RATE ,
       BASE_QUANTITY   ,
       OPERATION       ,
       MACHINE_TIMES   ,
       MACHINE_SPLITS  ,
       MACHINE_UNIT    ,
       DIVISION        , 
       PROFIT_CENTER   ,
	   SUBCON          ,
	   WORK_ORDER      ,
	   CONFIRM_QTY     ,
	   SUM_QTY
      FROM PRODUTIVITY_SMT_REPORT2_T
           WHERE COMPANY_CODE = inCompany;

 BEGIN

   --(1)清除舊的 KPI_MAP018_ORGANIZATION 資料
   DELETE FROM PRODUTIVITY_SMT_REPORT2
   WHERE PERIOD IN (SELECT PERIOD FROM PRODUTIVITY_SMT_REPORT2_T WHERE COMPANY_CODE = inCompany GROUP BY PERIOD)
     AND COMPANY_CODE = inCompany ;
   COMMIT;

   FOR REC1 IN C_ROUTING_T LOOP
       --開始處理資料
       INSERT INTO PRODUTIVITY_SMT_REPORT2 (
                   COMPANY_CODE            , PERIOD                   , USIPN                    , PLANT                 ,
                   GROUP_NUMBER            , GROUP_COUNTER            , WORK_CENTER              , CONVERSION_RATE      ,
				   BASE_QUANTITY           , OPERATION                , MACHINE_TIMES            , MACHINE_SPLITS        ,
				   MACHINE_UNIT            , CREATEDATE               , DIVISION                 , PROFIT_CENTER         ,
				   SUBCON                  , WORK_ORDER               , CONFIRM_QTY              , SUM_QTY
                 ) VALUES (
                   TRIM(REC1.COMPANY_CODE) , TRIM(REC1.PERIOD)        , TRIM(REC1.USIPN)         , TRIM(REC1.PLANT)       ,
                   TRIM(REC1.GROUP_NUMBER) , TRIM(REC1.GROUP_COUNTER) , TRIM(REC1.WORK_CENTER)   , TRIM(REC1.CONVERSION_RATE)       ,
				   TRIM(REC1.BASE_QUANTITY), TRIM(REC1.OPERATION)     , TRIM(REC1.MACHINE_TIMES) , TRIM(REC1.MACHINE_SPLITS)     ,
				   TRIM(REC1.MACHINE_UNIT) , SYSDATE                  , TRIM(REC1.DIVISION)      , TRIM(REC1.PROFIT_CENTER)   ,
				   TRIM(REC1.SUBCON)       , TRIM(REC1.WORK_ORDER)    , TRIM(REC1.CONFIRM_QTY)   , TRIM(REC1.SUM_QTY));
       COMMIT;
   END LOOP;
   
   DELETE FROM PRODUTIVITY_SMT_REPORT2_T WHERE COMPANY_CODE = inCompany;
   COMMIT;
END PRODUTIVITY_SMT_REPORT2_TRX ;
/

