create PROCEDURE PLSQL_PMI_PHR001_INSP01 (
  inCompany  in VARCHAR2,
  f_YYYYMMDD in VARCHAR2,
  t_YYYYMMDD in VARCHAR2

)
AUTHID DEFINER
is


BEGIN

    DBMS_OUTPUT.PUT_LINE(inCompany);


   -- PMI_PHR001_PROD_EFF_T-> PMI_PHR001_PROD_EFF
   Insert into PMI_PHR001_PROD_EFF
        Select * From PMI_PHR001_PROD_EFF_T where COMPANY_CODE = inCompany;



   insert into PMI_PHR001_PROD_EFF_HISTORY value(
   select * from PMI_PHR001_PROD_EFF
    where to_date(operate_date,'yyyymmdd') < sysdate - 61
	  and COMPANY_CODE = inCompany);

   delete from PMI_PHR001_PROD_EFF
    where to_date(operate_date,'yyyymmdd') < sysdate - 61
	  and COMPANY_CODE = inCompany;


   Commit;

END PLSQL_PMI_PHR001_INSP01 ;
/

