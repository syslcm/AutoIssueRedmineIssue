create PROCEDURE         "VRTN_PLSQL_SAP001_QUANLITY1" (
 inCompany  in VRT_SAP001_QUANLITY1_SITE.COMPANY_CODE%TYPE,
 f_YYYYMMDD in VARCHAR2,
 t_YYYYMMDD in VARCHAR2

)
IS

    /*
     每月執行一次 Vendor rating By MatGROUP
     1. 抓 VRTN_SAP001_QUANLITY1_SITE_T 資料
     2. Insert to VRTN_SAP001_QUANLITY1_SITE table
         3. Insert to VRTN_MAP030_SUMMARY_GRAD
         By susan
    */

 vPERCENTAGE_L1  VRT_MAP020_RATE_INDEX.PERCENTAGE%TYPE;
 vPERCENTAGE_L2  VRT_MAP020_RATE_INDEX.PERCENTAGE%TYPE;
 vPERCENTAGE_L3  VRT_MAP020_RATE_INDEX.PERCENTAGE%TYPE;
 vPERCENTAGE_L4  VRT_MAP020_RATE_INDEX.PERCENTAGE%TYPE;
 vPROCEE_YYYYMM  varchar2(6);
 iTracePoint     varchar2(100);
 cErrorText      varchar2(500);

BEGIN

  --抓上個月份
  iTracePoint := '100';
  vPROCEE_YYYYMM := TO_CHAR(ADD_MONTHS(SYSDATE, -1), 'YYYYMM');

  --清除重覆資料
   DELETE FROM VRTN_SAP001_QUANLITY1_SITE WHERE COMPANY_CODE =inCompany
          and YYYY = SUBSTRB(vPROCEE_YYYYMM,1,4)
          and MM   = SUBSTRB(vPROCEE_YYYYMM,5,2);

  iTracePoint := '200';
  Insert into VRTN_SAP001_QUANLITY1_SITE (
                   YYYY, MM, SITE , COMPANY_CODE , PTYPE, LIFNR, MATGROUP, QKENNZAHL, PLANT, DATE_TIME)
      Select YYYY, MM, SITE , COMPANY_CODE , PTYPE, LIFNR, MATGROUP, QKENNZAHL, PLANT, DATE_TIME
             from VRTN_SAP001_QUANLITY1_SITE_T
             where COMPANY_CODE = inCompany
              and YYYY = SUBSTRB(vPROCEE_YYYYMM,1,4)
              and MM   = SUBSTRB(vPROCEE_YYYYMM,5,2);


   iTracePoint := '300';
--   DELETE  from VRTN_SAP001_QUANLITY1_SITE_T
--    where COMPANY_CODE = inCompany
--          and YYYY = SUBSTRB(vPROCEE_YYYYMM,1,4)
--          and MM   = SUBSTRB(vPROCEE_YYYYMM,5,2);


  --抓各階分數
  iTracePoint := '400';
  vPERCENTAGE_L1 := null;
  vPERCENTAGE_L2 := null;
  vPERCENTAGE_L3 := null;
  vPERCENTAGE_L4 := null;

  for REC1 in ( select LEVEL_S, PERCENTAGE from VRTN_MAP020_RATE_INDEX
                 where INDEX_KEY = 'QUALITY' and TYPE = 'QA' ) loop
    if REC1.LEVEL_S = 'L1' then
      iTracePoint := '410';
      vPERCENTAGE_L1 := REC1.PERCENTAGE;
    elsif REC1.LEVEL_S = 'L2' then
      iTracePoint := '420';
      vPERCENTAGE_L2 := REC1.PERCENTAGE;
    elsif REC1.LEVEL_S = 'L3' then
      iTracePoint := '430';
      vPERCENTAGE_L3 := REC1.PERCENTAGE;
    elsif REC1.LEVEL_S = 'L4' then
      iTracePoint := '440';
      vPERCENTAGE_L4 := REC1.PERCENTAGE;
    end if;
  end loop;

  if vPERCENTAGE_L1 is null or vPERCENTAGE_L2 is null or vPERCENTAGE_L3 is null or vPERCENTAGE_L4 is null then
    --若沒抓到資料則寄 error mail
    iTracePoint := '450';
    cErrorText := 'vPERCENTAGE_L1 is ' || nvl(to_char(vPERCENTAGE_L1),'null') || ',vPERCENTAGE_L2 is ' || nvl(to_char(vPERCENTAGE_L2),'null') || ',vPERCENTAGE_L3 is ' || nvl(to_char(vPERCENTAGE_L3),'null') || ',vPERCENTAGE_L4 is ' || nvl(to_char(vPERCENTAGE_L4),'null');
    MAIL_FILE_BIDBDBADMIN(in_to_name => 'shuchin_lin@usiglobal.com', subject => '[VRT] PL/SQL VRTN_PLSQL_QUANLITY ERROR', message => '[VRT_PLSQL_ORR_REPLY_RATE], The tracepoint is  ' || iTracePoint || ' and ErrorText= ' || cErrorText) ;
  else
    --先清舊的資料以避免重覆
    iTracePoint := '500-' || vPROCEE_YYYYMM;
    delete from VRTN_MAP030_SUMMARY_GRAD
     where TYPE = 'QA' and YYYY = substr(vPROCEE_YYYYMM,1,4) and MM = substr(vPROCEE_YYYYMM,5,2) and BUKRS = inCompany;
    commit;


    --放入上月分數
    iTracePoint := '600';
    for REC1 in ( select a.YYYY, a.MM, a.SITE , a.COMPANY_CODE , a.PTYPE, a.LIFNR as VENDOR_CODE, a.MATGROUP ,a.QKENNZAHL as SCORE, a.DATE_TIME, a.YYYY || a.MM  AS YYYYMM, b.QUARTER
                         from VRTN_SAP001_QUANLITY1_SITE a, DIMENSION_DATE b
                         where a.YYYY = SUBSTRB(vPROCEE_YYYYMM,1,4) AND
                               a.MM   = SUBSTRB(vPROCEE_YYYYMM,5,2) AND
                               a.COMPANY_CODE = inCompany AND
                               ( a.YYYY || a.MM || '01' ) = b.DATE_KEY
                          Group by a.YYYY, a.MM, a.SITE , a.COMPANY_CODE , a.PTYPE, a.LIFNR, a.MATGROUP, a.QKENNZAHL, a.DATE_TIME, a.YYYY || a.MM, b.QUARTER ) loop


      --放到 VRTN_MAP030_SUMMARY_GRAD
      iTracePoint := '610-' || REC1.SITE || '-' || REC1.VENDOR_CODE || '-' ||  SUBSTRB(vPROCEE_YYYYMM,1,6);
      insert into VRTN_MAP030_SUMMARY_GRAD (
             SITE, LIFNR, MATGROUP, TYPE, YYYY, MM, QUARTER, BUKRS, L1, GRADE_L1, L2, GRADE_L2, L3, GRADE_L3, L4, GRADE_L4
           ) values (
             REC1.SITE,
             REC1.VENDOR_CODE,
			 REC1.MATGROUP,
             REC1.PTYPE,
             REC1.YYYY,
             REC1.MM,
             REC1.QUARTER,
             REC1.COMPANY_CODE,
             'S0',
             round(REC1.SCORE * vPERCENTAGE_L1, 5),
             'Q0',
             round(REC1.SCORE * vPERCENTAGE_L2, 5),
             'QA',
             round(REC1.SCORE * vPERCENTAGE_L3, 5),
             'QA',
             round(REC1.SCORE * vPERCENTAGE_L4, 5)
           );
      commit;
    end loop;
  end if;

EXCEPTION
   When OTHERS Then
    --有錯誤產生則寄mail
    cErrorText := SQLERRM();
    MAIL_FILE_BIDBDBADMIN(in_to_name => 'shuchin_lin@usiglobal.com', subject => '[VRTN] PL/SQL VRTN_PLSQL_SAP001_QUANLITY1 ERROR', message => '[VRT_SAP001_QUANLITY1_SITE], The tracepoint is  ' || iTracePoint || ' and ErrorText= ' || cErrorText) ;

END VRTN_PLSQL_SAP001_QUANLITY1;
/

