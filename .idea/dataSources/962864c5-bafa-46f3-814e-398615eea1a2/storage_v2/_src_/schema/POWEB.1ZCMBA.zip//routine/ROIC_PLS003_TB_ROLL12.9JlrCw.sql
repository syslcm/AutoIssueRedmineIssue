create PROCEDURE       ROIC_PLS003_TB_ROLL12 (
  t_YYYYMMDD in VARCHAR2,
  w_USER     in VARCHAR2
)
AUTHID DEFINER
is
/*********************************************************************
  PROG-ID      : ROIC_PLS003_TB_ROLL12
  PROG-ACTION  : Trial Balance Roll Up 12 Months Data
  Author       : Patty
  Date         : 2019/01/23
  OA No.       : SAI093838
  Process      : Excute Procedure ROIC_PLS003_TB_ROLL12_BTO &
                                  ROIC_PLS003_TB_ROLL12_IND
**********************************************************************/
/*---------------------------------------------------------------------
-- 2019/02/11 SAI094677 Patty add excute procedure: 
--                      ROIC_PLS003_TB_ROLL12_G1_BTO, ROIC_PLS003_TB_ROLL12_G1_IND
---------------------------------------------------------------------*/
  sPROC_NAME         ROIC_PST000_LOG.PROC_NAME%TYPE;
  sRUN_SEQ           ROIC_PST000_LOG.RUN_SEQ%TYPE;
  sRUN_DESC          ROIC_PST000_LOG.RUN_DESC%TYPE;
  sPARAMETER_DESC    ROIC_PST000_LOG.PARAMETER_DESC%TYPE;       
  t_PERIOD           ROIC_SAP003_TB_DATA.PERIOD%TYPE;  

             
BEGIN

  t_PERIOD := SUBSTR(t_YYYYMMDD,1,6);

  sPROC_NAME := 'ROIC_PLS003_TB_ROLL12';
  sRUN_SEQ   := '000010';
  sRUN_DESC  := 'Start';
  sPARAMETER_DESC := CONCAT(CONCAT(CONCAT('t_PERIOD=',t_PERIOD),';w_USER='),w_USER);
 
  --Insert Log
  INSERT INTO ROIC_PST000_LOG
      ( PROC_NAME, RUN_SEQ, RUN_DESC, PARAMETER_DESC )
    VALUES
      ( sPROC_NAME, sRUN_SEQ, sRUN_DESC, sPARAMETER_DESC );
  Commit;

  --Exec Store Procedure
  ROIC_PLS003_TB_ROLL12_IND(t_PERIOD);

  ROIC_PLS003_TB_ROLL12_BTO(t_PERIOD);

  ROIC_PLS003_TB_ROLL12_G1_IND(t_PERIOD);     -- SAI094677

  ROIC_PLS003_TB_ROLL12_G1_BTO(t_PERIOD);     -- SAI094677

  sRUN_SEQ   := '000020';
  sRUN_DESC  := 'End';

  --Insert Log
  INSERT INTO ROIC_PST000_LOG
      ( PROC_NAME, RUN_SEQ, RUN_DESC, PARAMETER_DESC )
    VALUES
      ( sPROC_NAME, sRUN_SEQ, sRUN_DESC, sPARAMETER_DESC );
  Commit;

END ROIC_PLS003_TB_ROLL12;
/

