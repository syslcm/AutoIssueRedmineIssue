create PROCEDURE PLSQL_PTP_INTEL_WEEKLY_2B (
  outRES OUT VARCHAR2
)
AUTHID DEFINER
is
  --RFQ
  CURSOR C_DCF_USI_RFQ is
    Select distinct
          A.USI_PN, A.USI_VENDOR_NO, A.USI_CURRENCY, A.USI_PRICE,
          A.QUOTA_TW, A.QUOTA_SZ, A.QUOTA_SH, A.QUOTA_MX, A.QUOTA_JP,
          B.VERSION, B.COMMODITY, B.COMMODITY_SPECIALIST, B.INTEL_PART, B.INTEL_DESCRIPTION,
          B.SUPPLIER, B.WEIGHTED_COST, B.CONTRACT_PRICE, B.INTEL_ALLOCATION, B.LAST_ALLOCATION,
          B.EFFECTIVITY_DATE, B.INTEL_COMMENT, B.INTEL_LAST_PRICE, B.LAST_PRICE_DATE,
          SUBSTRB(C.VENDOR_NAME,1,20) as VENDOR_NAME1
     From DCF_USI_RFQ A, PTP_INTEL_CURRENT B, RFQ_VENDOR_MASTER C, SAP_AMPL D
    where D.COMPANY_CODE is Not Null
      and D.INT_PART_NO like SUBSTRB(B.INTEL_PART,1,LENGTHB(B.INTEL_PART)-3) || '%'
      and D.PART_NO = A.USI_PN
      and A.USI_VENDOR_NO = C.VENDOR_ID
      and C.COMPANY_CODE = '1100'
      and SUBSTRB(B.INTEL_PART,-3,3) = 'XXX';

  --SAP inforecord and RFQ not exist
  CURSOR C_SAP_INFOREC1 is
    Select distinct
          A.PART_NO, A.VENDOR_CODE, A.INCOTERM, A.LOCATION, A.UNIT_PRICE, A.CURRENCY,
          B.VERSION, B.COMMODITY, B.COMMODITY_SPECIALIST, B.INTEL_PART, B.INTEL_DESCRIPTION,
          B.SUPPLIER, B.WEIGHTED_COST, B.CONTRACT_PRICE, B.INTEL_ALLOCATION, B.LAST_ALLOCATION,
          B.EFFECTIVITY_DATE, B.INTEL_COMMENT, B.INTEL_LAST_PRICE, B.LAST_PRICE_DATE,
          SUBSTRB(C.VENDOR_NAME,1,20) as VENDOR_NAME1
     From SAP_INFOREC A, PTP_INTEL_CURRENT B, RFQ_VENDOR_MASTER C, SAP_AMPL D
    where D.COMPANY_CODE is Not Null
      and D.INT_PART_NO like SUBSTRB(B.INTEL_PART,1,LENGTHB(B.INTEL_PART)-3) || '%'
      and D.PART_NO = A.PART_NO
      and NOT EXISTS (
	    Select D1.USI_PN from DCF_USI_RFQ D1
	     where D1.USI_PN = A.PART_NO
	       and D1.USI_VENDOR_NO = A.VENDOR_CODE
	  )
      and A.COMPANY_CODE = '1100'
      and A.VENDOR_CODE = C.VENDOR_ID
      and A.INFO_CATEGORY = '0'
      and C.COMPANY_CODE = '1100'
      and ( A.DELE_FLAG is NULL or A.DELE_FLAG = '' )
      and SUBSTRB(B.INTEL_PART,-3,3) = 'XXX';

  --SAP inforecord and RFQ exist
  CURSOR C_SAP_INFOREC2 is
    Select distinct
          A.PART_NO, A.VENDOR_CODE, A.INCOTERM, A.LOCATION, A.UNIT_PRICE, A.CURRENCY,
          B.INTEL_PART, B.SUPPLIER, B.CONTRACT_PRICE
     From SAP_INFOREC A, PTP_INTEL_CURRENT B, SAP_AMPL D
    where D.COMPANY_CODE is Not Null
      and D.INT_PART_NO like SUBSTRB(B.INTEL_PART,1,LENGTHB(B.INTEL_PART)-3) || '%'
      and D.PART_NO = A.PART_NO
      and EXISTS (
	    Select C.USI_PN from DCF_USI_RFQ C
	     where C.USI_PN = A.PART_NO
	       and C.USI_VENDOR_NO = A.VENDOR_CODE
	  )
      and A.COMPANY_CODE = '1100'
      and A.INFO_CATEGORY = '0'
      and ( A.DELE_FLAG is NULL or A.DELE_FLAG = '' )
      and SUBSTRB(B.INTEL_PART,-3,3) = 'XXX';

   nCOUNT              NUMBER(5);
   nUSI_CURRENCY       DCF_USI_RFQ.USI_CURRENCY%TYPE;
   nUSI_PRICE_USD      PTP_INTEL_WEEKLY_REPORT.USI_PRICE_USD%TYPE;
   nPRICE_DIFF         PTP_INTEL_WEEKLY_REPORT.PRICE_DIFF%TYPE;
   nALLOCATION_DIFF    PTP_INTEL_WEEKLY_REPORT.ALLOCATION_DIFF%TYPE;

 BEGIN
   outRES := 'START';

   --RFQ
   nCOUNT := 0;
   FOR REC1 in C_DCF_USI_RFQ LOOP
     outRES := 'C_DCF_USI_RFQ:' || REC1.INTEL_PART || '<>' || REC1.USI_PN || '<>' || REC1.SUPPLIER || '<>' || REC1.USI_VENDOR_NO;
     If REC1.USI_CURRENCY = 'USD' Then
       nUSI_PRICE_USD := REC1.USI_PRICE;
     Else
       BEGIN
         Select * into nUSI_PRICE_USD From (
           Select Round( (A.EXCH_RATE * REC1.USI_PRICE / B.EXCH_RATE), 6)
             from DCF_EXCHANGE_RATE A, DCF_EXCHANGE_RATE B
            where A.TO_CURRENCY = 'TWD'
              and A.FROM_CURRENCY = REC1.USI_CURRENCY
              and B.TO_CURRENCY = 'TWD'
              and B.FROM_CURRENCY = 'USD'
         ) Where ROWNUM <= 1;
       EXCEPTION
         WHEN OTHERS THEN
           nUSI_PRICE_USD := Null;
       END;
     End If;
     nPRICE_DIFF := Null;
     If nUSI_PRICE_USD is Not Null Then
       nPRICE_DIFF := Round(nUSI_PRICE_USD - NVL(REC1.CONTRACT_PRICE,0),6);
     End If;
     nALLOCATION_DIFF := Null;
     If REC1.INTEL_ALLOCATION is Not Null and REC1.LAST_ALLOCATION is Not Null Then
       nALLOCATION_DIFF := REC1.INTEL_ALLOCATION - REC1.LAST_ALLOCATION;
     End If;

     Insert into PTP_INTEL_WEEKLY_REPORT ( VERSION, COMMODITY, COMMODITY_SPECIALIST, INTEL_PART,
                 INTEL_DESCRIPTION, SUPPLIER, WEIGHTED_COST, CONTRACT_PRICE,
                 INTEL_ALLOCATION, LAST_ALLOCATION, EFFECTIVITY_DATE, INTEL_COMMENT,
                 USI_PN, USI_VENDOR_CODE, USI_VENDOR_NAME,
                 USI_PRICE, USI_PRICE_CURRENCY, USI_PRICE_USD,
                 USI_QUOTA_TW, USI_QUOTA_SZ, USI_QUOTA_SH, USI_QUOTA_MX, USI_QUOTA_JP,
                 INTEL_LAST_PRICE, LAST_PRICE_DATE, PRICE_DIFF, ALLOCATION_DIFF)
          values ( REC1.VERSION, REC1.COMMODITY, REC1.COMMODITY_SPECIALIST, REC1.INTEL_PART,
                   REC1.INTEL_DESCRIPTION, REC1.SUPPLIER, REC1.WEIGHTED_COST, REC1.CONTRACT_PRICE,
                   REC1.INTEL_ALLOCATION, REC1.LAST_ALLOCATION, REC1.EFFECTIVITY_DATE, REC1.INTEL_COMMENT,
                   REC1.USI_PN, REC1.USI_VENDOR_NO, REC1.VENDOR_NAME1,
                   REC1.USI_PRICE, REC1.USI_CURRENCY, nUSI_PRICE_USD,
                   REC1.QUOTA_TW, REC1.QUOTA_SZ, REC1.QUOTA_SH, REC1.QUOTA_MX, REC1.QUOTA_JP,
                   REC1.INTEL_LAST_PRICE, REC1.LAST_PRICE_DATE, nPRICE_DIFF, nALLOCATION_DIFF);
     nCOUNT := nCOUNT + 1;
     If nCOUNT = 100 Then
       Commit;
       nCOUNT := 0;
     End If;
   END LOOP;
   Commit;
   outRES := 'INSERT C_DCF_USI_RFQ OK';

   --SAP inforecord and RFQ not exist
   nCOUNT := 0;
   FOR REC1 in C_SAP_INFOREC1 LOOP
     outRES := 'C_SAP_INFOREC1:' || REC1.INTEL_PART || '<>' || REC1.PART_NO || '<>' || REC1.SUPPLIER || '<>' || REC1.VENDOR_CODE;
     If REC1.CURRENCY = 'USD' Then
       nUSI_PRICE_USD := REC1.UNIT_PRICE;
     Else
       BEGIN
         Select * into nUSI_PRICE_USD From (
           Select Round( (A.EXCH_RATE * REC1.UNIT_PRICE / B.EXCH_RATE), 6)
             from DCF_EXCHANGE_RATE A, DCF_EXCHANGE_RATE B
            where A.TO_CURRENCY = 'TWD'
              and A.FROM_CURRENCY = REC1.CURRENCY
              and B.TO_CURRENCY = 'TWD'
              and B.FROM_CURRENCY = 'USD'
         ) Where ROWNUM <= 1;
       EXCEPTION
         WHEN OTHERS THEN
           nUSI_PRICE_USD := Null;
       END;
     End If;
     nPRICE_DIFF := Null;
     If nUSI_PRICE_USD is Not Null Then
       nPRICE_DIFF := Round(nUSI_PRICE_USD - NVL(REC1.CONTRACT_PRICE,0),6);
     End If;
     nALLOCATION_DIFF := Null;
     If REC1.INTEL_ALLOCATION is Not Null and REC1.LAST_ALLOCATION is Not Null Then
       nALLOCATION_DIFF := REC1.INTEL_ALLOCATION - REC1.LAST_ALLOCATION;
     End If;

     Insert into PTP_INTEL_WEEKLY_REPORT ( VERSION, COMMODITY, COMMODITY_SPECIALIST, INTEL_PART,
                 INTEL_DESCRIPTION, SUPPLIER, WEIGHTED_COST, CONTRACT_PRICE,
                 INTEL_ALLOCATION, LAST_ALLOCATION, EFFECTIVITY_DATE, INTEL_COMMENT,
                 USI_PN, USI_VENDOR_CODE, USI_VENDOR_NAME,
                 USI_PRICE, USI_PRICE_CURRENCY, USI_PRICE_USD, USI_INCOTERM, LOCATION,
                 INTEL_LAST_PRICE, LAST_PRICE_DATE, PRICE_DIFF, ALLOCATION_DIFF )
          values ( REC1.VERSION, REC1.COMMODITY, REC1.COMMODITY_SPECIALIST, REC1.INTEL_PART,
                   REC1.INTEL_DESCRIPTION, REC1.SUPPLIER, REC1.WEIGHTED_COST, REC1.CONTRACT_PRICE,
                   REC1.INTEL_ALLOCATION, REC1.LAST_ALLOCATION, REC1.EFFECTIVITY_DATE, REC1.INTEL_COMMENT,
                   REC1.PART_NO, REC1.VENDOR_CODE, REC1.VENDOR_NAME1,
                   REC1.UNIT_PRICE, REC1.CURRENCY, nUSI_PRICE_USD, REC1.INCOTERM, REC1.LOCATION,
                   REC1.INTEL_LAST_PRICE, REC1.LAST_PRICE_DATE, nPRICE_DIFF, nALLOCATION_DIFF );
     nCOUNT := nCOUNT + 1;
     If nCOUNT = 100 Then
       Commit;
       nCOUNT := 0;
     End If;
   END LOOP;
   Commit;
   outRES := 'INSERT C_SAP_INFOREC1 OK';

   --SAP inforecord and RFQ exist
   nCOUNT := 0;
   FOR REC1 in C_SAP_INFOREC2 LOOP
     outRES := 'C_SAP_INFOREC2:' || REC1.INTEL_PART || '<>' || REC1.PART_NO || '<>' || REC1.SUPPLIER || '<>' || REC1.VENDOR_CODE;
     --Check RFQ Price exist or not
     nUSI_CURRENCY := Null;
     BEGIN
       Select * into nUSI_CURRENCY From (
         Select USI_PRICE_CURRENCY from PTP_INTEL_WEEKLY_REPORT
          where INTEL_PART = REC1.INTEL_PART
            and USI_PN = REC1.PART_NO
            and SUPPLIER = REC1.SUPPLIER
            and USI_VENDOR_CODE = REC1.VENDOR_CODE
       ) Where ROWNUM <= 1;
     EXCEPTION
       WHEN OTHERS THEN
         nUSI_CURRENCY := Null;
     END;
     If nUSI_CURRENCY is Null Then
       If REC1.CURRENCY = 'USD' Then
         nUSI_PRICE_USD := REC1.UNIT_PRICE;
       Else
         BEGIN
           Select * into nUSI_PRICE_USD From (
             Select Round( (A.EXCH_RATE * REC1.UNIT_PRICE / B.EXCH_RATE), 6)
               from DCF_EXCHANGE_RATE A, DCF_EXCHANGE_RATE B
              where A.TO_CURRENCY = 'TWD'
                and A.FROM_CURRENCY = REC1.CURRENCY
                and B.TO_CURRENCY = 'TWD'
                and B.FROM_CURRENCY = 'USD'
           ) Where ROWNUM <= 1;
         EXCEPTION
           WHEN OTHERS THEN
             nUSI_PRICE_USD := Null;
         END;
       End If;
       nPRICE_DIFF := Null;
       If nUSI_PRICE_USD is Not Null Then
         nPRICE_DIFF := Round(nUSI_PRICE_USD - NVL(REC1.CONTRACT_PRICE,0),6);
       End If;
       Update PTP_INTEL_WEEKLY_REPORT set
                                     USI_PRICE_CURRENCY = REC1.CURRENCY,
                                     USI_PRICE = REC1.UNIT_PRICE,
                                     USI_PRICE_USD = nUSI_PRICE_USD,
                                     USI_INCOTERM = REC1.INCOTERM,
                                     LOCATION = REC1.LOCATION,
                                     PRICE_DIFF = nPRICE_DIFF
                               where INTEL_PART = REC1.INTEL_PART
                                 and USI_PN = REC1.PART_NO
                                 and SUPPLIER = REC1.SUPPLIER
                                 and USI_VENDOR_CODE = REC1.VENDOR_CODE;
     Else
       Update PTP_INTEL_WEEKLY_REPORT set
                                     USI_INCOTERM = REC1.INCOTERM,
                                     LOCATION = REC1.LOCATION
                               where INTEL_PART = REC1.INTEL_PART
                                 and USI_PN = REC1.PART_NO
                                 and SUPPLIER = REC1.SUPPLIER
                                 and USI_VENDOR_CODE = REC1.VENDOR_CODE;
     End If;
     nCOUNT := nCOUNT + 1;
     If nCOUNT = 100 Then
       Commit;
       nCOUNT := 0;
     End If;
   END LOOP;
   Commit;

   outRES := 'SUCCESS';
 EXCEPTION
   WHEN OTHERS THEN
     outRES := TRIM(outRES) || ' - ' || TRIM(SUBSTR(SQLERRM,1,100));
     Rollback;
 END PLSQL_PTP_INTEL_WEEKLY_2B;
/

