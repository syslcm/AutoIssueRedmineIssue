create PROCEDURE       PLSQL_PLD_KPI_ZD319_PR
(
    inCompany  in VARCHAR2,
    f_YYYYMMDD in VARCHAR2,
    t_YYYYMMDD in VARCHAR2
)
AUTHID DEFINER
is
    /*
    處理 PLD_KPI_ZD318_PO 資料 (SAP SH2 ZD318) SAI030327
        -- NEW OPEN PO for PO management >>> PLD_KPI_ZD318_SUM
    處理 PLD_KPI_ZD319_PR 資料 (SAP SH2 ZD318) SAI030327
        -- NEW OPEN PR for PO management >>> PLD_KPI_ZD319_SUM
    SAI030876 : 更新邏輯, 天數是 ">" 而不是 ">=" , 且全部要帶 overdue 天數; PO Overdue 只認有 Cfm 的
    SAI031509 : 2012/06/28 PR 加入 RV
    */
    iTracePoint         varchar2(4);
    cErrorText          varchar2(500);
    t_sysdate           varchar2(8);
BEGIN
    iTracePoint := 'A000';
    t_sysdate := to_char(sysdate,'yyyymmdd');

    ---------------------------------------------------------------------------------------------------------------
    -- ZD318 (PO) / 只作 NB
    ---------------------------------------------------------------------------------------------------------------
    -- create_date <> sysdate 錯誤 (PLD_KPI_ZD318_PO)
    iTracePoint := 'A050';
    delete from PLD_KPI_ZD318_PO
        where COMPANY_CODE = inCompany
        and ( CREATE_DATE <> to_char(sysdate,'yyyymmdd') or PO_TYPE <> 'NB' or PART_NO is null );
    commit;

    -- 清除 create_date = sysdate 以重算資料 (PLD_KPI_ZD318_SUM)
    iTracePoint := 'A030';
    delete from PLD_KPI_ZD318_SUM
        where COMPANY_CODE = inCompany
        and CREATE_DATE = to_char(sysdate,'yyyymmdd');
    commit;

    ---------------------------------------------------------------------------------------------------------------
    -- PO_NON_CONFIRM ( > 七天)
    iTracePoint := 'A100';
    update PLD_KPI_ZD318_PO set
        OVERDUE_CFM = ( to_date(t_sysdate,'yyyymmdd') - to_date(POCRE_DATE,'yyyymmdd') )
    where COMPANY_CODE = inCompany and CREATE_DATE = to_char(sysdate,'yyyymmdd')
    and CFM_QTY = 0;
    commit;

    -- total count (PO_NON_CONFIRM, 分母: 所有 Open PO)
    iTracePoint := 'A150';
    insert into PLD_KPI_ZD318_SUM ( COMPANY_CODE, CREATE_DATE, REC_TYPE, REC_OVERDUE, REC_TOTAL, BUYER_CODE)
        select a.COMPANY_CODE, a.CREATE_DATE, '2. PO NON CONFIRM', 0, count(*), a.BUYER_CODE
        from PLD_KPI_ZD318_PO a
        where a.COMPANY_CODE = inCompany
        and a.CREATE_DATE = to_char(sysdate,'yyyymmdd')
        group by a.COMPANY_CODE, a.CREATE_DATE, a.BUYER_CODE;
    commit;

    iTracePoint := 'A180';
    for rec1 in (
        select COMPANY_CODE, CREATE_DATE, BUYER_CODE, count(*) as REC_COUNT from PLD_KPI_ZD318_PO
        where COMPANY_CODE = inCompany and CREATE_DATE = to_char(sysdate,'yyyymmdd')
        and OVERDUE_CFM > 7
        group by COMPANY_CODE, CREATE_DATE, BUYER_CODE
    ) loop
        iTracePoint := 'B' || rec1.BUYER_CODE;
        update PLD_KPI_ZD318_SUM set REC_OVERDUE = rec1.REC_COUNT
            where COMPANY_CODE = rec1.COMPANY_CODE and CREATE_DATE = rec1.CREATE_DATE
            and REC_TYPE = '2. PO NON CONFIRM' and BUYER_CODE = rec1.BUYER_CODE;
        commit;
    end loop;

    ---------------------------------------------------------------------------------------------------------------
    -- PO_OVERDUE ( > 三天 且有 Cfm 的)
    iTracePoint := 'C100';
    update PLD_KPI_ZD318_PO set
        OVERDUE_GR = ( to_date(t_sysdate,'yyyymmdd') - to_date(decode(CFM_DATE,null,REQ_DATE,CFM_DATE),'yyyymmdd') )
    where COMPANY_CODE = inCompany and CREATE_DATE = to_char(sysdate,'yyyymmdd')
    and CFM_QTY > 0;
    commit;

    -- total count (PO_NON_CONFIRM, 分母: 有 cfm 的 Open PO)
    iTracePoint := 'C150';
    insert into PLD_KPI_ZD318_SUM ( COMPANY_CODE, CREATE_DATE, REC_TYPE, REC_OVERDUE, REC_TOTAL, BUYER_CODE)
        select a.COMPANY_CODE, a.CREATE_DATE, '3. PO OVERDUE', 0, count(*), a.BUYER_CODE
        from PLD_KPI_ZD318_PO a
        where a.COMPANY_CODE = inCompany
        and a.CREATE_DATE = to_char(sysdate,'yyyymmdd')
        and a.CFM_QTY > 0
        group by a.COMPANY_CODE, a.CREATE_DATE, a.BUYER_CODE;
    commit;

    iTracePoint := 'C180';
    for rec1 in (
        select COMPANY_CODE, CREATE_DATE, BUYER_CODE, count(*) as REC_COUNT from PLD_KPI_ZD318_PO
        where COMPANY_CODE = inCompany and CREATE_DATE = to_char(sysdate,'yyyymmdd')
        and OVERDUE_GR > 3
        group by COMPANY_CODE, CREATE_DATE, BUYER_CODE
    ) loop
        iTracePoint := 'D' || rec1.BUYER_CODE;
        update PLD_KPI_ZD318_SUM set REC_OVERDUE = rec1.REC_COUNT
            where COMPANY_CODE = rec1.COMPANY_CODE and CREATE_DATE = rec1.CREATE_DATE
            and REC_TYPE = '3. PO OVERDUE' and BUYER_CODE = rec1.BUYER_CODE;
        commit;
    end loop;

    ---------------------------------------------------------------------------------------------------------------
    -- ZD319 (PR) / 納入 NB & RV
    ---------------------------------------------------------------------------------------------------------------
    -- create_date <> sysdate 錯誤 (PLD_KPI_ZD319_PR)
    iTracePoint := 'E000';
    delete from PLD_KPI_ZD319_PR
        where COMPANY_CODE = inCompany
        and ( CREATE_DATE <> to_char(sysdate,'yyyymmdd') or PR_TYPE not in ('NB','RV') or PART_NO is null );
    commit;

    -- 清除 create_date = sysdate 以重算資料 (PLD_KPI_ZD319_SUM)
    iTracePoint := 'E030';
    delete from PLD_KPI_ZD319_SUM
        where COMPANY_CODE = inCompany
        and CREATE_DATE = to_char(sysdate,'yyyymmdd');
    commit;

    -- PR_NON_PO ( > 三天)
    iTracePoint := 'E110';
    update PLD_KPI_ZD319_PR set
        OVERDUE_DAY = ( to_date(t_sysdate,'yyyymmdd') - to_date(PRCRE_DATE,'yyyymmdd') )
    where COMPANY_CODE = inCompany and CREATE_DATE = to_char(sysdate,'yyyymmdd')
    and OPEN_QTY > 0;
    commit;
    iTracePoint := 'E130';
    update PLD_KPI_ZD319_PR set
        OVERDUE_DAY = 0
    where COMPANY_CODE = inCompany and CREATE_DATE = to_char(sysdate,'yyyymmdd')
    and OPEN_QTY = 0;
    commit;

    -- total count
    iTracePoint := 'E210';
    insert into PLD_KPI_ZD319_SUM ( COMPANY_CODE, CREATE_DATE, REC_TYPE, REC_OVERDUE, REC_TOTAL, BUYER_CODE)
        select a.COMPANY_CODE, a.CREATE_DATE, '1. PR NON PO', 0, count(*), a.BUYER_CODE
        from PLD_KPI_ZD319_PR a
        where a.COMPANY_CODE = inCompany
        and a.CREATE_DATE = to_char(sysdate,'yyyymmdd')
        group by a.COMPANY_CODE, a.CREATE_DATE, a.BUYER_CODE;
    commit;

    iTracePoint := 'E230';
    for rec1 in (
        select COMPANY_CODE, CREATE_DATE, BUYER_CODE, count(*) as REC_COUNT from PLD_KPI_ZD319_PR
        where COMPANY_CODE = inCompany and CREATE_DATE = to_char(sysdate,'yyyymmdd')
        and OVERDUE_DAY > 3
        group by COMPANY_CODE, CREATE_DATE, BUYER_CODE
    ) loop
        iTracePoint := 'F' || rec1.BUYER_CODE;
        update PLD_KPI_ZD319_SUM set REC_OVERDUE = rec1.REC_COUNT
            where COMPANY_CODE = rec1.COMPANY_CODE and CREATE_DATE = rec1.CREATE_DATE
            and REC_TYPE = '1. PR NON PO' and BUYER_CODE = rec1.BUYER_CODE;
        commit;
    end loop;

    ---------------------------------------------------------------------------------------------------------------
    -- SUM PR & PO
    ---------------------------------------------------------------------------------------------------------------
    -- 彙整各一筆
    iTracePoint := 'G100';
    for rec1 in (
        select COMPANY_CODE, CREATE_DATE, BUYER_CODE from (
            select COMPANY_CODE, CREATE_DATE, BUYER_CODE, REC_TYPE from PLD_KPI_ZD318_SUM
            where COMPANY_CODE = inCompany and CREATE_DATE = to_char(sysdate,'yyyymmdd')
            union all
            select COMPANY_CODE, CREATE_DATE, BUYER_CODE, REC_TYPE from PLD_KPI_ZD319_SUM
            where COMPANY_CODE = inCompany and CREATE_DATE = to_char(sysdate,'yyyymmdd')
        ) group by COMPANY_CODE, CREATE_DATE, BUYER_CODE having count(*) < 3
    ) loop
        -- 1. PR NON PO
        begin
            select * into t_sysdate from (
                select distinct CREATE_DATE from PLD_KPI_ZD319_SUM
                where COMPANY_CODE = rec1.COMPANY_CODE and CREATE_DATE = rec1.CREATE_DATE
                and REC_TYPE = '1. PR NON PO' and BUYER_CODE = rec1.BUYER_CODE
            ) where rownum <= 1;
        exception
            when others then
                insert into PLD_KPI_ZD319_SUM ( COMPANY_CODE, CREATE_DATE, REC_TYPE, REC_OVERDUE, REC_TOTAL, BUYER_CODE )
                    values ( rec1.COMPANY_CODE, rec1.CREATE_DATE, '1. PR NON PO', null, null, rec1.BUYER_CODE );
                commit;
        end;
        -- 2. PO NON CONFIRM
        begin
            select * into t_sysdate from (
                select distinct CREATE_DATE from PLD_KPI_ZD318_SUM
                where COMPANY_CODE = rec1.COMPANY_CODE and CREATE_DATE = rec1.CREATE_DATE
                and REC_TYPE = '2. PO NON CONFIRM' and BUYER_CODE = rec1.BUYER_CODE
            ) where rownum <= 1;
        exception
            when others then
                insert into PLD_KPI_ZD318_SUM ( COMPANY_CODE, CREATE_DATE, REC_TYPE, REC_OVERDUE, REC_TOTAL, BUYER_CODE )
                    values ( rec1.COMPANY_CODE, rec1.CREATE_DATE, '2. PO NON CONFIRM', null, null, rec1.BUYER_CODE );
                commit;
        end;
        -- 3. PO OVERDUE
        begin
            select * into t_sysdate from (
                select distinct CREATE_DATE from PLD_KPI_ZD318_SUM
                where COMPANY_CODE = rec1.COMPANY_CODE and CREATE_DATE = rec1.CREATE_DATE
                and REC_TYPE = '3. PO OVERDUE' and BUYER_CODE = rec1.BUYER_CODE
            ) where rownum <= 1;
        exception
            when others then
                insert into PLD_KPI_ZD318_SUM ( COMPANY_CODE, CREATE_DATE, REC_TYPE, REC_OVERDUE, REC_TOTAL, BUYER_CODE )
                    values ( rec1.COMPANY_CODE, rec1.CREATE_DATE, '3. PO OVERDUE', null, null, rec1.BUYER_CODE );
                commit;
        end;
    end loop;

    iTracePoint := 'A999';

EXCEPTION
    WHEN OTHERS THEN
        cErrorText := SQLERRM();
        MAIL_FILE_BIDBDBADMIN(in_to_name=>'nish_wu@usiglobal.com',subject   => '[PLD KPI] PL/SQL PLSQL_PLD_KPI_ZD319_PR ERROR - Company: ' || inCompany, message => '[PLSQL_PLD_KPI_ZD319_PR], The tracepoint is  ' || iTracePoint || ' and ErrorText=' || cErrorText) ;
END PLSQL_PLD_KPI_ZD319_PR;
/

