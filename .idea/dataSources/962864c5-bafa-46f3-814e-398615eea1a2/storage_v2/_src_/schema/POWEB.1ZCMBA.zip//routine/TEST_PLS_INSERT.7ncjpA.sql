create PROCEDURE test_pls_insert (p_array_size IN PLS_INTEGER DEFAULT 100)
IS
   type row_type is table of KPI_SAP001_COPA_TRX%rowtype index by binary_integer;
   rows row_type;
   tcount long ;
 begin
    --select count(*) into tcount from KPI_SAP001_COPA_TRX where period like '201201'  ;
    --dbms_output.put_line(to_char(tcount));
    select * bulk collect into rows from KPI_SAP001_COPA_TRX where period like '201201' ;
	--dbms_output.put_line(to_char(rows.count));
    for i in 1..rows.count
    loop
        INSERT INTO T1 VALUES rows(i);
    end loop;
END test_pls_insert;
/

